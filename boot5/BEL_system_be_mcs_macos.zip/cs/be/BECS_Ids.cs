// Copyright 2015 The Brace Authors. All rights reserved.
// Use of this source code is governed by the BSD-3-Clause
// license that can be found in the LICENSE file.

namespace be {

using System.Collections.Generic;

public class BECS_Ids {
    
    public static Dictionary<string, int> callIds;
    public static Dictionary<int, string> idCalls;
    
}

}

