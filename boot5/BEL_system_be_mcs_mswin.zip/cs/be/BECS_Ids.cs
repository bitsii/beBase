// Copyright 2015 Craig Welch
//
// Licensed under the MIT license. See LICENSE.txt file in the project root 
// for full license information.

namespace be {

using System.Collections.Generic;

public class BECS_Ids {
    
    public static Dictionary<string, int> callIds;
    public static Dictionary<int, string> idCalls;
    
}

}

