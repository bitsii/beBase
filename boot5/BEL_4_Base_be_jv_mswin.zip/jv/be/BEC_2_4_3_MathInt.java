package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(24));
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_0, 39));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_18 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_20 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bevo_21 = (new BEC_2_4_3_MathInt(43));
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_1, 21));
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_2, 1));
private static BEC_2_4_3_MathInt bevo_24 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_25 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_26 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_27 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_28 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bevo_29 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bevo_30 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_31 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_32 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_33 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_34 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_35 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_36 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_37 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bevo_38 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;
public BEC_2_4_3_MathInt bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt());
return (BEC_2_4_3_MathInt) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
this.bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
this.bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_2;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bevo_3;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_4;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bevo_5;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bevo_7;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_8;
if (beva_radix.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_4_tmpany_phold = bevo_9;
if (beva_radix.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_7_tmpany_phold = bevo_10;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_radix);
bevt_5_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 83 */
bevt_9_tmpany_phold = bevo_11;
if (beva_radix.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 88 */
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_11_tmpany_phold = bevo_12;
bevt_13_tmpany_phold = bevo_13;
bevt_12_tmpany_phold = beva_radix.bem_subtract_1(bevt_13_tmpany_phold);
bevl_maxA = bevt_11_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevo_14;
bevt_16_tmpany_phold = bevo_15;
bevt_15_tmpany_phold = beva_radix.bem_subtract_1(bevt_16_tmpany_phold);
bevl_maxa = bevt_14_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
this.bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
this.bevi_int = bevt_3_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_j = bevt_4_tmpany_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 102 */ {
bevt_6_tmpany_phold = bevo_16;
if (bevl_j.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 102 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpany_phold = bevo_17;
if (bevl_ic.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 106 */ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 106 */ {
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 109 */
 else  /* Line: 106 */ {
bevt_12_tmpany_phold = bevo_18;
if (bevl_ic.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 110 */ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevt_14_tmpany_phold = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 113 */
 else  /* Line: 106 */ {
bevt_16_tmpany_phold = bevo_19;
if (bevl_ic.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 114 */ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 114 */
 else  /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 114 */ {
bevt_18_tmpany_phold = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 117 */
 else  /* Line: 106 */ {
bevt_20_tmpany_phold = bevo_20;
if (bevl_ic.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_21_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_21_tmpany_phold);
} /* Line: 120 */
 else  /* Line: 106 */ {
bevt_23_tmpany_phold = bevo_21;
if (bevl_ic.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 121 */ {
} /* Line: 121 */
 else  /* Line: 123 */ {
bevt_28_tmpany_phold = bevo_22;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(beva_str);
bevt_29_tmpany_phold = bevo_23;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevl_ic);
bevt_24_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 124 */
} /* Line: 106 */
} /* Line: 106 */
} /* Line: 106 */
} /* Line: 106 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 127 */
 else  /* Line: 102 */ {
break;
} /* Line: 102 */
} /* Line: 102 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
this.bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bevo_24;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_6_tmpany_phold = bevo_25;
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) bevt_6_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(bevt_1_tmpany_phold, bevt_3_tmpany_phold, bevt_5_tmpany_phold, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = this.bem_toHexString_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_26;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_4_tmpany_phold = bevo_27;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_3(beva_res, bevt_1_tmpany_phold, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpany_phold = bevo_28;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(bevt_1_tmpany_phold, beva_zeroPad, beva_radix, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_29;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
beva_res.bem_clear_0();
bevl_ts = this.bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 200 */ {
bevt_1_tmpany_phold = bevo_30;
if (bevl_ts.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 200 */ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpany_phold = bevo_31;
if (bevl_val.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 203 */ {
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_tmpany_phold.bevi_int;
} /* Line: 204 */
 else  /* Line: 205 */ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 206 */
bevt_6_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int <= bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevt_9_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpany_phold = bevo_32;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpany_phold);
} /* Line: 210 */
bevt_11_tmpany_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpany_phold, bevl_val);
bevt_13_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpany_phold = bevo_33;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 217 */
 else  /* Line: 200 */ {
break;
} /* Line: 200 */
} /* Line: 200 */
while (true)
 /* Line: 220 */ {
bevt_19_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_19_tmpany_phold.bevi_int < beva_zeroPad.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_21_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_21_tmpany_phold.bevi_int <= bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_24_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpany_phold = bevo_34;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpany_phold);
} /* Line: 222 */
bevt_26_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpany_phold = bevo_35;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpany_phold = bevo_36;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpany_phold);
} /* Line: 226 */
 else  /* Line: 220 */ {
break;
} /* Line: 220 */
} /* Line: 220 */
bevt_36_tmpany_phold = bevo_37;
if (this.bevi_int < bevt_36_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 230 */ {
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 231 */
bevt_38_tmpany_phold = beva_res.bem_reverseBytes_0();
return bevt_38_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = this.bevi_int;
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_absValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_38;
if (this.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 247 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_2_tmpany_phold);
} /* Line: 248 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 268 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /* Line: 275 */
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 283 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /* Line: 290 */
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 326 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /* Line: 333 */
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 355 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /* Line: 362 */
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 384 */ {
bevl_res = (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /* Line: 391 */
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 413 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /* Line: 425 */
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 452 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /* Line: 459 */
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 600 */ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 600 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 600 */
 else  /* Line: 600 */ {
break;
} /* Line: 600 */
} /* Line: 600 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {63, 63, 66, 70, 74, 74, 74, 74, 74, 74, 74, 74, 74, 78, 78, 78, 78, 78, 78, 78, 78, 78, 82, 82, 82, 0, 82, 82, 82, 0, 0, 83, 83, 83, 83, 85, 85, 85, 86, 88, 90, 90, 91, 91, 91, 91, 92, 92, 92, 92, 93, 97, 97, 98, 98, 99, 100, 101, 102, 102, 102, 104, 106, 106, 106, 106, 106, 0, 0, 0, 107, 107, 108, 109, 110, 110, 110, 110, 110, 0, 0, 0, 111, 111, 112, 113, 114, 114, 114, 114, 114, 0, 0, 0, 115, 115, 116, 117, 118, 118, 118, 120, 120, 121, 121, 121, 124, 124, 124, 124, 124, 124, 124, 126, 127, 132, 132, 136, 140, 140, 144, 155, 173, 177, 177, 177, 177, 177, 177, 177, 177, 181, 181, 181, 181, 185, 185, 185, 185, 185, 185, 189, 189, 189, 189, 189, 193, 193, 193, 193, 197, 198, 199, 200, 200, 200, 201, 202, 203, 203, 203, 204, 204, 206, 209, 209, 209, 209, 210, 210, 210, 210, 212, 212, 213, 213, 213, 213, 217, 220, 220, 220, 221, 221, 221, 221, 222, 222, 222, 222, 224, 224, 224, 224, 225, 225, 225, 225, 230, 230, 230, 231, 231, 233, 233, 237, 238, 239, 243, 243, 243, 247, 247, 247, 248, 248, 264, 269, 275, 284, 290, 308, 322, 327, 333, 351, 356, 362, 380, 385, 391, 409, 414, 425, 448, 453, 459, 477, 481, 492, 506, 510, 521, 535, 539, 550, 564, 568, 579, 593, 598, 600, 600, 600, 601, 600, 603, 635, 635, 664, 664, 685, 685, 706, 706, 727, 727, 748, 748};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {67, 68, 71, 75, 87, 88, 89, 90, 91, 92, 93, 94, 95, 107, 108, 109, 110, 111, 112, 113, 114, 115, 139, 140, 145, 146, 149, 150, 155, 156, 159, 163, 164, 165, 166, 168, 169, 174, 175, 178, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 227, 228, 229, 230, 231, 232, 233, 236, 237, 242, 243, 244, 245, 250, 251, 256, 257, 260, 264, 267, 268, 269, 270, 273, 274, 279, 280, 285, 286, 289, 293, 296, 297, 298, 299, 302, 303, 308, 309, 314, 315, 318, 322, 325, 326, 327, 328, 331, 332, 337, 338, 339, 342, 343, 348, 351, 352, 353, 354, 355, 356, 357, 363, 364, 374, 375, 378, 383, 384, 387, 391, 394, 404, 405, 406, 407, 408, 409, 410, 411, 417, 418, 419, 420, 428, 429, 430, 431, 432, 433, 440, 441, 442, 443, 444, 450, 451, 452, 453, 497, 498, 499, 502, 503, 508, 509, 510, 511, 512, 517, 518, 519, 522, 524, 525, 526, 531, 532, 533, 534, 535, 537, 538, 539, 540, 541, 542, 543, 551, 552, 557, 558, 559, 560, 565, 566, 567, 568, 569, 571, 572, 573, 574, 575, 576, 577, 578, 584, 585, 590, 591, 592, 594, 595, 599, 600, 601, 606, 607, 608, 614, 615, 620, 621, 622, 629, 635, 638, 645, 648, 654, 659, 665, 668, 674, 680, 683, 689, 695, 698, 704, 710, 713, 719, 725, 728, 734, 738, 741, 746, 750, 753, 758, 762, 765, 770, 774, 777, 782, 788, 789, 792, 797, 798, 799, 805, 814, 815, 824, 825, 834, 835, 844, 845, 854, 855, 864, 865};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 63 67
new 0 63 67
return 1 63 68
setStringValueDec 1 66 71
setStringValueHex 1 70 75
assign 1 74 87
new 0 74 87
assign 1 74 88
once 0 74 88
assign 1 74 89
new 0 74 89
assign 1 74 90
once 0 74 90
assign 1 74 91
new 0 74 91
assign 1 74 92
once 0 74 92
assign 1 74 93
new 0 74 93
assign 1 74 94
once 0 74 94
setStringValue 5 74 95
assign 1 78 107
new 0 78 107
assign 1 78 108
once 0 78 108
assign 1 78 109
new 0 78 109
assign 1 78 110
once 0 78 110
assign 1 78 111
new 0 78 111
assign 1 78 112
once 0 78 112
assign 1 78 113
new 0 78 113
assign 1 78 114
once 0 78 114
setStringValue 5 78 115
assign 1 82 139
new 0 82 139
assign 1 82 140
lesser 1 82 145
assign 1 0 146
assign 1 82 149
new 0 82 149
assign 1 82 150
greater 1 82 155
assign 1 0 156
assign 1 0 159
assign 1 83 163
new 0 83 163
assign 1 83 164
add 1 83 164
assign 1 83 165
new 1 83 165
throw 1 83 166
assign 1 85 168
new 0 85 168
assign 1 85 169
lesser 1 85 174
assign 1 86 175
copy 0 86 175
assign 1 88 178
new 0 88 178
assign 1 90 180
new 0 90 180
addValue 1 90 181
assign 1 91 182
new 0 91 182
assign 1 91 183
new 0 91 183
assign 1 91 184
subtract 1 91 184
assign 1 91 185
add 1 91 185
assign 1 92 186
new 0 92 186
assign 1 92 187
new 0 92 187
assign 1 92 188
subtract 1 92 188
assign 1 92 189
add 1 92 189
setStringValue 5 93 190
assign 1 97 227
new 0 97 227
setValue 1 97 228
assign 1 98 229
sizeGet 0 98 229
assign 1 98 230
copy 0 98 230
decrementValue 0 99 231
assign 1 100 232
new 0 100 232
assign 1 101 233
new 0 101 233
assign 1 102 236
new 0 102 236
assign 1 102 237
greaterEquals 1 102 242
getInt 2 104 243
assign 1 106 244
new 0 106 244
assign 1 106 245
greater 1 106 250
assign 1 106 251
lesser 1 106 256
assign 1 0 257
assign 1 0 260
assign 1 0 264
assign 1 107 267
new 0 107 267
subtractValue 1 107 268
multiplyValue 1 108 269
addValue 1 109 270
assign 1 110 273
new 0 110 273
assign 1 110 274
greater 1 110 279
assign 1 110 280
lesser 1 110 285
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 111 296
new 0 111 296
subtractValue 1 111 297
multiplyValue 1 112 298
addValue 1 113 299
assign 1 114 302
new 0 114 302
assign 1 114 303
greater 1 114 308
assign 1 114 309
lesser 1 114 314
assign 1 0 315
assign 1 0 318
assign 1 0 322
assign 1 115 325
new 0 115 325
subtractValue 1 115 326
multiplyValue 1 116 327
addValue 1 117 328
assign 1 118 331
new 0 118 331
assign 1 118 332
equals 1 118 337
assign 1 120 338
new 0 120 338
multiplyValue 1 120 339
assign 1 121 342
new 0 121 342
assign 1 121 343
equals 1 121 348
assign 1 124 351
new 0 124 351
assign 1 124 352
add 1 124 352
assign 1 124 353
new 0 124 353
assign 1 124 354
add 1 124 354
assign 1 124 355
add 1 124 355
assign 1 124 356
new 1 124 356
throw 1 124 357
decrementValue 0 126 363
multiplyValue 1 127 364
assign 1 132 374
toString 0 132 374
return 1 132 375
new 1 136 378
assign 1 140 383
new 0 140 383
return 1 140 384
return 1 144 387
assign 1 155 391
new 0 155 391
return 1 173 394
assign 1 177 404
new 0 177 404
assign 1 177 405
new 1 177 405
assign 1 177 406
new 0 177 406
assign 1 177 407
once 0 177 407
assign 1 177 408
new 0 177 408
assign 1 177 409
once 0 177 409
assign 1 177 410
toString 4 177 410
return 1 177 411
assign 1 181 417
new 0 181 417
assign 1 181 418
new 1 181 418
assign 1 181 419
toHexString 1 181 419
return 1 181 420
assign 1 185 428
new 0 185 428
assign 1 185 429
once 0 185 429
assign 1 185 430
new 0 185 430
assign 1 185 431
once 0 185 431
assign 1 185 432
toString 3 185 432
return 1 185 433
assign 1 189 440
new 1 189 440
assign 1 189 441
new 0 189 441
assign 1 189 442
once 0 189 442
assign 1 189 443
toString 4 189 443
return 1 189 444
assign 1 193 450
new 0 193 450
assign 1 193 451
once 0 193 451
assign 1 193 452
toString 4 193 452
return 1 193 453
clear 0 197 497
assign 1 198 498
abs 0 198 498
assign 1 199 499
new 0 199 499
assign 1 200 502
new 0 200 502
assign 1 200 503
greater 1 200 508
setValue 1 201 509
modulusValue 1 202 510
assign 1 203 511
new 0 203 511
assign 1 203 512
lesser 1 203 517
assign 1 204 518
new 0 204 518
addValue 1 204 519
addValue 1 206 522
assign 1 209 524
capacityGet 0 209 524
assign 1 209 525
sizeGet 0 209 525
assign 1 209 526
lesserEquals 1 209 531
assign 1 210 532
capacityGet 0 210 532
assign 1 210 533
new 0 210 533
assign 1 210 534
add 1 210 534
capacitySet 1 210 535
assign 1 212 537
sizeGet 0 212 537
setIntUnchecked 2 212 538
assign 1 213 539
sizeGet 0 213 539
assign 1 213 540
new 0 213 540
assign 1 213 541
add 1 213 541
sizeSet 1 213 542
divideValue 1 217 543
assign 1 220 551
sizeGet 0 220 551
assign 1 220 552
lesser 1 220 557
assign 1 221 558
capacityGet 0 221 558
assign 1 221 559
sizeGet 0 221 559
assign 1 221 560
lesserEquals 1 221 565
assign 1 222 566
capacityGet 0 222 566
assign 1 222 567
new 0 222 567
assign 1 222 568
add 1 222 568
capacitySet 1 222 569
assign 1 224 571
sizeGet 0 224 571
assign 1 224 572
new 0 224 572
assign 1 224 573
once 0 224 573
setIntUnchecked 2 224 574
assign 1 225 575
sizeGet 0 225 575
assign 1 225 576
new 0 225 576
assign 1 225 577
add 1 225 577
sizeSet 1 225 578
assign 1 230 584
new 0 230 584
assign 1 230 585
lesser 1 230 590
assign 1 231 591
new 0 231 591
addValue 1 231 592
assign 1 233 594
reverseBytes 0 233 594
return 1 233 595
assign 1 237 599
new 0 237 599
setValue 1 238 600
return 1 239 601
assign 1 243 606
copy 0 243 606
assign 1 243 607
absValue 0 243 607
return 1 243 608
assign 1 247 614
new 0 247 614
assign 1 247 615
lesser 1 247 620
assign 1 248 621
new 0 248 621
multiplyValue 1 248 622
return 1 264 629
assign 1 269 635
new 0 269 635
return 1 275 638
assign 1 284 645
new 0 284 645
return 1 290 648
return 1 308 654
return 1 322 659
assign 1 327 665
new 0 327 665
return 1 333 668
return 1 351 674
assign 1 356 680
new 0 356 680
return 1 362 683
return 1 380 689
assign 1 385 695
new 0 385 695
return 1 391 698
return 1 409 704
assign 1 414 710
new 0 414 710
return 1 425 713
return 1 448 719
assign 1 453 725
new 0 453 725
return 1 459 728
return 1 477 734
assign 1 481 738
new 0 481 738
return 1 492 741
return 1 506 746
assign 1 510 750
new 0 510 750
return 1 521 753
return 1 535 758
assign 1 539 762
new 0 539 762
return 1 550 765
return 1 564 770
assign 1 568 774
new 0 568 774
return 1 579 777
return 1 593 782
assign 1 598 788
new 0 598 788
assign 1 600 789
new 0 600 789
assign 1 600 792
lesser 1 600 797
multiplyValue 1 601 798
incrementValue 0 600 799
return 1 603 805
assign 1 635 814
new 0 635 814
return 1 635 815
assign 1 664 824
new 0 664 824
return 1 664 825
assign 1 685 834
new 0 685 834
return 1 685 835
assign 1 706 844
new 0 706 844
return 1 706 845
assign 1 727 854
new 0 727 854
return 1 727 855
assign 1 748 864
new 0 748 864
return 1 748 865
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1085372256: return bem_increment_0();
case -314718434: return bem_print_0();
case 92614563: return bem_abs_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1205852557: return bem_incrementValue_0();
case 2011061582: return bem_vintGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 2022143834: return bem_vintSet_0();
case -1046151292: return bem_decrement_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 663753935: return bem_decrementValue_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1717721534: return bem_toHexString_0();
case 1820417453: return bem_create_0();
case 1832132624: return bem_absValue_0();
case 1865310226: return bem_toFloat_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -736217829: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 92659731: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1551584407: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 3419349: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 81310150: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -50808448: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2139839746: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1567199433: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case -202757140: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1580104161: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 696708346: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 364269035: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -1717721533: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -440702026: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case -477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1265088726: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2116933162: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 432448303: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1089696223: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1852231828: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -979186229: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 92957641: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -436987761: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -387946633: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 1245164300: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1774940959: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1670339153: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 1774940960: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1774940961: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 1670339156: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
}
