package be;
/* IO:File: source/base/Int.be */
public final class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(24));
private static byte[] bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_0, 39));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_18 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_20 = (new BEC_2_4_3_MathInt(45));
private static byte[] bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_1, 21));
private static byte[] bels_2 = {0x20};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bels_2, 1));
private static BEC_2_4_3_MathInt bevo_23 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_24 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_25 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_26 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_27 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bevo_28 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bevo_29 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_30 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_31 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_32 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_33 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_34 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_35 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_36 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bevo_37 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_3_MathInt bevs_inst;
public BEC_2_4_3_MathInt bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt());
return (BEC_2_4_3_MathInt) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
this.bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
this.bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_2;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bevo_3;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_4;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bevo_5;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bevo_7;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_8;
if (beva_radix.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_4_tmpany_phold = bevo_9;
if (beva_radix.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_7_tmpany_phold = bevo_10;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_radix);
bevt_5_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 83 */
bevt_9_tmpany_phold = bevo_11;
if (beva_radix.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 88 */
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_11_tmpany_phold = bevo_12;
bevt_13_tmpany_phold = bevo_13;
bevt_12_tmpany_phold = beva_radix.bem_subtract_1(bevt_13_tmpany_phold);
bevl_maxA = bevt_11_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevo_14;
bevt_16_tmpany_phold = bevo_15;
bevt_15_tmpany_phold = beva_radix.bem_subtract_1(bevt_16_tmpany_phold);
bevl_maxa = bevt_14_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
this.bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
this.bevi_int = bevt_3_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_j = bevt_4_tmpany_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 102 */ {
bevt_6_tmpany_phold = bevo_16;
if (bevl_j.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 102 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpany_phold = bevo_17;
if (bevl_ic.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 106 */ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 106 */
 else  /* Line: 106 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 106 */ {
bevt_10_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 109 */
 else  /* Line: 106 */ {
bevt_12_tmpany_phold = bevo_18;
if (bevl_ic.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 110 */ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 110 */
 else  /* Line: 110 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 110 */ {
bevt_14_tmpany_phold = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 113 */
 else  /* Line: 106 */ {
bevt_16_tmpany_phold = bevo_19;
if (bevl_ic.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 114 */ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 114 */
 else  /* Line: 114 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 114 */ {
bevt_18_tmpany_phold = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bevi_int += bevl_ic.bevi_int;
} /* Line: 117 */
 else  /* Line: 106 */ {
bevt_20_tmpany_phold = bevo_20;
if (bevl_ic.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_21_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_21_tmpany_phold);
} /* Line: 120 */
 else  /* Line: 121 */ {
bevt_26_tmpany_phold = bevo_21;
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(beva_str);
bevt_27_tmpany_phold = bevo_22;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevl_ic);
bevt_22_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_23_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_22_tmpany_phold);
} /* Line: 122 */
} /* Line: 106 */
} /* Line: 106 */
} /* Line: 106 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 125 */
 else  /* Line: 102 */ {
break;
} /* Line: 102 */
} /* Line: 102 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
this.bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bevo_23;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_6_tmpany_phold = bevo_24;
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) bevt_6_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(bevt_1_tmpany_phold, bevt_3_tmpany_phold, bevt_5_tmpany_phold, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = this.bem_toHexString_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_25;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_4_tmpany_phold = bevo_26;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_3(beva_res, bevt_1_tmpany_phold, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpany_phold = bevo_27;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(bevt_1_tmpany_phold, beva_zeroPad, beva_radix, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_28;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = this.bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
beva_res.bem_clear_0();
bevl_ts = this.bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 198 */ {
bevt_1_tmpany_phold = bevo_29;
if (bevl_ts.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpany_phold = bevo_30;
if (bevl_val.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 201 */ {
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_tmpany_phold.bevi_int;
} /* Line: 202 */
 else  /* Line: 203 */ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 204 */
bevt_6_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int <= bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_9_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpany_phold = bevo_31;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpany_phold);
} /* Line: 208 */
bevt_11_tmpany_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpany_phold, bevl_val);
bevt_13_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpany_phold = bevo_32;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 215 */
 else  /* Line: 198 */ {
break;
} /* Line: 198 */
} /* Line: 198 */
while (true)
 /* Line: 218 */ {
bevt_19_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_19_tmpany_phold.bevi_int < beva_zeroPad.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_21_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_21_tmpany_phold.bevi_int <= bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_24_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpany_phold = bevo_33;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpany_phold);
} /* Line: 220 */
bevt_26_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpany_phold = bevo_34;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpany_phold = bevo_35;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpany_phold);
} /* Line: 224 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevt_36_tmpany_phold = bevo_36;
if (this.bevi_int < bevt_36_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_3));
beva_res.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 229 */
bevt_38_tmpany_phold = beva_res.bem_reverseBytes_0();
return bevt_38_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = this.bevi_int;
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_absValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_37;
if (this.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 245 */ {
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_2_tmpany_phold);
} /* Line: 246 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 266 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /* Line: 273 */
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 281 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /* Line: 288 */
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 324 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /* Line: 331 */
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 353 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /* Line: 360 */
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 382 */ {
bevl_res = (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /* Line: 389 */
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 411 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /* Line: 423 */
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
 /* Line: 450 */ {
bevl_res = (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /* Line: 457 */
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 598 */ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 598 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 598 */
 else  /* Line: 598 */ {
break;
} /* Line: 598 */
} /* Line: 598 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {63, 63, 66, 70, 74, 74, 74, 74, 74, 74, 74, 74, 74, 78, 78, 78, 78, 78, 78, 78, 78, 78, 82, 82, 82, 0, 82, 82, 82, 0, 0, 83, 83, 83, 83, 85, 85, 85, 86, 88, 90, 90, 91, 91, 91, 91, 92, 92, 92, 92, 93, 97, 97, 98, 98, 99, 100, 101, 102, 102, 102, 104, 106, 106, 106, 106, 106, 0, 0, 0, 107, 107, 108, 109, 110, 110, 110, 110, 110, 0, 0, 0, 111, 111, 112, 113, 114, 114, 114, 114, 114, 0, 0, 0, 115, 115, 116, 117, 118, 118, 118, 120, 120, 122, 122, 122, 122, 122, 122, 122, 124, 125, 130, 130, 134, 138, 138, 142, 153, 171, 175, 175, 175, 175, 175, 175, 175, 175, 179, 179, 179, 179, 183, 183, 183, 183, 183, 183, 187, 187, 187, 187, 187, 191, 191, 191, 191, 195, 196, 197, 198, 198, 198, 199, 200, 201, 201, 201, 202, 202, 204, 207, 207, 207, 207, 208, 208, 208, 208, 210, 210, 211, 211, 211, 211, 215, 218, 218, 218, 219, 219, 219, 219, 220, 220, 220, 220, 222, 222, 222, 222, 223, 223, 223, 223, 228, 228, 228, 229, 229, 231, 231, 235, 236, 237, 241, 241, 241, 245, 245, 245, 246, 246, 262, 267, 273, 282, 288, 306, 320, 325, 331, 349, 354, 360, 378, 383, 389, 407, 412, 423, 446, 451, 457, 475, 479, 490, 504, 508, 519, 533, 537, 548, 562, 566, 577, 591, 596, 598, 598, 598, 599, 598, 601, 633, 633, 662, 662, 683, 683, 704, 704, 725, 725, 746, 746};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {66, 67, 70, 74, 86, 87, 88, 89, 90, 91, 92, 93, 94, 106, 107, 108, 109, 110, 111, 112, 113, 114, 138, 139, 144, 145, 148, 149, 154, 155, 158, 162, 163, 164, 165, 167, 168, 173, 174, 177, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 224, 225, 226, 227, 228, 229, 230, 233, 234, 239, 240, 241, 242, 247, 248, 253, 254, 257, 261, 264, 265, 266, 267, 270, 271, 276, 277, 282, 283, 286, 290, 293, 294, 295, 296, 299, 300, 305, 306, 311, 312, 315, 319, 322, 323, 324, 325, 328, 329, 334, 335, 336, 339, 340, 341, 342, 343, 344, 345, 350, 351, 361, 362, 365, 370, 371, 374, 378, 381, 391, 392, 393, 394, 395, 396, 397, 398, 404, 405, 406, 407, 415, 416, 417, 418, 419, 420, 427, 428, 429, 430, 431, 437, 438, 439, 440, 484, 485, 486, 489, 490, 495, 496, 497, 498, 499, 504, 505, 506, 509, 511, 512, 513, 518, 519, 520, 521, 522, 524, 525, 526, 527, 528, 529, 530, 538, 539, 544, 545, 546, 547, 552, 553, 554, 555, 556, 558, 559, 560, 561, 562, 563, 564, 565, 571, 572, 577, 578, 579, 581, 582, 586, 587, 588, 593, 594, 595, 601, 602, 607, 608, 609, 616, 622, 625, 632, 635, 641, 646, 652, 655, 661, 667, 670, 676, 682, 685, 691, 697, 700, 706, 712, 715, 721, 725, 728, 733, 737, 740, 745, 749, 752, 757, 761, 764, 769, 775, 776, 779, 784, 785, 786, 792, 801, 802, 811, 812, 821, 822, 831, 832, 841, 842, 851, 852};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 63 66
new 0 63 66
return 1 63 67
setStringValueDec 1 66 70
setStringValueHex 1 70 74
assign 1 74 86
new 0 74 86
assign 1 74 87
once 0 74 87
assign 1 74 88
new 0 74 88
assign 1 74 89
once 0 74 89
assign 1 74 90
new 0 74 90
assign 1 74 91
once 0 74 91
assign 1 74 92
new 0 74 92
assign 1 74 93
once 0 74 93
setStringValue 5 74 94
assign 1 78 106
new 0 78 106
assign 1 78 107
once 0 78 107
assign 1 78 108
new 0 78 108
assign 1 78 109
once 0 78 109
assign 1 78 110
new 0 78 110
assign 1 78 111
once 0 78 111
assign 1 78 112
new 0 78 112
assign 1 78 113
once 0 78 113
setStringValue 5 78 114
assign 1 82 138
new 0 82 138
assign 1 82 139
lesser 1 82 144
assign 1 0 145
assign 1 82 148
new 0 82 148
assign 1 82 149
greater 1 82 154
assign 1 0 155
assign 1 0 158
assign 1 83 162
new 0 83 162
assign 1 83 163
add 1 83 163
assign 1 83 164
new 1 83 164
throw 1 83 165
assign 1 85 167
new 0 85 167
assign 1 85 168
lesser 1 85 173
assign 1 86 174
copy 0 86 174
assign 1 88 177
new 0 88 177
assign 1 90 179
new 0 90 179
addValue 1 90 180
assign 1 91 181
new 0 91 181
assign 1 91 182
new 0 91 182
assign 1 91 183
subtract 1 91 183
assign 1 91 184
add 1 91 184
assign 1 92 185
new 0 92 185
assign 1 92 186
new 0 92 186
assign 1 92 187
subtract 1 92 187
assign 1 92 188
add 1 92 188
setStringValue 5 93 189
assign 1 97 224
new 0 97 224
setValue 1 97 225
assign 1 98 226
sizeGet 0 98 226
assign 1 98 227
copy 0 98 227
decrementValue 0 99 228
assign 1 100 229
new 0 100 229
assign 1 101 230
new 0 101 230
assign 1 102 233
new 0 102 233
assign 1 102 234
greaterEquals 1 102 239
getInt 2 104 240
assign 1 106 241
new 0 106 241
assign 1 106 242
greater 1 106 247
assign 1 106 248
lesser 1 106 253
assign 1 0 254
assign 1 0 257
assign 1 0 261
assign 1 107 264
new 0 107 264
subtractValue 1 107 265
multiplyValue 1 108 266
addValue 1 109 267
assign 1 110 270
new 0 110 270
assign 1 110 271
greater 1 110 276
assign 1 110 277
lesser 1 110 282
assign 1 0 283
assign 1 0 286
assign 1 0 290
assign 1 111 293
new 0 111 293
subtractValue 1 111 294
multiplyValue 1 112 295
addValue 1 113 296
assign 1 114 299
new 0 114 299
assign 1 114 300
greater 1 114 305
assign 1 114 306
lesser 1 114 311
assign 1 0 312
assign 1 0 315
assign 1 0 319
assign 1 115 322
new 0 115 322
subtractValue 1 115 323
multiplyValue 1 116 324
addValue 1 117 325
assign 1 118 328
new 0 118 328
assign 1 118 329
equals 1 118 334
assign 1 120 335
new 0 120 335
multiplyValue 1 120 336
assign 1 122 339
new 0 122 339
assign 1 122 340
add 1 122 340
assign 1 122 341
new 0 122 341
assign 1 122 342
add 1 122 342
assign 1 122 343
add 1 122 343
assign 1 122 344
new 1 122 344
throw 1 122 345
decrementValue 0 124 350
multiplyValue 1 125 351
assign 1 130 361
toString 0 130 361
return 1 130 362
new 1 134 365
assign 1 138 370
new 0 138 370
return 1 138 371
return 1 142 374
assign 1 153 378
new 0 153 378
return 1 171 381
assign 1 175 391
new 0 175 391
assign 1 175 392
new 1 175 392
assign 1 175 393
new 0 175 393
assign 1 175 394
once 0 175 394
assign 1 175 395
new 0 175 395
assign 1 175 396
once 0 175 396
assign 1 175 397
toString 4 175 397
return 1 175 398
assign 1 179 404
new 0 179 404
assign 1 179 405
new 1 179 405
assign 1 179 406
toHexString 1 179 406
return 1 179 407
assign 1 183 415
new 0 183 415
assign 1 183 416
once 0 183 416
assign 1 183 417
new 0 183 417
assign 1 183 418
once 0 183 418
assign 1 183 419
toString 3 183 419
return 1 183 420
assign 1 187 427
new 1 187 427
assign 1 187 428
new 0 187 428
assign 1 187 429
once 0 187 429
assign 1 187 430
toString 4 187 430
return 1 187 431
assign 1 191 437
new 0 191 437
assign 1 191 438
once 0 191 438
assign 1 191 439
toString 4 191 439
return 1 191 440
clear 0 195 484
assign 1 196 485
abs 0 196 485
assign 1 197 486
new 0 197 486
assign 1 198 489
new 0 198 489
assign 1 198 490
greater 1 198 495
setValue 1 199 496
modulusValue 1 200 497
assign 1 201 498
new 0 201 498
assign 1 201 499
lesser 1 201 504
assign 1 202 505
new 0 202 505
addValue 1 202 506
addValue 1 204 509
assign 1 207 511
capacityGet 0 207 511
assign 1 207 512
sizeGet 0 207 512
assign 1 207 513
lesserEquals 1 207 518
assign 1 208 519
capacityGet 0 208 519
assign 1 208 520
new 0 208 520
assign 1 208 521
add 1 208 521
capacitySet 1 208 522
assign 1 210 524
sizeGet 0 210 524
setIntUnchecked 2 210 525
assign 1 211 526
sizeGet 0 211 526
assign 1 211 527
new 0 211 527
assign 1 211 528
add 1 211 528
sizeSet 1 211 529
divideValue 1 215 530
assign 1 218 538
sizeGet 0 218 538
assign 1 218 539
lesser 1 218 544
assign 1 219 545
capacityGet 0 219 545
assign 1 219 546
sizeGet 0 219 546
assign 1 219 547
lesserEquals 1 219 552
assign 1 220 553
capacityGet 0 220 553
assign 1 220 554
new 0 220 554
assign 1 220 555
add 1 220 555
capacitySet 1 220 556
assign 1 222 558
sizeGet 0 222 558
assign 1 222 559
new 0 222 559
assign 1 222 560
once 0 222 560
setIntUnchecked 2 222 561
assign 1 223 562
sizeGet 0 223 562
assign 1 223 563
new 0 223 563
assign 1 223 564
add 1 223 564
sizeSet 1 223 565
assign 1 228 571
new 0 228 571
assign 1 228 572
lesser 1 228 577
assign 1 229 578
new 0 229 578
addValue 1 229 579
assign 1 231 581
reverseBytes 0 231 581
return 1 231 582
assign 1 235 586
new 0 235 586
setValue 1 236 587
return 1 237 588
assign 1 241 593
copy 0 241 593
assign 1 241 594
absValue 0 241 594
return 1 241 595
assign 1 245 601
new 0 245 601
assign 1 245 602
lesser 1 245 607
assign 1 246 608
new 0 246 608
multiplyValue 1 246 609
return 1 262 616
assign 1 267 622
new 0 267 622
return 1 273 625
assign 1 282 632
new 0 282 632
return 1 288 635
return 1 306 641
return 1 320 646
assign 1 325 652
new 0 325 652
return 1 331 655
return 1 349 661
assign 1 354 667
new 0 354 667
return 1 360 670
return 1 378 676
assign 1 383 682
new 0 383 682
return 1 389 685
return 1 407 691
assign 1 412 697
new 0 412 697
return 1 423 700
return 1 446 706
assign 1 451 712
new 0 451 712
return 1 457 715
return 1 475 721
assign 1 479 725
new 0 479 725
return 1 490 728
return 1 504 733
assign 1 508 737
new 0 508 737
return 1 519 740
return 1 533 745
assign 1 537 749
new 0 537 749
return 1 548 752
return 1 562 757
assign 1 566 761
new 0 566 761
return 1 577 764
return 1 591 769
assign 1 596 775
new 0 596 775
assign 1 598 776
new 0 598 776
assign 1 598 779
lesser 1 598 784
multiplyValue 1 599 785
incrementValue 0 598 786
return 1 601 792
assign 1 633 801
new 0 633 801
return 1 633 802
assign 1 662 811
new 0 662 811
return 1 662 812
assign 1 683 821
new 0 683 821
return 1 683 822
assign 1 704 831
new 0 704 831
return 1 704 832
assign 1 725 841
new 0 725 841
return 1 725 842
assign 1 746 851
new 0 746 851
return 1 746 852
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1085372256: return bem_increment_0();
case -314718434: return bem_print_0();
case 92614563: return bem_abs_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1205852557: return bem_incrementValue_0();
case 2011061582: return bem_vintGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 2022143834: return bem_vintSet_0();
case -1046151292: return bem_decrement_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 663753935: return bem_decrementValue_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1717721534: return bem_toHexString_0();
case 1820417453: return bem_create_0();
case 1832132624: return bem_absValue_0();
case 1865310226: return bem_toFloat_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -736217829: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 92659731: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1551584407: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 3419349: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 81310150: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -50808448: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2139839746: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1567199433: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case -202757140: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1580104161: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 696708346: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 364269035: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -1717721533: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -440702026: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case -477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1265088726: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2116933162: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 432448303: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1089696223: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1852231828: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -979186229: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 92957641: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -436987761: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -387946633: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 1245164300: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1774940959: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1670339153: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 1774940960: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1774940961: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 1670339156: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bevs_inst = (BEC_2_4_3_MathInt)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bevs_inst;
}
}
