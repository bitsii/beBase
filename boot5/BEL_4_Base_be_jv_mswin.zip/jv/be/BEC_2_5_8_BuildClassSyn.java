package be;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_8_BuildClassSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 9));
private static byte[] bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_4, 78));
private static byte[] bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_5, 12));
private static byte[] bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_6, 38));
private static byte[] bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_7, 68));
private static byte[] bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_8, 75));
private static byte[] bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_10, 65));
private static byte[] bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_11, 11));
private static byte[] bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_12, 33));
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_14, 95));
private static byte[] bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_15, 84));
private static byte[] bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_16, 80));
private static byte[] bels_17 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_17, 9));
private static byte[] bels_18 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_18, 26));
public static BEC_2_5_8_BuildClassSyn bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_4_ContainerList bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_4_ContainerList bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public BEC_2_5_8_BuildClassSyn bem_new_0() throws Throwable {
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
bevp_integrated = be.BECS_Runtime.boolFalse;
bevp_iChecked = be.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = be.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_maxMtdx = (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 98 */ {
bevt_0_tmpany_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_ms.bem_mtdxGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 100 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 101 */
} /* Line: 100 */
 else  /* Line: 98 */ {
break;
} /* Line: 98 */
} /* Line: 98 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpany_phold);
if (bevl_dmtd == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 111 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) throws Throwable {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
bevp_integrated = be.BECS_Runtime.boolFalse;
bevp_iChecked = be.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = beva_psyn.bemd_0(-1974592946, BEL_4_Base.bevn_superListGet_0);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_3_tmpany_phold = beva_psyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_superList.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = beva_psyn.bemd_0(1477961836, BEL_4_Base.bevn_mtdListGet_0);
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_4_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_5_tmpany_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_5_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevt_7_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_6_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 134 */ {
bevt_8_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 134 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = beva_psyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_11_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_9_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_10_tmpany_phold);
bevt_14_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_1));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_15_tmpany_phold);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 137 */ {
if (bevl_pv == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
 else  /* Line: 137 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 137 */ {
bevt_19_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpany_phold).bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
 else  /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 137 */ {
bevt_24_tmpany_phold = bevo_1;
bevt_26_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevo_2;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_20_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 138 */
} /* Line: 137 */
 else  /* Line: 134 */ {
break;
} /* Line: 134 */
} /* Line: 134 */
bevt_31_tmpany_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevl_iv = bevt_31_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 143 */ {
bevt_32_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpany_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_33_tmpany_phold != null && bevt_33_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpany_phold).bevi_bool) /* Line: 145 */ {
bevt_35_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpany_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpany_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_36_tmpany_phold);
} /* Line: 146 */
} /* Line: 145 */
 else  /* Line: 143 */ {
break;
} /* Line: 143 */
} /* Line: 143 */
bevt_39_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_38_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 150 */ {
bevt_40_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpany_phold).bevi_bool) /* Line: 150 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpany_phold = beva_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_43_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_41_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_42_tmpany_phold);
if (bevl_pm == null) {
bevt_44_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_46_tmpany_phold = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevt_46_tmpany_phold == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 154 */ {
bevt_49_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_48_tmpany_phold == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevt_54_tmpany_phold = bevo_3;
bevt_56_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bem_add_1(bevt_55_tmpany_phold);
bevt_57_tmpany_phold = bevo_4;
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bem_add_1(bevt_57_tmpany_phold);
bevt_59_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_50_tmpany_phold);
} /* Line: 156 */
} /* Line: 155 */
} /* Line: 154 */
} /* Line: 153 */
 else  /* Line: 150 */ {
break;
} /* Line: 150 */
} /* Line: 150 */
this.bem_loadClass_1(beva_klass);
bevt_60_tmpany_phold = beva_psyn.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevt_61_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_61_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpany_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpany_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 170 */ {
return this;
} /* Line: 170 */
bevp_integrated = be.BECS_Runtime.boolTrue;
bevp_directProperties = be.BECS_Runtime.boolTrue;
bevp_directMethods = be.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 175 */ {
bevp_allAncestorsClose = be.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpany_loop = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 180 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 180 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_methodIndexesGet_0();
bevt_10_tmpany_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpany_phold.bem_put_1(bevt_10_tmpany_phold);
} /* Line: 181 */
 else  /* Line: 180 */ {
break;
} /* Line: 180 */
} /* Line: 180 */
return this;
} /* Line: 183 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (new BEC_2_4_3_MathInt(0));
bevt_11_tmpany_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpany_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpany_phold.bem_subtract_1(bevt_12_tmpany_phold);
bevt_15_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 190 */
bevt_16_tmpany_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 191 */ {
bevt_19_tmpany_phold = bevo_5;
bevt_20_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_17_tmpany_phold);
} /* Line: 192 */
bevt_21_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_23_tmpany_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 194 */
 else  /* Line: 194 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 194 */ {
bevt_26_tmpany_phold = bevo_6;
bevt_27_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_24_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 195 */
bevt_28_tmpany_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 197 */ {
if (bevp_isLocal.bevi_bool) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 197 */
 else  /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 197 */ {
if (bevp_isFinal.bevi_bool) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 197 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 197 */
 else  /* Line: 197 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 197 */ {
bevt_33_tmpany_phold = bevo_7;
bevt_34_tmpany_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevt_31_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_31_tmpany_phold);
} /* Line: 198 */
bevt_1_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 200 */ {
bevt_35_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_35_tmpany_phold != null && bevt_35_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpany_phold).bevi_bool) /* Line: 200 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_has_1(bevt_39_tmpany_phold);
if (bevt_37_tmpany_phold.bevi_bool) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevt_41_tmpany_phold = bevl_pn.bem_toString_0();
bevt_42_tmpany_phold = bevo_8;
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_notEquals_1(bevt_42_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 202 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 202 */
 else  /* Line: 202 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 202 */ {
bevp_directProperties = be.BECS_Runtime.boolFalse;
bevp_directMethods = be.BECS_Runtime.boolFalse;
} /* Line: 205 */
bevt_45_tmpany_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpany_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpany_phold = bevt_45_tmpany_phold.bem_has_1(bevt_46_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevp_allAncestorsClose = be.BECS_Runtime.boolFalse;
} /* Line: 208 */
} /* Line: 207 */
 else  /* Line: 200 */ {
break;
} /* Line: 200 */
} /* Line: 200 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 212 */ {
bevt_47_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpany_phold != null && bevt_47_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpany_phold).bevi_bool) /* Line: 212 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_48_tmpany_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpany_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpany_phold.bem_get_1(bevt_49_tmpany_phold);
if (bevl_pm == null) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevt_51_tmpany_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpany_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 219 */
} /* Line: 216 */
 else  /* Line: 221 */ {
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpany_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpany_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_methodIndexesGet_0();
bevt_57_tmpany_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpany_phold.bem_put_1(bevt_57_tmpany_phold);
} /* Line: 225 */
} /* Line: 215 */
 else  /* Line: 212 */ {
break;
} /* Line: 212 */
} /* Line: 212 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 232 */ {
return this;
} /* Line: 232 */
bevp_iChecked = be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 234 */ {
return this;
} /* Line: 234 */
bevl_psyn = beva_build.bemd_1(-706249818, BEL_4_Base.bevn_getSynNp_1, bevp_superNp);
bevt_4_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_3_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 236 */ {
bevt_5_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 236 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_6_tmpany_phold = bevl_psyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_8_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_6_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpany_phold);
if (bevl_pv == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_11_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 240 */ {
bevt_16_tmpany_phold = bevo_9;
bevt_18_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_19_tmpany_phold = bevo_10;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_22_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_12_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_13_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_12_tmpany_phold);
} /* Line: 241 */
 else  /* Line: 242 */ {
bevt_23_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpany_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_23_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_24_tmpany_phold);
bevt_26_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpany_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_27_tmpany_phold);
} /* Line: 244 */
} /* Line: 240 */
} /* Line: 239 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
bevt_30_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_29_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 248 */ {
bevt_31_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpany_phold).bevi_bool) /* Line: 248 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_32_tmpany_phold = bevl_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_34_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_32_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_33_tmpany_phold);
if (bevl_pm == null) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_36_tmpany_phold = bevl_pm.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
if (bevt_36_tmpany_phold != null && bevt_36_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpany_phold).bevi_bool) /* Line: 252 */ {
bevt_41_tmpany_phold = bevo_11;
bevt_43_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_add_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevo_12;
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_add_1(bevt_44_tmpany_phold);
bevt_47_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_37_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_38_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_37_tmpany_phold);
} /* Line: 253 */
bevt_49_tmpany_phold = bevl_om.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_oa = bevt_48_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 256 */ {
bevt_52_tmpany_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_50_tmpany_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_51_tmpany_phold);
if (bevt_50_tmpany_phold != null && bevt_50_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpany_phold).bevi_bool) /* Line: 256 */ {
bevt_53_tmpany_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_pmr = bevt_53_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_54_tmpany_phold = bevl_oa.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevl_omr = bevt_54_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
this.bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 256 */
 else  /* Line: 256 */ {
break;
} /* Line: 256 */
} /* Line: 256 */
bevl_pmr = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
bevt_55_tmpany_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_omr = bevt_55_tmpany_phold.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevl_pmr == null) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
if (bevl_omr == null) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 264 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 264 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 264 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 264 */ {
if (bevl_pmr == null) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpany_phold.bevi_bool) {
bevt_58_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_58_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_58_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 265 */ {
if (bevl_omr == null) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_61_tmpany_phold.bevi_bool) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 265 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 265 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 265 */ {
bevt_64_tmpany_phold = bevo_13;
bevt_67_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_add_1(bevt_65_tmpany_phold);
bevt_62_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_63_tmpany_phold, bevl_om);
throw new be.BECS_ThrowBack(bevt_62_tmpany_phold);
} /* Line: 266 */
} /* Line: 265 */
 else  /* Line: 268 */ {
this.bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 270 */
} /* Line: 264 */
} /* Line: 251 */
 else  /* Line: 248 */ {
break;
} /* Line: 248 */
} /* Line: 248 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) throws Throwable {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
bevt_2_tmpany_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_3_tmpany_phold = beva_omr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_3_tmpany_phold);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevt_6_tmpany_phold = bevo_14;
bevt_9_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 278 */
 else  /* Line: 277 */ {
bevt_10_tmpany_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 279 */ {
bevt_11_tmpany_phold = beva_pmr.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevt_12_tmpany_phold = beva_omr.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 282 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
 else  /* Line: 282 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 282 */ {
return this;
} /* Line: 283 */
bevt_13_tmpany_phold = beva_omr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_osyn = beva_build.bemd_1(-706249818, BEL_4_Base.bevn_getSynNp_1, bevt_13_tmpany_phold);
bevt_16_tmpany_phold = bevl_osyn.bemd_0(-986531569, BEL_4_Base.bevn_allTypesGet_0);
bevt_17_tmpany_phold = beva_pmr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_17_tmpany_phold);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 286 */ {
bevt_20_tmpany_phold = bevo_15;
bevt_23_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpany_phold, beva_om);
throw new be.BECS_ThrowBack(bevt_18_tmpany_phold);
} /* Line: 287 */
} /* Line: 286 */
} /* Line: 277 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
this.bem_new_0();
bevt_1_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_0_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 294 */ {
bevt_2_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 294 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 296 */ {
bevt_10_tmpany_phold = bevo_16;
bevt_12_tmpany_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevo_17;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_16_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpany_phold, bevl_ov);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 297 */
} /* Line: 296 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
this.bem_loadClass_1(beva_klass);
bevp_depth = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_1_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_2_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bemd_0(-1803479881, BEL_4_Base.bevn_libNameGet_0);
bevt_3_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpany_phold.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_4_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpany_phold.bemd_0(-842582618, BEL_4_Base.bevn_isLocalGet_0);
bevt_5_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpany_phold.bemd_0(363636983, BEL_4_Base.bevn_isNotNullGet_0);
bevt_7_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-83882038, BEL_4_Base.bevn_usedGet_0);
bevl_iu = bevt_6_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 312 */ {
bevt_8_tmpany_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 312 */ {
bevl_ou = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = bevl_ou.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_uses.bem_put_1(bevt_9_tmpany_phold);
} /* Line: 314 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
bevt_11_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_10_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 316 */ {
bevt_12_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 316 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 319 */
 else  /* Line: 316 */ {
break;
} /* Line: 316 */
} /* Line: 316 */
bevt_14_tmpany_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_13_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 321 */ {
bevt_15_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 321 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 324 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
this.bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_postLoad_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_nptyList = null;
BEC_2_9_4_ContainerList bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
bevl_nptyList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_mtdnList = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 334 */ {
bevt_1_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 334 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpany_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 336 */ {
bevt_5_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_ptyMap.bem_put_2(bevt_5_tmpany_phold, bevl_ov);
} /* Line: 338 */
} /* Line: 336 */
 else  /* Line: 334 */ {
break;
} /* Line: 334 */
} /* Line: 334 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 344 */ {
bevt_6_tmpany_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 344 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpany_phold = bevl_unq.bem_has_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_10_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpany_phold);
bevl_nom.bemd_1(1283009805, BEL_4_Base.bevn_mposSet_1, bevl_mpos);
bevt_11_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpany_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpany_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
} /* Line: 351 */
} /* Line: 346 */
 else  /* Line: 344 */ {
break;
} /* Line: 344 */
} /* Line: 344 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 358 */ {
bevt_14_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 358 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_15_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_mtdMap.bem_put_2(bevt_15_tmpany_phold, bevl_om);
bevt_18_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpany_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 363 */ {
bevt_19_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdOmap.bem_put_2(bevt_19_tmpany_phold, bevl_om);
} /* Line: 364 */
} /* Line: 363 */
 else  /* Line: 358 */ {
break;
} /* Line: 358 */
} /* Line: 358 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 370 */ {
bevt_20_tmpany_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpany_phold != null && bevt_20_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpany_phold).bevi_bool) /* Line: 370 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_22_tmpany_phold = bevl_unq.bem_has_1(bevt_23_tmpany_phold);
if (bevt_22_tmpany_phold.bevi_bool) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_24_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpany_phold == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_28_tmpany_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpany_phold);
} /* Line: 384 */
bevt_29_tmpany_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(-885379526, BEL_4_Base.bevn_declarationSet_1, bevt_29_tmpany_phold);
bevl_oma.bemd_1(-1365143591, BEL_4_Base.bevn_mtdxSet_1, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpany_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
} /* Line: 390 */
} /* Line: 372 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpany_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 395 */ {
bevt_32_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 395 */ {
bevl_s = bevt_0_tmpany_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 397 */
 else  /* Line: 395 */ {
break;
} /* Line: 395 */
} /* Line: 395 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() throws Throwable {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
return bevp_depth;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() throws Throwable {
return bevp_newMbrs;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() throws Throwable {
return bevp_newMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() throws Throwable {
return bevp_defMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() throws Throwable {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() throws Throwable {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() throws Throwable {
return bevp_allTypes;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() throws Throwable {
return bevp_superList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() throws Throwable {
return bevp_mtdMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGet_0() throws Throwable {
return bevp_mtdList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() throws Throwable {
return bevp_ptyMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGet_0() throws Throwable {
return bevp_ptyList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() throws Throwable {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() throws Throwable {
return bevp_integrated;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() throws Throwable {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() throws Throwable {
return bevp_uses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() throws Throwable {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() throws Throwable {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {74, 76, 78, 80, 81, 82, 83, 84, 85, 86, 87, 89, 90, 91, 92, 97, 98, 98, 99, 100, 100, 100, 101, 104, 108, 108, 109, 109, 111, 111, 113, 113, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 128, 129, 129, 130, 130, 131, 131, 134, 134, 134, 134, 135, 136, 136, 136, 136, 137, 137, 137, 137, 137, 137, 0, 0, 0, 137, 137, 137, 0, 0, 0, 138, 138, 138, 138, 138, 138, 138, 138, 138, 138, 138, 138, 143, 143, 143, 144, 145, 145, 146, 146, 146, 146, 150, 150, 150, 150, 151, 152, 152, 152, 152, 153, 153, 154, 154, 154, 155, 155, 155, 155, 156, 156, 156, 156, 156, 156, 156, 156, 156, 156, 156, 161, 162, 162, 162, 166, 166, 170, 171, 172, 173, 174, 175, 175, 176, 177, 178, 179, 180, 0, 180, 180, 181, 181, 181, 181, 183, 185, 186, 187, 189, 189, 189, 189, 190, 190, 190, 191, 192, 192, 192, 192, 192, 194, 194, 194, 0, 0, 0, 195, 195, 195, 195, 195, 197, 197, 197, 0, 0, 0, 197, 197, 0, 0, 0, 198, 198, 198, 198, 198, 200, 0, 200, 200, 201, 202, 202, 202, 202, 202, 202, 202, 202, 0, 0, 0, 204, 205, 207, 207, 207, 207, 207, 208, 212, 212, 213, 214, 214, 214, 215, 215, 216, 217, 217, 218, 218, 219, 222, 222, 223, 224, 225, 225, 225, 225, 232, 233, 234, 234, 234, 235, 236, 236, 236, 236, 237, 238, 238, 238, 238, 239, 239, 240, 240, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 243, 243, 243, 243, 244, 244, 244, 244, 248, 248, 248, 248, 249, 250, 250, 250, 250, 251, 251, 252, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 255, 255, 255, 256, 256, 256, 256, 257, 257, 258, 258, 260, 256, 262, 263, 263, 264, 264, 0, 264, 264, 0, 0, 265, 265, 265, 0, 265, 265, 265, 0, 0, 266, 266, 266, 266, 266, 266, 266, 270, 277, 277, 277, 278, 278, 278, 278, 278, 278, 278, 279, 282, 282, 0, 0, 0, 283, 285, 285, 286, 286, 286, 286, 287, 287, 287, 287, 287, 287, 287, 293, 294, 294, 294, 294, 295, 296, 296, 296, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 297, 300, 301, 306, 306, 307, 307, 308, 308, 309, 309, 310, 310, 311, 311, 312, 312, 312, 312, 313, 314, 314, 316, 316, 316, 316, 317, 318, 319, 321, 321, 321, 321, 322, 323, 324, 326, 330, 331, 334, 334, 335, 336, 336, 336, 336, 338, 338, 342, 343, 344, 344, 345, 346, 346, 346, 346, 347, 347, 348, 349, 349, 350, 351, 351, 351, 354, 356, 358, 358, 359, 361, 361, 363, 363, 363, 363, 364, 364, 368, 369, 370, 370, 371, 372, 372, 372, 372, 373, 373, 382, 382, 383, 383, 383, 384, 384, 386, 386, 387, 388, 389, 390, 390, 390, 393, 395, 0, 395, 395, 396, 397, 400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 97, 98, 101, 103, 104, 105, 110, 111, 118, 126, 127, 128, 133, 134, 135, 137, 138, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 235, 237, 238, 239, 240, 241, 242, 243, 244, 245, 247, 252, 253, 256, 260, 263, 264, 265, 267, 270, 274, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 295, 296, 299, 301, 302, 303, 305, 306, 307, 308, 315, 316, 317, 320, 322, 323, 324, 325, 326, 327, 332, 333, 334, 339, 340, 341, 342, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 367, 368, 369, 370, 375, 376, 444, 446, 447, 448, 449, 450, 455, 456, 457, 458, 459, 460, 460, 463, 465, 466, 467, 468, 469, 475, 477, 478, 479, 480, 481, 482, 483, 484, 485, 487, 489, 491, 492, 493, 494, 495, 497, 499, 500, 502, 505, 509, 512, 513, 514, 515, 516, 518, 520, 525, 526, 529, 533, 536, 541, 542, 545, 549, 552, 553, 554, 555, 556, 558, 558, 561, 563, 564, 565, 566, 567, 568, 573, 574, 575, 576, 578, 581, 585, 588, 589, 591, 592, 593, 594, 599, 600, 607, 610, 612, 613, 614, 615, 616, 621, 622, 624, 625, 626, 627, 628, 632, 633, 634, 635, 636, 637, 638, 639, 729, 731, 732, 737, 738, 740, 741, 742, 743, 746, 748, 749, 750, 751, 752, 753, 758, 759, 760, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 776, 777, 778, 779, 780, 781, 782, 783, 791, 792, 793, 796, 798, 799, 800, 801, 802, 803, 808, 809, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 824, 825, 826, 827, 830, 831, 832, 834, 835, 836, 837, 838, 839, 845, 846, 847, 848, 853, 854, 857, 862, 863, 866, 870, 875, 880, 881, 884, 889, 894, 895, 898, 902, 903, 904, 905, 906, 907, 908, 912, 948, 949, 950, 952, 953, 954, 955, 956, 957, 958, 961, 963, 965, 967, 970, 974, 977, 979, 980, 981, 982, 983, 984, 986, 987, 988, 989, 990, 991, 992, 1018, 1019, 1020, 1021, 1024, 1026, 1027, 1028, 1029, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1049, 1050, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1095, 1097, 1098, 1099, 1105, 1106, 1107, 1110, 1112, 1113, 1114, 1120, 1121, 1122, 1125, 1127, 1128, 1129, 1135, 1186, 1187, 1188, 1191, 1193, 1194, 1195, 1196, 1201, 1202, 1203, 1210, 1211, 1212, 1215, 1217, 1218, 1219, 1220, 1225, 1226, 1227, 1228, 1229, 1230, 1231, 1232, 1233, 1234, 1241, 1242, 1243, 1246, 1248, 1249, 1250, 1251, 1252, 1253, 1258, 1259, 1260, 1267, 1268, 1269, 1272, 1274, 1275, 1276, 1277, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1293, 1294, 1295, 1297, 1298, 1299, 1300, 1301, 1302, 1303, 1304, 1311, 1312, 1312, 1315, 1317, 1318, 1319, 1325, 1329, 1332, 1336, 1339, 1343, 1346, 1350, 1353, 1357, 1360, 1364, 1367, 1371, 1374, 1378, 1381, 1385, 1388, 1392, 1395, 1399, 1402, 1406, 1409, 1413, 1416, 1420, 1423, 1427, 1430, 1434, 1437, 1441, 1444, 1448, 1451, 1455, 1458, 1462, 1465, 1469, 1472, 1476, 1479, 1483, 1486, 1490, 1493, 1497, 1500, 1504, 1507, 1511, 1514};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 74 73
new 0 74 73
assign 1 76 74
new 0 76 74
assign 1 78 75
new 0 78 75
assign 1 80 76
new 0 80 76
assign 1 81 77
new 0 81 77
assign 1 82 78
new 0 82 78
assign 1 83 79
new 0 83 79
assign 1 84 80
new 0 84 80
assign 1 85 81
new 0 85 81
assign 1 86 82
new 0 86 82
assign 1 87 83
new 0 87 83
assign 1 89 84
new 0 89 84
assign 1 90 85
new 0 90 85
assign 1 91 86
new 0 91 86
assign 1 92 87
new 0 92 87
assign 1 97 97
new 0 97 97
assign 1 98 98
valueIteratorGet 0 98 98
assign 1 98 101
hasNextGet 0 98 101
assign 1 99 103
nextGet 0 99 103
assign 1 100 104
mtdxGet 0 100 104
assign 1 100 105
greater 1 100 110
assign 1 101 111
mtdxGet 0 101 111
return 1 104 118
assign 1 108 126
new 0 108 126
assign 1 108 127
get 1 108 127
assign 1 109 128
def 1 109 133
assign 1 111 134
new 0 111 134
return 1 111 135
assign 1 113 137
new 0 113 137
return 1 113 138
assign 1 117 211
new 0 117 211
assign 1 118 212
new 0 118 212
assign 1 119 213
new 0 119 213
assign 1 120 214
new 0 120 214
assign 1 121 215
new 0 121 215
assign 1 122 216
new 0 122 216
assign 1 123 217
new 0 123 217
assign 1 124 218
new 0 124 218
assign 1 125 219
new 0 125 219
assign 1 126 220
new 0 126 220
assign 1 127 221
new 0 127 221
assign 1 128 222
superListGet 0 128 222
assign 1 128 223
copy 0 128 223
assign 1 129 224
namepathGet 0 129 224
addValue 1 129 225
assign 1 130 226
mtdListGet 0 130 226
assign 1 130 227
copy 0 130 227
assign 1 131 228
ptyListGet 0 131 228
assign 1 131 229
copy 0 131 229
assign 1 134 230
heldGet 0 134 230
assign 1 134 231
orderedVarsGet 0 134 231
assign 1 134 232
iteratorGet 0 134 232
assign 1 134 235
hasNextGet 0 134 235
assign 1 135 237
nextGet 0 135 237
assign 1 136 238
ptyMapGet 0 136 238
assign 1 136 239
heldGet 0 136 239
assign 1 136 240
nameGet 0 136 240
assign 1 136 241
get 1 136 241
assign 1 137 242
heldGet 0 137 242
assign 1 137 243
nameGet 0 137 243
assign 1 137 244
new 0 137 244
assign 1 137 245
notEquals 1 137 245
assign 1 137 247
undef 1 137 252
assign 1 0 253
assign 1 0 256
assign 1 0 260
assign 1 137 263
heldGet 0 137 263
assign 1 137 264
isDeclaredGet 0 137 264
assign 1 137 265
not 0 137 265
assign 1 0 267
assign 1 0 270
assign 1 0 274
assign 1 138 277
new 0 138 277
assign 1 138 278
heldGet 0 138 278
assign 1 138 279
nameGet 0 138 279
assign 1 138 280
add 1 138 280
assign 1 138 281
new 0 138 281
assign 1 138 282
add 1 138 282
assign 1 138 283
heldGet 0 138 283
assign 1 138 284
namepathGet 0 138 284
assign 1 138 285
toString 0 138 285
assign 1 138 286
add 1 138 286
assign 1 138 287
new 2 138 287
throw 1 138 288
assign 1 143 295
ptyListGet 0 143 295
assign 1 143 296
iteratorGet 0 143 296
assign 1 143 299
hasNextGet 0 143 299
assign 1 144 301
nextGet 0 144 301
assign 1 145 302
memSynGet 0 145 302
assign 1 145 303
isTypedGet 0 145 303
assign 1 146 305
heldGet 0 146 305
assign 1 146 306
memSynGet 0 146 306
assign 1 146 307
namepathGet 0 146 307
addUsed 1 146 308
assign 1 150 315
heldGet 0 150 315
assign 1 150 316
orderedMethodsGet 0 150 316
assign 1 150 317
iteratorGet 0 150 317
assign 1 150 320
hasNextGet 0 150 320
assign 1 151 322
nextGet 0 151 322
assign 1 152 323
mtdMapGet 0 152 323
assign 1 152 324
heldGet 0 152 324
assign 1 152 325
nameGet 0 152 325
assign 1 152 326
get 1 152 326
assign 1 153 327
def 1 153 332
assign 1 154 333
rsynGet 0 154 333
assign 1 154 334
def 1 154 339
assign 1 155 340
heldGet 0 155 340
assign 1 155 341
rtypeGet 0 155 341
assign 1 155 342
undef 1 155 347
assign 1 156 348
new 0 156 348
assign 1 156 349
heldGet 0 156 349
assign 1 156 350
nameGet 0 156 350
assign 1 156 351
add 1 156 351
assign 1 156 352
new 0 156 352
assign 1 156 353
add 1 156 353
assign 1 156 354
heldGet 0 156 354
assign 1 156 355
nameGet 0 156 355
assign 1 156 356
add 1 156 356
assign 1 156 357
new 2 156 357
throw 1 156 358
loadClass 1 161 367
assign 1 162 368
depthGet 0 162 368
assign 1 162 369
new 0 162 369
assign 1 162 370
add 1 162 370
assign 1 166 375
has 1 166 375
return 1 166 376
return 1 170 444
assign 1 171 446
new 0 171 446
assign 1 172 447
new 0 172 447
assign 1 173 448
new 0 173 448
assign 1 174 449
new 0 174 449
assign 1 175 450
undef 1 175 455
assign 1 176 456
new 0 176 456
assign 1 177 457
sizeGet 0 177 457
assign 1 178 458
sizeGet 0 178 458
assign 1 179 459
assign 1 180 460
iteratorGet 0 0 460
assign 1 180 463
hasNextGet 0 180 463
assign 1 180 465
nextGet 0 180 465
assign 1 181 466
emitDataGet 0 181 466
assign 1 181 467
methodIndexesGet 0 181 467
assign 1 181 468
new 2 181 468
put 1 181 469
return 1 183 475
assign 1 185 477
getSynNp 1 185 477
assign 1 186 478
new 0 186 478
assign 1 187 479
new 0 187 479
assign 1 189 480
sizeGet 0 189 480
assign 1 189 481
ptyListGet 0 189 481
assign 1 189 482
sizeGet 0 189 482
assign 1 189 483
subtract 1 189 483
assign 1 190 484
libNameGet 0 190 484
assign 1 190 485
equals 1 190 485
integrate 1 190 487
assign 1 191 489
isFinalGet 0 191 489
assign 1 192 491
new 0 192 491
assign 1 192 492
toString 0 192 492
assign 1 192 493
add 1 192 493
assign 1 192 494
new 1 192 494
throw 1 192 495
assign 1 194 497
isLocalGet 0 194 497
assign 1 194 499
libNameGet 0 194 499
assign 1 194 500
notEquals 1 194 500
assign 1 0 502
assign 1 0 505
assign 1 0 509
assign 1 195 512
new 0 195 512
assign 1 195 513
toString 0 195 513
assign 1 195 514
add 1 195 514
assign 1 195 515
new 1 195 515
throw 1 195 516
assign 1 197 518
isLocalGet 0 197 518
assign 1 197 520
not 0 197 525
assign 1 0 526
assign 1 0 529
assign 1 0 533
assign 1 197 536
not 0 197 541
assign 1 0 542
assign 1 0 545
assign 1 0 549
assign 1 198 552
new 0 198 552
assign 1 198 553
toString 0 198 553
assign 1 198 554
add 1 198 554
assign 1 198 555
new 1 198 555
throw 1 198 556
assign 1 200 558
linkedListIteratorGet 0 0 558
assign 1 200 561
hasNextGet 0 200 561
assign 1 200 563
nextGet 0 200 563
assign 1 201 564
getSynNp 1 201 564
assign 1 202 565
closeLibrariesGet 0 202 565
assign 1 202 566
libNameGet 0 202 566
assign 1 202 567
has 1 202 567
assign 1 202 568
not 0 202 573
assign 1 202 574
toString 0 202 574
assign 1 202 575
new 0 202 575
assign 1 202 576
notEquals 1 202 576
assign 1 0 578
assign 1 0 581
assign 1 0 585
assign 1 204 588
new 0 204 588
assign 1 205 589
new 0 205 589
assign 1 207 591
closeLibrariesGet 0 207 591
assign 1 207 592
libNameGet 0 207 592
assign 1 207 593
has 1 207 593
assign 1 207 594
not 0 207 599
assign 1 208 600
new 0 208 600
assign 1 212 607
valueIteratorGet 0 212 607
assign 1 212 610
hasNextGet 0 212 610
assign 1 213 612
nextGet 0 213 612
assign 1 214 613
mtdMapGet 0 214 613
assign 1 214 614
nameGet 0 214 614
assign 1 214 615
get 1 214 615
assign 1 215 616
def 1 215 621
assign 1 216 622
notEquals 1 216 622
assign 1 217 624
new 0 217 624
lastDefSet 1 217 625
assign 1 218 626
new 0 218 626
isOverrideSet 1 218 627
assign 1 219 628
increment 0 219 628
assign 1 222 632
new 0 222 632
isOverrideSet 1 222 633
assign 1 223 634
increment 0 223 634
assign 1 224 635
increment 0 224 635
assign 1 225 636
emitDataGet 0 225 636
assign 1 225 637
methodIndexesGet 0 225 637
assign 1 225 638
new 2 225 638
put 1 225 639
return 1 232 729
assign 1 233 731
new 0 233 731
assign 1 234 732
undef 1 234 737
return 1 234 738
assign 1 235 740
getSynNp 1 235 740
assign 1 236 741
heldGet 0 236 741
assign 1 236 742
orderedVarsGet 0 236 742
assign 1 236 743
iteratorGet 0 236 743
assign 1 236 746
hasNextGet 0 236 746
assign 1 237 748
nextGet 0 237 748
assign 1 238 749
ptyMapGet 0 238 749
assign 1 238 750
heldGet 0 238 750
assign 1 238 751
nameGet 0 238 751
assign 1 238 752
get 1 238 752
assign 1 239 753
def 1 239 758
assign 1 240 759
heldGet 0 240 759
assign 1 240 760
isDeclaredGet 0 240 760
assign 1 241 762
new 0 241 762
assign 1 241 763
heldGet 0 241 763
assign 1 241 764
nameGet 0 241 764
assign 1 241 765
add 1 241 765
assign 1 241 766
new 0 241 766
assign 1 241 767
add 1 241 767
assign 1 241 768
heldGet 0 241 768
assign 1 241 769
namepathGet 0 241 769
assign 1 241 770
toString 0 241 770
assign 1 241 771
add 1 241 771
assign 1 241 772
new 1 241 772
throw 1 241 773
assign 1 243 776
heldGet 0 243 776
assign 1 243 777
memSynGet 0 243 777
assign 1 243 778
isTypedGet 0 243 778
isTypedSet 1 243 779
assign 1 244 780
heldGet 0 244 780
assign 1 244 781
memSynGet 0 244 781
assign 1 244 782
namepathGet 0 244 782
namepathSet 1 244 783
assign 1 248 791
heldGet 0 248 791
assign 1 248 792
orderedMethodsGet 0 248 792
assign 1 248 793
iteratorGet 0 248 793
assign 1 248 796
hasNextGet 0 248 796
assign 1 249 798
nextGet 0 249 798
assign 1 250 799
mtdMapGet 0 250 799
assign 1 250 800
heldGet 0 250 800
assign 1 250 801
nameGet 0 250 801
assign 1 250 802
get 1 250 802
assign 1 251 803
def 1 251 808
assign 1 252 809
isFinalGet 0 252 809
assign 1 253 811
new 0 253 811
assign 1 253 812
heldGet 0 253 812
assign 1 253 813
nameGet 0 253 813
assign 1 253 814
add 1 253 814
assign 1 253 815
new 0 253 815
assign 1 253 816
add 1 253 816
assign 1 253 817
heldGet 0 253 817
assign 1 253 818
namepathGet 0 253 818
assign 1 253 819
toString 0 253 819
assign 1 253 820
add 1 253 820
assign 1 253 821
new 2 253 821
throw 1 253 822
assign 1 255 824
containedGet 0 255 824
assign 1 255 825
firstGet 0 255 825
assign 1 255 826
containedGet 0 255 826
assign 1 256 827
new 0 256 827
assign 1 256 830
argSynsGet 0 256 830
assign 1 256 831
lengthGet 0 256 831
assign 1 256 832
lesser 1 256 832
assign 1 257 834
argSynsGet 0 257 834
assign 1 257 835
get 1 257 835
assign 1 258 836
get 1 258 836
assign 1 258 837
heldGet 0 258 837
checkTypes 5 260 838
assign 1 256 839
increment 0 256 839
assign 1 262 845
rsynGet 0 262 845
assign 1 263 846
heldGet 0 263 846
assign 1 263 847
rtypeGet 0 263 847
assign 1 264 848
undef 1 264 853
assign 1 0 854
assign 1 264 857
undef 1 264 862
assign 1 0 863
assign 1 0 866
assign 1 265 870
undef 1 265 875
assign 1 265 875
not 0 265 880
assign 1 0 881
assign 1 265 884
undef 1 265 889
assign 1 265 889
not 0 265 894
assign 1 0 895
assign 1 0 898
assign 1 266 902
new 0 266 902
assign 1 266 903
heldGet 0 266 903
assign 1 266 904
namepathGet 0 266 904
assign 1 266 905
toString 0 266 905
assign 1 266 906
add 1 266 906
assign 1 266 907
new 2 266 907
throw 1 266 908
checkTypes 5 270 912
assign 1 277 948
isTypedGet 0 277 948
assign 1 277 949
isTypedGet 0 277 949
assign 1 277 950
notEquals 1 277 950
assign 1 278 952
new 0 278 952
assign 1 278 953
heldGet 0 278 953
assign 1 278 954
namepathGet 0 278 954
assign 1 278 955
toString 0 278 955
assign 1 278 956
add 1 278 956
assign 1 278 957
new 2 278 957
throw 1 278 958
assign 1 279 961
isTypedGet 0 279 961
assign 1 282 963
isSelfGet 0 282 963
assign 1 282 965
isSelfGet 0 282 965
assign 1 0 967
assign 1 0 970
assign 1 0 974
return 1 283 977
assign 1 285 979
namepathGet 0 285 979
assign 1 285 980
getSynNp 1 285 980
assign 1 286 981
allTypesGet 0 286 981
assign 1 286 982
namepathGet 0 286 982
assign 1 286 983
has 1 286 983
assign 1 286 984
not 0 286 984
assign 1 287 986
new 0 287 986
assign 1 287 987
heldGet 0 287 987
assign 1 287 988
namepathGet 0 287 988
assign 1 287 989
toString 0 287 989
assign 1 287 990
add 1 287 990
assign 1 287 991
new 2 287 991
throw 1 287 992
new 0 293 1018
assign 1 294 1019
heldGet 0 294 1019
assign 1 294 1020
orderedVarsGet 0 294 1020
assign 1 294 1021
iteratorGet 0 294 1021
assign 1 294 1024
hasNextGet 0 294 1024
assign 1 295 1026
nextGet 0 295 1026
assign 1 296 1027
heldGet 0 296 1027
assign 1 296 1028
isDeclaredGet 0 296 1028
assign 1 296 1029
not 0 296 1029
assign 1 297 1031
new 0 297 1031
assign 1 297 1032
heldGet 0 297 1032
assign 1 297 1033
nameGet 0 297 1033
assign 1 297 1034
add 1 297 1034
assign 1 297 1035
new 0 297 1035
assign 1 297 1036
add 1 297 1036
assign 1 297 1037
heldGet 0 297 1037
assign 1 297 1038
namepathGet 0 297 1038
assign 1 297 1039
toString 0 297 1039
assign 1 297 1040
add 1 297 1040
assign 1 297 1041
new 2 297 1041
throw 1 297 1042
loadClass 1 300 1049
assign 1 301 1050
new 0 301 1050
assign 1 306 1078
heldGet 0 306 1078
assign 1 306 1079
fromFileGet 0 306 1079
assign 1 307 1080
heldGet 0 307 1080
assign 1 307 1081
namepathGet 0 307 1081
assign 1 308 1082
heldGet 0 308 1082
assign 1 308 1083
libNameGet 0 308 1083
assign 1 309 1084
heldGet 0 309 1084
assign 1 309 1085
isFinalGet 0 309 1085
assign 1 310 1086
heldGet 0 310 1086
assign 1 310 1087
isLocalGet 0 310 1087
assign 1 311 1088
heldGet 0 311 1088
assign 1 311 1089
isNotNullGet 0 311 1089
assign 1 312 1090
heldGet 0 312 1090
assign 1 312 1091
usedGet 0 312 1091
assign 1 312 1092
iteratorGet 0 312 1092
assign 1 312 1095
hasNextGet 0 312 1095
assign 1 313 1097
nextGet 0 313 1097
assign 1 314 1098
toString 0 314 1098
put 1 314 1099
assign 1 316 1105
heldGet 0 316 1105
assign 1 316 1106
orderedVarsGet 0 316 1106
assign 1 316 1107
iteratorGet 0 316 1107
assign 1 316 1110
hasNextGet 0 316 1110
assign 1 317 1112
nextGet 0 317 1112
assign 1 318 1113
new 2 318 1113
addValue 1 319 1114
assign 1 321 1120
heldGet 0 321 1120
assign 1 321 1121
orderedMethodsGet 0 321 1121
assign 1 321 1122
iteratorGet 0 321 1122
assign 1 321 1125
hasNextGet 0 321 1125
assign 1 322 1127
nextGet 0 322 1127
assign 1 323 1128
new 2 323 1128
addValue 1 324 1129
postLoad 0 326 1135
assign 1 330 1186
new 0 330 1186
assign 1 331 1187
new 0 331 1187
assign 1 334 1188
iteratorGet 0 334 1188
assign 1 334 1191
hasNextGet 0 334 1191
assign 1 335 1193
nextGet 0 335 1193
assign 1 336 1194
nameGet 0 336 1194
assign 1 336 1195
has 1 336 1195
assign 1 336 1196
not 0 336 1201
assign 1 338 1202
nameGet 0 338 1202
put 2 338 1203
assign 1 342 1210
new 0 342 1210
assign 1 343 1211
new 0 343 1211
assign 1 344 1212
iteratorGet 0 344 1212
assign 1 344 1215
hasNextGet 0 344 1215
assign 1 345 1217
nextGet 0 345 1217
assign 1 346 1218
nameGet 0 346 1218
assign 1 346 1219
has 1 346 1219
assign 1 346 1220
not 0 346 1225
assign 1 347 1226
nameGet 0 347 1226
assign 1 347 1227
get 1 347 1227
mposSet 1 348 1228
assign 1 349 1229
new 0 349 1229
assign 1 349 1230
add 1 349 1230
addValue 1 350 1231
assign 1 351 1232
nameGet 0 351 1232
assign 1 351 1233
nameGet 0 351 1233
put 2 351 1234
assign 1 354 1241
assign 1 356 1242
new 0 356 1242
assign 1 358 1243
iteratorGet 0 358 1243
assign 1 358 1246
hasNextGet 0 358 1246
assign 1 359 1248
nextGet 0 359 1248
assign 1 361 1249
nameGet 0 361 1249
put 2 361 1250
assign 1 363 1251
nameGet 0 363 1251
assign 1 363 1252
has 1 363 1252
assign 1 363 1253
not 0 363 1258
assign 1 364 1259
nameGet 0 364 1259
put 2 364 1260
assign 1 368 1267
new 0 368 1267
assign 1 369 1268
new 0 369 1268
assign 1 370 1269
iteratorGet 0 370 1269
assign 1 370 1272
hasNextGet 0 370 1272
assign 1 371 1274
nextGet 0 371 1274
assign 1 372 1275
nameGet 0 372 1275
assign 1 372 1276
has 1 372 1276
assign 1 372 1277
not 0 372 1282
assign 1 373 1283
nameGet 0 373 1283
assign 1 373 1284
get 1 373 1284
assign 1 382 1285
nameGet 0 382 1285
assign 1 382 1286
get 1 382 1286
assign 1 383 1287
declarationGet 0 383 1287
assign 1 383 1288
undef 1 383 1293
assign 1 384 1294
originGet 0 384 1294
declarationSet 1 384 1295
assign 1 386 1297
declarationGet 0 386 1297
declarationSet 1 386 1298
mtdxSet 1 387 1299
assign 1 388 1300
increment 0 388 1300
addValue 1 389 1301
assign 1 390 1302
nameGet 0 390 1302
assign 1 390 1303
nameGet 0 390 1303
put 2 390 1304
assign 1 393 1311
assign 1 395 1312
linkedListIteratorGet 0 0 1312
assign 1 395 1315
hasNextGet 0 395 1315
assign 1 395 1317
nextGet 0 395 1317
put 2 396 1318
assign 1 397 1319
put 2 400 1325
return 1 0 1329
assign 1 0 1332
return 1 0 1336
assign 1 0 1339
return 1 0 1343
assign 1 0 1346
return 1 0 1350
assign 1 0 1353
return 1 0 1357
assign 1 0 1360
return 1 0 1364
assign 1 0 1367
return 1 0 1371
assign 1 0 1374
return 1 0 1378
assign 1 0 1381
return 1 0 1385
assign 1 0 1388
return 1 0 1392
assign 1 0 1395
return 1 0 1399
assign 1 0 1402
return 1 0 1406
assign 1 0 1409
return 1 0 1413
assign 1 0 1416
return 1 0 1420
assign 1 0 1423
return 1 0 1427
assign 1 0 1430
return 1 0 1434
assign 1 0 1437
return 1 0 1441
assign 1 0 1444
return 1 0 1448
assign 1 0 1451
return 1 0 1455
assign 1 0 1458
return 1 0 1462
assign 1 0 1465
return 1 0 1469
assign 1 0 1472
return 1 0 1476
assign 1 0 1479
return 1 0 1483
assign 1 0 1486
return 1 0 1490
assign 1 0 1493
return 1 0 1497
assign 1 0 1500
return 1 0 1504
assign 1 0 1507
return 1 0 1511
assign 1 0 1514
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -153365600: return bem_ptyMapGet_0();
case 1314364113: return bem_newMbrsGet_0();
case -2097069068: return bem_integratedGet_0();
case -1803479881: return bem_libNameGet_0();
case 287040793: return bem_hashGet_0();
case -1443447938: return bem_directMethodsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2033393684: return bem_ptyListGet_0();
case -842582618: return bem_isLocalGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -311680096: return bem_allNamesGet_0();
case -2058095605: return bem_signatureChangedGet_0();
case 1774940957: return bem_toString_0();
case -786424307: return bem_tagGet_0();
case -492006165: return bem_directPropertiesGet_0();
case 834964524: return bem_defMtdsGet_0();
case 1820417453: return bem_create_0();
case -1974592946: return bem_superListGet_0();
case -1760712968: return bem_signatureCheckedGet_0();
case 1274615854: return bem_allAncestorsCloseGet_0();
case 363636983: return bem_isNotNullGet_0();
case -1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case -1012494862: return bem_once_0();
case -1631955979: return bem_foreignClassesGet_0();
case -1214937871: return bem_newMtdsGet_0();
case 795036897: return bem_fromFileGet_0();
case -845792839: return bem_iteratorGet_0();
case 71634217: return bem_iCheckedGet_0();
case 287367803: return bem_isFinalGet_0();
case 354142775: return bem_namepathGet_0();
case 202810500: return bem_depthGet_0();
case 1477961836: return bem_mtdListGet_0();
case 345555227: return bem_usesGet_0();
case -1308786538: return bem_echo_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 244359240: return bem_mtdMapGet_0();
case 2055025483: return bem_serializeContents_0();
case 443668840: return bem_methodNotDefined_0();
case -986531569: return bem_allTypesGet_0();
case 481879936: return bem_hasDefaultGet_0();
case 1413594071: return bem_postLoad_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case -1354714650: return bem_copy_0();
case 68632810: return bem_superNpGet_0();
case 1495449800: return bem_maxMtdxGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 1118052001: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 82716470: return bem_iCheckedSet_1(bevd_0);
case -1432365685: return bem_directMethodsSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 356637480: return bem_usesSet_1(bevd_0);
case -975449316: return bem_allTypesSet_1(bevd_0);
case -142283347: return bem_ptyMapSet_1(bevd_0);
case 79715063: return bem_superNpSet_1(bevd_0);
case -1749630715: return bem_signatureCheckedSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -2085986815: return bem_integratedSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -2047013352: return bem_signatureChangedSet_1(bevd_0);
case 255441493: return bem_mtdMapSet_1(bevd_0);
case -300597843: return bem_allNamesSet_1(bevd_0);
case 846046777: return bem_defMtdsSet_1(bevd_0);
case -831500365: return bem_isLocalSet_1(bevd_0);
case -480923912: return bem_directPropertiesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1489044089: return bem_mtdListSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1203855618: return bem_newMtdsSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1963510693: return bem_superListSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1285698107: return bem_allAncestorsCloseSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 340843364: return bem_loadClass_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1156342947: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1325446366: return bem_newMbrsSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 213892753: return bem_depthSet_1(bevd_0);
case -1620873726: return bem_foreignClassesSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 2044475937: return bem_ptyListSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1694832085: return bem_checkInheritance_2(bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case -913726521: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildClassSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildClassSyn.bevs_inst = (BEC_2_5_8_BuildClassSyn)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildClassSyn.bevs_inst;
}
}
