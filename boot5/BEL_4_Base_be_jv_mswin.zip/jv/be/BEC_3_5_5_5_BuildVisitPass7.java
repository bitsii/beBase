package be;
/* IO:File: source/build/Pass7.be */
public final class BEC_3_5_5_5_BuildVisitPass7 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_2 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_3 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_4 = {0x74,0x72,0x75,0x65};
private static byte[] bels_5 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_6 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_7 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_8, 41));
private static byte[] bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_10 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_12 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_15 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_17 = {0x6E,0x65,0x77};
public static BEC_3_5_5_5_BuildVisitPass7 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_3_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 41 */
if (bevp_inClassNp == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 43 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 45 */
bevt_16_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpany_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(8, bels_0));
bevp_build.bem_buildLiteral_2(beva_node, bevt_18_tmpany_phold);
} /* Line: 48 */
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_1));
bevp_build.bem_buildLiteral_2(beva_node, bevt_22_tmpany_phold);
} /* Line: 51 */
bevt_24_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpany_phold.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_26_tmpany_phold);
} /* Line: 54 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_3));
bevp_build.bem_buildLiteral_2(beva_node, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpany_phold);
} /* Line: 59 */
bevt_33_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpany_phold.bevi_int == bevt_34_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_4));
beva_node.bem_heldSet_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_5));
bevp_build.bem_buildLiteral_2(beva_node, bevt_36_tmpany_phold);
} /* Line: 63 */
bevt_38_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpany_phold.bevi_int == bevt_39_tmpany_phold.bevi_int) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 69 */ {
bevt_40_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_6));
beva_node.bem_heldSet_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(10, bels_7));
bevp_build.bem_buildLiteral_2(beva_node, bevt_41_tmpany_phold);
} /* Line: 71 */
 else  /* Line: 69 */ {
bevt_43_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpany_phold.bevi_int == bevt_44_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 73 */ {
bevt_50_tmpany_phold = beva_node.bem_heldGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_49_tmpany_phold == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 74 */ {
if (bevl_nnode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_53_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_54_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_54_tmpany_phold);
if (bevt_52_tmpany_phold != null && bevt_52_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpany_phold).bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_57_tmpany_phold = bevo_0;
bevt_59_tmpany_phold = beva_node.bem_heldGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_55_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_55_tmpany_phold);
} /* Line: 75 */
 else  /* Line: 76 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpany_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_62_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpany_phold;
} /* Line: 83 */
} /* Line: 74 */
 else  /* Line: 69 */ {
bevt_64_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 85 */ {
if (bevl_nnode == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_68_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpany_phold);
if (bevt_67_tmpany_phold != null && bevt_67_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpany_phold).bevi_bool) /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 86 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_71_tmpany_phold == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_72_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 89 */ {
bevt_73_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpany_phold != null && bevt_73_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_75_tmpany_phold = bevl_i.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpany_phold);
if (bevt_74_tmpany_phold != null && bevt_74_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 92 */
} /* Line: 91 */
 else  /* Line: 89 */ {
break;
} /* Line: 89 */
} /* Line: 89 */
bevl_ii = bevl_toremove.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 95 */ {
bevt_77_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_77_tmpany_phold != null && bevt_77_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_77_tmpany_phold).bevi_bool) /* Line: 95 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 97 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
} /* Line: 95 */
bevl_pc = bevl_nnode;
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpany_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_79_tmpany_phold);
bevl_pc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_82_tmpany_phold = bevl_dnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_83_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpany_phold);
if (bevt_81_tmpany_phold != null && bevt_81_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_81_tmpany_phold).bevi_bool) /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_onode == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(38, bels_9));
bevt_85_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpany_phold);
} /* Line: 111 */
 else  /* Line: 110 */ {
bevt_88_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpany_phold.bevi_int == bevt_89_tmpany_phold.bevi_int) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_91_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpany_phold);
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_94_tmpany_phold);
} /* Line: 116 */
 else  /* Line: 117 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 118 */
} /* Line: 113 */
 else  /* Line: 110 */ {
bevt_96_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpany_phold.bevi_int == bevt_97_tmpany_phold.bevi_int) {
bevt_95_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_101_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_99_tmpany_phold = bevt_100_tmpany_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_102_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_102_tmpany_phold);
if (bevt_98_tmpany_phold != null && bevt_98_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_98_tmpany_phold).bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_105_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_aliasedGet_0();
bevt_106_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpany_phold = bevt_104_tmpany_phold.bem_has_1(bevt_106_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_109_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpany_phold);
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_111_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_113_tmpany_phold);
} /* Line: 129 */
 else  /* Line: 130 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 131 */
} /* Line: 126 */
 else  /* Line: 110 */ {
bevt_115_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_116_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_10));
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpany_phold);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_118_tmpany_phold = (new BEC_2_4_6_TextString(70, bels_11));
bevt_117_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 134 */
 else  /* Line: 110 */ {
bevt_120_tmpany_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_121_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_12));
bevt_119_tmpany_phold = bevt_120_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpany_phold);
if (bevt_119_tmpany_phold != null && bevt_119_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_119_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_123_tmpany_phold = (new BEC_2_4_6_TextString(65, bels_13));
bevt_122_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_122_tmpany_phold);
} /* Line: 136 */
} /* Line: 110 */
} /* Line: 110 */
} /* Line: 110 */
} /* Line: 110 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(-1007846464, BEL_4_Base.bevn_prepend_1, bevl_onode);
bevl_dnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 141 */
 else  /* Line: 142 */ {
bevt_124_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1308209994, BEL_4_Base.bevn_boundSet_1, bevt_124_tmpany_phold);
bevt_125_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_125_tmpany_phold);
} /* Line: 144 */
} /* Line: 108 */
} /* Line: 86 */
 else  /* Line: 69 */ {
bevt_127_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpany_phold.bevi_int == bevt_128_tmpany_phold.bevi_int) {
bevt_126_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_131_tmpany_phold = (new BEC_2_4_6_TextString(34, bels_14));
bevt_130_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_130_tmpany_phold);
} /* Line: 153 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpany_phold.bevi_int == bevt_134_tmpany_phold.bevi_int) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevt_136_tmpany_phold = (new BEC_2_4_6_TextString(84, bels_15));
bevt_135_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_135_tmpany_phold);
} /* Line: 158 */
bevt_137_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpany_phold);
} /* Line: 160 */
 else  /* Line: 69 */ {
bevt_139_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpany_phold.bevi_int == bevt_140_tmpany_phold.bevi_int) {
bevt_138_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
if (bevl_onode == null) {
bevt_142_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 166 */ {
bevt_144_tmpany_phold = (new BEC_2_4_6_TextString(34, bels_16));
bevt_143_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpany_phold);
} /* Line: 167 */
bevt_146_tmpany_phold = bevl_nnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_147_tmpany_phold);
if (bevt_145_tmpany_phold != null && bevt_145_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_145_tmpany_phold).bevi_bool) /* Line: 169 */ {
bevl_pnode = bevl_nnode.bemd_0(-124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_pnode == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_150_tmpany_phold = bevl_pnode.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_151_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_151_tmpany_phold);
if (bevt_149_tmpany_phold != null && bevt_149_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpany_phold).bevi_bool) /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 171 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpany_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpany_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_ga.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_153_tmpany_phold);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpany_phold.bevi_int == bevt_156_tmpany_phold.bevi_int) {
bevt_154_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpany_phold.bevi_bool) /* Line: 180 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 181 */
 else  /* Line: 180 */ {
bevt_158_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpany_phold.bevi_int == bevt_159_tmpany_phold.bevi_int) {
bevt_157_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_163_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_164_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_164_tmpany_phold);
if (bevt_160_tmpany_phold != null && bevt_160_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_160_tmpany_phold).bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_167_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bem_aliasedGet_0();
bevt_168_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bem_has_1(bevt_168_tmpany_phold);
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 182 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 182 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 182 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpany_phold);
bevl_onode.bem_resolveNp_0();
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 188 */
} /* Line: 180 */
} /* Line: 180 */
} /* Line: 171 */
} /* Line: 169 */
} /* Line: 69 */
} /* Line: 69 */
} /* Line: 69 */
} /* Line: 69 */
bevt_171_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpany_phold;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) throws Throwable {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpany_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_17));
bevl_gnc.bem_nameSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpany_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {36, 39, 39, 39, 39, 40, 40, 41, 41, 41, 43, 43, 44, 45, 47, 47, 47, 47, 48, 48, 50, 50, 50, 50, 51, 51, 53, 53, 53, 53, 54, 54, 56, 56, 56, 56, 58, 58, 59, 59, 61, 61, 61, 61, 62, 62, 63, 63, 69, 69, 69, 69, 70, 70, 71, 71, 73, 73, 73, 73, 73, 73, 73, 0, 0, 0, 74, 74, 74, 74, 74, 74, 0, 74, 74, 74, 0, 0, 0, 0, 0, 75, 75, 75, 75, 75, 75, 77, 77, 77, 78, 79, 83, 83, 85, 85, 85, 85, 86, 86, 86, 86, 86, 0, 0, 0, 87, 87, 87, 88, 89, 89, 89, 90, 91, 91, 91, 92, 95, 95, 96, 97, 100, 101, 101, 102, 103, 103, 104, 105, 106, 107, 108, 108, 108, 108, 108, 0, 0, 0, 109, 110, 110, 111, 111, 111, 112, 112, 112, 112, 113, 113, 114, 114, 115, 115, 116, 116, 118, 120, 120, 120, 120, 120, 120, 120, 120, 120, 0, 120, 120, 120, 120, 0, 0, 0, 0, 0, 121, 122, 122, 123, 124, 124, 125, 126, 126, 127, 127, 128, 128, 129, 129, 131, 133, 133, 133, 134, 134, 134, 135, 135, 135, 136, 136, 136, 139, 140, 141, 143, 143, 144, 144, 148, 148, 148, 148, 151, 152, 152, 153, 153, 153, 155, 156, 157, 157, 157, 157, 158, 158, 158, 160, 160, 161, 161, 161, 161, 163, 166, 166, 0, 166, 166, 0, 0, 167, 167, 167, 169, 169, 169, 170, 171, 171, 0, 171, 171, 171, 0, 0, 172, 173, 173, 174, 175, 175, 176, 177, 178, 179, 180, 180, 180, 180, 181, 182, 182, 182, 182, 182, 182, 182, 182, 182, 0, 182, 182, 182, 182, 0, 0, 0, 0, 0, 183, 184, 184, 185, 186, 186, 187, 188, 193, 193, 197, 198, 199, 199, 200, 200, 201, 203, 204, 204, 205, 205, 206, 206, 207, 207, 208, 208, 209, 210, 210, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {219, 220, 221, 222, 227, 228, 229, 230, 231, 232, 234, 239, 240, 241, 243, 244, 245, 250, 251, 252, 254, 255, 256, 261, 262, 263, 265, 266, 267, 272, 273, 274, 276, 277, 278, 283, 284, 285, 286, 287, 289, 290, 291, 296, 297, 298, 299, 300, 302, 303, 304, 309, 310, 311, 312, 313, 316, 317, 318, 323, 324, 325, 326, 328, 331, 335, 338, 339, 340, 345, 346, 351, 352, 355, 356, 357, 359, 362, 366, 369, 373, 376, 377, 378, 379, 380, 381, 384, 385, 386, 387, 388, 389, 390, 394, 395, 396, 401, 402, 407, 408, 409, 410, 412, 415, 419, 422, 423, 428, 429, 430, 431, 434, 436, 437, 438, 439, 441, 448, 451, 453, 454, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 476, 477, 478, 479, 481, 484, 488, 491, 492, 497, 498, 499, 500, 503, 504, 505, 510, 511, 512, 514, 515, 516, 517, 518, 519, 522, 526, 527, 528, 533, 534, 535, 536, 537, 538, 540, 543, 544, 545, 546, 548, 551, 555, 558, 562, 565, 566, 567, 568, 569, 570, 571, 572, 573, 575, 576, 577, 578, 579, 580, 583, 587, 588, 589, 591, 592, 593, 596, 597, 598, 600, 601, 602, 608, 609, 610, 613, 614, 615, 616, 621, 622, 623, 628, 629, 630, 635, 636, 637, 638, 640, 641, 642, 643, 644, 649, 650, 651, 652, 654, 655, 658, 659, 660, 665, 666, 667, 672, 673, 676, 681, 682, 685, 689, 690, 691, 693, 694, 695, 697, 698, 703, 704, 707, 708, 709, 711, 714, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 735, 736, 739, 740, 741, 746, 747, 748, 749, 750, 751, 753, 756, 757, 758, 759, 761, 764, 768, 771, 775, 778, 779, 780, 781, 782, 783, 784, 785, 795, 796, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 833, 836, 840, 843};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 36 219
nextPeerGet 0 36 219
assign 1 39 220
typenameGet 0 39 220
assign 1 39 221
CLASSGet 0 39 221
assign 1 39 222
equals 1 39 227
assign 1 40 228
heldGet 0 40 228
assign 1 40 229
namepathGet 0 40 229
assign 1 41 230
heldGet 0 41 230
assign 1 41 231
fromFileGet 0 41 231
assign 1 41 232
toString 0 41 232
assign 1 43 234
def 1 43 239
inClassNpSet 1 44 240
inFileSet 1 45 241
assign 1 47 243
typenameGet 0 47 243
assign 1 47 244
INTLGet 0 47 244
assign 1 47 245
equals 1 47 250
assign 1 48 251
new 0 48 251
buildLiteral 2 48 252
assign 1 50 254
typenameGet 0 50 254
assign 1 50 255
FLOATLGet 0 50 255
assign 1 50 256
equals 1 50 261
assign 1 51 262
new 0 51 262
buildLiteral 2 51 263
assign 1 53 265
typenameGet 0 53 265
assign 1 53 266
STRINGLGet 0 53 266
assign 1 53 267
equals 1 53 272
assign 1 54 273
new 0 54 273
buildLiteral 2 54 274
assign 1 56 276
typenameGet 0 56 276
assign 1 56 277
WSTRINGLGet 0 56 277
assign 1 56 278
equals 1 56 283
assign 1 58 284
new 0 58 284
buildLiteral 2 58 285
assign 1 59 286
new 0 59 286
wideStringSet 1 59 287
assign 1 61 289
typenameGet 0 61 289
assign 1 61 290
TRUEGet 0 61 290
assign 1 61 291
equals 1 61 296
assign 1 62 297
new 0 62 297
heldSet 1 62 298
assign 1 63 299
new 0 63 299
buildLiteral 2 63 300
assign 1 69 302
typenameGet 0 69 302
assign 1 69 303
FALSEGet 0 69 303
assign 1 69 304
equals 1 69 309
assign 1 70 310
new 0 70 310
heldSet 1 70 311
assign 1 71 312
new 0 71 312
buildLiteral 2 71 313
assign 1 73 316
typenameGet 0 73 316
assign 1 73 317
VARGet 0 73 317
assign 1 73 318
equals 1 73 323
assign 1 73 324
heldGet 0 73 324
assign 1 73 325
isArgGet 0 73 325
assign 1 73 326
not 0 73 326
assign 1 0 328
assign 1 0 331
assign 1 0 335
assign 1 74 338
heldGet 0 74 338
assign 1 74 339
nameGet 0 74 339
assign 1 74 340
undef 1 74 345
assign 1 74 346
undef 1 74 351
assign 1 0 352
assign 1 74 355
typenameGet 0 74 355
assign 1 74 356
IDGet 0 74 356
assign 1 74 357
notEquals 1 74 357
assign 1 0 359
assign 1 0 362
assign 1 0 366
assign 1 0 369
assign 1 0 373
assign 1 75 376
new 0 75 376
assign 1 75 377
heldGet 0 75 377
assign 1 75 378
nameGet 0 75 378
assign 1 75 379
add 1 75 379
assign 1 75 380
new 2 75 380
throw 1 75 381
assign 1 77 384
heldGet 0 77 384
assign 1 77 385
heldGet 0 77 385
nameSet 1 77 386
addVariable 0 78 387
delete 0 79 388
assign 1 83 389
nextDescendGet 0 83 389
return 1 83 390
assign 1 85 394
typenameGet 0 85 394
assign 1 85 395
IDGet 0 85 395
assign 1 85 396
equals 1 85 401
assign 1 86 402
def 1 86 407
assign 1 86 408
typenameGet 0 86 408
assign 1 86 409
PARENSGet 0 86 409
assign 1 86 410
equals 1 86 410
assign 1 0 412
assign 1 0 415
assign 1 0 419
assign 1 87 422
containedGet 0 87 422
assign 1 87 423
def 1 87 428
assign 1 88 429
new 0 88 429
assign 1 89 430
containedGet 0 89 430
assign 1 89 431
iteratorGet 0 89 431
assign 1 89 434
hasNextGet 0 89 434
assign 1 90 436
nextGet 0 90 436
assign 1 91 437
typenameGet 0 91 437
assign 1 91 438
COMMAGet 0 91 438
assign 1 91 439
equals 1 91 439
addValue 1 92 441
assign 1 95 448
iteratorGet 0 95 448
assign 1 95 451
hasNextGet 0 95 451
assign 1 96 453
nextGet 0 96 453
delete 0 97 454
assign 1 100 461
assign 1 101 462
CALLGet 0 101 462
typenameSet 1 101 463
assign 1 102 464
new 0 102 464
assign 1 103 465
heldGet 0 103 465
nameSet 1 103 466
heldSet 1 104 467
delete 0 105 468
assign 1 106 469
assign 1 107 470
priorPeerGet 0 107 470
assign 1 108 471
def 1 108 476
assign 1 108 477
typenameGet 0 108 477
assign 1 108 478
DOTGet 0 108 478
assign 1 108 479
equals 1 108 479
assign 1 0 481
assign 1 0 484
assign 1 0 488
assign 1 109 491
priorPeerGet 0 109 491
assign 1 110 492
undef 1 110 497
assign 1 111 498
new 0 111 498
assign 1 111 499
new 2 111 499
throw 1 111 500
assign 1 112 503
typenameGet 0 112 503
assign 1 112 504
NAMEPATHGet 0 112 504
assign 1 112 505
equals 1 112 510
assign 1 113 511
nameGet 0 113 511
assign 1 113 512
isNewish 1 113 512
assign 1 114 514
new 0 114 514
wasBoundSet 1 114 515
assign 1 115 516
new 0 115 516
boundSet 1 115 517
assign 1 116 518
new 0 116 518
isConstructSet 1 116 519
createImpliedConstruct 2 118 522
assign 1 120 526
typenameGet 0 120 526
assign 1 120 527
IDGet 0 120 527
assign 1 120 528
equals 1 120 533
assign 1 120 534
transUnitGet 0 120 534
assign 1 120 535
heldGet 0 120 535
assign 1 120 536
aliasedGet 0 120 536
assign 1 120 537
heldGet 0 120 537
assign 1 120 538
has 1 120 538
assign 1 0 540
assign 1 120 543
emitDataGet 0 120 543
assign 1 120 544
aliasedGet 0 120 544
assign 1 120 545
heldGet 0 120 545
assign 1 120 546
has 1 120 546
assign 1 0 548
assign 1 0 551
assign 1 0 555
assign 1 0 558
assign 1 0 562
assign 1 121 565
new 0 121 565
assign 1 122 566
heldGet 0 122 566
addStep 1 122 567
heldSet 1 123 568
assign 1 124 569
NAMEPATHGet 0 124 569
typenameSet 1 124 570
resolveNp 0 125 571
assign 1 126 572
nameGet 0 126 572
assign 1 126 573
isNewish 1 126 573
assign 1 127 575
new 0 127 575
wasBoundSet 1 127 576
assign 1 128 577
new 0 128 577
boundSet 1 128 578
assign 1 129 579
new 0 129 579
isConstructSet 1 129 580
createImpliedConstruct 2 131 583
assign 1 133 587
nameGet 0 133 587
assign 1 133 588
new 0 133 588
assign 1 133 589
equals 1 133 589
assign 1 134 591
new 0 134 591
assign 1 134 592
new 2 134 592
throw 1 134 593
assign 1 135 596
nameGet 0 135 596
assign 1 135 597
new 0 135 597
assign 1 135 598
equals 1 135 598
assign 1 136 600
new 0 136 600
assign 1 136 601
new 2 136 601
throw 1 136 602
delete 0 139 608
prepend 1 140 609
delete 0 141 610
assign 1 143 613
new 0 143 613
boundSet 1 143 614
assign 1 144 615
new 0 144 615
wasBoundSet 1 144 616
assign 1 148 621
typenameGet 0 148 621
assign 1 148 622
IDXGet 0 148 622
assign 1 148 623
equals 1 148 628
assign 1 151 629
priorPeerGet 0 151 629
assign 1 152 630
undef 1 152 635
assign 1 153 636
new 0 153 636
assign 1 153 637
new 2 153 637
throw 1 153 638
delete 0 155 640
prepend 1 156 641
assign 1 157 642
typenameGet 0 157 642
assign 1 157 643
NAMEPATHGet 0 157 643
assign 1 157 644
equals 1 157 649
assign 1 158 650
new 0 158 650
assign 1 158 651
new 2 158 651
throw 1 158 652
assign 1 160 654
IDXACCGet 0 160 654
typenameSet 1 160 655
assign 1 161 658
typenameGet 0 161 658
assign 1 161 659
DOTGet 0 161 659
assign 1 161 660
equals 1 161 665
assign 1 163 666
priorPeerGet 0 163 666
assign 1 166 667
undef 1 166 672
assign 1 0 673
assign 1 166 676
undef 1 166 681
assign 1 0 682
assign 1 0 685
assign 1 167 689
new 0 167 689
assign 1 167 690
new 2 167 690
throw 1 167 691
assign 1 169 693
typenameGet 0 169 693
assign 1 169 694
IDGet 0 169 694
assign 1 169 695
equals 1 169 695
assign 1 170 697
nextPeerGet 0 170 697
assign 1 171 698
undef 1 171 703
assign 1 0 704
assign 1 171 707
typenameGet 0 171 707
assign 1 171 708
PARENSGet 0 171 708
assign 1 171 709
notEquals 1 171 709
assign 1 0 711
assign 1 0 714
assign 1 172 718
priorPeerGet 0 172 718
assign 1 173 719
ACCESSORGet 0 173 719
typenameSet 1 173 720
assign 1 174 721
new 0 174 721
assign 1 175 722
heldGet 0 175 722
nameSet 1 175 723
delete 0 176 724
delete 0 177 725
heldSet 1 178 726
addValue 1 179 727
assign 1 180 728
typenameGet 0 180 728
assign 1 180 729
NAMEPATHGet 0 180 729
assign 1 180 730
equals 1 180 735
createImpliedConstruct 2 181 736
assign 1 182 739
typenameGet 0 182 739
assign 1 182 740
IDGet 0 182 740
assign 1 182 741
equals 1 182 746
assign 1 182 747
transUnitGet 0 182 747
assign 1 182 748
heldGet 0 182 748
assign 1 182 749
aliasedGet 0 182 749
assign 1 182 750
heldGet 0 182 750
assign 1 182 751
has 1 182 751
assign 1 0 753
assign 1 182 756
emitDataGet 0 182 756
assign 1 182 757
aliasedGet 0 182 757
assign 1 182 758
heldGet 0 182 758
assign 1 182 759
has 1 182 759
assign 1 0 761
assign 1 0 764
assign 1 0 768
assign 1 0 771
assign 1 0 775
assign 1 183 778
new 0 183 778
assign 1 184 779
heldGet 0 184 779
addStep 1 184 780
heldSet 1 185 781
assign 1 186 782
NAMEPATHGet 0 186 782
typenameSet 1 186 783
resolveNp 0 187 784
createImpliedConstruct 2 188 785
assign 1 193 795
nextDescendGet 0 193 795
return 1 193 796
assign 1 197 809
new 0 197 809
heldSet 1 198 810
assign 1 199 811
NAMEPATHGet 0 199 811
typenameSet 1 199 812
assign 1 200 813
heldGet 0 200 813
heldSet 1 200 814
prepend 1 201 815
assign 1 203 816
new 0 203 816
assign 1 204 817
new 0 204 817
nameSet 1 204 818
assign 1 205 819
new 0 205 819
wasBoundSet 1 205 820
assign 1 206 821
new 0 206 821
boundSet 1 206 822
assign 1 207 823
new 0 207 823
isConstructSet 1 207 824
assign 1 208 825
new 0 208 825
wasImpliedConstructSet 1 208 826
heldSet 1 209 827
assign 1 210 828
CALLGet 0 210 828
typenameSet 1 210 829
return 1 0 833
assign 1 0 836
return 1 0 840
assign 1 0 843
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 822104518: return bem_inFileGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 856627742: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass7.bevs_inst = (BEC_3_5_5_5_BuildVisitPass7)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bevs_inst;
}
}
