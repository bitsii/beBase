package be;
/* IO:File: source/base/String.be */
public final class BEC_2_4_6_TextString extends BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) {
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) {
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) {
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(String bevi_string) throws Exception {
        byte[] bevi_bytes = bevi_string.getBytes("UTF-8");
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.length);
    }
    public String bems_toJvString() throws Exception {
        String jvString = new String(bevi_bytes, 0, bevp_size.bevi_int, "UTF-8");
        return jvString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_0 = {0x0A};
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_18 = (new BEC_2_4_3_MathInt(43));
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bevo_20 = (new BEC_2_4_3_MathInt(57));
private static BEC_2_4_3_MathInt bevo_21 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_22 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_23 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bevo_24 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_25 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_26 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_27 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_28 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_29 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_30 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_31 = (new BEC_2_4_3_MathInt(91));
private static BEC_2_4_3_MathInt bevo_32 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_33 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_34 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_35 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_36 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_37 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_38 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_39 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_40 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_41 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_42 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_43 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_44 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_45 = (new BEC_2_4_3_MathInt(-1));
private static BEC_2_4_3_MathInt bevo_46 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_47 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_2_4_3_MathInt bevo_48 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_49 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_4_6_TextString bevs_inst;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) throws Throwable {
bevp_size = (new BEC_2_4_3_MathInt(0));
this.bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_capacity == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevp_capacity = (new BEC_2_4_3_MathInt(0));
} /* Line: 187 */
 else  /* Line: 186 */ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 188 */ {
return this;
} /* Line: 189 */
} /* Line: 186 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        this.bevi_bytes = java.util.Arrays.copyOf(this.bevi_bytes, beva_ncap.bevi_int);
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 221 */
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_1;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
this.bem_new_1(bevt_0_tmpany_phold);
bevt_3_tmpany_phold = bevo_2;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_2_tmpany_phold.bevi_int;
bevt_5_tmpany_phold = bevo_3;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
this.bem_setHex_2(bevt_4_tmpany_phold, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_1_tmpany_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt(16));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_toString_3(bevt_3_tmpany_phold, bevt_4_tmpany_phold, bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) throws Throwable {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
if (bevp_leni == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevp_leni = (new BEC_2_4_3_MathInt());
bevp_sizi = (new BEC_2_4_3_MathInt());
} /* Line: 245 */
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 250 */ {
bevt_5_tmpany_phold = bevo_4;
bevt_4_tmpany_phold = bevp_sizi.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevo_5;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_multiply_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevo_6;
bevl_nsize = bevt_3_tmpany_phold.bem_divide_1(bevt_7_tmpany_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 252 */
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_9_tmpany_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_8_tmpany_phold, bevt_9_tmpany_phold, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) throws Throwable {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_7;
if (bevp_size.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_3_tmpany_phold = bevo_8;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bevo_9;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
this.bem_setIntUnchecked_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
bevt_7_tmpany_phold = bevo_10;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_6_tmpany_phold.bevi_int;
} /* Line: 288 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bevo_11;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevp_size.bevi_int = bevt_1_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = bevo_12;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
this.bem_setCodeUnchecked_2(bevt_3_tmpany_phold, (BEC_2_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() throws Throwable {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_6_15_SystemCurrentPlatform bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_1_tmpany_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 300 */ {
bevt_3_tmpany_phold = bevo_13;
bevt_5_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpany_phold = bevp_size.bem_subtract_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold = this.bem_substring_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 301 */
bevl_nl = (new BEC_2_4_6_TextString(1, bels_0));
bevt_6_tmpany_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevt_8_tmpany_phold = bevo_14;
bevt_10_tmpany_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpany_phold = bevp_size.bem_subtract_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = this.bem_substring_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
return bevt_7_tmpany_phold;
} /* Line: 305 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_copy_0() throws Throwable {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_15;
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_c = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_c.bem_addValue_1(this);
return (BEC_2_4_6_TextString) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_3_tmpany_phold = bevo_16;
if (bevl_found.bevi_int != bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 318 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 318 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 318 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 319 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 325 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 325 */
bevt_3_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bevp_size.bem_subtract_1(bevt_3_tmpany_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpany_phold);
if (bevl_found == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 328 */
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_3_tmpany_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 334 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 334 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 335 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
bevl_ic = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 342 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 342 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_4_tmpany_phold = bevo_17;
if (bevl_j.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_6_tmpany_phold = bevo_18;
if (bevl_ic.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_8_tmpany_phold = bevo_19;
if (bevl_ic.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 344 */
 else  /* Line: 344 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 344 */ {
} /* Line: 344 */
 else  /* Line: 344 */ {
bevt_10_tmpany_phold = bevo_20;
if (bevl_ic.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_12_tmpany_phold = bevo_21;
if (bevl_ic.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 346 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 346 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 346 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_13_tmpany_phold;
} /* Line: 347 */
} /* Line: 344 */
bevl_j.bevi_int++;
} /* Line: 342 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 355 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 355 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bevo_22;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_5_tmpany_phold = bevo_23;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 357 */
 else  /* Line: 357 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 357 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_tmpany_phold.bevi_int;
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 359 */
bevl_j.bevi_int++;
} /* Line: 355 */
 else  /* Line: 355 */ {
break;
} /* Line: 355 */
} /* Line: 355 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lowerValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevl_vc = (new BEC_2_4_3_MathInt());
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 370 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 370 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpany_phold = bevo_24;
if (bevl_vc.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_5_tmpany_phold = bevo_25;
if (bevl_vc.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 372 */
 else  /* Line: 372 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 372 */ {
bevt_6_tmpany_phold = (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpany_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 374 */
bevl_j.bevi_int++;
} /* Line: 370 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_upperValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_2_tmpany_phold = this.bem_split_1(beva_from);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_to, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_res = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_nxt = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 393 */ {
if (bevl_nxt == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevl_nxt = this.bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 395 */ {
bevt_2_tmpany_phold = this.bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
bevl_res.bem_addValue_1(beva_to);
bevt_3_tmpany_phold = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_tmpany_phold);
} /* Line: 398 */
 else  /* Line: 400 */ {
bevt_5_tmpany_phold = this.bem_sizeGet_0();
bevt_4_tmpany_phold = this.bem_substring_2(bevl_last, bevt_5_tmpany_phold);
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 401 */
} /* Line: 395 */
 else  /* Line: 393 */ {
break;
} /* Line: 393 */
} /* Line: 393 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(2));
bevl_buf = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 412 */ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 412 */ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 412 */
 else  /* Line: 412 */ {
break;
} /* Line: 412 */
} /* Line: 412 */
bevt_2_tmpany_phold = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_tmpany_phold.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevl_c = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_tmpany_phold.bevi_int;
bevl_j = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 422 */ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 422 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpany_phold);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 422 */
 else  /* Line: 422 */ {
break;
} /* Line: 422 */
} /* Line: 422 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = this.bem_hashValue_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_26;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 446 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 446 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 446 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 446 */
 else  /* Line: 446 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 446 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 466 */
 else  /* Line: 474 */ {
return null;
} /* Line: 475 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_27;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 488 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 488 */
 else  /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 488 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int < 0) {
            beva_into.bevi_int += 256;
         }
         } /* Line: 512 */
 else  /* Line: 517 */ {
return null;
} /* Line: 518 */
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_28;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 524 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 524 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 524 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 524 */
 else  /* Line: 524 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 524 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 525 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_29;
if (beva_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 530 */ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 530 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 530 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 530 */
 else  /* Line: 530 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 530 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 531 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() throws Throwable {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevl_input = this;
bevt_3_tmpany_phold = bevl_input.bem_sizeGet_0();
bevl_insz = bevt_3_tmpany_phold.bem_copy_0();
bevl_output = (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (new BEC_2_4_3_MathInt());
bevl_p = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 541 */ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 541 */ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_tmpany_phold = bevo_30;
if (bevl_c.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_8_tmpany_phold = bevo_31;
if (bevl_c.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
 else  /* Line: 543 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_10_tmpany_phold = bevo_32;
if (bevl_c.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_12_tmpany_phold = bevo_33;
if (bevl_c.bevi_int < bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
 else  /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_14_tmpany_phold = bevo_34;
if (bevl_c.bevi_int > bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_16_tmpany_phold = bevo_35;
if (bevl_c.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
 else  /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 543 */ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 545 */
bevl_i.bevi_int++;
} /* Line: 541 */
 else  /* Line: 541 */ {
break;
} /* Line: 541 */
} /* Line: 541 */
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_36;
if (bevp_size.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 553 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 554 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) throws Throwable {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b > 127) {
        twvls_b -= 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_reverseBytes_0();
bevt_3_tmpany_phold = beva_str.bem_copy_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpany_phold.bem_find_1(bevt_2_tmpany_phold);
if (bevl_rpos == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 647 */ {
bevt_5_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpany_phold;
} /* Line: 649 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_37;
bevt_0_tmpany_phold = this.bem_find_2(beva_str, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
if (beva_str == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
if (beva_start == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_9_tmpany_phold = bevo_38;
if (beva_start.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_12_tmpany_phold = beva_str.bem_sizeGet_0();
if (bevt_12_tmpany_phold.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_14_tmpany_phold = bevo_39;
if (bevp_size.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_16_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpany_phold = bevo_40;
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 661 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 661 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 661 */ {
return null;
} /* Line: 662 */
bevl_end = bevp_size;
bevl_current = beva_start.bem_copy_0();
bevl_myval = (new BEC_2_4_3_MathInt());
bevl_strfirst = (new BEC_2_4_3_MathInt());
bevt_18_tmpany_phold = (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpany_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpany_phold = bevo_41;
if (bevl_strsize.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 673 */ {
bevl_strval = (new BEC_2_4_3_MathInt());
bevl_current2 = (new BEC_2_4_3_MathInt());
bevl_end2 = (new BEC_2_4_3_MathInt());
} /* Line: 676 */
bevl_currentstr2 = (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 679 */ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 679 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 681 */ {
bevt_24_tmpany_phold = bevo_42;
if (bevl_strsize.bevi_int == bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 682 */ {
return bevl_current;
} /* Line: 683 */
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_tmpany_phold.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 689 */ {
return null;
} /* Line: 690 */
bevt_28_tmpany_phold = bevo_43;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
bevl_currentstr2.bevi_int = bevt_27_tmpany_phold.bevi_int;
while (true)
 /* Line: 693 */ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 693 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_30_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 696 */ {
break;
} /* Line: 697 */
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 700 */
 else  /* Line: 693 */ {
break;
} /* Line: 693 */
} /* Line: 693 */
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 702 */ {
return bevl_current;
} /* Line: 703 */
} /* Line: 702 */
bevl_current.bevi_int++;
} /* Line: 706 */
 else  /* Line: 679 */ {
break;
} /* Line: 679 */
} /* Line: 679 */
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 716 */ {
if (bevl_i == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 716 */ {
bevt_1_tmpany_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpany_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 719 */
 else  /* Line: 716 */ {
break;
} /* Line: 716 */
} /* Line: 716 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 721 */ {
bevt_3_tmpany_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 722 */
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_9_TextTokenizer bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lineSplitterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_stri == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 744 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 744 */ {
bevt_2_tmpany_phold = beva_stri.bemd_1(-1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 744 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 744 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 744 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 744 */ {
return null;
} /* Line: 745 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 749 */ {
bevl_maxsize = bevl_osize;
} /* Line: 750 */
 else  /* Line: 751 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 752 */
bevl_myret = (new BEC_2_4_3_MathInt());
bevl_mv = (new BEC_2_4_3_MathInt());
bevl_ov = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 757 */ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 757 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 760 */ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 761 */ {
bevt_7_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_7_tmpany_phold;
} /* Line: 762 */
 else  /* Line: 763 */ {
bevt_8_tmpany_phold = (new BEC_2_4_3_MathInt(-1));
return bevt_8_tmpany_phold;
} /* Line: 764 */
} /* Line: 761 */
bevl_i.bevi_int++;
} /* Line: 757 */
 else  /* Line: 757 */ {
break;
} /* Line: 757 */
} /* Line: 757 */
bevt_10_tmpany_phold = bevo_44;
if (bevl_myret.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 768 */ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 769 */ {
bevl_myret = (new BEC_2_4_3_MathInt(1));
} /* Line: 770 */
 else  /* Line: 769 */ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 771 */ {
bevl_myret = (new BEC_2_4_3_MathInt(-1));
} /* Line: 772 */
} /* Line: 769 */
} /* Line: 769 */
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 779 */ {
return null;
} /* Line: 779 */
bevt_2_tmpany_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bevo_45;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 780 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 781 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_stri == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 787 */ {
return null;
} /* Line: 787 */
bevt_2_tmpany_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpany_phold = bevo_46;
if (bevt_2_tmpany_phold.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 788 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 789 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

  //if (beva_stri instanceof BEC_2_4_6_TextString) {
    BEC_2_4_6_TextString bevls_stri = (BEC_2_4_6_TextString) beva_stri;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  //}
  bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_equals_1(beva_str);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) throws Throwable {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpany_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpany_phold = bevp_size.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpany_phold, bevp_size, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpany_phold, bevt_5_tmpany_phold, bevp_size);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_create_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) throws Throwable {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_47;
if (beva_starti.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 880 */ {
bevt_4_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 880 */ {
bevt_6_tmpany_phold = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 880 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 880 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 880 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 880 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(31, bels_1));
bevt_7_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 881 */
 else  /* Line: 882 */ {
if (bevp_leni == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 885 */ {
bevp_leni = (new BEC_2_4_3_MathInt());
bevp_sizi = (new BEC_2_4_3_MathInt());
} /* Line: 887 */
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 896 */ {
this.bem_capacitySet_1(bevp_sizi);
} /* Line: 897 */

         //source, sourceStart, dest, destStart, length
         System.arraycopy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 952 */ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 956 */
return this;
} /* Line: 958 */
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_sizeGet_0();
bevt_0_tmpany_phold = this.bem_substring_2(beva_starti, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevi_bytes.length - 1);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_print_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevp_size.bevi_int);
System.out.write('\n');
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_echo_0() throws Throwable {
this.bem_output_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() throws Throwable {
BEC_2_4_12_TextByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() throws Throwable {
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_snw == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1084 */ {
this.bem_new_0();
} /* Line: 1085 */
 else  /* Line: 1086 */ {
bevt_2_tmpany_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpany_phold = bevo_48;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
this.bem_new_1(bevt_1_tmpany_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1088 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_strip_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() throws Throwable {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevl_vb = (new BEC_2_4_3_MathInt());
bevl_ve = (new BEC_2_4_3_MathInt());
bevl_b = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = bevo_49;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpany_phold);
while (true)
 /* Line: 1105 */ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1105 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1111 */
 else  /* Line: 1105 */ {
break;
} /* Line: 1105 */
} /* Line: 1105 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() throws Throwable {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() throws Throwable {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {168, 169, 182, 182, 182, 186, 186, 187, 188, 188, 189, 220, 220, 221, 223, 227, 227, 227, 228, 228, 228, 229, 229, 229, 233, 233, 233, 233, 233, 233, 233, 237, 238, 242, 243, 243, 244, 245, 247, 247, 248, 250, 250, 251, 251, 251, 251, 251, 251, 252, 254, 254, 254, 258, 262, 266, 270, 280, 281, 282, 286, 286, 286, 287, 287, 287, 287, 287, 288, 288, 288, 293, 293, 294, 294, 294, 295, 295, 295, 299, 299, 300, 301, 301, 301, 301, 301, 303, 304, 305, 305, 305, 305, 305, 307, 311, 311, 311, 312, 313, 317, 318, 318, 0, 318, 318, 318, 0, 0, 319, 319, 321, 321, 325, 325, 325, 325, 326, 326, 326, 327, 327, 328, 328, 330, 330, 334, 334, 0, 334, 334, 334, 0, 0, 335, 335, 337, 337, 341, 342, 342, 342, 343, 344, 344, 344, 344, 344, 344, 0, 344, 344, 344, 0, 0, 0, 0, 0, 346, 346, 346, 0, 346, 346, 346, 0, 0, 347, 347, 342, 350, 350, 354, 355, 355, 355, 356, 357, 357, 357, 357, 357, 357, 0, 0, 0, 358, 358, 359, 355, 365, 365, 365, 369, 370, 370, 370, 371, 372, 372, 372, 372, 372, 372, 0, 0, 0, 373, 373, 374, 370, 380, 380, 380, 384, 384, 384, 384, 390, 391, 392, 393, 393, 394, 395, 395, 396, 396, 397, 398, 398, 401, 401, 401, 405, 410, 410, 411, 412, 412, 412, 413, 412, 415, 415, 416, 420, 421, 421, 422, 422, 422, 423, 424, 424, 425, 422, 428, 432, 432, 432, 436, 436, 436, 446, 446, 446, 446, 446, 0, 0, 0, 475, 477, 488, 488, 488, 488, 488, 0, 0, 0, 518, 520, 524, 524, 524, 524, 524, 0, 0, 0, 525, 530, 530, 530, 530, 530, 0, 0, 0, 531, 536, 537, 537, 538, 539, 540, 541, 541, 541, 542, 543, 543, 543, 543, 543, 543, 0, 0, 0, 0, 543, 543, 543, 543, 543, 543, 0, 0, 0, 0, 0, 0, 543, 543, 543, 543, 543, 543, 0, 0, 0, 0, 0, 544, 545, 541, 548, 549, 553, 553, 553, 554, 554, 556, 556, 639, 639, 645, 645, 645, 645, 645, 647, 647, 648, 648, 649, 649, 651, 655, 655, 655, 661, 661, 0, 661, 661, 0, 0, 0, 661, 661, 661, 0, 0, 0, 661, 661, 0, 0, 0, 661, 661, 661, 0, 0, 0, 661, 661, 661, 0, 0, 0, 661, 661, 661, 661, 0, 0, 662, 665, 666, 667, 668, 669, 669, 671, 673, 673, 673, 674, 675, 676, 678, 679, 679, 680, 681, 681, 682, 682, 682, 683, 685, 686, 687, 688, 688, 689, 689, 690, 692, 692, 692, 693, 693, 694, 695, 696, 696, 699, 700, 702, 702, 703, 706, 708, 712, 713, 714, 715, 716, 716, 717, 717, 718, 719, 721, 721, 722, 722, 724, 728, 728, 728, 732, 732, 732, 732, 736, 744, 744, 0, 744, 0, 0, 745, 747, 748, 749, 749, 750, 752, 754, 755, 756, 757, 757, 757, 758, 759, 760, 760, 761, 761, 762, 762, 764, 764, 757, 768, 768, 768, 769, 769, 770, 771, 771, 772, 775, 779, 779, 779, 780, 780, 780, 780, 781, 781, 783, 783, 787, 787, 787, 788, 788, 788, 788, 789, 789, 791, 791, 840, 840, 844, 844, 844, 848, 849, 849, 849, 850, 850, 850, 851, 851, 851, 852, 855, 855, 880, 880, 880, 0, 880, 880, 880, 0, 880, 880, 880, 0, 0, 0, 0, 881, 881, 881, 885, 885, 886, 887, 889, 890, 891, 893, 894, 896, 896, 897, 952, 952, 956, 958, 963, 963, 963, 967, 967, 967, 967, 967, 1052, 1056, 1056, 1060, 1060, 1064, 1064, 1068, 1068, 1072, 1072, 1076, 1076, 1080, 1084, 1084, 1085, 1087, 1087, 1087, 1087, 1088, 1093, 1093, 1097, 1097, 1097, 1101, 1102, 1103, 1104, 1104, 1105, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {103, 104, 110, 111, 112, 119, 124, 125, 128, 133, 134, 143, 148, 149, 151, 161, 162, 163, 164, 165, 166, 167, 168, 169, 179, 180, 181, 182, 183, 184, 185, 189, 190, 206, 207, 212, 213, 214, 216, 217, 218, 219, 224, 225, 226, 227, 228, 229, 230, 231, 233, 234, 235, 239, 242, 245, 249, 260, 261, 262, 273, 274, 279, 280, 281, 282, 283, 284, 285, 286, 287, 297, 298, 299, 300, 301, 302, 303, 304, 320, 321, 322, 324, 325, 326, 327, 328, 330, 331, 333, 334, 335, 336, 337, 339, 345, 346, 347, 348, 349, 359, 360, 365, 366, 369, 370, 375, 376, 379, 383, 384, 386, 387, 398, 403, 404, 405, 407, 408, 409, 410, 415, 416, 417, 419, 420, 429, 434, 435, 438, 439, 444, 445, 448, 452, 453, 455, 456, 476, 477, 480, 485, 486, 487, 488, 493, 494, 495, 500, 501, 504, 505, 510, 511, 514, 518, 521, 525, 530, 531, 536, 537, 540, 541, 546, 547, 550, 554, 555, 558, 564, 565, 577, 578, 581, 586, 587, 588, 589, 594, 595, 596, 601, 602, 605, 609, 612, 613, 614, 616, 627, 628, 629, 641, 642, 645, 650, 651, 652, 653, 658, 659, 660, 665, 666, 669, 673, 676, 677, 678, 680, 691, 692, 693, 699, 700, 701, 702, 714, 715, 716, 719, 724, 725, 726, 731, 732, 733, 734, 735, 736, 739, 740, 741, 748, 758, 759, 760, 761, 764, 769, 770, 771, 777, 778, 779, 787, 788, 789, 790, 793, 798, 799, 800, 801, 802, 803, 809, 814, 815, 816, 821, 822, 823, 830, 831, 836, 837, 842, 843, 846, 850, 857, 859, 866, 867, 872, 873, 878, 879, 882, 886, 896, 898, 905, 906, 911, 912, 917, 918, 921, 925, 928, 937, 938, 943, 944, 949, 950, 953, 957, 960, 988, 989, 990, 991, 992, 993, 994, 997, 1002, 1003, 1004, 1005, 1010, 1011, 1012, 1017, 1018, 1021, 1025, 1028, 1031, 1032, 1037, 1038, 1039, 1044, 1045, 1048, 1052, 1055, 1058, 1062, 1065, 1066, 1071, 1072, 1073, 1078, 1079, 1082, 1086, 1089, 1092, 1096, 1097, 1099, 1105, 1106, 1113, 1114, 1119, 1120, 1121, 1123, 1124, 1142, 1143, 1154, 1155, 1156, 1157, 1158, 1159, 1164, 1165, 1166, 1167, 1168, 1170, 1175, 1176, 1177, 1221, 1226, 1227, 1230, 1235, 1236, 1239, 1243, 1246, 1247, 1252, 1253, 1256, 1260, 1263, 1268, 1269, 1272, 1276, 1279, 1280, 1285, 1286, 1289, 1293, 1296, 1297, 1302, 1303, 1306, 1310, 1313, 1314, 1315, 1320, 1321, 1324, 1328, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1343, 1344, 1345, 1346, 1348, 1351, 1356, 1357, 1358, 1363, 1364, 1365, 1370, 1371, 1373, 1374, 1375, 1376, 1377, 1378, 1383, 1384, 1386, 1387, 1388, 1391, 1396, 1397, 1398, 1399, 1404, 1407, 1408, 1414, 1419, 1420, 1423, 1429, 1440, 1441, 1442, 1443, 1446, 1451, 1452, 1453, 1454, 1455, 1461, 1466, 1467, 1468, 1470, 1475, 1476, 1477, 1483, 1484, 1485, 1486, 1489, 1512, 1517, 1518, 1521, 1523, 1526, 1530, 1532, 1533, 1534, 1539, 1540, 1543, 1545, 1546, 1547, 1548, 1551, 1556, 1557, 1558, 1559, 1564, 1565, 1570, 1571, 1572, 1575, 1576, 1579, 1585, 1586, 1591, 1592, 1597, 1598, 1601, 1606, 1607, 1611, 1620, 1625, 1626, 1628, 1629, 1630, 1635, 1636, 1637, 1639, 1640, 1649, 1654, 1655, 1657, 1658, 1659, 1664, 1665, 1666, 1668, 1669, 1685, 1686, 1691, 1692, 1697, 1708, 1709, 1710, 1711, 1712, 1713, 1714, 1715, 1716, 1717, 1718, 1722, 1723, 1740, 1741, 1746, 1747, 1750, 1751, 1756, 1757, 1760, 1761, 1766, 1767, 1770, 1774, 1777, 1781, 1782, 1783, 1786, 1791, 1792, 1793, 1795, 1796, 1797, 1798, 1799, 1800, 1805, 1806, 1811, 1816, 1817, 1819, 1825, 1826, 1827, 1834, 1835, 1836, 1837, 1838, 1852, 1857, 1858, 1862, 1863, 1867, 1868, 1872, 1873, 1877, 1878, 1882, 1883, 1886, 1893, 1898, 1899, 1902, 1903, 1904, 1905, 1906, 1912, 1913, 1918, 1919, 1920, 1929, 1930, 1931, 1932, 1933, 1936, 1941, 1942, 1943, 1944, 1945, 1946, 1947, 1956, 1959, 1963, 1966, 1969, 1973, 1976};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 168 103
new 0 168 103
capacitySet 1 169 104
assign 1 182 110
new 0 182 110
assign 1 182 111
once 0 182 111
new 1 182 112
assign 1 186 119
undef 1 186 124
assign 1 187 125
new 0 187 125
assign 1 188 128
equals 1 188 133
return 1 189 134
assign 1 220 143
greater 1 220 148
setValue 1 221 149
setValue 1 223 151
assign 1 227 161
new 0 227 161
assign 1 227 162
once 0 227 162
new 1 227 163
assign 1 228 164
new 0 228 164
assign 1 228 165
once 0 228 165
setValue 1 228 166
assign 1 229 167
new 0 229 167
assign 1 229 168
once 0 229 168
setHex 2 229 169
assign 1 233 179
new 0 233 179
assign 1 233 180
getCode 2 233 180
assign 1 233 181
new 0 233 181
assign 1 233 182
new 0 233 182
assign 1 233 183
new 0 233 183
assign 1 233 184
toString 3 233 184
return 1 233 185
assign 1 237 189
hexNew 1 237 189
setCode 2 238 190
assign 1 242 206
toString 0 242 206
assign 1 243 207
undef 1 243 212
assign 1 244 213
new 0 244 213
assign 1 245 214
new 0 245 214
assign 1 247 216
sizeGet 0 247 216
setValue 1 247 217
addValue 1 248 218
assign 1 250 219
lesser 1 250 224
assign 1 251 225
new 0 251 225
assign 1 251 226
add 1 251 226
assign 1 251 227
new 0 251 227
assign 1 251 228
multiply 1 251 228
assign 1 251 229
new 0 251 229
assign 1 251 230
divide 1 251 230
capacitySet 1 252 231
assign 1 254 233
new 0 254 233
assign 1 254 234
sizeGet 0 254 234
copyValue 4 254 235
return 1 258 239
return 1 262 242
addValue 1 266 245
write 1 270 249
assign 1 280 260
copy 0 280 260
clear 0 281 261
return 1 282 262
assign 1 286 273
new 0 286 273
assign 1 286 274
greater 1 286 279
assign 1 287 280
new 0 287 280
assign 1 287 281
once 0 287 281
assign 1 287 282
new 0 287 282
assign 1 287 283
once 0 287 283
setIntUnchecked 2 287 284
assign 1 288 285
new 0 288 285
assign 1 288 286
once 0 288 286
setValue 1 288 287
assign 1 293 297
new 0 293 297
new 1 293 298
assign 1 294 299
new 0 294 299
assign 1 294 300
once 0 294 300
setValue 1 294 301
assign 1 295 302
new 0 295 302
assign 1 295 303
once 0 295 303
setCodeUnchecked 2 295 304
assign 1 299 320
new 0 299 320
assign 1 299 321
newlineGet 0 299 321
assign 1 300 322
ends 1 300 322
assign 1 301 324
new 0 301 324
assign 1 301 325
sizeGet 0 301 325
assign 1 301 326
subtract 1 301 326
assign 1 301 327
substring 2 301 327
return 1 301 328
assign 1 303 330
new 0 303 330
assign 1 304 331
ends 1 304 331
assign 1 305 333
new 0 305 333
assign 1 305 334
sizeGet 0 305 334
assign 1 305 335
subtract 1 305 335
assign 1 305 336
substring 2 305 336
return 1 305 337
return 1 307 339
assign 1 311 345
new 0 311 345
assign 1 311 346
add 1 311 346
assign 1 311 347
new 1 311 347
addValue 1 312 348
return 1 313 349
assign 1 317 359
find 1 317 359
assign 1 318 360
undef 1 318 365
assign 1 0 366
assign 1 318 369
new 0 318 369
assign 1 318 370
notEquals 1 318 375
assign 1 0 376
assign 1 0 379
assign 1 319 383
new 0 319 383
return 1 319 384
assign 1 321 386
new 0 321 386
return 1 321 387
assign 1 325 398
undef 1 325 403
assign 1 325 404
new 0 325 404
return 1 325 405
assign 1 326 407
sizeGet 0 326 407
assign 1 326 408
subtract 1 326 408
assign 1 326 409
find 2 326 409
assign 1 327 410
undef 1 327 415
assign 1 328 416
new 0 328 416
return 1 328 417
assign 1 330 419
new 0 330 419
return 1 330 420
assign 1 334 429
undef 1 334 434
assign 1 0 435
assign 1 334 438
find 1 334 438
assign 1 334 439
undef 1 334 444
assign 1 0 445
assign 1 0 448
assign 1 335 452
new 0 335 452
return 1 335 453
assign 1 337 455
new 0 337 455
return 1 337 456
assign 1 341 476
new 0 341 476
assign 1 342 477
new 0 342 477
assign 1 342 480
lesser 1 342 485
getInt 2 343 486
assign 1 344 487
new 0 344 487
assign 1 344 488
equals 1 344 493
assign 1 344 494
new 0 344 494
assign 1 344 495
equals 1 344 500
assign 1 0 501
assign 1 344 504
new 0 344 504
assign 1 344 505
equals 1 344 510
assign 1 0 511
assign 1 0 514
assign 1 0 518
assign 1 0 521
assign 1 0 525
assign 1 346 530
new 0 346 530
assign 1 346 531
greater 1 346 536
assign 1 0 537
assign 1 346 540
new 0 346 540
assign 1 346 541
lesser 1 346 546
assign 1 0 547
assign 1 0 550
assign 1 347 554
new 0 347 554
return 1 347 555
incrementValue 0 342 558
assign 1 350 564
new 0 350 564
return 1 350 565
assign 1 354 577
new 0 354 577
assign 1 355 578
new 0 355 578
assign 1 355 581
lesser 1 355 586
getInt 2 356 587
assign 1 357 588
new 0 357 588
assign 1 357 589
greater 1 357 594
assign 1 357 595
new 0 357 595
assign 1 357 596
lesser 1 357 601
assign 1 0 602
assign 1 0 605
assign 1 0 609
assign 1 358 612
new 0 358 612
addValue 1 358 613
setIntUnchecked 2 359 614
incrementValue 0 355 616
assign 1 365 627
copy 0 365 627
assign 1 365 628
lowerValue 0 365 628
return 1 365 629
assign 1 369 641
new 0 369 641
assign 1 370 642
new 0 370 642
assign 1 370 645
lesser 1 370 650
getInt 2 371 651
assign 1 372 652
new 0 372 652
assign 1 372 653
greater 1 372 658
assign 1 372 659
new 0 372 659
assign 1 372 660
lesser 1 372 665
assign 1 0 666
assign 1 0 669
assign 1 0 673
assign 1 373 676
new 0 373 676
subtractValue 1 373 677
setIntUnchecked 2 374 678
incrementValue 0 370 680
assign 1 380 691
copy 0 380 691
assign 1 380 692
upperValue 0 380 692
return 1 380 693
assign 1 384 699
new 0 384 699
assign 1 384 700
split 1 384 700
assign 1 384 701
join 2 384 701
return 1 384 702
assign 1 390 714
new 0 390 714
assign 1 391 715
new 0 391 715
assign 1 392 716
new 0 392 716
assign 1 393 719
def 1 393 724
assign 1 394 725
find 2 394 725
assign 1 395 726
def 1 395 731
assign 1 396 732
substring 2 396 732
addValue 1 396 733
addValue 1 397 734
assign 1 398 735
sizeGet 0 398 735
assign 1 398 736
add 1 398 736
assign 1 401 739
sizeGet 0 401 739
assign 1 401 740
substring 2 401 740
addValue 1 401 741
return 1 405 748
assign 1 410 758
new 0 410 758
assign 1 410 759
new 1 410 759
assign 1 411 760
mbiterGet 0 411 760
assign 1 412 761
new 0 412 761
assign 1 412 764
lesser 1 412 769
next 1 413 770
incrementValue 0 412 771
assign 1 415 777
next 1 415 777
assign 1 415 778
toString 0 415 778
return 1 416 779
assign 1 420 787
new 0 420 787
assign 1 421 788
new 0 421 788
setValue 1 421 789
assign 1 422 790
new 0 422 790
assign 1 422 793
lesser 1 422 798
getInt 2 423 799
assign 1 424 800
new 0 424 800
multiplyValue 1 424 801
addValue 1 425 802
incrementValue 0 422 803
return 1 428 809
assign 1 432 814
new 0 432 814
assign 1 432 815
hashValue 1 432 815
return 1 432 816
assign 1 436 821
new 0 436 821
assign 1 436 822
getCode 2 436 822
return 1 436 823
assign 1 446 830
new 0 446 830
assign 1 446 831
greaterEquals 1 446 836
assign 1 446 837
greater 1 446 842
assign 1 0 843
assign 1 0 846
assign 1 0 850
return 1 475 857
return 1 477 859
assign 1 488 866
new 0 488 866
assign 1 488 867
greaterEquals 1 488 872
assign 1 488 873
greater 1 488 878
assign 1 0 879
assign 1 0 882
assign 1 0 886
return 1 518 896
return 1 520 898
assign 1 524 905
new 0 524 905
assign 1 524 906
greaterEquals 1 524 911
assign 1 524 912
greater 1 524 917
assign 1 0 918
assign 1 0 921
assign 1 0 925
setIntUnchecked 2 525 928
assign 1 530 937
new 0 530 937
assign 1 530 938
greaterEquals 1 530 943
assign 1 530 944
greater 1 530 949
assign 1 0 950
assign 1 0 953
assign 1 0 957
setCodeUnchecked 2 531 960
assign 1 536 988
assign 1 537 989
sizeGet 0 537 989
assign 1 537 990
copy 0 537 990
assign 1 538 991
new 1 538 991
assign 1 539 992
new 0 539 992
assign 1 540 993
new 0 540 993
assign 1 541 994
new 0 541 994
assign 1 541 997
lesser 1 541 1002
getInt 2 542 1003
assign 1 543 1004
new 0 543 1004
assign 1 543 1005
greater 1 543 1010
assign 1 543 1011
new 0 543 1011
assign 1 543 1012
lesser 1 543 1017
assign 1 0 1018
assign 1 0 1021
assign 1 0 1025
assign 1 0 1028
assign 1 543 1031
new 0 543 1031
assign 1 543 1032
greater 1 543 1037
assign 1 543 1038
new 0 543 1038
assign 1 543 1039
lesser 1 543 1044
assign 1 0 1045
assign 1 0 1048
assign 1 0 1052
assign 1 0 1055
assign 1 0 1058
assign 1 0 1062
assign 1 543 1065
new 0 543 1065
assign 1 543 1066
greater 1 543 1071
assign 1 543 1072
new 0 543 1072
assign 1 543 1073
lesser 1 543 1078
assign 1 0 1079
assign 1 0 1082
assign 1 0 1086
assign 1 0 1089
assign 1 0 1092
setIntUnchecked 2 544 1096
incrementValue 0 545 1097
incrementValue 0 541 1099
sizeSet 1 548 1105
return 1 549 1106
assign 1 553 1113
new 0 553 1113
assign 1 553 1114
lesserEquals 1 553 1119
assign 1 554 1120
new 0 554 1120
return 1 554 1121
assign 1 556 1123
new 0 556 1123
return 1 556 1124
assign 1 639 1142
rfind 1 639 1142
return 1 639 1143
assign 1 645 1154
copy 0 645 1154
assign 1 645 1155
reverseBytes 0 645 1155
assign 1 645 1156
copy 0 645 1156
assign 1 645 1157
reverseBytes 0 645 1157
assign 1 645 1158
find 1 645 1158
assign 1 647 1159
def 1 647 1164
assign 1 648 1165
sizeGet 0 648 1165
addValue 1 648 1166
assign 1 649 1167
subtract 1 649 1167
return 1 649 1168
return 1 651 1170
assign 1 655 1175
new 0 655 1175
assign 1 655 1176
find 2 655 1176
return 1 655 1177
assign 1 661 1221
undef 1 661 1226
assign 1 0 1227
assign 1 661 1230
undef 1 661 1235
assign 1 0 1236
assign 1 0 1239
assign 1 0 1243
assign 1 661 1246
new 0 661 1246
assign 1 661 1247
lesser 1 661 1252
assign 1 0 1253
assign 1 0 1256
assign 1 0 1260
assign 1 661 1263
greaterEquals 1 661 1268
assign 1 0 1269
assign 1 0 1272
assign 1 0 1276
assign 1 661 1279
sizeGet 0 661 1279
assign 1 661 1280
greater 1 661 1285
assign 1 0 1286
assign 1 0 1289
assign 1 0 1293
assign 1 661 1296
new 0 661 1296
assign 1 661 1297
equals 1 661 1302
assign 1 0 1303
assign 1 0 1306
assign 1 0 1310
assign 1 661 1313
sizeGet 0 661 1313
assign 1 661 1314
new 0 661 1314
assign 1 661 1315
equals 1 661 1320
assign 1 0 1321
assign 1 0 1324
return 1 662 1328
assign 1 665 1330
assign 1 666 1331
copy 0 666 1331
assign 1 667 1332
new 0 667 1332
assign 1 668 1333
new 0 668 1333
assign 1 669 1334
new 0 669 1334
getInt 2 669 1335
assign 1 671 1336
sizeGet 0 671 1336
assign 1 673 1337
new 0 673 1337
assign 1 673 1338
greater 1 673 1343
assign 1 674 1344
new 0 674 1344
assign 1 675 1345
new 0 675 1345
assign 1 676 1346
new 0 676 1346
assign 1 678 1348
new 0 678 1348
assign 1 679 1351
lesser 1 679 1356
getInt 2 680 1357
assign 1 681 1358
equals 1 681 1363
assign 1 682 1364
new 0 682 1364
assign 1 682 1365
equals 1 682 1370
return 1 683 1371
setValue 1 685 1373
incrementValue 0 686 1374
setValue 1 687 1375
assign 1 688 1376
sizeGet 0 688 1376
addValue 1 688 1377
assign 1 689 1378
greater 1 689 1383
return 1 690 1384
assign 1 692 1386
new 0 692 1386
assign 1 692 1387
once 0 692 1387
setValue 1 692 1388
assign 1 693 1391
lesser 1 693 1396
getInt 2 694 1397
getInt 2 695 1398
assign 1 696 1399
notEquals 1 696 1404
incrementValue 0 699 1407
incrementValue 0 700 1408
assign 1 702 1414
equals 1 702 1419
return 1 703 1420
incrementValue 0 706 1423
return 1 708 1429
assign 1 712 1440
new 0 712 1440
assign 1 713 1441
new 0 713 1441
assign 1 714 1442
find 2 714 1442
assign 1 715 1443
sizeGet 0 715 1443
assign 1 716 1446
def 1 716 1451
assign 1 717 1452
substring 2 717 1452
addValue 1 717 1453
assign 1 718 1454
add 1 718 1454
assign 1 719 1455
find 2 719 1455
assign 1 721 1461
lesser 1 721 1466
assign 1 722 1467
substring 2 722 1467
addValue 1 722 1468
return 1 724 1470
assign 1 728 1475
new 0 728 1475
assign 1 728 1476
join 2 728 1476
return 1 728 1477
assign 1 732 1483
new 0 732 1483
assign 1 732 1484
lineSplitterGet 0 732 1484
assign 1 732 1485
tokenize 1 732 1485
return 1 732 1486
return 1 736 1489
assign 1 744 1512
undef 1 744 1517
assign 1 0 1518
assign 1 744 1521
otherType 1 744 1521
assign 1 0 1523
assign 1 0 1526
return 1 745 1530
assign 1 747 1532
assign 1 748 1533
sizeGet 0 748 1533
assign 1 749 1534
greater 1 749 1539
assign 1 750 1540
assign 1 752 1543
assign 1 754 1545
new 0 754 1545
assign 1 755 1546
new 0 755 1546
assign 1 756 1547
new 0 756 1547
assign 1 757 1548
new 0 757 1548
assign 1 757 1551
lesser 1 757 1556
getCode 2 758 1557
getCode 2 759 1558
assign 1 760 1559
notEquals 1 760 1564
assign 1 761 1565
greater 1 761 1570
assign 1 762 1571
new 0 762 1571
return 1 762 1572
assign 1 764 1575
new 0 764 1575
return 1 764 1576
incrementValue 0 757 1579
assign 1 768 1585
new 0 768 1585
assign 1 768 1586
equals 1 768 1591
assign 1 769 1592
greater 1 769 1597
assign 1 770 1598
new 0 770 1598
assign 1 771 1601
greater 1 771 1606
assign 1 772 1607
new 0 772 1607
return 1 775 1611
assign 1 779 1620
undef 1 779 1625
return 1 779 1626
assign 1 780 1628
compare 1 780 1628
assign 1 780 1629
new 0 780 1629
assign 1 780 1630
equals 1 780 1635
assign 1 781 1636
new 0 781 1636
return 1 781 1637
assign 1 783 1639
new 0 783 1639
return 1 783 1640
assign 1 787 1649
undef 1 787 1654
return 1 787 1655
assign 1 788 1657
compare 1 788 1657
assign 1 788 1658
new 0 788 1658
assign 1 788 1659
equals 1 788 1664
assign 1 789 1665
new 0 789 1665
return 1 789 1666
assign 1 791 1668
new 0 791 1668
return 1 791 1669
assign 1 840 1685
new 0 840 1685
return 1 840 1686
assign 1 844 1691
equals 1 844 1691
assign 1 844 1692
not 0 844 1697
return 1 844 1697
assign 1 848 1708
toString 0 848 1708
assign 1 849 1709
sizeGet 0 849 1709
assign 1 849 1710
add 1 849 1710
assign 1 849 1711
new 1 849 1711
assign 1 850 1712
new 0 850 1712
assign 1 850 1713
new 0 850 1713
copyValue 4 850 1714
assign 1 851 1715
new 0 851 1715
assign 1 851 1716
sizeGet 0 851 1716
copyValue 4 851 1717
return 1 852 1718
assign 1 855 1722
new 0 855 1722
return 1 855 1723
assign 1 880 1740
new 0 880 1740
assign 1 880 1741
lesser 1 880 1746
assign 1 0 1747
assign 1 880 1750
sizeGet 0 880 1750
assign 1 880 1751
greater 1 880 1756
assign 1 0 1757
assign 1 880 1760
sizeGet 0 880 1760
assign 1 880 1761
greater 1 880 1766
assign 1 0 1767
assign 1 0 1770
assign 1 0 1774
assign 1 0 1777
assign 1 881 1781
new 0 881 1781
assign 1 881 1782
new 1 881 1782
throw 1 881 1783
assign 1 885 1786
undef 1 885 1791
assign 1 886 1792
new 0 886 1792
assign 1 887 1793
new 0 887 1793
setValue 1 889 1795
subtractValue 1 890 1796
assign 1 891 1797
setValue 1 893 1798
addValue 1 894 1799
assign 1 896 1800
greater 1 896 1805
capacitySet 1 897 1806
assign 1 952 1811
greater 1 952 1816
setValue 1 956 1817
return 1 958 1819
assign 1 963 1825
sizeGet 0 963 1825
assign 1 963 1826
substring 2 963 1826
return 1 963 1827
assign 1 967 1834
subtract 1 967 1834
assign 1 967 1835
new 1 967 1835
assign 1 967 1836
new 0 967 1836
assign 1 967 1837
copyValue 4 967 1837
return 1 967 1838
output 0 1052 1852
assign 1 1056 1857
new 1 1056 1857
return 1 1056 1858
assign 1 1060 1862
new 1 1060 1862
return 1 1060 1863
assign 1 1064 1867
new 1 1064 1867
return 1 1064 1868
assign 1 1068 1872
new 1 1068 1872
return 1 1068 1873
assign 1 1072 1877
new 1 1072 1877
return 1 1072 1878
assign 1 1076 1882
new 1 1076 1882
return 1 1076 1883
return 1 1080 1886
assign 1 1084 1893
undef 1 1084 1898
new 0 1085 1899
assign 1 1087 1902
sizeGet 0 1087 1902
assign 1 1087 1903
new 0 1087 1903
assign 1 1087 1904
add 1 1087 1904
new 1 1087 1905
addValue 1 1088 1906
assign 1 1093 1912
new 0 1093 1912
return 1 1093 1913
assign 1 1097 1918
new 0 1097 1918
assign 1 1097 1919
strip 1 1097 1919
return 1 1097 1920
assign 1 1101 1929
new 0 1101 1929
assign 1 1102 1930
new 0 1102 1930
assign 1 1103 1931
new 0 1103 1931
assign 1 1104 1932
new 0 1104 1932
assign 1 1104 1933
subtract 1 1104 1933
assign 1 1105 1936
greater 1 1105 1941
getInt 2 1106 1942
getInt 2 1107 1943
setInt 2 1108 1944
setInt 2 1109 1945
incrementValue 0 1110 1946
decrementValue 0 1111 1947
return 1 0 1956
assign 1 0 1959
return 1 0 1963
return 1 0 1966
assign 1 0 1969
return 1 0 1973
assign 1 0 1976
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case -1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case -1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case -223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case -855090856: return bem_multiByteIteratorGet_0();
case -1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 195899181: return bem_biterGet_0();
case -1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1607888168: return bem_stringIteratorGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case -729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case -1881757495: return bem_strip_0();
case -139115914: return bem_splitLines_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case -800915430: return bem_reverseBytes_0();
case -1354714650: return bem_copy_0();
case -85457677: return bem_leniGet_0();
case 960545748: return bem_toAlphaNum_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1143153819: return bem_codeNew_1(bevd_0);
case 99049420: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -74375424: return bem_leniSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1954998871: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 636254476: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -1274448085: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1250088509: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case -477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -1298743126: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case 340923733: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1412717737: return bem_compare_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case -1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 599761551: return bem_siziSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1406325780: return bem_writeTo_1(bevd_0);
case -2001811380: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1811422864: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -889715578: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1154529699: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -761715532: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1250088508: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1393886412: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1956186668: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1395074208: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 340923734: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1274448084: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case -391213135: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_6_TextString();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_6_TextString.bevs_inst = (BEC_2_4_6_TextString)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_6_TextString.bevs_inst;
}
}
