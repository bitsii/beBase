package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 817 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 819 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 822 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 828 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 830 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 833 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 840 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(99049421, BEL_4_Base.bevn_has_2, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 842 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 845 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 852 */ {
bevl_r = bevp_container.bemd_0(98246023, BEL_4_Base.bevn_get_0);
bevp_lock.bem_unlock_0();
} /* Line: 854 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 857 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 864 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 866 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 869 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 876 */ {
bevl_r = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 879 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 882 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 889 */ {
bevl_r = bevp_container.bemd_2(98246025, BEL_4_Base.bevn_get_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 891 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 894 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 901 */ {
bevp_container.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 903 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 906 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 912 */ {
bevl_r = bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 914 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 917 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 924 */ {
bevp_container.bemd_1(107034369, BEL_4_Base.bevn_put_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 926 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 929 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 935 */ {
bevl_r = bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 937 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 940 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 947 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 949 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 952 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 958 */ {
bevl_rc = bevp_container.bemd_3(-250195426, BEL_4_Base.bevn_testAndPut_3, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 960 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 963 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 970 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(1959489623, BEL_4_Base.bevn_getMap_0);
bevp_lock.bem_unlock_0();
} /* Line: 972 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 975 */
return bevl_rc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 982 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(1959489624, BEL_4_Base.bevn_getMap_1, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 984 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 987 */
return bevl_rc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 994 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 995 */ {
bevl_didPut = be.BECS_Runtime.boolFalse;
} /* Line: 996 */
 else  /* Line: 997 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_didPut = be.BECS_Runtime.boolTrue;
} /* Line: 999 */
bevp_lock.bem_unlock_0();
} /* Line: 1001 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1004 */
return bevl_didPut;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1011 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(99049420, BEL_4_Base.bevn_has_1, beva_key);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 1012 */ {
bevl_result = bevp_container.bemd_1(98246024, BEL_4_Base.bevn_get_1, beva_key);
} /* Line: 1013 */
 else  /* Line: 1014 */ {
bevp_container.bemd_2(107034370, BEL_4_Base.bevn_put_2, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1016 */
bevp_lock.bem_unlock_0();
} /* Line: 1018 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1021 */
return bevl_result;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1028 */ {
bevp_container.bemd_3(107034371, BEL_4_Base.bevn_put_3, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1030 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1033 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1039 */ {
bevl_r = bevp_container.bemd_1(819712669, BEL_4_Base.bevn_delete_1, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1041 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1044 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1051 */ {
bevl_r = bevp_container.bemd_2(819712670, BEL_4_Base.bevn_delete_2, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1053 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1056 */
return bevl_r;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1063 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1065 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1068 */
return bevl_r;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1075 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(1089531140, BEL_4_Base.bevn_isEmptyGet_0);
bevp_lock.bem_unlock_0();
} /* Line: 1077 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1080 */
return bevl_r;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyContainer_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1087 */ {
bevl_r = bevp_container.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevp_lock.bem_unlock_0();
} /* Line: 1089 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1092 */
return bevl_r;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1099 */ {
bevp_container.bemd_0(856777406, BEL_4_Base.bevn_clear_0);
bevp_lock.bem_unlock_0();
} /* Line: 1101 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1104 */
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1110 */ {
bevp_container.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevp_lock.bem_unlock_0();
} /* Line: 1112 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1115 */
return this;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() throws Throwable {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {813, 816, 818, 819, 821, 822, 827, 829, 830, 832, 833, 835, 839, 841, 842, 844, 845, 847, 851, 853, 854, 856, 857, 859, 863, 865, 866, 868, 869, 871, 875, 877, 878, 879, 881, 882, 884, 888, 890, 891, 893, 894, 896, 900, 902, 903, 905, 906, 911, 913, 914, 916, 917, 919, 923, 925, 926, 928, 929, 934, 936, 937, 939, 940, 942, 946, 948, 949, 951, 952, 957, 959, 960, 962, 963, 965, 969, 971, 972, 974, 975, 977, 981, 983, 984, 986, 987, 989, 993, 995, 996, 998, 999, 1001, 1003, 1004, 1006, 1010, 1012, 1013, 1015, 1016, 1018, 1020, 1021, 1023, 1027, 1029, 1030, 1032, 1033, 1038, 1040, 1041, 1043, 1044, 1046, 1050, 1052, 1053, 1055, 1056, 1058, 1062, 1064, 1065, 1067, 1068, 1070, 1074, 1076, 1077, 1079, 1080, 1082, 1086, 1088, 1089, 1091, 1092, 1094, 1098, 1100, 1101, 1103, 1104, 1109, 1111, 1112, 1114, 1115, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 17, 18, 22, 23, 30, 32, 33, 37, 38, 40, 45, 47, 48, 52, 53, 55, 60, 62, 63, 67, 68, 70, 75, 77, 78, 82, 83, 85, 90, 92, 93, 94, 98, 99, 101, 106, 108, 109, 113, 114, 116, 120, 122, 123, 127, 128, 135, 137, 138, 142, 143, 145, 149, 151, 152, 156, 157, 164, 166, 167, 171, 172, 174, 178, 180, 181, 185, 186, 193, 195, 196, 200, 201, 203, 208, 210, 211, 215, 216, 218, 223, 225, 226, 230, 231, 233, 239, 241, 243, 246, 247, 249, 253, 254, 256, 262, 264, 266, 269, 270, 272, 276, 277, 279, 283, 285, 286, 290, 291, 298, 300, 301, 305, 306, 308, 313, 315, 316, 320, 321, 323, 328, 330, 331, 335, 336, 338, 343, 345, 346, 350, 351, 353, 358, 360, 361, 365, 366, 368, 372, 374, 375, 379, 380, 386, 388, 389, 393, 394, 399, 402, 406, 409};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 813 14
new 0 813 14
lock 0 816 15
assign 1 818 17
unlock 0 819 18
unlock 0 821 22
throw 1 822 23
lock 0 827 30
assign 1 829 32
has 1 829 32
unlock 0 830 33
unlock 0 832 37
throw 1 833 38
return 1 835 40
lock 0 839 45
assign 1 841 47
has 2 841 47
unlock 0 842 48
unlock 0 844 52
throw 1 845 53
return 1 847 55
lock 0 851 60
assign 1 853 62
get 0 853 62
unlock 0 854 63
unlock 0 856 67
throw 1 857 68
return 1 859 70
lock 0 863 75
assign 1 865 77
get 1 865 77
unlock 0 866 78
unlock 0 868 82
throw 1 869 83
return 1 871 85
lock 0 875 90
assign 1 877 92
get 1 877 92
delete 1 878 93
unlock 0 879 94
unlock 0 881 98
throw 1 882 99
return 1 884 101
lock 0 888 106
assign 1 890 108
get 2 890 108
unlock 0 891 109
unlock 0 893 113
throw 1 894 114
return 1 896 116
lock 0 900 120
addValue 1 902 122
unlock 0 903 123
unlock 0 905 127
throw 1 906 128
lock 0 911 135
assign 1 913 137
put 1 913 137
unlock 0 914 138
unlock 0 916 142
throw 1 917 143
return 1 919 145
lock 0 923 149
put 1 925 151
unlock 0 926 152
unlock 0 928 156
throw 1 929 157
lock 0 934 164
assign 1 936 166
put 2 936 166
unlock 0 937 167
unlock 0 939 171
throw 1 940 172
return 1 942 174
lock 0 946 178
put 2 948 180
unlock 0 949 181
unlock 0 951 185
throw 1 952 186
lock 0 957 193
assign 1 959 195
testAndPut 3 959 195
unlock 0 960 196
unlock 0 962 200
throw 1 963 201
return 1 965 203
lock 0 969 208
assign 1 971 210
getMap 0 971 210
unlock 0 972 211
unlock 0 974 215
throw 1 975 216
return 1 977 218
lock 0 981 223
assign 1 983 225
getMap 1 983 225
unlock 0 984 226
unlock 0 986 230
throw 1 987 231
return 1 989 233
lock 0 993 239
assign 1 995 241
has 1 995 241
assign 1 996 243
new 0 996 243
put 2 998 246
assign 1 999 247
new 0 999 247
unlock 0 1001 249
unlock 0 1003 253
throw 1 1004 254
return 1 1006 256
lock 0 1010 262
assign 1 1012 264
has 1 1012 264
assign 1 1013 266
get 1 1013 266
put 2 1015 269
assign 1 1016 270
unlock 0 1018 272
unlock 0 1020 276
throw 1 1021 277
return 1 1023 279
lock 0 1027 283
put 3 1029 285
unlock 0 1030 286
unlock 0 1032 290
throw 1 1033 291
lock 0 1038 298
assign 1 1040 300
delete 1 1040 300
unlock 0 1041 301
unlock 0 1043 305
throw 1 1044 306
return 1 1046 308
lock 0 1050 313
assign 1 1052 315
delete 2 1052 315
unlock 0 1053 316
unlock 0 1055 320
throw 1 1056 321
return 1 1058 323
lock 0 1062 328
assign 1 1064 330
sizeGet 0 1064 330
unlock 0 1065 331
unlock 0 1067 335
throw 1 1068 336
return 1 1070 338
lock 0 1074 343
assign 1 1076 345
isEmptyGet 0 1076 345
unlock 0 1077 346
unlock 0 1079 350
throw 1 1080 351
return 1 1082 353
lock 0 1086 358
assign 1 1088 360
copy 0 1088 360
unlock 0 1089 361
unlock 0 1091 365
throw 1 1092 366
return 1 1094 368
lock 0 1098 372
clear 0 1100 374
unlock 0 1101 375
unlock 0 1103 379
throw 1 1104 380
lock 0 1109 386
close 0 1111 388
unlock 0 1112 389
unlock 0 1114 393
throw 1 1115 394
return 1 0 399
assign 1 0 402
return 1 0 406
assign 1 0 409
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 833063302: return bem_containerGet_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -786424307: return bem_tagGet_0();
case -1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case -314718434: return bem_print_0();
case -1182494494: return bem_toAny_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case -952571108: return bem_lockGet_0();
case 866536361: return bem_close_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 98246023: return bem_get_0();
case 1820417453: return bem_create_0();
case 454584637: return bem_copyContainer_0();
case -729571811: return bem_serializeToString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1354714650: return bem_copy_0();
case 1959489623: return bem_getMap_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case -941488855: return bem_lockSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -365996783: return bem_putReturn_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1572587742: return bem_getAndClear_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1959489624: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 107034370: return bem_put_2(bevd_0, bevd_1);
case 2074693976: return bem_putIfAbsent_2(bevd_0, bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 819712670: return bem_delete_2(bevd_0, bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 99049421: return bem_has_2(bevd_0, bevd_1);
case -365996782: return bem_putReturn_2(bevd_0, bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -188241239: return bem_getOrPut_2(bevd_0, bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 98246025: return bem_get_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 107034371: return bem_put_3(bevd_0, bevd_1, bevd_2);
case -250195426: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
}
