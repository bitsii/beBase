package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_3_6_6_4_SystemThreadLock extends BEC_2_6_6_SystemObject {
public BEC_3_6_6_4_SystemThreadLock() { }

  volatile public ReentrantLock bevi_lock = new ReentrantLock();
  private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4C,0x6F,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_3_6_6_4_SystemThreadLock bevs_inst;
public BEC_2_5_4_LogicBool bem_lock_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

    bevi_lock.lock();
    bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_unlock_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

    bevi_lock.unlock();
    bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {792, 792, 806, 806};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 23, 24};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 792 16
new 0 792 16
return 1 792 17
assign 1 806 23
new 0 806 23
return 1 806 24
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -210949643: return bem_unlock_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case -1097453028: return bem_lock_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_6_4_SystemThreadLock();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_6_4_SystemThreadLock.bevs_inst = (BEC_3_6_6_4_SystemThreadLock)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_6_4_SystemThreadLock.bevs_inst;
}
}
