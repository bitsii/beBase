package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_6_BuildVisitRewind extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_1, 11));
private static byte[] bels_2 = {0x5F,0x30};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_2, 2));
private static byte[] bels_3 = {0x5F,0x30};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_3, 2));
private static byte[] bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_6 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_6, 27));
private static byte[] bels_7 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_8 = {0x41,0x72,0x67,0x73,0x5F,0x31};
private static byte[] bels_9 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x31};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20,0x41,0x20};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_10, 15));
private static byte[] bels_11 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_11, 10));
private static byte[] bels_12 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_3_5_5_6_BuildVisitRewind bevs_inst;
public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_3_5_5_6_BuildVisitRewind bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_83_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_86_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_12_tmpany_phold = beva_node.bem_heldGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(654935401, BEL_4_Base.bevn_wasForeachGennedGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpany_phold).bevi_bool) /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 251 */
 else  /* Line: 251 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 251 */ {
bevt_15_tmpany_phold = beva_node.bem_containerGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevt_20_tmpany_phold = beva_node.bem_containerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_0));
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpany_phold);
if (bevt_17_tmpany_phold != null && bevt_17_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpany_phold).bevi_bool) /* Line: 253 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 253 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 253 */
 else  /* Line: 253 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 253 */ {
bevt_22_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 253 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 253 */
 else  /* Line: 253 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 253 */ {
bevt_26_tmpany_phold = beva_node.bem_containedGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_firstGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpany_phold);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpany_phold).bevi_bool) /* Line: 255 */ {
bevt_31_tmpany_phold = beva_node.bem_containedGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_firstGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_28_tmpany_phold != null && bevt_28_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpany_phold).bevi_bool) /* Line: 255 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 255 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 255 */
 else  /* Line: 255 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 255 */ {
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpany_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_lastGet_0();
bevt_39_tmpany_phold = bevo_0;
bevt_40_tmpany_phold = bevo_1;
bevt_38_tmpany_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpany_phold, bevt_40_tmpany_phold);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_lowerValue_0();
bevt_42_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_41_tmpany_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bevo_2;
bevl_fgin = bevt_36_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpany_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpany_phold = bevo_3;
bevt_45_tmpany_phold = bevl_fgin.bem_add_1(bevt_46_tmpany_phold);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_tmpany_phold.bem_get_1(bevt_45_tmpany_phold);
if (bevl_fgms == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 262 */ {
bevt_48_tmpany_phold = beva_node.bem_heldGet_0();
bevt_48_tmpany_phold.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_fgin);
bevt_49_tmpany_phold = beva_node.bem_heldGet_0();
bevt_51_tmpany_phold = bevo_4;
bevt_50_tmpany_phold = bevl_fgin.bem_add_1(bevt_51_tmpany_phold);
bevt_49_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_50_tmpany_phold);
} /* Line: 265 */
} /* Line: 262 */
} /* Line: 255 */
} /* Line: 253 */
bevt_53_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_tmpany_phold.bevi_int == bevt_54_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 270 */ {
bevp_inClass = beva_node;
bevt_55_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_56_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 273 */
bevt_58_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_59_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 277 */
 else  /* Line: 275 */ {
bevt_61_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpany_phold.bevi_int == bevt_62_tmpany_phold.bevi_int) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 278 */ {
bevt_64_tmpany_phold = beva_node.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
if (bevt_63_tmpany_phold != null && bevt_63_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpany_phold).bevi_bool) /* Line: 278 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 278 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 278 */
 else  /* Line: 278 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 278 */ {
bevt_66_tmpany_phold = beva_node.bem_heldGet_0();
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_67_tmpany_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_65_tmpany_phold, bevt_67_tmpany_phold);
bevt_69_tmpany_phold = beva_node.bem_heldGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_68_tmpany_phold);
if (bevl_ll == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 281 */ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = beva_node.bem_heldGet_0();
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_rmap.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_71_tmpany_phold, bevl_ll);
} /* Line: 283 */
bevl_ll.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 285 */
 else  /* Line: 275 */ {
bevt_74_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_tmpany_phold.bevi_int == bevt_75_tmpany_phold.bevi_int) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_77_tmpany_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 286 */ {
bevt_80_tmpany_phold = beva_node.bem_containerGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_containerGet_0();
if (bevt_79_tmpany_phold == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 286 */ {
bevt_84_tmpany_phold = beva_node.bem_containerGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bem_containerGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_typenameGet_0();
bevt_85_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_tmpany_phold.bevi_int == bevt_85_tmpany_phold.bevi_int) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 286 */ {
this.bem_processTmps_0();
} /* Line: 288 */
} /* Line: 275 */
} /* Line: 275 */
bevt_86_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpany_phold;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_103_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 302 */ {
if (bevl_foundone != null && bevl_foundone instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevl_foundone).bevi_bool) /* Line: 302 */ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(-2145224760, BEL_4_Base.bevn_valueIteratorGet_0);
while (true)
 /* Line: 304 */ {
bevt_9_tmpany_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_9_tmpany_phold != null && bevt_9_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpany_phold).bevi_bool) /* Line: 304 */ {
bevl_nv = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_11_tmpany_phold = bevl_nv.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpany_phold).bevi_bool) /* Line: 307 */ {
bevl_nvname = bevl_nv.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_ll = bevp_rmap.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_nvname);
bevt_0_tmpany_loop = bevl_ll.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 312 */ {
bevt_12_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpany_phold != null && bevt_12_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpany_phold).bevi_bool) /* Line: 312 */ {
bevl_k = bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpany_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpany_phold).bevi_bool) /* Line: 313 */ {
bevt_16_tmpany_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_17_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpany_phold);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 313 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 313 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 313 */
 else  /* Line: 313 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 313 */ {
bevt_21_tmpany_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_22_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_4));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_22_tmpany_phold);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpany_phold).bevi_bool) /* Line: 313 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 313 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 313 */
 else  /* Line: 313 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 313 */ {
bevt_26_tmpany_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_27_tmpany_phold);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpany_phold).bevi_bool) /* Line: 313 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 313 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 313 */
 else  /* Line: 313 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 313 */ {
bevt_28_tmpany_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevl_tcall = bevt_28_tmpany_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targNp = null;
bevt_31_tmpany_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_30_tmpany_phold == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 317 */ {
bevt_32_tmpany_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_targNp = bevt_32_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
} /* Line: 318 */
 else  /* Line: 319 */ {
bevt_33_tmpany_phold = bevl_tcall.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_targ = bevt_33_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_35_tmpany_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpany_phold).bevi_bool) /* Line: 324 */ {
bevl_tany = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 325 */
 else  /* Line: 326 */ {
bevt_37_tmpany_phold = bevp_inClassSyn.bemd_0(-153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_39_tmpany_phold = bevl_targ.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_38_tmpany_phold);
bevl_tany = bevt_36_tmpany_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 327 */
bevt_40_tmpany_phold = bevl_tany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_targNp = bevl_tany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 331 */
} /* Line: 330 */
if (bevl_targNp == null) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 334 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_44_tmpany_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_42_tmpany_phold.bem_get_1(bevt_43_tmpany_phold);
if (bevl_mtdc == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 338 */ {
bevl_oany = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevl_oany == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevt_47_tmpany_phold = bevl_oany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_47_tmpany_phold != null && bevt_47_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpany_phold).bevi_bool) /* Line: 341 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 341 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 341 */
 else  /* Line: 341 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 341 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_48_tmpany_phold != null && bevt_48_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpany_phold).bevi_bool) /* Line: 344 */ {
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_targNp);
} /* Line: 345 */
 else  /* Line: 346 */ {
bevt_49_tmpany_phold = bevl_oany.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_49_tmpany_phold);
} /* Line: 347 */
bevt_50_tmpany_phold = bevl_oany.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bevp_inClass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_52_tmpany_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_51_tmpany_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_52_tmpany_phold);
bevt_55_tmpany_phold = bevl_nv.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_5));
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_56_tmpany_phold);
if (bevt_53_tmpany_phold != null && bevt_53_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_53_tmpany_phold).bevi_bool) /* Line: 351 */ {
bevt_58_tmpany_phold = bevo_5;
bevt_59_tmpany_phold = bevl_oany.bemd_0(-535212143, BEL_4_Base.bevn_isSelfGet_0);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold.bem_print_0();
} /* Line: 351 */
} /* Line: 351 */
} /* Line: 341 */
 else  /* Line: 338 */ {
bevt_62_tmpany_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_7));
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_63_tmpany_phold);
if (bevt_60_tmpany_phold != null && bevt_60_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_60_tmpany_phold).bevi_bool) /* Line: 353 */ {
bevt_66_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_69_tmpany_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_70_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_8));
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_70_tmpany_phold);
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bem_get_1(bevt_67_tmpany_phold);
if (bevt_65_tmpany_phold == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_73_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_74_tmpany_phold = bevo_6;
bevt_72_tmpany_phold = bevt_73_tmpany_phold.bem_get_1(bevt_74_tmpany_phold);
if (bevt_72_tmpany_phold == null) {
bevt_71_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_71_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 355 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 355 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 355 */ {
bevt_75_tmpany_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_75_tmpany_phold.bemd_1(1154745507, BEL_4_Base.bevn_untypedSet_1, bevt_76_tmpany_phold);
} /* Line: 356 */
 else  /* Line: 357 */ {
bevt_81_tmpany_phold = bevo_7;
bevt_83_tmpany_phold = bevl_tcall.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_80_tmpany_phold = bevt_81_tmpany_phold.bem_add_1(bevt_82_tmpany_phold);
bevt_84_tmpany_phold = bevo_8;
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_add_1(bevt_84_tmpany_phold);
bevt_85_tmpany_phold = bevl_targNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bem_add_1(bevt_85_tmpany_phold);
bevt_77_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_78_tmpany_phold, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_77_tmpany_phold);
} /* Line: 358 */
} /* Line: 354 */
} /* Line: 338 */
} /* Line: 338 */
} /* Line: 334 */
 else  /* Line: 313 */ {
bevt_86_tmpany_phold = bevl_k.bemd_0(1987872129, BEL_4_Base.bevn_isFirstGet_0);
if (bevt_86_tmpany_phold != null && bevt_86_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_86_tmpany_phold).bevi_bool) /* Line: 364 */ {
bevt_89_tmpany_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_90_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_90_tmpany_phold);
if (bevt_87_tmpany_phold != null && bevt_87_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_87_tmpany_phold).bevi_bool) /* Line: 364 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 364 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 364 */
 else  /* Line: 364 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 364 */ {
bevt_94_tmpany_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_12));
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_95_tmpany_phold);
if (bevt_91_tmpany_phold != null && bevt_91_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_91_tmpany_phold).bevi_bool) /* Line: 364 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 364 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 364 */
 else  /* Line: 364 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 364 */ {
bevt_99_tmpany_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_100_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_100_tmpany_phold);
if (bevt_96_tmpany_phold != null && bevt_96_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_96_tmpany_phold).bevi_bool) /* Line: 364 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 364 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 364 */
 else  /* Line: 364 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 364 */ {
bevt_102_tmpany_phold = bevl_k.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
bevt_101_tmpany_phold = bevt_102_tmpany_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevl_targ = bevt_101_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_103_tmpany_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_103_tmpany_phold != null && bevt_103_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_103_tmpany_phold).bevi_bool) /* Line: 367 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_104_tmpany_phold = bevl_targ.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevl_nv.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_104_tmpany_phold);
bevt_105_tmpany_phold = bevl_targ.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_nv.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_105_tmpany_phold);
} /* Line: 372 */
} /* Line: 367 */
} /* Line: 313 */
} /* Line: 313 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
} /* Line: 312 */
} /* Line: 307 */
 else  /* Line: 304 */ {
break;
} /* Line: 304 */
} /* Line: 304 */
} /* Line: 304 */
 else  /* Line: 302 */ {
break;
} /* Line: 302 */
} /* Line: 302 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() throws Throwable {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_tvmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() throws Throwable {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_rmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClass = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {251, 251, 251, 251, 251, 251, 0, 0, 0, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 0, 0, 0, 253, 0, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 0, 0, 256, 256, 256, 256, 257, 257, 258, 258, 258, 258, 258, 258, 258, 258, 258, 260, 261, 261, 261, 261, 262, 262, 264, 264, 265, 265, 265, 265, 270, 270, 270, 270, 271, 272, 272, 273, 273, 275, 275, 275, 275, 276, 277, 278, 278, 278, 278, 278, 278, 0, 0, 0, 279, 279, 279, 279, 280, 280, 280, 281, 281, 282, 283, 283, 283, 285, 286, 286, 286, 286, 286, 286, 286, 0, 0, 0, 286, 286, 286, 286, 0, 0, 0, 286, 286, 286, 286, 286, 286, 0, 0, 0, 288, 290, 290, 294, 303, 304, 304, 305, 307, 307, 310, 311, 312, 0, 312, 312, 313, 313, 313, 313, 313, 0, 0, 0, 313, 313, 313, 313, 313, 0, 0, 0, 313, 313, 313, 313, 313, 0, 0, 0, 315, 315, 316, 317, 317, 317, 317, 318, 318, 320, 320, 324, 324, 325, 327, 327, 327, 327, 327, 330, 331, 334, 334, 336, 337, 337, 337, 337, 338, 338, 340, 341, 341, 341, 0, 0, 0, 342, 344, 345, 347, 347, 349, 349, 350, 350, 350, 351, 351, 351, 351, 351, 351, 351, 351, 353, 353, 353, 353, 354, 354, 354, 354, 354, 354, 354, 354, 0, 355, 355, 355, 355, 355, 0, 0, 356, 356, 356, 358, 358, 358, 358, 358, 358, 358, 358, 358, 358, 364, 364, 364, 364, 364, 0, 0, 0, 364, 364, 364, 364, 364, 0, 0, 0, 364, 364, 364, 364, 364, 0, 0, 0, 365, 365, 365, 367, 369, 371, 371, 372, 372, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {134, 135, 136, 141, 142, 143, 145, 148, 152, 155, 156, 157, 158, 163, 164, 165, 166, 167, 168, 170, 173, 177, 180, 182, 185, 189, 192, 193, 194, 195, 196, 198, 199, 200, 201, 203, 206, 210, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 238, 239, 240, 241, 242, 243, 244, 249, 250, 251, 256, 257, 258, 259, 260, 261, 263, 264, 265, 270, 271, 272, 275, 276, 277, 282, 283, 284, 286, 289, 293, 296, 297, 298, 299, 300, 301, 302, 303, 308, 309, 310, 311, 312, 314, 317, 318, 319, 324, 325, 326, 331, 332, 335, 339, 342, 343, 344, 349, 350, 353, 357, 360, 361, 362, 363, 364, 369, 370, 373, 377, 380, 384, 385, 507, 511, 512, 515, 517, 518, 519, 521, 522, 523, 523, 526, 528, 529, 531, 532, 533, 534, 536, 539, 543, 546, 547, 548, 549, 550, 552, 555, 559, 562, 563, 564, 565, 566, 568, 571, 575, 578, 579, 580, 581, 582, 583, 588, 589, 590, 593, 594, 595, 596, 598, 601, 602, 603, 604, 605, 607, 609, 612, 617, 618, 619, 620, 621, 622, 623, 628, 629, 630, 635, 636, 638, 641, 645, 648, 649, 651, 654, 655, 657, 658, 659, 660, 661, 662, 663, 664, 665, 667, 668, 669, 670, 675, 676, 677, 678, 680, 681, 682, 683, 684, 685, 686, 691, 692, 695, 696, 697, 698, 703, 704, 707, 711, 712, 713, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 732, 734, 735, 736, 737, 739, 742, 746, 749, 750, 751, 752, 753, 755, 758, 762, 765, 766, 767, 768, 769, 771, 774, 778, 781, 782, 783, 784, 786, 787, 788, 789, 790, 813, 816, 820, 823, 827, 830, 834, 837, 841, 844, 848, 851, 855, 858};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 251 134
typenameGet 0 251 134
assign 1 251 135
CALLGet 0 251 135
assign 1 251 136
equals 1 251 141
assign 1 251 142
heldGet 0 251 142
assign 1 251 143
wasForeachGennedGet 0 251 143
assign 1 0 145
assign 1 0 148
assign 1 0 152
assign 1 253 155
containerGet 0 253 155
assign 1 253 156
typenameGet 0 253 156
assign 1 253 157
CALLGet 0 253 157
assign 1 253 158
equals 1 253 163
assign 1 253 164
containerGet 0 253 164
assign 1 253 165
heldGet 0 253 165
assign 1 253 166
orgNameGet 0 253 166
assign 1 253 167
new 0 253 167
assign 1 253 168
equals 1 253 168
assign 1 0 170
assign 1 0 173
assign 1 0 177
assign 1 253 180
isSecondGet 0 253 180
assign 1 0 182
assign 1 0 185
assign 1 0 189
assign 1 255 192
containedGet 0 255 192
assign 1 255 193
firstGet 0 255 193
assign 1 255 194
typenameGet 0 255 194
assign 1 255 195
VARGet 0 255 195
assign 1 255 196
equals 1 255 196
assign 1 255 198
containedGet 0 255 198
assign 1 255 199
firstGet 0 255 199
assign 1 255 200
heldGet 0 255 200
assign 1 255 201
isTypedGet 0 255 201
assign 1 0 203
assign 1 0 206
assign 1 0 210
assign 1 256 213
containedGet 0 256 213
assign 1 256 214
firstGet 0 256 214
assign 1 256 215
heldGet 0 256 215
assign 1 256 216
namepathGet 0 256 216
assign 1 257 217
stepsGet 0 257 217
assign 1 257 218
lastGet 0 257 218
assign 1 258 219
new 0 258 219
assign 1 258 220
new 0 258 220
assign 1 258 221
substring 2 258 221
assign 1 258 222
lowerValue 0 258 222
assign 1 258 223
new 0 258 223
assign 1 258 224
substring 1 258 224
assign 1 258 225
add 1 258 225
assign 1 258 226
new 0 258 226
assign 1 258 227
add 1 258 227
assign 1 260 228
getSynNp 1 260 228
assign 1 261 229
mtdMapGet 0 261 229
assign 1 261 230
new 0 261 230
assign 1 261 231
add 1 261 231
assign 1 261 232
get 1 261 232
assign 1 262 233
def 1 262 238
assign 1 264 239
heldGet 0 264 239
orgNameSet 1 264 240
assign 1 265 241
heldGet 0 265 241
assign 1 265 242
new 0 265 242
assign 1 265 243
add 1 265 243
nameSet 1 265 244
assign 1 270 249
typenameGet 0 270 249
assign 1 270 250
CLASSGet 0 270 250
assign 1 270 251
equals 1 270 256
assign 1 271 257
assign 1 272 258
heldGet 0 272 258
assign 1 272 259
namepathGet 0 272 259
assign 1 273 260
heldGet 0 273 260
assign 1 273 261
synGet 0 273 261
assign 1 275 263
typenameGet 0 275 263
assign 1 275 264
METHODGet 0 275 264
assign 1 275 265
equals 1 275 270
assign 1 276 271
new 0 276 271
assign 1 277 272
new 0 277 272
assign 1 278 275
typenameGet 0 278 275
assign 1 278 276
VARGet 0 278 276
assign 1 278 277
equals 1 278 282
assign 1 278 283
heldGet 0 278 283
assign 1 278 284
isTmpVarGet 0 278 284
assign 1 0 286
assign 1 0 289
assign 1 0 293
assign 1 279 296
heldGet 0 279 296
assign 1 279 297
nameGet 0 279 297
assign 1 279 298
heldGet 0 279 298
put 2 279 299
assign 1 280 300
heldGet 0 280 300
assign 1 280 301
nameGet 0 280 301
assign 1 280 302
get 1 280 302
assign 1 281 303
undef 1 281 308
assign 1 282 309
new 0 282 309
assign 1 283 310
heldGet 0 283 310
assign 1 283 311
nameGet 0 283 311
put 2 283 312
addValue 1 285 314
assign 1 286 317
typenameGet 0 286 317
assign 1 286 318
RBRACESGet 0 286 318
assign 1 286 319
equals 1 286 324
assign 1 286 325
containerGet 0 286 325
assign 1 286 326
def 1 286 331
assign 1 0 332
assign 1 0 335
assign 1 0 339
assign 1 286 342
containerGet 0 286 342
assign 1 286 343
containerGet 0 286 343
assign 1 286 344
def 1 286 349
assign 1 0 350
assign 1 0 353
assign 1 0 357
assign 1 286 360
containerGet 0 286 360
assign 1 286 361
containerGet 0 286 361
assign 1 286 362
typenameGet 0 286 362
assign 1 286 363
METHODGet 0 286 363
assign 1 286 364
equals 1 286 369
assign 1 0 370
assign 1 0 373
assign 1 0 377
processTmps 0 288 380
assign 1 290 384
nextDescendGet 0 290 384
return 1 290 385
assign 1 294 507
new 0 294 507
assign 1 303 511
new 0 303 511
assign 1 304 512
valueIteratorGet 0 304 512
assign 1 304 515
hasNextGet 0 304 515
assign 1 305 517
nextGet 0 305 517
assign 1 307 518
isTypedGet 0 307 518
assign 1 307 519
not 0 307 519
assign 1 310 521
nameGet 0 310 521
assign 1 311 522
get 1 311 522
assign 1 312 523
iteratorGet 0 0 523
assign 1 312 526
hasNextGet 0 312 526
assign 1 312 528
nextGet 0 312 528
assign 1 313 529
isFirstGet 0 313 529
assign 1 313 531
containerGet 0 313 531
assign 1 313 532
typenameGet 0 313 532
assign 1 313 533
CALLGet 0 313 533
assign 1 313 534
equals 1 313 534
assign 1 0 536
assign 1 0 539
assign 1 0 543
assign 1 313 546
containerGet 0 313 546
assign 1 313 547
heldGet 0 313 547
assign 1 313 548
orgNameGet 0 313 548
assign 1 313 549
new 0 313 549
assign 1 313 550
equals 1 313 550
assign 1 0 552
assign 1 0 555
assign 1 0 559
assign 1 313 562
containerGet 0 313 562
assign 1 313 563
secondGet 0 313 563
assign 1 313 564
typenameGet 0 313 564
assign 1 313 565
CALLGet 0 313 565
assign 1 313 566
equals 1 313 566
assign 1 0 568
assign 1 0 571
assign 1 0 575
assign 1 315 578
containerGet 0 315 578
assign 1 315 579
secondGet 0 315 579
assign 1 316 580
assign 1 317 581
heldGet 0 317 581
assign 1 317 582
newNpGet 0 317 582
assign 1 317 583
def 1 317 588
assign 1 318 589
heldGet 0 318 589
assign 1 318 590
newNpGet 0 318 590
assign 1 320 593
containedGet 0 320 593
assign 1 320 594
firstGet 0 320 594
assign 1 324 595
heldGet 0 324 595
assign 1 324 596
isDeclaredGet 0 324 596
assign 1 325 598
heldGet 0 325 598
assign 1 327 601
ptyMapGet 0 327 601
assign 1 327 602
heldGet 0 327 602
assign 1 327 603
nameGet 0 327 603
assign 1 327 604
get 1 327 604
assign 1 327 605
memSynGet 0 327 605
assign 1 330 607
isTypedGet 0 330 607
assign 1 331 609
namepathGet 0 331 609
assign 1 334 612
def 1 334 617
assign 1 336 618
getSynNp 1 336 618
assign 1 337 619
mtdMapGet 0 337 619
assign 1 337 620
heldGet 0 337 620
assign 1 337 621
nameGet 0 337 621
assign 1 337 622
get 1 337 622
assign 1 338 623
def 1 338 628
assign 1 340 629
rsynGet 0 340 629
assign 1 341 630
def 1 341 635
assign 1 341 636
isTypedGet 0 341 636
assign 1 0 638
assign 1 0 641
assign 1 0 645
assign 1 342 648
new 0 342 648
assign 1 344 649
isSelfGet 0 344 649
namepathSet 1 345 651
assign 1 347 654
namepathGet 0 347 654
namepathSet 1 347 655
assign 1 349 657
isTypedGet 0 349 657
isTypedSet 1 349 658
assign 1 350 659
heldGet 0 350 659
assign 1 350 660
namepathGet 0 350 660
addUsed 1 350 661
assign 1 351 662
namepathGet 0 351 662
assign 1 351 663
toString 0 351 663
assign 1 351 664
new 0 351 664
assign 1 351 665
equals 1 351 665
assign 1 351 667
new 0 351 667
assign 1 351 668
isSelfGet 0 351 668
assign 1 351 669
add 1 351 669
print 0 351 670
assign 1 353 675
heldGet 0 353 675
assign 1 353 676
orgNameGet 0 353 676
assign 1 353 677
new 0 353 677
assign 1 353 678
notEquals 1 353 678
assign 1 354 680
mtdMapGet 0 354 680
assign 1 354 681
heldGet 0 354 681
assign 1 354 682
orgNameGet 0 354 682
assign 1 354 683
new 0 354 683
assign 1 354 684
add 1 354 684
assign 1 354 685
get 1 354 685
assign 1 354 686
def 1 354 691
assign 1 0 692
assign 1 355 695
mtdMapGet 0 355 695
assign 1 355 696
new 0 355 696
assign 1 355 697
get 1 355 697
assign 1 355 698
def 1 355 703
assign 1 0 704
assign 1 0 707
assign 1 356 711
heldGet 0 356 711
assign 1 356 712
new 0 356 712
untypedSet 1 356 713
assign 1 358 716
new 0 358 716
assign 1 358 717
heldGet 0 358 717
assign 1 358 718
nameGet 0 358 718
assign 1 358 719
add 1 358 719
assign 1 358 720
new 0 358 720
assign 1 358 721
add 1 358 721
assign 1 358 722
toString 0 358 722
assign 1 358 723
add 1 358 723
assign 1 358 724
new 2 358 724
throw 1 358 725
assign 1 364 732
isFirstGet 0 364 732
assign 1 364 734
containerGet 0 364 734
assign 1 364 735
typenameGet 0 364 735
assign 1 364 736
CALLGet 0 364 736
assign 1 364 737
equals 1 364 737
assign 1 0 739
assign 1 0 742
assign 1 0 746
assign 1 364 749
containerGet 0 364 749
assign 1 364 750
heldGet 0 364 750
assign 1 364 751
orgNameGet 0 364 751
assign 1 364 752
new 0 364 752
assign 1 364 753
equals 1 364 753
assign 1 0 755
assign 1 0 758
assign 1 0 762
assign 1 364 765
containerGet 0 364 765
assign 1 364 766
secondGet 0 364 766
assign 1 364 767
typenameGet 0 364 767
assign 1 364 768
VARGet 0 364 768
assign 1 364 769
equals 1 364 769
assign 1 0 771
assign 1 0 774
assign 1 0 778
assign 1 365 781
containerGet 0 365 781
assign 1 365 782
secondGet 0 365 782
assign 1 365 783
heldGet 0 365 783
assign 1 367 784
isTypedGet 0 367 784
assign 1 369 786
new 0 369 786
assign 1 371 787
isTypedGet 0 371 787
isTypedSet 1 371 788
assign 1 372 789
namepathGet 0 372 789
namepathSet 1 372 790
return 1 0 813
assign 1 0 816
return 1 0 820
assign 1 0 823
return 1 0 827
assign 1 0 830
return 1 0 834
assign 1 0 837
return 1 0 841
assign 1 0 844
return 1 0 848
assign 1 0 851
return 1 0 855
assign 1 0 858
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -493012039: return bem_buildGet_0();
case -2028575047: return bem_emitterGet_0();
case -1308786538: return bem_echo_0();
case -1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2001798761: return bem_nlGet_0();
case 2055025483: return bem_serializeContents_0();
case -2041762316: return bem_inClassGet_0();
case 304475661: return bem_tvmapGet_0();
case -1012494862: return bem_once_0();
case -997464046: return bem_inClassSynGet_0();
case -1081412016: return bem_many_0();
case 1344145980: return bem_processTmps_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
case 265089021: return bem_rmapGet_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -2030680063: return bem_inClassSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case 315557914: return bem_tvmapSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 276171274: return bem_rmapSet_1(bevd_0);
case -1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitRewind.bevs_inst = (BEC_3_5_5_6_BuildVisitRewind)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitRewind.bevs_inst;
}
}
