package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException extends BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bels_1 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_2 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_5 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bels_6 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_7 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_8 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bels_9 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_10, 2));
private static byte[] bels_11 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_11, 2));
private static byte[] bels_12 = {0x0D,0x0A};
private static byte[] bels_13 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x61,0x74,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_14, 3));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_15 = {0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_15, 1));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_16 = {0x69,0x6E};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_16, 2));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_17 = {0x20};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_17, 1));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_18 = {0x3A};
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_19 = {0x6C,0x69,0x6E,0x65,0x20};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_19, 5));
private static byte[] bels_20 = {0x28};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_20, 1));
private static byte[] bels_21 = {0x29};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_21, 1));
private static BEC_2_4_3_MathInt bevo_18 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_22 = {0x3A};
private static BEC_2_4_3_MathInt bevo_20 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_23 = {0x3A};
private static BEC_2_4_3_MathInt bevo_21 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_22 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_24 = {0x28};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bels_24, 1));
private static BEC_2_4_3_MathInt bevo_24 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_25 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_26 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_25 = {0x2E};
private static byte[] bels_26 = {0x2E};
private static BEC_2_4_3_MathInt bevo_27 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_27 = {0x42,0x45,0x4C,0x5F};
private static BEC_2_4_6_TextString bevo_28 = (new BEC_2_4_6_TextString(bels_27, 4));
private static BEC_2_4_3_MathInt bevo_29 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_28 = {0x5F};
private static BEC_2_4_6_TextString bevo_30 = (new BEC_2_4_6_TextString(bels_28, 1));
private static BEC_2_4_3_MathInt bevo_31 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_32 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_33 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_34 = (new BEC_2_4_3_MathInt(7));
private static byte[] bels_29 = {0x62,0x65};
private static byte[] bels_30 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_35 = (new BEC_2_4_6_TextString(bels_30, 2));
private static byte[] bels_31 = {0x62,0x65};
private static byte[] bels_32 = {0x2E};
private static byte[] bels_33 = {0x42,0x45,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_36 = (new BEC_2_4_6_TextString(bels_33, 4));
private static byte[] bels_34 = {0x5F};
private static BEC_2_4_3_MathInt bevo_37 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_38 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_35 = {0x3A};
private static byte[] bels_36 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_39 = (new BEC_2_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x5F};
private static BEC_2_4_3_MathInt bevo_40 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_41 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_38 = {0x5F};
private static byte[] bels_39 = {0x0A};
private static BEC_2_4_6_TextString bevo_42 = (new BEC_2_4_6_TextString(bels_39, 1));
public static BEC_2_6_9_SystemException bevs_inst;
public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) throws Throwable {
bevp_description = beva_descr;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString(11, bels_0));
if (bevp_lang == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_1));
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevl_toRet = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_lang);
} /* Line: 37 */
if (bevp_emitLang == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 39 */ {
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_2));
bevt_4_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_emitLang);
} /* Line: 40 */
if (bevp_methodName == null) {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 42 */ {
bevt_8_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_3));
bevt_7_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_8_tmpvar_phold);
bevl_toRet = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_methodName);
} /* Line: 43 */
if (bevp_klassName == null) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevt_11_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_4));
bevt_10_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_toRet = bevt_10_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_klassName);
} /* Line: 46 */
if (bevp_description == null) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_14_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_5));
bevt_13_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevl_toRet = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_description);
} /* Line: 49 */
if (bevp_fileName == null) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_17_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_6));
bevt_16_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_17_tmpvar_phold);
bevl_toRet = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_fileName);
} /* Line: 52 */
if (bevp_lineNumber == null) {
bevt_18_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_20_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_7));
bevt_19_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = bevp_lineNumber.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toRet = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
} /* Line: 55 */
if (bevp_framesText == null) {
bevt_22_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_24_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_8));
bevt_23_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevl_toRet = bevt_23_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_framesText);
} /* Line: 58 */
if (bevp_frames == null) {
bevt_25_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_26_tmpvar_phold = this.bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 61 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_translateEmittedException_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
try  /* Line: 67 */ {
this.bem_translateEmittedExceptionInner_0();
} /* Line: 68 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_0_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold.bem_print_0();
} /* Line: 70 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_translateEmittedExceptionInner_0() throws Throwable {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_4_6_TextString bevl_libLens = null;
BEC_2_4_3_MathInt bevl_libLen = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_113_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_115_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_117_tmpvar_phold = null;
if (bevp_translated == null) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 78 */ {
if (bevp_translated.bevi_bool) /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
 else  /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 78 */ {
return this;
} /* Line: 79 */
bevp_translated = be.BECS_Runtime.boolTrue;
if (bevp_framesText == null) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 82 */ {
if (bevp_lang == null) {
bevt_14_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
 else  /* Line: 82 */ {
bevt_4_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevt_16_tmpvar_phold = bevo_1;
bevt_15_tmpvar_phold = bevp_lang.bem_equals_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_18_tmpvar_phold = bevo_2;
bevt_17_tmpvar_phold = bevp_lang.bem_equals_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevt_19_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_12));
bevl_ltok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_19_tmpvar_phold);
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevp_framesText);
bevt_21_tmpvar_phold = bevo_3;
bevt_20_tmpvar_phold = bevp_lang.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevl_isCs = be.BECS_Runtime.boolTrue;
} /* Line: 86 */
 else  /* Line: 87 */ {
bevl_isCs = be.BECS_Runtime.boolFalse;
} /* Line: 88 */
bevt_0_tmpvar_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 90 */ {
bevt_22_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 90 */ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_23_tmpvar_phold = bevo_4;
bevl_start = bevl_line.bem_find_1(bevt_23_tmpvar_phold);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_24_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 95 */ {
bevt_26_tmpvar_phold = bevo_5;
if (bevl_start.bevi_int >= bevt_26_tmpvar_phold.bevi_int) {
bevt_25_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 95 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_5_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 95 */ {
bevt_27_tmpvar_phold = bevo_6;
bevt_29_tmpvar_phold = bevo_7;
bevt_28_tmpvar_phold = bevl_start.bem_add_1(bevt_29_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_27_tmpvar_phold, bevt_28_tmpvar_phold);
if (bevl_end == null) {
bevt_30_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 98 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_31_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 98 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 98 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 98 */
 else  /* Line: 98 */ {
bevt_6_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 98 */ {
bevt_33_tmpvar_phold = bevo_8;
bevt_32_tmpvar_phold = bevl_start.bem_add_1(bevt_33_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_32_tmpvar_phold, bevl_end);
if (bevl_isCs.bevi_bool) /* Line: 102 */ {
bevt_34_tmpvar_phold = bevo_9;
bevl_start = bevl_line.bem_find_2(bevt_34_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_35_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_37_tmpvar_phold = bevo_10;
bevt_36_tmpvar_phold = bevl_start.bem_add_1(bevt_37_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_1(bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevo_11;
bevt_38_tmpvar_phold = bevl_inPart.bem_ends_1(bevt_39_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 107 */ {
bevt_41_tmpvar_phold = bevl_inPart.bem_sizeGet_0();
bevt_42_tmpvar_phold = bevo_12;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_subtract_1(bevt_42_tmpvar_phold);
bevl_inPart.bem_sizeSet_1(bevt_40_tmpvar_phold);
} /* Line: 108 */
bevt_43_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_18));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_43_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_44_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_45_tmpvar_phold = bevo_13;
bevl_efile = bevl_inPart.bem_substring_2(bevt_45_tmpvar_phold, bevl_pdelim);
bevt_47_tmpvar_phold = bevo_14;
bevt_46_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_47_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_46_tmpvar_phold);
bevt_49_tmpvar_phold = bevo_15;
bevt_48_tmpvar_phold = bevl_iv.bem_begins_1(bevt_49_tmpvar_phold);
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_50_tmpvar_phold = (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_50_tmpvar_phold);
} /* Line: 117 */
bevt_51_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 121 */
} /* Line: 120 */
} /* Line: 112 */
} /* Line: 104 */
 else  /* Line: 125 */ {
bevt_52_tmpvar_phold = bevo_16;
bevl_start = bevl_line.bem_find_2(bevt_52_tmpvar_phold, bevl_end);
if (bevl_start == null) {
bevt_53_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevt_54_tmpvar_phold = bevo_17;
bevt_56_tmpvar_phold = bevo_18;
bevt_55_tmpvar_phold = bevl_start.bem_add_1(bevt_56_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_54_tmpvar_phold, bevt_55_tmpvar_phold);
if (bevl_end == null) {
bevt_57_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_57_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevt_59_tmpvar_phold = bevo_19;
bevt_58_tmpvar_phold = bevl_start.bem_add_1(bevt_59_tmpvar_phold);
bevl_inPart = bevl_line.bem_substring_2(bevt_58_tmpvar_phold, bevl_end);
bevt_60_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_22));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_60_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_61_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_61_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_62_tmpvar_phold = bevo_20;
bevl_inPart = bevl_inPart.bem_substring_2(bevt_62_tmpvar_phold, bevl_pdelim);
bevt_63_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_23));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_63_tmpvar_phold);
if (bevl_pdelim == null) {
bevt_64_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_64_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 140 */ {
bevt_65_tmpvar_phold = bevo_21;
bevl_efile = bevl_inPart.bem_substring_2(bevt_65_tmpvar_phold, bevl_pdelim);
} /* Line: 141 */
bevt_67_tmpvar_phold = bevo_22;
bevt_66_tmpvar_phold = bevl_pdelim.bem_add_1(bevt_67_tmpvar_phold);
bevl_iv = bevl_inPart.bem_substring_1(bevt_66_tmpvar_phold);
bevt_68_tmpvar_phold = bevl_iv.bem_isInteger_0();
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 146 */
} /* Line: 145 */
} /* Line: 136 */
} /* Line: 131 */
} /* Line: 127 */
} /* Line: 102 */
 else  /* Line: 152 */ {
bevt_69_tmpvar_phold = bevo_23;
bevt_71_tmpvar_phold = bevo_24;
bevt_70_tmpvar_phold = bevl_start.bem_add_1(bevt_71_tmpvar_phold);
bevl_end = bevl_line.bem_find_2(bevt_69_tmpvar_phold, bevt_70_tmpvar_phold);
if (bevl_end == null) {
bevt_72_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 154 */ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_73_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_7_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 154 */ {
bevt_75_tmpvar_phold = bevo_25;
bevt_74_tmpvar_phold = bevl_start.bem_add_1(bevt_75_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_2(bevt_74_tmpvar_phold, bevl_end);
} /* Line: 155 */
 else  /* Line: 156 */ {
bevt_77_tmpvar_phold = bevo_26;
bevt_76_tmpvar_phold = bevl_start.bem_add_1(bevt_77_tmpvar_phold);
bevl_callPart = bevl_line.bem_substring_1(bevt_76_tmpvar_phold);
} /* Line: 157 */
} /* Line: 154 */
if (bevl_callPart == null) {
bevt_78_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 160 */ {
if (bevl_isCs.bevi_bool) /* Line: 161 */ {
bevt_79_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_25));
bevl_parts = bevl_callPart.bem_split_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_80_tmpvar_phold);
bevt_81_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_81_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_83_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_82_tmpvar_phold = this.bem_getSourceFileName_1(bevt_83_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_82_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 174 */
 else  /* Line: 175 */ {
bevt_84_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_26));
bevl_parts = bevl_callPart.bem_split_1(bevt_84_tmpvar_phold);
bevt_86_tmpvar_phold = bevl_parts.bem_sizeGet_0();
bevt_87_tmpvar_phold = bevo_27;
if (bevt_86_tmpvar_phold.bevi_int > bevt_87_tmpvar_phold.bevi_int) {
bevt_85_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_85_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 179 */ {
bevt_88_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_88_tmpvar_phold);
bevl_mtd = this.bem_extractMethod_1(bevl_mtd);
bevt_89_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_89_tmpvar_phold);
bevt_90_tmpvar_phold = bevo_28;
bevl_start = bevl_klass.bem_find_1(bevt_90_tmpvar_phold);
if (bevl_start == null) {
bevt_91_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_91_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevt_93_tmpvar_phold = bevo_29;
if (bevl_start.bevi_int > bevt_93_tmpvar_phold.bevi_int) {
bevt_92_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevt_8_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 185 */ {
bevt_8_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 185 */
 else  /* Line: 185 */ {
bevt_8_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 185 */ {
bevt_94_tmpvar_phold = bevo_30;
bevt_96_tmpvar_phold = bevo_31;
bevt_95_tmpvar_phold = bevl_start.bem_add_1(bevt_96_tmpvar_phold);
bevl_end = bevl_klass.bem_find_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
if (bevl_end == null) {
bevt_97_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_97_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 187 */ {
bevt_99_tmpvar_phold = bevo_32;
if (bevl_end.bevi_int > bevt_99_tmpvar_phold.bevi_int) {
bevt_98_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpvar_phold.bevi_bool) /* Line: 187 */ {
bevt_9_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 187 */ {
bevt_9_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 187 */
 else  /* Line: 187 */ {
bevt_9_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 187 */ {
bevt_101_tmpvar_phold = bevo_33;
bevt_100_tmpvar_phold = bevl_start.bem_add_1(bevt_101_tmpvar_phold);
bevl_libLens = bevl_klass.bem_substring_2(bevt_100_tmpvar_phold, bevl_end);
bevl_libLen = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_libLens);
bevt_104_tmpvar_phold = bevo_34;
bevt_103_tmpvar_phold = bevl_start.bem_add_1(bevt_104_tmpvar_phold);
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_add_1(bevl_libLen);
bevl_klass = bevl_klass.bem_substring_1(bevt_102_tmpvar_phold);
bevl_klass = this.bem_extractKlass_1(bevl_klass);
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_106_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_105_tmpvar_phold = this.bem_getSourceFileName_1(bevt_106_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_105_tmpvar_phold);
this.bem_addFrame_1(bevl_fr);
} /* Line: 197 */
} /* Line: 187 */
} /* Line: 185 */
} /* Line: 179 */
} /* Line: 161 */
} /* Line: 160 */
} /* Line: 95 */
 else  /* Line: 90 */ {
break;
} /* Line: 90 */
} /* Line: 90 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bels_29));
bevp_framesText = null;
} /* Line: 207 */
 else  /* Line: 82 */ {
if (bevp_frames == null) {
bevt_107_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 208 */ {
if (bevp_lang == null) {
bevt_108_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_11_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_11_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 208 */
 else  /* Line: 208 */ {
bevt_11_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 208 */ {
bevt_110_tmpvar_phold = bevo_35;
bevt_109_tmpvar_phold = bevp_lang.bem_equals_1(bevt_110_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_10_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 208 */ {
bevt_10_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 208 */
 else  /* Line: 208 */ {
bevt_10_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 208 */ {
bevt_1_tmpvar_loop = bevp_frames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 209 */ {
bevt_111_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_111_tmpvar_phold != null && bevt_111_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_111_tmpvar_phold).bevi_bool) /* Line: 209 */ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_tmpvar_loop.bem_nextGet_0();
bevt_113_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_112_tmpvar_phold = this.bem_extractKlassLib_1(bevt_113_tmpvar_phold);
bevl_fr.bem_klassNameSet_1(bevt_112_tmpvar_phold);
bevt_115_tmpvar_phold = bevl_fr.bem_methodNameGet_0();
bevt_114_tmpvar_phold = this.bem_extractMethod_1(bevt_115_tmpvar_phold);
bevl_fr.bem_methodNameSet_1(bevt_114_tmpvar_phold);
bevt_117_tmpvar_phold = bevl_fr.bem_klassNameGet_0();
bevt_116_tmpvar_phold = this.bem_getSourceFileName_1(bevt_117_tmpvar_phold);
bevl_fr.bem_fileNameSet_1(bevt_116_tmpvar_phold);
 /* Line: 213 */ {
bevl_fr.bem_extractLine_0();
} /* Line: 214 */
} /* Line: 213 */
 else  /* Line: 209 */ {
break;
} /* Line: 209 */
} /* Line: 209 */
bevp_emitLang = bevp_lang;
bevp_lang = (new BEC_2_4_6_TextString(2, bels_31));
} /* Line: 218 */
 else  /* Line: 219 */ {
} /* Line: 219 */
} /* Line: 82 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
bevl_i = this.bem_createInstance_2(beva_klassName, bevt_0_tmpvar_phold);
if (bevl_i == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_2_tmpvar_phold = bevl_i.bemd_0(478622533, BEL_4_Base.bevn_sourceFileNameGet_0);
return (BEC_2_4_6_TextString) bevt_2_tmpvar_phold;
} /* Line: 229 */
return null;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_32));
bevl_parts = beva_callPart.bem_split_1(bevt_0_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_2_tmpvar_phold = bevl_parts.bem_get_1(bevt_3_tmpvar_phold);
bevt_1_tmpvar_phold = this.bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_tmpvar_phold);
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
try  /* Line: 243 */ {
bevt_0_tmpvar_phold = this.bem_extractKlassInner_1(beva_klass);
return bevt_0_tmpvar_phold;
} /* Line: 244 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 245 */
return beva_klass;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
if (beva_klass == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 252 */ {
bevt_4_tmpvar_phold = bevo_36;
bevt_3_tmpvar_phold = beva_klass.bem_begins_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 252 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 252 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 252 */ {
return beva_klass;
} /* Line: 253 */
bevt_6_tmpvar_phold = (new BEC_2_4_3_MathInt(6));
bevt_5_tmpvar_phold = beva_klass.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_34));
bevl_kparts = bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_kparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_37;
bevl_kps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 260 */ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevt_11_tmpvar_phold = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevl_sofar.bem_add_1(bevl_len);
bevt_12_tmpvar_phold = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_tmpvar_phold);
bevl_bec.bem_addValue_1(bevt_12_tmpvar_phold);
bevt_16_tmpvar_phold = bevo_38;
bevt_15_tmpvar_phold = bevl_i.bem_add_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_int < bevl_kps.bevi_int) {
bevt_14_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_17_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_35));
bevl_bec.bem_addValue_1(bevt_17_tmpvar_phold);
} /* Line: 264 */
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 260 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
return bevl_bec;
} /*method end*/
public BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
if (beva_mtd == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_4_tmpvar_phold = bevo_39;
bevt_3_tmpvar_phold = beva_mtd.bem_begins_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
return beva_mtd;
} /* Line: 273 */
bevt_6_tmpvar_phold = (new BEC_2_4_3_MathInt(4));
bevt_5_tmpvar_phold = beva_mtd.bem_substring_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_37));
bevl_mparts = bevt_5_tmpvar_phold.bem_split_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_mparts.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevo_40;
bevl_mps = bevt_8_tmpvar_phold.bem_subtract_1(bevt_9_tmpvar_phold);
bevl_bem = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 278 */ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_11_tmpvar_phold = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_41;
bevt_13_tmpvar_phold = bevl_i.bem_add_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_int < bevl_mps.bevi_int) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_38));
bevl_bem.bem_addValue_1(bevt_15_tmpvar_phold);
} /* Line: 280 */
bevl_i.bevi_int++;
} /* Line: 278 */
 else  /* Line: 278 */ {
break;
} /* Line: 278 */
} /* Line: 278 */
return bevl_bem;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGet_0() throws Throwable {
this.bem_translateEmittedException_0();
return bevp_frames;
} /*method end*/
public BEC_2_4_6_TextString bem_getFrameText_0() throws Throwable {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
this.bem_translateEmittedException_0();
bevl_toRet = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = this.bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_2_tmpvar_phold = bevo_42;
bevl_toRet = bevl_toRet.bem_add_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 299 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 299 */ {
bevl_ft = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 300 */
 else  /* Line: 299 */ {
break;
} /* Line: 299 */
} /* Line: 299 */
} /* Line: 299 */
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGet_0() throws Throwable {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_frames == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevp_frames = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 312 */
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) throws Throwable {
BEC_2_9_5_ExceptionFrame bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
this.bem_addFrame_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGet_0() throws Throwable {
return bevp_methodName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_methodName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_klassName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGet_0() throws Throwable {
return bevp_description;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_description = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGet_0() throws Throwable {
return bevp_fileName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fileName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGet_0() throws Throwable {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lineNumber = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_langGet_0() throws Throwable {
return bevp_lang;
} /*method end*/
public BEC_2_6_6_SystemObject bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGet_0() throws Throwable {
return bevp_emitLang;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGet_0() throws Throwable {
return bevp_framesText;
} /*method end*/
public BEC_2_6_6_SystemObject bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGet_0() throws Throwable {
return bevp_translated;
} /*method end*/
public BEC_2_6_6_SystemObject bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {28, 32, 35, 36, 36, 37, 37, 37, 39, 39, 40, 40, 40, 42, 42, 43, 43, 43, 45, 45, 46, 46, 46, 48, 48, 49, 49, 49, 51, 51, 52, 52, 52, 54, 54, 55, 55, 55, 55, 57, 57, 58, 58, 58, 60, 60, 61, 61, 63, 68, 70, 70, 78, 78, 0, 0, 0, 79, 81, 82, 82, 82, 82, 0, 0, 0, 82, 82, 0, 82, 82, 0, 0, 0, 0, 0, 83, 83, 84, 85, 85, 86, 88, 90, 0, 90, 90, 92, 92, 93, 94, 95, 95, 95, 95, 95, 0, 0, 0, 97, 97, 97, 97, 98, 98, 98, 98, 0, 0, 0, 100, 100, 100, 103, 103, 104, 104, 106, 106, 106, 107, 107, 108, 108, 108, 108, 111, 111, 112, 112, 113, 113, 115, 115, 115, 116, 116, 117, 117, 120, 121, 126, 126, 127, 127, 130, 130, 130, 130, 131, 131, 133, 133, 133, 135, 135, 136, 136, 137, 137, 139, 139, 140, 140, 141, 141, 143, 143, 143, 145, 146, 153, 153, 153, 153, 154, 154, 154, 154, 0, 0, 0, 155, 155, 155, 157, 157, 157, 160, 160, 163, 163, 165, 165, 166, 166, 168, 170, 172, 173, 173, 173, 174, 178, 178, 179, 179, 179, 179, 180, 180, 181, 183, 183, 184, 184, 185, 185, 185, 185, 185, 0, 0, 0, 186, 186, 186, 186, 187, 187, 187, 187, 187, 0, 0, 0, 188, 188, 188, 190, 191, 191, 191, 191, 193, 195, 196, 196, 196, 197, 205, 206, 207, 208, 208, 208, 208, 0, 0, 0, 208, 208, 0, 0, 0, 209, 0, 209, 209, 210, 210, 210, 211, 211, 211, 212, 212, 212, 214, 217, 218, 226, 226, 227, 227, 229, 229, 232, 237, 237, 239, 239, 239, 239, 244, 244, 248, 252, 252, 0, 252, 252, 252, 252, 0, 0, 253, 255, 255, 255, 255, 256, 256, 256, 257, 258, 259, 260, 260, 260, 261, 261, 263, 263, 263, 264, 264, 264, 264, 264, 264, 265, 260, 268, 272, 272, 0, 272, 272, 272, 272, 0, 0, 273, 275, 275, 275, 275, 276, 276, 276, 277, 278, 278, 278, 279, 279, 280, 280, 280, 280, 280, 280, 278, 283, 289, 290, 294, 295, 296, 297, 297, 298, 298, 299, 0, 299, 299, 300, 303, 307, 311, 311, 312, 314, 318, 318, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {102, 134, 135, 136, 141, 142, 143, 144, 146, 151, 152, 153, 154, 156, 161, 162, 163, 164, 166, 171, 172, 173, 174, 176, 181, 182, 183, 184, 186, 191, 192, 193, 194, 196, 201, 202, 203, 204, 205, 207, 212, 213, 214, 215, 217, 222, 223, 224, 226, 232, 236, 237, 378, 383, 385, 388, 392, 395, 397, 398, 403, 404, 409, 410, 413, 417, 420, 421, 423, 426, 427, 429, 432, 436, 439, 443, 446, 447, 448, 449, 450, 452, 455, 457, 457, 460, 462, 463, 464, 465, 466, 467, 472, 473, 474, 479, 480, 483, 487, 490, 491, 492, 493, 494, 499, 500, 505, 506, 509, 513, 516, 517, 518, 520, 521, 522, 527, 528, 529, 530, 531, 532, 534, 535, 536, 537, 539, 540, 541, 546, 547, 548, 549, 550, 551, 552, 553, 555, 556, 558, 560, 566, 567, 568, 573, 574, 575, 576, 577, 578, 583, 584, 585, 586, 587, 588, 589, 594, 595, 596, 597, 598, 599, 604, 605, 606, 608, 609, 610, 611, 613, 621, 622, 623, 624, 625, 630, 631, 636, 637, 640, 644, 647, 648, 649, 652, 653, 654, 657, 662, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 679, 680, 681, 682, 683, 688, 689, 690, 691, 692, 693, 694, 695, 696, 701, 702, 703, 708, 709, 712, 716, 719, 720, 721, 722, 723, 728, 729, 730, 735, 736, 739, 743, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 771, 772, 773, 776, 781, 782, 787, 788, 791, 795, 798, 799, 801, 804, 808, 811, 811, 814, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 827, 834, 835, 847, 848, 849, 854, 855, 856, 858, 866, 867, 868, 869, 870, 871, 877, 878, 883, 911, 916, 917, 920, 921, 922, 927, 928, 931, 935, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 950, 955, 956, 957, 958, 959, 960, 961, 962, 963, 968, 969, 970, 972, 973, 979, 1002, 1007, 1008, 1011, 1012, 1013, 1018, 1019, 1022, 1026, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1039, 1044, 1045, 1046, 1047, 1048, 1049, 1054, 1055, 1056, 1058, 1064, 1067, 1068, 1078, 1079, 1080, 1081, 1086, 1087, 1088, 1089, 1089, 1092, 1094, 1095, 1102, 1105, 1109, 1114, 1115, 1117, 1122, 1123, 1127, 1130, 1134, 1138, 1141, 1145, 1148, 1152, 1155, 1159, 1162, 1166, 1169, 1173, 1177, 1180, 1184, 1187};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 28 102
translateEmittedException 0 32 134
assign 1 35 135
new 0 35 135
assign 1 36 136
def 1 36 141
assign 1 37 142
new 0 37 142
assign 1 37 143
add 1 37 143
assign 1 37 144
add 1 37 144
assign 1 39 146
def 1 39 151
assign 1 40 152
new 0 40 152
assign 1 40 153
add 1 40 153
assign 1 40 154
add 1 40 154
assign 1 42 156
def 1 42 161
assign 1 43 162
new 0 43 162
assign 1 43 163
add 1 43 163
assign 1 43 164
add 1 43 164
assign 1 45 166
def 1 45 171
assign 1 46 172
new 0 46 172
assign 1 46 173
add 1 46 173
assign 1 46 174
add 1 46 174
assign 1 48 176
def 1 48 181
assign 1 49 182
new 0 49 182
assign 1 49 183
add 1 49 183
assign 1 49 184
add 1 49 184
assign 1 51 186
def 1 51 191
assign 1 52 192
new 0 52 192
assign 1 52 193
add 1 52 193
assign 1 52 194
add 1 52 194
assign 1 54 196
def 1 54 201
assign 1 55 202
new 0 55 202
assign 1 55 203
add 1 55 203
assign 1 55 204
toString 0 55 204
assign 1 55 205
add 1 55 205
assign 1 57 207
def 1 57 212
assign 1 58 213
new 0 58 213
assign 1 58 214
add 1 58 214
assign 1 58 215
add 1 58 215
assign 1 60 217
def 1 60 222
assign 1 61 223
getFrameText 0 61 223
assign 1 61 224
add 1 61 224
return 1 63 226
translateEmittedExceptionInner 0 68 232
assign 1 70 236
new 0 70 236
print 0 70 237
assign 1 78 378
def 1 78 383
assign 1 0 385
assign 1 0 388
assign 1 0 392
return 1 79 395
assign 1 81 397
new 0 81 397
assign 1 82 398
def 1 82 403
assign 1 82 404
def 1 82 409
assign 1 0 410
assign 1 0 413
assign 1 0 417
assign 1 82 420
new 0 82 420
assign 1 82 421
equals 1 82 421
assign 1 0 423
assign 1 82 426
new 0 82 426
assign 1 82 427
equals 1 82 427
assign 1 0 429
assign 1 0 432
assign 1 0 436
assign 1 0 439
assign 1 0 443
assign 1 83 446
new 0 83 446
assign 1 83 447
new 1 83 447
assign 1 84 448
tokenize 1 84 448
assign 1 85 449
new 0 85 449
assign 1 85 450
equals 1 85 450
assign 1 86 452
new 0 86 452
assign 1 88 455
new 0 88 455
assign 1 90 457
linkedListIteratorGet 0 0 457
assign 1 90 460
hasNextGet 0 90 460
assign 1 90 462
nextGet 0 90 462
assign 1 92 463
new 0 92 463
assign 1 92 464
find 1 92 464
assign 1 93 465
assign 1 94 466
assign 1 95 467
def 1 95 472
assign 1 95 473
new 0 95 473
assign 1 95 474
greaterEquals 1 95 479
assign 1 0 480
assign 1 0 483
assign 1 0 487
assign 1 97 490
new 0 97 490
assign 1 97 491
new 0 97 491
assign 1 97 492
add 1 97 492
assign 1 97 493
find 2 97 493
assign 1 98 494
def 1 98 499
assign 1 98 500
greater 1 98 505
assign 1 0 506
assign 1 0 509
assign 1 0 513
assign 1 100 516
new 0 100 516
assign 1 100 517
add 1 100 517
assign 1 100 518
substring 2 100 518
assign 1 103 520
new 0 103 520
assign 1 103 521
find 2 103 521
assign 1 104 522
def 1 104 527
assign 1 106 528
new 0 106 528
assign 1 106 529
add 1 106 529
assign 1 106 530
substring 1 106 530
assign 1 107 531
new 0 107 531
assign 1 107 532
ends 1 107 532
assign 1 108 534
sizeGet 0 108 534
assign 1 108 535
new 0 108 535
assign 1 108 536
subtract 1 108 536
sizeSet 1 108 537
assign 1 111 539
new 0 111 539
assign 1 111 540
rfind 1 111 540
assign 1 112 541
def 1 112 546
assign 1 113 547
new 0 113 547
assign 1 113 548
substring 2 113 548
assign 1 115 549
new 0 115 549
assign 1 115 550
add 1 115 550
assign 1 115 551
substring 1 115 551
assign 1 116 552
new 0 116 552
assign 1 116 553
begins 1 116 553
assign 1 117 555
new 0 117 555
assign 1 117 556
substring 1 117 556
assign 1 120 558
isInteger 0 120 558
assign 1 121 560
new 1 121 560
assign 1 126 566
new 0 126 566
assign 1 126 567
find 2 126 567
assign 1 127 568
def 1 127 573
assign 1 130 574
new 0 130 574
assign 1 130 575
new 0 130 575
assign 1 130 576
add 1 130 576
assign 1 130 577
find 2 130 577
assign 1 131 578
def 1 131 583
assign 1 133 584
new 0 133 584
assign 1 133 585
add 1 133 585
assign 1 133 586
substring 2 133 586
assign 1 135 587
new 0 135 587
assign 1 135 588
rfind 1 135 588
assign 1 136 589
def 1 136 594
assign 1 137 595
new 0 137 595
assign 1 137 596
substring 2 137 596
assign 1 139 597
new 0 139 597
assign 1 139 598
rfind 1 139 598
assign 1 140 599
def 1 140 604
assign 1 141 605
new 0 141 605
assign 1 141 606
substring 2 141 606
assign 1 143 608
new 0 143 608
assign 1 143 609
add 1 143 609
assign 1 143 610
substring 1 143 610
assign 1 145 611
isInteger 0 145 611
assign 1 146 613
new 1 146 613
assign 1 153 621
new 0 153 621
assign 1 153 622
new 0 153 622
assign 1 153 623
add 1 153 623
assign 1 153 624
find 2 153 624
assign 1 154 625
def 1 154 630
assign 1 154 631
greater 1 154 636
assign 1 0 637
assign 1 0 640
assign 1 0 644
assign 1 155 647
new 0 155 647
assign 1 155 648
add 1 155 648
assign 1 155 649
substring 2 155 649
assign 1 157 652
new 0 157 652
assign 1 157 653
add 1 157 653
assign 1 157 654
substring 1 157 654
assign 1 160 657
def 1 160 662
assign 1 163 664
new 0 163 664
assign 1 163 665
split 1 163 665
assign 1 165 666
new 0 165 666
assign 1 165 667
get 1 165 667
assign 1 166 668
new 0 166 668
assign 1 166 669
get 1 166 669
assign 1 168 670
extractKlass 1 168 670
assign 1 170 671
extractMethod 1 170 671
assign 1 172 672
new 4 172 672
assign 1 173 673
klassNameGet 0 173 673
assign 1 173 674
getSourceFileName 1 173 674
fileNameSet 1 173 675
addFrame 1 174 676
assign 1 178 679
new 0 178 679
assign 1 178 680
split 1 178 680
assign 1 179 681
sizeGet 0 179 681
assign 1 179 682
new 0 179 682
assign 1 179 683
greater 1 179 688
assign 1 180 689
new 0 180 689
assign 1 180 690
get 1 180 690
assign 1 181 691
extractMethod 1 181 691
assign 1 183 692
new 0 183 692
assign 1 183 693
get 1 183 693
assign 1 184 694
new 0 184 694
assign 1 184 695
find 1 184 695
assign 1 185 696
def 1 185 701
assign 1 185 702
new 0 185 702
assign 1 185 703
greater 1 185 708
assign 1 0 709
assign 1 0 712
assign 1 0 716
assign 1 186 719
new 0 186 719
assign 1 186 720
new 0 186 720
assign 1 186 721
add 1 186 721
assign 1 186 722
find 2 186 722
assign 1 187 723
def 1 187 728
assign 1 187 729
new 0 187 729
assign 1 187 730
greater 1 187 735
assign 1 0 736
assign 1 0 739
assign 1 0 743
assign 1 188 746
new 0 188 746
assign 1 188 747
add 1 188 747
assign 1 188 748
substring 2 188 748
assign 1 190 749
new 1 190 749
assign 1 191 750
new 0 191 750
assign 1 191 751
add 1 191 751
assign 1 191 752
add 1 191 752
assign 1 191 753
substring 1 191 753
assign 1 193 754
extractKlass 1 193 754
assign 1 195 755
new 4 195 755
assign 1 196 756
klassNameGet 0 196 756
assign 1 196 757
getSourceFileName 1 196 757
fileNameSet 1 196 758
addFrame 1 197 759
assign 1 205 771
assign 1 206 772
new 0 206 772
assign 1 207 773
assign 1 208 776
def 1 208 781
assign 1 208 782
def 1 208 787
assign 1 0 788
assign 1 0 791
assign 1 0 795
assign 1 208 798
new 0 208 798
assign 1 208 799
equals 1 208 799
assign 1 0 801
assign 1 0 804
assign 1 0 808
assign 1 209 811
linkedListIteratorGet 0 0 811
assign 1 209 814
hasNextGet 0 209 814
assign 1 209 816
nextGet 0 209 816
assign 1 210 817
klassNameGet 0 210 817
assign 1 210 818
extractKlassLib 1 210 818
klassNameSet 1 210 819
assign 1 211 820
methodNameGet 0 211 820
assign 1 211 821
extractMethod 1 211 821
methodNameSet 1 211 822
assign 1 212 823
klassNameGet 0 212 823
assign 1 212 824
getSourceFileName 1 212 824
fileNameSet 1 212 825
extractLine 0 214 827
assign 1 217 834
assign 1 218 835
new 0 218 835
assign 1 226 847
new 0 226 847
assign 1 226 848
createInstance 2 226 848
assign 1 227 849
def 1 227 854
assign 1 229 855
sourceFileNameGet 0 229 855
return 1 229 856
return 1 232 858
assign 1 237 866
new 0 237 866
assign 1 237 867
split 1 237 867
assign 1 239 868
new 0 239 868
assign 1 239 869
get 1 239 869
assign 1 239 870
extractKlass 1 239 870
return 1 239 871
assign 1 244 877
extractKlassInner 1 244 877
return 1 244 878
return 1 248 883
assign 1 252 911
undef 1 252 916
assign 1 0 917
assign 1 252 920
new 0 252 920
assign 1 252 921
begins 1 252 921
assign 1 252 922
not 0 252 927
assign 1 0 928
assign 1 0 931
return 1 253 935
assign 1 255 937
new 0 255 937
assign 1 255 938
substring 1 255 938
assign 1 255 939
new 0 255 939
assign 1 255 940
split 1 255 940
assign 1 256 941
sizeGet 0 256 941
assign 1 256 942
new 0 256 942
assign 1 256 943
subtract 1 256 943
assign 1 257 944
get 1 257 944
assign 1 258 945
new 0 258 945
assign 1 259 946
new 0 259 946
assign 1 260 947
new 0 260 947
assign 1 260 950
lesser 1 260 955
assign 1 261 956
get 1 261 956
assign 1 261 957
new 1 261 957
assign 1 263 958
add 1 263 958
assign 1 263 959
substring 2 263 959
addValue 1 263 960
assign 1 264 961
new 0 264 961
assign 1 264 962
add 1 264 962
assign 1 264 963
lesser 1 264 968
assign 1 264 969
new 0 264 969
addValue 1 264 970
addValue 1 265 972
incrementValue 0 260 973
return 1 268 979
assign 1 272 1002
undef 1 272 1007
assign 1 0 1008
assign 1 272 1011
new 0 272 1011
assign 1 272 1012
begins 1 272 1012
assign 1 272 1013
not 0 272 1018
assign 1 0 1019
assign 1 0 1022
return 1 273 1026
assign 1 275 1028
new 0 275 1028
assign 1 275 1029
substring 1 275 1029
assign 1 275 1030
new 0 275 1030
assign 1 275 1031
split 1 275 1031
assign 1 276 1032
sizeGet 0 276 1032
assign 1 276 1033
new 0 276 1033
assign 1 276 1034
subtract 1 276 1034
assign 1 277 1035
new 0 277 1035
assign 1 278 1036
new 0 278 1036
assign 1 278 1039
lesser 1 278 1044
assign 1 279 1045
get 1 279 1045
addValue 1 279 1046
assign 1 280 1047
new 0 280 1047
assign 1 280 1048
add 1 280 1048
assign 1 280 1049
lesser 1 280 1054
assign 1 280 1055
new 0 280 1055
addValue 1 280 1056
incrementValue 0 278 1058
return 1 283 1064
translateEmittedException 0 289 1067
return 1 290 1068
translateEmittedException 0 294 1078
assign 1 295 1079
new 0 295 1079
assign 1 296 1080
framesGet 0 296 1080
assign 1 297 1081
def 1 297 1086
assign 1 298 1087
new 0 298 1087
assign 1 298 1088
add 1 298 1088
assign 1 299 1089
linkedListIteratorGet 0 0 1089
assign 1 299 1092
hasNextGet 0 299 1092
assign 1 299 1094
nextGet 0 299 1094
assign 1 300 1095
add 1 300 1095
return 1 303 1102
return 1 307 1105
assign 1 311 1109
undef 1 311 1114
assign 1 312 1115
new 0 312 1115
addValue 1 314 1117
assign 1 318 1122
new 4 318 1122
addFrame 1 318 1123
return 1 0 1127
assign 1 0 1130
assign 1 0 1134
return 1 0 1138
assign 1 0 1141
return 1 0 1145
assign 1 0 1148
return 1 0 1152
assign 1 0 1155
return 1 0 1159
assign 1 0 1162
return 1 0 1166
assign 1 0 1169
assign 1 0 1173
return 1 0 1177
assign 1 0 1180
return 1 0 1184
assign 1 0 1187
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1353219100: return bem_klassNameGet_0();
case 1774940957: return bem_toString_0();
case -1354714650: return bem_copy_0();
case 734830721: return bem_framesGet_0();
case 1475977273: return bem_langGet_0();
case -1308786538: return bem_echo_0();
case 1307921883: return bem_methodNameGet_0();
case -1184167343: return bem_translatedGet_0();
case -764669899: return bem_getFrameText_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -786424307: return bem_tagGet_0();
case 104713553: return bem_new_0();
case 484558571: return bem_descriptionGet_0();
case -1611190486: return bem_lineNumberGet_0();
case 556476320: return bem_fileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1012494862: return bem_once_0();
case 287040793: return bem_hashGet_0();
case 154290862: return bem_translateEmittedException_0();
case -1081412016: return bem_many_0();
case 443668840: return bem_methodNotDefined_0();
case 970476426: return bem_translateEmittedExceptionInner_0();
case 1102720804: return bem_classNameGet_0();
case 2055025483: return bem_serializeContents_0();
case -845792839: return bem_iteratorGet_0();
case -1141730732: return bem_framesTextGet_0();
case -314718434: return bem_print_0();
case -220901978: return bem_emitLangGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -1286797640: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1600108233: return bem_lineNumberSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 495640824: return bem_descriptionSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 567558573: return bem_fileNameSet_1(bevd_0);
case 2124977673: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1364301353: return bem_klassNameSet_1(bevd_0);
case 745912974: return bem_framesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1487059526: return bem_langSet_1(bevd_0);
case -813541388: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1173085090: return bem_translatedSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -205231606: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1319004136: return bem_methodNameSet_1(bevd_0);
case 1300981246: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -371136143: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1130648479: return bem_framesTextSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1300981249: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_9_SystemException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_9_SystemException.bevs_inst = (BEC_2_6_9_SystemException)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_9_SystemException.bevs_inst;
}
}
