package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet extends BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_9_3_ContainerSet bevs_inst;
public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public BEC_2_9_3_ContainerSet bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(11));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 237 */
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 244 */
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) throws Throwable {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 262 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevt_4_tmpvar_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpvar_phold = this.bem_innerPut_4(bevt_4_tmpvar_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 265 */ {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 266 */
} /* Line: 265 */
} /* Line: 264 */
 else  /* Line: 262 */ {
break;
} /* Line: 262 */
} /* Line: 262 */
bevt_6_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpvar_phold = bevo_2;
bevl_nslots = bevt_0_tmpvar_phold.bem_add_1(bevt_2_tmpvar_phold);
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 277 */ {
bevt_4_tmpvar_phold = this.bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 277 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 279 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
return bevl_ninner;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (beva_other == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 285 */ {
bevt_4_tmpvar_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpvar_phold = this.bem_sizeGet_0();
if (bevt_4_tmpvar_phold.bevi_int != bevt_5_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 285 */ {
bevt_1_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 285 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 285 */ {
bevt_6_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 286 */
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 288 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 288 */ {
bevl_i = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_other.bem_has_1(bevl_i);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_10_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /* Line: 289 */
} /* Line: 289 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
bevt_11_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) throws Throwable {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 298 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 299 */
} /* Line: 298 */
 else  /* Line: 301 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(-449328306, BEL_4_Base.bevn_hvalGet_0);
} /* Line: 302 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 306 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 308 */ {
if (beva_inode == null) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 309 */ {
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpvar_phold);
} /* Line: 310 */
 else  /* Line: 311 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 312 */
bevp_innerPutAdded = be.BECS_Runtime.boolTrue;
bevt_7_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 315 */
 else  /* Line: 308 */ {
bevt_10_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 316 */ {
bevt_11_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /* Line: 317 */
 else  /* Line: 308 */ {
bevt_13_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpvar_phold, beva_k);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 318 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = be.BECS_Runtime.boolFalse;
bevt_14_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_14_tmpvar_phold;
} /* Line: 322 */
 else  /* Line: 323 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 325 */ {
bevt_16_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_16_tmpvar_phold;
} /* Line: 326 */
} /* Line: 325 */
} /* Line: 308 */
} /* Line: 308 */
} /* Line: 308 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 333 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
while (true)
 /* Line: 336 */ {
bevt_3_tmpvar_phold = this.bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 336 */ {
bevl_slt = (BEC_2_9_4_ContainerList) this.bem_rehash_1(bevl_slt);
} /* Line: 337 */
 else  /* Line: 336 */ {
break;
} /* Line: 336 */
} /* Line: 336 */
bevp_slots = bevl_slt;
} /* Line: 339 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 341 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 342 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 351 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 355 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 357 */ {
return null;
} /* Line: 358 */
 else  /* Line: 357 */ {
bevt_5_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 359 */ {
return null;
} /* Line: 360 */
 else  /* Line: 357 */ {
bevt_7_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpvar_phold, beva_k);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 361 */ {
bevt_8_tmpvar_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpvar_phold;
} /* Line: 362 */
 else  /* Line: 363 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 365 */ {
return null;
} /* Line: 366 */
} /* Line: 365 */
} /* Line: 357 */
} /* Line: 357 */
} /* Line: 357 */
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpvar_phold = bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 377 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 381 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 383 */ {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /* Line: 384 */
 else  /* Line: 383 */ {
bevt_6_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevt_7_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /* Line: 386 */
 else  /* Line: 383 */ {
bevt_9_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpvar_phold, beva_k);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 387 */ {
bevt_10_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 388 */
 else  /* Line: 389 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /* Line: 392 */
} /* Line: 391 */
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 383 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpvar_phold = bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 404 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 408 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 410 */ {
bevt_4_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 411 */
 else  /* Line: 410 */ {
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 412 */ {
bevt_8_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 413 */
 else  /* Line: 410 */ {
bevt_10_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpvar_phold, beva_k);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 414 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 418 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 420 */ {
bevt_15_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpvar_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 420 */ {
bevt_0_tmpvar_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 420 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 420 */ {
bevt_16_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_16_tmpvar_phold;
} /* Line: 421 */
 else  /* Line: 422 */ {
bevt_18_tmpvar_phold = bevo_7;
bevt_17_tmpvar_phold = bevl_sl.bem_subtract_1(bevt_18_tmpvar_phold);
bevl_slt.bem_put_2(bevt_17_tmpvar_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 424 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 426 */
 else  /* Line: 418 */ {
break;
} /* Line: 418 */
} /* Line: 418 */
bevt_19_tmpvar_phold = be.BECS_Runtime.boolTrue;
return bevt_19_tmpvar_phold;
} /* Line: 428 */
 else  /* Line: 429 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 431 */ {
bevt_21_tmpvar_phold = be.BECS_Runtime.boolFalse;
return bevt_21_tmpvar_phold;
} /* Line: 432 */
} /* Line: 431 */
} /* Line: 410 */
} /* Line: 410 */
} /* Line: 410 */
} /*method end*/
public BEC_2_9_3_ContainerSet bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpvar_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
bevl_other = this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_slots.bem_copy_0();
bevl_other.bemd_1(365988447, BEL_4_Base.bevn_slotsSet_1, bevt_0_tmpvar_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 442 */ {
bevt_2_tmpvar_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 444 */ {
bevt_4_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_6_tmpvar_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpvar_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpvar_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpvar_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_new_3(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_4_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_5_tmpvar_phold);
} /* Line: 445 */
 else  /* Line: 446 */ {
bevt_10_tmpvar_phold = bevl_other.bemd_0(354906194, BEL_4_Base.bevn_slotsGet_0);
bevt_10_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, null);
} /* Line: 447 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 442 */
 else  /* Line: 442 */ {
break;
} /* Line: 442 */
} /* Line: 442 */
return (BEC_2_9_3_ContainerSet) bevl_other;
} /*method end*/
public BEC_2_6_6_SystemObject bem_clear_0() throws Throwable {
bevp_slots.bem_clear_0();
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() throws Throwable {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_keyIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_nodeIteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 485 */ {
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 486 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 486 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_3_tmpvar_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 487 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 488 */
} /* Line: 487 */
 else  /* Line: 486 */ {
break;
} /* Line: 486 */
} /* Line: 486 */
} /* Line: 486 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_i = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = this.bem_setIteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 497 */ {
bevl_x = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 498 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
if (beva_other == null) {
bevt_3_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 500 */ {
bevt_1_tmpvar_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 501 */ {
bevt_4_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 501 */ {
bevl_x = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 502 */
 else  /* Line: 501 */ {
break;
} /* Line: 501 */
} /* Line: 501 */
} /* Line: 501 */
return bevl_i;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) throws Throwable {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = this.bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
if (beva_other == null) {
bevt_1_tmpvar_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_2_tmpvar_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 516 */ {
bevt_0_tmpvar_loop = beva_other.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 517 */ {
bevt_3_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 517 */ {
bevl_x = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_put_1(bevl_x);
} /* Line: 518 */
 else  /* Line: 517 */ {
break;
} /* Line: 517 */
} /* Line: 517 */
} /* Line: 517 */
 else  /* Line: 516 */ {
bevt_4_tmpvar_phold = beva_other.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_baseNode);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 520 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_put_1(bevt_5_tmpvar_phold);
} /* Line: 521 */
 else  /* Line: 522 */ {
this.bem_put_1(beva_other);
} /* Line: 523 */
} /* Line: 516 */
} /* Line: 516 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGet_0() throws Throwable {
return bevp_slots;
} /*method end*/
public BEC_2_6_6_SystemObject bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGet_0() throws Throwable {
return bevp_modu;
} /*method end*/
public BEC_2_6_6_SystemObject bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGet_0() throws Throwable {
return bevp_multi;
} /*method end*/
public BEC_2_6_6_SystemObject bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() throws Throwable {
return bevp_rel;
} /*method end*/
public BEC_2_6_6_SystemObject bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() throws Throwable {
return bevp_baseNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() throws Throwable {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {218, 218, 224, 225, 226, 227, 228, 229, 230, 236, 236, 236, 237, 237, 239, 239, 243, 243, 243, 244, 244, 246, 246, 250, 250, 254, 254, 258, 258, 262, 262, 263, 264, 264, 265, 265, 265, 266, 266, 270, 270, 275, 275, 275, 275, 276, 277, 277, 278, 279, 281, 285, 285, 0, 285, 285, 285, 285, 0, 0, 286, 286, 288, 0, 288, 288, 289, 289, 289, 289, 289, 291, 291, 295, 296, 296, 297, 298, 298, 298, 299, 302, 304, 305, 307, 308, 308, 309, 309, 310, 310, 310, 312, 314, 315, 315, 316, 316, 316, 316, 317, 317, 318, 318, 319, 321, 322, 322, 324, 325, 325, 326, 326, 333, 333, 334, 335, 336, 336, 337, 339, 342, 347, 348, 349, 350, 350, 350, 351, 353, 354, 356, 357, 357, 358, 359, 359, 359, 359, 360, 361, 361, 362, 362, 364, 365, 365, 366, 373, 374, 375, 376, 376, 376, 377, 379, 380, 382, 383, 383, 384, 384, 385, 385, 385, 385, 386, 386, 387, 387, 388, 388, 390, 391, 391, 392, 392, 399, 400, 402, 403, 403, 403, 404, 406, 407, 409, 410, 410, 411, 411, 412, 412, 412, 412, 413, 413, 414, 414, 415, 416, 417, 418, 418, 419, 420, 420, 0, 420, 420, 420, 420, 0, 0, 421, 421, 423, 423, 423, 424, 426, 428, 428, 430, 431, 431, 432, 432, 439, 440, 441, 441, 442, 442, 442, 442, 443, 444, 444, 445, 445, 445, 445, 445, 445, 445, 447, 447, 442, 450, 455, 456, 460, 460, 464, 464, 468, 468, 472, 472, 476, 476, 480, 480, 484, 485, 485, 486, 0, 486, 486, 487, 488, 492, 496, 497, 0, 497, 497, 498, 500, 500, 501, 0, 501, 501, 502, 505, 509, 510, 511, 515, 515, 516, 517, 0, 517, 517, 518, 520, 521, 521, 523, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 26, 30, 31, 32, 33, 34, 35, 36, 44, 45, 50, 51, 52, 54, 55, 62, 63, 68, 69, 70, 72, 73, 77, 78, 82, 83, 88, 89, 101, 104, 106, 107, 112, 113, 114, 115, 117, 118, 126, 127, 137, 138, 139, 140, 141, 144, 145, 147, 148, 154, 170, 175, 176, 179, 180, 181, 186, 187, 190, 194, 195, 197, 197, 200, 202, 203, 204, 209, 210, 211, 218, 219, 244, 245, 250, 251, 252, 253, 258, 259, 263, 265, 266, 269, 270, 275, 276, 281, 282, 283, 284, 287, 289, 290, 291, 294, 295, 296, 301, 302, 303, 306, 307, 309, 310, 311, 312, 315, 316, 321, 322, 323, 336, 337, 339, 340, 343, 344, 346, 352, 355, 376, 377, 378, 379, 380, 385, 386, 388, 389, 392, 393, 398, 399, 402, 403, 404, 409, 410, 413, 414, 416, 417, 420, 421, 426, 427, 454, 455, 456, 457, 458, 463, 464, 466, 467, 470, 471, 476, 477, 478, 481, 482, 483, 488, 489, 490, 493, 494, 496, 497, 500, 501, 506, 507, 508, 544, 545, 546, 547, 548, 553, 554, 556, 557, 560, 561, 566, 567, 568, 571, 572, 573, 578, 579, 580, 583, 584, 586, 587, 588, 591, 596, 597, 598, 603, 604, 607, 608, 609, 614, 615, 618, 622, 623, 626, 627, 628, 629, 631, 637, 638, 641, 642, 647, 648, 649, 671, 672, 673, 674, 675, 678, 679, 684, 685, 686, 691, 692, 693, 694, 695, 696, 697, 698, 701, 702, 704, 710, 713, 714, 719, 720, 724, 725, 729, 730, 734, 735, 739, 740, 744, 745, 754, 755, 760, 761, 761, 764, 766, 767, 769, 777, 787, 788, 788, 791, 793, 794, 800, 805, 806, 806, 809, 811, 812, 819, 823, 824, 825, 835, 840, 841, 843, 843, 846, 848, 849, 857, 859, 860, 863, 870, 873, 877, 880, 884, 887, 891, 894, 898, 901, 905, 908, 912, 915};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 218 25
new 0 218 25
new 1 218 26
assign 1 224 30
new 1 224 30
assign 1 225 31
assign 1 226 32
new 0 226 32
assign 1 227 33
new 0 227 33
assign 1 228 34
new 0 228 34
assign 1 229 35
new 0 229 35
assign 1 230 36
new 0 230 36
assign 1 236 44
new 0 236 44
assign 1 236 45
equals 1 236 50
assign 1 237 51
new 0 237 51
return 1 237 52
assign 1 239 54
new 0 239 54
return 1 239 55
assign 1 243 62
new 0 243 62
assign 1 243 63
equals 1 243 68
assign 1 244 69
new 0 244 69
return 1 244 70
assign 1 246 72
new 0 246 72
return 1 246 73
assign 1 250 77
toString 0 250 77
return 1 250 78
assign 1 254 82
new 1 254 82
new 1 254 83
assign 1 258 88
new 1 258 88
return 1 258 89
assign 1 262 101
arrayIteratorGet 0 262 101
assign 1 262 104
hasNextGet 0 262 104
assign 1 263 106
nextGet 0 263 106
assign 1 264 107
def 1 264 112
assign 1 265 113
keyGet 0 265 113
assign 1 265 114
innerPut 4 265 114
assign 1 265 115
not 0 265 115
assign 1 266 117
new 0 266 117
return 1 266 118
assign 1 270 126
new 0 270 126
return 1 270 127
assign 1 275 137
sizeGet 0 275 137
assign 1 275 138
multiply 1 275 138
assign 1 275 139
new 0 275 139
assign 1 275 140
add 1 275 140
assign 1 276 141
new 1 276 141
assign 1 277 144
insertAll 2 277 144
assign 1 277 145
not 0 277 145
assign 1 278 147
increment 0 278 147
assign 1 279 148
new 1 279 148
return 1 281 154
assign 1 285 170
undef 1 285 175
assign 1 0 176
assign 1 285 179
sizeGet 0 285 179
assign 1 285 180
sizeGet 0 285 180
assign 1 285 181
notEquals 1 285 186
assign 1 0 187
assign 1 0 190
assign 1 286 194
new 0 286 194
return 1 286 195
assign 1 288 197
setIteratorGet 0 0 197
assign 1 288 200
hasNextGet 0 288 200
assign 1 288 202
nextGet 0 288 202
assign 1 289 203
has 1 289 203
assign 1 289 204
not 0 289 209
assign 1 289 210
new 0 289 210
return 1 289 211
assign 1 291 218
new 0 291 218
return 1 291 219
assign 1 295 244
sizeGet 0 295 244
assign 1 296 245
undef 1 296 250
assign 1 297 251
getHash 1 297 251
assign 1 298 252
new 0 298 252
assign 1 298 253
lesser 1 298 258
assign 1 299 259
abs 0 299 259
assign 1 302 263
hvalGet 0 302 263
assign 1 304 265
modulus 1 304 265
assign 1 305 266
assign 1 307 269
get 1 307 269
assign 1 308 270
undef 1 308 275
assign 1 309 276
undef 1 309 281
assign 1 310 282
create 0 310 282
assign 1 310 283
new 3 310 283
put 2 310 284
put 2 312 287
assign 1 314 289
new 0 314 289
assign 1 315 290
new 0 315 290
return 1 315 291
assign 1 316 294
hvalGet 0 316 294
assign 1 316 295
modulus 1 316 295
assign 1 316 296
notEquals 1 316 301
assign 1 317 302
new 0 317 302
return 1 317 303
assign 1 318 306
keyGet 0 318 306
assign 1 318 307
isEqual 2 318 307
putTo 2 319 309
assign 1 321 310
new 0 321 310
assign 1 322 311
new 0 322 311
return 1 322 312
assign 1 324 315
increment 0 324 315
assign 1 325 316
greaterEquals 1 325 321
assign 1 326 322
new 0 326 322
return 1 326 323
assign 1 333 336
innerPut 4 333 336
assign 1 333 337
not 0 333 337
assign 1 334 339
assign 1 335 340
rehash 1 335 340
assign 1 336 343
innerPut 4 336 343
assign 1 336 344
not 0 336 344
assign 1 337 346
rehash 1 337 346
assign 1 339 352
assign 1 342 355
increment 0 342 355
assign 1 347 376
assign 1 348 377
sizeGet 0 348 377
assign 1 349 378
getHash 1 349 378
assign 1 350 379
new 0 350 379
assign 1 350 380
lesser 1 350 385
assign 1 351 386
abs 0 351 386
assign 1 353 388
modulus 1 353 388
assign 1 354 389
assign 1 356 392
get 1 356 392
assign 1 357 393
undef 1 357 398
return 1 358 399
assign 1 359 402
hvalGet 0 359 402
assign 1 359 403
modulus 1 359 403
assign 1 359 404
notEquals 1 359 409
return 1 360 410
assign 1 361 413
keyGet 0 361 413
assign 1 361 414
isEqual 2 361 414
assign 1 362 416
getFrom 0 362 416
return 1 362 417
assign 1 364 420
increment 0 364 420
assign 1 365 421
greaterEquals 1 365 426
return 1 366 427
assign 1 373 454
assign 1 374 455
sizeGet 0 374 455
assign 1 375 456
getHash 1 375 456
assign 1 376 457
new 0 376 457
assign 1 376 458
lesser 1 376 463
assign 1 377 464
abs 0 377 464
assign 1 379 466
modulus 1 379 466
assign 1 380 467
assign 1 382 470
get 1 382 470
assign 1 383 471
undef 1 383 476
assign 1 384 477
new 0 384 477
return 1 384 478
assign 1 385 481
hvalGet 0 385 481
assign 1 385 482
modulus 1 385 482
assign 1 385 483
notEquals 1 385 488
assign 1 386 489
new 0 386 489
return 1 386 490
assign 1 387 493
keyGet 0 387 493
assign 1 387 494
isEqual 2 387 494
assign 1 388 496
new 0 388 496
return 1 388 497
assign 1 390 500
increment 0 390 500
assign 1 391 501
greaterEquals 1 391 506
assign 1 392 507
new 0 392 507
return 1 392 508
assign 1 399 544
assign 1 400 545
sizeGet 0 400 545
assign 1 402 546
getHash 1 402 546
assign 1 403 547
new 0 403 547
assign 1 403 548
lesser 1 403 553
assign 1 404 554
abs 0 404 554
assign 1 406 556
modulus 1 406 556
assign 1 407 557
assign 1 409 560
get 1 409 560
assign 1 410 561
undef 1 410 566
assign 1 411 567
new 0 411 567
return 1 411 568
assign 1 412 571
hvalGet 0 412 571
assign 1 412 572
modulus 1 412 572
assign 1 412 573
notEquals 1 412 578
assign 1 413 579
new 0 413 579
return 1 413 580
assign 1 414 583
keyGet 0 414 583
assign 1 414 584
isEqual 2 414 584
put 2 415 586
assign 1 416 587
decrement 0 416 587
assign 1 417 588
increment 0 417 588
assign 1 418 591
lesser 1 418 596
assign 1 419 597
get 1 419 597
assign 1 420 598
undef 1 420 603
assign 1 0 604
assign 1 420 607
hvalGet 0 420 607
assign 1 420 608
modulus 1 420 608
assign 1 420 609
notEquals 1 420 614
assign 1 0 615
assign 1 0 618
assign 1 421 622
new 0 421 622
return 1 421 623
assign 1 423 626
new 0 423 626
assign 1 423 627
subtract 1 423 627
put 2 423 628
put 2 424 629
assign 1 426 631
increment 0 426 631
assign 1 428 637
new 0 428 637
return 1 428 638
assign 1 430 641
increment 0 430 641
assign 1 431 642
greaterEquals 1 431 647
assign 1 432 648
new 0 432 648
return 1 432 649
assign 1 439 671
create 0 439 671
copyTo 1 440 672
assign 1 441 673
copy 0 441 673
slotsSet 1 441 674
assign 1 442 675
new 0 442 675
assign 1 442 678
lengthGet 0 442 678
assign 1 442 679
lesser 1 442 684
assign 1 443 685
get 1 443 685
assign 1 444 686
def 1 444 691
assign 1 445 692
slotsGet 0 445 692
assign 1 445 693
create 0 445 693
assign 1 445 694
hvalGet 0 445 694
assign 1 445 695
keyGet 0 445 695
assign 1 445 696
getFrom 0 445 696
assign 1 445 697
new 3 445 697
put 2 445 698
assign 1 447 701
slotsGet 0 447 701
put 2 447 702
assign 1 442 704
increment 0 442 704
return 1 450 710
clear 0 455 713
assign 1 456 714
new 0 456 714
assign 1 460 719
new 1 460 719
return 1 460 720
assign 1 464 724
new 1 464 724
return 1 464 725
assign 1 468 729
new 1 468 729
return 1 468 730
assign 1 472 734
keyIteratorGet 0 472 734
return 1 472 735
assign 1 476 739
new 1 476 739
return 1 476 740
assign 1 480 744
nodeIteratorGet 0 480 744
return 1 480 745
assign 1 484 754
new 0 484 754
assign 1 485 755
def 1 485 760
assign 1 486 761
setIteratorGet 0 0 761
assign 1 486 764
hasNextGet 0 486 764
assign 1 486 766
nextGet 0 486 766
assign 1 487 767
has 1 487 767
put 1 488 769
return 1 492 777
assign 1 496 787
new 0 496 787
assign 1 497 788
setIteratorGet 0 0 788
assign 1 497 791
hasNextGet 0 497 791
assign 1 497 793
nextGet 0 497 793
put 1 498 794
assign 1 500 800
def 1 500 805
assign 1 501 806
setIteratorGet 0 0 806
assign 1 501 809
hasNextGet 0 501 809
assign 1 501 811
nextGet 0 501 811
put 1 502 812
return 1 505 819
assign 1 509 823
copy 0 509 823
addValue 1 510 824
return 1 511 825
assign 1 515 835
def 1 515 840
assign 1 516 841
sameType 1 516 841
assign 1 517 843
iteratorGet 0 0 843
assign 1 517 846
hasNextGet 0 517 846
assign 1 517 848
nextGet 0 517 848
put 1 518 849
assign 1 520 857
sameType 1 520 857
assign 1 521 859
keyGet 0 521 859
put 1 521 860
put 1 523 863
return 1 0 870
assign 1 0 873
return 1 0 877
assign 1 0 880
return 1 0 884
assign 1 0 887
return 1 0 891
assign 1 0 894
return 1 0 898
assign 1 0 901
return 1 0 905
assign 1 0 908
return 1 0 912
assign 1 0 915
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -712928736: return bem_innerPutAddedGet_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1586230380: return bem_moduGet_0();
case -1114073101: return bem_keysGet_0();
case 104713553: return bem_new_0();
case 2086347094: return bem_nodesGet_0();
case 287040793: return bem_hashGet_0();
case 2056412570: return bem_keyIteratorGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 354906194: return bem_slotsGet_0();
case -2142483603: return bem_notEmptyGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case -1431826729: return bem_nodeIteratorGet_0();
case 1820417453: return bem_create_0();
case 1227011022: return bem_multiGet_0();
case -578884498: return bem_relGet_0();
case -786424307: return bem_tagGet_0();
case 235611348: return bem_baseNodeGet_0();
case 499932279: return bem_setIteratorGet_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1575148127: return bem_moduSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 99049420: return bem_has_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 98246024: return bem_get_1(bevd_0);
case -567802245: return bem_relSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1078124908: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -701846483: return bem_innerPutAddedSet_1(bevd_0);
case 1238093275: return bem_multiSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -79841285: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 819712669: return bem_delete_1(bevd_0);
case -286659903: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 107034369: return bem_put_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -668984013: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 246693601: return bem_baseNodeSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 365988447: return bem_slotsSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -131089957: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 809795150: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerSet();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerSet.bevs_inst = (BEC_2_9_3_ContainerSet)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerSet.bevs_inst;
}
}
