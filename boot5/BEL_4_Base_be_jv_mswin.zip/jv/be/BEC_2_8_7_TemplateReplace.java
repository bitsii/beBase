package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_7_TemplateReplace extends BEC_2_6_6_SystemObject {
public BEC_2_8_7_TemplateReplace() { }
private static byte[] becc_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x65,0x70,0x6C,0x61,0x63,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C,0x3F,0x74,0x74};
private static byte[] bels_1 = {0x3F,0x3E};
private static byte[] bels_2 = {0x20};
public static BEC_2_8_7_TemplateReplace bevs_inst;
public BEC_2_9_10_ContainerLinkedList bevp_steps;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_append;
public BEC_2_8_6_TemplateRunner bevp_runner;
public BEC_2_8_7_TemplateReplace bem_new_0() throws Throwable {
bevp_append = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
this.bem_load_2(beva_template, null);
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_load_2(BEC_2_4_6_TextString beva_template, BEC_2_8_6_TemplateRunner beva__runner) throws Throwable {
BEC_2_4_6_TextString bevl_blStart = null;
BEC_2_4_6_TextString bevl_blEnd = null;
BEC_2_5_4_LogicBool bevl_onStart = null;
BEC_2_5_4_LogicBool bevl_nextIsCall = null;
BEC_2_4_6_TextString bevl_delim = null;
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_4_6_TextString bevl_payload = null;
BEC_2_9_10_ContainerLinkedList bevl_payloads = null;
BEC_2_7_8_ReplaceCallStep bevl_rcs = null;
BEC_2_4_6_TextString bevl_paypart = null;
BEC_2_7_7_ReplaceRunStep bevl_rs = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_7_10_ReplaceStringStep bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_7_10_ReplaceStringStep bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevp_runner = beva__runner;
bevp_size = beva_template.bem_sizeGet_0();
bevl_blStart = (new BEC_2_4_6_TextString(4, bels_0));
bevl_blEnd = (new BEC_2_4_6_TextString(2, bels_1));
bevl_onStart = be.BECS_Runtime.boolTrue;
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blStart;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_2_4_3_MathInt(0));
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
bevl_ds = bevl_delim.bem_sizeGet_0();
while (true)
 /* Line: 83 */ {
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 83 */ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 84 */ {
if (bevl_nextIsCall.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevl_i);
bevl_payload = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_strip_0();
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_2));
bevl_payloads = bevl_payload.bem_split_1(bevt_4_tmpany_phold);
if (bevp_runner == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevl_rcs = (new BEC_2_7_8_ReplaceCallStep()).bem_new_1(bevl_payloads);
bevl_splits.bem_addValue_1(bevl_rcs);
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
} /* Line: 92 */
 else  /* Line: 93 */ {
bevt_0_tmpany_loop = bevl_payloads.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 95 */ {
bevt_6_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 95 */ {
bevl_paypart = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_rs = (new BEC_2_7_7_ReplaceRunStep()).bem_new_2(this, bevl_paypart);
bevl_splits.bem_addValue_1(bevl_rs);
} /* Line: 97 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
bevl_nextIsCall = be.BECS_Runtime.boolFalse;
} /* Line: 99 */
} /* Line: 88 */
 else  /* Line: 101 */ {
bevt_8_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevl_i);
bevt_7_tmpany_phold = (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_8_tmpany_phold);
bevl_splits.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 102 */
} /* Line: 85 */
bevl_last = bevl_i.bem_add_1(bevl_ds);
if (bevl_onStart.bevi_bool) /* Line: 106 */ {
bevl_onStart = be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blEnd;
bevl_ds = bevl_delim.bem_sizeGet_0();
bevl_nextIsCall = be.BECS_Runtime.boolTrue;
} /* Line: 110 */
 else  /* Line: 111 */ {
bevl_onStart = be.BECS_Runtime.boolTrue;
bevl_delim = bevl_blStart;
bevl_ds = bevl_delim.bem_sizeGet_0();
} /* Line: 114 */
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
} /* Line: 116 */
 else  /* Line: 83 */ {
break;
} /* Line: 83 */
} /* Line: 83 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_11_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevp_size);
bevt_10_tmpany_phold = (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_11_tmpany_phold);
bevl_splits.bem_addValue_1(bevt_10_tmpany_phold);
} /* Line: 119 */
bevp_steps = bevl_splits;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_accept_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_out) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_iter = bevp_steps.bem_iteratorGet_0();
while (true)
 /* Line: 126 */ {
bevt_0_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_append.bevi_bool) /* Line: 128 */ {
bevt_1_tmpany_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, beva_inst);
beva_out.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_1_tmpany_phold);
} /* Line: 129 */
} /* Line: 128 */
 else  /* Line: 126 */ {
break;
} /* Line: 126 */
} /* Line: 126 */
return beva_out;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
return bevp_steps;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_stepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_appendGet_0() throws Throwable {
return bevp_append;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_appendSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runnerGet_0() throws Throwable {
return bevp_runner;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_runnerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {59, 66, 70, 71, 73, 74, 75, 76, 78, 79, 80, 81, 82, 83, 83, 84, 84, 86, 86, 87, 87, 88, 88, 90, 91, 92, 95, 0, 95, 95, 96, 97, 99, 102, 102, 102, 105, 107, 108, 109, 110, 112, 113, 114, 116, 118, 118, 119, 119, 119, 121, 125, 126, 127, 129, 129, 132, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 20, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 63, 68, 69, 74, 76, 77, 78, 79, 80, 85, 86, 87, 88, 91, 91, 94, 96, 97, 98, 104, 108, 109, 110, 113, 115, 116, 117, 118, 121, 122, 123, 125, 131, 136, 137, 138, 139, 141, 149, 152, 154, 156, 157, 164, 167, 170, 174, 177, 181, 184, 188, 191};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 59 16
new 0 59 16
load 2 66 20
assign 1 70 50
assign 1 71 51
sizeGet 0 71 51
assign 1 73 52
new 0 73 52
assign 1 74 53
new 0 74 53
assign 1 75 54
new 0 75 54
assign 1 76 55
new 0 76 55
assign 1 78 56
assign 1 79 57
new 0 79 57
assign 1 80 58
new 0 80 58
assign 1 81 59
find 2 81 59
assign 1 82 60
sizeGet 0 82 60
assign 1 83 63
def 1 83 68
assign 1 84 69
greater 1 84 74
assign 1 86 76
substring 2 86 76
assign 1 86 77
strip 0 86 77
assign 1 87 78
new 0 87 78
assign 1 87 79
split 1 87 79
assign 1 88 80
undef 1 88 85
assign 1 90 86
new 1 90 86
addValue 1 91 87
assign 1 92 88
new 0 92 88
assign 1 95 91
linkedListIteratorGet 0 0 91
assign 1 95 94
hasNextGet 0 95 94
assign 1 95 96
nextGet 0 95 96
assign 1 96 97
new 2 96 97
addValue 1 97 98
assign 1 99 104
new 0 99 104
assign 1 102 108
substring 2 102 108
assign 1 102 109
new 1 102 109
addValue 1 102 110
assign 1 105 113
add 1 105 113
assign 1 107 115
new 0 107 115
assign 1 108 116
assign 1 109 117
sizeGet 0 109 117
assign 1 110 118
new 0 110 118
assign 1 112 121
new 0 112 121
assign 1 113 122
assign 1 114 123
sizeGet 0 114 123
assign 1 116 125
find 2 116 125
assign 1 118 131
lesser 1 118 136
assign 1 119 137
substring 2 119 137
assign 1 119 138
new 1 119 138
addValue 1 119 139
assign 1 121 141
assign 1 125 149
iteratorGet 0 125 149
assign 1 126 152
hasNextGet 0 126 152
assign 1 127 154
nextGet 0 127 154
assign 1 129 156
handle 1 129 156
write 1 129 157
return 1 132 164
return 1 0 167
assign 1 0 170
return 1 0 174
assign 1 0 177
return 1 0 181
assign 1 0 184
return 1 0 188
assign 1 0 191
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -723109216: return bem_stepsGet_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1908752755: return bem_appendGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -251179977: return bem_runnerGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case 474162694: return bem_sizeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1897670502: return bem_appendSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -712026963: return bem_stepsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -240097724: return bem_runnerSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1097519336: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1097519335: return bem_load_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_8_6_TemplateRunner) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2146525509: return bem_accept_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_7_TemplateReplace();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_7_TemplateReplace.bevs_inst = (BEC_2_8_7_TemplateReplace)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_7_TemplateReplace.bevs_inst;
}
}
