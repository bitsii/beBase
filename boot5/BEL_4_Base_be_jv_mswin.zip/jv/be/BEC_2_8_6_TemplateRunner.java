package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_8_6_TemplateRunner bevs_inst;
public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public BEC_2_8_6_TemplateRunner bem_new_0() throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_swap == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 185 */ {
bevp_swap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 185 */
return bevp_swap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_handOff == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevp_handOff = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 190 */
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) throws Throwable {
this.bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) throws Throwable {
this.bem_new_0();
this.bem_load_1(beva_template);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bevp_replace = (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_restart_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 210 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 212 */
bevp_stepIter = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
if (bevp_stepIter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_1_tmpany_phold = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_tmpany_phold.bem_iteratorGet_0();
} /* Line: 219 */
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_1_tmpany_phold = null;
if (bevp_baton == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevt_1_tmpany_phold = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_tmpany_phold;
} /* Line: 226 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_8_6_TemplateRunner bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = this.bem_currentRunnerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_stepIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1582066476, BEL_4_Base.bevn_currentNodeGet_0);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = this.bem_stepIterGet_0();
bevl_iter.bemd_1(1593148729, BEL_4_Base.bevn_currentNodeSet_1, beva_node);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_4_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 244 */
 else  /* Line: 245 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 248 */
} /* Line: 243 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 252 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 252 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 254 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 254 */
 else  /* Line: 254 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 254 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 254 */
 else  /* Line: 254 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 254 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 259 */
 else  /* Line: 260 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 263 */
} /* Line: 258 */
 else  /* Line: 254 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 265 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_label);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 265 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 265 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 265 */
 else  /* Line: 265 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 265 */ {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 266 */
 else  /* Line: 267 */ {
bevt_18_tmpany_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, this);
bevp_output.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_18_tmpany_phold);
} /* Line: 268 */
} /* Line: 254 */
} /* Line: 254 */
 else  /* Line: 252 */ {
break;
} /* Line: 252 */
} /* Line: 252 */
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_19_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
if (bevp_baton == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevt_4_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 277 */
 else  /* Line: 278 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 281 */
} /* Line: 276 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 285 */ {
bevt_6_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 287 */ {
bevt_8_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 287 */ {
bevt_10_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_9_tmpany_phold = bevp_handOff.bem_has_1(bevt_10_tmpany_phold);
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 287 */ {
bevt_11_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpany_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_13_tmpany_phold;
} /* Line: 292 */
 else  /* Line: 293 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 296 */
} /* Line: 291 */
 else  /* Line: 287 */ {
bevt_14_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpany_phold).bevi_bool) /* Line: 298 */ {
bevt_16_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_label);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpany_phold).bevi_bool) /* Line: 298 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 298 */
 else  /* Line: 298 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 298 */ {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_17_tmpany_phold;
} /* Line: 299 */
} /* Line: 287 */
} /* Line: 287 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_18_tmpany_phold;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_run_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
if (bevp_baton == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 309 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 312 */ {
bevt_3_tmpany_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpany_phold).bevi_bool) /* Line: 312 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_5_tmpany_phold = bevl_s.bemd_1(-1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 314 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
 else  /* Line: 314 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 314 */ {
bevt_7_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_6_tmpany_phold = bevp_handOff.bem_has_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
 else  /* Line: 314 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 314 */ {
bevt_8_tmpany_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_tmpany_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 320 */
 else  /* Line: 321 */ {
bevt_9_tmpany_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, this);
bevp_output.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_9_tmpany_phold);
} /* Line: 322 */
} /* Line: 314 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_output = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_stepIter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGet_0() throws Throwable {
return bevp_baton;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {180, 185, 185, 185, 186, 190, 190, 190, 191, 195, 196, 200, 201, 205, 206, 210, 210, 211, 212, 214, 218, 218, 219, 219, 221, 225, 225, 226, 226, 228, 232, 232, 232, 232, 237, 238, 242, 242, 243, 244, 244, 247, 248, 251, 252, 253, 254, 254, 254, 0, 0, 0, 254, 254, 0, 0, 0, 255, 255, 256, 257, 258, 259, 259, 262, 263, 265, 265, 265, 0, 0, 0, 266, 266, 268, 268, 271, 271, 275, 275, 276, 277, 277, 280, 281, 284, 285, 286, 287, 287, 287, 0, 0, 0, 287, 287, 0, 0, 0, 288, 288, 289, 290, 291, 292, 292, 295, 296, 298, 298, 298, 0, 0, 0, 299, 299, 302, 302, 306, 306, 307, 308, 309, 311, 312, 313, 314, 314, 314, 0, 0, 0, 314, 314, 0, 0, 0, 315, 315, 316, 317, 318, 319, 320, 322, 322, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 21, 26, 27, 29, 33, 38, 39, 41, 44, 45, 49, 50, 54, 55, 60, 65, 66, 67, 69, 75, 80, 81, 82, 84, 89, 94, 95, 96, 98, 104, 105, 106, 107, 111, 112, 138, 143, 144, 146, 147, 150, 151, 154, 157, 159, 160, 165, 166, 168, 171, 175, 178, 179, 181, 184, 188, 191, 192, 193, 194, 195, 197, 198, 201, 202, 206, 208, 209, 211, 214, 218, 221, 222, 225, 226, 234, 235, 259, 264, 265, 267, 268, 271, 272, 275, 278, 280, 281, 286, 287, 289, 292, 296, 299, 300, 302, 305, 309, 312, 313, 314, 315, 316, 318, 319, 322, 323, 327, 329, 330, 332, 335, 339, 342, 343, 351, 352, 367, 372, 373, 374, 375, 377, 380, 382, 383, 388, 389, 391, 394, 398, 401, 402, 404, 407, 411, 414, 415, 416, 417, 418, 419, 420, 423, 424, 434, 437, 441, 444, 448, 452, 456, 460, 463, 467, 470};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 180 16
new 0 180 16
assign 1 185 21
undef 1 185 26
assign 1 185 27
new 0 185 27
return 1 186 29
assign 1 190 33
undef 1 190 38
assign 1 190 39
new 0 190 39
return 1 191 41
new 1 195 44
assign 1 196 45
new 0 200 49
load 1 201 50
assign 1 205 54
new 0 205 54
load 2 206 55
assign 1 210 60
def 1 210 65
restart 0 211 66
assign 1 212 67
assign 1 214 69
assign 1 218 75
undef 1 218 80
assign 1 219 81
stepsGet 0 219 81
assign 1 219 82
iteratorGet 0 219 82
return 1 221 84
assign 1 225 89
def 1 225 94
assign 1 226 95
currentRunnerGet 0 226 95
return 1 226 96
return 1 228 98
assign 1 232 104
currentRunnerGet 0 232 104
assign 1 232 105
stepIterGet 0 232 105
assign 1 232 106
currentNodeGet 0 232 106
return 1 232 107
assign 1 237 111
stepIterGet 0 237 111
currentNodeSet 1 238 112
assign 1 242 138
def 1 242 143
assign 1 243 144
runToLabel 1 243 144
assign 1 244 146
new 0 244 146
return 1 244 147
restart 0 247 150
assign 1 248 151
assign 1 251 154
stepIterGet 0 251 154
assign 1 252 157
hasNextGet 0 252 157
assign 1 253 159
nextGet 0 253 159
assign 1 254 160
def 1 254 165
assign 1 254 166
sameType 1 254 166
assign 1 0 168
assign 1 0 171
assign 1 0 175
assign 1 254 178
strGet 0 254 178
assign 1 254 179
has 1 254 179
assign 1 0 181
assign 1 0 184
assign 1 0 188
assign 1 255 191
strGet 0 255 191
assign 1 255 192
get 1 255 192
outputSet 1 256 193
swapSet 1 257 194
assign 1 258 195
runToLabel 1 258 195
assign 1 259 197
new 0 259 197
return 1 259 198
restart 0 262 201
assign 1 263 202
assign 1 265 206
sameType 1 265 206
assign 1 265 208
strGet 0 265 208
assign 1 265 209
equals 1 265 209
assign 1 0 211
assign 1 0 214
assign 1 0 218
assign 1 266 221
new 0 266 221
return 1 266 222
assign 1 268 225
handle 1 268 225
write 1 268 226
assign 1 271 234
new 0 271 234
return 1 271 235
assign 1 275 259
def 1 275 264
assign 1 276 265
skipToLabel 1 276 265
assign 1 277 267
new 0 277 267
return 1 277 268
restart 0 280 271
assign 1 281 272
assign 1 284 275
stepIterGet 0 284 275
assign 1 285 278
hasNextGet 0 285 278
assign 1 286 280
nextGet 0 286 280
assign 1 287 281
def 1 287 286
assign 1 287 287
sameType 1 287 287
assign 1 0 289
assign 1 0 292
assign 1 0 296
assign 1 287 299
strGet 0 287 299
assign 1 287 300
has 1 287 300
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 288 312
strGet 0 288 312
assign 1 288 313
get 1 288 313
outputSet 1 289 314
swapSet 1 290 315
assign 1 291 316
skipToLabel 1 291 316
assign 1 292 318
new 0 292 318
return 1 292 319
restart 0 295 322
assign 1 296 323
assign 1 298 327
sameType 1 298 327
assign 1 298 329
strGet 0 298 329
assign 1 298 330
equals 1 298 330
assign 1 0 332
assign 1 0 335
assign 1 0 339
assign 1 299 342
new 0 299 342
return 1 299 343
assign 1 302 351
new 0 302 351
return 1 302 352
assign 1 306 367
def 1 306 372
run 0 307 373
restart 0 308 374
assign 1 309 375
assign 1 311 377
stepIterGet 0 311 377
assign 1 312 380
hasNextGet 0 312 380
assign 1 313 382
nextGet 0 313 382
assign 1 314 383
def 1 314 388
assign 1 314 389
sameType 1 314 389
assign 1 0 391
assign 1 0 394
assign 1 0 398
assign 1 314 401
strGet 0 314 401
assign 1 314 402
has 1 314 402
assign 1 0 404
assign 1 0 407
assign 1 0 411
assign 1 315 414
strGet 0 315 414
assign 1 315 415
get 1 315 415
outputSet 1 316 416
swapSet 1 317 417
run 0 318 418
restart 0 319 419
assign 1 320 420
assign 1 322 423
handle 1 322 423
write 1 322 424
return 1 0 434
assign 1 0 437
return 1 0 441
assign 1 0 444
assign 1 0 448
assign 1 0 452
assign 1 0 456
return 1 0 460
assign 1 0 463
return 1 0 467
assign 1 0 470
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1052303331: return bem_stepIterGet_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1294131276: return bem_swapGet_0();
case 1582066476: return bem_currentNodeGet_0();
case 104713553: return bem_new_0();
case 1941218611: return bem_batonGet_0();
case 287040793: return bem_hashGet_0();
case 108875644: return bem_run_0();
case 1774940957: return bem_toString_0();
case -1858379264: return bem_restart_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 438504243: return bem_replaceGet_0();
case -847016698: return bem_outputGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1032568578: return bem_currentRunnerGet_0();
case 1098633959: return bem_handOffGet_0();
case 1820417453: return bem_create_0();
case 930387920: return bem_runStepGet_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1952300864: return bem_batonSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 941470173: return bem_runStepSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1109716212: return bem_handOffSet_1(bevd_0);
case 449586496: return bem_replaceSet_1(bevd_0);
case -1097519336: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1283049023: return bem_swapSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1593148729: return bem_currentNodeSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -835934445: return bem_outputSet_1(bevd_0);
case 1586884588: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 1063385584: return bem_stepIterSet_1(bevd_0);
case -2118449056: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_TemplateRunner();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_TemplateRunner.bevs_inst = (BEC_2_8_6_TemplateRunner)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_TemplateRunner.bevs_inst;
}
}
