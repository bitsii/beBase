package be.BEL_4_Base;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_4_IOFile extends BEC_6_6_SystemObject {
public BEC_2_4_IOFile() { }
private static byte[] becc_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_4_IOFile bevs_inst;
public BEC_2_4_4_IOFilePath bevp_path;
public BEC_6_6_SystemObject bevp_reader;
public BEC_6_6_SystemObject bevp_writer;
public BEC_2_4_IOFile bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_IOFile bem_new_1(BEC_6_6_SystemObject beva_fpath) throws Throwable {
BEC_2_4_4_IOFilePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_new_1((BEC_4_6_TextString) beva_fpath);
this.bem_pathSet_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_IOFile bem_apNew_1(BEC_6_6_SystemObject beva_fpath) throws Throwable {
BEC_2_4_4_IOFilePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) beva_fpath);
this.bem_pathSet_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_IOFile bem_pathNew_1(BEC_2_4_4_IOFilePath beva__path) throws Throwable {
this.bem_pathSet_1(beva__path);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_readerGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
if (bevp_reader == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 62 */ {
bevt_1_tmpvar_phold = bevp_path.bem_toString_0();
bevp_reader = (new BEC_2_4_6_IOFileReader()).bem_new_1(bevt_1_tmpvar_phold);
} /* Line: 63 */
return bevp_reader;
} /*method end*/
public BEC_6_6_SystemObject bem_writerGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
if (bevp_writer == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 69 */ {
bevt_1_tmpvar_phold = bevp_path.bem_toString_0();
bevp_writer = (new BEC_2_4_6_IOFileWriter()).bem_new_1(bevt_1_tmpvar_phold);
} /* Line: 70 */
return bevp_writer;
} /*method end*/
public BEC_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_6_6_SystemObject bevl_llpath = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_existsGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 86 */ {

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.delete();
         } /* Line: 99 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_copyFile_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_4_6_TextString bevl_frs = null;
BEC_4_6_TextString bevl_tos = null;
BEC_5_4_LogicBool bevl_r = null;
BEC_5_4_LogicBool bevl_t = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevt_0_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevl_tos = (BEC_4_6_TextString) bevt_0_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_r = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_t = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_3_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(992607997, BEL_4_Base.bevn_parentGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_1_tmpvar_phold.bemd_0(181594299, BEL_4_Base.bevn_makeDirs_0);
return bevl_r;
} /*method end*/
public BEC_6_6_SystemObject bem_mkdirs_0() throws Throwable {
this.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_mkdir_0() throws Throwable {
this.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_makeDirs_0() throws Throwable {
BEC_4_6_TextString bevl_frs = null;
BEC_5_4_LogicBool bevl_r = null;
BEC_5_4_LogicBool bevl_t = null;
BEC_6_6_SystemObject bevl_strn = null;
BEC_6_6_SystemObject bevl_parentpath = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
bevl_frs = bevp_path.bem_toString_0();
bevl_r = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_t = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_strn = BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevp_path.bem_toString_0();
bevt_3_tmpvar_phold = bevl_strn.bemd_0(1081741254, BEL_4_Base.bevn_emptyGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 158 */ {
bevt_5_tmpvar_phold = this.bem_existsGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_not_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 158 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 158 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 158 */
 else  /* Line: 158 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 158 */ {
bevl_parentpath = bevp_path.bem_parentGet_0();
bevt_6_tmpvar_phold = bevp_path.bem_equals_1(bevl_parentpath);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 160 */ {
return this;
} /* Line: 162 */
bevt_7_tmpvar_phold = bevl_parentpath.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold.bemd_0(181594299, BEL_4_Base.bevn_makeDirs_0);

         java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
         bevls_f.mkdir();
         } /* Line: 187 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isDirectoryGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_isDirGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isDirGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_spa = null;
BEC_5_4_LogicBool bevl_result = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_result = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpvar_phold = this.bem_existsGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 214 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isDirectory()) {
            bevl_result = be.BELS_Base.BECS_Runtime.boolTrue;
          }
          } /* Line: 239 */
return bevl_result;
} /*method end*/
public BEC_5_4_LogicBool bem_isFileGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_spa = null;
BEC_5_4_LogicBool bevl_result = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_result = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpvar_phold = this.bem_existsGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 262 */ {

          java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
          if (bevls_f.isFile()) {
            bevl_result = be.BELS_Base.BECS_Runtime.boolTrue;
          }
          } /* Line: 287 */
return bevl_result;
} /*method end*/
public BEC_6_6_SystemObject bem_makeFile_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_writerGet_0();
bevt_0_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevt_1_tmpvar_phold = this.bem_writerGet_0();
bevt_1_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return this;
} /*method end*/
public BEC_4_6_TextString bem_contentsGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_existsGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 305 */ {
return null;
} /* Line: 306 */
bevt_2_tmpvar_phold = this.bem_contentsNoCheckGet_0();
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_contentsNoCheckGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_r = null;
BEC_4_6_TextString bevl_res = null;
bevl_r = this.bem_readerGet_0();
bevl_r.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_res = (BEC_4_6_TextString) bevl_r.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_r.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return bevl_res;
} /*method end*/
public BEC_2_4_IOFile bem_contentsSet_1(BEC_4_6_TextString beva_contents) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_IOFile bevt_2_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_3_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_4_tmpvar_phold = null;
BEC_2_4_IOFile bevt_5_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_6_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_7_tmpvar_phold = null;
bevt_4_tmpvar_phold = this.bem_pathGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_parentGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_fileGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_existsGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_7_tmpvar_phold = this.bem_pathGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_parentGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_fileGet_0();
bevt_5_tmpvar_phold.bem_makeDirs_0();
} /* Line: 321 */
this.bem_contentsNoCheckSet_1(beva_contents);
return this;
} /*method end*/
public BEC_2_4_IOFile bem_contentsNoCheckSet_1(BEC_4_6_TextString beva_contents) throws Throwable {
BEC_6_6_SystemObject bevl_w = null;
bevl_w = this.bem_writerGet_0();
bevl_w.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, beva_contents);
bevl_w.bemd_0(866536361, BEL_4_Base.bevn_close_0);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_6_6_SystemObject bevl_spa = null;
BEC_4_3_MathInt bevl__size = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl__size = (new BEC_4_3_MathInt()).bem_new_0();
bevl_spa = bevp_path.bem_toString_0();
bevt_0_tmpvar_phold = this.bem_existsGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 345 */ {
} /* Line: 346 */
return bevl__size;
} /*method end*/
public BEC_5_4_LogicBool bem_existsGet_0() throws Throwable {
BEC_5_4_LogicBool bevl_tvala = null;
BEC_6_6_SystemObject bevl_mpath = null;
bevl_tvala = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_mpath = bevp_path.bem_toString_0();

      java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
      if (bevls_f.exists()) {
        bevl_tvala = be.BELS_Base.BECS_Runtime.boolTrue;
      }
      return bevl_tvala;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_absPathGet_0() throws Throwable {
BEC_2_4_4_IOFilePath bevl_absp = null;
BEC_4_6_TextString bevl_abstr = null;
 /* Line: 409 */ {

        java.io.File bevls_f = new java.io.File(new String(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int, "UTF-8"));
        bevl_abstr = new BEC_4_6_TextString(bevls_f.toPath().toRealPath().toString());
        } /* Line: 410 */
bevl_absp = (new BEC_2_4_4_IOFilePath()).bem_apNew_1(bevl_abstr);
return bevl_absp;
} /*method end*/
public BEC_6_6_SystemObject bem_close_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (bevp_reader == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 422 */ {
bevp_reader.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 423 */
if (bevp_writer == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 425 */ {
bevp_writer.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 426 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_4_17_IOFileDirectoryIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_17_IOFileDirectoryIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_6_6_SystemObject bem_pathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_path = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_readerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_reader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_writerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_writer = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 50, 54, 54, 58, 62, 62, 63, 63, 65, 69, 69, 70, 70, 72, 86, 119, 120, 120, 121, 122, 123, 123, 123, 123, 135, 140, 143, 154, 155, 156, 157, 158, 158, 158, 158, 158, 0, 0, 0, 159, 160, 162, 164, 164, 200, 200, 212, 213, 214, 248, 260, 261, 262, 296, 300, 300, 301, 301, 305, 305, 306, 308, 308, 312, 313, 314, 315, 316, 320, 320, 320, 320, 320, 321, 321, 321, 321, 323, 327, 328, 329, 330, 343, 344, 345, 355, 366, 367, 401, 417, 418, 422, 422, 423, 425, 425, 426, 431, 431, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 22, 23, 27, 33, 38, 39, 40, 42, 47, 52, 53, 54, 56, 61, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 90, 94, 111, 112, 113, 114, 115, 116, 117, 119, 120, 122, 125, 129, 132, 133, 135, 137, 138, 147, 148, 154, 155, 156, 164, 170, 171, 172, 180, 185, 186, 187, 188, 195, 196, 198, 200, 201, 206, 207, 208, 209, 210, 221, 222, 223, 224, 225, 227, 228, 229, 230, 232, 237, 238, 239, 240, 247, 248, 249, 252, 257, 258, 264, 274, 275, 280, 285, 286, 288, 293, 294, 300, 301, 304, 307, 311, 315};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 16
new 1 50 16
pathSet 1 50 17
assign 1 54 22
apNew 1 54 22
pathSet 1 54 23
pathSet 1 58 27
assign 1 62 33
undef 1 62 38
assign 1 63 39
toString 0 63 39
assign 1 63 40
new 1 63 40
return 1 65 42
assign 1 69 47
undef 1 69 52
assign 1 70 53
toString 0 70 53
assign 1 70 54
new 1 70 54
return 1 72 56
assign 1 86 61
existsGet 0 86 61
assign 1 119 78
toString 0 119 78
assign 1 120 79
pathGet 0 120 79
assign 1 120 80
toString 0 120 80
assign 1 121 81
new 0 121 81
assign 1 122 82
new 0 122 82
assign 1 123 83
pathGet 0 123 83
assign 1 123 84
parentGet 0 123 84
assign 1 123 85
fileGet 0 123 85
makeDirs 0 123 86
return 1 135 87
makeDirs 0 140 90
makeDirs 0 143 94
assign 1 154 111
toString 0 154 111
assign 1 155 112
new 0 155 112
assign 1 156 113
new 0 156 113
assign 1 157 114
new 0 157 114
assign 1 158 115
toString 0 158 115
assign 1 158 116
emptyGet 0 158 116
assign 1 158 117
notEquals 1 158 117
assign 1 158 119
existsGet 0 158 119
assign 1 158 120
not 0 158 120
assign 1 0 122
assign 1 0 125
assign 1 0 129
assign 1 159 132
parentGet 0 159 132
assign 1 160 133
equals 1 160 133
return 1 162 135
assign 1 164 137
fileGet 0 164 137
makeDirs 0 164 138
assign 1 200 147
isDirGet 0 200 147
return 1 200 148
assign 1 212 154
new 0 212 154
assign 1 213 155
toString 0 213 155
assign 1 214 156
existsGet 0 214 156
return 1 248 164
assign 1 260 170
new 0 260 170
assign 1 261 171
toString 0 261 171
assign 1 262 172
existsGet 0 262 172
return 1 296 180
assign 1 300 185
writerGet 0 300 185
open 0 300 186
assign 1 301 187
writerGet 0 301 187
close 0 301 188
assign 1 305 195
existsGet 0 305 195
assign 1 305 196
not 0 305 196
return 1 306 198
assign 1 308 200
contentsNoCheckGet 0 308 200
return 1 308 201
assign 1 312 206
readerGet 0 312 206
open 0 313 207
assign 1 314 208
readString 0 314 208
close 0 315 209
return 1 316 210
assign 1 320 221
pathGet 0 320 221
assign 1 320 222
parentGet 0 320 222
assign 1 320 223
fileGet 0 320 223
assign 1 320 224
existsGet 0 320 224
assign 1 320 225
not 0 320 225
assign 1 321 227
pathGet 0 321 227
assign 1 321 228
parentGet 0 321 228
assign 1 321 229
fileGet 0 321 229
makeDirs 0 321 230
contentsNoCheckSet 1 323 232
assign 1 327 237
writerGet 0 327 237
open 0 328 238
write 1 329 239
close 0 330 240
assign 1 343 247
new 0 343 247
assign 1 344 248
toString 0 344 248
assign 1 345 249
existsGet 0 345 249
return 1 355 252
assign 1 366 257
new 0 366 257
assign 1 367 258
toString 0 367 258
return 1 401 264
assign 1 417 274
apNew 1 417 274
return 1 418 275
assign 1 422 280
def 1 422 285
close 0 423 286
assign 1 425 288
def 1 425 293
close 0 426 294
assign 1 431 300
new 1 431 300
return 1 431 301
return 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 0 315
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 371906180: return bem_readerGet_0();
case 209284380: return bem_isDirectoryGet_0();
case 1081412016: return bem_many_0();
case 181594299: return bem_makeDirs_0();
case 129806037: return bem_mkdirs_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 574873532: return bem_isDirGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 160463007: return bem_isFileGet_0();
case 2072547979: return bem_existsGet_0();
case 108109840: return bem_absPathGet_0();
case 866536361: return bem_close_0();
case 547861133: return bem_contentsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 124528197: return bem_makeFile_0();
case 729571811: return bem_serializeToString_0();
case 439054906: return bem_contentsNoCheckGet_0();
case 1354714650: return bem_copy_0();
case 819712668: return bem_delete_0();
case 400189342: return bem_pathGet_0();
case 1112565280: return bem_mkdir_0();
case 2037163820: return bem_writerGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 450137159: return bem_contentsNoCheckSet_1((BEC_4_6_TextString) bevd_0);
case 389107089: return bem_pathSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1294597629: return bem_copyFile_1(bevd_0);
case 382988433: return bem_readerSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 393721811: return bem_pathNew_1((BEC_2_4_4_IOFilePath) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 824830365: return bem_apNew_1(bevd_0);
case 2026081567: return bem_writerSet_1(bevd_0);
case 558943386: return bem_contentsSet_1((BEC_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_IOFile();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_IOFile.bevs_inst = (BEC_2_4_IOFile)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_IOFile.bevs_inst;
}
}
