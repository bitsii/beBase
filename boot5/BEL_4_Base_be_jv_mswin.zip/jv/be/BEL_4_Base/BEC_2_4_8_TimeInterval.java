package be.BEL_4_Base;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval extends BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
private static byte[] becc_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(3600));
private static byte[] bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_0, 10));
private static byte[] bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_19 = (new BEC_2_4_6_TextString(bels_1, 13));
private static byte[] bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bevo_20 = (new BEC_2_4_6_TextString(bels_2, 13));
private static byte[] bels_3 = {0x3A};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bels_4, 13));
private static byte[] bels_5 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bels_5, 13));
public static BEC_2_4_8_TimeInterval bevs_inst;
public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public BEC_2_4_8_TimeInterval bem_now_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt()).bem_new_0();
bevp_millis = (new BEC_2_4_3_MathInt()).bem_new_0();

            long ctm = System.currentTimeMillis();
            bevp_secs.bevi_int = (int) (ctm / 1000);
            bevp_millis.bevi_int = (int) (ctm % 1000);
            return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_0() throws Throwable {
bevp_secs = (new BEC_2_4_3_MathInt(0));
bevp_millis = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
this.bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_copy_0() throws Throwable {
BEC_2_4_8_TimeInterval bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondInMinuteGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_secs.bem_modulus_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_minutesGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_1;
bevt_0_tmpvar_phold = bevp_secs.bem_divide_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secondsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = beva__secs;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisecondsGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = beva__millis;
this.bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_2;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_5;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
this.bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_carryMillis_0() throws Throwable {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_6;
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_tmpvar_phold);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 230 */ {
bevt_5_tmpvar_phold = bevo_7;
bevt_4_tmpvar_phold = bevp_millis.bem_divide_1(bevt_5_tmpvar_phold);
bevp_secs = bevp_secs.bem_add_1(bevt_4_tmpvar_phold);
bevp_millis = bevl_mmod;
} /* Line: 232 */
bevt_7_tmpvar_phold = bevo_8;
if (bevp_millis.bevi_int < bevt_7_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_9_tmpvar_phold = bevo_9;
if (bevp_secs.bevi_int > bevt_9_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 234 */ {
bevt_10_tmpvar_phold = bevo_10;
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_11;
bevp_millis = bevt_11_tmpvar_phold.bem_add_1(bevp_millis);
} /* Line: 236 */
 else  /* Line: 234 */ {
bevt_13_tmpvar_phold = bevo_12;
if (bevp_millis.bevi_int > bevt_13_tmpvar_phold.bevi_int) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_15_tmpvar_phold = bevo_13;
if (bevp_secs.bevi_int < bevt_15_tmpvar_phold.bevi_int) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 237 */ {
bevt_16_tmpvar_phold = bevo_14;
bevp_secs = bevp_secs.bem_add_1(bevt_16_tmpvar_phold);
bevt_18_tmpvar_phold = bevo_15;
bevt_19_tmpvar_phold = bevo_16;
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_subtract_1(bevt_19_tmpvar_phold);
bevp_millis = bevt_17_tmpvar_phold.bem_add_1(bevp_millis);
} /* Line: 239 */
} /* Line: 234 */
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) throws Throwable {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) throws Throwable {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
this.bem_carryMillis_0();
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_tmpvar_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_res = (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 269 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 269 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 269 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 269 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 270 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
 else  /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 276 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 277 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 283 */
 else  /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 283 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 283 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 283 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 284 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_4_tmpvar_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_6_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 291 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_sameClass_1(beva_other);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_4_tmpvar_phold = beva_other.bemd_0(739051419, BEL_4_Base.bevn_secsGet_0);
bevt_3_tmpvar_phold = bevp_secs.bem_equals_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
 else  /* Line: 297 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 297 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(1914769121, BEL_4_Base.bevn_millisGet_0);
bevt_5_tmpvar_phold = bevp_millis.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 297 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 297 */
 else  /* Line: 297 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 297 */ {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /* Line: 298 */
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = this.bem_sameClass_1(beva_other);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_5_tmpvar_phold = beva_other.bemd_0(739051419, BEL_4_Base.bevn_secsGet_0);
bevt_4_tmpvar_phold = bevp_secs.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 304 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_7_tmpvar_phold = beva_other.bemd_0(1914769121, BEL_4_Base.bevn_millisGet_0);
bevt_6_tmpvar_phold = bevp_millis.bem_notEquals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 304 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 304 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 304 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 304 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 305 */
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
if (beva_other == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 312 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 312 */
bevt_3_tmpvar_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_7_tmpvar_phold = beva_other.bem_secsGet_0();
bevt_6_tmpvar_phold = bevp_secs.bem_subtract_1(bevt_7_tmpvar_phold);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_abs_0();
bevt_8_tmpvar_phold = bevo_17;
if (bevt_5_tmpvar_phold.bevi_int == bevt_8_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_9_tmpvar_phold;
} /* Line: 315 */
} /* Line: 314 */
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_10_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringMinutes_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
bevt_6_tmpvar_phold = this.bem_minutesGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_toString_0();
bevt_7_tmpvar_phold = bevo_18;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = this.bem_secondInMinuteGet_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevp_millis);
bevt_10_tmpvar_phold = bevo_20;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toShortString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevp_secs.bem_toString_0();
bevt_3_tmpvar_phold = bevo_21;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_millis.bem_toString_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
bevt_3_tmpvar_phold = bevp_secs.bem_toString_0();
bevt_4_tmpvar_phold = bevo_22;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_4_tmpvar_phold);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevp_millis);
bevt_5_tmpvar_phold = bevo_23;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGet_0() throws Throwable {
return bevp_secs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGet_0() throws Throwable {
return bevp_millis;
} /*method end*/
public BEC_2_6_6_SystemObject bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {119, 120, 157, 158, 164, 165, 166, 170, 170, 174, 174, 174, 178, 182, 182, 182, 186, 190, 194, 198, 199, 203, 203, 203, 207, 207, 207, 211, 211, 211, 215, 215, 215, 220, 224, 225, 229, 229, 230, 230, 231, 231, 231, 232, 234, 234, 234, 234, 234, 234, 0, 0, 0, 235, 235, 236, 236, 237, 237, 237, 237, 237, 237, 0, 0, 0, 238, 238, 239, 239, 239, 239, 244, 248, 249, 253, 253, 254, 254, 255, 256, 257, 261, 261, 262, 262, 263, 264, 265, 269, 269, 269, 0, 269, 269, 269, 269, 269, 269, 0, 0, 0, 0, 0, 270, 270, 272, 272, 276, 276, 276, 0, 276, 276, 276, 276, 276, 276, 0, 0, 0, 0, 0, 277, 277, 279, 279, 283, 283, 283, 0, 283, 283, 283, 283, 283, 283, 0, 0, 0, 0, 0, 284, 284, 286, 286, 290, 290, 290, 0, 290, 290, 290, 290, 290, 290, 0, 0, 0, 0, 0, 291, 291, 293, 293, 297, 297, 297, 0, 0, 0, 297, 297, 0, 0, 0, 298, 298, 300, 300, 304, 304, 0, 304, 304, 0, 0, 0, 304, 304, 0, 0, 305, 305, 307, 307, 312, 312, 312, 312, 313, 313, 313, 314, 314, 314, 314, 314, 314, 315, 315, 318, 318, 322, 322, 322, 322, 322, 322, 322, 322, 322, 322, 322, 322, 326, 326, 326, 326, 326, 326, 330, 330, 330, 330, 330, 330, 330, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 50, 51, 55, 56, 57, 62, 63, 68, 69, 70, 73, 78, 79, 80, 83, 86, 90, 93, 94, 100, 101, 102, 108, 109, 110, 116, 117, 118, 124, 125, 126, 130, 134, 135, 160, 161, 162, 167, 168, 169, 170, 171, 173, 174, 179, 180, 181, 186, 187, 190, 194, 197, 198, 199, 200, 203, 204, 209, 210, 211, 216, 217, 220, 224, 227, 228, 229, 230, 231, 232, 238, 242, 243, 252, 253, 254, 255, 256, 257, 258, 266, 267, 268, 269, 270, 271, 272, 284, 285, 290, 291, 294, 295, 300, 301, 302, 307, 308, 311, 315, 318, 321, 325, 326, 328, 329, 341, 342, 347, 348, 351, 352, 357, 358, 359, 364, 365, 368, 372, 375, 378, 382, 383, 385, 386, 398, 399, 404, 405, 408, 409, 414, 415, 416, 421, 422, 425, 429, 432, 435, 439, 440, 442, 443, 455, 456, 461, 462, 465, 466, 471, 472, 473, 478, 479, 482, 486, 489, 492, 496, 497, 499, 500, 512, 514, 515, 517, 520, 524, 527, 528, 530, 533, 537, 540, 541, 543, 544, 557, 558, 560, 563, 564, 566, 569, 573, 576, 577, 579, 582, 586, 587, 589, 590, 604, 609, 610, 611, 613, 614, 619, 620, 621, 622, 623, 624, 629, 630, 631, 634, 635, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 668, 669, 670, 671, 672, 673, 682, 683, 684, 685, 686, 687, 688, 691, 694, 698, 701};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 119 41
new 0 119 41
assign 1 120 42
new 0 120 42
assign 1 157 50
new 0 157 50
assign 1 158 51
new 0 158 51
assign 1 164 55
assign 1 165 56
carryMillis 0 166 57
assign 1 170 62
new 2 170 62
return 1 170 63
assign 1 174 68
new 0 174 68
assign 1 174 69
modulus 1 174 69
return 1 174 70
return 1 178 73
assign 1 182 78
new 0 182 78
assign 1 182 79
divide 1 182 79
return 1 182 80
return 1 186 83
assign 1 190 86
return 1 194 90
assign 1 198 93
carryMillis 0 199 94
assign 1 203 100
new 0 203 100
assign 1 203 101
multiply 1 203 101
assign 1 203 102
add 1 203 102
assign 1 207 108
new 0 207 108
assign 1 207 109
multiply 1 207 109
assign 1 207 110
add 1 207 110
assign 1 211 116
new 0 211 116
assign 1 211 117
multiply 1 211 117
assign 1 211 118
subtract 1 211 118
assign 1 215 124
new 0 215 124
assign 1 215 125
multiply 1 215 125
assign 1 215 126
subtract 1 215 126
assign 1 220 130
add 1 220 130
assign 1 224 134
add 1 224 134
carryMillis 0 225 135
assign 1 229 160
new 0 229 160
assign 1 229 161
modulus 1 229 161
assign 1 230 162
notEquals 1 230 167
assign 1 231 168
new 0 231 168
assign 1 231 169
divide 1 231 169
assign 1 231 170
add 1 231 170
assign 1 232 171
assign 1 234 173
new 0 234 173
assign 1 234 174
lesser 1 234 179
assign 1 234 180
new 0 234 180
assign 1 234 181
greater 1 234 186
assign 1 0 187
assign 1 0 190
assign 1 0 194
assign 1 235 197
new 0 235 197
assign 1 235 198
subtract 1 235 198
assign 1 236 199
new 0 236 199
assign 1 236 200
add 1 236 200
assign 1 237 203
new 0 237 203
assign 1 237 204
greater 1 237 209
assign 1 237 210
new 0 237 210
assign 1 237 211
lesser 1 237 216
assign 1 0 217
assign 1 0 220
assign 1 0 224
assign 1 238 227
new 0 238 227
assign 1 238 228
add 1 238 228
assign 1 239 229
new 0 239 229
assign 1 239 230
new 0 239 230
assign 1 239 231
subtract 1 239 231
assign 1 239 232
add 1 239 232
assign 1 244 238
subtract 1 244 238
assign 1 248 242
subtract 1 248 242
carryMillis 0 249 243
assign 1 253 252
secsGet 0 253 252
assign 1 253 253
add 1 253 253
assign 1 254 254
millisGet 0 254 254
assign 1 254 255
add 1 254 255
assign 1 255 256
new 2 255 256
carryMillis 0 256 257
return 1 257 258
assign 1 261 266
secsGet 0 261 266
assign 1 261 267
subtract 1 261 267
assign 1 262 268
millisGet 0 262 268
assign 1 262 269
subtract 1 262 269
assign 1 263 270
new 2 263 270
carryMillis 0 264 271
return 1 265 272
assign 1 269 284
secsGet 0 269 284
assign 1 269 285
greater 1 269 290
assign 1 0 291
assign 1 269 294
secsGet 0 269 294
assign 1 269 295
equals 1 269 300
assign 1 269 301
millisGet 0 269 301
assign 1 269 302
greater 1 269 307
assign 1 0 308
assign 1 0 311
assign 1 0 315
assign 1 0 318
assign 1 0 321
assign 1 270 325
new 0 270 325
return 1 270 326
assign 1 272 328
new 0 272 328
return 1 272 329
assign 1 276 341
secsGet 0 276 341
assign 1 276 342
lesser 1 276 347
assign 1 0 348
assign 1 276 351
secsGet 0 276 351
assign 1 276 352
equals 1 276 357
assign 1 276 358
millisGet 0 276 358
assign 1 276 359
lesser 1 276 364
assign 1 0 365
assign 1 0 368
assign 1 0 372
assign 1 0 375
assign 1 0 378
assign 1 277 382
new 0 277 382
return 1 277 383
assign 1 279 385
new 0 279 385
return 1 279 386
assign 1 283 398
secsGet 0 283 398
assign 1 283 399
greaterEquals 1 283 404
assign 1 0 405
assign 1 283 408
secsGet 0 283 408
assign 1 283 409
equals 1 283 414
assign 1 283 415
millisGet 0 283 415
assign 1 283 416
greaterEquals 1 283 421
assign 1 0 422
assign 1 0 425
assign 1 0 429
assign 1 0 432
assign 1 0 435
assign 1 284 439
new 0 284 439
return 1 284 440
assign 1 286 442
new 0 286 442
return 1 286 443
assign 1 290 455
secsGet 0 290 455
assign 1 290 456
lesserEquals 1 290 461
assign 1 0 462
assign 1 290 465
secsGet 0 290 465
assign 1 290 466
equals 1 290 471
assign 1 290 472
millisGet 0 290 472
assign 1 290 473
lesserEquals 1 290 478
assign 1 0 479
assign 1 0 482
assign 1 0 486
assign 1 0 489
assign 1 0 492
assign 1 291 496
new 0 291 496
return 1 291 497
assign 1 293 499
new 0 293 499
return 1 293 500
assign 1 297 512
sameClass 1 297 512
assign 1 297 514
secsGet 0 297 514
assign 1 297 515
equals 1 297 515
assign 1 0 517
assign 1 0 520
assign 1 0 524
assign 1 297 527
millisGet 0 297 527
assign 1 297 528
equals 1 297 528
assign 1 0 530
assign 1 0 533
assign 1 0 537
assign 1 298 540
new 0 298 540
return 1 298 541
assign 1 300 543
new 0 300 543
return 1 300 544
assign 1 304 557
sameClass 1 304 557
assign 1 304 558
not 0 304 558
assign 1 0 560
assign 1 304 563
secsGet 0 304 563
assign 1 304 564
notEquals 1 304 564
assign 1 0 566
assign 1 0 569
assign 1 0 573
assign 1 304 576
millisGet 0 304 576
assign 1 304 577
notEquals 1 304 577
assign 1 0 579
assign 1 0 582
assign 1 305 586
new 0 305 586
return 1 305 587
assign 1 307 589
new 0 307 589
return 1 307 590
assign 1 312 604
undef 1 312 609
assign 1 312 610
new 0 312 610
return 1 312 611
assign 1 313 613
millisGet 0 313 613
assign 1 313 614
equals 1 313 619
assign 1 314 620
secsGet 0 314 620
assign 1 314 621
subtract 1 314 621
assign 1 314 622
abs 0 314 622
assign 1 314 623
new 0 314 623
assign 1 314 624
equals 1 314 629
assign 1 315 630
new 0 315 630
return 1 315 631
assign 1 318 634
new 0 318 634
return 1 318 635
assign 1 322 649
minutesGet 0 322 649
assign 1 322 650
toString 0 322 650
assign 1 322 651
new 0 322 651
assign 1 322 652
add 1 322 652
assign 1 322 653
secondInMinuteGet 0 322 653
assign 1 322 654
add 1 322 654
assign 1 322 655
new 0 322 655
assign 1 322 656
add 1 322 656
assign 1 322 657
add 1 322 657
assign 1 322 658
new 0 322 658
assign 1 322 659
add 1 322 659
return 1 322 660
assign 1 326 668
toString 0 326 668
assign 1 326 669
new 0 326 669
assign 1 326 670
add 1 326 670
assign 1 326 671
toString 0 326 671
assign 1 326 672
add 1 326 672
return 1 326 673
assign 1 330 682
toString 0 330 682
assign 1 330 683
new 0 330 683
assign 1 330 684
add 1 330 684
assign 1 330 685
add 1 330 685
assign 1 330 686
new 0 330 686
assign 1 330 687
add 1 330 687
return 1 330 688
return 1 0 691
assign 1 0 694
return 1 0 698
assign 1 0 701
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 284498275: return bem_toShortString_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 316166507: return bem_millisecondsGet_0();
case 314718434: return bem_print_0();
case 888746948: return bem_toStringMinutes_0();
case 478622533: return bem_sourceFileNameGet_0();
case 169908808: return bem_secondsGet_0();
case 1914769121: return bem_millisGet_0();
case 1490855437: return bem_millisecondInSecondGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 324838054: return bem_secondInMinuteGet_0();
case 24587954: return bem_carryMillis_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 864467992: return bem_minutesGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 105011463: return bem_now_0();
case 1354714650: return bem_copy_0();
case 739051419: return bem_secsGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 979186229: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 81310150: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 92659731: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1301342541: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case 180991061: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 445912502: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case 955482416: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 305084254: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1925851374: return bem_millisSet_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1286233312: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1103128156: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 727969166: return bem_secsSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 309281416: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1689132987: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1992862333: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 1081152067: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_8_TimeInterval();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_8_TimeInterval.bevs_inst = (BEC_2_4_8_TimeInterval)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_8_TimeInterval.bevs_inst;
}
}
