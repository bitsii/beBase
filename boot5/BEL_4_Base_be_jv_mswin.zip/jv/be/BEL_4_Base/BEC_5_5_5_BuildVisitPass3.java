package be.BEL_4_Base;
/* IO:File: source/build/Pass3.be */
public class BEC_5_5_5_BuildVisitPass3 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass3() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x33};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x33,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(1));
private static byte[] bels_0 = {0x2D};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_0, 1));
public static BEC_5_5_5_BuildVisitPass3 bevs_inst;
public BEC_5_4_BuildNode bevp_container;
public BEC_4_3_MathInt bevp_nestComment;
public BEC_4_3_MathInt bevp_strqCnt;
public BEC_5_4_BuildNode bevp_goingStr;
public BEC_4_3_MathInt bevp_quoteType;
public BEC_5_4_LogicBool bevp_inLc;
public BEC_5_4_LogicBool bevp_inSpace;
public BEC_5_4_LogicBool bevp_inNl;
public BEC_5_4_LogicBool bevp_inStr;
public BEC_6_6_SystemObject bem_begin_1(BEC_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
bevp_nestComment = (new BEC_4_3_MathInt(0));
bevp_strqCnt = (new BEC_4_3_MathInt(0));
bevp_inLc = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inSpace = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inNl = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_inStr = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_4_BuildNode bevl_toRet = null;
BEC_5_4_BuildNode bevl_xn = null;
BEC_4_3_MathInt bevl_typename = null;
BEC_5_4_BuildNode bevl_nextPeer = null;
BEC_4_3_MathInt bevl_nextPeerTypename = null;
BEC_4_3_MathInt bevl_fsc = null;
BEC_6_6_SystemObject bevl_csc = null;
BEC_6_6_SystemObject bevl_ia = null;
BEC_5_4_BuildNode bevl_vback = null;
BEC_5_4_BuildNode bevl_pre = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_17_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_18_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_19_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_20_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_21_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_22_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_23_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_24_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_25_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_26_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_27_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_28_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_29_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_30_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_31_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_32_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_33_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_34_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_35_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_36_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_37_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_38_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_39_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_40_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_41_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_42_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_43_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_44_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_45_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_46_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_47_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_48_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_49_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_50_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_51_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_52_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_53_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_54_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_55_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_56_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_64_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_72_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_4_3_MathInt bevt_93_tmpvar_phold = null;
BEC_4_3_MathInt bevt_94_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_99_tmpvar_phold = null;
BEC_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_101_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_110_tmpvar_phold = null;
BEC_4_3_MathInt bevt_111_tmpvar_phold = null;
BEC_4_3_MathInt bevt_112_tmpvar_phold = null;
BEC_4_3_MathInt bevt_113_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_119_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_4_3_MathInt bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_125_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_126_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_131_tmpvar_phold = null;
BEC_4_3_MathInt bevt_132_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_133_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_134_tmpvar_phold = null;
BEC_4_3_MathInt bevt_135_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_136_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_137_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_138_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_139_tmpvar_phold = null;
BEC_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_4_3_MathInt bevt_141_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_142_tmpvar_phold = null;
BEC_4_3_MathInt bevt_143_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_144_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_145_tmpvar_phold = null;
BEC_4_3_MathInt bevt_146_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_147_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_148_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_149_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_150_tmpvar_phold = null;
BEC_4_3_MathInt bevt_151_tmpvar_phold = null;
BEC_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_153_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_154_tmpvar_phold = null;
BEC_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_4_3_MathInt bevt_156_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_157_tmpvar_phold = null;
BEC_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_4_3_MathInt bevt_159_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_160_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_161_tmpvar_phold = null;
BEC_4_3_MathInt bevt_162_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_163_tmpvar_phold = null;
BEC_4_6_TextString bevt_164_tmpvar_phold = null;
BEC_4_6_TextString bevt_165_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_167_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_168_tmpvar_phold = null;
BEC_4_3_MathInt bevt_169_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_170_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_171_tmpvar_phold = null;
BEC_4_3_MathInt bevt_172_tmpvar_phold = null;
BEC_4_3_MathInt bevt_173_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_175_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_176_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_177_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_178_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_179_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_180_tmpvar_phold = null;
BEC_4_3_MathInt bevt_181_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_182_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_183_tmpvar_phold = null;
BEC_4_3_MathInt bevt_184_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_185_tmpvar_phold = null;
BEC_4_3_MathInt bevt_186_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_187_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_190_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_191_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_192_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_193_tmpvar_phold = null;
BEC_4_3_MathInt bevt_194_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_196_tmpvar_phold = null;
BEC_4_3_MathInt bevt_197_tmpvar_phold = null;
BEC_4_3_MathInt bevt_198_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_199_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_200_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_202_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_203_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_204_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_205_tmpvar_phold = null;
BEC_4_3_MathInt bevt_206_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_207_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_208_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_209_tmpvar_phold = null;
BEC_4_3_MathInt bevt_210_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_211_tmpvar_phold = null;
BEC_4_3_MathInt bevt_212_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_216_tmpvar_phold = null;
BEC_4_3_MathInt bevt_217_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_218_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_219_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_220_tmpvar_phold = null;
BEC_4_3_MathInt bevt_221_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_222_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_223_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_224_tmpvar_phold = null;
BEC_4_3_MathInt bevt_225_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_226_tmpvar_phold = null;
BEC_4_3_MathInt bevt_227_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_228_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_231_tmpvar_phold = null;
BEC_4_3_MathInt bevt_232_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_233_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_234_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_235_tmpvar_phold = null;
BEC_4_3_MathInt bevt_236_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_237_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_4_3_MathInt bevt_239_tmpvar_phold = null;
BEC_4_3_MathInt bevt_240_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_241_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_242_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_243_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_244_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_245_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_246_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_247_tmpvar_phold = null;
BEC_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_249_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_250_tmpvar_phold = null;
BEC_4_3_MathInt bevt_251_tmpvar_phold = null;
BEC_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_253_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_254_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_255_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_256_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_257_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_258_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_259_tmpvar_phold = null;
BEC_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_261_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_4_3_MathInt bevt_263_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_265_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_266_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_267_tmpvar_phold = null;
BEC_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_269_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_270_tmpvar_phold = null;
BEC_4_3_MathInt bevt_271_tmpvar_phold = null;
BEC_4_3_MathInt bevt_272_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_273_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_274_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_275_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_276_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_277_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_278_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_279_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_280_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_281_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_282_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_283_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_284_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_285_tmpvar_phold = null;
BEC_4_3_MathInt bevt_286_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_287_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_288_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_289_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_290_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_291_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_292_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_293_tmpvar_phold = null;
BEC_4_3_MathInt bevt_294_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_295_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_296_tmpvar_phold = null;
BEC_4_3_MathInt bevt_297_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_298_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_299_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_300_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_301_tmpvar_phold = null;
BEC_4_3_MathInt bevt_302_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_303_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_304_tmpvar_phold = null;
BEC_4_3_MathInt bevt_305_tmpvar_phold = null;
BEC_4_3_MathInt bevt_306_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_307_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_308_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_309_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_310_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_311_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_312_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_313_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_314_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_315_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_316_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_317_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_318_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_319_tmpvar_phold = null;
BEC_4_3_MathInt bevt_320_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_321_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_322_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_323_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_324_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_325_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_326_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_327_tmpvar_phold = null;
BEC_4_3_MathInt bevt_328_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_329_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_330_tmpvar_phold = null;
BEC_4_3_MathInt bevt_331_tmpvar_phold = null;
BEC_4_3_MathInt bevt_332_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_333_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_334_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_335_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_336_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_337_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_338_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_339_tmpvar_phold = null;
BEC_4_3_MathInt bevt_340_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_341_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_342_tmpvar_phold = null;
BEC_4_3_MathInt bevt_343_tmpvar_phold = null;
BEC_4_3_MathInt bevt_344_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_345_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_346_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_347_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_348_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_349_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_350_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_351_tmpvar_phold = null;
BEC_4_3_MathInt bevt_352_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_353_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_354_tmpvar_phold = null;
BEC_4_3_MathInt bevt_355_tmpvar_phold = null;
BEC_4_3_MathInt bevt_356_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_357_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_358_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_359_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_360_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_361_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_362_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_363_tmpvar_phold = null;
BEC_4_3_MathInt bevt_364_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_365_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_366_tmpvar_phold = null;
BEC_4_3_MathInt bevt_367_tmpvar_phold = null;
BEC_4_3_MathInt bevt_368_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_369_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_370_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_371_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_372_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_373_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_374_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_375_tmpvar_phold = null;
BEC_4_3_MathInt bevt_376_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_377_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_378_tmpvar_phold = null;
BEC_4_3_MathInt bevt_379_tmpvar_phold = null;
BEC_4_3_MathInt bevt_380_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_381_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_382_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_383_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_384_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_385_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_386_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_387_tmpvar_phold = null;
BEC_4_3_MathInt bevt_388_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_389_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_390_tmpvar_phold = null;
BEC_4_3_MathInt bevt_391_tmpvar_phold = null;
BEC_4_3_MathInt bevt_392_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_393_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_394_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_395_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_396_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_397_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_398_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_399_tmpvar_phold = null;
BEC_4_3_MathInt bevt_400_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_401_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_402_tmpvar_phold = null;
BEC_4_3_MathInt bevt_403_tmpvar_phold = null;
BEC_4_3_MathInt bevt_404_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_405_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_406_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_407_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_408_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_409_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_410_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_411_tmpvar_phold = null;
BEC_4_3_MathInt bevt_412_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_413_tmpvar_phold = null;
BEC_4_3_MathInt bevt_414_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_415_tmpvar_phold = null;
bevl_typename = beva_node.bem_typenameGet_0();
bevl_nextPeer = beva_node.bem_nextPeerGet_0();
if (bevl_nextPeer == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevl_nextPeerTypename = bevl_nextPeer.bem_typenameGet_0();
} /* Line: 56 */
bevt_59_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_58_tmpvar_phold = bevl_typename.bem_equals_1(bevt_59_tmpvar_phold);
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 60 */ {
if (bevl_nextPeer == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_62_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_61_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_62_tmpvar_phold);
if (bevt_61_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevt_63_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 60 */ {
bevp_nestComment = bevp_nestComment.bem_increment_0();
bevt_64_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_64_tmpvar_phold.bem_nextDescendGet_0();
bevt_65_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_65_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 66 */
bevt_67_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_66_tmpvar_phold = bevl_typename.bem_equals_1(bevt_67_tmpvar_phold);
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 68 */ {
if (bevl_nextPeer == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 68 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 68 */
 else  /* Line: 68 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 68 */ {
bevt_70_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_69_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_70_tmpvar_phold);
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 68 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 68 */
 else  /* Line: 68 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 68 */ {
bevt_71_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 68 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 68 */
 else  /* Line: 68 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 68 */ {
bevp_nestComment = bevp_nestComment.bem_decrement_0();
bevt_72_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_72_tmpvar_phold.bem_nextDescendGet_0();
bevt_73_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_73_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 74 */
bevt_75_tmpvar_phold = bevo_0;
bevt_74_tmpvar_phold = bevp_nestComment.bem_greater_1(bevt_75_tmpvar_phold);
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 79 */
bevt_76_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_77_tmpvar_phold = bevp_inLc.bem_not_0();
if (bevt_77_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevt_79_tmpvar_phold = bevp_ntypes.bem_STRQGet_0();
bevt_78_tmpvar_phold = bevl_typename.bem_equals_1(bevt_79_tmpvar_phold);
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_81_tmpvar_phold = bevp_ntypes.bem_WSTRQGet_0();
bevt_80_tmpvar_phold = bevl_typename.bem_equals_1(bevt_81_tmpvar_phold);
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 81 */ {
bevl_xn = beva_node.bem_nextPeerGet_0();
bevp_strqCnt = (new BEC_4_3_MathInt(1));
bevp_quoteType = beva_node.bem_typenameGet_0();
while (true)
 /* Line: 85 */ {
if (bevl_xn == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevt_84_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_equals_1(bevp_quoteType);
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 85 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
 else  /* Line: 85 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 85 */ {
bevp_strqCnt = bevp_strqCnt.bem_increment_0();
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 88 */
 else  /* Line: 85 */ {
break;
} /* Line: 85 */
} /* Line: 85 */
bevt_86_tmpvar_phold = bevo_1;
bevt_85_tmpvar_phold = bevp_strqCnt.bem_equals_1(bevt_86_tmpvar_phold);
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 90 */ {
bevp_strqCnt = (new BEC_4_3_MathInt(0));
bevt_87_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
beva_node.bem_heldSet_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
beva_node.bem_typenameSet_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (new BEC_4_3_MathInt(1));
beva_node.bem_typeDetailSet_1(bevt_89_tmpvar_phold);
} /* Line: 94 */
 else  /* Line: 95 */ {
bevp_inStr = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_goingStr = beva_node;
bevt_90_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
beva_node.bem_heldSet_1(bevt_90_tmpvar_phold);
bevt_92_tmpvar_phold = bevp_ntypes.bem_WSTRQGet_0();
bevt_91_tmpvar_phold = bevl_typename.bem_equals_1(bevt_92_tmpvar_phold);
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_93_tmpvar_phold = bevp_ntypes.bem_WSTRINGLGet_0();
bevp_goingStr.bem_typenameSet_1(bevt_93_tmpvar_phold);
} /* Line: 101 */
 else  /* Line: 102 */ {
bevt_94_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevp_goingStr.bem_typenameSet_1(bevt_94_tmpvar_phold);
} /* Line: 103 */
} /* Line: 99 */
return bevl_xn;
} /* Line: 106 */
if (bevp_inStr.bevi_bool) /* Line: 108 */ {
bevt_95_tmpvar_phold = bevp_inLc.bem_not_0();
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 108 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
 else  /* Line: 108 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 108 */ {
bevt_97_tmpvar_phold = bevp_goingStr.bem_typenameGet_0();
bevt_98_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_96_tmpvar_phold = bevt_97_tmpvar_phold.bem_equals_1(bevt_98_tmpvar_phold);
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_100_tmpvar_phold = bevp_ntypes.bem_FSLASHGet_0();
bevt_99_tmpvar_phold = bevl_typename.bem_equals_1(bevt_100_tmpvar_phold);
if (bevt_99_tmpvar_phold.bevi_bool) /* Line: 109 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 109 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 109 */
 else  /* Line: 109 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 109 */ {
beva_node.bem_delayDelete_0();
bevl_xn = beva_node.bem_nextPeerGet_0();
bevl_fsc = (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 113 */ {
if (bevl_xn == null) {
bevt_101_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_101_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_101_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_103_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_104_tmpvar_phold = bevp_ntypes.bem_FSLASHGet_0();
bevt_102_tmpvar_phold = bevt_103_tmpvar_phold.bem_equals_1(bevt_104_tmpvar_phold);
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 113 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 113 */
 else  /* Line: 113 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 113 */ {
bevl_fsc = bevl_fsc.bem_increment_0();
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 116 */
 else  /* Line: 113 */ {
break;
} /* Line: 113 */
} /* Line: 113 */
bevl_ia = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 118 */ {
bevt_105_tmpvar_phold = bevl_ia.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fsc);
if (bevt_105_tmpvar_phold != null && bevt_105_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_105_tmpvar_phold).bevi_bool) /* Line: 118 */ {
bevt_107_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_108_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_108_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_106_tmpvar_phold);
bevl_ia = bevl_ia.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 118 */
 else  /* Line: 118 */ {
break;
} /* Line: 118 */
} /* Line: 118 */
if (bevl_xn == null) {
bevt_109_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_109_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_112_tmpvar_phold = bevo_2;
bevt_111_tmpvar_phold = bevl_fsc.bem_modulus_1(bevt_112_tmpvar_phold);
bevt_113_tmpvar_phold = bevo_3;
bevt_110_tmpvar_phold = bevt_111_tmpvar_phold.bem_equals_1(bevt_113_tmpvar_phold);
if (bevt_110_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 121 */ {
bevt_115_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_114_tmpvar_phold = bevt_115_tmpvar_phold.bem_equals_1(bevp_quoteType);
if (bevt_114_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 121 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 121 */
 else  /* Line: 121 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 121 */ {
bevl_xn.bem_delayDelete_0();
bevt_117_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_118_tmpvar_phold = bevl_xn.bem_heldGet_0();
bevt_116_tmpvar_phold = bevt_117_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_118_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_116_tmpvar_phold);
bevl_xn = bevl_xn.bem_nextDescendGet_0();
} /* Line: 124 */
return bevl_xn;
} /* Line: 126 */
 else  /* Line: 109 */ {
bevt_119_tmpvar_phold = bevl_typename.bem_equals_1(bevp_quoteType);
if (bevt_119_tmpvar_phold.bevi_bool) /* Line: 127 */ {
beva_node.bem_delayDelete_0();
bevl_xn = beva_node.bem_nextPeerGet_0();
bevl_csc = (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 131 */ {
if (bevl_xn == null) {
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevt_122_tmpvar_phold = bevl_xn.bem_typenameGet_0();
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bem_equals_1(bevp_quoteType);
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
 else  /* Line: 131 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 131 */ {
bevl_csc = bevl_csc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 134 */
 else  /* Line: 131 */ {
break;
} /* Line: 131 */
} /* Line: 131 */
bevt_123_tmpvar_phold = bevl_csc.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_strqCnt);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevp_goingStr.bem_typeDetailSet_1(bevp_strqCnt);
bevp_strqCnt = (new BEC_4_3_MathInt(0));
bevp_goingStr = null;
bevp_inStr = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 140 */
 else  /* Line: 141 */ {
bevl_ia = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 142 */ {
bevt_124_tmpvar_phold = bevl_ia.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_csc);
if (bevt_124_tmpvar_phold != null && bevt_124_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_124_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevt_126_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_127_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_125_tmpvar_phold = bevt_126_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_127_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_125_tmpvar_phold);
bevl_ia = bevl_ia.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 142 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
} /* Line: 142 */
return bevl_xn;
} /* Line: 146 */
 else  /* Line: 147 */ {
bevt_129_tmpvar_phold = bevp_goingStr.bem_heldGet_0();
bevt_130_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_130_tmpvar_phold);
bevp_goingStr.bem_heldSet_1(bevt_128_tmpvar_phold);
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 151 */
} /* Line: 109 */
} /* Line: 109 */
bevt_132_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_131_tmpvar_phold = bevl_typename.bem_equals_1(bevt_132_tmpvar_phold);
if (bevt_131_tmpvar_phold.bevi_bool) /* Line: 154 */ {
if (bevl_nextPeer == null) {
bevt_133_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_133_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_133_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_17_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_17_tmpvar_anchor.bevi_bool) /* Line: 154 */ {
bevt_135_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_134_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_135_tmpvar_phold);
if (bevt_134_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 154 */ {
bevt_136_tmpvar_phold = bevp_inStr.bem_not_0();
if (bevt_136_tmpvar_phold.bevi_bool) /* Line: 154 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 154 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 154 */
 else  /* Line: 154 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 154 */ {
bevt_137_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_137_tmpvar_phold.bem_nextDescendGet_0();
bevp_inLc = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_138_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_138_tmpvar_phold.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 159 */
if (bevp_inLc.bevi_bool) /* Line: 161 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
bevt_140_tmpvar_phold = bevl_toRet.bem_typenameGet_0();
bevt_141_tmpvar_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevt_139_tmpvar_phold = bevt_140_tmpvar_phold.bem_equals_1(bevt_141_tmpvar_phold);
if (bevt_139_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevp_inLc = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_toRet.bem_delayDelete_0();
bevl_toRet = bevl_toRet.bem_nextDescendGet_0();
} /* Line: 167 */
return bevl_toRet;
} /* Line: 169 */
bevt_143_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_142_tmpvar_phold = bevl_typename.bem_equals_1(bevt_143_tmpvar_phold);
if (bevt_142_tmpvar_phold.bevi_bool) /* Line: 171 */ {
if (bevl_nextPeer == null) {
bevt_144_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_144_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_144_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
 else  /* Line: 171 */ {
bevt_19_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_19_tmpvar_anchor.bevi_bool) /* Line: 171 */ {
bevt_146_tmpvar_phold = bevp_ntypes.bem_INTLGet_0();
bevt_145_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_146_tmpvar_phold);
if (bevt_145_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
 else  /* Line: 171 */ {
bevt_18_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_18_tmpvar_anchor.bevi_bool) /* Line: 171 */ {
bevt_148_tmpvar_phold = beva_node.bem_priorPeerGet_0();
if (bevt_148_tmpvar_phold == null) {
bevt_147_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_147_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_147_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevl_vback = beva_node.bem_priorPeerGet_0();
while (true)
 /* Line: 174 */ {
if (bevl_vback == null) {
bevt_149_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_149_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_149_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_151_tmpvar_phold = bevl_vback.bem_typenameGet_0();
bevt_152_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bem_equals_1(bevt_152_tmpvar_phold);
if (bevt_150_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 174 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 174 */
 else  /* Line: 174 */ {
bevt_20_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_20_tmpvar_anchor.bevi_bool) /* Line: 174 */ {
bevl_vback = bevl_vback.bem_priorPeerGet_0();
} /* Line: 175 */
 else  /* Line: 174 */ {
break;
} /* Line: 174 */
} /* Line: 174 */
bevl_pre = bevl_vback;
} /* Line: 177 */
if (bevl_pre == null) {
bevt_153_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_153_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_153_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_155_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_156_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_154_tmpvar_phold = bevt_155_tmpvar_phold.bem_equals_1(bevt_156_tmpvar_phold);
if (bevt_154_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_23_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
if (bevt_23_tmpvar_anchor.bevi_bool) /* Line: 180 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_158_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_159_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_157_tmpvar_phold = bevt_158_tmpvar_phold.bem_equals_1(bevt_159_tmpvar_phold);
if (bevt_157_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_22_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
if (bevt_22_tmpvar_anchor.bevi_bool) /* Line: 180 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_161_tmpvar_phold = bevp_const.bem_operGet_0();
bevt_162_tmpvar_phold = bevl_pre.bem_typenameGet_0();
bevt_160_tmpvar_phold = bevt_161_tmpvar_phold.bem_has_1(bevt_162_tmpvar_phold);
if (bevt_160_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_21_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
if (bevt_21_tmpvar_anchor.bevi_bool) /* Line: 180 */ {
bevt_163_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_165_tmpvar_phold = bevo_4;
bevt_167_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_166_tmpvar_phold = bevt_167_tmpvar_phold.bem_heldGet_0();
bevt_164_tmpvar_phold = bevt_165_tmpvar_phold.bem_add_1(bevt_166_tmpvar_phold);
bevt_163_tmpvar_phold.bem_heldSet_1(bevt_164_tmpvar_phold);
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 186 */
} /* Line: 180 */
bevt_169_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_168_tmpvar_phold = bevl_typename.bem_equals_1(bevt_169_tmpvar_phold);
if (bevt_168_tmpvar_phold.bevi_bool) /* Line: 189 */ {
if (bevl_nextPeer == null) {
bevt_170_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_170_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_170_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
 else  /* Line: 189 */ {
bevt_25_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_25_tmpvar_anchor.bevi_bool) /* Line: 189 */ {
bevt_172_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_171_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_172_tmpvar_phold);
if (bevt_171_tmpvar_phold.bevi_bool) /* Line: 189 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 189 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 189 */
 else  /* Line: 189 */ {
bevt_24_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_24_tmpvar_anchor.bevi_bool) /* Line: 189 */ {
bevt_173_tmpvar_phold = bevp_ntypes.bem_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_173_tmpvar_phold);
bevt_175_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_177_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_176_tmpvar_phold = bevt_177_tmpvar_phold.bem_heldGet_0();
bevt_174_tmpvar_phold = bevt_175_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_176_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_174_tmpvar_phold);
bevt_178_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_178_tmpvar_phold.bem_nextDescendGet_0();
bevt_179_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_179_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 194 */
bevt_181_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_180_tmpvar_phold = bevl_typename.bem_equals_1(bevt_181_tmpvar_phold);
if (bevt_180_tmpvar_phold.bevi_bool) /* Line: 196 */ {
if (bevl_nextPeer == null) {
bevt_182_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_182_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_182_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_27_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_27_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_184_tmpvar_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_183_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_184_tmpvar_phold);
if (bevt_183_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_186_tmpvar_phold = bevp_ntypes.bem_MANYGet_0();
bevt_185_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_186_tmpvar_phold);
if (bevt_185_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
if (bevt_26_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_26_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_26_tmpvar_anchor.bevi_bool) /* Line: 196 */ {
bevt_188_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_190_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_189_tmpvar_phold = bevt_190_tmpvar_phold.bem_heldGet_0();
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_189_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_187_tmpvar_phold);
bevt_191_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_191_tmpvar_phold.bem_nextDescendGet_0();
bevt_192_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_192_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 201 */
bevt_194_tmpvar_phold = bevp_ntypes.bem_NOTGet_0();
bevt_193_tmpvar_phold = bevl_typename.bem_equals_1(bevt_194_tmpvar_phold);
if (bevt_193_tmpvar_phold.bevi_bool) /* Line: 203 */ {
if (bevl_nextPeer == null) {
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_195_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_195_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 203 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 203 */
 else  /* Line: 203 */ {
bevt_29_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_29_tmpvar_anchor.bevi_bool) /* Line: 203 */ {
bevt_197_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_196_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_197_tmpvar_phold);
if (bevt_196_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 203 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 203 */
 else  /* Line: 203 */ {
bevt_28_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_28_tmpvar_anchor.bevi_bool) /* Line: 203 */ {
bevt_198_tmpvar_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_198_tmpvar_phold);
bevt_200_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_202_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_201_tmpvar_phold = bevt_202_tmpvar_phold.bem_heldGet_0();
bevt_199_tmpvar_phold = bevt_200_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_201_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_199_tmpvar_phold);
bevt_203_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_203_tmpvar_phold.bem_nextDescendGet_0();
bevt_204_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_204_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 208 */
bevt_206_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_205_tmpvar_phold = bevl_typename.bem_equals_1(bevt_206_tmpvar_phold);
if (bevt_205_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_208_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_208_tmpvar_phold == null) {
bevt_207_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_207_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_207_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_211_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bem_typenameGet_0();
bevt_212_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_209_tmpvar_phold = bevt_210_tmpvar_phold.bem_equals_1(bevt_212_tmpvar_phold);
if (bevt_209_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 211 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 211 */
 else  /* Line: 211 */ {
bevt_30_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_30_tmpvar_anchor.bevi_bool) /* Line: 211 */ {
bevt_214_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_216_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bem_heldGet_0();
bevt_213_tmpvar_phold = bevt_214_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_215_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_213_tmpvar_phold);
bevt_217_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
beva_node.bem_typenameSet_1(bevt_217_tmpvar_phold);
bevt_218_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_218_tmpvar_phold.bem_nextDescendGet_0();
bevt_219_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_219_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 216 */
} /* Line: 211 */
bevt_221_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_220_tmpvar_phold = bevl_typename.bem_equals_1(bevt_221_tmpvar_phold);
if (bevt_220_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevt_223_tmpvar_phold = beva_node.bem_nextPeerGet_0();
if (bevt_223_tmpvar_phold == null) {
bevt_222_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_222_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_222_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_226_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bem_typenameGet_0();
bevt_227_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_224_tmpvar_phold = bevt_225_tmpvar_phold.bem_equals_1(bevt_227_tmpvar_phold);
if (bevt_224_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_31_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_31_tmpvar_anchor.bevi_bool) /* Line: 220 */ {
bevt_229_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_231_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_230_tmpvar_phold = bevt_231_tmpvar_phold.bem_heldGet_0();
bevt_228_tmpvar_phold = bevt_229_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_230_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_228_tmpvar_phold);
bevt_232_tmpvar_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
beva_node.bem_typenameSet_1(bevt_232_tmpvar_phold);
bevt_233_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_233_tmpvar_phold.bem_nextDescendGet_0();
bevt_234_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_234_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 225 */
} /* Line: 220 */
bevt_236_tmpvar_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_235_tmpvar_phold = bevl_typename.bem_equals_1(bevt_236_tmpvar_phold);
if (bevt_235_tmpvar_phold.bevi_bool) /* Line: 228 */ {
if (bevl_nextPeer == null) {
bevt_237_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_237_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_237_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_33_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_33_tmpvar_anchor.bevi_bool) /* Line: 228 */ {
bevt_239_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_238_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_239_tmpvar_phold);
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 228 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 228 */
 else  /* Line: 228 */ {
bevt_32_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_32_tmpvar_anchor.bevi_bool) /* Line: 228 */ {
bevt_240_tmpvar_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_240_tmpvar_phold);
bevt_242_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_244_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_243_tmpvar_phold = bevt_244_tmpvar_phold.bem_heldGet_0();
bevt_241_tmpvar_phold = bevt_242_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_243_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_241_tmpvar_phold);
bevt_245_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_245_tmpvar_phold.bem_nextDescendGet_0();
bevt_246_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_246_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 233 */
bevt_248_tmpvar_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_247_tmpvar_phold = bevl_typename.bem_equals_1(bevt_248_tmpvar_phold);
if (bevt_247_tmpvar_phold.bevi_bool) /* Line: 235 */ {
if (bevl_nextPeer == null) {
bevt_249_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_249_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_249_tmpvar_phold.bevi_bool) /* Line: 235 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_35_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_35_tmpvar_anchor.bevi_bool) /* Line: 235 */ {
bevt_251_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_250_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_251_tmpvar_phold);
if (bevt_250_tmpvar_phold.bevi_bool) /* Line: 235 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_34_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_34_tmpvar_anchor.bevi_bool) /* Line: 235 */ {
bevt_252_tmpvar_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_252_tmpvar_phold);
bevt_254_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_256_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_255_tmpvar_phold = bevt_256_tmpvar_phold.bem_heldGet_0();
bevt_253_tmpvar_phold = bevt_254_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_255_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_253_tmpvar_phold);
bevt_257_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_257_tmpvar_phold.bem_nextDescendGet_0();
bevt_258_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_258_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 240 */
bevt_260_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_259_tmpvar_phold = bevl_typename.bem_equals_1(bevt_260_tmpvar_phold);
if (bevt_259_tmpvar_phold.bevi_bool) /* Line: 242 */ {
if (bevl_nextPeer == null) {
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_261_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_37_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_37_tmpvar_anchor.bevi_bool) /* Line: 242 */ {
bevt_263_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_262_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_263_tmpvar_phold);
if (bevt_262_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_36_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_36_tmpvar_anchor.bevi_bool) /* Line: 242 */ {
bevt_266_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_265_tmpvar_phold = bevt_266_tmpvar_phold.bem_nextPeerGet_0();
if (bevt_265_tmpvar_phold == null) {
bevt_264_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_264_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_264_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_270_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bem_nextPeerGet_0();
bevt_268_tmpvar_phold = bevt_269_tmpvar_phold.bem_typenameGet_0();
bevt_271_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_267_tmpvar_phold = bevt_268_tmpvar_phold.bem_equals_1(bevt_271_tmpvar_phold);
if (bevt_267_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_38_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_38_tmpvar_anchor.bevi_bool) /* Line: 243 */ {
bevt_272_tmpvar_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_272_tmpvar_phold);
bevt_275_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_277_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_276_tmpvar_phold = bevt_277_tmpvar_phold.bem_heldGet_0();
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_276_tmpvar_phold);
bevt_280_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_279_tmpvar_phold = bevt_280_tmpvar_phold.bem_nextPeerGet_0();
bevt_278_tmpvar_phold = bevt_279_tmpvar_phold.bem_heldGet_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_278_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_273_tmpvar_phold);
bevt_282_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_281_tmpvar_phold = bevt_282_tmpvar_phold.bem_nextPeerGet_0();
bevl_toRet = bevt_281_tmpvar_phold.bem_nextDescendGet_0();
bevt_283_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_283_tmpvar_phold.bem_delayDelete_0();
bevt_285_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_284_tmpvar_phold = bevt_285_tmpvar_phold.bem_nextPeerGet_0();
bevt_284_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 249 */
bevt_286_tmpvar_phold = bevp_ntypes.bem_INCREMENTGet_0();
beva_node.bem_typenameSet_1(bevt_286_tmpvar_phold);
bevt_288_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_290_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_289_tmpvar_phold = bevt_290_tmpvar_phold.bem_heldGet_0();
bevt_287_tmpvar_phold = bevt_288_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_289_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_287_tmpvar_phold);
bevt_291_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_291_tmpvar_phold.bem_nextDescendGet_0();
bevt_292_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_292_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 255 */
bevt_294_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_293_tmpvar_phold = bevl_typename.bem_equals_1(bevt_294_tmpvar_phold);
if (bevt_293_tmpvar_phold.bevi_bool) /* Line: 257 */ {
if (bevl_nextPeer == null) {
bevt_295_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_295_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_295_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 257 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 257 */
 else  /* Line: 257 */ {
bevt_40_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_40_tmpvar_anchor.bevi_bool) /* Line: 257 */ {
bevt_297_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_296_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_297_tmpvar_phold);
if (bevt_296_tmpvar_phold.bevi_bool) /* Line: 257 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 257 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 257 */
 else  /* Line: 257 */ {
bevt_39_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_39_tmpvar_anchor.bevi_bool) /* Line: 257 */ {
bevt_300_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_299_tmpvar_phold = bevt_300_tmpvar_phold.bem_nextPeerGet_0();
if (bevt_299_tmpvar_phold == null) {
bevt_298_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_298_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_298_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_304_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_303_tmpvar_phold = bevt_304_tmpvar_phold.bem_nextPeerGet_0();
bevt_302_tmpvar_phold = bevt_303_tmpvar_phold.bem_typenameGet_0();
bevt_305_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_301_tmpvar_phold = bevt_302_tmpvar_phold.bem_equals_1(bevt_305_tmpvar_phold);
if (bevt_301_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 258 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 258 */
 else  /* Line: 258 */ {
bevt_41_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_41_tmpvar_anchor.bevi_bool) /* Line: 258 */ {
bevt_306_tmpvar_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_306_tmpvar_phold);
bevt_309_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_311_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_310_tmpvar_phold = bevt_311_tmpvar_phold.bem_heldGet_0();
bevt_308_tmpvar_phold = bevt_309_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_310_tmpvar_phold);
bevt_314_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_313_tmpvar_phold = bevt_314_tmpvar_phold.bem_nextPeerGet_0();
bevt_312_tmpvar_phold = bevt_313_tmpvar_phold.bem_heldGet_0();
bevt_307_tmpvar_phold = bevt_308_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_312_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_307_tmpvar_phold);
bevt_316_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_315_tmpvar_phold = bevt_316_tmpvar_phold.bem_nextPeerGet_0();
bevl_toRet = bevt_315_tmpvar_phold.bem_nextDescendGet_0();
bevt_317_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_317_tmpvar_phold.bem_delayDelete_0();
bevt_319_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_318_tmpvar_phold = bevt_319_tmpvar_phold.bem_nextPeerGet_0();
bevt_318_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 264 */
bevt_320_tmpvar_phold = bevp_ntypes.bem_DECREMENTGet_0();
beva_node.bem_typenameSet_1(bevt_320_tmpvar_phold);
bevt_322_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_324_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_323_tmpvar_phold = bevt_324_tmpvar_phold.bem_heldGet_0();
bevt_321_tmpvar_phold = bevt_322_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_323_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_321_tmpvar_phold);
bevt_325_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_325_tmpvar_phold.bem_nextDescendGet_0();
bevt_326_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_326_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 270 */
bevt_328_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_327_tmpvar_phold = bevl_typename.bem_equals_1(bevt_328_tmpvar_phold);
if (bevt_327_tmpvar_phold.bevi_bool) /* Line: 272 */ {
if (bevl_nextPeer == null) {
bevt_329_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_329_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_329_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_43_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_43_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
bevt_331_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_330_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_331_tmpvar_phold);
if (bevt_330_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
 else  /* Line: 272 */ {
bevt_42_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_42_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
bevt_332_tmpvar_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_332_tmpvar_phold);
bevt_334_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_336_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_335_tmpvar_phold = bevt_336_tmpvar_phold.bem_heldGet_0();
bevt_333_tmpvar_phold = bevt_334_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_335_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_333_tmpvar_phold);
bevt_337_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_337_tmpvar_phold.bem_nextDescendGet_0();
bevt_338_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_338_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 277 */
bevt_340_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_339_tmpvar_phold = bevl_typename.bem_equals_1(bevt_340_tmpvar_phold);
if (bevt_339_tmpvar_phold.bevi_bool) /* Line: 279 */ {
if (bevl_nextPeer == null) {
bevt_341_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_341_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_341_tmpvar_phold.bevi_bool) /* Line: 279 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 279 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 279 */
 else  /* Line: 279 */ {
bevt_45_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_45_tmpvar_anchor.bevi_bool) /* Line: 279 */ {
bevt_343_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_342_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_343_tmpvar_phold);
if (bevt_342_tmpvar_phold.bevi_bool) /* Line: 279 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 279 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 279 */
 else  /* Line: 279 */ {
bevt_44_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_44_tmpvar_anchor.bevi_bool) /* Line: 279 */ {
bevt_344_tmpvar_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_344_tmpvar_phold);
bevt_346_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_348_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_347_tmpvar_phold = bevt_348_tmpvar_phold.bem_heldGet_0();
bevt_345_tmpvar_phold = bevt_346_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_347_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_345_tmpvar_phold);
bevt_349_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_349_tmpvar_phold.bem_nextDescendGet_0();
bevt_350_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_350_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 284 */
bevt_352_tmpvar_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_351_tmpvar_phold = bevl_typename.bem_equals_1(bevt_352_tmpvar_phold);
if (bevt_351_tmpvar_phold.bevi_bool) /* Line: 286 */ {
if (bevl_nextPeer == null) {
bevt_353_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_353_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_353_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_47_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_47_tmpvar_anchor.bevi_bool) /* Line: 286 */ {
bevt_355_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_354_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_355_tmpvar_phold);
if (bevt_354_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 286 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 286 */
 else  /* Line: 286 */ {
bevt_46_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_46_tmpvar_anchor.bevi_bool) /* Line: 286 */ {
bevt_356_tmpvar_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_356_tmpvar_phold);
bevt_358_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_360_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_359_tmpvar_phold = bevt_360_tmpvar_phold.bem_heldGet_0();
bevt_357_tmpvar_phold = bevt_358_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_359_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_357_tmpvar_phold);
bevt_361_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_361_tmpvar_phold.bem_nextDescendGet_0();
bevt_362_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_362_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 291 */
bevt_364_tmpvar_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_363_tmpvar_phold = bevl_typename.bem_equals_1(bevt_364_tmpvar_phold);
if (bevt_363_tmpvar_phold.bevi_bool) /* Line: 293 */ {
if (bevl_nextPeer == null) {
bevt_365_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_365_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_365_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 293 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 293 */
 else  /* Line: 293 */ {
bevt_49_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_49_tmpvar_anchor.bevi_bool) /* Line: 293 */ {
bevt_367_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_366_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_367_tmpvar_phold);
if (bevt_366_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 293 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 293 */
 else  /* Line: 293 */ {
bevt_48_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_48_tmpvar_anchor.bevi_bool) /* Line: 293 */ {
bevt_368_tmpvar_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_368_tmpvar_phold);
bevt_370_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_372_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_371_tmpvar_phold = bevt_372_tmpvar_phold.bem_heldGet_0();
bevt_369_tmpvar_phold = bevt_370_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_371_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_369_tmpvar_phold);
bevt_373_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_373_tmpvar_phold.bem_nextDescendGet_0();
bevt_374_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_374_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 298 */
bevt_376_tmpvar_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_375_tmpvar_phold = bevl_typename.bem_equals_1(bevt_376_tmpvar_phold);
if (bevt_375_tmpvar_phold.bevi_bool) /* Line: 300 */ {
if (bevl_nextPeer == null) {
bevt_377_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_377_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_377_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_51_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_51_tmpvar_anchor.bevi_bool) /* Line: 300 */ {
bevt_379_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_378_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_379_tmpvar_phold);
if (bevt_378_tmpvar_phold.bevi_bool) /* Line: 300 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 300 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 300 */
 else  /* Line: 300 */ {
bevt_50_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_50_tmpvar_anchor.bevi_bool) /* Line: 300 */ {
bevt_380_tmpvar_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_380_tmpvar_phold);
bevt_382_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_384_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_383_tmpvar_phold = bevt_384_tmpvar_phold.bem_heldGet_0();
bevt_381_tmpvar_phold = bevt_382_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_383_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_381_tmpvar_phold);
bevt_385_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_385_tmpvar_phold.bem_nextDescendGet_0();
bevt_386_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_386_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 305 */
bevt_388_tmpvar_phold = bevp_ntypes.bem_ANDGet_0();
bevt_387_tmpvar_phold = bevl_typename.bem_equals_1(bevt_388_tmpvar_phold);
if (bevt_387_tmpvar_phold.bevi_bool) /* Line: 307 */ {
if (bevl_nextPeer == null) {
bevt_389_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_389_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_389_tmpvar_phold.bevi_bool) /* Line: 307 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 307 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 307 */
 else  /* Line: 307 */ {
bevt_53_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_53_tmpvar_anchor.bevi_bool) /* Line: 307 */ {
bevt_391_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_390_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_391_tmpvar_phold);
if (bevt_390_tmpvar_phold.bevi_bool) /* Line: 307 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 307 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 307 */
 else  /* Line: 307 */ {
bevt_52_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_52_tmpvar_anchor.bevi_bool) /* Line: 307 */ {
bevt_392_tmpvar_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_392_tmpvar_phold);
bevt_394_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_396_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_395_tmpvar_phold = bevt_396_tmpvar_phold.bem_heldGet_0();
bevt_393_tmpvar_phold = bevt_394_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_395_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_393_tmpvar_phold);
bevt_397_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_397_tmpvar_phold.bem_nextDescendGet_0();
bevt_398_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_398_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 312 */
bevt_400_tmpvar_phold = bevp_ntypes.bem_ORGet_0();
bevt_399_tmpvar_phold = bevl_typename.bem_equals_1(bevt_400_tmpvar_phold);
if (bevt_399_tmpvar_phold.bevi_bool) /* Line: 314 */ {
if (bevl_nextPeer == null) {
bevt_401_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_401_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_401_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
 else  /* Line: 314 */ {
bevt_55_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_55_tmpvar_anchor.bevi_bool) /* Line: 314 */ {
bevt_403_tmpvar_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_402_tmpvar_phold = bevl_nextPeerTypename.bem_equals_1(bevt_403_tmpvar_phold);
if (bevt_402_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
 else  /* Line: 314 */ {
bevt_54_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_54_tmpvar_anchor.bevi_bool) /* Line: 314 */ {
bevt_404_tmpvar_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_404_tmpvar_phold);
bevt_406_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_408_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_407_tmpvar_phold = bevt_408_tmpvar_phold.bem_heldGet_0();
bevt_405_tmpvar_phold = bevt_406_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_407_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_405_tmpvar_phold);
bevt_409_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_409_tmpvar_phold.bem_nextDescendGet_0();
bevt_410_tmpvar_phold = beva_node.bem_nextPeerGet_0();
bevt_410_tmpvar_phold.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 319 */
bevt_412_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevt_411_tmpvar_phold = bevl_typename.bem_equals_1(bevt_412_tmpvar_phold);
if (bevt_411_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_414_tmpvar_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevt_413_tmpvar_phold = bevl_typename.bem_equals_1(bevt_414_tmpvar_phold);
if (bevt_413_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 321 */ {
bevt_56_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 321 */
if (bevt_56_tmpvar_anchor.bevi_bool) /* Line: 321 */ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 324 */
bevt_415_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_415_tmpvar_phold;
} /*method end*/
public BEC_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_6_6_SystemObject bem_containerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_container = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_nestCommentGet_0() throws Throwable {
return bevp_nestComment;
} /*method end*/
public BEC_6_6_SystemObject bem_nestCommentSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nestComment = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_strqCntGet_0() throws Throwable {
return bevp_strqCnt;
} /*method end*/
public BEC_6_6_SystemObject bem_strqCntSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_strqCnt = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_goingStrGet_0() throws Throwable {
return bevp_goingStr;
} /*method end*/
public BEC_6_6_SystemObject bem_goingStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_goingStr = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_quoteTypeGet_0() throws Throwable {
return bevp_quoteType;
} /*method end*/
public BEC_6_6_SystemObject bem_quoteTypeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_quoteType = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_inLcGet_0() throws Throwable {
return bevp_inLc;
} /*method end*/
public BEC_6_6_SystemObject bem_inLcSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inLc = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_inSpaceGet_0() throws Throwable {
return bevp_inSpace;
} /*method end*/
public BEC_6_6_SystemObject bem_inSpaceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inSpace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_inNlGet_0() throws Throwable {
return bevp_inNl;
} /*method end*/
public BEC_6_6_SystemObject bem_inNlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inNl = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_inStrGet_0() throws Throwable {
return bevp_inStr;
} /*method end*/
public BEC_6_6_SystemObject bem_inStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inStr = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {24, 30, 32, 41, 42, 43, 44, 53, 54, 55, 56, 60, 0, 60, 0, 60, 0, 62, 63, 64, 65, 66, 68, 0, 68, 0, 68, 0, 70, 71, 72, 73, 74, 76, 77, 78, 79, 81, 0, 81, 0, 81, 0, 82, 83, 84, 85, 0, 86, 87, 88, 90, 91, 92, 93, 94, 96, 97, 98, 99, 101, 103, 106, 108, 0, 109, 0, 110, 111, 112, 113, 0, 114, 115, 116, 118, 119, 118, 121, 0, 121, 0, 122, 123, 124, 126, 127, 128, 129, 130, 131, 0, 132, 133, 134, 136, 137, 138, 139, 140, 142, 143, 142, 146, 148, 149, 150, 151, 154, 0, 154, 0, 154, 0, 155, 156, 157, 158, 159, 162, 163, 164, 165, 166, 167, 169, 171, 0, 171, 0, 172, 173, 174, 0, 175, 177, 180, 0, 180, 0, 180, 0, 180, 0, 183, 184, 185, 186, 189, 0, 189, 0, 190, 191, 192, 193, 194, 196, 0, 196, 0, 196, 0, 198, 199, 200, 201, 203, 0, 203, 0, 204, 205, 206, 207, 208, 210, 211, 0, 212, 213, 214, 215, 216, 219, 220, 0, 221, 222, 223, 224, 225, 228, 0, 228, 0, 229, 230, 231, 232, 233, 235, 0, 235, 0, 236, 237, 238, 239, 240, 242, 0, 242, 0, 243, 0, 244, 245, 246, 247, 248, 249, 251, 252, 253, 254, 255, 257, 0, 257, 0, 258, 0, 259, 260, 261, 262, 263, 264, 266, 267, 268, 269, 270, 272, 0, 272, 0, 273, 274, 275, 276, 277, 279, 0, 279, 0, 280, 281, 282, 283, 284, 286, 0, 286, 0, 287, 288, 289, 290, 291, 293, 0, 293, 0, 294, 295, 296, 297, 298, 300, 0, 300, 0, 301, 302, 303, 304, 305, 307, 0, 307, 0, 308, 309, 310, 311, 312, 314, 0, 314, 0, 315, 316, 317, 318, 319, 321, 0, 321, 0, 322, 323, 324, 326, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 24 24
assign 1 30 24
new 0 30 24
assign 1 32 24
new 0 32 24
assign 1 41 24
new 0 41 24
assign 1 42 24
new 0 42 24
assign 1 43 24
new 0 43 24
assign 1 44 24
new 0 44 24
assign 1 53 24
typenameGet 0 53 24
assign 1 54 24
nextPeerGet 0 54 24
assign 1 55 24
def 1 55 24
assign 1 56 24
typenameGet 0 56 24
assign 1 60 24
DIVIDEGet 0 60 24
assign 1 60 24
equals 1 60 24
assign 1 60 24
def 1 60 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 60 24
MULTIPLYGet 0 60 24
assign 1 60 24
equals 1 60 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 60 24
not 0 60 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 62 24
increment 0 62 24
assign 1 63 24
nextPeerGet 0 63 24
assign 1 63 24
nextDescendGet 0 63 24
assign 1 64 24
nextPeerGet 0 64 24
delayDelete 0 64 24
delayDelete 0 65 24
return 1 66 24
assign 1 68 24
MULTIPLYGet 0 68 24
assign 1 68 24
equals 1 68 24
assign 1 68 24
def 1 68 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 68 24
DIVIDEGet 0 68 24
assign 1 68 24
equals 1 68 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 68 24
not 0 68 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 70 24
decrement 0 70 24
assign 1 71 24
nextPeerGet 0 71 24
assign 1 71 24
nextDescendGet 0 71 24
assign 1 72 24
nextPeerGet 0 72 24
delayDelete 0 72 24
delayDelete 0 73 24
return 1 74 24
assign 1 76 24
new 0 76 24
assign 1 76 24
greater 1 76 24
assign 1 77 24
nextDescendGet 0 77 24
delayDelete 0 78 24
return 1 79 24
assign 1 81 24
not 0 81 24
assign 1 81 24
not 0 81 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 81 24
STRQGet 0 81 24
assign 1 81 24
equals 1 81 24
assign 1 0 24
assign 1 81 24
WSTRQGet 0 81 24
assign 1 81 24
equals 1 81 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 82 24
nextPeerGet 0 82 24
assign 1 83 24
new 0 83 24
assign 1 84 24
typenameGet 0 84 24
assign 1 85 24
def 1 85 24
assign 1 85 24
typenameGet 0 85 24
assign 1 85 24
equals 1 85 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 86 24
increment 0 86 24
delayDelete 0 87 24
assign 1 88 24
nextPeerGet 0 88 24
assign 1 90 24
new 0 90 24
assign 1 90 24
equals 1 90 24
assign 1 91 24
new 0 91 24
assign 1 92 24
new 0 92 24
heldSet 1 92 24
assign 1 93 24
STRINGLGet 0 93 24
typenameSet 1 93 24
assign 1 94 24
new 0 94 24
typeDetailSet 1 94 24
assign 1 96 24
new 0 96 24
assign 1 97 24
assign 1 98 24
new 0 98 24
heldSet 1 98 24
assign 1 99 24
WSTRQGet 0 99 24
assign 1 99 24
equals 1 99 24
assign 1 101 24
WSTRINGLGet 0 101 24
typenameSet 1 101 24
assign 1 103 24
STRINGLGet 0 103 24
typenameSet 1 103 24
return 1 106 24
assign 1 108 24
not 0 108 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 109 24
typenameGet 0 109 24
assign 1 109 24
STRINGLGet 0 109 24
assign 1 109 24
equals 1 109 24
assign 1 109 24
FSLASHGet 0 109 24
assign 1 109 24
equals 1 109 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
delayDelete 0 110 24
assign 1 111 24
nextPeerGet 0 111 24
assign 1 112 24
new 0 112 24
assign 1 113 24
def 1 113 24
assign 1 113 24
typenameGet 0 113 24
assign 1 113 24
FSLASHGet 0 113 24
assign 1 113 24
equals 1 113 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 114 24
increment 0 114 24
delayDelete 0 115 24
assign 1 116 24
nextPeerGet 0 116 24
assign 1 118 24
new 0 118 24
assign 1 118 24
lesser 1 118 24
assign 1 119 24
heldGet 0 119 24
assign 1 119 24
heldGet 0 119 24
assign 1 119 24
add 1 119 24
heldSet 1 119 24
assign 1 118 24
increment 0 118 24
assign 1 121 24
def 1 121 24
assign 1 121 24
new 0 121 24
assign 1 121 24
modulus 1 121 24
assign 1 121 24
new 0 121 24
assign 1 121 24
equals 1 121 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 121 24
typenameGet 0 121 24
assign 1 121 24
equals 1 121 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
delayDelete 0 122 24
assign 1 123 24
heldGet 0 123 24
assign 1 123 24
heldGet 0 123 24
assign 1 123 24
add 1 123 24
heldSet 1 123 24
assign 1 124 24
nextDescendGet 0 124 24
return 1 126 24
assign 1 127 24
equals 1 127 24
delayDelete 0 128 24
assign 1 129 24
nextPeerGet 0 129 24
assign 1 130 24
new 0 130 24
assign 1 131 24
def 1 131 24
assign 1 131 24
typenameGet 0 131 24
assign 1 131 24
equals 1 131 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 132 24
increment 0 132 24
delayDelete 0 133 24
assign 1 134 24
nextPeerGet 0 134 24
assign 1 136 24
equals 1 136 24
typeDetailSet 1 137 24
assign 1 138 24
new 0 138 24
assign 1 139 24
assign 1 140 24
new 0 140 24
assign 1 142 24
new 0 142 24
assign 1 142 24
lesser 1 142 24
assign 1 143 24
heldGet 0 143 24
assign 1 143 24
heldGet 0 143 24
assign 1 143 24
add 1 143 24
heldSet 1 143 24
assign 1 142 24
increment 0 142 24
return 1 146 24
assign 1 148 24
heldGet 0 148 24
assign 1 148 24
heldGet 0 148 24
assign 1 148 24
add 1 148 24
heldSet 1 148 24
assign 1 149 24
nextDescendGet 0 149 24
delayDelete 0 150 24
return 1 151 24
assign 1 154 24
DIVIDEGet 0 154 24
assign 1 154 24
equals 1 154 24
assign 1 154 24
def 1 154 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 154 24
DIVIDEGet 0 154 24
assign 1 154 24
equals 1 154 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 154 24
not 0 154 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 155 24
nextPeerGet 0 155 24
assign 1 155 24
nextDescendGet 0 155 24
assign 1 156 24
new 0 156 24
assign 1 157 24
nextPeerGet 0 157 24
delayDelete 0 157 24
delayDelete 0 158 24
return 1 159 24
assign 1 162 24
nextDescendGet 0 162 24
delayDelete 0 163 24
assign 1 164 24
typenameGet 0 164 24
assign 1 164 24
NEWLINEGet 0 164 24
assign 1 164 24
equals 1 164 24
assign 1 165 24
new 0 165 24
delayDelete 0 166 24
assign 1 167 24
nextDescendGet 0 167 24
return 1 169 24
assign 1 171 24
SUBTRACTGet 0 171 24
assign 1 171 24
equals 1 171 24
assign 1 171 24
def 1 171 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 171 24
INTLGet 0 171 24
assign 1 171 24
equals 1 171 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 172 24
priorPeerGet 0 172 24
assign 1 172 24
def 1 172 24
assign 1 173 24
priorPeerGet 0 173 24
assign 1 174 24
def 1 174 24
assign 1 174 24
typenameGet 0 174 24
assign 1 174 24
SPACEGet 0 174 24
assign 1 174 24
equals 1 174 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 175 24
priorPeerGet 0 175 24
assign 1 177 24
assign 1 180 24
undef 1 180 24
assign 1 0 24
assign 1 180 24
typenameGet 0 180 24
assign 1 180 24
COMMAGet 0 180 24
assign 1 180 24
equals 1 180 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 180 24
typenameGet 0 180 24
assign 1 180 24
PARENSGet 0 180 24
assign 1 180 24
equals 1 180 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 180 24
operGet 0 180 24
assign 1 180 24
typenameGet 0 180 24
assign 1 180 24
has 1 180 24
assign 1 0 24
assign 1 0 24
assign 1 183 24
nextPeerGet 0 183 24
assign 1 183 24
new 0 183 24
assign 1 183 24
nextPeerGet 0 183 24
assign 1 183 24
heldGet 0 183 24
assign 1 183 24
add 1 183 24
heldSet 1 183 24
assign 1 184 24
nextDescendGet 0 184 24
delayDelete 0 185 24
return 1 186 24
assign 1 189 24
ASSIGNGet 0 189 24
assign 1 189 24
equals 1 189 24
assign 1 189 24
def 1 189 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 189 24
ASSIGNGet 0 189 24
assign 1 189 24
equals 1 189 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 190 24
EQUALSGet 0 190 24
typenameSet 1 190 24
assign 1 191 24
heldGet 0 191 24
assign 1 191 24
nextPeerGet 0 191 24
assign 1 191 24
heldGet 0 191 24
assign 1 191 24
add 1 191 24
heldSet 1 191 24
assign 1 192 24
nextPeerGet 0 192 24
assign 1 192 24
nextDescendGet 0 192 24
assign 1 193 24
nextPeerGet 0 193 24
delayDelete 0 193 24
return 1 194 24
assign 1 196 24
ASSIGNGet 0 196 24
assign 1 196 24
equals 1 196 24
assign 1 196 24
def 1 196 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 196 24
ONCEGet 0 196 24
assign 1 196 24
equals 1 196 24
assign 1 0 24
assign 1 196 24
MANYGet 0 196 24
assign 1 196 24
equals 1 196 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 198 24
heldGet 0 198 24
assign 1 198 24
nextPeerGet 0 198 24
assign 1 198 24
heldGet 0 198 24
assign 1 198 24
add 1 198 24
heldSet 1 198 24
assign 1 199 24
nextPeerGet 0 199 24
assign 1 199 24
nextDescendGet 0 199 24
assign 1 200 24
nextPeerGet 0 200 24
delayDelete 0 200 24
return 1 201 24
assign 1 203 24
NOTGet 0 203 24
assign 1 203 24
equals 1 203 24
assign 1 203 24
def 1 203 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 203 24
ASSIGNGet 0 203 24
assign 1 203 24
equals 1 203 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 204 24
NOT_EQUALSGet 0 204 24
typenameSet 1 204 24
assign 1 205 24
heldGet 0 205 24
assign 1 205 24
nextPeerGet 0 205 24
assign 1 205 24
heldGet 0 205 24
assign 1 205 24
add 1 205 24
heldSet 1 205 24
assign 1 206 24
nextPeerGet 0 206 24
assign 1 206 24
nextDescendGet 0 206 24
assign 1 207 24
nextPeerGet 0 207 24
delayDelete 0 207 24
return 1 208 24
assign 1 210 24
ORGet 0 210 24
assign 1 210 24
equals 1 210 24
assign 1 211 24
nextPeerGet 0 211 24
assign 1 211 24
def 1 211 24
assign 1 211 24
nextPeerGet 0 211 24
assign 1 211 24
typenameGet 0 211 24
assign 1 211 24
ORGet 0 211 24
assign 1 211 24
equals 1 211 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 212 24
heldGet 0 212 24
assign 1 212 24
nextPeerGet 0 212 24
assign 1 212 24
heldGet 0 212 24
assign 1 212 24
add 1 212 24
heldSet 1 212 24
assign 1 213 24
LOGICAL_ORGet 0 213 24
typenameSet 1 213 24
assign 1 214 24
nextPeerGet 0 214 24
assign 1 214 24
nextDescendGet 0 214 24
assign 1 215 24
nextPeerGet 0 215 24
delayDelete 0 215 24
return 1 216 24
assign 1 219 24
ANDGet 0 219 24
assign 1 219 24
equals 1 219 24
assign 1 220 24
nextPeerGet 0 220 24
assign 1 220 24
def 1 220 24
assign 1 220 24
nextPeerGet 0 220 24
assign 1 220 24
typenameGet 0 220 24
assign 1 220 24
ANDGet 0 220 24
assign 1 220 24
equals 1 220 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 221 24
heldGet 0 221 24
assign 1 221 24
nextPeerGet 0 221 24
assign 1 221 24
heldGet 0 221 24
assign 1 221 24
add 1 221 24
heldSet 1 221 24
assign 1 222 24
LOGICAL_ANDGet 0 222 24
typenameSet 1 222 24
assign 1 223 24
nextPeerGet 0 223 24
assign 1 223 24
nextDescendGet 0 223 24
assign 1 224 24
nextPeerGet 0 224 24
delayDelete 0 224 24
return 1 225 24
assign 1 228 24
GREATERGet 0 228 24
assign 1 228 24
equals 1 228 24
assign 1 228 24
def 1 228 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 228 24
ASSIGNGet 0 228 24
assign 1 228 24
equals 1 228 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 229 24
GREATER_EQUALSGet 0 229 24
typenameSet 1 229 24
assign 1 230 24
heldGet 0 230 24
assign 1 230 24
nextPeerGet 0 230 24
assign 1 230 24
heldGet 0 230 24
assign 1 230 24
add 1 230 24
heldSet 1 230 24
assign 1 231 24
nextPeerGet 0 231 24
assign 1 231 24
nextDescendGet 0 231 24
assign 1 232 24
nextPeerGet 0 232 24
delayDelete 0 232 24
return 1 233 24
assign 1 235 24
LESSERGet 0 235 24
assign 1 235 24
equals 1 235 24
assign 1 235 24
def 1 235 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 235 24
ASSIGNGet 0 235 24
assign 1 235 24
equals 1 235 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 236 24
LESSER_EQUALSGet 0 236 24
typenameSet 1 236 24
assign 1 237 24
heldGet 0 237 24
assign 1 237 24
nextPeerGet 0 237 24
assign 1 237 24
heldGet 0 237 24
assign 1 237 24
add 1 237 24
heldSet 1 237 24
assign 1 238 24
nextPeerGet 0 238 24
assign 1 238 24
nextDescendGet 0 238 24
assign 1 239 24
nextPeerGet 0 239 24
delayDelete 0 239 24
return 1 240 24
assign 1 242 24
ADDGet 0 242 24
assign 1 242 24
equals 1 242 24
assign 1 242 24
def 1 242 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 242 24
ADDGet 0 242 24
assign 1 242 24
equals 1 242 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 243 24
nextPeerGet 0 243 24
assign 1 243 24
nextPeerGet 0 243 24
assign 1 243 24
def 1 243 24
assign 1 243 24
nextPeerGet 0 243 24
assign 1 243 24
nextPeerGet 0 243 24
assign 1 243 24
typenameGet 0 243 24
assign 1 243 24
ASSIGNGet 0 243 24
assign 1 243 24
equals 1 243 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 244 24
INCREMENT_ASSIGNGet 0 244 24
typenameSet 1 244 24
assign 1 245 24
heldGet 0 245 24
assign 1 245 24
nextPeerGet 0 245 24
assign 1 245 24
heldGet 0 245 24
assign 1 245 24
add 1 245 24
assign 1 245 24
nextPeerGet 0 245 24
assign 1 245 24
nextPeerGet 0 245 24
assign 1 245 24
heldGet 0 245 24
assign 1 245 24
add 1 245 24
heldSet 1 245 24
assign 1 246 24
nextPeerGet 0 246 24
assign 1 246 24
nextPeerGet 0 246 24
assign 1 246 24
nextDescendGet 0 246 24
assign 1 247 24
nextPeerGet 0 247 24
delayDelete 0 247 24
assign 1 248 24
nextPeerGet 0 248 24
assign 1 248 24
nextPeerGet 0 248 24
delayDelete 0 248 24
return 1 249 24
assign 1 251 24
INCREMENTGet 0 251 24
typenameSet 1 251 24
assign 1 252 24
heldGet 0 252 24
assign 1 252 24
nextPeerGet 0 252 24
assign 1 252 24
heldGet 0 252 24
assign 1 252 24
add 1 252 24
heldSet 1 252 24
assign 1 253 24
nextPeerGet 0 253 24
assign 1 253 24
nextDescendGet 0 253 24
assign 1 254 24
nextPeerGet 0 254 24
delayDelete 0 254 24
return 1 255 24
assign 1 257 24
SUBTRACTGet 0 257 24
assign 1 257 24
equals 1 257 24
assign 1 257 24
def 1 257 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 257 24
SUBTRACTGet 0 257 24
assign 1 257 24
equals 1 257 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 258 24
nextPeerGet 0 258 24
assign 1 258 24
nextPeerGet 0 258 24
assign 1 258 24
def 1 258 24
assign 1 258 24
nextPeerGet 0 258 24
assign 1 258 24
nextPeerGet 0 258 24
assign 1 258 24
typenameGet 0 258 24
assign 1 258 24
ASSIGNGet 0 258 24
assign 1 258 24
equals 1 258 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 259 24
DECREMENT_ASSIGNGet 0 259 24
typenameSet 1 259 24
assign 1 260 24
heldGet 0 260 24
assign 1 260 24
nextPeerGet 0 260 24
assign 1 260 24
heldGet 0 260 24
assign 1 260 24
add 1 260 24
assign 1 260 24
nextPeerGet 0 260 24
assign 1 260 24
nextPeerGet 0 260 24
assign 1 260 24
heldGet 0 260 24
assign 1 260 24
add 1 260 24
heldSet 1 260 24
assign 1 261 24
nextPeerGet 0 261 24
assign 1 261 24
nextPeerGet 0 261 24
assign 1 261 24
nextDescendGet 0 261 24
assign 1 262 24
nextPeerGet 0 262 24
delayDelete 0 262 24
assign 1 263 24
nextPeerGet 0 263 24
assign 1 263 24
nextPeerGet 0 263 24
delayDelete 0 263 24
return 1 264 24
assign 1 266 24
DECREMENTGet 0 266 24
typenameSet 1 266 24
assign 1 267 24
heldGet 0 267 24
assign 1 267 24
nextPeerGet 0 267 24
assign 1 267 24
heldGet 0 267 24
assign 1 267 24
add 1 267 24
heldSet 1 267 24
assign 1 268 24
nextPeerGet 0 268 24
assign 1 268 24
nextDescendGet 0 268 24
assign 1 269 24
nextPeerGet 0 269 24
delayDelete 0 269 24
return 1 270 24
assign 1 272 24
ADDGet 0 272 24
assign 1 272 24
equals 1 272 24
assign 1 272 24
def 1 272 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 272 24
ASSIGNGet 0 272 24
assign 1 272 24
equals 1 272 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 273 24
ADD_ASSIGNGet 0 273 24
typenameSet 1 273 24
assign 1 274 24
heldGet 0 274 24
assign 1 274 24
nextPeerGet 0 274 24
assign 1 274 24
heldGet 0 274 24
assign 1 274 24
add 1 274 24
heldSet 1 274 24
assign 1 275 24
nextPeerGet 0 275 24
assign 1 275 24
nextDescendGet 0 275 24
assign 1 276 24
nextPeerGet 0 276 24
delayDelete 0 276 24
return 1 277 24
assign 1 279 24
SUBTRACTGet 0 279 24
assign 1 279 24
equals 1 279 24
assign 1 279 24
def 1 279 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 279 24
ASSIGNGet 0 279 24
assign 1 279 24
equals 1 279 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 280 24
SUBTRACT_ASSIGNGet 0 280 24
typenameSet 1 280 24
assign 1 281 24
heldGet 0 281 24
assign 1 281 24
nextPeerGet 0 281 24
assign 1 281 24
heldGet 0 281 24
assign 1 281 24
add 1 281 24
heldSet 1 281 24
assign 1 282 24
nextPeerGet 0 282 24
assign 1 282 24
nextDescendGet 0 282 24
assign 1 283 24
nextPeerGet 0 283 24
delayDelete 0 283 24
return 1 284 24
assign 1 286 24
MULTIPLYGet 0 286 24
assign 1 286 24
equals 1 286 24
assign 1 286 24
def 1 286 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 286 24
ASSIGNGet 0 286 24
assign 1 286 24
equals 1 286 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 287 24
MULTIPLY_ASSIGNGet 0 287 24
typenameSet 1 287 24
assign 1 288 24
heldGet 0 288 24
assign 1 288 24
nextPeerGet 0 288 24
assign 1 288 24
heldGet 0 288 24
assign 1 288 24
add 1 288 24
heldSet 1 288 24
assign 1 289 24
nextPeerGet 0 289 24
assign 1 289 24
nextDescendGet 0 289 24
assign 1 290 24
nextPeerGet 0 290 24
delayDelete 0 290 24
return 1 291 24
assign 1 293 24
DIVIDEGet 0 293 24
assign 1 293 24
equals 1 293 24
assign 1 293 24
def 1 293 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 293 24
ASSIGNGet 0 293 24
assign 1 293 24
equals 1 293 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 294 24
DIVIDE_ASSIGNGet 0 294 24
typenameSet 1 294 24
assign 1 295 24
heldGet 0 295 24
assign 1 295 24
nextPeerGet 0 295 24
assign 1 295 24
heldGet 0 295 24
assign 1 295 24
add 1 295 24
heldSet 1 295 24
assign 1 296 24
nextPeerGet 0 296 24
assign 1 296 24
nextDescendGet 0 296 24
assign 1 297 24
nextPeerGet 0 297 24
delayDelete 0 297 24
return 1 298 24
assign 1 300 24
MODULUSGet 0 300 24
assign 1 300 24
equals 1 300 24
assign 1 300 24
def 1 300 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 300 24
ASSIGNGet 0 300 24
assign 1 300 24
equals 1 300 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 301 24
MODULUS_ASSIGNGet 0 301 24
typenameSet 1 301 24
assign 1 302 24
heldGet 0 302 24
assign 1 302 24
nextPeerGet 0 302 24
assign 1 302 24
heldGet 0 302 24
assign 1 302 24
add 1 302 24
heldSet 1 302 24
assign 1 303 24
nextPeerGet 0 303 24
assign 1 303 24
nextDescendGet 0 303 24
assign 1 304 24
nextPeerGet 0 304 24
delayDelete 0 304 24
return 1 305 24
assign 1 307 24
ANDGet 0 307 24
assign 1 307 24
equals 1 307 24
assign 1 307 24
def 1 307 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 307 24
ASSIGNGet 0 307 24
assign 1 307 24
equals 1 307 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 308 24
AND_ASSIGNGet 0 308 24
typenameSet 1 308 24
assign 1 309 24
heldGet 0 309 24
assign 1 309 24
nextPeerGet 0 309 24
assign 1 309 24
heldGet 0 309 24
assign 1 309 24
add 1 309 24
heldSet 1 309 24
assign 1 310 24
nextPeerGet 0 310 24
assign 1 310 24
nextDescendGet 0 310 24
assign 1 311 24
nextPeerGet 0 311 24
delayDelete 0 311 24
return 1 312 24
assign 1 314 24
ORGet 0 314 24
assign 1 314 24
equals 1 314 24
assign 1 314 24
def 1 314 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 314 24
ASSIGNGet 0 314 24
assign 1 314 24
equals 1 314 24
assign 1 0 24
assign 1 0 24
assign 1 0 24
assign 1 315 24
OR_ASSIGNGet 0 315 24
typenameSet 1 315 24
assign 1 316 24
heldGet 0 316 24
assign 1 316 24
nextPeerGet 0 316 24
assign 1 316 24
heldGet 0 316 24
assign 1 316 24
add 1 316 24
heldSet 1 316 24
assign 1 317 24
nextPeerGet 0 317 24
assign 1 317 24
nextDescendGet 0 317 24
assign 1 318 24
nextPeerGet 0 318 24
delayDelete 0 318 24
return 1 319 24
assign 1 321 24
SPACEGet 0 321 24
assign 1 321 24
equals 1 321 24
assign 1 0 24
assign 1 321 24
NEWLINEGet 0 321 24
assign 1 321 24
equals 1 321 24
assign 1 0 24
assign 1 0 24
assign 1 322 24
nextDescendGet 0 322 24
delayDelete 0 323 24
return 1 324 24
assign 1 326 24
nextDescendGet 0 326 24
return 1 326 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
return 1 0 24
assign 1 0 24
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 572357856: return bem_nestCommentGet_0();
case 599903714: return bem_strqCntGet_0();
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 734766741: return bem_inLcGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1788342768: return bem_goingStrGet_0();
case 1081412016: return bem_many_0();
case 1246859482: return bem_inSpaceGet_0();
case 1417421339: return bem_inStrGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1297902980: return bem_inNlGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case 2021097297: return bem_quoteTypeGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1235777229: return bem_inSpaceSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 588821461: return bem_strqCntSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1428503592: return bem_inStrSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 723684488: return bem_inLcSet_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 583440109: return bem_nestCommentSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 2032179550: return bem_quoteTypeSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1799425021: return bem_goingStrSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1308985233: return bem_inNlSet_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass3();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass3.bevs_inst = (BEC_5_5_5_BuildVisitPass3)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass3.bevs_inst;
}
}
