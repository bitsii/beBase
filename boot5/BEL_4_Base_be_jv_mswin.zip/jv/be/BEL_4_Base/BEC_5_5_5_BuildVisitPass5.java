package be.BEL_4_Base;
/* IO:File: source/build/Pass5.be */
public class BEC_5_5_5_BuildVisitPass5 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass5() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x35};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x35,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x6F,0x66,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_2 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x75,0x73,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x61,0x6C,0x69,0x61,0x73,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x20,0x2D,0x61,0x73,0x2D,0x2E};
private static byte[] bels_3 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x6F,0x74,0x20,0x77,0x69,0x74,0x68,0x69,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x75,0x6E,0x69,0x74};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(2));
private static byte[] bels_4 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_5 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_6 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bels_7 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_9 = {0x4F,0x6E,0x6C,0x79,0x20,0x73,0x69,0x6E,0x67,0x6C,0x65,0x20,0x69,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x61,0x6C,0x6C,0x6F,0x77,0x65,0x64};
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x73,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x62,0x72,0x61,0x63,0x65,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x2E};
private static byte[] bels_13 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_14 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(2));
private static byte[] bels_15 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bels_16 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_17 = {0x4C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bels_18 = {0x46,0x69,0x72,0x73,0x74,0x20,0x63,0x68,0x61,0x72,0x61,0x63,0x74,0x65,0x72,0x20,0x6F,0x66,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x61,0x6E,0x64,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x6E,0x61,0x6D,0x65,0x73,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x6E,0x75,0x6D,0x65,0x72,0x69,0x63,0x20,0x64,0x69,0x67,0x69,0x74};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x31};
private static byte[] bels_20 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x32};
private static byte[] bels_21 = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] bels_22 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x69,0x6D,0x70,0x72,0x6F,0x70,0x65,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x63,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x73,0x20,0x61,0x70,0x70,0x65,0x61,0x72,0x20,0x74,0x6F,0x20,0x62,0x65,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6F,0x72,0x20,0x73,0x75,0x62,0x72,0x6F,0x75,0x74,0x69,0x6E,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x2E};
private static byte[] bels_23 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x74,0x68,0x65,0x73,0x69,0x73,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x28,0x62,0x75,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x29,0x20,0x61,0x66,0x74,0x65,0x72,0x3A,0x20};
public static BEC_5_5_5_BuildVisitPass5 bevs_inst;
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevl_err = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_ix = null;
BEC_6_6_SystemObject bevl_vinp = null;
BEC_6_6_SystemObject bevl_nnode = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_namepath = null;
BEC_4_6_TextString bevl_alias = null;
BEC_6_6_SystemObject bevl_mas = null;
BEC_6_6_SystemObject bevl_gnext = null;
BEC_6_6_SystemObject bevl_tnode = null;
BEC_5_4_LogicBool bevl_isFinal = null;
BEC_5_4_LogicBool bevl_isLocal = null;
BEC_5_4_LogicBool bevl_isNotNull = null;
BEC_5_4_BuildNode bevl_prp = null;
BEC_4_3_MathInt bevl_prpi = null;
BEC_5_4_BuildNode bevl_prptmp = null;
BEC_6_6_SystemObject bevl_m = null;
BEC_6_6_SystemObject bevl_mx = null;
BEC_6_6_SystemObject bevl_nx = null;
BEC_6_6_SystemObject bevl_con = null;
BEC_6_6_SystemObject bevl_lpnode = null;
BEC_6_6_SystemObject bevl_ii = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_9_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_10_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_11_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_12_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_13_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_14_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_15_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_16_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_9_BuildTransUnit bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_4_3_MathInt bevt_81_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_85_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_86_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_87_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_91_tmpvar_phold = null;
BEC_4_3_MathInt bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_4_3_MathInt bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_97_tmpvar_phold = null;
BEC_4_3_MathInt bevt_98_tmpvar_phold = null;
BEC_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_4_3_MathInt bevt_105_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_4_6_TextString bevt_108_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_4_3_MathInt bevt_111_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_5_5_BuildClass bevt_115_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_118_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_4_3_MathInt bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_4_3_MathInt bevt_125_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_130_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_132_tmpvar_phold = null;
BEC_4_6_TextString bevt_133_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_136_tmpvar_phold = null;
BEC_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_138_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_4_3_MathInt bevt_141_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_142_tmpvar_phold = null;
BEC_4_6_TextString bevt_143_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_4_3_MathInt bevt_147_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_149_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_152_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_158_tmpvar_phold = null;
BEC_4_6_TextString bevt_159_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_160_tmpvar_phold = null;
BEC_4_6_TextString bevt_161_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_162_tmpvar_phold = null;
BEC_4_6_TextString bevt_163_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_164_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_167_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_169_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_4_6_TextString bevt_171_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_5_8_BuildNamePath bevt_174_tmpvar_phold = null;
BEC_4_6_TextString bevt_175_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_176_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_177_tmpvar_phold = null;
BEC_4_3_MathInt bevt_178_tmpvar_phold = null;
BEC_4_3_MathInt bevt_179_tmpvar_phold = null;
BEC_5_6_BuildMethod bevt_180_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_181_tmpvar_phold = null;
BEC_4_3_MathInt bevt_182_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_183_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_184_tmpvar_phold = null;
BEC_4_3_MathInt bevt_185_tmpvar_phold = null;
BEC_4_3_MathInt bevt_186_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_187_tmpvar_phold = null;
BEC_4_3_MathInt bevt_188_tmpvar_phold = null;
BEC_4_3_MathInt bevt_189_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_191_tmpvar_phold = null;
BEC_4_6_TextString bevt_192_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_194_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_195_tmpvar_phold = null;
BEC_4_3_MathInt bevt_196_tmpvar_phold = null;
BEC_4_3_MathInt bevt_197_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_198_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_199_tmpvar_phold = null;
BEC_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_201_tmpvar_phold = null;
BEC_4_6_TextString bevt_202_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_203_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_205_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_4_3_MathInt bevt_208_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_4_3_MathInt bevt_211_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_4_3_MathInt bevt_214_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_216_tmpvar_phold = null;
BEC_4_3_MathInt bevt_217_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_219_tmpvar_phold = null;
BEC_4_3_MathInt bevt_220_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_221_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_224_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_4_3_MathInt bevt_227_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_228_tmpvar_phold = null;
BEC_4_6_TextString bevt_229_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_230_tmpvar_phold = null;
BEC_4_6_TextString bevt_231_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_232_tmpvar_phold = null;
BEC_4_6_TextString bevt_233_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_235_tmpvar_phold = null;
BEC_4_6_TextString bevt_236_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_237_tmpvar_phold = null;
BEC_4_6_TextString bevt_238_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_239_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_240_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_241_tmpvar_phold = null;
BEC_5_9_BuildConstants bevt_242_tmpvar_phold = null;
BEC_4_3_MathInt bevt_243_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_244_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_245_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_246_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_247_tmpvar_phold = null;
BEC_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_249_tmpvar_phold = null;
BEC_4_6_TextString bevt_250_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_251_tmpvar_phold = null;
BEC_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_4_3_MathInt bevt_253_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_254_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_255_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_256_tmpvar_phold = null;
BEC_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_4_3_MathInt bevt_258_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_259_tmpvar_phold = null;
BEC_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_4_3_MathInt bevt_261_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_263_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_264_tmpvar_phold = null;
BEC_4_3_MathInt bevt_265_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_267_tmpvar_phold = null;
BEC_4_3_MathInt bevt_268_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_269_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_270_tmpvar_phold = null;
BEC_4_3_MathInt bevt_271_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_272_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_273_tmpvar_phold = null;
BEC_4_3_MathInt bevt_274_tmpvar_phold = null;
BEC_4_3_MathInt bevt_275_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_276_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_277_tmpvar_phold = null;
bevt_18_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_equals_1(bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_20_tmpvar_phold = (new BEC_5_9_BuildTransUnit()).bem_new_0();
beva_node.bem_heldSet_1(bevt_20_tmpvar_phold);
} /* Line: 27 */
bevt_22_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_23_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_equals_1(bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_25_tmpvar_phold = beva_node.bem_heldGet_0();
if (bevt_25_tmpvar_phold == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_27_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_29_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_emptyGet_0();
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_28_tmpvar_phold);
if (bevt_26_tmpvar_phold != null && bevt_26_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_26_tmpvar_phold).bevi_bool) /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 30 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 30 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 30 */ {
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 32 */
} /* Line: 30 */
bevl_ix = beva_node.bem_nextPeerGet_0();
if (bevl_ix == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_32_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_33_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_equals_1(bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_35_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_36_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bem_equals_1(bevt_36_tmpvar_phold);
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
 else  /* Line: 36 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_38_tmpvar_phold = bevl_ix.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_39_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_39_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 36 */
 else  /* Line: 36 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 36 */ {
bevt_41_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_42_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_equals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 38 */ {
bevl_vinp = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_43_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_43_tmpvar_phold);
} /* Line: 40 */
 else  /* Line: 41 */ {
bevl_vinp = beva_node.bem_heldGet_0();
} /* Line: 42 */
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_44_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_45_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
beva_node.bem_typenameSet_1(bevt_45_tmpvar_phold);
beva_node.bem_heldSet_1(bevl_v);
} /* Line: 49 */
bevt_47_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_48_tmpvar_phold = bevp_ntypes.bem_USEGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_equals_1(bevt_48_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 54 */ {
if (bevl_nnode == null) {
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_49_tmpvar_phold.bevi_bool) /* Line: 54 */ {
bevt_51_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_52_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_52_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 54 */
 else  /* Line: 54 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 54 */ {
bevl_nnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
} /* Line: 55 */
 else  /* Line: 54 */ {
break;
} /* Line: 54 */
} /* Line: 54 */
if (bevl_nnode == null) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 57 */ {
bevt_55_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_56_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_56_tmpvar_phold);
if (bevt_54_tmpvar_phold != null && bevt_54_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_54_tmpvar_phold).bevi_bool) /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 57 */
 else  /* Line: 57 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 57 */ {
bevl_clnode = bevl_nnode;
bevt_57_tmpvar_phold = bevl_clnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nnode = bevt_57_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 59 */
 else  /* Line: 60 */ {
bevl_clnode = null;
} /* Line: 61 */
if (bevl_nnode == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 64 */ {
bevt_60_tmpvar_phold = (new BEC_4_6_TextString(59, bels_0));
bevt_59_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_60_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_59_tmpvar_phold);
} /* Line: 65 */
bevt_62_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_63_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_63_tmpvar_phold);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 68 */ {
bevl_namepath = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_64_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_64_tmpvar_phold);
} /* Line: 70 */
 else  /* Line: 68 */ {
bevt_66_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_67_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_67_tmpvar_phold);
if (bevt_65_tmpvar_phold != null && bevt_65_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_65_tmpvar_phold).bevi_bool) /* Line: 71 */ {
bevl_namepath = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 72 */
 else  /* Line: 73 */ {
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(55, bels_1));
bevt_68_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_69_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_68_tmpvar_phold);
} /* Line: 74 */
} /* Line: 68 */
bevl_alias = null;
bevl_mas = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_71_tmpvar_phold = bevl_mas.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpvar_phold = bevp_ntypes.bem_ASGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 79 */ {
bevl_nnode = bevl_mas.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_74_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_75_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_75_tmpvar_phold);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 81 */ {
bevt_77_tmpvar_phold = (new BEC_4_6_TextString(57, bels_2));
bevt_76_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_77_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_76_tmpvar_phold);
} /* Line: 82 */
bevl_alias = (BEC_4_6_TextString) bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 84 */
if (bevl_clnode == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_80_tmpvar_phold = bevl_gnext.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_81_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_81_tmpvar_phold);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 91 */ {
bevl_nnode = bevl_gnext;
bevl_gnext = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 94 */
} /* Line: 91 */
 else  /* Line: 96 */ {
bevl_gnext = bevl_clnode;
} /* Line: 97 */
beva_node.bem_heldSet_1(bevl_namepath);
bevl_tnode = beva_node.bem_transUnitGet_0();
if (bevl_tnode == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_84_tmpvar_phold = (new BEC_4_6_TextString(53, bels_3));
bevt_83_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_84_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_83_tmpvar_phold);
} /* Line: 104 */
if (bevl_alias == null) {
bevt_85_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_85_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_85_tmpvar_phold.bevi_bool) /* Line: 107 */ {
bevl_alias = (BEC_4_6_TextString) bevl_namepath.bemd_0(1672091917, BEL_4_Base.bevn_labelGet_0);
} /* Line: 108 */
bevt_87_tmpvar_phold = bevl_tnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_86_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_alias, bevl_namepath);
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 112 */
bevt_89_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_90_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_equals_1(bevt_90_tmpvar_phold);
if (bevt_88_tmpvar_phold.bevi_bool) /* Line: 114 */ {
bevl_isFinal = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isLocal = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_isNotNull = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 119 */ {
bevt_92_tmpvar_phold = bevo_0;
bevt_91_tmpvar_phold = bevl_prpi.bem_lesser_1(bevt_92_tmpvar_phold);
if (bevt_91_tmpvar_phold.bevi_bool) /* Line: 119 */ {
if (bevl_prp == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_95_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_96_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_94_tmpvar_phold = bevt_95_tmpvar_phold.bem_equals_1(bevt_96_tmpvar_phold);
if (bevt_94_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_98_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_99_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bem_equals_1(bevt_99_tmpvar_phold);
if (bevt_97_tmpvar_phold.bevi_bool) /* Line: 122 */ {
bevt_101_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_102_tmpvar_phold = (new BEC_4_6_TextString(5, bels_4));
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_102_tmpvar_phold);
if (bevt_100_tmpvar_phold != null && bevt_100_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_100_tmpvar_phold).bevi_bool) /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 122 */
 else  /* Line: 122 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 122 */ {
bevl_isFinal = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 123 */
 else  /* Line: 122 */ {
bevt_104_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_105_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_equals_1(bevt_105_tmpvar_phold);
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_107_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_108_tmpvar_phold = (new BEC_4_6_TextString(5, bels_5));
bevt_106_tmpvar_phold = bevt_107_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_108_tmpvar_phold);
if (bevt_106_tmpvar_phold != null && bevt_106_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_106_tmpvar_phold).bevi_bool) /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
 else  /* Line: 124 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevl_isLocal = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 125 */
 else  /* Line: 122 */ {
bevt_110_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_111_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_109_tmpvar_phold = bevt_110_tmpvar_phold.bem_equals_1(bevt_111_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_113_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_114_tmpvar_phold = (new BEC_4_6_TextString(7, bels_6));
bevt_112_tmpvar_phold = bevt_113_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_114_tmpvar_phold);
if (bevt_112_tmpvar_phold != null && bevt_112_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_112_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevl_isNotNull = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 127 */
} /* Line: 122 */
} /* Line: 122 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 131 */
 else  /* Line: 132 */ {
bevl_prp = null;
} /* Line: 133 */
} /* Line: 121 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 119 */
 else  /* Line: 119 */ {
break;
} /* Line: 119 */
} /* Line: 119 */
bevt_115_tmpvar_phold = (new BEC_5_5_BuildClass()).bem_new_0();
beva_node.bem_heldSet_1(bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_117_tmpvar_phold = bevp_build.bem_fromFileGet_0();
bevt_116_tmpvar_phold.bemd_1(806119150, BEL_4_Base.bevn_fromFileSet_1, bevt_117_tmpvar_phold);
try  /* Line: 139 */ {
bevt_118_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_118_tmpvar_phold.bem_firstGet_0();
bevt_120_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_121_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpvar_phold);
if (bevt_119_tmpvar_phold != null && bevt_119_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_119_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_namepath = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_122_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_namepath.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_122_tmpvar_phold);
} /* Line: 143 */
 else  /* Line: 141 */ {
bevt_124_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_125_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_125_tmpvar_phold);
if (bevt_123_tmpvar_phold != null && bevt_123_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_123_tmpvar_phold).bevi_bool) /* Line: 144 */ {
bevl_namepath = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 145 */
 else  /* Line: 146 */ {
bevt_127_tmpvar_phold = (new BEC_4_6_TextString(35, bels_7));
bevt_126_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 147 */
} /* Line: 141 */
bevt_128_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_128_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_namepath);
bevt_129_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_129_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevl_isFinal);
bevt_130_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_130_tmpvar_phold.bemd_1(831500365, BEL_4_Base.bevn_isLocalSet_1, bevl_isLocal);
bevt_131_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_131_tmpvar_phold.bemd_1(374719236, BEL_4_Base.bevn_isNotNullSet_1, bevl_isNotNull);
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 153 */
 catch (Throwable beve_0) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_133_tmpvar_phold = (new BEC_4_6_TextString(61, bels_8));
bevt_132_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_133_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_132_tmpvar_phold);
} /* Line: 156 */
try  /* Line: 158 */ {
bevt_134_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_nnode = bevt_134_tmpvar_phold.bem_firstGet_0();
bevt_136_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_137_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_135_tmpvar_phold = bevt_136_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_137_tmpvar_phold);
if (bevt_135_tmpvar_phold != null && bevt_135_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_135_tmpvar_phold).bevi_bool) /* Line: 160 */ {
bevt_140_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_139_tmpvar_phold = bevt_140_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_141_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevt_138_tmpvar_phold = bevt_139_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_141_tmpvar_phold);
if (bevt_138_tmpvar_phold != null && bevt_138_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_138_tmpvar_phold).bevi_bool) /* Line: 161 */ {
bevt_143_tmpvar_phold = (new BEC_4_6_TextString(34, bels_9));
bevt_142_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_143_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_142_tmpvar_phold);
} /* Line: 162 */
try  /* Line: 164 */ {
bevt_144_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_m = bevt_144_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_146_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_147_tmpvar_phold);
if (bevt_145_tmpvar_phold != null && bevt_145_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_145_tmpvar_phold).bevi_bool) /* Line: 166 */ {
bevt_148_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_149_tmpvar_phold = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_148_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_149_tmpvar_phold);
bevt_151_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_152_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_150_tmpvar_phold.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_152_tmpvar_phold);
} /* Line: 168 */
 else  /* Line: 166 */ {
bevt_154_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_155_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_155_tmpvar_phold);
if (bevt_153_tmpvar_phold != null && bevt_153_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_153_tmpvar_phold).bevi_bool) /* Line: 169 */ {
bevt_156_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_157_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_157_tmpvar_phold);
} /* Line: 170 */
 else  /* Line: 171 */ {
bevt_159_tmpvar_phold = (new BEC_4_6_TextString(42, bels_10));
bevt_158_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_159_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_158_tmpvar_phold);
} /* Line: 172 */
} /* Line: 166 */
} /* Line: 166 */
 catch (Throwable beve_1) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_1));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_161_tmpvar_phold = (new BEC_4_6_TextString(68, bels_11));
bevt_160_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_161_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_160_tmpvar_phold);
} /* Line: 177 */
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 179 */
} /* Line: 160 */
 catch (Throwable beve_2) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_2));
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_163_tmpvar_phold = (new BEC_4_6_TextString(60, bels_12));
bevt_162_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_163_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_162_tmpvar_phold);
} /* Line: 183 */
bevt_166_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_165_tmpvar_phold == null) {
bevt_164_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_164_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_164_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevt_170_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_169_tmpvar_phold = bevt_170_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_168_tmpvar_phold = bevt_169_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_171_tmpvar_phold = (new BEC_4_6_TextString(13, bels_13));
bevt_167_tmpvar_phold = bevt_168_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_171_tmpvar_phold);
if (bevt_167_tmpvar_phold != null && bevt_167_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_167_tmpvar_phold).bevi_bool) /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 186 */
 else  /* Line: 186 */ {
bevt_8_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpvar_anchor.bevi_bool) /* Line: 186 */ {
bevt_172_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_174_tmpvar_phold = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_175_tmpvar_phold = (new BEC_4_6_TextString(13, bels_14));
bevt_173_tmpvar_phold = bevt_174_tmpvar_phold.bem_fromString_1(bevt_175_tmpvar_phold);
bevt_172_tmpvar_phold.bemd_1(440408699, BEL_4_Base.bevn_extendsSet_1, bevt_173_tmpvar_phold);
} /* Line: 187 */
bevt_176_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_176_tmpvar_phold;
} /* Line: 190 */
bevt_178_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_179_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_177_tmpvar_phold = bevt_178_tmpvar_phold.bem_equals_1(bevt_179_tmpvar_phold);
if (bevt_177_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevt_180_tmpvar_phold = (new BEC_5_6_BuildMethod()).bem_new_0();
beva_node.bem_heldSet_1(bevt_180_tmpvar_phold);
bevl_prp = beva_node.bem_priorPeerGet_0();
bevl_prpi = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 195 */ {
bevt_182_tmpvar_phold = bevo_1;
bevt_181_tmpvar_phold = bevl_prpi.bem_lesser_1(bevt_182_tmpvar_phold);
if (bevt_181_tmpvar_phold.bevi_bool) /* Line: 195 */ {
if (bevl_prp == null) {
bevt_183_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_183_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_183_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_185_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_186_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_184_tmpvar_phold = bevt_185_tmpvar_phold.bem_equals_1(bevt_186_tmpvar_phold);
if (bevt_184_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevt_188_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_189_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bem_equals_1(bevt_189_tmpvar_phold);
if (bevt_187_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevt_191_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_192_tmpvar_phold = (new BEC_4_6_TextString(5, bels_15));
bevt_190_tmpvar_phold = bevt_191_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_192_tmpvar_phold);
if (bevt_190_tmpvar_phold != null && bevt_190_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_190_tmpvar_phold).bevi_bool) /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 198 */
 else  /* Line: 198 */ {
bevt_9_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_9_tmpvar_anchor.bevi_bool) /* Line: 198 */ {
bevt_193_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_194_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_193_tmpvar_phold.bemd_1(298450056, BEL_4_Base.bevn_isFinalSet_1, bevt_194_tmpvar_phold);
} /* Line: 199 */
 else  /* Line: 198 */ {
bevt_196_tmpvar_phold = bevl_prp.bem_typenameGet_0();
bevt_197_tmpvar_phold = bevp_ntypes.bem_DEFMODGet_0();
bevt_195_tmpvar_phold = bevt_196_tmpvar_phold.bem_equals_1(bevt_197_tmpvar_phold);
if (bevt_195_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevt_199_tmpvar_phold = bevl_prp.bem_heldGet_0();
bevt_200_tmpvar_phold = (new BEC_4_6_TextString(5, bels_16));
bevt_198_tmpvar_phold = bevt_199_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_200_tmpvar_phold);
if (bevt_198_tmpvar_phold != null && bevt_198_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_198_tmpvar_phold).bevi_bool) /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 200 */
 else  /* Line: 200 */ {
bevt_10_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_10_tmpvar_anchor.bevi_bool) /* Line: 200 */ {
bevt_202_tmpvar_phold = (new BEC_4_6_TextString(27, bels_17));
bevt_201_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_202_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_201_tmpvar_phold);
} /* Line: 202 */
} /* Line: 198 */
bevl_prptmp = bevl_prp.bem_priorPeerGet_0();
bevl_prp.bem_delete_0();
bevl_prp = bevl_prptmp;
} /* Line: 206 */
 else  /* Line: 207 */ {
bevl_prp = null;
} /* Line: 208 */
} /* Line: 197 */
bevl_prpi = bevl_prpi.bem_increment_0();
} /* Line: 195 */
 else  /* Line: 195 */ {
break;
} /* Line: 195 */
} /* Line: 195 */
try  /* Line: 212 */ {
bevt_203_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_203_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_204_tmpvar_phold.bevi_bool) /* Line: 214 */ {
bevl_mx = bevl_m.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_mx == null) {
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_205_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_205_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevl_mx = bevl_mx.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_207_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_208_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_206_tmpvar_phold = bevt_207_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_208_tmpvar_phold);
if (bevt_206_tmpvar_phold != null && bevt_206_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_206_tmpvar_phold).bevi_bool) /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_210_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_211_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_209_tmpvar_phold = bevt_210_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_211_tmpvar_phold);
if (bevt_209_tmpvar_phold != null && bevt_209_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_209_tmpvar_phold).bevi_bool) /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_11_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
if (bevt_11_tmpvar_anchor.bevi_bool) /* Line: 218 */ {
bevt_213_tmpvar_phold = bevl_mx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_214_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_212_tmpvar_phold = bevt_213_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_214_tmpvar_phold);
if (bevt_212_tmpvar_phold != null && bevt_212_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_212_tmpvar_phold).bevi_bool) /* Line: 220 */ {
bevl_vinp = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_215_tmpvar_phold = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_vinp.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_215_tmpvar_phold);
} /* Line: 222 */
 else  /* Line: 223 */ {
bevl_vinp = bevl_mx.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 224 */
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_216_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_216_tmpvar_phold);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevl_vinp);
bevt_217_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_mx.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_217_tmpvar_phold);
bevl_mx.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
} /* Line: 230 */
} /* Line: 218 */
bevt_219_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_220_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_218_tmpvar_phold = bevt_219_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_220_tmpvar_phold);
if (bevt_218_tmpvar_phold != null && bevt_218_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_218_tmpvar_phold).bevi_bool) /* Line: 233 */ {
bevt_221_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_222_tmpvar_phold = bevl_m.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_221_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_222_tmpvar_phold);
bevt_226_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_227_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_224_tmpvar_phold = bevt_225_tmpvar_phold.bemd_1(636254476, BEL_4_Base.bevn_getPoint_1, bevt_227_tmpvar_phold);
bevt_223_tmpvar_phold = bevt_224_tmpvar_phold.bemd_0(1670870885, BEL_4_Base.bevn_isInteger_0);
if (bevt_223_tmpvar_phold != null && bevt_223_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_223_tmpvar_phold).bevi_bool) /* Line: 235 */ {
bevt_229_tmpvar_phold = (new BEC_4_6_TextString(75, bels_18));
bevt_228_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_229_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_228_tmpvar_phold);
} /* Line: 236 */
bevl_m.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 238 */
 else  /* Line: 239 */ {
bevt_231_tmpvar_phold = (new BEC_4_6_TextString(42, bels_19));
bevt_230_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_231_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_230_tmpvar_phold);
} /* Line: 240 */
} /* Line: 233 */
 else  /* Line: 242 */ {
bevt_233_tmpvar_phold = (new BEC_4_6_TextString(42, bels_20));
bevt_232_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_233_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_232_tmpvar_phold);
} /* Line: 243 */
} /* Line: 214 */
 catch (Throwable beve_3) {
bevl_err = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_3));
bevt_235_tmpvar_phold = bevl_err.bemd_0(1102720804, BEL_4_Base.bevn_classNameGet_0);
bevt_236_tmpvar_phold = (new BEC_4_6_TextString(16, bels_21));
bevt_234_tmpvar_phold = bevt_235_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_236_tmpvar_phold);
if (bevt_234_tmpvar_phold != null && bevt_234_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_234_tmpvar_phold).bevi_bool) /* Line: 246 */ {
throw new be.BELS_Base.BECS_ThrowBack(bevl_err);
} /* Line: 246 */
bevl_err.bemd_0(314718434, BEL_4_Base.bevn_print_0);
bevt_238_tmpvar_phold = (new BEC_4_6_TextString(104, bels_22));
bevt_237_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_238_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_237_tmpvar_phold);
} /* Line: 248 */
bevt_239_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_239_tmpvar_phold;
} /* Line: 250 */
bevt_242_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevt_241_tmpvar_phold = bevt_242_tmpvar_phold.bem_parensReqGet_0();
bevt_243_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_240_tmpvar_phold = bevt_241_tmpvar_phold.bem_has_1(bevt_243_tmpvar_phold);
if (bevt_240_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_244_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_m = bevt_244_tmpvar_phold.bem_firstGet_0();
if (bevl_m == null) {
bevt_245_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_245_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_245_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_247_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_248_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_246_tmpvar_phold = bevt_247_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_248_tmpvar_phold);
if (bevt_246_tmpvar_phold != null && bevt_246_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_246_tmpvar_phold).bevi_bool) /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_12_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 254 */
if (bevt_12_tmpvar_anchor.bevi_bool) /* Line: 254 */ {
bevt_250_tmpvar_phold = (new BEC_4_6_TextString(50, bels_23));
bevt_249_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_250_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_249_tmpvar_phold);
} /* Line: 255 */
} /* Line: 254 */
bevt_252_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_253_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_251_tmpvar_phold = bevt_252_tmpvar_phold.bem_equals_1(bevt_253_tmpvar_phold);
if (bevt_251_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevl_m = beva_node.bem_containerGet_0();
if (bevl_m == null) {
bevt_254_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_254_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_254_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevt_256_tmpvar_phold = bevl_m.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_257_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_255_tmpvar_phold = bevt_256_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_257_tmpvar_phold);
if (bevt_255_tmpvar_phold != null && bevt_255_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_255_tmpvar_phold).bevi_bool) /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 261 */
 else  /* Line: 261 */ {
bevt_13_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_13_tmpvar_anchor.bevi_bool) /* Line: 261 */ {
bevt_258_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
beva_node.bem_typenameSet_1(bevt_258_tmpvar_phold);
} /* Line: 262 */
} /* Line: 261 */
bevt_260_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_261_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_259_tmpvar_phold = bevt_260_tmpvar_phold.bem_equals_1(bevt_261_tmpvar_phold);
if (bevt_259_tmpvar_phold.bevi_bool) /* Line: 265 */ {
bevl_nx = beva_node.bem_priorPeerGet_0();
bevl_gnext = beva_node.bem_nextAscendGet_0();
while (true)
 /* Line: 271 */ {
if (bevl_nx == null) {
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_262_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_262_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_264_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_265_tmpvar_phold = bevp_ntypes.bem_SEMIGet_0();
bevt_263_tmpvar_phold = bevt_264_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_265_tmpvar_phold);
if (bevt_263_tmpvar_phold != null && bevt_263_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_263_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_16_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_16_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
bevt_267_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_268_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_266_tmpvar_phold = bevt_267_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_268_tmpvar_phold);
if (bevt_266_tmpvar_phold != null && bevt_266_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_266_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_15_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_15_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
bevt_270_tmpvar_phold = bevl_nx.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_271_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_271_tmpvar_phold);
if (bevt_269_tmpvar_phold != null && bevt_269_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_269_tmpvar_phold).bevi_bool) /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_14_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_14_tmpvar_anchor.bevi_bool) /* Line: 271 */ {
if (bevl_con == null) {
bevt_272_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_272_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_272_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevl_con = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 273 */
bevl_con.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_nx);
bevl_nx = bevl_nx.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
} /* Line: 276 */
 else  /* Line: 271 */ {
break;
} /* Line: 271 */
} /* Line: 271 */
if (bevl_con == null) {
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_273_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_273_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_274_tmpvar_phold = bevp_ntypes.bem_EXPRGet_0();
beva_node.bem_typenameSet_1(bevt_274_tmpvar_phold);
beva_node.bem_heldSet_1(null);
bevl_lpnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_275_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_lpnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_275_tmpvar_phold);
beva_node.bem_addValue_1((BEC_5_4_BuildNode) bevl_lpnode);
bevl_lpnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_ii = bevl_con.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 285 */ {
bevt_276_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_276_tmpvar_phold != null && bevt_276_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_276_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lpnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 288 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
} /* Line: 285 */
 else  /* Line: 294 */ {
beva_node.bem_delete_0();
} /* Line: 295 */
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 297 */
bevt_277_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_277_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 27, 29, 30, 0, 30, 0, 31, 32, 35, 36, 0, 36, 0, 36, 0, 38, 39, 40, 42, 44, 45, 47, 48, 49, 51, 53, 54, 0, 55, 57, 0, 58, 59, 61, 64, 65, 68, 69, 70, 71, 72, 74, 77, 78, 79, 80, 81, 82, 84, 87, 88, 89, 91, 92, 93, 94, 97, 99, 101, 103, 104, 107, 108, 110, 112, 114, 115, 116, 117, 118, 119, 120, 121, 122, 0, 123, 124, 0, 125, 126, 0, 127, 129, 130, 131, 133, 119, 137, 138, 140, 141, 142, 143, 144, 145, 147, 149, 150, 151, 152, 153, 155, 156, 159, 160, 161, 162, 165, 166, 167, 168, 169, 170, 172, 176, 177, 179, 182, 183, 186, 0, 187, 190, 192, 193, 194, 195, 196, 197, 198, 0, 199, 200, 0, 202, 204, 205, 206, 208, 195, 213, 214, 215, 216, 217, 218, 0, 218, 0, 220, 221, 222, 224, 226, 227, 228, 229, 230, 233, 234, 235, 236, 238, 240, 243, 246, 247, 248, 250, 252, 253, 254, 0, 254, 0, 255, 259, 260, 261, 0, 262, 265, 266, 267, 271, 0, 271, 0, 271, 0, 272, 273, 275, 276, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 295, 297, 300};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337, 337};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 26 337
typenameGet 0 26 337
assign 1 26 337
TRANSUNITGet 0 26 337
assign 1 26 337
equals 1 26 337
assign 1 27 337
new 0 27 337
heldSet 1 27 337
assign 1 29 337
typenameGet 0 29 337
assign 1 29 337
VARGet 0 29 337
assign 1 29 337
equals 1 29 337
assign 1 30 337
heldGet 0 30 337
assign 1 30 337
undef 1 30 337
assign 1 0 337
assign 1 30 337
heldGet 0 30 337
assign 1 30 337
new 0 30 337
assign 1 30 337
emptyGet 0 30 337
assign 1 30 337
sameType 1 30 337
assign 1 0 337
assign 1 0 337
assign 1 31 337
new 0 31 337
heldSet 1 32 337
assign 1 35 337
nextPeerGet 0 35 337
assign 1 36 337
def 1 36 337
assign 1 36 337
typenameGet 0 36 337
assign 1 36 337
IDGet 0 36 337
assign 1 36 337
equals 1 36 337
assign 1 0 337
assign 1 36 337
typenameGet 0 36 337
assign 1 36 337
NAMEPATHGet 0 36 337
assign 1 36 337
equals 1 36 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 36 337
typenameGet 0 36 337
assign 1 36 337
IDGet 0 36 337
assign 1 36 337
equals 1 36 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 38 337
typenameGet 0 38 337
assign 1 38 337
IDGet 0 38 337
assign 1 38 337
equals 1 38 337
assign 1 39 337
new 0 39 337
assign 1 40 337
heldGet 0 40 337
addStep 1 40 337
assign 1 42 337
heldGet 0 42 337
assign 1 44 337
new 0 44 337
assign 1 45 337
new 0 45 337
isTypedSet 1 45 337
namepathSet 1 47 337
assign 1 48 337
VARGet 0 48 337
typenameSet 1 48 337
heldSet 1 49 337
assign 1 51 337
typenameGet 0 51 337
assign 1 51 337
USEGet 0 51 337
assign 1 51 337
equals 1 51 337
assign 1 53 337
nextPeerGet 0 53 337
assign 1 54 337
def 1 54 337
assign 1 54 337
typenameGet 0 54 337
assign 1 54 337
DEFMODGet 0 54 337
assign 1 54 337
equals 1 54 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 55 337
nextPeerGet 0 55 337
assign 1 57 337
def 1 57 337
assign 1 57 337
typenameGet 0 57 337
assign 1 57 337
CLASSGet 0 57 337
assign 1 57 337
equals 1 57 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 58 337
assign 1 59 337
containedGet 0 59 337
assign 1 59 337
firstGet 0 59 337
assign 1 61 337
assign 1 64 337
undef 1 64 337
assign 1 65 337
new 0 65 337
assign 1 65 337
new 2 65 337
throw 1 65 337
assign 1 68 337
typenameGet 0 68 337
assign 1 68 337
IDGet 0 68 337
assign 1 68 337
equals 1 68 337
assign 1 69 337
new 0 69 337
assign 1 70 337
heldGet 0 70 337
addStep 1 70 337
assign 1 71 337
typenameGet 0 71 337
assign 1 71 337
NAMEPATHGet 0 71 337
assign 1 71 337
equals 1 71 337
assign 1 72 337
heldGet 0 72 337
assign 1 74 337
new 0 74 337
assign 1 74 337
new 2 74 337
throw 1 74 337
assign 1 77 337
assign 1 78 337
nextPeerGet 0 78 337
assign 1 79 337
typenameGet 0 79 337
assign 1 79 337
ASGet 0 79 337
assign 1 79 337
equals 1 79 337
assign 1 80 337
nextPeerGet 0 80 337
assign 1 81 337
typenameGet 0 81 337
assign 1 81 337
IDGet 0 81 337
assign 1 81 337
notEquals 1 81 337
assign 1 82 337
new 0 82 337
assign 1 82 337
new 2 82 337
throw 1 82 337
assign 1 84 337
heldGet 0 84 337
assign 1 87 337
undef 1 87 337
assign 1 88 337
nextPeerGet 0 88 337
delete 0 89 337
assign 1 91 337
typenameGet 0 91 337
assign 1 91 337
SEMIGet 0 91 337
assign 1 91 337
equals 1 91 337
assign 1 92 337
assign 1 93 337
nextPeerGet 0 93 337
delete 0 94 337
assign 1 97 337
heldSet 1 99 337
assign 1 101 337
transUnitGet 0 101 337
assign 1 103 337
undef 1 103 337
assign 1 104 337
new 0 104 337
assign 1 104 337
new 2 104 337
throw 1 104 337
assign 1 107 337
undef 1 107 337
assign 1 108 337
labelGet 0 108 337
assign 1 110 337
heldGet 0 110 337
assign 1 110 337
aliasedGet 0 110 337
put 2 110 337
return 1 112 337
assign 1 114 337
typenameGet 0 114 337
assign 1 114 337
CLASSGet 0 114 337
assign 1 114 337
equals 1 114 337
assign 1 115 337
new 0 115 337
assign 1 116 337
new 0 116 337
assign 1 117 337
new 0 117 337
assign 1 118 337
priorPeerGet 0 118 337
assign 1 119 337
new 0 119 337
assign 1 119 337
new 0 119 337
assign 1 119 337
lesser 1 119 337
assign 1 120 337
def 1 120 337
assign 1 121 337
typenameGet 0 121 337
assign 1 121 337
DEFMODGet 0 121 337
assign 1 121 337
equals 1 121 337
assign 1 122 337
typenameGet 0 122 337
assign 1 122 337
DEFMODGet 0 122 337
assign 1 122 337
equals 1 122 337
assign 1 122 337
heldGet 0 122 337
assign 1 122 337
new 0 122 337
assign 1 122 337
equals 1 122 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 123 337
new 0 123 337
assign 1 124 337
typenameGet 0 124 337
assign 1 124 337
DEFMODGet 0 124 337
assign 1 124 337
equals 1 124 337
assign 1 124 337
heldGet 0 124 337
assign 1 124 337
new 0 124 337
assign 1 124 337
equals 1 124 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 125 337
new 0 125 337
assign 1 126 337
typenameGet 0 126 337
assign 1 126 337
DEFMODGet 0 126 337
assign 1 126 337
equals 1 126 337
assign 1 126 337
heldGet 0 126 337
assign 1 126 337
new 0 126 337
assign 1 126 337
equals 1 126 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 127 337
new 0 127 337
assign 1 129 337
priorPeerGet 0 129 337
delete 0 130 337
assign 1 131 337
assign 1 133 337
assign 1 119 337
increment 0 119 337
assign 1 137 337
new 0 137 337
heldSet 1 137 337
assign 1 138 337
heldGet 0 138 337
assign 1 138 337
fromFileGet 0 138 337
fromFileSet 1 138 337
assign 1 140 337
containedGet 0 140 337
assign 1 140 337
firstGet 0 140 337
assign 1 141 337
typenameGet 0 141 337
assign 1 141 337
IDGet 0 141 337
assign 1 141 337
equals 1 141 337
assign 1 142 337
new 0 142 337
assign 1 143 337
heldGet 0 143 337
addStep 1 143 337
assign 1 144 337
typenameGet 0 144 337
assign 1 144 337
NAMEPATHGet 0 144 337
assign 1 144 337
equals 1 144 337
assign 1 145 337
heldGet 0 145 337
assign 1 147 337
new 0 147 337
assign 1 147 337
new 2 147 337
throw 1 147 337
assign 1 149 337
heldGet 0 149 337
namepathSet 1 149 337
assign 1 150 337
heldGet 0 150 337
isFinalSet 1 150 337
assign 1 151 337
heldGet 0 151 337
isLocalSet 1 151 337
assign 1 152 337
heldGet 0 152 337
isNotNullSet 1 152 337
delete 0 153 337
print 0 155 337
assign 1 156 337
new 0 156 337
assign 1 156 337
new 2 156 337
throw 1 156 337
assign 1 159 337
containedGet 0 159 337
assign 1 159 337
firstGet 0 159 337
assign 1 160 337
typenameGet 0 160 337
assign 1 160 337
PARENSGet 0 160 337
assign 1 160 337
equals 1 160 337
assign 1 161 337
containedGet 0 161 337
assign 1 161 337
lengthGet 0 161 337
assign 1 161 337
new 0 161 337
assign 1 161 337
greater 1 161 337
assign 1 162 337
new 0 162 337
assign 1 162 337
new 2 162 337
throw 1 162 337
assign 1 165 337
containedGet 0 165 337
assign 1 165 337
firstGet 0 165 337
assign 1 166 337
typenameGet 0 166 337
assign 1 166 337
IDGet 0 166 337
assign 1 166 337
equals 1 166 337
assign 1 167 337
heldGet 0 167 337
assign 1 167 337
new 0 167 337
extendsSet 1 167 337
assign 1 168 337
heldGet 0 168 337
assign 1 168 337
extendsGet 0 168 337
assign 1 168 337
heldGet 0 168 337
addStep 1 168 337
assign 1 169 337
typenameGet 0 169 337
assign 1 169 337
NAMEPATHGet 0 169 337
assign 1 169 337
equals 1 169 337
assign 1 170 337
heldGet 0 170 337
assign 1 170 337
heldGet 0 170 337
extendsSet 1 170 337
assign 1 172 337
new 0 172 337
assign 1 172 337
new 2 172 337
throw 1 172 337
print 0 176 337
assign 1 177 337
new 0 177 337
assign 1 177 337
new 2 177 337
throw 1 177 337
delete 0 179 337
print 0 182 337
assign 1 183 337
new 0 183 337
assign 1 183 337
new 2 183 337
throw 1 183 337
assign 1 186 337
heldGet 0 186 337
assign 1 186 337
extendsGet 0 186 337
assign 1 186 337
undef 1 186 337
assign 1 186 337
heldGet 0 186 337
assign 1 186 337
namepathGet 0 186 337
assign 1 186 337
toString 0 186 337
assign 1 186 337
new 0 186 337
assign 1 186 337
notEquals 1 186 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 187 337
heldGet 0 187 337
assign 1 187 337
new 0 187 337
assign 1 187 337
new 0 187 337
assign 1 187 337
fromString 1 187 337
extendsSet 1 187 337
assign 1 190 337
nextDescendGet 0 190 337
return 1 190 337
assign 1 192 337
typenameGet 0 192 337
assign 1 192 337
METHODGet 0 192 337
assign 1 192 337
equals 1 192 337
assign 1 193 337
new 0 193 337
heldSet 1 193 337
assign 1 194 337
priorPeerGet 0 194 337
assign 1 195 337
new 0 195 337
assign 1 195 337
new 0 195 337
assign 1 195 337
lesser 1 195 337
assign 1 196 337
def 1 196 337
assign 1 197 337
typenameGet 0 197 337
assign 1 197 337
DEFMODGet 0 197 337
assign 1 197 337
equals 1 197 337
assign 1 198 337
typenameGet 0 198 337
assign 1 198 337
DEFMODGet 0 198 337
assign 1 198 337
equals 1 198 337
assign 1 198 337
heldGet 0 198 337
assign 1 198 337
new 0 198 337
assign 1 198 337
equals 1 198 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 199 337
heldGet 0 199 337
assign 1 199 337
new 0 199 337
isFinalSet 1 199 337
assign 1 200 337
typenameGet 0 200 337
assign 1 200 337
DEFMODGet 0 200 337
assign 1 200 337
equals 1 200 337
assign 1 200 337
heldGet 0 200 337
assign 1 200 337
new 0 200 337
assign 1 200 337
equals 1 200 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 202 337
new 0 202 337
assign 1 202 337
new 2 202 337
throw 1 202 337
assign 1 204 337
priorPeerGet 0 204 337
delete 0 205 337
assign 1 206 337
assign 1 208 337
assign 1 195 337
increment 0 195 337
assign 1 213 337
containedGet 0 213 337
assign 1 213 337
firstGet 0 213 337
assign 1 214 337
def 1 214 337
assign 1 215 337
nextPeerGet 0 215 337
assign 1 216 337
def 1 216 337
assign 1 217 337
nextPeerGet 0 217 337
assign 1 218 337
typenameGet 0 218 337
assign 1 218 337
IDGet 0 218 337
assign 1 218 337
equals 1 218 337
assign 1 0 337
assign 1 218 337
typenameGet 0 218 337
assign 1 218 337
NAMEPATHGet 0 218 337
assign 1 218 337
equals 1 218 337
assign 1 0 337
assign 1 0 337
assign 1 220 337
typenameGet 0 220 337
assign 1 220 337
IDGet 0 220 337
assign 1 220 337
equals 1 220 337
assign 1 221 337
new 0 221 337
assign 1 222 337
heldGet 0 222 337
addStep 1 222 337
assign 1 224 337
heldGet 0 224 337
assign 1 226 337
new 0 226 337
assign 1 227 337
new 0 227 337
isTypedSet 1 227 337
namepathSet 1 228 337
assign 1 229 337
VARGet 0 229 337
typenameSet 1 229 337
heldSet 1 230 337
assign 1 233 337
typenameGet 0 233 337
assign 1 233 337
IDGet 0 233 337
assign 1 233 337
equals 1 233 337
assign 1 234 337
heldGet 0 234 337
assign 1 234 337
heldGet 0 234 337
nameSet 1 234 337
assign 1 235 337
heldGet 0 235 337
assign 1 235 337
nameGet 0 235 337
assign 1 235 337
new 0 235 337
assign 1 235 337
getPoint 1 235 337
assign 1 235 337
isInteger 0 235 337
assign 1 236 337
new 0 236 337
assign 1 236 337
new 2 236 337
throw 1 236 337
delete 0 238 337
assign 1 240 337
new 0 240 337
assign 1 240 337
new 2 240 337
throw 1 240 337
assign 1 243 337
new 0 243 337
assign 1 243 337
new 2 243 337
throw 1 243 337
assign 1 246 337
classNameGet 0 246 337
assign 1 246 337
new 0 246 337
assign 1 246 337
equals 1 246 337
throw 1 246 337
print 0 247 337
assign 1 248 337
new 0 248 337
assign 1 248 337
new 2 248 337
throw 1 248 337
assign 1 250 337
nextDescendGet 0 250 337
return 1 250 337
assign 1 252 337
constantsGet 0 252 337
assign 1 252 337
parensReqGet 0 252 337
assign 1 252 337
typenameGet 0 252 337
assign 1 252 337
has 1 252 337
assign 1 253 337
containedGet 0 253 337
assign 1 253 337
firstGet 0 253 337
assign 1 254 337
undef 1 254 337
assign 1 0 337
assign 1 254 337
typenameGet 0 254 337
assign 1 254 337
PARENSGet 0 254 337
assign 1 254 337
notEquals 1 254 337
assign 1 0 337
assign 1 0 337
assign 1 255 337
new 0 255 337
assign 1 255 337
new 2 255 337
throw 1 255 337
assign 1 259 337
typenameGet 0 259 337
assign 1 259 337
BRACESGet 0 259 337
assign 1 259 337
equals 1 259 337
assign 1 260 337
containerGet 0 260 337
assign 1 261 337
def 1 261 337
assign 1 261 337
typenameGet 0 261 337
assign 1 261 337
EXPRGet 0 261 337
assign 1 261 337
equals 1 261 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 262 337
PARENSGet 0 262 337
typenameSet 1 262 337
assign 1 265 337
typenameGet 0 265 337
assign 1 265 337
SEMIGet 0 265 337
assign 1 265 337
equals 1 265 337
assign 1 266 337
priorPeerGet 0 266 337
assign 1 267 337
nextAscendGet 0 267 337
assign 1 271 337
def 1 271 337
assign 1 271 337
typenameGet 0 271 337
assign 1 271 337
SEMIGet 0 271 337
assign 1 271 337
notEquals 1 271 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 271 337
typenameGet 0 271 337
assign 1 271 337
BRACESGet 0 271 337
assign 1 271 337
notEquals 1 271 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 271 337
typenameGet 0 271 337
assign 1 271 337
EXPRGet 0 271 337
assign 1 271 337
notEquals 1 271 337
assign 1 0 337
assign 1 0 337
assign 1 0 337
assign 1 272 337
undef 1 272 337
assign 1 273 337
new 0 273 337
prepend 1 275 337
assign 1 276 337
priorPeerGet 0 276 337
assign 1 278 337
def 1 278 337
assign 1 279 337
EXPRGet 0 279 337
typenameSet 1 279 337
heldSet 1 280 337
assign 1 281 337
new 1 281 337
assign 1 282 337
PARENSGet 0 282 337
typenameSet 1 282 337
addValue 1 283 337
copyLoc 1 284 337
assign 1 285 337
iteratorGet 0 285 337
assign 1 285 337
hasNextGet 0 285 337
assign 1 286 337
nextGet 0 286 337
delete 0 287 337
addValue 1 288 337
delete 0 295 337
return 1 297 337
assign 1 300 337
nextDescendGet 0 300 337
return 1 300 337
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass5();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass5.bevs_inst = (BEC_5_5_5_BuildVisitPass5)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass5.bevs_inst;
}
}
