package be.BEL_4_Base;
/* IO:File: source/build/Pass7.be */
public class BEC_3_5_5_5_BuildVisitPass7 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x65,0x77};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_4 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_5 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_6 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_7 = {0x74,0x72,0x75,0x65};
private static byte[] bels_8 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_9 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_10 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_11, 41));
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_17 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_18 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_20 = {0x6E,0x65,0x77};
public static BEC_3_5_5_5_BuildVisitPass7 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_3_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(630006451, BEL_4_Base.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_5_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_5_tmpvar_phold);
bevl_nlnpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_0));
bevl_nlc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEL_4_Base.bevn_isLiteralSet_1, bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_11_tmpvar_phold);
beva_node.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_12_tmpvar_phold);
beva_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_14_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_1));
bevt_13_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_16_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_2));
bevt_15_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 49 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 51 */ {
bevt_19_tmpvar_phold = bevl_pn.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_20_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_22_tmpvar_phold = bevl_pn.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_23_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
 else  /* Line: 51 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_26_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_27_tmpvar_phold);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_29_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_30_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_32_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_33_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_35_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_36_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_36_tmpvar_phold);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_38_tmpvar_phold = bevl_pn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpvar_phold = bevl_nlc.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_39_tmpvar_phold);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_37_tmpvar_phold);
bevl_pn.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 60 */
} /* Line: 53 */
} /* Line: 51 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_116_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_118_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_131_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpvar_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 89 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 91 */
if (bevp_inClassNp == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 93 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 95 */
bevt_16_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpvar_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpvar_phold.bevi_int == bevt_17_tmpvar_phold.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 97 */ {
bevt_18_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_3));
this.bem_buildLiteral_2(beva_node, bevt_18_tmpvar_phold);
} /* Line: 98 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpvar_phold.bevi_int == bevt_21_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevt_22_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_4));
this.bem_buildLiteral_2(beva_node, bevt_22_tmpvar_phold);
} /* Line: 101 */
bevt_24_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpvar_phold.bevi_int == bevt_25_tmpvar_phold.bevi_int) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_26_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_5));
this.bem_buildLiteral_2(beva_node, bevt_26_tmpvar_phold);
} /* Line: 104 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpvar_phold.bevi_int == bevt_29_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 106 */ {
bevt_30_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_6));
this.bem_buildLiteral_2(beva_node, bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpvar_phold);
} /* Line: 109 */
bevt_33_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpvar_phold.bevi_int == bevt_34_tmpvar_phold.bevi_int) {
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 111 */ {
bevt_35_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_7));
beva_node.bem_heldSet_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_8));
this.bem_buildLiteral_2(beva_node, bevt_36_tmpvar_phold);
} /* Line: 113 */
bevt_38_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpvar_phold.bevi_int == bevt_39_tmpvar_phold.bevi_int) {
bevt_37_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 119 */ {
bevt_40_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_9));
beva_node.bem_heldSet_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_10));
this.bem_buildLiteral_2(beva_node, bevt_41_tmpvar_phold);
} /* Line: 121 */
 else  /* Line: 119 */ {
bevt_43_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpvar_phold.bevi_int == bevt_44_tmpvar_phold.bevi_int) {
bevt_42_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 123 */ {
bevt_47_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 123 */
 else  /* Line: 123 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 123 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_49_tmpvar_phold == null) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 124 */ {
if (bevl_nnode == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_53_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_54_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
 else  /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevt_57_tmpvar_phold = bevo_0;
bevt_59_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_55_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_55_tmpvar_phold);
} /* Line: 125 */
 else  /* Line: 126 */ {
bevt_60_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_61_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpvar_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_62_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpvar_phold;
} /* Line: 133 */
} /* Line: 124 */
 else  /* Line: 119 */ {
bevt_64_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpvar_phold.bevi_int == bevt_65_tmpvar_phold.bevi_int) {
bevt_63_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 135 */ {
if (bevl_nnode == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_68_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 136 */
 else  /* Line: 136 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 136 */ {
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_71_tmpvar_phold == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 137 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_72_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 139 */ {
bevt_73_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 139 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_75_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 142 */
} /* Line: 141 */
 else  /* Line: 139 */ {
break;
} /* Line: 139 */
} /* Line: 139 */
bevl_ii = bevl_toremove.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 145 */ {
bevt_77_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 147 */
 else  /* Line: 145 */ {
break;
} /* Line: 145 */
} /* Line: 145 */
} /* Line: 145 */
bevl_pc = bevl_nnode;
bevt_78_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpvar_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_79_tmpvar_phold);
bevl_pc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 158 */ {
bevt_82_tmpvar_phold = bevl_dnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_83_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpvar_phold);
if (bevt_81_tmpvar_phold != null && bevt_81_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_81_tmpvar_phold).bevi_bool) /* Line: 158 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 158 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 158 */
 else  /* Line: 158 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 158 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_onode == null) {
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevt_86_tmpvar_phold = (new BEC_2_4_6_TextString(38, bels_12));
bevt_85_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_85_tmpvar_phold);
} /* Line: 161 */
 else  /* Line: 160 */ {
bevt_88_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpvar_phold.bevi_int == bevt_89_tmpvar_phold.bevi_int) {
bevt_87_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_91_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpvar_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpvar_phold);
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_92_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_92_tmpvar_phold);
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_94_tmpvar_phold);
} /* Line: 166 */
 else  /* Line: 167 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 168 */
} /* Line: 163 */
 else  /* Line: 160 */ {
bevt_96_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpvar_phold.bevi_int == bevt_97_tmpvar_phold.bevi_int) {
bevt_95_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 170 */ {
bevt_101_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_102_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpvar_phold = bevt_99_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_102_tmpvar_phold);
if (bevt_98_tmpvar_phold != null && bevt_98_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_98_tmpvar_phold).bevi_bool) /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_105_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_aliasedGet_0();
bevt_106_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_has_1(bevt_106_tmpvar_phold);
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 170 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 170 */
 else  /* Line: 170 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 170 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_109_tmpvar_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpvar_phold);
if (bevt_109_tmpvar_phold.bevi_bool) /* Line: 176 */ {
bevt_111_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_111_tmpvar_phold);
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_112_tmpvar_phold);
bevt_113_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_113_tmpvar_phold);
} /* Line: 179 */
 else  /* Line: 180 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 181 */
} /* Line: 176 */
 else  /* Line: 160 */ {
bevt_115_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_116_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_13));
bevt_114_tmpvar_phold = bevt_115_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpvar_phold);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 183 */ {
bevt_118_tmpvar_phold = (new BEC_2_4_6_TextString(70, bels_14));
bevt_117_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_117_tmpvar_phold);
} /* Line: 184 */
 else  /* Line: 160 */ {
bevt_120_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_121_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_15));
bevt_119_tmpvar_phold = bevt_120_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_121_tmpvar_phold);
if (bevt_119_tmpvar_phold != null && bevt_119_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_119_tmpvar_phold).bevi_bool) /* Line: 185 */ {
bevt_123_tmpvar_phold = (new BEC_2_4_6_TextString(65, bels_16));
bevt_122_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_122_tmpvar_phold);
} /* Line: 186 */
} /* Line: 160 */
} /* Line: 160 */
} /* Line: 160 */
} /* Line: 160 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_onode);
bevl_dnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 191 */
 else  /* Line: 192 */ {
bevt_124_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_124_tmpvar_phold);
bevt_125_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_125_tmpvar_phold);
} /* Line: 194 */
} /* Line: 158 */
} /* Line: 136 */
 else  /* Line: 119 */ {
bevt_127_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpvar_phold.bevi_int == bevt_128_tmpvar_phold.bevi_int) {
bevt_126_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_131_tmpvar_phold = (new BEC_2_4_6_TextString(34, bels_17));
bevt_130_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_130_tmpvar_phold);
} /* Line: 203 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpvar_phold.bevi_int == bevt_134_tmpvar_phold.bevi_int) {
bevt_132_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_136_tmpvar_phold = (new BEC_2_4_6_TextString(84, bels_18));
bevt_135_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_135_tmpvar_phold);
} /* Line: 208 */
bevt_137_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpvar_phold);
} /* Line: 210 */
 else  /* Line: 119 */ {
bevt_139_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpvar_phold.bevi_int == bevt_140_tmpvar_phold.bevi_int) {
bevt_138_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
if (bevl_onode == null) {
bevt_142_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 216 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 216 */ {
bevt_144_tmpvar_phold = (new BEC_2_4_6_TextString(34, bels_19));
bevt_143_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_143_tmpvar_phold);
} /* Line: 217 */
bevt_146_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_147_tmpvar_phold);
if (bevt_145_tmpvar_phold != null && bevt_145_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_145_tmpvar_phold).bevi_bool) /* Line: 219 */ {
bevl_pnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_pnode == null) {
bevt_148_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpvar_phold.bevi_bool) /* Line: 221 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_150_tmpvar_phold = bevl_pnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_151_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpvar_phold = bevt_150_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_151_tmpvar_phold);
if (bevt_149_tmpvar_phold != null && bevt_149_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_149_tmpvar_phold).bevi_bool) /* Line: 221 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 221 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpvar_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_ga.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_153_tmpvar_phold);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpvar_phold.bevi_int == bevt_156_tmpvar_phold.bevi_int) {
bevt_154_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpvar_phold.bevi_bool) /* Line: 230 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 231 */
 else  /* Line: 230 */ {
bevt_158_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpvar_phold.bevi_int == bevt_159_tmpvar_phold.bevi_int) {
bevt_157_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevt_163_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_161_tmpvar_phold = bevt_162_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_164_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpvar_phold = bevt_161_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_164_tmpvar_phold);
if (bevt_160_tmpvar_phold != null && bevt_160_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_160_tmpvar_phold).bevi_bool) /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 232 */ {
bevt_167_tmpvar_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpvar_phold = bevt_167_tmpvar_phold.bem_aliasedGet_0();
bevt_168_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bem_has_1(bevt_168_tmpvar_phold);
if (bevt_165_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 232 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 232 */
 else  /* Line: 232 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 232 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 238 */
} /* Line: 230 */
} /* Line: 230 */
} /* Line: 221 */
} /* Line: 219 */
} /* Line: 119 */
} /* Line: 119 */
} /* Line: 119 */
} /* Line: 119 */
bevt_171_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) throws Throwable {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpvar_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_20));
bevl_gnc.bem_nameSet_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpvar_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {26, 27, 29, 30, 30, 31, 32, 34, 35, 35, 36, 36, 37, 37, 38, 38, 39, 39, 40, 40, 42, 44, 44, 45, 47, 49, 49, 0, 49, 49, 0, 0, 50, 51, 51, 51, 51, 51, 0, 51, 51, 51, 0, 0, 0, 0, 0, 52, 53, 53, 0, 53, 53, 53, 53, 53, 53, 0, 0, 0, 53, 53, 53, 0, 0, 0, 53, 53, 53, 0, 0, 0, 0, 0, 59, 59, 59, 59, 60, 86, 89, 89, 89, 89, 90, 90, 91, 91, 91, 93, 93, 94, 95, 97, 97, 97, 97, 98, 98, 100, 100, 100, 100, 101, 101, 103, 103, 103, 103, 104, 104, 106, 106, 106, 106, 108, 108, 109, 109, 111, 111, 111, 111, 112, 112, 113, 113, 119, 119, 119, 119, 120, 120, 121, 121, 123, 123, 123, 123, 123, 123, 123, 0, 0, 0, 124, 124, 124, 124, 124, 124, 0, 124, 124, 124, 0, 0, 0, 0, 0, 125, 125, 125, 125, 125, 125, 127, 127, 127, 128, 129, 133, 133, 135, 135, 135, 135, 136, 136, 136, 136, 136, 0, 0, 0, 137, 137, 137, 138, 139, 139, 139, 140, 141, 141, 141, 142, 145, 145, 146, 147, 150, 151, 151, 152, 153, 153, 154, 155, 156, 157, 158, 158, 158, 158, 158, 0, 0, 0, 159, 160, 160, 161, 161, 161, 162, 162, 162, 162, 163, 163, 164, 164, 165, 165, 166, 166, 168, 170, 170, 170, 170, 170, 170, 170, 170, 170, 0, 170, 170, 170, 170, 0, 0, 0, 0, 0, 171, 172, 172, 173, 174, 174, 175, 176, 176, 177, 177, 178, 178, 179, 179, 181, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 189, 190, 191, 193, 193, 194, 194, 198, 198, 198, 198, 201, 202, 202, 203, 203, 203, 205, 206, 207, 207, 207, 207, 208, 208, 208, 210, 210, 211, 211, 211, 211, 213, 216, 216, 0, 216, 216, 0, 0, 217, 217, 217, 219, 219, 219, 220, 221, 221, 0, 221, 221, 221, 0, 0, 222, 223, 223, 224, 225, 225, 226, 227, 228, 229, 230, 230, 230, 230, 231, 232, 232, 232, 232, 232, 232, 232, 232, 232, 0, 232, 232, 232, 232, 0, 0, 0, 0, 0, 233, 234, 234, 235, 236, 236, 237, 238, 243, 243, 247, 248, 249, 249, 250, 250, 251, 253, 254, 254, 255, 255, 256, 256, 257, 257, 258, 258, 259, 260, 260, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 109, 112, 113, 115, 118, 122, 123, 128, 129, 130, 131, 133, 136, 137, 138, 140, 143, 147, 150, 154, 157, 158, 163, 164, 167, 168, 169, 171, 172, 173, 175, 178, 182, 185, 186, 187, 189, 192, 196, 199, 200, 201, 203, 206, 210, 213, 216, 220, 221, 222, 223, 224, 417, 418, 419, 420, 425, 426, 427, 428, 429, 430, 432, 437, 438, 439, 441, 442, 443, 448, 449, 450, 452, 453, 454, 459, 460, 461, 463, 464, 465, 470, 471, 472, 474, 475, 476, 481, 482, 483, 484, 485, 487, 488, 489, 494, 495, 496, 497, 498, 500, 501, 502, 507, 508, 509, 510, 511, 514, 515, 516, 521, 522, 523, 524, 526, 529, 533, 536, 537, 538, 543, 544, 549, 550, 553, 554, 555, 557, 560, 564, 567, 571, 574, 575, 576, 577, 578, 579, 582, 583, 584, 585, 586, 587, 588, 592, 593, 594, 599, 600, 605, 606, 607, 608, 610, 613, 617, 620, 621, 626, 627, 628, 629, 632, 634, 635, 636, 637, 639, 646, 649, 651, 652, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 674, 675, 676, 677, 679, 682, 686, 689, 690, 695, 696, 697, 698, 701, 702, 703, 708, 709, 710, 712, 713, 714, 715, 716, 717, 720, 724, 725, 726, 731, 732, 733, 734, 735, 736, 738, 741, 742, 743, 744, 746, 749, 753, 756, 760, 763, 764, 765, 766, 767, 768, 769, 770, 771, 773, 774, 775, 776, 777, 778, 781, 785, 786, 787, 789, 790, 791, 794, 795, 796, 798, 799, 800, 806, 807, 808, 811, 812, 813, 814, 819, 820, 821, 826, 827, 828, 833, 834, 835, 836, 838, 839, 840, 841, 842, 847, 848, 849, 850, 852, 853, 856, 857, 858, 863, 864, 865, 870, 871, 874, 879, 880, 883, 887, 888, 889, 891, 892, 893, 895, 896, 901, 902, 905, 906, 907, 909, 912, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 933, 934, 937, 938, 939, 944, 945, 946, 947, 948, 949, 951, 954, 955, 956, 957, 959, 962, 966, 969, 973, 976, 977, 978, 979, 980, 981, 982, 983, 993, 994, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1031, 1034, 1038, 1041};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 26 81
new 0 26 81
fromString 1 27 82
assign 1 29 83
new 1 29 83
assign 1 30 84
NAMEPATHGet 0 30 84
typenameSet 1 30 85
heldSet 1 31 86
copyLoc 1 32 87
assign 1 34 88
new 0 34 88
assign 1 35 89
new 0 35 89
nameSet 1 35 90
assign 1 36 91
new 0 36 91
wasBoundSet 1 36 92
assign 1 37 93
new 0 37 93
boundSet 1 37 94
assign 1 38 95
new 0 38 95
isConstructSet 1 38 96
assign 1 39 97
new 0 39 97
isLiteralSet 1 39 98
assign 1 40 99
heldGet 0 40 99
literalValueSet 1 40 100
addValue 1 42 101
assign 1 44 102
CALLGet 0 44 102
typenameSet 1 44 103
heldSet 1 45 104
resolveNp 0 47 105
assign 1 49 106
new 0 49 106
assign 1 49 107
equals 1 49 107
assign 1 0 109
assign 1 49 112
new 0 49 112
assign 1 49 113
equals 1 49 113
assign 1 0 115
assign 1 0 118
assign 1 50 122
priorPeerGet 0 50 122
assign 1 51 123
def 1 51 128
assign 1 51 129
typenameGet 0 51 129
assign 1 51 130
SUBTRACTGet 0 51 130
assign 1 51 131
equals 1 51 131
assign 1 0 133
assign 1 51 136
typenameGet 0 51 136
assign 1 51 137
ADDGet 0 51 137
assign 1 51 138
equals 1 51 138
assign 1 0 140
assign 1 0 143
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 52 157
priorPeerGet 0 52 157
assign 1 53 158
undef 1 53 163
assign 1 0 164
assign 1 53 167
typenameGet 0 53 167
assign 1 53 168
CALLGet 0 53 168
assign 1 53 169
notEquals 1 53 169
assign 1 53 171
typenameGet 0 53 171
assign 1 53 172
IDGet 0 53 172
assign 1 53 173
notEquals 1 53 173
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 53 185
typenameGet 0 53 185
assign 1 53 186
VARGet 0 53 186
assign 1 53 187
notEquals 1 53 187
assign 1 0 189
assign 1 0 192
assign 1 0 196
assign 1 53 199
typenameGet 0 53 199
assign 1 53 200
ACCESSORGet 0 53 200
assign 1 53 201
notEquals 1 53 201
assign 1 0 203
assign 1 0 206
assign 1 0 210
assign 1 0 213
assign 1 0 216
assign 1 59 220
heldGet 0 59 220
assign 1 59 221
literalValueGet 0 59 221
assign 1 59 222
add 1 59 222
literalValueSet 1 59 223
delete 0 60 224
assign 1 86 417
nextPeerGet 0 86 417
assign 1 89 418
typenameGet 0 89 418
assign 1 89 419
CLASSGet 0 89 419
assign 1 89 420
equals 1 89 425
assign 1 90 426
heldGet 0 90 426
assign 1 90 427
namepathGet 0 90 427
assign 1 91 428
heldGet 0 91 428
assign 1 91 429
fromFileGet 0 91 429
assign 1 91 430
toString 0 91 430
assign 1 93 432
def 1 93 437
inClassNpSet 1 94 438
inFileSet 1 95 439
assign 1 97 441
typenameGet 0 97 441
assign 1 97 442
INTLGet 0 97 442
assign 1 97 443
equals 1 97 448
assign 1 98 449
new 0 98 449
buildLiteral 2 98 450
assign 1 100 452
typenameGet 0 100 452
assign 1 100 453
FLOATLGet 0 100 453
assign 1 100 454
equals 1 100 459
assign 1 101 460
new 0 101 460
buildLiteral 2 101 461
assign 1 103 463
typenameGet 0 103 463
assign 1 103 464
STRINGLGet 0 103 464
assign 1 103 465
equals 1 103 470
assign 1 104 471
new 0 104 471
buildLiteral 2 104 472
assign 1 106 474
typenameGet 0 106 474
assign 1 106 475
WSTRINGLGet 0 106 475
assign 1 106 476
equals 1 106 481
assign 1 108 482
new 0 108 482
buildLiteral 2 108 483
assign 1 109 484
new 0 109 484
wideStringSet 1 109 485
assign 1 111 487
typenameGet 0 111 487
assign 1 111 488
TRUEGet 0 111 488
assign 1 111 489
equals 1 111 494
assign 1 112 495
new 0 112 495
heldSet 1 112 496
assign 1 113 497
new 0 113 497
buildLiteral 2 113 498
assign 1 119 500
typenameGet 0 119 500
assign 1 119 501
FALSEGet 0 119 501
assign 1 119 502
equals 1 119 507
assign 1 120 508
new 0 120 508
heldSet 1 120 509
assign 1 121 510
new 0 121 510
buildLiteral 2 121 511
assign 1 123 514
typenameGet 0 123 514
assign 1 123 515
VARGet 0 123 515
assign 1 123 516
equals 1 123 521
assign 1 123 522
heldGet 0 123 522
assign 1 123 523
isArgGet 0 123 523
assign 1 123 524
not 0 123 524
assign 1 0 526
assign 1 0 529
assign 1 0 533
assign 1 124 536
heldGet 0 124 536
assign 1 124 537
nameGet 0 124 537
assign 1 124 538
undef 1 124 543
assign 1 124 544
undef 1 124 549
assign 1 0 550
assign 1 124 553
typenameGet 0 124 553
assign 1 124 554
IDGet 0 124 554
assign 1 124 555
notEquals 1 124 555
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 0 567
assign 1 0 571
assign 1 125 574
new 0 125 574
assign 1 125 575
heldGet 0 125 575
assign 1 125 576
nameGet 0 125 576
assign 1 125 577
add 1 125 577
assign 1 125 578
new 2 125 578
throw 1 125 579
assign 1 127 582
heldGet 0 127 582
assign 1 127 583
heldGet 0 127 583
nameSet 1 127 584
addVariable 0 128 585
delete 0 129 586
assign 1 133 587
nextDescendGet 0 133 587
return 1 133 588
assign 1 135 592
typenameGet 0 135 592
assign 1 135 593
IDGet 0 135 593
assign 1 135 594
equals 1 135 599
assign 1 136 600
def 1 136 605
assign 1 136 606
typenameGet 0 136 606
assign 1 136 607
PARENSGet 0 136 607
assign 1 136 608
equals 1 136 608
assign 1 0 610
assign 1 0 613
assign 1 0 617
assign 1 137 620
containedGet 0 137 620
assign 1 137 621
def 1 137 626
assign 1 138 627
new 0 138 627
assign 1 139 628
containedGet 0 139 628
assign 1 139 629
iteratorGet 0 139 629
assign 1 139 632
hasNextGet 0 139 632
assign 1 140 634
nextGet 0 140 634
assign 1 141 635
typenameGet 0 141 635
assign 1 141 636
COMMAGet 0 141 636
assign 1 141 637
equals 1 141 637
addValue 1 142 639
assign 1 145 646
iteratorGet 0 145 646
assign 1 145 649
hasNextGet 0 145 649
assign 1 146 651
nextGet 0 146 651
delete 0 147 652
assign 1 150 659
assign 1 151 660
CALLGet 0 151 660
typenameSet 1 151 661
assign 1 152 662
new 0 152 662
assign 1 153 663
heldGet 0 153 663
nameSet 1 153 664
heldSet 1 154 665
delete 0 155 666
assign 1 156 667
assign 1 157 668
priorPeerGet 0 157 668
assign 1 158 669
def 1 158 674
assign 1 158 675
typenameGet 0 158 675
assign 1 158 676
DOTGet 0 158 676
assign 1 158 677
equals 1 158 677
assign 1 0 679
assign 1 0 682
assign 1 0 686
assign 1 159 689
priorPeerGet 0 159 689
assign 1 160 690
undef 1 160 695
assign 1 161 696
new 0 161 696
assign 1 161 697
new 2 161 697
throw 1 161 698
assign 1 162 701
typenameGet 0 162 701
assign 1 162 702
NAMEPATHGet 0 162 702
assign 1 162 703
equals 1 162 708
assign 1 163 709
nameGet 0 163 709
assign 1 163 710
isNewish 1 163 710
assign 1 164 712
new 0 164 712
wasBoundSet 1 164 713
assign 1 165 714
new 0 165 714
boundSet 1 165 715
assign 1 166 716
new 0 166 716
isConstructSet 1 166 717
createImpliedConstruct 2 168 720
assign 1 170 724
typenameGet 0 170 724
assign 1 170 725
IDGet 0 170 725
assign 1 170 726
equals 1 170 731
assign 1 170 732
transUnitGet 0 170 732
assign 1 170 733
heldGet 0 170 733
assign 1 170 734
aliasedGet 0 170 734
assign 1 170 735
heldGet 0 170 735
assign 1 170 736
has 1 170 736
assign 1 0 738
assign 1 170 741
emitDataGet 0 170 741
assign 1 170 742
aliasedGet 0 170 742
assign 1 170 743
heldGet 0 170 743
assign 1 170 744
has 1 170 744
assign 1 0 746
assign 1 0 749
assign 1 0 753
assign 1 0 756
assign 1 0 760
assign 1 171 763
new 0 171 763
assign 1 172 764
heldGet 0 172 764
addStep 1 172 765
heldSet 1 173 766
assign 1 174 767
NAMEPATHGet 0 174 767
typenameSet 1 174 768
resolveNp 0 175 769
assign 1 176 770
nameGet 0 176 770
assign 1 176 771
isNewish 1 176 771
assign 1 177 773
new 0 177 773
wasBoundSet 1 177 774
assign 1 178 775
new 0 178 775
boundSet 1 178 776
assign 1 179 777
new 0 179 777
isConstructSet 1 179 778
createImpliedConstruct 2 181 781
assign 1 183 785
nameGet 0 183 785
assign 1 183 786
new 0 183 786
assign 1 183 787
equals 1 183 787
assign 1 184 789
new 0 184 789
assign 1 184 790
new 2 184 790
throw 1 184 791
assign 1 185 794
nameGet 0 185 794
assign 1 185 795
new 0 185 795
assign 1 185 796
equals 1 185 796
assign 1 186 798
new 0 186 798
assign 1 186 799
new 2 186 799
throw 1 186 800
delete 0 189 806
prepend 1 190 807
delete 0 191 808
assign 1 193 811
new 0 193 811
boundSet 1 193 812
assign 1 194 813
new 0 194 813
wasBoundSet 1 194 814
assign 1 198 819
typenameGet 0 198 819
assign 1 198 820
IDXGet 0 198 820
assign 1 198 821
equals 1 198 826
assign 1 201 827
priorPeerGet 0 201 827
assign 1 202 828
undef 1 202 833
assign 1 203 834
new 0 203 834
assign 1 203 835
new 2 203 835
throw 1 203 836
delete 0 205 838
prepend 1 206 839
assign 1 207 840
typenameGet 0 207 840
assign 1 207 841
NAMEPATHGet 0 207 841
assign 1 207 842
equals 1 207 847
assign 1 208 848
new 0 208 848
assign 1 208 849
new 2 208 849
throw 1 208 850
assign 1 210 852
IDXACCGet 0 210 852
typenameSet 1 210 853
assign 1 211 856
typenameGet 0 211 856
assign 1 211 857
DOTGet 0 211 857
assign 1 211 858
equals 1 211 863
assign 1 213 864
priorPeerGet 0 213 864
assign 1 216 865
undef 1 216 870
assign 1 0 871
assign 1 216 874
undef 1 216 879
assign 1 0 880
assign 1 0 883
assign 1 217 887
new 0 217 887
assign 1 217 888
new 2 217 888
throw 1 217 889
assign 1 219 891
typenameGet 0 219 891
assign 1 219 892
IDGet 0 219 892
assign 1 219 893
equals 1 219 893
assign 1 220 895
nextPeerGet 0 220 895
assign 1 221 896
undef 1 221 901
assign 1 0 902
assign 1 221 905
typenameGet 0 221 905
assign 1 221 906
PARENSGet 0 221 906
assign 1 221 907
notEquals 1 221 907
assign 1 0 909
assign 1 0 912
assign 1 222 916
priorPeerGet 0 222 916
assign 1 223 917
ACCESSORGet 0 223 917
typenameSet 1 223 918
assign 1 224 919
new 0 224 919
assign 1 225 920
heldGet 0 225 920
nameSet 1 225 921
delete 0 226 922
delete 0 227 923
heldSet 1 228 924
addValue 1 229 925
assign 1 230 926
typenameGet 0 230 926
assign 1 230 927
NAMEPATHGet 0 230 927
assign 1 230 928
equals 1 230 933
createImpliedConstruct 2 231 934
assign 1 232 937
typenameGet 0 232 937
assign 1 232 938
IDGet 0 232 938
assign 1 232 939
equals 1 232 944
assign 1 232 945
transUnitGet 0 232 945
assign 1 232 946
heldGet 0 232 946
assign 1 232 947
aliasedGet 0 232 947
assign 1 232 948
heldGet 0 232 948
assign 1 232 949
has 1 232 949
assign 1 0 951
assign 1 232 954
emitDataGet 0 232 954
assign 1 232 955
aliasedGet 0 232 955
assign 1 232 956
heldGet 0 232 956
assign 1 232 957
has 1 232 957
assign 1 0 959
assign 1 0 962
assign 1 0 966
assign 1 0 969
assign 1 0 973
assign 1 233 976
new 0 233 976
assign 1 234 977
heldGet 0 234 977
addStep 1 234 978
heldSet 1 235 979
assign 1 236 980
NAMEPATHGet 0 236 980
typenameSet 1 236 981
resolveNp 0 237 982
createImpliedConstruct 2 238 983
assign 1 243 993
nextDescendGet 0 243 993
return 1 243 994
assign 1 247 1007
new 0 247 1007
heldSet 1 248 1008
assign 1 249 1009
NAMEPATHGet 0 249 1009
typenameSet 1 249 1010
assign 1 250 1011
heldGet 0 250 1011
heldSet 1 250 1012
prepend 1 251 1013
assign 1 253 1014
new 0 253 1014
assign 1 254 1015
new 0 254 1015
nameSet 1 254 1016
assign 1 255 1017
new 0 255 1017
wasBoundSet 1 255 1018
assign 1 256 1019
new 0 256 1019
boundSet 1 256 1020
assign 1 257 1021
new 0 257 1021
isConstructSet 1 257 1022
assign 1 258 1023
new 0 258 1023
wasImpliedConstructSet 1 258 1024
heldSet 1 259 1025
assign 1 260 1026
CALLGet 0 260 1026
typenameSet 1 260 1027
return 1 0 1031
assign 1 0 1034
return 1 0 1038
assign 1 0 1041
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 822104518: return bem_inFileGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 856627742: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_5_BuildVisitPass7.bevs_inst = (BEC_3_5_5_5_BuildVisitPass7)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_5_BuildVisitPass7.bevs_inst;
}
}
