package be.BEL_4_Base;
/* IO:File: source/build/Transport.be */
public class BEC_5_9_BuildTransport extends BEC_6_6_SystemObject {
public BEC_5_9_BuildTransport() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65,0x3A};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 38));
private static byte[] bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 10));
private static byte[] bels_3 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_4, 10));
private static byte[] bels_5 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bels_6 = {0x6D,0x74,0x64};
private static byte[] bels_7 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_8 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static BEC_5_9_BuildTransport bevs_inst;
public BEC_5_5_BuildBuild bevp_build;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_5_4_BuildNode bevp_outermost;
public BEC_5_4_BuildNode bevp_current;
public BEC_5_9_BuildTransport bem_new_1(BEC_5_5_BuildBuild beva__build) throws Throwable {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(9, bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_9_BuildTransport bem_new_2(BEC_5_5_BuildBuild beva__build, BEC_5_4_BuildNode beva__outermost) throws Throwable {
BEC_5_9_BuildConstants bevt_0_tmpvar_phold = null;
bevp_build = beva__build;
bevt_0_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpvar_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_traverse_1(BEC_5_5_7_BuildVisitVisitor beva_visitor) throws Throwable {
BEC_5_4_BuildNode bevl_node = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
try  /* Line: 39 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 44 */ {
if (bevl_node == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 45 */
 else  /* Line: 44 */ {
break;
} /* Line: 44 */
} /* Line: 44 */
beva_visitor.bem_end_1(this);
} /* Line: 48 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 50 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold.bem_print_0();
bevl_node.bem_print_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 54 */
 else  /* Line: 55 */ {
bevt_4_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold.bem_print_0();
bevt_5_tmpvar_phold = bevo_3;
bevt_5_tmpvar_phold.bem_print_0();
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
} /* Line: 58 */
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 60 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_contain_0() throws Throwable {
BEC_9_3_ContainerMap bevl_conTypes = null;
BEC_5_4_BuildNode bevl_curr = null;
BEC_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_5_4_BuildNode bevl_node = null;
BEC_5_4_BuildNode bevl_wf = null;
BEC_5_4_BuildNode bevl_cnode = null;
BEC_5_4_BuildNode bevl_mnode = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_9_BuildConstants bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
bevt_6_tmpvar_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_6_tmpvar_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_iteratorGet_0();
while (true)
 /* Line: 69 */ {
bevt_7_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 69 */ {
bevl_node = (BEC_5_4_BuildNode) bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_node.bem_delayDeleteGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_11_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_12_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_equals_1(bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 74 */ {
bevt_14_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_15_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_equals_1(bevt_15_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 74 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 74 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 78 */ {
if (bevl_wf == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevt_18_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_19_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_equals_1(bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_21_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_22_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_equals_1(bevt_22_tmpvar_phold);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_24_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_25_tmpvar_phold = bevp_ntypes.bem_SPACEGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_equals_1(bevt_25_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 79 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 79 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 78 */
 else  /* Line: 78 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 79 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 80 */
 else  /* Line: 78 */ {
break;
} /* Line: 78 */
} /* Line: 78 */
if (bevl_wf == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_28_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_equals_1(bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_31_tmpvar_phold = bevl_wf.bem_typenameGet_0();
bevt_32_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_equals_1(bevt_32_tmpvar_phold);
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 82 */ {
bevl_cnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_33_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(5, bels_5));
bevl_cnode.bem_heldSet_1(bevt_34_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 89 */
} /* Line: 82 */
bevt_36_tmpvar_phold = bevl_curr.bem_typenameGet_0();
bevt_37_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_equals_1(bevt_37_tmpvar_phold);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 92 */ {
bevt_40_tmpvar_phold = bevl_curr.bem_containerGet_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_typenameGet_0();
bevt_41_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_equals_1(bevt_41_tmpvar_phold);
if (bevt_38_tmpvar_phold.bevi_bool) /* Line: 92 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 92 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 92 */
 else  /* Line: 92 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 92 */ {
bevt_43_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_44_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_equals_1(bevt_44_tmpvar_phold);
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 92 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 92 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 92 */
 else  /* Line: 92 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 92 */ {
bevl_mnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_45_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_45_tmpvar_phold);
bevt_46_tmpvar_phold = (new BEC_4_6_TextString(3, bels_6));
bevl_mnode.bem_heldSet_1(bevt_46_tmpvar_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 98 */
bevt_48_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_49_tmpvar_phold = bevp_ntypes.bem_RPARENSGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bem_equals_1(bevt_49_tmpvar_phold);
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 100 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 101 */
 else  /* Line: 100 */ {
bevt_51_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_52_tmpvar_phold = bevp_ntypes.bem_RIDXGet_0();
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bem_equals_1(bevt_52_tmpvar_phold);
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
} /* Line: 103 */
 else  /* Line: 100 */ {
bevt_54_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_55_tmpvar_phold = bevp_ntypes.bem_RBRACESGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_equals_1(bevt_55_tmpvar_phold);
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 106 */ {
bevt_58_tmpvar_phold = (new BEC_4_6_TextString(32, bels_7));
bevt_57_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_58_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_57_tmpvar_phold);
} /* Line: 107 */
bevl_curr = this.bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpvar_phold.bevi_bool) /* Line: 110 */ {
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(32, bels_8));
bevt_60_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_61_tmpvar_phold, bevl_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_60_tmpvar_phold);
} /* Line: 111 */
} /* Line: 110 */
 else  /* Line: 113 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 114 */
} /* Line: 100 */
} /* Line: 100 */
bevt_63_tmpvar_phold = bevl_node.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevl_conTypes.bem_has_1(bevt_63_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevl_curr = bevl_node;
} /* Line: 117 */
} /* Line: 116 */
} /* Line: 73 */
 else  /* Line: 69 */ {
break;
} /* Line: 69 */
} /* Line: 69 */
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_stepBack_1(BEC_5_4_BuildNode beva_curr) throws Throwable {
BEC_5_4_BuildNode bevl_hop = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 125 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(32, bels_9));
bevt_1_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpvar_phold, beva_curr);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 126 */
return bevl_hop;
} /*method end*/
public BEC_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_build = (BEC_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_outermostGet_0() throws Throwable {
return bevp_outermost;
} /*method end*/
public BEC_6_6_SystemObject bem_outermostSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outermost = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_currentGet_0() throws Throwable {
return bevp_current;
} /*method end*/
public BEC_6_6_SystemObject bem_currentSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_current = (BEC_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 22, 22, 23, 24, 26, 26, 27, 27, 31, 32, 32, 33, 34, 40, 42, 44, 44, 45, 48, 50, 50, 51, 51, 52, 53, 53, 54, 56, 56, 57, 57, 58, 60, 65, 65, 66, 67, 68, 69, 69, 72, 73, 73, 74, 74, 74, 74, 74, 74, 0, 0, 0, 77, 78, 78, 78, 78, 78, 0, 78, 78, 78, 0, 0, 0, 79, 79, 79, 0, 0, 0, 0, 0, 80, 82, 82, 82, 82, 82, 0, 82, 82, 82, 0, 0, 0, 0, 0, 85, 86, 86, 87, 87, 88, 89, 92, 92, 92, 92, 92, 92, 92, 0, 0, 0, 92, 92, 92, 0, 0, 0, 94, 95, 95, 96, 96, 97, 98, 100, 100, 100, 101, 102, 102, 102, 103, 104, 104, 104, 105, 106, 106, 107, 107, 107, 109, 110, 110, 111, 111, 111, 114, 116, 116, 117, 124, 125, 125, 126, 126, 126, 128, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 31, 32, 33, 34, 35, 36, 37, 38, 43, 44, 45, 46, 47, 60, 61, 64, 69, 70, 76, 80, 85, 86, 87, 88, 89, 90, 91, 94, 95, 96, 97, 98, 100, 177, 178, 179, 180, 181, 182, 185, 187, 188, 189, 191, 192, 193, 195, 196, 197, 199, 202, 206, 209, 212, 217, 218, 219, 220, 222, 225, 226, 227, 229, 232, 236, 239, 240, 241, 243, 246, 250, 253, 257, 260, 266, 271, 272, 273, 274, 276, 279, 280, 281, 283, 286, 290, 293, 297, 300, 301, 302, 303, 304, 305, 306, 309, 310, 311, 313, 314, 315, 316, 318, 321, 325, 328, 329, 330, 332, 335, 339, 342, 343, 344, 345, 346, 347, 348, 350, 351, 352, 354, 357, 358, 359, 361, 364, 365, 366, 368, 369, 374, 375, 376, 377, 379, 380, 385, 386, 387, 388, 392, 396, 397, 399, 414, 415, 420, 421, 422, 423, 425, 428, 431, 435, 438, 442, 445, 449, 452};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 21 30
assign 1 22 31
constantsGet 0 22 31
assign 1 22 32
ntypesGet 0 22 32
assign 1 23 33
new 1 23 33
assign 1 24 34
assign 1 26 35
TRANSUNITGet 0 26 35
typenameSet 1 26 36
assign 1 27 37
new 0 27 37
heldSet 1 27 38
assign 1 31 43
assign 1 32 44
constantsGet 0 32 44
assign 1 32 45
ntypesGet 0 32 45
assign 1 33 46
assign 1 34 47
begin 1 40 60
assign 1 42 61
accept 1 42 61
assign 1 44 64
def 1 44 69
assign 1 45 70
accept 1 45 70
end 1 48 76
assign 1 50 80
def 1 50 85
assign 1 51 86
new 0 51 86
print 0 51 87
print 0 52 88
assign 1 53 89
new 0 53 89
print 0 53 90
print 0 54 91
assign 1 56 94
new 0 56 94
print 0 56 95
assign 1 57 96
new 0 57 96
print 0 57 97
print 0 58 98
throw 1 60 100
assign 1 65 177
constantsGet 0 65 177
assign 1 65 178
conTypesGet 0 65 178
assign 1 66 179
assign 1 67 180
containedGet 0 67 180
containedSet 1 68 181
assign 1 69 182
iteratorGet 0 69 182
assign 1 69 185
hasNextGet 0 69 185
assign 1 72 187
nextGet 0 72 187
assign 1 73 188
delayDeleteGet 0 73 188
assign 1 73 189
not 0 73 189
assign 1 74 191
typenameGet 0 74 191
assign 1 74 192
TRANSUNITGet 0 74 192
assign 1 74 193
equals 1 74 193
assign 1 74 195
typenameGet 0 74 195
assign 1 74 196
IDGet 0 74 196
assign 1 74 197
equals 1 74 197
assign 1 0 199
assign 1 0 202
assign 1 0 206
assign 1 77 209
assign 1 78 212
def 1 78 217
assign 1 78 218
typenameGet 0 78 218
assign 1 78 219
IDGet 0 78 219
assign 1 78 220
equals 1 78 220
assign 1 0 222
assign 1 78 225
typenameGet 0 78 225
assign 1 78 226
COLONGet 0 78 226
assign 1 78 227
equals 1 78 227
assign 1 0 229
assign 1 0 232
assign 1 0 236
assign 1 79 239
typenameGet 0 79 239
assign 1 79 240
SPACEGet 0 79 240
assign 1 79 241
equals 1 79 241
assign 1 0 243
assign 1 0 246
assign 1 0 250
assign 1 0 253
assign 1 0 257
assign 1 80 260
nextPeerGet 0 80 260
assign 1 82 266
def 1 82 271
assign 1 82 272
typenameGet 0 82 272
assign 1 82 273
PARENSGet 0 82 273
assign 1 82 274
equals 1 82 274
assign 1 0 276
assign 1 82 279
typenameGet 0 82 279
assign 1 82 280
BRACESGet 0 82 280
assign 1 82 281
equals 1 82 281
assign 1 0 283
assign 1 0 286
assign 1 0 290
assign 1 0 293
assign 1 0 297
assign 1 85 300
new 1 85 300
assign 1 86 301
CLASSGet 0 86 301
typenameSet 1 86 302
assign 1 87 303
new 0 87 303
heldSet 1 87 304
addValue 1 88 305
assign 1 89 306
assign 1 92 309
typenameGet 0 92 309
assign 1 92 310
BRACESGet 0 92 310
assign 1 92 311
equals 1 92 311
assign 1 92 313
containerGet 0 92 313
assign 1 92 314
typenameGet 0 92 314
assign 1 92 315
CLASSGet 0 92 315
assign 1 92 316
equals 1 92 316
assign 1 0 318
assign 1 0 321
assign 1 0 325
assign 1 92 328
typenameGet 0 92 328
assign 1 92 329
IDGet 0 92 329
assign 1 92 330
equals 1 92 330
assign 1 0 332
assign 1 0 335
assign 1 0 339
assign 1 94 342
new 1 94 342
assign 1 95 343
METHODGet 0 95 343
typenameSet 1 95 344
assign 1 96 345
new 0 96 345
heldSet 1 96 346
addValue 1 97 347
assign 1 98 348
assign 1 100 350
typenameGet 0 100 350
assign 1 100 351
RPARENSGet 0 100 351
assign 1 100 352
equals 1 100 352
assign 1 101 354
stepBack 1 101 354
assign 1 102 357
typenameGet 0 102 357
assign 1 102 358
RIDXGet 0 102 358
assign 1 102 359
equals 1 102 359
assign 1 103 361
stepBack 1 103 361
assign 1 104 364
typenameGet 0 104 364
assign 1 104 365
RBRACESGet 0 104 365
assign 1 104 366
equals 1 104 366
assign 1 105 368
stepBack 1 105 368
assign 1 106 369
undef 1 106 374
assign 1 107 375
new 0 107 375
assign 1 107 376
new 2 107 376
throw 1 107 377
assign 1 109 379
stepBack 1 109 379
assign 1 110 380
undef 1 110 385
assign 1 111 386
new 0 111 386
assign 1 111 387
new 2 111 387
throw 1 111 388
addValue 1 114 392
assign 1 116 396
typenameGet 0 116 396
assign 1 116 397
has 1 116 397
assign 1 117 399
assign 1 124 414
containerGet 0 124 414
assign 1 125 415
undef 1 125 420
assign 1 126 421
new 0 126 421
assign 1 126 422
new 2 126 422
throw 1 126 423
return 1 128 425
return 1 0 428
assign 1 0 431
return 1 0 435
assign 1 0 438
return 1 0 442
assign 1 0 445
return 1 0 449
assign 1 0 452
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 410956923: return bem_contain_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case 1081412016: return bem_many_0();
case 1380522583: return bem_outermostGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_5_5_BuildBuild) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 2101994299: return bem_stepBack_1((BEC_5_4_BuildNode) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1369440330: return bem_outermostSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 688372900: return bem_traverse_1((BEC_5_5_7_BuildVisitVisitor) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_5_5_BuildBuild) bevd_0, (BEC_5_4_BuildNode) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_9_BuildTransport();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_9_BuildTransport.bevs_inst = (BEC_5_9_BuildTransport)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_9_BuildTransport.bevs_inst;
}
}
