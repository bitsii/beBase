package be.BEL_4_Base;
/* IO:File: source/build/Pass7.be */
public class BEC_5_5_5_BuildVisitPass7 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass7() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x65,0x77};
private static byte[] bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_2 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_3 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_4 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bels_5 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_6 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_7 = {0x74,0x72,0x75,0x65};
private static byte[] bels_8 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_9 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_10 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_11, 41));
private static byte[] bels_12 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_15 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_17 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_18 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_20 = {0x6E,0x65,0x77};
public static BEC_5_5_5_BuildVisitPass7 bevs_inst;
public BEC_5_8_BuildNamePath bevp_inClassNp;
public BEC_4_6_TextString bevp_inFile;
public BEC_5_5_5_BuildVisitPass7 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_buildLiteral_2(BEC_6_6_SystemObject beva_node, BEC_6_6_SystemObject beva_tName) throws Throwable {
BEC_6_6_SystemObject bevl_nlnp = null;
BEC_6_6_SystemObject bevl_nlnpn = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_6_6_SystemObject bevl_pn = null;
BEC_6_6_SystemObject bevl_pn2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
bevl_nlnp = (new BEC_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(630006451, BEL_4_Base.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_5_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_5_tmpvar_phold);
bevl_nlnpn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(3, bels_0));
bevl_nlc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_8_tmpvar_phold);
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEL_4_Base.bevn_isLiteralSet_1, bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = beva_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_11_tmpvar_phold);
beva_node.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_12_tmpvar_phold);
beva_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(8, bels_1));
bevt_13_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(10, bels_2));
bevt_15_tmpvar_phold = beva_tName.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 51 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 51 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 51 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_19_tmpvar_phold = bevl_pn.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_20_tmpvar_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_20_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_22_tmpvar_phold = bevl_pn.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_23_tmpvar_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_23_tmpvar_phold);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_26_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_27_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_27_tmpvar_phold);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_29_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_30_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_30_tmpvar_phold);
if (bevt_28_tmpvar_phold != null && bevt_28_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_28_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_32_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_33_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_33_tmpvar_phold);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_35_tmpvar_phold = bevl_pn2.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_36_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_36_tmpvar_phold);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 55 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 55 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 55 */ {
bevt_38_tmpvar_phold = bevl_pn.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_39_tmpvar_phold = bevl_nlc.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_39_tmpvar_phold);
bevl_nlc.bemd_1(1098588850, BEL_4_Base.bevn_literalValueSet_1, bevt_37_tmpvar_phold);
bevl_pn.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 62 */
} /* Line: 55 */
} /* Line: 53 */
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_np = null;
BEC_6_6_SystemObject bevl_toremove = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_ii = null;
BEC_6_6_SystemObject bevl_nnode = null;
BEC_6_6_SystemObject bevl_dnode = null;
BEC_5_4_BuildNode bevl_onode = null;
BEC_6_6_SystemObject bevl_pc = null;
BEC_6_6_SystemObject bevl_gc = null;
BEC_5_8_BuildNamePath bevl_namepath = null;
BEC_6_6_SystemObject bevl_pnode = null;
BEC_6_6_SystemObject bevl_ponode = null;
BEC_6_6_SystemObject bevl_ga = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_3_MathInt bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_4_3_MathInt bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_62_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_63_tmpvar_phold = null;
BEC_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_4_3_MathInt bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_4_3_MathInt bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_80_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_4_3_MathInt bevt_83_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_91_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_92_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_94_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_4_3_MathInt bevt_97_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_98_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_102_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_103_tmpvar_phold = null;
BEC_4_3_MathInt bevt_104_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_105_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_109_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_4_6_TextString bevt_112_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_113_tmpvar_phold = null;
BEC_4_6_TextString bevt_114_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_118_tmpvar_phold = null;
BEC_4_6_TextString bevt_119_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_122_tmpvar_phold = null;
BEC_4_3_MathInt bevt_123_tmpvar_phold = null;
BEC_4_3_MathInt bevt_124_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_125_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_126_tmpvar_phold = null;
BEC_4_6_TextString bevt_127_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_128_tmpvar_phold = null;
BEC_4_3_MathInt bevt_129_tmpvar_phold = null;
BEC_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_131_tmpvar_phold = null;
BEC_4_6_TextString bevt_132_tmpvar_phold = null;
BEC_4_3_MathInt bevt_133_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_134_tmpvar_phold = null;
BEC_4_3_MathInt bevt_135_tmpvar_phold = null;
BEC_4_3_MathInt bevt_136_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_138_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_139_tmpvar_phold = null;
BEC_4_6_TextString bevt_140_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_4_3_MathInt bevt_143_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_144_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_4_3_MathInt bevt_147_tmpvar_phold = null;
BEC_4_3_MathInt bevt_148_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_150_tmpvar_phold = null;
BEC_4_3_MathInt bevt_151_tmpvar_phold = null;
BEC_4_3_MathInt bevt_152_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_153_tmpvar_phold = null;
BEC_4_3_MathInt bevt_154_tmpvar_phold = null;
BEC_4_3_MathInt bevt_155_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_161_tmpvar_phold = null;
BEC_4_3_MathInt bevt_162_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_163_tmpvar_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_11_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_5_8_BuildNamePath) bevt_11_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevp_inFile = (BEC_4_6_TextString) bevt_12_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 93 */
if (bevp_inClassNp == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 95 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 97 */
bevt_16_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpvar_phold = bevp_ntypes.bem_INTLGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 99 */ {
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(8, bels_3));
this.bem_buildLiteral_2(beva_node, bevt_18_tmpvar_phold);
} /* Line: 100 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_FLOATLGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_equals_1(bevt_21_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 102 */ {
bevt_22_tmpvar_phold = (new BEC_4_6_TextString(10, bels_4));
this.bem_buildLiteral_2(beva_node, bevt_22_tmpvar_phold);
} /* Line: 103 */
bevt_24_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_equals_1(bevt_25_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 105 */ {
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(11, bels_5));
this.bem_buildLiteral_2(beva_node, bevt_26_tmpvar_phold);
} /* Line: 106 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_WSTRINGLGet_0();
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_equals_1(bevt_29_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 108 */ {
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(11, bels_6));
this.bem_buildLiteral_2(beva_node, bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpvar_phold);
} /* Line: 111 */
bevt_33_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_equals_1(bevt_34_tmpvar_phold);
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_35_tmpvar_phold = (new BEC_4_6_TextString(4, bels_7));
beva_node.bem_heldSet_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (new BEC_4_6_TextString(10, bels_8));
this.bem_buildLiteral_2(beva_node, bevt_36_tmpvar_phold);
} /* Line: 115 */
bevt_38_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_equals_1(bevt_39_tmpvar_phold);
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_40_tmpvar_phold = (new BEC_4_6_TextString(5, bels_9));
beva_node.bem_heldSet_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (new BEC_4_6_TextString(10, bels_10));
this.bem_buildLiteral_2(beva_node, bevt_41_tmpvar_phold);
} /* Line: 123 */
 else  /* Line: 121 */ {
bevt_43_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_equals_1(bevt_44_tmpvar_phold);
if (bevt_42_tmpvar_phold.bevi_bool) /* Line: 125 */ {
bevt_47_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1869307931, BEL_4_Base.bevn_isArgGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 125 */
 else  /* Line: 125 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 125 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
if (bevt_49_tmpvar_phold == null) {
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpvar_phold.bevi_bool) /* Line: 126 */ {
if (bevl_nnode == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_53_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_54_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_54_tmpvar_phold);
if (bevt_52_tmpvar_phold != null && bevt_52_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_52_tmpvar_phold).bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 126 */ {
bevt_57_tmpvar_phold = bevo_0;
bevt_59_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_55_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_55_tmpvar_phold);
} /* Line: 127 */
 else  /* Line: 128 */ {
bevt_60_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_61_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpvar_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevt_62_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpvar_phold;
} /* Line: 135 */
} /* Line: 126 */
 else  /* Line: 121 */ {
bevt_64_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_equals_1(bevt_65_tmpvar_phold);
if (bevt_63_tmpvar_phold.bevi_bool) /* Line: 137 */ {
if (bevl_nnode == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 138 */ {
bevt_68_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_69_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_69_tmpvar_phold);
if (bevt_67_tmpvar_phold != null && bevt_67_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_67_tmpvar_phold).bevi_bool) /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
 else  /* Line: 138 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_71_tmpvar_phold == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 139 */ {
bevl_toremove = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_72_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 141 */ {
bevt_73_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_75_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_76_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpvar_phold = bevt_75_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_76_tmpvar_phold);
if (bevt_74_tmpvar_phold != null && bevt_74_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_74_tmpvar_phold).bevi_bool) /* Line: 143 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 144 */
} /* Line: 143 */
 else  /* Line: 141 */ {
break;
} /* Line: 141 */
} /* Line: 141 */
bevl_ii = bevl_toremove.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 147 */ {
bevt_77_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_77_tmpvar_phold != null && bevt_77_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_77_tmpvar_phold).bevi_bool) /* Line: 147 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 149 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
} /* Line: 147 */
bevl_pc = bevl_nnode;
bevt_78_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_78_tmpvar_phold);
bevl_gc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_79_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_79_tmpvar_phold);
bevl_pc.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevt_82_tmpvar_phold = bevl_dnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_83_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpvar_phold = bevt_82_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_83_tmpvar_phold);
if (bevt_81_tmpvar_phold != null && bevt_81_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_81_tmpvar_phold).bevi_bool) /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 160 */
 else  /* Line: 160 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 160 */ {
bevl_onode = (BEC_5_4_BuildNode) bevl_dnode.bemd_0(2110470555, BEL_4_Base.bevn_priorPeerGet_0);
if (bevl_onode == null) {
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_86_tmpvar_phold = (new BEC_4_6_TextString(38, bels_12));
bevt_85_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_85_tmpvar_phold);
} /* Line: 163 */
 else  /* Line: 162 */ {
bevt_88_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_87_tmpvar_phold = bevt_88_tmpvar_phold.bem_equals_1(bevt_89_tmpvar_phold);
if (bevt_87_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevt_91_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_90_tmpvar_phold = bevp_build.bem_isNewish_1((BEC_4_6_TextString) bevt_91_tmpvar_phold);
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevt_92_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_92_tmpvar_phold);
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_93_tmpvar_phold);
bevt_94_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_94_tmpvar_phold);
} /* Line: 168 */
 else  /* Line: 169 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 170 */
} /* Line: 165 */
 else  /* Line: 162 */ {
bevt_96_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_95_tmpvar_phold = bevt_96_tmpvar_phold.bem_equals_1(bevt_97_tmpvar_phold);
if (bevt_95_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_101_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_102_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpvar_phold = bevt_99_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_102_tmpvar_phold);
if (bevt_98_tmpvar_phold != null && bevt_98_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_98_tmpvar_phold).bevi_bool) /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
 else  /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 172 */ {
bevl_namepath = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_103_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_103_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_104_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_104_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
bevt_106_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_105_tmpvar_phold = bevp_build.bem_isNewish_1((BEC_4_6_TextString) bevt_106_tmpvar_phold);
if (bevt_105_tmpvar_phold.bevi_bool) /* Line: 178 */ {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_107_tmpvar_phold);
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_108_tmpvar_phold);
bevt_109_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(213400007, BEL_4_Base.bevn_isConstructSet_1, bevt_109_tmpvar_phold);
} /* Line: 181 */
 else  /* Line: 182 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 183 */
} /* Line: 178 */
 else  /* Line: 162 */ {
bevt_111_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_112_tmpvar_phold = (new BEC_4_6_TextString(6, bels_13));
bevt_110_tmpvar_phold = bevt_111_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_112_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 185 */ {
bevt_114_tmpvar_phold = (new BEC_4_6_TextString(70, bels_14));
bevt_113_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_114_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_113_tmpvar_phold);
} /* Line: 186 */
 else  /* Line: 162 */ {
bevt_116_tmpvar_phold = bevl_gc.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_117_tmpvar_phold = (new BEC_4_6_TextString(5, bels_15));
bevt_115_tmpvar_phold = bevt_116_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_117_tmpvar_phold);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 187 */ {
bevt_119_tmpvar_phold = (new BEC_4_6_TextString(65, bels_16));
bevt_118_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_119_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_118_tmpvar_phold);
} /* Line: 188 */
} /* Line: 162 */
} /* Line: 162 */
} /* Line: 162 */
} /* Line: 162 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_onode);
bevl_dnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 193 */
 else  /* Line: 194 */ {
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1308209994, BEL_4_Base.bevn_boundSet_1, bevt_120_tmpvar_phold);
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(724818817, BEL_4_Base.bevn_wasBoundSet_1, bevt_121_tmpvar_phold);
} /* Line: 196 */
} /* Line: 160 */
} /* Line: 138 */
 else  /* Line: 121 */ {
bevt_123_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_124_tmpvar_phold = bevp_ntypes.bem_IDXGet_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bem_equals_1(bevt_124_tmpvar_phold);
if (bevt_122_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_125_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_125_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_125_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_127_tmpvar_phold = (new BEC_4_6_TextString(34, bels_17));
bevt_126_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_127_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_126_tmpvar_phold);
} /* Line: 205 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_129_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_130_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bem_equals_1(bevt_130_tmpvar_phold);
if (bevt_128_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevt_132_tmpvar_phold = (new BEC_4_6_TextString(84, bels_18));
bevt_131_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_132_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_131_tmpvar_phold);
} /* Line: 210 */
bevt_133_tmpvar_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_133_tmpvar_phold);
} /* Line: 212 */
 else  /* Line: 121 */ {
bevt_135_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_136_tmpvar_phold = bevp_ntypes.bem_DOTGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bem_equals_1(bevt_136_tmpvar_phold);
if (bevt_134_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_137_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
if (bevl_onode == null) {
bevt_138_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 218 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 218 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 218 */ {
bevt_140_tmpvar_phold = (new BEC_4_6_TextString(34, bels_19));
bevt_139_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_140_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_139_tmpvar_phold);
} /* Line: 219 */
bevt_142_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_143_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_141_tmpvar_phold = bevt_142_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_143_tmpvar_phold);
if (bevt_141_tmpvar_phold != null && bevt_141_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_141_tmpvar_phold).bevi_bool) /* Line: 221 */ {
bevl_pnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
if (bevl_pnode == null) {
bevt_144_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_144_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_144_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_146_tmpvar_phold = bevl_pnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_147_tmpvar_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_145_tmpvar_phold = bevt_146_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_147_tmpvar_phold);
if (bevt_145_tmpvar_phold != null && bevt_145_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_145_tmpvar_phold).bevi_bool) /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 223 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_148_tmpvar_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_148_tmpvar_phold);
bevl_ga = (new BEC_5_8_BuildAccessor()).bem_new_0();
bevt_149_tmpvar_phold = bevl_nnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_ga.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_149_tmpvar_phold);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_151_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_152_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bem_equals_1(bevt_152_tmpvar_phold);
if (bevt_150_tmpvar_phold.bevi_bool) /* Line: 232 */ {
this.bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 233 */
 else  /* Line: 232 */ {
bevt_154_tmpvar_phold = bevl_onode.bem_typenameGet_0();
bevt_155_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bem_equals_1(bevt_155_tmpvar_phold);
if (bevt_153_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_159_tmpvar_phold = beva_node.bem_transUnitGet_0();
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_157_tmpvar_phold = bevt_158_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevt_160_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_160_tmpvar_phold);
if (bevt_156_tmpvar_phold != null && bevt_156_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_156_tmpvar_phold).bevi_bool) /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 234 */
 else  /* Line: 234 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 234 */ {
bevl_namepath = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_161_tmpvar_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_161_tmpvar_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_162_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_162_tmpvar_phold);
bevl_onode.bem_resolveNp_0();
this.bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 240 */
} /* Line: 232 */
} /* Line: 232 */
} /* Line: 223 */
} /* Line: 221 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
} /* Line: 121 */
bevt_163_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_163_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_createImpliedConstruct_2(BEC_5_4_BuildNode beva_onode, BEC_6_6_SystemObject beva_gc) throws Throwable {
BEC_5_4_BuildNode bevl_npcnode = null;
BEC_5_4_BuildCall bevl_gnc = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
bevl_npcnode = (BEC_5_4_BuildNode) (new BEC_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpvar_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (new BEC_5_4_BuildCall()).bem_new_0();
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(3, bels_20));
bevl_gnc.bem_nameSet_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpvar_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_6_6_SystemObject bem_inClassNpSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_6_6_SystemObject bem_inFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inFile = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {28, 29, 31, 32, 32, 33, 34, 36, 37, 37, 38, 38, 39, 39, 40, 40, 41, 41, 42, 42, 44, 46, 46, 47, 49, 51, 51, 0, 51, 51, 0, 0, 52, 53, 53, 53, 53, 53, 0, 53, 53, 53, 0, 0, 0, 0, 0, 54, 55, 55, 0, 55, 55, 55, 55, 55, 55, 0, 0, 0, 55, 55, 55, 0, 0, 0, 55, 55, 55, 0, 0, 0, 0, 0, 61, 61, 61, 61, 62, 88, 91, 91, 91, 92, 92, 93, 93, 93, 95, 95, 96, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 110, 110, 111, 111, 113, 113, 113, 114, 114, 115, 115, 121, 121, 121, 122, 122, 123, 123, 125, 125, 125, 125, 125, 125, 0, 0, 0, 126, 126, 126, 126, 126, 126, 0, 126, 126, 126, 0, 0, 0, 0, 0, 127, 127, 127, 127, 127, 127, 129, 129, 129, 130, 131, 135, 135, 137, 137, 137, 138, 138, 138, 138, 138, 0, 0, 0, 139, 139, 139, 140, 141, 141, 141, 142, 143, 143, 143, 144, 147, 147, 148, 149, 152, 153, 153, 154, 155, 155, 156, 157, 158, 159, 160, 160, 160, 160, 160, 0, 0, 0, 161, 162, 162, 163, 163, 163, 164, 164, 164, 165, 165, 166, 166, 167, 167, 168, 168, 170, 172, 172, 172, 172, 172, 172, 172, 172, 0, 0, 0, 173, 174, 174, 175, 176, 176, 177, 178, 178, 179, 179, 180, 180, 181, 181, 183, 185, 185, 185, 186, 186, 186, 187, 187, 187, 188, 188, 188, 191, 192, 193, 195, 195, 196, 196, 200, 200, 200, 203, 204, 204, 205, 205, 205, 207, 208, 209, 209, 209, 210, 210, 210, 212, 212, 213, 213, 213, 215, 218, 218, 0, 218, 218, 0, 0, 219, 219, 219, 221, 221, 221, 222, 223, 223, 0, 223, 223, 223, 0, 0, 224, 225, 225, 226, 227, 227, 228, 229, 230, 231, 232, 232, 232, 233, 234, 234, 234, 234, 234, 234, 234, 234, 0, 0, 0, 235, 236, 236, 237, 238, 238, 239, 240, 245, 245, 249, 250, 251, 251, 252, 252, 253, 255, 256, 256, 257, 257, 258, 258, 259, 259, 260, 260, 261, 262, 262, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 109, 112, 113, 115, 118, 122, 123, 128, 129, 130, 131, 133, 136, 137, 138, 140, 143, 147, 150, 154, 157, 158, 163, 164, 167, 168, 169, 171, 172, 173, 175, 178, 182, 185, 186, 187, 189, 192, 196, 199, 200, 201, 203, 206, 210, 213, 216, 220, 221, 222, 223, 224, 409, 410, 411, 412, 414, 415, 416, 417, 418, 420, 425, 426, 427, 429, 430, 431, 433, 434, 436, 437, 438, 440, 441, 443, 444, 445, 447, 448, 450, 451, 452, 454, 455, 456, 457, 459, 460, 461, 463, 464, 465, 466, 468, 469, 470, 472, 473, 474, 475, 478, 479, 480, 482, 483, 484, 486, 489, 493, 496, 497, 498, 503, 504, 509, 510, 513, 514, 515, 517, 520, 524, 527, 531, 534, 535, 536, 537, 538, 539, 542, 543, 544, 545, 546, 547, 548, 552, 553, 554, 556, 561, 562, 563, 564, 566, 569, 573, 576, 577, 582, 583, 584, 585, 588, 590, 591, 592, 593, 595, 602, 605, 607, 608, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 630, 631, 632, 633, 635, 638, 642, 645, 646, 651, 652, 653, 654, 657, 658, 659, 661, 662, 664, 665, 666, 667, 668, 669, 672, 676, 677, 678, 680, 681, 682, 683, 684, 686, 689, 693, 696, 697, 698, 699, 700, 701, 702, 703, 704, 706, 707, 708, 709, 710, 711, 714, 718, 719, 720, 722, 723, 724, 727, 728, 729, 731, 732, 733, 739, 740, 741, 744, 745, 746, 747, 752, 753, 754, 756, 757, 762, 763, 764, 765, 767, 768, 769, 770, 771, 773, 774, 775, 777, 778, 781, 782, 783, 785, 786, 791, 792, 795, 800, 801, 804, 808, 809, 810, 812, 813, 814, 816, 817, 822, 823, 826, 827, 828, 830, 833, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 851, 854, 855, 856, 858, 859, 860, 861, 862, 864, 867, 871, 874, 875, 876, 877, 878, 879, 880, 881, 891, 892, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 929, 932, 936, 939};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 28 81
new 0 28 81
fromString 1 29 82
assign 1 31 83
new 1 31 83
assign 1 32 84
NAMEPATHGet 0 32 84
typenameSet 1 32 85
heldSet 1 33 86
copyLoc 1 34 87
assign 1 36 88
new 0 36 88
assign 1 37 89
new 0 37 89
nameSet 1 37 90
assign 1 38 91
new 0 38 91
wasBoundSet 1 38 92
assign 1 39 93
new 0 39 93
boundSet 1 39 94
assign 1 40 95
new 0 40 95
isConstructSet 1 40 96
assign 1 41 97
new 0 41 97
isLiteralSet 1 41 98
assign 1 42 99
heldGet 0 42 99
literalValueSet 1 42 100
addValue 1 44 101
assign 1 46 102
CALLGet 0 46 102
typenameSet 1 46 103
heldSet 1 47 104
resolveNp 0 49 105
assign 1 51 106
new 0 51 106
assign 1 51 107
equals 1 51 107
assign 1 0 109
assign 1 51 112
new 0 51 112
assign 1 51 113
equals 1 51 113
assign 1 0 115
assign 1 0 118
assign 1 52 122
priorPeerGet 0 52 122
assign 1 53 123
def 1 53 128
assign 1 53 129
typenameGet 0 53 129
assign 1 53 130
SUBTRACTGet 0 53 130
assign 1 53 131
equals 1 53 131
assign 1 0 133
assign 1 53 136
typenameGet 0 53 136
assign 1 53 137
ADDGet 0 53 137
assign 1 53 138
equals 1 53 138
assign 1 0 140
assign 1 0 143
assign 1 0 147
assign 1 0 150
assign 1 0 154
assign 1 54 157
priorPeerGet 0 54 157
assign 1 55 158
undef 1 55 163
assign 1 0 164
assign 1 55 167
typenameGet 0 55 167
assign 1 55 168
CALLGet 0 55 168
assign 1 55 169
notEquals 1 55 169
assign 1 55 171
typenameGet 0 55 171
assign 1 55 172
IDGet 0 55 172
assign 1 55 173
notEquals 1 55 173
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 55 185
typenameGet 0 55 185
assign 1 55 186
VARGet 0 55 186
assign 1 55 187
notEquals 1 55 187
assign 1 0 189
assign 1 0 192
assign 1 0 196
assign 1 55 199
typenameGet 0 55 199
assign 1 55 200
ACCESSORGet 0 55 200
assign 1 55 201
notEquals 1 55 201
assign 1 0 203
assign 1 0 206
assign 1 0 210
assign 1 0 213
assign 1 0 216
assign 1 61 220
heldGet 0 61 220
assign 1 61 221
literalValueGet 0 61 221
assign 1 61 222
add 1 61 222
literalValueSet 1 61 223
delete 0 62 224
assign 1 88 409
nextPeerGet 0 88 409
assign 1 91 410
typenameGet 0 91 410
assign 1 91 411
CLASSGet 0 91 411
assign 1 91 412
equals 1 91 412
assign 1 92 414
heldGet 0 92 414
assign 1 92 415
namepathGet 0 92 415
assign 1 93 416
heldGet 0 93 416
assign 1 93 417
fromFileGet 0 93 417
assign 1 93 418
toString 0 93 418
assign 1 95 420
def 1 95 425
inClassNpSet 1 96 426
inFileSet 1 97 427
assign 1 99 429
typenameGet 0 99 429
assign 1 99 430
INTLGet 0 99 430
assign 1 99 431
equals 1 99 431
assign 1 100 433
new 0 100 433
buildLiteral 2 100 434
assign 1 102 436
typenameGet 0 102 436
assign 1 102 437
FLOATLGet 0 102 437
assign 1 102 438
equals 1 102 438
assign 1 103 440
new 0 103 440
buildLiteral 2 103 441
assign 1 105 443
typenameGet 0 105 443
assign 1 105 444
STRINGLGet 0 105 444
assign 1 105 445
equals 1 105 445
assign 1 106 447
new 0 106 447
buildLiteral 2 106 448
assign 1 108 450
typenameGet 0 108 450
assign 1 108 451
WSTRINGLGet 0 108 451
assign 1 108 452
equals 1 108 452
assign 1 110 454
new 0 110 454
buildLiteral 2 110 455
assign 1 111 456
new 0 111 456
wideStringSet 1 111 457
assign 1 113 459
typenameGet 0 113 459
assign 1 113 460
TRUEGet 0 113 460
assign 1 113 461
equals 1 113 461
assign 1 114 463
new 0 114 463
heldSet 1 114 464
assign 1 115 465
new 0 115 465
buildLiteral 2 115 466
assign 1 121 468
typenameGet 0 121 468
assign 1 121 469
FALSEGet 0 121 469
assign 1 121 470
equals 1 121 470
assign 1 122 472
new 0 122 472
heldSet 1 122 473
assign 1 123 474
new 0 123 474
buildLiteral 2 123 475
assign 1 125 478
typenameGet 0 125 478
assign 1 125 479
VARGet 0 125 479
assign 1 125 480
equals 1 125 480
assign 1 125 482
heldGet 0 125 482
assign 1 125 483
isArgGet 0 125 483
assign 1 125 484
not 0 125 484
assign 1 0 486
assign 1 0 489
assign 1 0 493
assign 1 126 496
heldGet 0 126 496
assign 1 126 497
nameGet 0 126 497
assign 1 126 498
undef 1 126 503
assign 1 126 504
undef 1 126 509
assign 1 0 510
assign 1 126 513
typenameGet 0 126 513
assign 1 126 514
IDGet 0 126 514
assign 1 126 515
notEquals 1 126 515
assign 1 0 517
assign 1 0 520
assign 1 0 524
assign 1 0 527
assign 1 0 531
assign 1 127 534
new 0 127 534
assign 1 127 535
heldGet 0 127 535
assign 1 127 536
nameGet 0 127 536
assign 1 127 537
add 1 127 537
assign 1 127 538
new 2 127 538
throw 1 127 539
assign 1 129 542
heldGet 0 129 542
assign 1 129 543
heldGet 0 129 543
nameSet 1 129 544
addVariable 0 130 545
delete 0 131 546
assign 1 135 547
nextDescendGet 0 135 547
return 1 135 548
assign 1 137 552
typenameGet 0 137 552
assign 1 137 553
IDGet 0 137 553
assign 1 137 554
equals 1 137 554
assign 1 138 556
def 1 138 561
assign 1 138 562
typenameGet 0 138 562
assign 1 138 563
PARENSGet 0 138 563
assign 1 138 564
equals 1 138 564
assign 1 0 566
assign 1 0 569
assign 1 0 573
assign 1 139 576
containedGet 0 139 576
assign 1 139 577
def 1 139 582
assign 1 140 583
new 0 140 583
assign 1 141 584
containedGet 0 141 584
assign 1 141 585
iteratorGet 0 141 585
assign 1 141 588
hasNextGet 0 141 588
assign 1 142 590
nextGet 0 142 590
assign 1 143 591
typenameGet 0 143 591
assign 1 143 592
COMMAGet 0 143 592
assign 1 143 593
equals 1 143 593
addValue 1 144 595
assign 1 147 602
iteratorGet 0 147 602
assign 1 147 605
hasNextGet 0 147 605
assign 1 148 607
nextGet 0 148 607
delete 0 149 608
assign 1 152 615
assign 1 153 616
CALLGet 0 153 616
typenameSet 1 153 617
assign 1 154 618
new 0 154 618
assign 1 155 619
heldGet 0 155 619
nameSet 1 155 620
heldSet 1 156 621
delete 0 157 622
assign 1 158 623
assign 1 159 624
priorPeerGet 0 159 624
assign 1 160 625
def 1 160 630
assign 1 160 631
typenameGet 0 160 631
assign 1 160 632
DOTGet 0 160 632
assign 1 160 633
equals 1 160 633
assign 1 0 635
assign 1 0 638
assign 1 0 642
assign 1 161 645
priorPeerGet 0 161 645
assign 1 162 646
undef 1 162 651
assign 1 163 652
new 0 163 652
assign 1 163 653
new 2 163 653
throw 1 163 654
assign 1 164 657
typenameGet 0 164 657
assign 1 164 658
NAMEPATHGet 0 164 658
assign 1 164 659
equals 1 164 659
assign 1 165 661
nameGet 0 165 661
assign 1 165 662
isNewish 1 165 662
assign 1 166 664
new 0 166 664
wasBoundSet 1 166 665
assign 1 167 666
new 0 167 666
boundSet 1 167 667
assign 1 168 668
new 0 168 668
isConstructSet 1 168 669
createImpliedConstruct 2 170 672
assign 1 172 676
typenameGet 0 172 676
assign 1 172 677
IDGet 0 172 677
assign 1 172 678
equals 1 172 678
assign 1 172 680
transUnitGet 0 172 680
assign 1 172 681
heldGet 0 172 681
assign 1 172 682
aliasedGet 0 172 682
assign 1 172 683
heldGet 0 172 683
assign 1 172 684
has 1 172 684
assign 1 0 686
assign 1 0 689
assign 1 0 693
assign 1 173 696
new 0 173 696
assign 1 174 697
heldGet 0 174 697
addStep 1 174 698
heldSet 1 175 699
assign 1 176 700
NAMEPATHGet 0 176 700
typenameSet 1 176 701
resolveNp 0 177 702
assign 1 178 703
nameGet 0 178 703
assign 1 178 704
isNewish 1 178 704
assign 1 179 706
new 0 179 706
wasBoundSet 1 179 707
assign 1 180 708
new 0 180 708
boundSet 1 180 709
assign 1 181 710
new 0 181 710
isConstructSet 1 181 711
createImpliedConstruct 2 183 714
assign 1 185 718
nameGet 0 185 718
assign 1 185 719
new 0 185 719
assign 1 185 720
equals 1 185 720
assign 1 186 722
new 0 186 722
assign 1 186 723
new 2 186 723
throw 1 186 724
assign 1 187 727
nameGet 0 187 727
assign 1 187 728
new 0 187 728
assign 1 187 729
equals 1 187 729
assign 1 188 731
new 0 188 731
assign 1 188 732
new 2 188 732
throw 1 188 733
delete 0 191 739
prepend 1 192 740
delete 0 193 741
assign 1 195 744
new 0 195 744
boundSet 1 195 745
assign 1 196 746
new 0 196 746
wasBoundSet 1 196 747
assign 1 200 752
typenameGet 0 200 752
assign 1 200 753
IDXGet 0 200 753
assign 1 200 754
equals 1 200 754
assign 1 203 756
priorPeerGet 0 203 756
assign 1 204 757
undef 1 204 762
assign 1 205 763
new 0 205 763
assign 1 205 764
new 2 205 764
throw 1 205 765
delete 0 207 767
prepend 1 208 768
assign 1 209 769
typenameGet 0 209 769
assign 1 209 770
NAMEPATHGet 0 209 770
assign 1 209 771
equals 1 209 771
assign 1 210 773
new 0 210 773
assign 1 210 774
new 2 210 774
throw 1 210 775
assign 1 212 777
IDXACCGet 0 212 777
typenameSet 1 212 778
assign 1 213 781
typenameGet 0 213 781
assign 1 213 782
DOTGet 0 213 782
assign 1 213 783
equals 1 213 783
assign 1 215 785
priorPeerGet 0 215 785
assign 1 218 786
undef 1 218 791
assign 1 0 792
assign 1 218 795
undef 1 218 800
assign 1 0 801
assign 1 0 804
assign 1 219 808
new 0 219 808
assign 1 219 809
new 2 219 809
throw 1 219 810
assign 1 221 812
typenameGet 0 221 812
assign 1 221 813
IDGet 0 221 813
assign 1 221 814
equals 1 221 814
assign 1 222 816
nextPeerGet 0 222 816
assign 1 223 817
undef 1 223 822
assign 1 0 823
assign 1 223 826
typenameGet 0 223 826
assign 1 223 827
PARENSGet 0 223 827
assign 1 223 828
notEquals 1 223 828
assign 1 0 830
assign 1 0 833
assign 1 224 837
priorPeerGet 0 224 837
assign 1 225 838
ACCESSORGet 0 225 838
typenameSet 1 225 839
assign 1 226 840
new 0 226 840
assign 1 227 841
heldGet 0 227 841
nameSet 1 227 842
delete 0 228 843
delete 0 229 844
heldSet 1 230 845
addValue 1 231 846
assign 1 232 847
typenameGet 0 232 847
assign 1 232 848
NAMEPATHGet 0 232 848
assign 1 232 849
equals 1 232 849
createImpliedConstruct 2 233 851
assign 1 234 854
typenameGet 0 234 854
assign 1 234 855
IDGet 0 234 855
assign 1 234 856
equals 1 234 856
assign 1 234 858
transUnitGet 0 234 858
assign 1 234 859
heldGet 0 234 859
assign 1 234 860
aliasedGet 0 234 860
assign 1 234 861
heldGet 0 234 861
assign 1 234 862
has 1 234 862
assign 1 0 864
assign 1 0 867
assign 1 0 871
assign 1 235 874
new 0 235 874
assign 1 236 875
heldGet 0 236 875
addStep 1 236 876
heldSet 1 237 877
assign 1 238 878
NAMEPATHGet 0 238 878
typenameSet 1 238 879
resolveNp 0 239 880
createImpliedConstruct 2 240 881
assign 1 245 891
nextDescendGet 0 245 891
return 1 245 892
assign 1 249 905
new 0 249 905
heldSet 1 250 906
assign 1 251 907
NAMEPATHGet 0 251 907
typenameSet 1 251 908
assign 1 252 909
heldGet 0 252 909
heldSet 1 252 910
prepend 1 253 911
assign 1 255 912
new 0 255 912
assign 1 256 913
new 0 256 913
nameSet 1 256 914
assign 1 257 915
new 0 257 915
wasBoundSet 1 257 916
assign 1 258 917
new 0 258 917
boundSet 1 258 918
assign 1 259 919
new 0 259 919
isConstructSet 1 259 920
assign 1 260 921
new 0 260 921
wasImpliedConstructSet 1 260 922
heldSet 1 261 923
assign 1 262 924
CALLGet 0 262 924
typenameSet 1 262 925
return 1 0 929
assign 1 0 932
return 1 0 936
assign 1 0 939
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 822104518: return bem_inFileGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 856627742: return bem_createImpliedConstruct_2((BEC_5_4_BuildNode) bevd_0, bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass7();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass7.bevs_inst = (BEC_5_5_5_BuildVisitPass7)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass7.bevs_inst;
}
}
