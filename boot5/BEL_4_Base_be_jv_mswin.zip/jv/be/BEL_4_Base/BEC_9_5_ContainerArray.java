package be.BEL_4_Base;
/* IO:File: source/base/Array.be */
public class BEC_9_5_ContainerArray extends BEC_6_6_SystemObject {
public BEC_9_5_ContainerArray() { }

   
    public BEC_6_6_SystemObject[] bevi_array;
    
   
   
   public BEC_9_5_ContainerArray(BEC_6_6_SystemObject[] bevi_array) {
        this.bevi_array = bevi_array;
        this.bevp_length = new BEC_4_3_MathInt(bevi_array.length);
        this.bevp_capacity = new BEC_4_3_MathInt(bevi_array.length);
        this.bevp_multiplier = new BEC_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_8 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_10 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_11 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_12 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_13 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_14 = (new BEC_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_4_3_MathInt bevo_15 = (new BEC_4_3_MathInt(2));
public static BEC_9_5_ContainerArray bevs_inst;
public BEC_6_6_SystemObject bevp_varray;
public BEC_4_3_MathInt bevp_length;
public BEC_4_3_MathInt bevp_capacity;
public BEC_4_3_MathInt bevp_multiplier;
public BEC_9_5_ContainerArray bem_new_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpvar_phold, bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_new_1(BEC_4_3_MathInt beva_leni) throws Throwable {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_new_2(BEC_4_3_MathInt beva_leni, BEC_4_3_MathInt beva_capi) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_leni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
if (beva_capi == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 141 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 141 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 141 */ {
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(61, bels_0));
bevt_3_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 142 */
if (bevp_length == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 144 */ {
bevt_6_tmpvar_phold = bevp_length.bem_equals_1(beva_leni);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 147 */ {
return this;
} /* Line: 148 */
} /* Line: 147 */

      bevi_array = new BEC_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevp_length.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 176 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_varrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_varraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_5_ContainerArray bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevp_length.bem_subtract_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_put_2(BEC_4_3_MathInt beva_posi, BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold = beva_posi.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(36, bels_1));
bevt_2_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 209 */
bevt_4_tmpvar_phold = beva_posi.bem_greaterEquals_1(bevp_length);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_6_tmpvar_phold = bevo_7;
bevt_5_tmpvar_phold = beva_posi.bem_add_1(bevt_6_tmpvar_phold);
this.bem_lengthSet_1(bevt_5_tmpvar_phold);
} /* Line: 212 */

      this.bevi_array[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_6_6_SystemObject bem_get_1(BEC_4_3_MathInt beva_posi) throws Throwable {
BEC_6_6_SystemObject bevl_val = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
bevt_1_tmpvar_phold = beva_posi.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_3_tmpvar_phold = beva_posi.bem_lesser_1(bevp_length);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 223 */
 else  /* Line: 223 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 223 */ {

      bevl_val = this.bevi_array[beva_posi.bevi_int];
      } /* Line: 224 */
return bevl_val;
} /*method end*/
public BEC_6_6_SystemObject bem_delete_1(BEC_4_3_MathInt beva_pos) throws Throwable {
BEC_4_3_MathInt bevl_fl = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_pos.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_1_tmpvar_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_i = beva_pos;
while (true)
 /* Line: 236 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(bevl_fl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 236 */ {
bevt_5_tmpvar_phold = bevo_10;
bevt_4_tmpvar_phold = bevl_i.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = this.bem_get_1(bevt_4_tmpvar_phold);
this.bem_put_2(bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 236 */
 else  /* Line: 236 */ {
break;
} /* Line: 236 */
} /* Line: 236 */
this.bem_put_2(bevl_fl, null);
bevt_7_tmpvar_phold = bevo_11;
bevt_6_tmpvar_phold = bevp_length.bem_subtract_1(bevt_7_tmpvar_phold);
this.bem_lengthSet_1(bevt_6_tmpvar_phold);
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 241 */
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_5_8_ArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_5_8_ArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_5_ContainerArray bem_clear_0() throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 251 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 251 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 251 */
 else  /* Line: 251 */ {
break;
} /* Line: 251 */
} /* Line: 251 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_9_5_ContainerArray bevl_n = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_n = (BEC_9_5_ContainerArray) this.bem_create_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 258 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_1_tmpvar_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 258 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
return bevl_n;
} /*method end*/
public BEC_6_6_SystemObject bem_create_1(BEC_4_3_MathInt beva_len) throws Throwable {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_5_ContainerArray()).bem_new_1(beva_len);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_5_ContainerArray()).bem_new_1(bevp_length);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_5_ContainerArray bem_add_1(BEC_9_5_ContainerArray beva_xi) throws Throwable {
BEC_9_5_ContainerArray bevl_yi = null;
BEC_6_6_SystemObject bevl_c = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_4_tmpvar_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_length.bem_add_1(bevt_4_tmpvar_phold);
bevl_yi = (new BEC_9_5_ContainerArray()).bem_new_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_loop = this.bem_iteratorGet_0();
while (true)
 /* Line: 270 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 270 */ {
bevl_c = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 271 */
 else  /* Line: 270 */ {
break;
} /* Line: 270 */
} /* Line: 270 */
bevt_1_tmpvar_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 273 */ {
bevt_6_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 273 */ {
bevl_c = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 274 */
 else  /* Line: 273 */ {
break;
} /* Line: 273 */
} /* Line: 273 */
return (BEC_9_5_ContainerArray) bevl_yi;
} /*method end*/
public BEC_9_5_ContainerArray bem_sort_0() throws Throwable {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_mergeSort_0();
return (BEC_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_5_ContainerArray bem_sortValue_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_sortValue_2(bevt_0_tmpvar_phold, bevp_length);
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_sortValue_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_c = null;
BEC_4_3_MathInt bevl_j = null;
BEC_6_6_SystemObject bevl_hold = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_start;
while (true)
 /* Line: 288 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(beva_end);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 288 */ {
bevl_c = bevl_i;
bevl_j = bevl_i;
while (true)
 /* Line: 290 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(beva_end);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 290 */ {
bevt_3_tmpvar_phold = this.bem_get_1(bevl_j);
bevt_4_tmpvar_phold = this.bem_get_1(bevl_c);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 291 */ {
bevl_c = bevl_j;
} /* Line: 292 */
bevl_j = bevl_j.bem_increment_0();
} /* Line: 290 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpvar_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpvar_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 288 */
 else  /* Line: 288 */ {
break;
} /* Line: 288 */
} /* Line: 288 */
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_mergeIn_2(BEC_9_5_ContainerArray beva_first, BEC_9_5_ContainerArray beva_second) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_fi = null;
BEC_4_3_MathInt bevl_si = null;
BEC_4_3_MathInt bevl_fl = null;
BEC_4_3_MathInt bevl_sl = null;
BEC_6_6_SystemObject bevl_fo = null;
BEC_6_6_SystemObject bevl_so = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = (new BEC_4_3_MathInt(0));
bevl_fi = (new BEC_4_3_MathInt(0));
bevl_si = (new BEC_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 307 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 307 */ {
bevt_2_tmpvar_phold = bevl_fi.bem_lesser_1(bevl_fl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 308 */ {
bevt_3_tmpvar_phold = bevl_si.bem_lesser_1(bevl_sl);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 308 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 308 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 308 */
 else  /* Line: 308 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 308 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpvar_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 311 */ {
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 313 */
 else  /* Line: 314 */ {
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 316 */
} /* Line: 311 */
 else  /* Line: 308 */ {
bevt_5_tmpvar_phold = bevl_si.bem_lesser_1(bevl_sl);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 318 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 321 */
 else  /* Line: 308 */ {
bevt_6_tmpvar_phold = bevl_fi.bem_lesser_1(bevl_fl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 322 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 325 */
} /* Line: 308 */
} /* Line: 308 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 327 */
 else  /* Line: 307 */ {
break;
} /* Line: 307 */
} /* Line: 307 */
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_mergeSort_0() throws Throwable {
BEC_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = this.bem_mergeSort_2(bevt_1_tmpvar_phold, bevp_length);
return (BEC_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_5_ContainerArray bem_mergeSort_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) throws Throwable {
BEC_4_3_MathInt bevl_mlen = null;
BEC_9_5_ContainerArray bevl_ra = null;
BEC_4_3_MathInt bevl_shalf = null;
BEC_4_3_MathInt bevl_fhalf = null;
BEC_4_3_MathInt bevl_fend = null;
BEC_9_5_ContainerArray bevl_fa = null;
BEC_9_5_ContainerArray bevl_sa = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpvar_phold = bevo_12;
bevt_0_tmpvar_phold = bevl_mlen.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 337 */ {
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_2_tmpvar_phold = this.bem_create_1(bevt_3_tmpvar_phold);
return (BEC_9_5_ContainerArray) bevt_2_tmpvar_phold;
} /* Line: 338 */
 else  /* Line: 337 */ {
bevt_5_tmpvar_phold = bevo_13;
bevt_4_tmpvar_phold = bevl_mlen.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 339 */ {
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevl_ra = (BEC_9_5_ContainerArray) this.bem_create_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_8_tmpvar_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
return (BEC_9_5_ContainerArray) bevl_ra;
} /* Line: 342 */
 else  /* Line: 343 */ {
bevt_9_tmpvar_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpvar_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_9_5_ContainerArray) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_9_5_ContainerArray) bevl_ra;
} /* Line: 351 */
} /* Line: 337 */
} /*method end*/
public BEC_6_6_SystemObject bem_capacitySet_1(BEC_4_3_MathInt beva_newcap) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_9_SystemException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(13, bels_2));
bevt_1_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 357 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_lengthSet_1(BEC_4_3_MathInt beva_newlen) throws Throwable {
BEC_4_3_MathInt bevl_newcap = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_newlen.bem_greater_1(bevp_capacity);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 363 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_array = java.util.Arrays.copyOf(this.bevi_array, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 380 */
while (true)
 /* Line: 383 */ {
bevt_1_tmpvar_phold = bevp_length.bem_lesser_1(beva_newlen);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 383 */ {

         this.bevi_array[this.bevp_length.bevi_int] = null;
         bevp_length.bem_incrementValue_0();
} /* Line: 389 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
bevp_length.bem_setValue_1(beva_newlen);
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_iterateAdd_1(BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 395 */ {
while (true)
 /* Line: 396 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 396 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 397 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
} /* Line: 396 */
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_addAll_1(BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 404 */
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_addValueWhole_1(BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_lesser_1(bevp_capacity);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 409 */ {

       this.bevi_array[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bem_incrementValue_0();
} /* Line: 415 */
 else  /* Line: 416 */ {
bevt_1_tmpvar_phold = bevp_length.bem_copy_0();
this.bem_put_2((BEC_4_3_MathInt) bevt_1_tmpvar_phold, beva_val);
} /* Line: 418 */
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_addValue_1(BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_2_tmpvar_phold = beva_val.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 423 */
 else  /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 423 */ {
this.bem_addAll_1(beva_val);
} /* Line: 424 */
 else  /* Line: 425 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 426 */
return this;
} /*method end*/
public BEC_4_3_MathInt bem_find_1(BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_6_6_SystemObject bevl_aval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 432 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(bevp_length);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 432 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 434 */ {
bevt_3_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 434 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 434 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 434 */
 else  /* Line: 434 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 434 */ {
return bevl_i;
} /* Line: 435 */
bevl_i.bem_incrementValue_0();
} /* Line: 432 */
 else  /* Line: 432 */ {
break;
} /* Line: 432 */
} /* Line: 432 */
return null;
} /*method end*/
public BEC_5_4_LogicBool bem_has_1(BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 443 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_sortedFind_1(BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_sortedFind_2(BEC_6_6_SystemObject beva_value, BEC_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_4_3_MathInt bevl_high = null;
BEC_4_3_MathInt bevl_low = null;
BEC_4_3_MathInt bevl_lastMid = null;
BEC_4_3_MathInt bevl_mid = null;
BEC_6_6_SystemObject bevl_aval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_high = bevp_length;
bevl_low = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 462 */ {
bevt_3_tmpvar_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpvar_phold = bevo_15;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_divide_1(bevt_4_tmpvar_phold);
bevl_mid = bevt_2_tmpvar_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 465 */ {
return bevl_mid;
} /* Line: 466 */
 else  /* Line: 465 */ {
bevt_6_tmpvar_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 467 */ {
bevl_low = bevl_mid;
} /* Line: 469 */
 else  /* Line: 465 */ {
bevt_7_tmpvar_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 470 */ {
bevl_high = bevl_mid;
} /* Line: 472 */
} /* Line: 465 */
} /* Line: 465 */
if (bevl_lastMid == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 475 */ {
bevt_9_tmpvar_phold = bevl_lastMid.bem_equals_1(bevl_mid);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 475 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 475 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 475 */
 else  /* Line: 475 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 475 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 476 */ {
bevt_11_tmpvar_phold = this.bem_get_1(bevl_low);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 476 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 476 */
 else  /* Line: 476 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 476 */ {
return bevl_low;
} /* Line: 477 */
return null;
} /* Line: 479 */
bevl_lastMid = bevl_mid;
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 482 */ {
return null;
} /* Line: 483 */
} /* Line: 482 */
} /*method end*/
public BEC_6_6_SystemObject bem_varraySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_varray = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_6_6_SystemObject bem_multiplierSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_multiplier = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {133, 133, 133, 133, 133, 137, 141, 141, 0, 141, 141, 0, 0, 142, 142, 142, 144, 144, 147, 148, 164, 165, 166, 171, 175, 175, 176, 176, 178, 178, 188, 188, 192, 192, 196, 196, 200, 200, 200, 204, 204, 204, 204, 208, 208, 209, 209, 209, 211, 212, 212, 212, 223, 223, 223, 0, 0, 0, 230, 234, 235, 235, 236, 236, 237, 237, 237, 237, 236, 239, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 252, 251, 257, 258, 258, 259, 259, 258, 261, 264, 264, 266, 266, 269, 269, 269, 269, 270, 0, 270, 270, 271, 273, 0, 273, 273, 274, 276, 280, 280, 284, 284, 288, 288, 289, 290, 290, 291, 291, 291, 292, 290, 295, 296, 296, 297, 288, 302, 303, 304, 305, 306, 307, 308, 308, 0, 0, 0, 309, 310, 311, 312, 313, 315, 316, 318, 319, 320, 321, 322, 323, 324, 325, 327, 332, 332, 332, 336, 337, 337, 338, 338, 338, 339, 339, 340, 340, 341, 341, 341, 342, 344, 344, 345, 346, 347, 348, 349, 350, 351, 356, 357, 357, 357, 363, 364, 380, 383, 389, 391, 395, 395, 396, 397, 397, 403, 403, 404, 404, 409, 415, 418, 418, 423, 423, 423, 0, 0, 0, 424, 426, 432, 432, 433, 434, 434, 434, 0, 0, 0, 435, 432, 438, 442, 442, 442, 443, 443, 445, 445, 451, 451, 451, 458, 459, 463, 463, 463, 463, 464, 465, 466, 467, 469, 470, 472, 475, 475, 475, 0, 0, 0, 476, 476, 0, 0, 0, 477, 479, 481, 482, 483, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {49, 50, 51, 52, 53, 57, 68, 73, 74, 77, 82, 83, 86, 90, 91, 92, 94, 99, 100, 102, 107, 108, 109, 113, 120, 121, 123, 124, 126, 127, 137, 138, 142, 143, 148, 149, 154, 155, 156, 162, 163, 164, 165, 175, 176, 178, 179, 180, 182, 184, 185, 186, 198, 199, 201, 203, 206, 210, 216, 231, 233, 234, 235, 238, 240, 241, 242, 243, 244, 250, 251, 252, 253, 254, 255, 257, 258, 262, 263, 268, 271, 273, 274, 287, 288, 291, 293, 294, 295, 301, 305, 306, 310, 311, 323, 324, 325, 326, 327, 327, 330, 332, 333, 339, 339, 342, 344, 345, 351, 355, 356, 360, 361, 375, 378, 380, 381, 384, 386, 387, 388, 390, 392, 398, 399, 400, 401, 402, 425, 426, 427, 428, 429, 432, 434, 436, 438, 441, 445, 448, 449, 450, 452, 453, 456, 457, 461, 463, 464, 465, 468, 470, 471, 472, 476, 487, 488, 489, 509, 510, 511, 513, 514, 515, 518, 519, 521, 522, 523, 524, 525, 526, 529, 530, 531, 532, 533, 534, 535, 536, 537, 545, 547, 548, 549, 557, 559, 562, 566, 570, 576, 583, 588, 591, 593, 594, 606, 611, 612, 613, 620, 624, 627, 628, 636, 641, 642, 644, 647, 651, 654, 657, 668, 671, 673, 674, 679, 680, 682, 685, 689, 692, 694, 700, 707, 708, 713, 714, 715, 717, 718, 723, 724, 725, 746, 747, 750, 751, 752, 753, 754, 755, 757, 760, 762, 765, 767, 771, 776, 777, 779, 782, 786, 790, 791, 793, 796, 800, 803, 805, 807, 808, 810, 815, 819, 822, 825, 828};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 133 49
new 0 133 49
assign 1 133 50
once 0 133 50
assign 1 133 51
new 0 133 51
assign 1 133 52
once 0 133 52
new 2 133 53
new 2 137 57
assign 1 141 68
undef 1 141 73
assign 1 0 74
assign 1 141 77
undef 1 141 82
assign 1 0 83
assign 1 0 86
assign 1 142 90
new 0 142 90
assign 1 142 91
new 1 142 91
throw 1 142 92
assign 1 144 94
def 1 144 99
assign 1 147 100
equals 1 147 100
return 1 148 102
assign 1 164 107
copy 0 164 107
assign 1 165 108
copy 0 165 108
assign 1 166 109
new 0 166 109
return 1 171 113
assign 1 175 120
new 0 175 120
assign 1 175 121
equals 1 175 121
assign 1 176 123
new 0 176 123
return 1 176 124
assign 1 178 126
new 0 178 126
return 1 178 127
assign 1 188 137
toString 0 188 137
return 1 188 138
assign 1 192 142
new 1 192 142
new 1 192 143
assign 1 196 148
iteratorGet 0 196 148
return 1 196 149
assign 1 200 154
new 0 200 154
assign 1 200 155
get 1 200 155
return 1 200 156
assign 1 204 162
new 0 204 162
assign 1 204 163
subtract 1 204 163
assign 1 204 164
get 1 204 164
return 1 204 165
assign 1 208 175
new 0 208 175
assign 1 208 176
lesser 1 208 176
assign 1 209 178
new 0 209 178
assign 1 209 179
new 1 209 179
throw 1 209 180
assign 1 211 182
greaterEquals 1 211 182
assign 1 212 184
new 0 212 184
assign 1 212 185
add 1 212 185
lengthSet 1 212 186
assign 1 223 198
new 0 223 198
assign 1 223 199
greaterEquals 1 223 199
assign 1 223 201
lesser 1 223 201
assign 1 0 203
assign 1 0 206
assign 1 0 210
return 1 230 216
assign 1 234 231
lesser 1 234 231
assign 1 235 233
new 0 235 233
assign 1 235 234
subtract 1 235 234
assign 1 236 235
assign 1 236 238
lesser 1 236 238
assign 1 237 240
new 0 237 240
assign 1 237 241
add 1 237 241
assign 1 237 242
get 1 237 242
put 2 237 243
assign 1 236 244
increment 0 236 244
put 2 239 250
assign 1 240 251
new 0 240 251
assign 1 240 252
subtract 1 240 252
lengthSet 1 240 253
assign 1 241 254
new 0 241 254
return 1 241 255
assign 1 243 257
new 0 243 257
return 1 243 258
assign 1 247 262
new 1 247 262
return 1 247 263
assign 1 251 268
new 0 251 268
assign 1 251 271
lesser 1 251 271
put 2 252 273
assign 1 251 274
increment 0 251 274
assign 1 257 287
create 0 257 287
assign 1 258 288
new 0 258 288
assign 1 258 291
lesser 1 258 291
assign 1 259 293
get 1 259 293
put 2 259 294
assign 1 258 295
increment 0 258 295
return 1 261 301
assign 1 264 305
new 1 264 305
return 1 264 306
assign 1 266 310
new 1 266 310
return 1 266 311
assign 1 269 323
new 0 269 323
assign 1 269 324
lengthGet 0 269 324
assign 1 269 325
add 1 269 325
assign 1 269 326
new 2 269 326
assign 1 270 327
iteratorGet 0 0 327
assign 1 270 330
hasNextGet 0 270 330
assign 1 270 332
nextGet 0 270 332
addValueWhole 1 271 333
assign 1 273 339
iteratorGet 0 0 339
assign 1 273 342
hasNextGet 0 273 342
assign 1 273 344
nextGet 0 273 344
addValueWhole 1 274 345
return 1 276 351
assign 1 280 355
mergeSort 0 280 355
return 1 280 356
assign 1 284 360
new 0 284 360
sortValue 2 284 361
assign 1 288 375
assign 1 288 378
lesser 1 288 378
assign 1 289 380
assign 1 290 381
assign 1 290 384
lesser 1 290 384
assign 1 291 386
get 1 291 386
assign 1 291 387
get 1 291 387
assign 1 291 388
lesser 1 291 388
assign 1 292 390
assign 1 290 392
increment 0 290 392
assign 1 295 398
get 1 295 398
assign 1 296 399
get 1 296 399
put 2 296 400
put 2 297 401
assign 1 288 402
increment 0 288 402
assign 1 302 425
new 0 302 425
assign 1 303 426
new 0 303 426
assign 1 304 427
new 0 304 427
assign 1 305 428
lengthGet 0 305 428
assign 1 306 429
lengthGet 0 306 429
assign 1 307 432
lesser 1 307 432
assign 1 308 434
lesser 1 308 434
assign 1 308 436
lesser 1 308 436
assign 1 0 438
assign 1 0 441
assign 1 0 445
assign 1 309 448
get 1 309 448
assign 1 310 449
get 1 310 449
assign 1 311 450
lesser 1 311 450
assign 1 312 452
increment 0 312 452
put 2 313 453
assign 1 315 456
increment 0 315 456
put 2 316 457
assign 1 318 461
lesser 1 318 461
assign 1 319 463
get 1 319 463
assign 1 320 464
increment 0 320 464
put 2 321 465
assign 1 322 468
lesser 1 322 468
assign 1 323 470
get 1 323 470
assign 1 324 471
increment 0 324 471
put 2 325 472
assign 1 327 476
increment 0 327 476
assign 1 332 487
new 0 332 487
assign 1 332 488
mergeSort 2 332 488
return 1 332 489
assign 1 336 509
subtract 1 336 509
assign 1 337 510
new 0 337 510
assign 1 337 511
equals 1 337 511
assign 1 338 513
new 0 338 513
assign 1 338 514
create 1 338 514
return 1 338 515
assign 1 339 518
new 0 339 518
assign 1 339 519
equals 1 339 519
assign 1 340 521
new 0 340 521
assign 1 340 522
create 1 340 522
assign 1 341 523
new 0 341 523
assign 1 341 524
get 1 341 524
put 2 341 525
return 1 342 526
assign 1 344 529
new 0 344 529
assign 1 344 530
divide 1 344 530
assign 1 345 531
subtract 1 345 531
assign 1 346 532
add 1 346 532
assign 1 347 533
mergeSort 2 347 533
assign 1 348 534
mergeSort 2 348 534
assign 1 349 535
create 1 349 535
mergeIn 2 350 536
return 1 351 537
assign 1 356 545
new 0 356 545
assign 1 357 547
new 0 357 547
assign 1 357 548
new 1 357 548
throw 1 357 549
assign 1 363 557
greater 1 363 557
assign 1 364 559
multiply 1 364 559
assign 1 380 562
assign 1 383 566
lesser 1 383 566
incrementValue 0 389 570
setValue 1 391 576
assign 1 395 583
def 1 395 588
assign 1 396 591
hasNextGet 0 396 591
assign 1 397 593
nextGet 0 397 593
addValueWhole 1 397 594
assign 1 403 606
def 1 403 611
assign 1 404 612
iteratorGet 0 404 612
iterateAdd 1 404 613
assign 1 409 620
lesser 1 409 620
incrementValue 0 415 624
assign 1 418 627
copy 0 418 627
put 2 418 628
assign 1 423 636
def 1 423 641
assign 1 423 642
sameType 1 423 642
assign 1 0 644
assign 1 0 647
assign 1 0 651
addAll 1 424 654
addValueWhole 1 426 657
assign 1 432 668
new 0 432 668
assign 1 432 671
lesser 1 432 671
assign 1 433 673
get 1 433 673
assign 1 434 674
def 1 434 679
assign 1 434 680
equals 1 434 680
assign 1 0 682
assign 1 0 685
assign 1 0 689
return 1 435 692
incrementValue 0 432 694
return 1 438 700
assign 1 442 707
find 1 442 707
assign 1 442 708
def 1 442 713
assign 1 443 714
new 0 443 714
return 1 443 715
assign 1 445 717
new 0 445 717
return 1 445 718
assign 1 451 723
new 0 451 723
assign 1 451 724
sortedFind 2 451 724
return 1 451 725
assign 1 458 746
assign 1 459 747
new 0 459 747
assign 1 463 750
subtract 1 463 750
assign 1 463 751
new 0 463 751
assign 1 463 752
divide 1 463 752
assign 1 463 753
add 1 463 753
assign 1 464 754
get 1 464 754
assign 1 465 755
equals 1 465 755
return 1 466 757
assign 1 467 760
greater 1 467 760
assign 1 469 762
assign 1 470 765
lesser 1 470 765
assign 1 472 767
assign 1 475 771
def 1 475 776
assign 1 475 777
equals 1 475 777
assign 1 0 779
assign 1 0 782
assign 1 0 786
assign 1 476 790
get 1 476 790
assign 1 476 791
lesser 1 476 791
assign 1 0 793
assign 1 0 796
assign 1 0 800
return 1 477 803
return 1 479 805
assign 1 481 807
assign 1 482 808
new 0 482 808
return 1 483 810
assign 1 0 815
return 1 0 819
return 1 0 822
return 1 0 825
assign 1 0 828
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 896593457: return bem_sort_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1616433729: return bem_lengthGet_0();
case 729571811: return bem_serializeToString_0();
case 1473032100: return bem_varrayGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1479417926: return bem_multiplierGet_0();
case 188061735: return bem_mergeSort_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1484114352: return bem_varraySet_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 856777406: return bem_clear_0();
case 1089531140: return bem_isEmptyGet_0();
case 1478277476: return bem_sortValue_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case 1990707345: return bem_lastGet_0();
case 786424307: return bem_tagGet_0();
case 1751843603: return bem_capacityGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1484114353: return bem_varraySet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_4_3_MathInt) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_4_3_MathInt) bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1274448085: return bem_find_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_9_5_ContainerArray) bevd_0);
case 228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 104713555: return bem_new_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1478277478: return bem_sortValue_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_9_5_ContainerArray) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_5_ContainerArray();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_5_ContainerArray.bevs_inst = (BEC_9_5_ContainerArray)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_5_ContainerArray.bevs_inst;
}
}
