package be.BEL_4_Base;
/* IO:File: source/base/Stack.be */
public class BEC_9_5_ContainerQueue extends BEC_6_6_SystemObject {
public BEC_9_5_ContainerQueue() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static BEC_9_5_ContainerQueue bevs_inst;
public BEC_9_5_4_ContainerStackNode bevp_top;
public BEC_9_5_4_ContainerStackNode bevp_bottom;
public BEC_9_5_4_ContainerStackNode bevp_end;
public BEC_4_3_MathInt bevp_size;
public BEC_9_5_ContainerQueue bem_new_0() throws Throwable {
bevp_size = (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addValue_1(BEC_6_6_SystemObject beva_item) throws Throwable {
this.bem_enqueue_1(beva_item);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_enqueue_1(BEC_6_6_SystemObject beva_item) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_9_5_4_ContainerStackNode bevt_3_tmpvar_phold = null;
BEC_9_5_4_ContainerStackNode bevt_4_tmpvar_phold = null;
BEC_9_5_4_ContainerStackNode bevt_5_tmpvar_phold = null;
if (bevp_top == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevp_top = (new BEC_9_5_4_ContainerStackNode()).bem_new_0();
bevp_end = bevp_top;
bevp_bottom = bevp_top;
} /* Line: 134 */
 else  /* Line: 131 */ {
if (bevp_bottom == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 135 */ {
bevt_3_tmpvar_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 136 */ {
bevt_4_tmpvar_phold = (new BEC_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpvar_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
bevp_end = bevp_top;
} /* Line: 140 */
 else  /* Line: 141 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 142 */
} /* Line: 136 */
 else  /* Line: 144 */ {
bevp_bottom = bevp_top;
} /* Line: 145 */
} /* Line: 131 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_dequeue_0() throws Throwable {
BEC_6_6_SystemObject bevl_item = null;
BEC_9_5_4_ContainerStackNode bevl_last = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 152 */ {
return null;
} /* Line: 153 */
bevl_item = bevp_bottom.bem_heldGet_0();
bevp_bottom.bem_heldSet_1(null);
bevt_1_tmpvar_phold = bevp_bottom.bem_equals_1(bevp_top);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 157 */ {
bevp_bottom = null;
} /* Line: 158 */
 else  /* Line: 159 */ {
bevl_last = bevp_bottom;
bevp_bottom = bevp_bottom.bem_nextGet_0();
bevl_last.bem_nextSet_1(null);
bevl_last.bem_priorSet_1(bevp_end);
bevp_end.bem_nextSet_1(bevl_last);
bevp_end = bevl_last;
} /* Line: 166 */
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_get_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_dequeue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_put_1(BEC_6_6_SystemObject beva_item) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_enqueue_1(beva_item);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_5_4_ContainerStackNode bem_topGet_0() throws Throwable {
return bevp_top;
} /*method end*/
public BEC_6_6_SystemObject bem_topSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_top = (BEC_9_5_4_ContainerStackNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_4_ContainerStackNode bem_bottomGet_0() throws Throwable {
return bevp_bottom;
} /*method end*/
public BEC_6_6_SystemObject bem_bottomSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_bottom = (BEC_9_5_4_ContainerStackNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_4_ContainerStackNode bem_endGet_0() throws Throwable {
return bevp_end;
} /*method end*/
public BEC_6_6_SystemObject bem_endSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_end = (BEC_9_5_4_ContainerStackNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {121, 127, 131, 131, 132, 133, 134, 135, 135, 136, 136, 136, 137, 137, 138, 138, 139, 140, 142, 145, 147, 148, 152, 152, 153, 155, 156, 157, 158, 161, 162, 163, 164, 165, 166, 168, 169, 173, 173, 177, 177, 181, 181, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 17, 27, 32, 33, 34, 35, 38, 43, 44, 45, 50, 51, 52, 53, 54, 55, 56, 59, 63, 66, 67, 75, 80, 81, 83, 84, 85, 87, 90, 91, 92, 93, 94, 95, 97, 98, 102, 107, 111, 112, 116, 117, 120, 123, 127, 130, 134, 137, 141, 144};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 121 13
new 0 121 13
enqueue 1 127 17
assign 1 131 27
undef 1 131 32
assign 1 132 33
new 0 132 33
assign 1 133 34
assign 1 134 35
assign 1 135 38
def 1 135 43
assign 1 136 44
nextGet 0 136 44
assign 1 136 45
undef 1 136 50
assign 1 137 51
new 0 137 51
nextSet 1 137 52
assign 1 138 53
nextGet 0 138 53
priorSet 1 138 54
assign 1 139 55
nextGet 0 139 55
assign 1 140 56
assign 1 142 59
nextGet 0 142 59
assign 1 145 63
heldSet 1 147 66
assign 1 148 67
increment 0 148 67
assign 1 152 75
undef 1 152 80
return 1 153 81
assign 1 155 83
heldGet 0 155 83
heldSet 1 156 84
assign 1 157 85
equals 1 157 85
assign 1 158 87
assign 1 161 90
assign 1 162 91
nextGet 0 162 91
nextSet 1 163 92
priorSet 1 164 93
nextSet 1 165 94
assign 1 166 95
assign 1 168 97
decrement 0 168 97
return 1 169 98
assign 1 173 102
undef 1 173 107
return 1 173 107
assign 1 177 111
dequeue 0 177 111
return 1 177 112
assign 1 181 116
enqueue 1 181 116
return 1 181 117
return 1 0 120
assign 1 0 123
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 98246023: return bem_get_0();
case 1308786538: return bem_echo_0();
case 1702950252: return bem_endGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 631556580: return bem_bottomGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 228537569: return bem_dequeue_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case 988612302: return bem_topGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 107034369: return bem_put_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 620474327: return bem_bottomSet_1(bevd_0);
case 1221474234: return bem_enqueue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 977530049: return bem_topSet_1(bevd_0);
case 1714032505: return bem_endSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_5_ContainerQueue();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_5_ContainerQueue.bevs_inst = (BEC_9_5_ContainerQueue)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_5_ContainerQueue.bevs_inst;
}
}
