package be.BEL_4_Base;
/* IO:File: source/extended/Template.be */
public class BEC_8_7_TemplateReplace extends BEC_6_6_SystemObject {
public BEC_8_7_TemplateReplace() { }
private static byte[] becc_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x65,0x70,0x6C,0x61,0x63,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C,0x3F,0x74,0x74};
private static byte[] bels_1 = {0x3F,0x3E};
private static byte[] bels_2 = {0x20};
public static BEC_8_7_TemplateReplace bevs_inst;
public BEC_9_10_ContainerLinkedList bevp_steps;
public BEC_4_3_MathInt bevp_size;
public BEC_5_4_LogicBool bevp_append;
public BEC_8_6_TemplateRunner bevp_runner;
public BEC_8_7_TemplateReplace bem_new_0() throws Throwable {
bevp_append = be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_8_7_TemplateReplace bem_load_1(BEC_4_6_TextString beva_template) throws Throwable {
this.bem_load_2(beva_template, null);
return this;
} /*method end*/
public BEC_8_7_TemplateReplace bem_load_2(BEC_4_6_TextString beva_template, BEC_8_6_TemplateRunner beva__runner) throws Throwable {
BEC_4_6_TextString bevl_blStart = null;
BEC_4_6_TextString bevl_blEnd = null;
BEC_5_4_LogicBool bevl_onStart = null;
BEC_5_4_LogicBool bevl_nextIsCall = null;
BEC_4_6_TextString bevl_delim = null;
BEC_9_10_ContainerLinkedList bevl_splits = null;
BEC_4_3_MathInt bevl_last = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_ds = null;
BEC_4_6_TextString bevl_payload = null;
BEC_9_10_ContainerLinkedList bevl_payloads = null;
BEC_7_8_ReplaceCallStep bevl_rcs = null;
BEC_4_6_TextString bevl_paypart = null;
BEC_7_7_ReplaceRunStep bevl_rs = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_7_10_ReplaceStringStep bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_7_10_ReplaceStringStep bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
bevp_runner = beva__runner;
bevp_size = beva_template.bem_sizeGet_0();
bevl_blStart = (new BEC_4_6_TextString(4, bels_0));
bevl_blEnd = (new BEC_4_6_TextString(2, bels_1));
bevl_onStart = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_nextIsCall = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_delim = bevl_blStart;
bevl_splits = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_4_3_MathInt(0));
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
bevl_ds = bevl_delim.bem_sizeGet_0();
while (true)
 /* Line: 86 */ {
if (bevl_i == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevt_2_tmpvar_phold = bevl_i.bem_greater_1(bevl_last);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 87 */ {
if (bevl_nextIsCall.bevi_bool) /* Line: 88 */ {
bevt_3_tmpvar_phold = beva_template.bem_substring_2(bevl_last, bevl_i);
bevl_payload = (BEC_4_6_TextString) bevt_3_tmpvar_phold.bem_strip_0();
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(1, bels_2));
bevl_payloads = (BEC_9_10_ContainerLinkedList) bevl_payload.bem_split_1(bevt_4_tmpvar_phold);
if (bevp_runner == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevl_rcs = (new BEC_7_8_ReplaceCallStep()).bem_new_1(bevl_payloads);
bevl_splits.bem_addValue_1(bevl_rcs);
bevl_nextIsCall = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 95 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_loop = bevl_payloads.bem_iteratorGet_0();
while (true)
 /* Line: 98 */ {
bevt_6_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 98 */ {
bevl_paypart = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_rs = (new BEC_7_7_ReplaceRunStep()).bem_new_2(this, bevl_paypart);
bevl_splits.bem_addValue_1(bevl_rs);
} /* Line: 100 */
 else  /* Line: 98 */ {
break;
} /* Line: 98 */
} /* Line: 98 */
bevl_nextIsCall = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 102 */
} /* Line: 91 */
 else  /* Line: 104 */ {
bevt_8_tmpvar_phold = beva_template.bem_substring_2(bevl_last, bevl_i);
bevt_7_tmpvar_phold = (new BEC_7_10_ReplaceStringStep()).bem_new_1(bevt_8_tmpvar_phold);
bevl_splits.bem_addValue_1(bevt_7_tmpvar_phold);
} /* Line: 105 */
} /* Line: 88 */
bevl_last = bevl_i.bem_add_1(bevl_ds);
if (bevl_onStart.bevi_bool) /* Line: 109 */ {
bevl_onStart = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_delim = bevl_blEnd;
bevl_ds = bevl_delim.bem_sizeGet_0();
bevl_nextIsCall = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 113 */
 else  /* Line: 114 */ {
bevl_onStart = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_delim = bevl_blStart;
bevl_ds = bevl_delim.bem_sizeGet_0();
} /* Line: 117 */
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
} /* Line: 119 */
 else  /* Line: 86 */ {
break;
} /* Line: 86 */
} /* Line: 86 */
bevt_9_tmpvar_phold = bevl_last.bem_lesser_1(bevp_size);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 121 */ {
bevt_11_tmpvar_phold = beva_template.bem_substring_2(bevl_last, bevp_size);
bevt_10_tmpvar_phold = (new BEC_7_10_ReplaceStringStep()).bem_new_1(bevt_11_tmpvar_phold);
bevl_splits.bem_addValue_1(bevt_10_tmpvar_phold);
} /* Line: 122 */
bevp_steps = bevl_splits;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_accept_2(BEC_6_6_SystemObject beva_inst, BEC_6_6_SystemObject beva_out) throws Throwable {
BEC_6_6_SystemObject bevl_iter = null;
BEC_6_6_SystemObject bevl_s = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_iter = bevp_steps.bem_iteratorGet_0();
while (true)
 /* Line: 129 */ {
bevt_0_tmpvar_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 129 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_append.bevi_bool) /* Line: 131 */ {
bevt_1_tmpvar_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, beva_inst);
beva_out.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_1_tmpvar_phold);
} /* Line: 132 */
} /* Line: 131 */
 else  /* Line: 129 */ {
break;
} /* Line: 129 */
} /* Line: 129 */
return beva_out;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
return bevp_steps;
} /*method end*/
public BEC_6_6_SystemObject bem_stepsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_steps = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_appendGet_0() throws Throwable {
return bevp_append;
} /*method end*/
public BEC_6_6_SystemObject bem_appendSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_append = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_8_6_TemplateRunner bem_runnerGet_0() throws Throwable {
return bevp_runner;
} /*method end*/
public BEC_6_6_SystemObject bem_runnerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runner = (BEC_8_6_TemplateRunner) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {62, 69, 73, 74, 76, 77, 78, 79, 81, 82, 83, 84, 85, 86, 86, 87, 89, 89, 90, 90, 91, 91, 93, 94, 95, 98, 0, 98, 98, 99, 100, 102, 105, 105, 105, 108, 110, 111, 112, 113, 115, 116, 117, 119, 121, 122, 122, 122, 124, 128, 129, 130, 132, 132, 135, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 20, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 63, 68, 69, 72, 73, 74, 75, 76, 81, 82, 83, 84, 87, 87, 90, 92, 93, 94, 100, 104, 105, 106, 109, 111, 112, 113, 114, 117, 118, 119, 121, 127, 129, 130, 131, 133, 141, 144, 146, 148, 149, 156, 159, 162, 166, 169, 173, 176, 180, 183};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 62 16
new 0 62 16
load 2 69 20
assign 1 73 50
assign 1 74 51
sizeGet 0 74 51
assign 1 76 52
new 0 76 52
assign 1 77 53
new 0 77 53
assign 1 78 54
new 0 78 54
assign 1 79 55
new 0 79 55
assign 1 81 56
assign 1 82 57
new 0 82 57
assign 1 83 58
new 0 83 58
assign 1 84 59
find 2 84 59
assign 1 85 60
sizeGet 0 85 60
assign 1 86 63
def 1 86 68
assign 1 87 69
greater 1 87 69
assign 1 89 72
substring 2 89 72
assign 1 89 73
strip 0 89 73
assign 1 90 74
new 0 90 74
assign 1 90 75
split 1 90 75
assign 1 91 76
undef 1 91 81
assign 1 93 82
new 1 93 82
addValue 1 94 83
assign 1 95 84
new 0 95 84
assign 1 98 87
iteratorGet 0 0 87
assign 1 98 90
hasNextGet 0 98 90
assign 1 98 92
nextGet 0 98 92
assign 1 99 93
new 2 99 93
addValue 1 100 94
assign 1 102 100
new 0 102 100
assign 1 105 104
substring 2 105 104
assign 1 105 105
new 1 105 105
addValue 1 105 106
assign 1 108 109
add 1 108 109
assign 1 110 111
new 0 110 111
assign 1 111 112
assign 1 112 113
sizeGet 0 112 113
assign 1 113 114
new 0 113 114
assign 1 115 117
new 0 115 117
assign 1 116 118
assign 1 117 119
sizeGet 0 117 119
assign 1 119 121
find 2 119 121
assign 1 121 127
lesser 1 121 127
assign 1 122 129
substring 2 122 129
assign 1 122 130
new 1 122 130
addValue 1 122 131
assign 1 124 133
assign 1 128 141
iteratorGet 0 128 141
assign 1 129 144
hasNextGet 0 129 144
assign 1 130 146
nextGet 0 130 146
assign 1 132 148
handle 1 132 148
write 1 132 149
return 1 135 156
return 1 0 159
assign 1 0 162
return 1 0 166
assign 1 0 169
return 1 0 173
assign 1 0 176
return 1 0 180
assign 1 0 183
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 723109216: return bem_stepsGet_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1908752755: return bem_appendGet_0();
case 1102720804: return bem_classNameGet_0();
case 251179977: return bem_runnerGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 474162694: return bem_sizeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1097519336: return bem_load_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 712026963: return bem_stepsSet_1(bevd_0);
case 240097724: return bem_runnerSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1897670502: return bem_appendSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1097519335: return bem_load_2((BEC_4_6_TextString) bevd_0, (BEC_8_6_TemplateRunner) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 2146525509: return bem_accept_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_8_7_TemplateReplace();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_8_7_TemplateReplace.bevs_inst = (BEC_8_7_TemplateReplace)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_8_7_TemplateReplace.bevs_inst;
}
}
