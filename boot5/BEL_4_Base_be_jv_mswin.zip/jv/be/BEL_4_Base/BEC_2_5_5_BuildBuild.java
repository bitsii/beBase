package be.BEL_4_Base;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bels_6 = {0x31};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_9, 28));
private static byte[] bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_11 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_11, 12));
private static byte[] bels_12 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_12, 21));
private static byte[] bels_13 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_13, 6));
private static byte[] bels_14 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_14, 13));
private static byte[] bels_15 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_15, 21));
private static byte[] bels_16 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_16, 6));
private static byte[] bels_17 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_18 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_18, 5));
private static byte[] bels_19 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_21 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_22 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_23 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_24 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_25 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_26 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_27 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_28 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_29 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_30 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_31 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_32 = {0x74,0x72,0x75,0x65};
private static byte[] bels_33 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_35 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_36 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_37 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_38 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_39 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_40 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_42 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_43 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_44 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_45 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_49 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_50 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_51 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_52 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_53 = {0x72,0x75,0x6E};
private static byte[] bels_54 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_55 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_56 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_57 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_58 = {0x67,0x63,0x63};
private static byte[] bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_60 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_61 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_61, 9));
private static byte[] bels_62 = {};
private static byte[] bels_63 = {0x63};
private static byte[] bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_64, 8));
private static byte[] bels_65 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_65, 7));
private static byte[] bels_66 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_67 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_68 = {0x6A,0x76};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_68, 2));
private static byte[] bels_69 = {0x63,0x73};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_69, 2));
private static byte[] bels_70 = {0x6A,0x73};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_70, 2));
private static byte[] bels_71 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_72 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_72, 19));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_73, 31));
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_74, 41));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_19 = (new BEC_2_4_6_TextString(bels_75, 30));
private static byte[] bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_20 = (new BEC_2_4_6_TextString(bels_76, 31));
private static byte[] bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_77, 41));
private static byte[] bels_78 = {0x2F};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bels_78, 1));
private static byte[] bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bels_79, 31));
private static byte[] bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_24 = (new BEC_2_4_6_TextString(bels_80, 41));
private static byte[] bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_25 = (new BEC_2_4_6_TextString(bels_81, 51));
private static byte[] bels_82 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_26 = (new BEC_2_4_6_TextString(bels_82, 14));
private static byte[] bels_83 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bevo_27 = (new BEC_2_4_6_TextString(bels_83, 19));
private static byte[] bels_84 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bevo_28 = (new BEC_2_4_6_TextString(bels_84, 9));
private static byte[] bels_85 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_29 = (new BEC_2_4_6_TextString(bels_85, 13));
private static byte[] bels_86 = {0x2E,0x20};
private static BEC_2_4_6_TextString bevo_30 = (new BEC_2_4_6_TextString(bels_86, 2));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bevo_31 = (new BEC_2_4_6_TextString(bels_87, 22));
private static byte[] bels_88 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_32 = (new BEC_2_4_6_TextString(bels_88, 3));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bevo_33 = (new BEC_2_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_34 = (new BEC_2_4_6_TextString(bels_90, 4));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bevo_35 = (new BEC_2_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_36 = (new BEC_2_4_6_TextString(bels_92, 5));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bevo_37 = (new BEC_2_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_38 = (new BEC_2_4_6_TextString(bels_94, 6));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bevo_39 = (new BEC_2_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_40 = (new BEC_2_4_6_TextString(bels_96, 7));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bevo_41 = (new BEC_2_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_42 = (new BEC_2_4_6_TextString(bels_98, 8));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bevo_43 = (new BEC_2_4_6_TextString(bels_99, 15));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_44 = (new BEC_2_4_6_TextString(bels_100, 9));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bevo_45 = (new BEC_2_4_6_TextString(bels_101, 15));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_46 = (new BEC_2_4_6_TextString(bels_102, 10));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bevo_47 = (new BEC_2_4_6_TextString(bels_103, 15));
private static byte[] bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_48 = (new BEC_2_4_6_TextString(bels_104, 11));
private static byte[] bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bevo_49 = (new BEC_2_4_6_TextString(bels_105, 16));
private static byte[] bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_50 = (new BEC_2_4_6_TextString(bels_106, 12));
private static byte[] bels_107 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bevo_51 = (new BEC_2_4_6_TextString(bels_107, 16));
private static byte[] bels_108 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_52 = (new BEC_2_4_6_TextString(bels_108, 13));
private static byte[] bels_109 = {0x20};
private static BEC_2_4_6_TextString bevo_53 = (new BEC_2_4_6_TextString(bels_109, 1));
private static byte[] bels_110 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bevo_54 = (new BEC_2_4_6_TextString(bels_110, 16));
public static BEC_2_5_5_BuildBuild bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
 else  /* Line: 96 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 96 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 97 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bevs_inst;
bevt_2_tmpvar_phold = this.bem_main_1(bevl__args);
bevt_1_tmpvar_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_5));
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevp_params.bem_get_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpvar_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 115 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevl_res = this.bem_go_0();
bevl_i.bevi_int++;
} /* Line: 115 */
 else  /* Line: 115 */ {
break;
} /* Line: 115 */
} /* Line: 115 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 125 */ {
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bels_7));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bels_8));
} /* Line: 128 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 133 */
if (bevp_printSteps.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 135 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 135 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 135 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 136 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_10));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 148 */
return beva_addTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_93_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_96_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_109_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_113_tmpvar_phold = null;
BEC_2_9_4_ContainerList bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_116_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_120_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_2_4_IOFile bevt_122_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpvar_phold = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bels_17));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 158 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 159 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 159 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpvar_phold.bevi_bool) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 160 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 162 */
} /* Line: 160 */
 else  /* Line: 159 */ {
break;
} /* Line: 159 */
} /* Line: 159 */
} /* Line: 159 */
bevt_13_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 167 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 168 */
bevt_16_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_19));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_20));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevt_20_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_21));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 172 */
 else  /* Line: 173 */ {
bevp_exeName = bevp_libName;
} /* Line: 174 */
bevt_24_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_22));
bevt_25_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_23));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_24));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_25));
bevt_31_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_26));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_27));
bevt_36_tmpvar_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_28));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_2_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_2_4_6_TextString(16, bels_29));
bevt_44_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_30));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_31));
bevt_48_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_32));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_33));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_34));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_35));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 189 */
bevt_55_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_36));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_57_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_37));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_59_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_38));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_61_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_39));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_63_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_40));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_65_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_41));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_67_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_42));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_69_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_43));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_71_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_44));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 225 */
bevt_73_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_45));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 229 */
 else  /* Line: 230 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 231 */
bevt_75_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_46));
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_47));
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_48));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_49));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_50));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_84_tmpvar_phold.bevi_bool) {
bevt_83_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_83_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 239 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 240 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 240 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 241 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
} /* Line: 240 */
bevt_86_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_51));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (new BEC_2_4_6_TextString(19, bels_52));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_53));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (new BEC_2_4_6_TextString(21, bels_54));
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_55));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_56));
bevp_emitFlags = bevp_params.bem_get_1(bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_57));
bevt_95_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_58));
bevt_93_tmpvar_phold = bevp_params.bem_get_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_93_tmpvar_phold.bem_firstGet_0();
bevt_97_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_59));
bevt_98_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_60));
bevt_96_tmpvar_phold = bevp_params.bem_get_2(bevt_97_tmpvar_phold, bevt_98_tmpvar_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = bevo_10;
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_102_tmpvar_phold = (new BEC_2_4_6_TextString(0, bels_62));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_102_tmpvar_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevp_parse = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 260 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 261 */
 else  /* Line: 262 */ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bels_63));
} /* Line: 263 */
bevt_106_tmpvar_phold = bevo_11;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevt_107_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_104_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 271 */ {
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_109_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 272 */
bevt_111_tmpvar_phold = bevo_12;
bevt_110_tmpvar_phold = bevl_outLang.bem_add_1(bevt_111_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_langSources == null) {
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_113_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 277 */
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_114_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_114_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_115_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_116_tmpvar_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_116_tmpvar_phold);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_existsGet_0();
if (bevt_118_tmpvar_phold.bevi_bool) {
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_117_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevt_120_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpvar_phold.bem_makeDirs_0();
} /* Line: 290 */
if (bevp_emitFileHeader == null) {
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 292 */ {
bevt_122_tmpvar_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_122_tmpvar_phold.bem_readerGet_0();
bevt_123_tmpvar_phold = bevl_emr.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_123_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 295 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_66));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_67));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_6_6_SystemObject bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 311 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 315 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 316 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
} /* Line: 315 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 321 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 322 */
 else  /* Line: 321 */ {
break;
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 321 */
} /* Line: 320 */
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 327 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 327 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 329 */
 else  /* Line: 327 */ {
break;
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 340 */ {
return bevp_emitCommon;
} /* Line: 341 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 346 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 348 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 348 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 354 */ {
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(49, bels_71));
bevt_8_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 355 */
} /* Line: 348 */
} /* Line: 348 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 358 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_4_8_TimeInterval bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_16_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_21_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_23_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_24_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_37_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_64_tmpvar_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_76_tmpvar_phold = null;
BEC_2_4_8_TimeInterval bevt_77_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_85_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_90_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
bevt_4_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_4_tmpvar_phold.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 368 */ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 371 */ {
bevt_7_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_libName);
bevt_6_tmpvar_phold.bem_print_0();
} /* Line: 372 */
} /* Line: 371 */
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 377 */ {
bevt_8_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 377 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_10_tmpvar_phold.bevi_bool) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 378 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 381 */
} /* Line: 378 */
 else  /* Line: 377 */ {
break;
} /* Line: 377 */
} /* Line: 377 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 384 */ {
bevt_11_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 384 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpvar_phold.bevi_bool) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 385 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_14_tmpvar_phold = bevl_pack.bemd_0(-1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_14_tmpvar_phold);
} /* Line: 389 */
} /* Line: 385 */
 else  /* Line: 384 */ {
break;
} /* Line: 384 */
} /* Line: 384 */
if (bevp_parse.bevi_bool) /* Line: 392 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 394 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 394 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 397 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 399 */
bevt_17_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_now_0();
bevp_parseTime = bevt_16_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_19_tmpvar_phold = bevo_17;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_18_tmpvar_phold.bem_print_0();
bevt_21_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevt_22_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_22_tmpvar_phold.bem_now_0();
bevt_23_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_23_tmpvar_phold.bem_doEmit_0();
bevt_25_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_24_tmpvar_phold.bem_subtract_1(bevp_startTime);
bevt_27_tmpvar_phold = bevo_18;
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_26_tmpvar_phold.bem_print_0();
bevt_29_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_now_0();
bevl_emitTime = bevt_28_tmpvar_phold.bem_subtract_1(bevl_emitStart);
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevl_emitTime);
bevt_30_tmpvar_phold.bem_print_0();
bevt_32_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
return bevt_32_tmpvar_phold;
} /* Line: 414 */
if (bevp_doEmit.bevi_bool) /* Line: 416 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_33_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_33_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 420 */ {
bevt_34_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 420 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(-4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 422 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
bevl_em.bemd_0(-1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_35_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_35_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 426 */ {
bevt_36_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 426 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 428 */
 else  /* Line: 426 */ {
break;
} /* Line: 426 */
} /* Line: 426 */
} /* Line: 426 */
bevt_38_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_37_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 433 */ {
bevt_41_tmpvar_phold = bevo_20;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_40_tmpvar_phold.bem_print_0();
} /* Line: 434 */
bevt_43_tmpvar_phold = bevo_21;
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_42_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 437 */ {
bevl_em.bemd_1(-1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 439 */
if (bevp_make.bevi_bool) /* Line: 442 */ {
if (bevp_genOnly.bevi_bool) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 443 */ {
bevl_em.bemd_1(-1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 446 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 447 */ {
bevt_45_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 447 */ {
bevl_bp = bevt_2_tmpvar_loop.bem_nextGet_0();
bevt_46_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_46_tmpvar_phold.bemd_0(-159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_47_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_47_tmpvar_phold.bem_copy_0();
bevt_49_tmpvar_phold = bevl_cpFrom.bemd_0(-723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_48_tmpvar_phold);
bevt_51_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 451 */ {
bevt_52_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_52_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 452 */
bevt_55_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 454 */ {
bevt_56_tmpvar_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_56_tmpvar_phold, bevt_57_tmpvar_phold);
} /* Line: 455 */
} /* Line: 454 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
} /* Line: 447 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 462 */ {
bevt_58_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_58_tmpvar_phold != null && bevt_58_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_58_tmpvar_phold).bevi_bool) /* Line: 462 */ {
bevt_59_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 462 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 462 */ {
bevt_60_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_60_tmpvar_phold);
bevt_65_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_64_tmpvar_phold = bevt_65_tmpvar_phold.bem_copy_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_toString_0();
bevt_66_tmpvar_phold = bevo_22;
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bem_add_1(bevt_66_tmpvar_phold);
bevt_67_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bem_add_1(bevt_67_tmpvar_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_61_tmpvar_phold);
bevt_69_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_68_tmpvar_phold != null && bevt_68_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_68_tmpvar_phold).bevi_bool) /* Line: 466 */ {
bevt_70_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_70_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 467 */
bevt_73_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_71_tmpvar_phold != null && bevt_71_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_71_tmpvar_phold).bevi_bool) /* Line: 469 */ {
bevt_74_tmpvar_phold = bevl_cpFrom.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_75_tmpvar_phold = bevl_cpTo.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEL_4_Base.bevn_deployFile_2, bevt_74_tmpvar_phold, bevt_75_tmpvar_phold);
} /* Line: 470 */
} /* Line: 469 */
 else  /* Line: 462 */ {
break;
} /* Line: 462 */
} /* Line: 462 */
} /* Line: 462 */
} /* Line: 443 */
bevt_77_tmpvar_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_76_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpvar_phold.bevi_bool) /* Line: 477 */ {
bevt_80_tmpvar_phold = bevo_23;
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_79_tmpvar_phold.bem_print_0();
} /* Line: 478 */
if (bevp_parseEmitTime == null) {
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 480 */ {
bevt_83_tmpvar_phold = bevo_24;
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_82_tmpvar_phold.bem_print_0();
} /* Line: 481 */
if (bevp_parseEmitCompileTime == null) {
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpvar_phold.bevi_bool) /* Line: 483 */ {
bevt_86_tmpvar_phold = bevo_25;
bevt_85_tmpvar_phold = bevt_86_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_85_tmpvar_phold.bem_print_0();
} /* Line: 484 */
if (bevp_run.bevi_bool) /* Line: 487 */ {
bevt_87_tmpvar_phold = bevo_26;
bevt_87_tmpvar_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_90_tmpvar_phold = bevo_27;
bevt_89_tmpvar_phold = bevt_90_tmpvar_phold.bem_add_1(bevl_result);
bevt_91_tmpvar_phold = bevo_28;
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bem_add_1(bevt_91_tmpvar_phold);
bevt_88_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 491 */
bevt_92_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
return bevt_92_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 497 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 501 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 503 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 503 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 507 */
 else  /* Line: 503 */ {
break;
} /* Line: 503 */
} /* Line: 503 */
bevt_6_tmpvar_phold = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 513 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 514 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 517 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 522 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(-1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 524 */
 else  /* Line: 525 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 527 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 529 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpvar_phold, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 539 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 540 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps, (BEC_2_5_8_BuildClassSyn) bevl_syn);
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 555 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 556 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 569 */ {
if (bevp_printSteps.bevi_bool) /* Line: 570 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 570 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 570 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 570 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 570 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 570 */ {
bevt_4_tmpvar_phold = bevo_29;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 571 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(-1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 580 */ {
bevt_11_tmpvar_phold = bevo_30;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 581 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(-1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 584 */ {
bevt_13_tmpvar_phold = bevo_31;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 586 */
if (bevp_printSteps.bevi_bool) /* Line: 589 */ {
bevt_15_tmpvar_phold = bevo_32;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 590 */
bevt_16_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 593 */ {
bevt_17_tmpvar_phold = bevo_33;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 595 */
if (bevp_printSteps.bevi_bool) /* Line: 597 */ {
bevt_19_tmpvar_phold = bevo_34;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 598 */
bevt_20_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(-410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 603 */ {
bevt_21_tmpvar_phold = bevo_35;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 605 */
if (bevp_printSteps.bevi_bool) /* Line: 608 */ {
bevt_23_tmpvar_phold = bevo_36;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 609 */
bevt_24_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 612 */ {
bevt_25_tmpvar_phold = bevo_37;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 614 */
if (bevp_printSteps.bevi_bool) /* Line: 617 */ {
bevt_27_tmpvar_phold = bevo_38;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 618 */
bevt_28_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 621 */ {
bevt_29_tmpvar_phold = bevo_39;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 623 */
if (bevp_printSteps.bevi_bool) /* Line: 626 */ {
bevt_31_tmpvar_phold = bevo_40;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 627 */
bevt_32_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 630 */ {
bevt_33_tmpvar_phold = bevo_41;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 632 */
if (bevp_printSteps.bevi_bool) /* Line: 635 */ {
bevt_35_tmpvar_phold = bevo_42;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 636 */
bevt_36_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 639 */ {
bevt_37_tmpvar_phold = bevo_43;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 641 */
if (bevp_printSteps.bevi_bool) /* Line: 644 */ {
bevt_39_tmpvar_phold = bevo_44;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 645 */
bevt_40_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 648 */ {
bevt_41_tmpvar_phold = bevo_45;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 650 */
if (bevp_printSteps.bevi_bool) /* Line: 653 */ {
bevt_43_tmpvar_phold = bevo_46;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 654 */
bevt_44_tmpvar_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 657 */ {
bevt_45_tmpvar_phold = bevo_47;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 659 */
if (bevp_printSteps.bevi_bool) /* Line: 662 */ {
bevt_47_tmpvar_phold = bevo_48;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 663 */
bevt_48_tmpvar_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 666 */ {
bevt_49_tmpvar_phold = bevo_49;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 668 */
if (bevp_printSteps.bevi_bool) /* Line: 670 */ {
bevt_51_tmpvar_phold = bevo_50;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 671 */
bevt_52_tmpvar_phold = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 674 */ {
bevt_53_tmpvar_phold = bevo_51;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 676 */
if (bevp_printSteps.bevi_bool) /* Line: 679 */ {
bevt_55_tmpvar_phold = bevo_52;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_53;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 681 */
bevt_57_tmpvar_phold = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 684 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 684 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 684 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 684 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 684 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 684 */ {
bevt_58_tmpvar_phold = bevo_54;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 686 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 688 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 688 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(-1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(-568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(-557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 699 */
 else  /* Line: 688 */ {
break;
} /* Line: 688 */
} /* Line: 688 */
} /* Line: 688 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 709 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 709 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 713 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 714 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 716 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 718 */
} /* Line: 716 */
 else  /* Line: 709 */ {
break;
} /* Line: 709 */
} /* Line: 709 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_6_6_SystemObject bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_6_6_SystemObject bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_6_6_SystemObject bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_6_6_SystemObject bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_6_6_SystemObject bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_6_6_SystemObject bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_6_6_SystemObject bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() throws Throwable {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_2_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_6_6_SystemObject bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {53, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 70, 72, 73, 74, 75, 75, 78, 81, 82, 88, 89, 90, 91, 91, 96, 96, 96, 96, 0, 96, 96, 0, 0, 0, 0, 0, 97, 97, 99, 99, 103, 103, 103, 103, 107, 107, 108, 108, 108, 112, 113, 114, 114, 114, 114, 114, 115, 115, 115, 116, 115, 118, 122, 123, 124, 126, 127, 128, 130, 131, 132, 132, 133, 0, 0, 0, 136, 138, 142, 142, 142, 143, 143, 143, 143, 144, 144, 144, 145, 145, 145, 146, 146, 146, 146, 147, 147, 147, 148, 148, 148, 150, 155, 157, 158, 158, 158, 159, 159, 0, 159, 159, 160, 160, 160, 161, 162, 162, 167, 167, 167, 167, 168, 170, 170, 170, 171, 171, 172, 172, 172, 174, 176, 176, 176, 176, 176, 176, 177, 178, 178, 179, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 185, 185, 185, 186, 186, 186, 187, 187, 188, 188, 189, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 233, 233, 233, 234, 234, 234, 235, 235, 236, 236, 237, 238, 238, 239, 239, 239, 239, 239, 0, 0, 0, 240, 0, 240, 240, 241, 244, 244, 245, 245, 246, 246, 247, 247, 247, 248, 248, 249, 249, 250, 250, 250, 250, 251, 251, 251, 251, 252, 252, 252, 252, 252, 253, 254, 255, 256, 257, 260, 260, 261, 263, 270, 270, 270, 270, 270, 271, 271, 272, 272, 275, 275, 275, 276, 276, 277, 277, 280, 281, 281, 0, 281, 281, 282, 282, 284, 285, 286, 288, 289, 289, 289, 289, 290, 290, 292, 292, 293, 293, 294, 294, 295, 301, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 304, 308, 309, 309, 309, 310, 311, 311, 311, 311, 312, 312, 312, 312, 313, 313, 313, 313, 313, 314, 314, 315, 0, 315, 315, 316, 319, 319, 319, 319, 319, 320, 320, 321, 0, 321, 321, 322, 327, 327, 327, 328, 329, 329, 329, 329, 329, 329, 336, 336, 340, 340, 341, 346, 346, 347, 348, 348, 349, 350, 350, 351, 352, 352, 353, 355, 355, 355, 357, 358, 360, 365, 365, 366, 367, 368, 368, 369, 370, 372, 372, 372, 375, 377, 0, 377, 377, 378, 378, 378, 379, 380, 381, 384, 0, 384, 384, 385, 385, 385, 386, 387, 388, 389, 389, 394, 394, 395, 397, 399, 402, 402, 402, 404, 404, 404, 406, 406, 406, 408, 408, 409, 409, 410, 410, 410, 411, 411, 411, 412, 412, 412, 413, 413, 413, 414, 414, 417, 418, 420, 420, 420, 421, 422, 424, 425, 426, 426, 426, 427, 428, 432, 432, 432, 433, 433, 434, 434, 434, 436, 436, 436, 439, 443, 443, 444, 445, 447, 0, 447, 447, 448, 448, 449, 449, 450, 450, 450, 451, 451, 452, 452, 454, 454, 454, 455, 455, 455, 459, 460, 462, 462, 0, 0, 0, 463, 463, 464, 464, 464, 464, 464, 464, 464, 464, 466, 466, 467, 467, 469, 469, 469, 470, 470, 470, 475, 475, 475, 477, 477, 478, 478, 478, 480, 480, 481, 481, 481, 483, 483, 484, 484, 484, 488, 488, 489, 490, 490, 490, 490, 490, 491, 493, 493, 497, 497, 497, 498, 499, 499, 500, 501, 503, 503, 503, 504, 505, 505, 506, 507, 509, 509, 513, 513, 513, 513, 514, 514, 514, 516, 516, 517, 517, 517, 517, 518, 520, 520, 520, 520, 520, 522, 522, 523, 523, 524, 527, 527, 527, 529, 531, 531, 532, 532, 532, 532, 533, 537, 538, 538, 539, 539, 540, 546, 546, 547, 548, 555, 555, 556, 558, 563, 564, 565, 566, 567, 568, 568, 0, 0, 0, 571, 571, 571, 571, 573, 575, 575, 575, 575, 576, 576, 576, 577, 581, 581, 583, 583, 585, 585, 586, 586, 590, 590, 592, 592, 594, 594, 595, 595, 598, 598, 601, 601, 602, 604, 604, 605, 605, 609, 609, 611, 611, 613, 613, 614, 614, 618, 618, 620, 620, 622, 622, 623, 623, 627, 627, 629, 629, 631, 631, 632, 632, 636, 636, 638, 638, 640, 640, 641, 641, 645, 645, 647, 647, 649, 649, 650, 650, 654, 654, 656, 656, 658, 658, 659, 659, 663, 663, 665, 665, 667, 667, 668, 668, 671, 671, 673, 673, 675, 675, 676, 676, 680, 680, 681, 681, 683, 683, 0, 0, 0, 685, 685, 686, 686, 688, 688, 688, 689, 691, 692, 693, 693, 694, 695, 695, 695, 696, 697, 698, 699, 705, 706, 707, 708, 708, 709, 709, 710, 711, 711, 712, 713, 713, 714, 716, 716, 717, 718, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 283, 288, 289, 290, 292, 295, 296, 298, 301, 305, 308, 312, 315, 316, 318, 319, 325, 326, 327, 328, 335, 336, 337, 338, 339, 351, 352, 353, 354, 355, 356, 357, 358, 361, 366, 367, 368, 374, 382, 383, 384, 386, 387, 388, 392, 393, 394, 395, 396, 399, 403, 406, 410, 412, 432, 433, 434, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 457, 593, 594, 595, 596, 601, 602, 603, 603, 606, 608, 609, 610, 615, 616, 617, 618, 626, 627, 628, 629, 631, 633, 634, 635, 636, 637, 639, 640, 641, 644, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 695, 696, 698, 699, 700, 705, 706, 708, 709, 710, 715, 716, 718, 719, 720, 725, 726, 728, 729, 730, 735, 736, 738, 739, 740, 745, 746, 748, 749, 750, 755, 756, 758, 759, 760, 765, 766, 768, 769, 770, 775, 776, 778, 779, 780, 785, 786, 788, 789, 790, 795, 796, 799, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 819, 820, 821, 826, 827, 830, 834, 837, 837, 840, 842, 843, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 886, 887, 890, 892, 893, 894, 895, 896, 897, 902, 903, 904, 906, 907, 908, 909, 914, 915, 916, 918, 919, 920, 920, 923, 925, 926, 927, 933, 934, 935, 936, 937, 938, 939, 944, 945, 946, 948, 953, 954, 955, 956, 957, 958, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982, 983, 1023, 1024, 1025, 1028, 1030, 1031, 1032, 1033, 1034, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1050, 1051, 1051, 1054, 1056, 1057, 1064, 1065, 1066, 1067, 1068, 1069, 1074, 1075, 1075, 1078, 1080, 1081, 1094, 1095, 1098, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1116, 1117, 1131, 1136, 1137, 1139, 1144, 1145, 1146, 1147, 1149, 1152, 1153, 1155, 1158, 1159, 1161, 1164, 1165, 1166, 1170, 1171, 1173, 1285, 1286, 1287, 1288, 1289, 1294, 1295, 1296, 1298, 1299, 1300, 1303, 1304, 1304, 1307, 1309, 1310, 1311, 1316, 1317, 1318, 1319, 1326, 1326, 1329, 1331, 1332, 1333, 1338, 1339, 1340, 1341, 1342, 1343, 1351, 1354, 1356, 1357, 1363, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1387, 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1398, 1399, 1400, 1401, 1404, 1406, 1407, 1413, 1414, 1415, 1416, 1419, 1421, 1422, 1429, 1430, 1431, 1432, 1437, 1438, 1439, 1440, 1442, 1443, 1444, 1446, 1449, 1454, 1455, 1456, 1458, 1458, 1461, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1474, 1475, 1477, 1478, 1479, 1481, 1482, 1483, 1491, 1492, 1495, 1497, 1499, 1502, 1506, 1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1522, 1523, 1525, 1526, 1527, 1529, 1530, 1531, 1540, 1541, 1542, 1543, 1548, 1549, 1550, 1551, 1553, 1558, 1559, 1560, 1561, 1563, 1568, 1569, 1570, 1571, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1584, 1585, 1598, 1599, 1602, 1604, 1605, 1606, 1607, 1608, 1614, 1615, 1618, 1620, 1621, 1622, 1623, 1624, 1630, 1631, 1659, 1660, 1661, 1666, 1667, 1668, 1669, 1671, 1672, 1673, 1674, 1675, 1680, 1681, 1684, 1685, 1686, 1687, 1688, 1689, 1694, 1695, 1696, 1697, 1700, 1701, 1702, 1704, 1706, 1707, 1708, 1709, 1710, 1711, 1712, 1720, 1721, 1722, 1723, 1728, 1729, 1731, 1732, 1733, 1734, 1738, 1743, 1744, 1746, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1834, 1838, 1841, 1845, 1846, 1847, 1848, 1850, 1851, 1852, 1853, 1854, 1855, 1856, 1857, 1858, 1860, 1861, 1863, 1864, 1866, 1867, 1868, 1869, 1872, 1873, 1875, 1876, 1878, 1879, 1880, 1881, 1884, 1885, 1887, 1888, 1889, 1891, 1892, 1893, 1894, 1897, 1898, 1900, 1901, 1903, 1904, 1905, 1906, 1909, 1910, 1912, 1913, 1915, 1916, 1917, 1918, 1921, 1922, 1924, 1925, 1927, 1928, 1929, 1930, 1933, 1934, 1936, 1937, 1939, 1940, 1941, 1942, 1945, 1946, 1948, 1949, 1951, 1952, 1953, 1954, 1957, 1958, 1960, 1961, 1963, 1964, 1965, 1966, 1969, 1970, 1972, 1973, 1975, 1976, 1977, 1978, 1981, 1982, 1984, 1985, 1987, 1988, 1989, 1990, 1993, 1994, 1995, 1996, 1998, 1999, 2001, 2005, 2008, 2012, 2013, 2014, 2015, 2017, 2018, 2021, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2057, 2058, 2059, 2060, 2061, 2062, 2065, 2067, 2068, 2069, 2070, 2071, 2072, 2074, 2076, 2077, 2079, 2080, 2090, 2093, 2097, 2100, 2104, 2107, 2111, 2114, 2118, 2121, 2125, 2128, 2132, 2135, 2139, 2142, 2146, 2149, 2153, 2156, 2160, 2163, 2167, 2170, 2174, 2177, 2181, 2184, 2188, 2191, 2195, 2198, 2202, 2205, 2209, 2212, 2216, 2219, 2223, 2226, 2230, 2233, 2237, 2240, 2244, 2247, 2251, 2254, 2258, 2261, 2265, 2268, 2272, 2275, 2279, 2282, 2286, 2289, 2293, 2296, 2300, 2303, 2307, 2310, 2314, 2317, 2321, 2324, 2328, 2331, 2335, 2338, 2342, 2345, 2349, 2352, 2356, 2359, 2363, 2366, 2370, 2373, 2377, 2380, 2384, 2387, 2391, 2394, 2398, 2401, 2405, 2408, 2412, 2415, 2419, 2422, 2426, 2429, 2433, 2436, 2440, 2443, 2447, 2450, 2454, 2457, 2461, 2464, 2468, 2471, 2475, 2478, 2482, 2485, 2489, 2492, 2496, 2499, 2503, 2506, 2510, 2513, 2517, 2520, 2524, 2527, 2531, 2534, 2538, 2541, 2545, 2548, 2552, 2555, 2559, 2562, 2566};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 53 246
new 0 53 246
assign 1 55 247
new 0 55 247
assign 1 56 248
new 0 56 248
assign 1 57 249
new 0 57 249
assign 1 58 250
new 0 58 250
assign 1 60 251
new 0 60 251
assign 1 61 252
new 0 61 252
assign 1 62 253
new 0 62 253
assign 1 63 254
new 0 63 254
assign 1 64 255
new 0 64 255
assign 1 65 256
new 0 65 256
assign 1 66 257
new 0 66 257
assign 1 70 258
new 0 70 258
assign 1 72 259
new 1 72 259
assign 1 73 260
ntypesGet 0 73 260
assign 1 74 261
twtokGet 0 74 261
assign 1 75 262
new 0 75 262
assign 1 75 263
new 1 75 263
assign 1 78 264
new 0 78 264
assign 1 81 265
new 0 81 265
assign 1 82 266
new 0 82 266
assign 1 88 267
new 0 88 267
assign 1 89 268
new 0 89 268
assign 1 90 269
new 0 90 269
assign 1 91 270
new 0 91 270
assign 1 91 271
new 1 91 271
assign 1 96 283
def 1 96 288
assign 1 96 289
new 0 96 289
assign 1 96 290
equals 1 96 290
assign 1 0 292
assign 1 96 295
new 0 96 295
assign 1 96 296
ends 1 96 296
assign 1 0 298
assign 1 0 301
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 97 315
new 0 97 315
return 1 97 316
assign 1 99 318
new 0 99 318
return 1 99 319
assign 1 103 325
new 0 103 325
assign 1 103 326
new 0 103 326
assign 1 103 327
swap 2 103 327
return 1 103 328
assign 1 107 335
new 0 107 335
assign 1 107 336
argsGet 0 107 336
assign 1 108 337
new 0 108 337
assign 1 108 338
main 1 108 338
exit 1 108 339
assign 1 112 351
assign 1 113 352
new 1 113 352
assign 1 114 353
new 0 114 353
assign 1 114 354
new 0 114 354
assign 1 114 355
get 2 114 355
assign 1 114 356
firstGet 0 114 356
assign 1 114 357
new 1 114 357
assign 1 115 358
new 0 115 358
assign 1 115 361
lesser 1 115 366
assign 1 116 367
go 0 116 367
incrementValue 0 115 368
return 1 118 374
assign 1 122 382
new 0 122 382
config 0 123 383
assign 1 124 384
new 0 124 384
assign 1 126 386
new 0 126 386
assign 1 127 387
doWhat 0 127 387
assign 1 128 388
new 0 128 388
assign 1 130 392
toString 0 130 392
assign 1 131 393
new 0 131 393
assign 1 132 394
new 0 132 394
assign 1 132 395
add 1 132 395
assign 1 133 396
new 0 133 396
assign 1 0 399
assign 1 0 403
assign 1 0 406
print 0 136 410
return 1 138 412
assign 1 142 432
nameGet 0 142 432
assign 1 142 433
new 0 142 433
assign 1 142 434
equals 1 142 434
assign 1 143 436
new 0 143 436
assign 1 143 437
add 1 143 437
assign 1 143 438
add 1 143 438
assign 1 143 439
add 1 143 439
assign 1 144 440
new 0 144 440
assign 1 144 441
add 1 144 441
assign 1 144 442
add 1 144 442
assign 1 145 443
new 0 145 443
assign 1 145 444
add 1 145 444
assign 1 145 445
add 1 145 445
assign 1 146 446
new 0 146 446
assign 1 146 447
add 1 146 447
assign 1 146 448
add 1 146 448
assign 1 146 449
add 1 146 449
assign 1 147 450
new 0 147 450
assign 1 147 451
add 1 147 451
assign 1 147 452
add 1 147 452
assign 1 148 453
new 0 148 453
assign 1 148 454
add 1 148 454
assign 1 148 455
add 1 148 455
return 1 150 457
assign 1 155 593
new 0 155 593
assign 1 157 594
new 0 157 594
assign 1 158 595
get 1 158 595
assign 1 158 596
def 1 158 601
assign 1 159 602
get 1 159 602
assign 1 159 603
iteratorGet 0 0 603
assign 1 159 606
hasNextGet 0 159 606
assign 1 159 608
nextGet 0 159 608
assign 1 160 609
has 1 160 609
assign 1 160 610
not 0 160 615
put 1 161 616
assign 1 162 617
new 1 162 617
addFile 1 162 618
assign 1 167 626
new 0 167 626
assign 1 167 627
nameGet 0 167 627
assign 1 167 628
new 0 167 628
assign 1 167 629
equals 1 167 629
preProcessorSet 1 168 631
assign 1 170 633
new 0 170 633
assign 1 170 634
get 1 170 634
assign 1 170 635
firstGet 0 170 635
assign 1 171 636
new 0 171 636
assign 1 171 637
has 1 171 637
assign 1 172 639
new 0 172 639
assign 1 172 640
get 1 172 640
assign 1 172 641
firstGet 0 172 641
assign 1 174 644
assign 1 176 646
new 0 176 646
assign 1 176 647
new 0 176 647
assign 1 176 648
get 2 176 648
assign 1 176 649
firstGet 0 176 649
assign 1 176 650
new 1 176 650
assign 1 176 651
pathGet 0 176 651
addStep 1 177 652
assign 1 178 653
new 0 178 653
addStep 1 178 654
assign 1 179 655
new 0 179 655
assign 1 179 656
new 0 179 656
assign 1 179 657
get 2 179 657
assign 1 179 658
firstGet 0 179 658
assign 1 179 659
new 1 179 659
assign 1 179 660
pathGet 0 179 660
assign 1 180 661
new 0 180 661
assign 1 180 662
new 0 180 662
assign 1 180 663
nameGet 0 180 663
assign 1 180 664
get 2 180 664
assign 1 180 665
firstGet 0 180 665
assign 1 180 666
new 1 180 666
assign 1 181 667
new 0 181 667
assign 1 181 668
nameGet 0 181 668
assign 1 181 669
get 2 181 669
assign 1 181 670
firstGet 0 181 670
assign 1 181 671
new 1 181 671
assign 1 182 672
new 0 182 672
assign 1 182 673
new 0 182 673
assign 1 182 674
get 2 182 674
assign 1 182 675
firstGet 0 182 675
assign 1 182 676
new 1 182 676
assign 1 183 677
new 0 183 677
assign 1 183 678
new 0 183 678
assign 1 183 679
get 2 183 679
assign 1 183 680
firstGet 0 183 680
assign 1 183 681
new 1 183 681
assign 1 185 682
new 0 185 682
assign 1 185 683
get 1 185 683
assign 1 185 684
firstGet 0 185 684
assign 1 186 685
new 0 186 685
assign 1 186 686
get 1 186 686
assign 1 186 687
firstGet 0 186 687
assign 1 187 688
new 0 187 688
assign 1 187 689
get 1 187 689
assign 1 188 690
undef 1 188 695
assign 1 189 696
new 0 189 696
assign 1 191 698
new 0 191 698
assign 1 191 699
get 1 191 699
assign 1 192 700
undef 1 192 705
assign 1 193 706
new 0 193 706
assign 1 195 708
new 0 195 708
assign 1 195 709
get 1 195 709
assign 1 196 710
undef 1 196 715
assign 1 197 716
new 0 197 716
assign 1 199 718
new 0 199 718
assign 1 199 719
get 1 199 719
assign 1 200 720
undef 1 200 725
assign 1 201 726
new 0 201 726
assign 1 203 728
new 0 203 728
assign 1 203 729
get 1 203 729
assign 1 204 730
undef 1 204 735
assign 1 205 736
new 0 205 736
assign 1 207 738
new 0 207 738
assign 1 207 739
get 1 207 739
assign 1 208 740
undef 1 208 745
assign 1 209 746
new 0 209 746
assign 1 211 748
new 0 211 748
assign 1 211 749
get 1 211 749
assign 1 212 750
undef 1 212 755
assign 1 213 756
new 0 213 756
assign 1 215 758
new 0 215 758
assign 1 215 759
get 1 215 759
assign 1 216 760
undef 1 216 765
assign 1 217 766
new 0 217 766
assign 1 219 768
new 0 219 768
assign 1 219 769
get 1 219 769
assign 1 220 770
undef 1 220 775
assign 1 221 776
new 0 221 776
assign 1 223 778
new 0 223 778
assign 1 223 779
get 1 223 779
assign 1 224 780
def 1 224 785
assign 1 225 786
firstGet 0 225 786
assign 1 227 788
new 0 227 788
assign 1 227 789
get 1 227 789
assign 1 228 790
def 1 228 795
assign 1 229 796
firstGet 0 229 796
assign 1 231 799
new 0 231 799
assign 1 233 801
new 0 233 801
assign 1 233 802
new 0 233 802
assign 1 233 803
isTrue 2 233 803
assign 1 234 804
new 0 234 804
assign 1 234 805
new 0 234 805
assign 1 234 806
isTrue 2 234 806
assign 1 235 807
new 0 235 807
assign 1 235 808
isTrue 1 235 808
assign 1 236 809
new 0 236 809
assign 1 236 810
isTrue 1 236 810
assign 1 237 811
new 0 237 811
assign 1 238 812
new 0 238 812
assign 1 238 813
get 1 238 813
assign 1 239 814
def 1 239 819
assign 1 239 820
isEmptyGet 0 239 820
assign 1 239 821
not 0 239 826
assign 1 0 827
assign 1 0 830
assign 1 0 834
assign 1 240 837
linkedListIteratorGet 0 0 837
assign 1 240 840
hasNextGet 0 240 840
assign 1 240 842
nextGet 0 240 842
put 1 241 843
assign 1 244 850
new 0 244 850
assign 1 244 851
isTrue 1 244 851
assign 1 245 852
new 0 245 852
assign 1 245 853
isTrue 1 245 853
assign 1 246 854
new 0 246 854
assign 1 246 855
isTrue 1 246 855
assign 1 247 856
new 0 247 856
assign 1 247 857
new 0 247 857
assign 1 247 858
isTrue 2 247 858
assign 1 248 859
new 0 248 859
assign 1 248 860
get 1 248 860
assign 1 249 861
new 0 249 861
assign 1 249 862
get 1 249 862
assign 1 250 863
new 0 250 863
assign 1 250 864
new 0 250 864
assign 1 250 865
get 2 250 865
assign 1 250 866
firstGet 0 250 866
assign 1 251 867
new 0 251 867
assign 1 251 868
new 0 251 868
assign 1 251 869
get 2 251 869
assign 1 251 870
firstGet 0 251 870
assign 1 252 871
new 0 252 871
assign 1 252 872
add 1 252 872
assign 1 252 873
new 0 252 873
assign 1 252 874
get 2 252 874
assign 1 252 875
firstGet 0 252 875
assign 1 253 876
new 0 253 876
assign 1 254 877
new 0 254 877
assign 1 255 878
new 0 255 878
assign 1 256 879
new 0 256 879
assign 1 257 880
new 0 257 880
assign 1 260 881
def 1 260 886
assign 1 261 887
firstGet 0 261 887
assign 1 263 890
new 0 263 890
assign 1 270 892
new 0 270 892
assign 1 270 893
add 1 270 893
assign 1 270 894
nameGet 0 270 894
assign 1 270 895
add 1 270 895
assign 1 270 896
get 1 270 896
assign 1 271 897
def 1 271 902
assign 1 272 903
orderedGet 0 272 903
addAll 1 272 904
assign 1 275 906
new 0 275 906
assign 1 275 907
add 1 275 907
assign 1 275 908
get 1 275 908
assign 1 276 909
def 1 276 914
assign 1 277 915
orderedGet 0 277 915
addAll 1 277 916
assign 1 280 918
new 0 280 918
assign 1 281 919
orderedGet 0 281 919
assign 1 281 920
iteratorGet 0 0 920
assign 1 281 923
hasNextGet 0 281 923
assign 1 281 925
nextGet 0 281 925
assign 1 282 926
new 1 282 926
addValue 1 282 927
assign 1 284 933
newlineGet 0 284 933
assign 1 285 934
assign 1 286 935
new 1 286 935
assign 1 288 936
copy 0 288 936
assign 1 289 937
fileGet 0 289 937
assign 1 289 938
existsGet 0 289 938
assign 1 289 939
not 0 289 944
assign 1 290 945
fileGet 0 290 945
makeDirs 0 290 946
assign 1 292 948
def 1 292 953
assign 1 293 954
new 1 293 954
assign 1 293 955
readerGet 0 293 955
assign 1 294 956
open 0 294 956
assign 1 294 957
readString 0 294 957
close 0 295 958
assign 1 301 972
classNameGet 0 301 972
assign 1 302 973
add 1 302 973
assign 1 302 974
new 0 302 974
assign 1 302 975
add 1 302 975
assign 1 302 976
toString 0 302 976
assign 1 302 977
add 1 302 977
assign 1 303 978
add 1 303 978
assign 1 303 979
new 0 303 979
assign 1 303 980
add 1 303 980
assign 1 303 981
toString 0 303 981
assign 1 303 982
add 1 303 982
return 1 304 983
assign 1 308 1023
new 0 308 1023
assign 1 309 1024
classesGet 0 309 1024
assign 1 309 1025
valueIteratorGet 0 309 1025
assign 1 309 1028
hasNextGet 0 309 1028
assign 1 310 1030
nextGet 0 310 1030
assign 1 311 1031
shouldEmitGet 0 311 1031
assign 1 311 1032
heldGet 0 311 1032
assign 1 311 1033
fromFileGet 0 311 1033
assign 1 311 1034
has 1 311 1034
assign 1 312 1036
heldGet 0 312 1036
assign 1 312 1037
namepathGet 0 312 1037
assign 1 312 1038
toString 0 312 1038
put 1 312 1039
assign 1 313 1040
usedByGet 0 313 1040
assign 1 313 1041
heldGet 0 313 1041
assign 1 313 1042
namepathGet 0 313 1042
assign 1 313 1043
toString 0 313 1043
assign 1 313 1044
get 1 313 1044
assign 1 314 1045
def 1 314 1050
assign 1 315 1051
setIteratorGet 0 0 1051
assign 1 315 1054
hasNextGet 0 315 1054
assign 1 315 1056
nextGet 0 315 1056
put 1 316 1057
assign 1 319 1064
subClassesGet 0 319 1064
assign 1 319 1065
heldGet 0 319 1065
assign 1 319 1066
namepathGet 0 319 1066
assign 1 319 1067
toString 0 319 1067
assign 1 319 1068
get 1 319 1068
assign 1 320 1069
def 1 320 1074
assign 1 321 1075
setIteratorGet 0 0 1075
assign 1 321 1078
hasNextGet 0 321 1078
assign 1 321 1080
nextGet 0 321 1080
put 1 322 1081
assign 1 327 1094
classesGet 0 327 1094
assign 1 327 1095
valueIteratorGet 0 327 1095
assign 1 327 1098
hasNextGet 0 327 1098
assign 1 328 1100
nextGet 0 328 1100
assign 1 329 1101
heldGet 0 329 1101
assign 1 329 1102
heldGet 0 329 1102
assign 1 329 1103
namepathGet 0 329 1103
assign 1 329 1104
toString 0 329 1104
assign 1 329 1105
has 1 329 1105
shouldWriteSet 1 329 1106
assign 1 336 1116
new 0 336 1116
return 1 336 1117
assign 1 340 1131
def 1 340 1136
return 1 341 1137
assign 1 346 1139
def 1 346 1144
assign 1 347 1145
firstGet 0 347 1145
assign 1 348 1146
new 0 348 1146
assign 1 348 1147
equals 1 348 1147
assign 1 349 1149
new 1 349 1149
assign 1 350 1152
new 0 350 1152
assign 1 350 1153
equals 1 350 1153
assign 1 351 1155
new 1 351 1155
assign 1 352 1158
new 0 352 1158
assign 1 352 1159
equals 1 352 1159
assign 1 353 1161
new 1 353 1161
assign 1 355 1164
new 0 355 1164
assign 1 355 1165
new 1 355 1165
throw 1 355 1166
dynConditionsAllSet 1 357 1170
return 1 358 1171
return 1 360 1173
assign 1 365 1285
new 0 365 1285
assign 1 365 1286
now 0 365 1286
assign 1 366 1287
new 0 366 1287
assign 1 367 1288
emitterGet 0 367 1288
assign 1 368 1289
def 1 368 1294
assign 1 369 1295
new 4 369 1295
put 1 370 1296
assign 1 372 1298
new 0 372 1298
assign 1 372 1299
add 1 372 1299
print 0 372 1300
assign 1 375 1303
new 0 375 1303
assign 1 377 1304
iteratorGet 0 0 1304
assign 1 377 1307
hasNextGet 0 377 1307
assign 1 377 1309
nextGet 0 377 1309
assign 1 378 1310
has 1 378 1310
assign 1 378 1311
not 0 378 1316
put 1 379 1317
assign 1 380 1318
new 2 380 1318
addValue 1 381 1319
assign 1 384 1326
iteratorGet 0 0 1326
assign 1 384 1329
hasNextGet 0 384 1329
assign 1 384 1331
nextGet 0 384 1331
assign 1 385 1332
has 1 385 1332
assign 1 385 1333
not 0 385 1338
put 1 386 1339
assign 1 387 1340
new 2 387 1340
addValue 1 388 1341
assign 1 389 1342
libNameGet 0 389 1342
put 1 389 1343
assign 1 394 1351
iteratorGet 0 394 1351
assign 1 394 1354
hasNextGet 0 394 1354
assign 1 395 1356
nextGet 0 395 1356
doParse 1 397 1357
buildSyns 1 399 1363
assign 1 402 1365
new 0 402 1365
assign 1 402 1366
now 0 402 1366
assign 1 402 1367
subtract 1 402 1367
assign 1 404 1368
new 0 404 1368
assign 1 404 1369
add 1 404 1369
print 0 404 1370
assign 1 406 1371
emitCommonGet 0 406 1371
assign 1 406 1372
def 1 406 1377
assign 1 408 1378
new 0 408 1378
assign 1 408 1379
now 0 408 1379
assign 1 409 1380
emitCommonGet 0 409 1380
doEmit 0 409 1381
assign 1 410 1382
new 0 410 1382
assign 1 410 1383
now 0 410 1383
assign 1 410 1384
subtract 1 410 1384
assign 1 411 1385
new 0 411 1385
assign 1 411 1386
add 1 411 1386
print 0 411 1387
assign 1 412 1388
new 0 412 1388
assign 1 412 1389
now 0 412 1389
assign 1 412 1390
subtract 1 412 1390
assign 1 413 1391
new 0 413 1391
assign 1 413 1392
add 1 413 1392
print 0 413 1393
assign 1 414 1394
new 0 414 1394
return 1 414 1395
setClassesToWrite 0 417 1398
libnameInfoGet 0 418 1399
assign 1 420 1400
classesGet 0 420 1400
assign 1 420 1401
valueIteratorGet 0 420 1401
assign 1 420 1404
hasNextGet 0 420 1404
assign 1 421 1406
nextGet 0 421 1406
doEmit 1 422 1407
emitMain 0 424 1413
emitCUInit 0 425 1414
assign 1 426 1415
classesGet 0 426 1415
assign 1 426 1416
valueIteratorGet 0 426 1416
assign 1 426 1419
hasNextGet 0 426 1419
assign 1 427 1421
nextGet 0 427 1421
emitSyn 1 428 1422
assign 1 432 1429
new 0 432 1429
assign 1 432 1430
now 0 432 1430
assign 1 432 1431
subtract 1 432 1431
assign 1 433 1432
def 1 433 1437
assign 1 434 1438
new 0 434 1438
assign 1 434 1439
add 1 434 1439
print 0 434 1440
assign 1 436 1442
new 0 436 1442
assign 1 436 1443
add 1 436 1443
print 0 436 1444
prepMake 1 439 1446
assign 1 443 1449
not 0 443 1454
make 1 444 1455
deployLibrary 1 445 1456
assign 1 447 1458
linkedListIteratorGet 0 0 1458
assign 1 447 1461
hasNextGet 0 447 1461
assign 1 447 1463
nextGet 0 447 1463
assign 1 448 1464
libnameInfoGet 0 448 1464
assign 1 448 1465
unitShlibGet 0 448 1465
assign 1 449 1466
emitPathGet 0 449 1466
assign 1 449 1467
copy 0 449 1467
assign 1 450 1468
stepsGet 0 450 1468
assign 1 450 1469
lastGet 0 450 1469
addStep 1 450 1470
assign 1 451 1471
fileGet 0 451 1471
assign 1 451 1472
existsGet 0 451 1472
assign 1 452 1474
fileGet 0 452 1474
delete 0 452 1475
assign 1 454 1477
fileGet 0 454 1477
assign 1 454 1478
existsGet 0 454 1478
assign 1 454 1479
not 0 454 1479
assign 1 455 1481
fileGet 0 455 1481
assign 1 455 1482
fileGet 0 455 1482
deployFile 2 455 1483
assign 1 459 1491
iteratorGet 0 459 1491
assign 1 460 1492
iteratorGet 0 460 1492
assign 1 462 1495
hasNextGet 0 462 1495
assign 1 462 1497
hasNextGet 0 462 1497
assign 1 0 1499
assign 1 0 1502
assign 1 0 1506
assign 1 463 1509
nextGet 0 463 1509
assign 1 463 1510
apNew 1 463 1510
assign 1 464 1511
emitPathGet 0 464 1511
assign 1 464 1512
copy 0 464 1512
assign 1 464 1513
toString 0 464 1513
assign 1 464 1514
new 0 464 1514
assign 1 464 1515
add 1 464 1515
assign 1 464 1516
nextGet 0 464 1516
assign 1 464 1517
add 1 464 1517
assign 1 464 1518
apNew 1 464 1518
assign 1 466 1519
fileGet 0 466 1519
assign 1 466 1520
existsGet 0 466 1520
assign 1 467 1522
fileGet 0 467 1522
delete 0 467 1523
assign 1 469 1525
fileGet 0 469 1525
assign 1 469 1526
existsGet 0 469 1526
assign 1 469 1527
not 0 469 1527
assign 1 470 1529
fileGet 0 470 1529
assign 1 470 1530
fileGet 0 470 1530
deployFile 2 470 1531
assign 1 475 1540
new 0 475 1540
assign 1 475 1541
now 0 475 1541
assign 1 475 1542
subtract 1 475 1542
assign 1 477 1543
def 1 477 1548
assign 1 478 1549
new 0 478 1549
assign 1 478 1550
add 1 478 1550
print 0 478 1551
assign 1 480 1553
def 1 480 1558
assign 1 481 1559
new 0 481 1559
assign 1 481 1560
add 1 481 1560
print 0 481 1561
assign 1 483 1563
def 1 483 1568
assign 1 484 1569
new 0 484 1569
assign 1 484 1570
add 1 484 1570
print 0 484 1571
assign 1 488 1574
new 0 488 1574
print 0 488 1575
assign 1 489 1576
run 2 489 1576
assign 1 490 1577
new 0 490 1577
assign 1 490 1578
add 1 490 1578
assign 1 490 1579
new 0 490 1579
assign 1 490 1580
add 1 490 1580
print 0 490 1581
return 1 491 1582
assign 1 493 1584
new 0 493 1584
return 1 493 1585
assign 1 497 1598
justParsedGet 0 497 1598
assign 1 497 1599
valueIteratorGet 0 497 1599
assign 1 497 1602
hasNextGet 0 497 1602
assign 1 498 1604
nextGet 0 498 1604
assign 1 499 1605
heldGet 0 499 1605
libNameSet 1 499 1606
assign 1 500 1607
getSyn 2 500 1607
libNameSet 1 501 1608
assign 1 503 1614
justParsedGet 0 503 1614
assign 1 503 1615
valueIteratorGet 0 503 1615
assign 1 503 1618
hasNextGet 0 503 1618
assign 1 504 1620
nextGet 0 504 1620
assign 1 505 1621
heldGet 0 505 1621
assign 1 505 1622
synGet 0 505 1622
checkInheritance 2 506 1623
integrate 1 507 1624
assign 1 509 1630
new 0 509 1630
justParsedSet 1 509 1631
assign 1 513 1659
heldGet 0 513 1659
assign 1 513 1660
synGet 0 513 1660
assign 1 513 1661
def 1 513 1666
assign 1 514 1667
heldGet 0 514 1667
assign 1 514 1668
synGet 0 514 1668
return 1 514 1669
assign 1 516 1671
heldGet 0 516 1671
libNameSet 1 516 1672
assign 1 517 1673
heldGet 0 517 1673
assign 1 517 1674
extendsGet 0 517 1674
assign 1 517 1675
undef 1 517 1680
assign 1 518 1681
new 1 518 1681
assign 1 520 1684
classesGet 0 520 1684
assign 1 520 1685
heldGet 0 520 1685
assign 1 520 1686
extendsGet 0 520 1686
assign 1 520 1687
toString 0 520 1687
assign 1 520 1688
get 1 520 1688
assign 1 522 1689
def 1 522 1694
assign 1 523 1695
heldGet 0 523 1695
libNameSet 1 523 1696
assign 1 524 1697
getSyn 2 524 1697
assign 1 527 1700
heldGet 0 527 1700
assign 1 527 1701
extendsGet 0 527 1701
assign 1 527 1702
loadSyn 1 527 1702
assign 1 529 1704
new 2 529 1704
assign 1 531 1706
heldGet 0 531 1706
synSet 1 531 1707
assign 1 532 1708
heldGet 0 532 1708
assign 1 532 1709
namepathGet 0 532 1709
assign 1 532 1710
toString 0 532 1710
addSynClass 2 532 1711
return 1 533 1712
assign 1 537 1720
toString 0 537 1720
assign 1 538 1721
synClassesGet 0 538 1721
assign 1 538 1722
get 1 538 1722
assign 1 539 1723
def 1 539 1728
return 1 540 1729
assign 1 546 1731
emitterGet 0 546 1731
assign 1 546 1732
loadSyn 1 546 1732
addSynClass 2 547 1733
return 1 548 1734
assign 1 555 1738
undef 1 555 1743
assign 1 556 1744
new 1 556 1744
return 1 558 1746
assign 1 563 1825
new 1 563 1825
assign 1 564 1826
new 0 564 1826
assign 1 565 1827
emitterGet 0 565 1827
assign 1 566 1828
assign 1 567 1829
new 0 567 1829
assign 1 568 1830
shouldEmitGet 0 568 1830
put 1 568 1831
assign 1 0 1834
assign 1 0 1838
assign 1 0 1841
assign 1 571 1845
new 0 571 1845
assign 1 571 1846
toString 0 571 1846
assign 1 571 1847
add 1 571 1847
print 0 571 1848
assign 1 573 1850
assign 1 575 1851
fileGet 0 575 1851
assign 1 575 1852
readerGet 0 575 1852
assign 1 575 1853
open 0 575 1853
assign 1 575 1854
readBuffer 1 575 1854
assign 1 576 1855
fileGet 0 576 1855
assign 1 576 1856
readerGet 0 576 1856
close 0 576 1857
assign 1 577 1858
tokenize 1 577 1858
assign 1 581 1860
new 0 581 1860
echo 0 581 1861
assign 1 583 1863
outermostGet 0 583 1863
nodify 2 583 1864
assign 1 585 1866
new 0 585 1866
print 0 585 1867
assign 1 586 1868
new 2 586 1868
traverse 1 586 1869
assign 1 590 1872
new 0 590 1872
echo 0 590 1873
assign 1 592 1875
new 0 592 1875
traverse 1 592 1876
assign 1 594 1878
new 0 594 1878
print 0 594 1879
assign 1 595 1880
new 2 595 1880
traverse 1 595 1881
assign 1 598 1884
new 0 598 1884
echo 0 598 1885
assign 1 601 1887
new 0 601 1887
traverse 1 601 1888
contain 0 602 1889
assign 1 604 1891
new 0 604 1891
print 0 604 1892
assign 1 605 1893
new 2 605 1893
traverse 1 605 1894
assign 1 609 1897
new 0 609 1897
echo 0 609 1898
assign 1 611 1900
new 0 611 1900
traverse 1 611 1901
assign 1 613 1903
new 0 613 1903
print 0 613 1904
assign 1 614 1905
new 2 614 1905
traverse 1 614 1906
assign 1 618 1909
new 0 618 1909
echo 0 618 1910
assign 1 620 1912
new 0 620 1912
traverse 1 620 1913
assign 1 622 1915
new 0 622 1915
print 0 622 1916
assign 1 623 1917
new 2 623 1917
traverse 1 623 1918
assign 1 627 1921
new 0 627 1921
echo 0 627 1922
assign 1 629 1924
new 0 629 1924
traverse 1 629 1925
assign 1 631 1927
new 0 631 1927
print 0 631 1928
assign 1 632 1929
new 2 632 1929
traverse 1 632 1930
assign 1 636 1933
new 0 636 1933
echo 0 636 1934
assign 1 638 1936
new 0 638 1936
traverse 1 638 1937
assign 1 640 1939
new 0 640 1939
print 0 640 1940
assign 1 641 1941
new 2 641 1941
traverse 1 641 1942
assign 1 645 1945
new 0 645 1945
echo 0 645 1946
assign 1 647 1948
new 0 647 1948
traverse 1 647 1949
assign 1 649 1951
new 0 649 1951
print 0 649 1952
assign 1 650 1953
new 2 650 1953
traverse 1 650 1954
assign 1 654 1957
new 0 654 1957
echo 0 654 1958
assign 1 656 1960
new 0 656 1960
traverse 1 656 1961
assign 1 658 1963
new 0 658 1963
print 0 658 1964
assign 1 659 1965
new 2 659 1965
traverse 1 659 1966
assign 1 663 1969
new 0 663 1969
echo 0 663 1970
assign 1 665 1972
new 0 665 1972
traverse 1 665 1973
assign 1 667 1975
new 0 667 1975
print 0 667 1976
assign 1 668 1977
new 2 668 1977
traverse 1 668 1978
assign 1 671 1981
new 0 671 1981
echo 0 671 1982
assign 1 673 1984
new 0 673 1984
traverse 1 673 1985
assign 1 675 1987
new 0 675 1987
print 0 675 1988
assign 1 676 1989
new 2 676 1989
traverse 1 676 1990
assign 1 680 1993
new 0 680 1993
echo 0 680 1994
assign 1 681 1995
new 0 681 1995
print 0 681 1996
assign 1 683 1998
new 0 683 1998
traverse 1 683 1999
assign 1 0 2001
assign 1 0 2005
assign 1 0 2008
assign 1 685 2012
new 0 685 2012
print 0 685 2013
assign 1 686 2014
new 2 686 2014
traverse 1 686 2015
assign 1 688 2017
classesGet 0 688 2017
assign 1 688 2018
valueIteratorGet 0 688 2018
assign 1 688 2021
hasNextGet 0 688 2021
assign 1 689 2023
nextGet 0 689 2023
assign 1 691 2024
transUnitGet 0 691 2024
assign 1 692 2025
new 1 692 2025
assign 1 693 2026
TRANSUNITGet 0 693 2026
typenameSet 1 693 2027
assign 1 694 2028
new 0 694 2028
assign 1 695 2029
heldGet 0 695 2029
assign 1 695 2030
emitsGet 0 695 2030
emitsSet 1 695 2031
heldSet 1 696 2032
delete 0 697 2033
addValue 1 698 2034
copyLoc 1 699 2035
reInitContained 0 705 2057
assign 1 706 2058
containedGet 0 706 2058
assign 1 707 2059
new 0 707 2059
assign 1 708 2060
new 0 708 2060
assign 1 708 2061
crGet 0 708 2061
assign 1 709 2062
linkedListIteratorGet 0 709 2062
assign 1 709 2065
hasNextGet 0 709 2065
assign 1 710 2067
new 1 710 2067
assign 1 711 2068
nextGet 0 711 2068
heldSet 1 711 2069
nlcSet 1 712 2070
assign 1 713 2071
heldGet 0 713 2071
assign 1 713 2072
equals 1 713 2072
assign 1 714 2074
increment 0 714 2074
assign 1 716 2076
heldGet 0 716 2076
assign 1 716 2077
notEquals 1 716 2077
addValue 1 717 2079
containerSet 1 718 2080
return 1 0 2090
assign 1 0 2093
return 1 0 2097
assign 1 0 2100
return 1 0 2104
assign 1 0 2107
return 1 0 2111
assign 1 0 2114
return 1 0 2118
assign 1 0 2121
return 1 0 2125
assign 1 0 2128
return 1 0 2132
assign 1 0 2135
return 1 0 2139
assign 1 0 2142
return 1 0 2146
assign 1 0 2149
return 1 0 2153
assign 1 0 2156
return 1 0 2160
assign 1 0 2163
return 1 0 2167
assign 1 0 2170
return 1 0 2174
assign 1 0 2177
return 1 0 2181
assign 1 0 2184
return 1 0 2188
assign 1 0 2191
return 1 0 2195
assign 1 0 2198
return 1 0 2202
assign 1 0 2205
return 1 0 2209
assign 1 0 2212
return 1 0 2216
assign 1 0 2219
return 1 0 2223
assign 1 0 2226
return 1 0 2230
assign 1 0 2233
return 1 0 2237
assign 1 0 2240
return 1 0 2244
assign 1 0 2247
return 1 0 2251
assign 1 0 2254
return 1 0 2258
assign 1 0 2261
return 1 0 2265
assign 1 0 2268
return 1 0 2272
assign 1 0 2275
return 1 0 2279
assign 1 0 2282
return 1 0 2286
assign 1 0 2289
return 1 0 2293
assign 1 0 2296
return 1 0 2300
assign 1 0 2303
return 1 0 2307
assign 1 0 2310
return 1 0 2314
assign 1 0 2317
return 1 0 2321
assign 1 0 2324
return 1 0 2328
assign 1 0 2331
return 1 0 2335
assign 1 0 2338
return 1 0 2342
assign 1 0 2345
return 1 0 2349
assign 1 0 2352
return 1 0 2356
assign 1 0 2359
return 1 0 2363
assign 1 0 2366
return 1 0 2370
assign 1 0 2373
return 1 0 2377
assign 1 0 2380
return 1 0 2384
assign 1 0 2387
return 1 0 2391
assign 1 0 2394
return 1 0 2398
assign 1 0 2401
return 1 0 2405
assign 1 0 2408
return 1 0 2412
assign 1 0 2415
return 1 0 2419
assign 1 0 2422
return 1 0 2426
assign 1 0 2429
return 1 0 2433
assign 1 0 2436
return 1 0 2440
assign 1 0 2443
return 1 0 2447
assign 1 0 2450
return 1 0 2454
assign 1 0 2457
return 1 0 2461
assign 1 0 2464
return 1 0 2468
assign 1 0 2471
return 1 0 2475
assign 1 0 2478
return 1 0 2482
assign 1 0 2485
return 1 0 2489
assign 1 0 2492
return 1 0 2496
assign 1 0 2499
return 1 0 2503
assign 1 0 2506
return 1 0 2510
assign 1 0 2513
return 1 0 2517
assign 1 0 2520
return 1 0 2524
assign 1 0 2527
return 1 0 2531
assign 1 0 2534
return 1 0 2538
assign 1 0 2541
return 1 0 2545
assign 1 0 2548
return 1 0 2552
assign 1 0 2555
return 1 0 2559
assign 1 0 2562
assign 1 0 2566
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1308786538: return bem_echo_0();
case -404051026: return bem_printPlacesGet_0();
case -729571811: return bem_serializeToString_0();
case -2113443821: return bem_deployLibraryGet_0();
case -34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case -340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case -580139405: return bem_config_0();
case -2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case -1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case -1803479881: return bem_libNameGet_0();
case -314718434: return bem_print_0();
case -2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case -186098742: return bem_exeNameGet_0();
case -1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case -829911139: return bem_compilerProfileGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case -658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case -2082855574: return bem_emitDataGet_0();
case -786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case -2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case -271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case -2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case -1919619119: return bem_setClassesToWrite_0();
case -2127864150: return bem_argsGet_0();
case -400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case -1003238764: return bem_parseGet_0();
case -902949587: return bem_printStepsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case -1505775346: return bem_putLineNumbersInTraceGet_0();
case -1713520961: return bem_linkLibArgsGet_0();
case -1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case -644675716: return bem_ntypesGet_0();
case -1185503219: return bem_deployFilesFromGet_0();
case -1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case -1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case -560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case -733055122: return bem_makeNameGet_0();
case -328200718: return bem_printAstGet_0();
case -126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case -1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case -1458327669: return bem_emitFileHeaderGet_0();
case -1220511308: return bem_buildSucceededGet_0();
case -845792839: return bem_iteratorGet_0();
case -1149621350: return bem_codeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -505952126: return bem_copyTo_1(bevd_0);
case -392968773: return bem_printPlacesSet_1(bevd_0);
case -2071773321: return bem_emitDataSet_1(bevd_0);
case -1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case -1702438708: return bem_linkLibArgsSet_1(bevd_0);
case -891867334: return bem_printStepsSet_1(bevd_0);
case -647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -721972869: return bem_makeNameSet_1(bevd_0);
case -175016489: return bem_exeNameSet_1(bevd_0);
case -972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case -2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case -115429536: return bem_outputPlatformSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case -818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case -1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case -706249818: return bem_getSynNp_1(bevd_0);
case -1310359934: return bem_emitLangsSet_1(bevd_0);
case -329197947: return bem_startTimeSet_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case -1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case -1174420966: return bem_deployFilesFromSet_1(bevd_0);
case -389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case -2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case -1138539097: return bem_codeSet_1(bevd_0);
case -23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -2036609109: return bem_buildSyns_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case -992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case -1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case -260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case -1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1081571541: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case -2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bevs_inst = (BEC_2_5_5_BuildBuild)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bevs_inst;
}
}
