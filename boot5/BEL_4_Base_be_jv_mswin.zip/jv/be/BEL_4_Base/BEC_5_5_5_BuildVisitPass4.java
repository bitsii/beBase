package be.BEL_4_Base;
/* IO:File: source/build/Pass4.be */
public class BEC_5_5_5_BuildVisitPass4 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass4() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static BEC_5_5_5_BuildVisitPass4 bevs_inst;
public BEC_6_6_SystemObject bem_begin_1(BEC_6_6_SystemObject beva_transi) throws Throwable {
super.bem_begin_1(beva_transi);
return this;
} /*method end*/
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_5_4_BuildNode bevl_nnode = null;
BEC_4_6_TextString bevl_nps = null;
BEC_5_4_BuildNode bevl_nxn = null;
BEC_5_4_BuildNode bevl_nxnn = null;
BEC_5_4_BuildNode bevl_first = null;
BEC_5_8_BuildNamePath bevl_np = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_29_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_30_tmpvar_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 26 */ {
bevt_5_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_equals_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 26 */ {
if (bevl_nnode == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 26 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 26 */
 else  /* Line: 26 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 26 */ {
bevt_9_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_COLONGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 26 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 26 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 26 */
 else  /* Line: 26 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 26 */ {
if (bevl_nps == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevl_nps = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 28 */
bevt_13_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_12_tmpvar_phold = bevl_nps.bem_add_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 32 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_17_tmpvar_phold = bevl_nxn.bem_typenameGet_0();
bevt_18_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_notEquals_1(bevt_18_tmpvar_phold);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 32 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 32 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 32 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 32 */ {
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(19, bels_0));
bevt_19_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_20_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_19_tmpvar_phold);
} /* Line: 33 */
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 36 */ {
beva_node.bem_delete_0();
} /* Line: 37 */
 else  /* Line: 38 */ {
bevl_first = beva_node;
} /* Line: 39 */
bevl_nnode.bem_delete_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 43 */
 else  /* Line: 26 */ {
break;
} /* Line: 26 */
} /* Line: 26 */
if (bevl_first == null) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 45 */ {
bevt_23_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_tmpvar_phold);
bevl_np = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_26_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_equals_1(bevt_27_tmpvar_phold);
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 48 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 48 */ {
bevt_28_tmpvar_phold = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_tmpvar_phold);
beva_node.bem_delete_0();
} /* Line: 50 */
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_tmpvar_phold = bevl_first.bem_nextDescendGet_0();
return bevt_29_tmpvar_phold;
} /* Line: 54 */
bevt_30_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 25, 26, 26, 26, 26, 26, 0, 0, 0, 26, 26, 26, 0, 0, 0, 27, 27, 28, 30, 30, 30, 30, 31, 32, 32, 0, 32, 32, 32, 0, 0, 33, 33, 33, 35, 36, 36, 37, 39, 41, 42, 43, 45, 45, 46, 46, 47, 48, 48, 48, 48, 48, 0, 0, 0, 49, 49, 50, 52, 53, 54, 54, 56, 56};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {10, 51, 54, 55, 56, 58, 63, 64, 67, 71, 74, 75, 76, 78, 81, 85, 88, 93, 94, 96, 97, 98, 99, 100, 101, 106, 107, 110, 111, 112, 114, 117, 121, 122, 123, 125, 126, 131, 132, 135, 137, 138, 139, 145, 150, 151, 152, 153, 154, 159, 160, 161, 162, 164, 167, 171, 174, 175, 176, 178, 179, 180, 181, 183, 184};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
begin 1 21 10
assign 1 25 51
nextPeerGet 0 25 51
assign 1 26 54
typenameGet 0 26 54
assign 1 26 55
IDGet 0 26 55
assign 1 26 56
equals 1 26 56
assign 1 26 58
def 1 26 63
assign 1 0 64
assign 1 0 67
assign 1 0 71
assign 1 26 74
typenameGet 0 26 74
assign 1 26 75
COLONGet 0 26 75
assign 1 26 76
equals 1 26 76
assign 1 0 78
assign 1 0 81
assign 1 0 85
assign 1 27 88
undef 1 27 93
assign 1 28 94
new 0 28 94
assign 1 30 96
heldGet 0 30 96
assign 1 30 97
add 1 30 97
assign 1 30 98
heldGet 0 30 98
assign 1 30 99
add 1 30 99
assign 1 31 100
nextPeerGet 0 31 100
assign 1 32 101
undef 1 32 106
assign 1 0 107
assign 1 32 110
typenameGet 0 32 110
assign 1 32 111
IDGet 0 32 111
assign 1 32 112
notEquals 1 32 112
assign 1 0 114
assign 1 0 117
assign 1 33 121
new 0 33 121
assign 1 33 122
new 2 33 122
throw 1 33 123
assign 1 35 125
nextPeerGet 0 35 125
assign 1 36 126
def 1 36 131
delete 0 37 132
assign 1 39 135
delete 0 41 137
assign 1 42 138
assign 1 43 139
assign 1 45 145
def 1 45 150
assign 1 46 151
NAMEPATHGet 0 46 151
typenameSet 1 46 152
assign 1 47 153
new 0 47 153
assign 1 48 154
def 1 48 159
assign 1 48 160
typenameGet 0 48 160
assign 1 48 161
IDGet 0 48 161
assign 1 48 162
equals 1 48 162
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 49 174
heldGet 0 49 174
assign 1 49 175
add 1 49 175
delete 0 50 176
fromString 1 52 178
heldSet 1 53 179
assign 1 54 180
nextDescendGet 0 54 180
return 1 54 181
assign 1 56 183
nextDescendGet 0 56 183
return 1 56 184
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass4();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass4.bevs_inst = (BEC_5_5_5_BuildVisitPass4)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass4.bevs_inst;
}
}
