package be.BEL_4_Base;
/* File: source/base/Object.be */
public class BEC_6_6_SystemObject extends be.BELS_Base.BECS_Object {
public BEC_6_6_SystemObject() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x69,0x6E,0x20,0x61,0x20,0x63,0x6F,0x6E,0x74,0x65,0x78,0x74,0x20,0x77,0x68,0x65,0x72,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x20,0x77,0x65,0x72,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x76,0x61,0x69,0x6C,0x61,0x62,0x6C,0x65,0x20,0x66,0x72,0x6F,0x6D,0x20,0x74,0x68,0x65,0x20,0x73,0x74,0x61,0x63,0x6B};
private static byte[] bels_1 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64};
private static byte[] bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_2, 8));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_3, 23));
private static byte[] bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_5, 16));
private static byte[] bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x41,0x72,0x72,0x61,0x79,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x5F};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_8, 1));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(7));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(7));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(7));
private static byte[] bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_11 = {0x5F};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_11, 1));
public static BEC_6_6_SystemObject bevs_inst;
public BEC_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_undefined_1(BEC_6_6_SystemObject beva_ref) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_defined_1(BEC_6_6_SystemObject beva_ref) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_undef_1(BEC_6_6_SystemObject beva_ref) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_def_1(BEC_6_6_SystemObject beva_ref) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_methodNotDefined_0() throws Throwable {
BEC_6_11_SystemForwardCall bevl_forwardCall = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_forwardCall = (new BEC_6_11_SystemForwardCall()).bem_new_0();
bevt_0_tmpvar_phold = bevl_forwardCall.bem_notReadyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 79 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(86, bels_0));
bevt_1_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 80 */
bevt_3_tmpvar_phold = this.bem_methodNotDefined_1(bevl_forwardCall);
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_methodNotDefined_1(BEC_6_11_SystemForwardCall beva_forwardCall) throws Throwable {
BEC_6_6_SystemObject bevl_s = null;
BEC_6_6_SystemObject bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_16_SystemMethodNotDefined bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(7, bels_1));
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = this.bem_can_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 86 */ {
bevl_s = this;
bevl_result = bevl_s.bemd_1(2097807671, BEL_4_Base.bevn_forward_1, beva_forwardCall);
return bevl_result;
} /* Line: 90 */
 else  /* Line: 86 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevt_8_tmpvar_phold = bevo_0;
bevt_9_tmpvar_phold = beva_forwardCall.bem_nameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_1;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = this.bem_classNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_6_16_SystemMethodNotDefined) (new BEC_6_16_SystemMethodNotDefined()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 92 */
} /* Line: 86 */
return bevl_result;
} /*method end*/
public BEC_6_6_SystemObject bem_createInstance_1(BEC_4_6_TextString beva_cname) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_phold = this.bem_createInstance_2(beva_cname, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_createInstance_2(BEC_4_6_TextString beva_cname, BEC_5_4_LogicBool beva_throwOnFail) throws Throwable {
BEC_6_6_SystemObject bevl_result = null;
BEC_4_3_MathInt bevl_chash = null;
BEC_4_6_TextString bevl_mname = null;
BEC_4_3_MathInt bevl_mhash = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_11_SystemInitializer bevt_9_tmpvar_phold = null;
if (beva_cname == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(18, bels_4));
bevt_1_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 118 */
bevl_result = null;

        String key = new String(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int, "UTF-8");
        Class ti = be.BELS_Base.BECS_Runtime.typeInstances.get(key);
        if (ti != null) {
            //System.out.println("Getting new instance for |" + key + "|");
            bevl_result = (BEC_6_6_SystemObject) ti.newInstance();
        } 
        //else {
        //    System.out.println("No typeInstance for |" + key + "|");
        //}
        if (bevl_result == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 196 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 197 */ {
bevt_7_tmpvar_phold = bevo_2;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(beva_cname);
bevt_5_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 198 */
 else  /* Line: 199 */ {
return null;
} /* Line: 200 */
} /* Line: 197 */
bevt_9_tmpvar_phold = (BEC_6_11_SystemInitializer) (new BEC_6_11_SystemInitializer()).bem_new_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_initializeIfShould_1(bevl_result);
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_invoke_2(BEC_4_6_TextString beva_name, BEC_9_5_ContainerArray beva_args) throws Throwable {
BEC_4_6_TextString bevl_cname = null;
BEC_4_3_MathInt bevl_chash = null;
BEC_6_6_SystemObject bevl_rval = null;
BEC_4_3_MathInt bevl_numargs = null;
BEC_9_5_ContainerArray bevl_args2 = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(23, bels_6));
bevt_1_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 239 */
if (beva_args == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 241 */ {
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(33, bels_7));
bevt_4_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 242 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpvar_phold = bevo_3;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();
 /* Line: 251 */ {
bevt_10_tmpvar_phold = bevo_4;
bevt_9_tmpvar_phold = bevl_numargs.bem_greater_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevt_12_tmpvar_phold = bevo_5;
bevt_11_tmpvar_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpvar_phold);
bevl_args2 = (new BEC_9_5_ContainerArray()).bem_new_1(bevt_11_tmpvar_phold);
bevl_i = (new BEC_4_3_MathInt(7));
while (true)
 /* Line: 254 */ {
bevt_13_tmpvar_phold = bevl_i.bem_lesser_1(bevl_numargs);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_15_tmpvar_phold = bevo_6;
bevt_14_tmpvar_phold = bevl_i.bem_subtract_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpvar_phold, bevt_16_tmpvar_phold);
bevl_i.bem_incrementValue_0();
} /* Line: 254 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 252 */

        int ci = be.BELS_Base.BECS_Ids.callIds.get(new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8"));
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(bevl_chash.bevi_int, ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(bevl_chash.bevi_int, ci, beva_args.bevi_array[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5], beva_args.bevi_array[6]);
        } else {
            bevl_rval = bemd_x(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5], beva_args.bevi_array[6], bevl_args2.bevi_array);
        }
        bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 382 */
return bevl_rval;
} /*method end*/
public BEC_6_6_SystemObject bem_can_2(BEC_4_6_TextString beva_name, BEC_4_3_MathInt beva_numargs) throws Throwable {
BEC_4_6_TextString bevl_cname = null;
BEC_4_3_MathInt bevl_chash = null;
BEC_6_6_SystemObject bevl_rval = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(18, bels_9));
bevt_1_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 410 */
if (beva_numargs == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 412 */ {
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(21, bels_10));
bevt_4_tmpvar_phold = (BEC_6_19_SystemInvocationException) (new BEC_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 413 */
bevt_7_tmpvar_phold = bevo_7;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      String name = "bem_" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      java.lang.reflect.Method[] methods = this.getClass().getMethods();
      for (int i = 0;i < methods.length;i++) {
        if (methods[i].getName().equals(name)) {
            return be.BELS_Base.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 469 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 470 */
if (bevl_rval == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 472 */ {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /* Line: 473 */
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_classNameGet_0() throws Throwable {
BEC_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clname();
      bevl_xi = new BEC_4_6_TextString(bevls_clname.length, bevls_clname);
      return bevl_xi;
} /*method end*/
public BEC_4_6_TextString bem_sourceFileNameGet_0() throws Throwable {
BEC_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clfile();
      bevl_xi = new BEC_4_6_TextString(bevls_clname.length, bevls_clname);
      return bevl_xi;
} /*method end*/
public BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_sameObject_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_tagGet_0() throws Throwable {
BEC_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_4_3_MathInt()).bem_new_0();

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_tagGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_print_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_echo_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_echo_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_create_0();
bevt_0_tmpvar_phold = this.bem_copyTo_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_copyTo_1(BEC_6_6_SystemObject beva_copy) throws Throwable {
BEC_6_22_SystemObjectPropertyIterator bevl_siter = null;
BEC_6_22_SystemObjectPropertyIterator bevl_citer = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
if (beva_copy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 660 */ {
return beva_copy;
} /* Line: 661 */
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_6_22_SystemObjectPropertyIterator()).bem_new_2(this, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_6_22_SystemObjectPropertyIterator()).bem_new_2(beva_copy, bevt_2_tmpvar_phold);
while (true)
 /* Line: 665 */ {
bevt_3_tmpvar_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_4_tmpvar_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpvar_phold);
} /* Line: 666 */
 else  /* Line: 665 */ {
break;
} /* Line: 665 */
} /* Line: 665 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_deserializeFromString_1(BEC_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_serializeToString_0() throws Throwable {
return null;
} /*method end*/
public BEC_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_6_22_SystemObjectPropertyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_6_22_SystemObjectPropertyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_6_22_SystemObjectPropertyIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_6_22_SystemObjectPropertyIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
BEC_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return bevl_copy;
} /*method end*/
public BEC_5_4_LogicBool bem_sameClass_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && this.getClass().equals(beva_other.getClass())) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_otherClass_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameClass_1(beva_other);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_sameType_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && beva_other.getClass().isAssignableFrom(this.getClass())) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_otherType_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameType_1(beva_other);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_once_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_many_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {39, 39, 50, 50, 61, 61, 72, 72, 77, 79, 80, 80, 80, 82, 82, 86, 86, 86, 88, 89, 90, 91, 92, 92, 92, 92, 92, 92, 92, 92, 92, 94, 98, 98, 98, 117, 117, 118, 118, 118, 120, 196, 196, 198, 198, 198, 198, 200, 203, 203, 203, 238, 238, 239, 239, 239, 241, 241, 242, 242, 242, 244, 245, 245, 245, 245, 246, 252, 252, 253, 253, 253, 254, 254, 255, 255, 255, 255, 254, 380, 382, 384, 409, 409, 410, 410, 410, 412, 412, 413, 413, 413, 415, 415, 415, 415, 416, 469, 470, 472, 472, 473, 473, 475, 475, 509, 531, 563, 563, 595, 595, 606, 632, 636, 636, 640, 640, 640, 644, 644, 648, 648, 652, 652, 656, 656, 656, 660, 660, 661, 663, 663, 664, 664, 665, 666, 666, 672, 672, 678, 684, 684, 688, 688, 692, 692, 715, 762, 762, 766, 766, 766, 821, 821, 825, 825, 825};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {33, 34, 38, 39, 43, 44, 48, 49, 57, 58, 60, 61, 62, 64, 65, 82, 83, 84, 86, 87, 88, 91, 93, 94, 95, 96, 97, 98, 99, 100, 101, 104, 109, 110, 111, 128, 133, 134, 135, 136, 138, 149, 154, 156, 157, 158, 159, 162, 165, 166, 167, 194, 199, 200, 201, 202, 204, 209, 210, 211, 212, 214, 215, 216, 217, 218, 219, 221, 222, 224, 225, 226, 227, 230, 232, 233, 234, 235, 236, 266, 268, 270, 289, 294, 295, 296, 297, 299, 304, 305, 306, 307, 309, 310, 311, 312, 313, 322, 324, 326, 331, 332, 333, 335, 336, 343, 350, 358, 359, 367, 368, 372, 375, 379, 380, 385, 386, 387, 391, 392, 396, 397, 402, 403, 409, 410, 411, 421, 426, 427, 429, 430, 431, 432, 435, 437, 438, 448, 449, 455, 462, 463, 467, 468, 472, 473, 479, 487, 488, 493, 494, 495, 503, 504, 509, 510, 511};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 39 33
new 0 39 33
return 1 39 34
assign 1 50 38
new 0 50 38
return 1 50 39
assign 1 61 43
new 0 61 43
return 1 61 44
assign 1 72 48
new 0 72 48
return 1 72 49
assign 1 77 57
new 0 77 57
assign 1 79 58
notReadyGet 0 79 58
assign 1 80 60
new 0 80 60
assign 1 80 61
new 1 80 61
throw 1 80 62
assign 1 82 64
methodNotDefined 1 82 64
return 1 82 65
assign 1 86 82
new 0 86 82
assign 1 86 83
new 0 86 83
assign 1 86 84
can 2 86 84
assign 1 88 86
assign 1 89 87
forward 1 89 87
return 1 90 88
assign 1 91 91
new 0 91 91
assign 1 92 93
new 0 92 93
assign 1 92 94
nameGet 0 92 94
assign 1 92 95
add 1 92 95
assign 1 92 96
new 0 92 96
assign 1 92 97
add 1 92 97
assign 1 92 98
classNameGet 0 92 98
assign 1 92 99
add 1 92 99
assign 1 92 100
new 1 92 100
throw 1 92 101
return 1 94 104
assign 1 98 109
new 0 98 109
assign 1 98 110
createInstance 2 98 110
return 1 98 111
assign 1 117 128
undef 1 117 133
assign 1 118 134
new 0 118 134
assign 1 118 135
new 1 118 135
throw 1 118 136
assign 1 120 138
assign 1 196 149
undef 1 196 154
assign 1 198 156
new 0 198 156
assign 1 198 157
add 1 198 157
assign 1 198 158
new 1 198 158
throw 1 198 159
return 1 200 162
assign 1 203 165
new 0 203 165
assign 1 203 166
initializeIfShould 1 203 166
return 1 203 167
assign 1 238 194
undef 1 238 199
assign 1 239 200
new 0 239 200
assign 1 239 201
new 1 239 201
throw 1 239 202
assign 1 241 204
undef 1 241 209
assign 1 242 210
new 0 242 210
assign 1 242 211
new 1 242 211
throw 1 242 212
assign 1 244 214
lengthGet 0 244 214
assign 1 245 215
new 0 245 215
assign 1 245 216
add 1 245 216
assign 1 245 217
toString 0 245 217
assign 1 245 218
add 1 245 218
assign 1 246 219
hashGet 0 246 219
assign 1 252 221
new 0 252 221
assign 1 252 222
greater 1 252 222
assign 1 253 224
new 0 253 224
assign 1 253 225
subtract 1 253 225
assign 1 253 226
new 1 253 226
assign 1 254 227
new 0 254 227
assign 1 254 230
lesser 1 254 230
assign 1 255 232
new 0 255 232
assign 1 255 233
subtract 1 255 233
assign 1 255 234
get 1 255 234
put 2 255 235
incrementValue 0 254 236
assign 1 380 266
new 0 380 266
toString 0 382 268
return 1 384 270
assign 1 409 289
undef 1 409 294
assign 1 410 295
new 0 410 295
assign 1 410 296
new 1 410 296
throw 1 410 297
assign 1 412 299
undef 1 412 304
assign 1 413 305
new 0 413 305
assign 1 413 306
new 1 413 306
throw 1 413 307
assign 1 415 309
new 0 415 309
assign 1 415 310
add 1 415 310
assign 1 415 311
toString 0 415 311
assign 1 415 312
add 1 415 312
assign 1 416 313
hashGet 0 416 313
assign 1 469 322
new 0 469 322
toString 0 470 324
assign 1 472 326
def 1 472 331
assign 1 473 332
new 0 473 332
return 1 473 333
assign 1 475 335
new 0 475 335
return 1 475 336
return 1 509 343
return 1 531 350
assign 1 563 358
new 0 563 358
return 1 563 359
assign 1 595 367
new 0 595 367
return 1 595 368
assign 1 606 372
new 0 606 372
return 1 632 375
assign 1 636 379
tagGet 0 636 379
return 1 636 380
assign 1 640 385
equals 1 640 385
assign 1 640 386
not 0 640 386
return 1 640 387
assign 1 644 391
classNameGet 0 644 391
return 1 644 392
assign 1 648 396
toString 0 648 396
print 0 648 397
assign 1 652 402
toString 0 652 402
echo 0 652 403
assign 1 656 409
create 0 656 409
assign 1 656 410
copyTo 1 656 410
return 1 656 411
assign 1 660 421
undef 1 660 426
return 1 661 427
assign 1 663 429
new 0 663 429
assign 1 663 430
new 2 663 430
assign 1 664 431
new 0 664 431
assign 1 664 432
new 2 664 432
assign 1 665 435
hasNextGet 0 665 435
assign 1 666 437
nextGet 0 666 437
nextSet 1 666 438
assign 1 672 448
classNameGet 0 672 448
return 1 672 449
return 1 678 455
assign 1 684 462
new 1 684 462
return 1 684 463
assign 1 688 467
new 1 688 467
return 1 688 468
assign 1 692 472
new 0 692 472
return 1 692 473
return 1 715 479
assign 1 762 487
new 0 762 487
return 1 762 488
assign 1 766 493
sameClass 1 766 493
assign 1 766 494
not 0 766 494
return 1 766 495
assign 1 821 503
new 0 821 503
return 1 821 504
assign 1 825 509
sameType 1 825 509
assign 1 825 510
not 0 825 510
return 1 825 511
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_6_SystemObject();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_6_SystemObject.bevs_inst = becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_6_SystemObject.bevs_inst;
}
}
