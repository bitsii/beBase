package be.BEL_4_Base;
/* IO:File: source/extended/Startup.be */
public class BEC_6_10_SystemParameters extends BEC_6_6_SystemObject {
public BEC_6_10_SystemParameters() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x0D,0x0A};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_8 = (new BEC_4_3_MathInt(3));
private static byte[] bels_1 = {0x2D,0x2D};
private static BEC_4_6_TextString bevo_9 = (new BEC_4_6_TextString(bels_1, 2));
private static BEC_4_3_MathInt bevo_10 = (new BEC_4_3_MathInt(2));
private static byte[] bels_2 = {0x2D};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_2, 1));
private static BEC_4_3_MathInt bevo_12 = (new BEC_4_3_MathInt(1));
private static byte[] bels_3 = {0x3D};
private static BEC_4_6_TextString bevo_13 = (new BEC_4_6_TextString(bels_3, 1));
private static BEC_4_3_MathInt bevo_14 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_15 = (new BEC_4_3_MathInt(1));
private static byte[] bels_4 = {0x23,0x2D,0x2D};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_4, 3));
private static BEC_4_3_MathInt bevo_17 = (new BEC_4_3_MathInt(3));
private static byte[] bels_5 = {0x23};
private static BEC_4_6_TextString bevo_18 = (new BEC_4_6_TextString(bels_5, 1));
public static BEC_6_10_SystemParameters bevs_inst;
public BEC_9_5_ContainerArray bevp_args;
public BEC_9_3_ContainerMap bevp_params;
public BEC_9_5_ContainerArray bevp_ordered;
public BEC_4_9_TextTokenizer bevp_fileTok;
public BEC_6_6_SystemObject bevp_preProcessor;
public BEC_6_10_SystemParameters bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(2, bels_0));
bevp_fileTok = (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_10_SystemParameters bem_new_1(BEC_9_5_ContainerArray beva__args) throws Throwable {
this.bem_new_0();
this.bem_addArgs_1(beva__args);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addArgs_1(BEC_6_6_SystemObject beva__args) throws Throwable {
BEC_4_3_MathInt bevl_ii = null;
BEC_4_6_TextString bevl_pname = null;
BEC_5_4_LogicBool bevl_pnameComment = null;
BEC_4_6_TextString bevl_i = null;
BEC_4_6_TextString bevl_fa = null;
BEC_4_6_TextString bevl_fb = null;
BEC_4_6_TextString bevl_fc = null;
BEC_4_6_TextString bevl_par = null;
BEC_4_3_MathInt bevl_pos = null;
BEC_4_6_TextString bevl_key = null;
BEC_4_6_TextString bevl_value = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_4_3_MathInt bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_4_3_MathInt bevt_41_tmpvar_phold = null;
BEC_4_3_MathInt bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_52_tmpvar_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 126 */ {
bevl_ii = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 127 */ {
bevt_7_tmpvar_phold = beva__args.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_6_tmpvar_phold = bevl_ii.bem_lesser_1((BEC_4_3_MathInt) bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 127 */ {
bevt_9_tmpvar_phold = beva__args.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_ii);
bevt_8_tmpvar_phold = bevp_preProcessor.bemd_1(1094759839, BEL_4_Base.bevn_process_1, bevt_9_tmpvar_phold);
beva__args.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_ii, bevt_8_tmpvar_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 127 */
 else  /* Line: 127 */ {
break;
} /* Line: 127 */
} /* Line: 127 */
} /* Line: 127 */
if (bevp_args == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 131 */ {
bevp_args = (BEC_9_5_ContainerArray) beva__args;
bevp_params = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (new BEC_9_5_ContainerArray()).bem_new_0();
} /* Line: 134 */
 else  /* Line: 135 */ {
bevp_args = bevp_args.bem_add_1((BEC_9_5_ContainerArray) beva__args);
} /* Line: 136 */
bevl_pname = null;
bevl_pnameComment = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_loop = beva__args.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 140 */ {
bevt_11_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 140 */ {
bevl_i = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_13_tmpvar_phold = bevl_i.bem_sizeGet_0();
bevt_14_tmpvar_phold = bevo_0;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_greater_1(bevt_14_tmpvar_phold);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 144 */ {
bevt_15_tmpvar_phold = bevo_1;
bevt_16_tmpvar_phold = bevo_2;
bevl_fa = bevl_i.bem_substring_2(bevt_15_tmpvar_phold, bevt_16_tmpvar_phold);
bevt_18_tmpvar_phold = bevl_i.bem_sizeGet_0();
bevt_19_tmpvar_phold = bevo_3;
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_greater_1(bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 146 */ {
bevt_20_tmpvar_phold = bevo_4;
bevt_21_tmpvar_phold = bevo_5;
bevl_fb = bevl_i.bem_substring_2(bevt_20_tmpvar_phold, bevt_21_tmpvar_phold);
bevt_23_tmpvar_phold = bevl_i.bem_sizeGet_0();
bevt_24_tmpvar_phold = bevo_6;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_greater_1(bevt_24_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 148 */ {
bevt_25_tmpvar_phold = bevo_7;
bevt_26_tmpvar_phold = bevo_8;
bevl_fc = bevl_i.bem_substring_2(bevt_25_tmpvar_phold, bevt_26_tmpvar_phold);
} /* Line: 149 */
} /* Line: 148 */
} /* Line: 146 */
if (bevl_pname == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 153 */ {
bevt_28_tmpvar_phold = bevl_pnameComment.bem_not_0();
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 154 */ {
this.bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 155 */
bevl_pname = null;
bevl_pnameComment = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 158 */
 else  /* Line: 153 */ {
if (bevl_fb == null) {
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_31_tmpvar_phold = bevo_9;
bevt_30_tmpvar_phold = bevl_fb.bem_equals_1(bevt_31_tmpvar_phold);
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 159 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 159 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 159 */
 else  /* Line: 159 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 159 */ {
bevt_32_tmpvar_phold = bevo_10;
bevt_33_tmpvar_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_32_tmpvar_phold, bevt_33_tmpvar_phold);
} /* Line: 160 */
 else  /* Line: 153 */ {
if (bevl_fa == null) {
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevt_36_tmpvar_phold = bevo_11;
bevt_35_tmpvar_phold = bevl_fa.bem_equals_1(bevt_36_tmpvar_phold);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 161 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 161 */
 else  /* Line: 161 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 161 */ {
bevt_37_tmpvar_phold = bevo_12;
bevt_38_tmpvar_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_37_tmpvar_phold, bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = bevo_13;
bevl_pos = bevl_par.bem_find_1(bevt_39_tmpvar_phold);
if (bevl_pos == null) {
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_40_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevt_41_tmpvar_phold = bevo_14;
bevl_key = bevl_par.bem_substring_2(bevt_41_tmpvar_phold, bevl_pos);
bevt_43_tmpvar_phold = bevo_15;
bevt_42_tmpvar_phold = bevl_pos.bem_add_1(bevt_43_tmpvar_phold);
bevl_value = bevl_par.bem_substring_1(bevt_42_tmpvar_phold);
this.bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 167 */
} /* Line: 164 */
 else  /* Line: 153 */ {
if (bevl_fc == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 169 */ {
bevt_46_tmpvar_phold = bevo_16;
bevt_45_tmpvar_phold = bevl_fc.bem_equals_1(bevt_46_tmpvar_phold);
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 169 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 169 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 169 */
 else  /* Line: 169 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 169 */ {
bevt_47_tmpvar_phold = bevo_17;
bevt_48_tmpvar_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevl_pnameComment = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 171 */
 else  /* Line: 153 */ {
if (bevl_fa == null) {
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_49_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_51_tmpvar_phold = bevo_18;
bevt_50_tmpvar_phold = bevl_fa.bem_equals_1(bevt_51_tmpvar_phold);
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 172 */
 else  /* Line: 172 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
bevt_52_tmpvar_phold = bevt_4_tmpvar_anchor.bem_not_0();
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 173 */
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
} /* Line: 153 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_preProcessorSet_1(BEC_6_6_SystemObject beva__preProcessor) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_9_3_ContainerMap bevl__params = null;
BEC_6_6_SystemObject bevl_it = null;
BEC_4_6_TextString bevl_key = null;
BEC_9_10_ContainerLinkedList bevl_vals = null;
BEC_9_10_ContainerLinkedList bevl__vals = null;
BEC_4_6_TextString bevl_istr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 180 */ {
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 181 */ {
bevt_3_tmpvar_phold = bevp_args.bem_lengthGet_0();
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 181 */ {
bevt_5_tmpvar_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpvar_phold = bevp_preProcessor.bemd_1(1094759839, BEL_4_Base.bevn_process_1, bevt_5_tmpvar_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 181 */
 else  /* Line: 181 */ {
break;
} /* Line: 181 */
} /* Line: 181 */
} /* Line: 181 */
if (bevp_ordered == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 186 */ {
bevt_8_tmpvar_phold = bevp_ordered.bem_lengthGet_0();
bevt_7_tmpvar_phold = bevl_i.bem_lesser_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 186 */ {
bevt_10_tmpvar_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpvar_phold = bevp_preProcessor.bemd_1(1094759839, BEL_4_Base.bevn_process_1, bevt_10_tmpvar_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 186 */
 else  /* Line: 186 */ {
break;
} /* Line: 186 */
} /* Line: 186 */
} /* Line: 186 */
if (bevp_params == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 190 */ {
bevl__params = (new BEC_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 192 */ {
bevt_12_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 192 */ {
bevl_key = (BEC_4_6_TextString) bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_vals = (BEC_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpvar_loop = bevl_vals.bem_iteratorGet_0();
while (true)
 /* Line: 196 */ {
bevt_13_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 196 */ {
bevl_istr = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_14_tmpvar_phold = bevp_preProcessor.bemd_1(1094759839, BEL_4_Base.bevn_process_1, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpvar_phold);
} /* Line: 197 */
 else  /* Line: 196 */ {
break;
} /* Line: 196 */
} /* Line: 196 */
bevl_key = (BEC_4_6_TextString) bevp_preProcessor.bemd_1(1094759839, BEL_4_Base.bevn_process_1, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 200 */
 else  /* Line: 192 */ {
break;
} /* Line: 192 */
} /* Line: 192 */
bevp_params = bevl__params;
} /* Line: 202 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isTrue_2(BEC_4_6_TextString beva_name, BEC_5_4_LogicBool beva_isit) throws Throwable {
BEC_4_6_TextString bevl_res = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_res = this.bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 208 */ {
beva_isit = (new BEC_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 210 */
return beva_isit;
} /*method end*/
public BEC_5_4_LogicBool bem_isTrue_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_isTrue_2(beva_name, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_has_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_get_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_params.bem_get_1(beva_name);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_get_2(BEC_4_6_TextString beva_name, BEC_4_6_TextString beva_default) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_pl = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_pl = (BEC_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 230 */ {
bevl_pl = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 232 */
return bevl_pl;
} /*method end*/
public BEC_4_6_TextString bem_getFirst_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_getFirst_2(beva_name, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_getFirst_2(BEC_4_6_TextString beva_name, BEC_4_6_TextString beva_default) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_pl = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_pl = (BEC_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 243 */ {
return beva_default;
} /* Line: 244 */
bevt_1_tmpvar_phold = bevl_pl.bem_firstGet_0();
return (BEC_4_6_TextString) bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_addParameter_2(BEC_4_6_TextString beva_name, BEC_4_6_TextString beva_value) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_vals = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_vals = (BEC_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 252 */ {
bevl_vals = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 254 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addFile_1(BEC_2_4_IOFile beva_file) throws Throwable {
BEC_6_6_SystemObject bevl_fcontents = null;
BEC_9_5_ContainerArray bevl_fargs = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_file.bem_readerGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_fcontents = bevt_0_tmpvar_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_2_tmpvar_phold = beva_file.bem_readerGet_0();
bevt_2_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_3_tmpvar_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_9_5_ContainerArray) bevt_3_tmpvar_phold.bemd_0(1897309391, BEL_4_Base.bevn_toArray_0);
this.bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_orderedGet_0() throws Throwable {
return bevp_ordered;
} /*method end*/
public BEC_6_6_SystemObject bem_orderedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ordered = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_fileTokGet_0() throws Throwable {
return bevp_fileTok;
} /*method end*/
public BEC_6_6_SystemObject bem_fileTokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fileTok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_preProcessorGet_0() throws Throwable {
return bevp_preProcessor;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {114, 114, 121, 122, 126, 126, 127, 127, 127, 128, 128, 128, 127, 131, 131, 132, 133, 134, 136, 138, 139, 140, 0, 140, 140, 141, 142, 143, 144, 144, 144, 145, 145, 145, 146, 146, 146, 147, 147, 147, 148, 148, 148, 149, 149, 149, 153, 153, 154, 155, 157, 158, 159, 159, 159, 159, 0, 0, 0, 160, 160, 160, 161, 161, 161, 161, 0, 0, 0, 162, 162, 162, 163, 163, 164, 164, 165, 165, 166, 166, 166, 167, 169, 169, 169, 169, 0, 0, 0, 170, 170, 170, 171, 172, 172, 172, 172, 0, 0, 0, 172, 173, 179, 180, 180, 181, 181, 181, 182, 182, 182, 181, 185, 185, 186, 186, 186, 187, 187, 187, 186, 190, 190, 191, 192, 192, 193, 194, 195, 196, 0, 196, 196, 197, 197, 199, 200, 202, 207, 208, 208, 210, 213, 217, 217, 217, 221, 221, 225, 225, 229, 230, 230, 231, 232, 234, 238, 238, 242, 243, 243, 244, 246, 246, 251, 252, 252, 253, 254, 256, 260, 260, 260, 261, 261, 262, 262, 263, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {40, 41, 45, 46, 114, 119, 120, 123, 124, 126, 127, 128, 129, 136, 141, 142, 143, 144, 147, 149, 150, 151, 151, 154, 156, 157, 158, 159, 160, 161, 162, 164, 165, 166, 167, 168, 169, 171, 172, 173, 174, 175, 176, 178, 179, 180, 184, 189, 190, 192, 194, 195, 198, 203, 204, 205, 207, 210, 214, 217, 218, 219, 222, 227, 228, 229, 231, 234, 238, 241, 242, 243, 244, 245, 246, 251, 252, 253, 254, 255, 256, 257, 261, 266, 267, 268, 270, 273, 277, 280, 281, 282, 283, 286, 291, 292, 293, 295, 298, 302, 304, 306, 342, 343, 348, 349, 352, 353, 355, 356, 357, 358, 365, 370, 371, 374, 375, 377, 378, 379, 380, 387, 392, 393, 394, 397, 399, 400, 401, 402, 402, 405, 407, 408, 409, 415, 416, 422, 429, 430, 435, 436, 438, 443, 444, 445, 449, 450, 454, 455, 460, 461, 466, 467, 468, 470, 474, 475, 481, 482, 487, 488, 490, 491, 496, 497, 502, 503, 504, 506, 516, 517, 518, 519, 520, 521, 522, 523, 527, 530, 534, 537, 541, 544, 548, 551, 555};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 114 40
new 0 114 40
assign 1 114 41
new 1 114 41
new 0 121 45
addArgs 1 122 46
assign 1 126 114
def 1 126 119
assign 1 127 120
new 0 127 120
assign 1 127 123
lengthGet 0 127 123
assign 1 127 124
lesser 1 127 124
assign 1 128 126
get 1 128 126
assign 1 128 127
process 1 128 127
put 2 128 128
assign 1 127 129
increment 0 127 129
assign 1 131 136
undef 1 131 141
assign 1 132 142
assign 1 133 143
new 0 133 143
assign 1 134 144
new 0 134 144
assign 1 136 147
add 1 136 147
assign 1 138 149
assign 1 139 150
new 0 139 150
assign 1 140 151
iteratorGet 0 0 151
assign 1 140 154
hasNextGet 0 140 154
assign 1 140 156
nextGet 0 140 156
assign 1 141 157
assign 1 142 158
assign 1 143 159
assign 1 144 160
sizeGet 0 144 160
assign 1 144 161
new 0 144 161
assign 1 144 162
greater 1 144 162
assign 1 145 164
new 0 145 164
assign 1 145 165
new 0 145 165
assign 1 145 166
substring 2 145 166
assign 1 146 167
sizeGet 0 146 167
assign 1 146 168
new 0 146 168
assign 1 146 169
greater 1 146 169
assign 1 147 171
new 0 147 171
assign 1 147 172
new 0 147 172
assign 1 147 173
substring 2 147 173
assign 1 148 174
sizeGet 0 148 174
assign 1 148 175
new 0 148 175
assign 1 148 176
greater 1 148 176
assign 1 149 178
new 0 149 178
assign 1 149 179
new 0 149 179
assign 1 149 180
substring 2 149 180
assign 1 153 184
def 1 153 189
assign 1 154 190
not 0 154 190
addParameter 2 155 192
assign 1 157 194
assign 1 158 195
new 0 158 195
assign 1 159 198
def 1 159 203
assign 1 159 204
new 0 159 204
assign 1 159 205
equals 1 159 205
assign 1 0 207
assign 1 0 210
assign 1 0 214
assign 1 160 217
new 0 160 217
assign 1 160 218
sizeGet 0 160 218
assign 1 160 219
substring 2 160 219
assign 1 161 222
def 1 161 227
assign 1 161 228
new 0 161 228
assign 1 161 229
equals 1 161 229
assign 1 0 231
assign 1 0 234
assign 1 0 238
assign 1 162 241
new 0 162 241
assign 1 162 242
sizeGet 0 162 242
assign 1 162 243
substring 2 162 243
assign 1 163 244
new 0 163 244
assign 1 163 245
find 1 163 245
assign 1 164 246
def 1 164 251
assign 1 165 252
new 0 165 252
assign 1 165 253
substring 2 165 253
assign 1 166 254
new 0 166 254
assign 1 166 255
add 1 166 255
assign 1 166 256
substring 1 166 256
addParameter 2 167 257
assign 1 169 261
def 1 169 266
assign 1 169 267
new 0 169 267
assign 1 169 268
equals 1 169 268
assign 1 0 270
assign 1 0 273
assign 1 0 277
assign 1 170 280
new 0 170 280
assign 1 170 281
sizeGet 0 170 281
assign 1 170 282
substring 2 170 282
assign 1 171 283
new 0 171 283
assign 1 172 286
def 1 172 291
assign 1 172 292
new 0 172 292
assign 1 172 293
equals 1 172 293
assign 1 0 295
assign 1 0 298
assign 1 0 302
assign 1 172 304
not 0 172 304
addValue 1 173 306
assign 1 179 342
assign 1 180 343
def 1 180 348
assign 1 181 349
new 0 181 349
assign 1 181 352
lengthGet 0 181 352
assign 1 181 353
lesser 1 181 353
assign 1 182 355
get 1 182 355
assign 1 182 356
process 1 182 356
put 2 182 357
assign 1 181 358
increment 0 181 358
assign 1 185 365
def 1 185 370
assign 1 186 371
new 0 186 371
assign 1 186 374
lengthGet 0 186 374
assign 1 186 375
lesser 1 186 375
assign 1 187 377
get 1 187 377
assign 1 187 378
process 1 187 378
put 2 187 379
assign 1 186 380
increment 0 186 380
assign 1 190 387
def 1 190 392
assign 1 191 393
new 0 191 393
assign 1 192 394
keyIteratorGet 0 192 394
assign 1 192 397
hasNextGet 0 192 397
assign 1 193 399
nextGet 0 193 399
assign 1 194 400
get 1 194 400
assign 1 195 401
new 0 195 401
assign 1 196 402
iteratorGet 0 0 402
assign 1 196 405
hasNextGet 0 196 405
assign 1 196 407
nextGet 0 196 407
assign 1 197 408
process 1 197 408
addValue 1 197 409
assign 1 199 415
process 1 199 415
put 2 200 416
assign 1 202 422
assign 1 207 429
getFirst 1 207 429
assign 1 208 430
def 1 208 435
assign 1 210 436
new 1 210 436
return 1 213 438
assign 1 217 443
new 0 217 443
assign 1 217 444
isTrue 2 217 444
return 1 217 445
assign 1 221 449
has 1 221 449
return 1 221 450
assign 1 225 454
get 1 225 454
return 1 225 455
assign 1 229 460
get 1 229 460
assign 1 230 461
undef 1 230 466
assign 1 231 467
new 0 231 467
addValue 1 232 468
return 1 234 470
assign 1 238 474
getFirst 2 238 474
return 1 238 475
assign 1 242 481
get 1 242 481
assign 1 243 482
undef 1 243 487
return 1 244 488
assign 1 246 490
firstGet 0 246 490
return 1 246 491
assign 1 251 496
get 1 251 496
assign 1 252 497
undef 1 252 502
assign 1 253 503
new 0 253 503
put 2 254 504
addValue 1 256 506
assign 1 260 516
readerGet 0 260 516
assign 1 260 517
open 0 260 517
assign 1 260 518
readString 0 260 518
assign 1 261 519
readerGet 0 261 519
close 0 261 520
assign 1 262 521
tokenize 1 262 521
assign 1 262 522
toArray 0 262 522
addArgs 1 263 523
return 1 0 527
assign 1 0 530
return 1 0 534
assign 1 0 537
return 1 0 541
assign 1 0 544
return 1 0 548
assign 1 0 551
return 1 0 555
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 1695168417: return bem_paramsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1600549146: return bem_orderedGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1895160755: return bem_fileTokGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2127864150: return bem_argsGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 1128894872: return bem_preProcessorGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 99049420: return bem_has_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_9_5_ContainerArray) bevd_0);
case 187837996: return bem_getFirst_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1139977125: return bem_preProcessorSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 98246024: return bem_get_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1611631399: return bem_orderedSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1906243008: return bem_fileTokSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 516636336: return bem_addArgs_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 381666769: return bem_addFile_1((BEC_2_4_IOFile) bevd_0);
case 191084662: return bem_isTrue_1((BEC_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 187837997: return bem_getFirst_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 98246025: return bem_get_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1957079483: return bem_addParameter_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 191084661: return bem_isTrue_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_10_SystemParameters();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_10_SystemParameters.bevs_inst = (BEC_6_10_SystemParameters)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_10_SystemParameters.bevs_inst;
}
}
