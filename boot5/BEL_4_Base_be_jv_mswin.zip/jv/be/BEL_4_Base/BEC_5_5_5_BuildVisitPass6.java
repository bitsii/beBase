package be.BEL_4_Base;
/* IO:File: source/build/Pass6.be */
public class BEC_5_5_5_BuildVisitPass6 extends BEC_5_5_7_BuildVisitVisitor {
public BEC_5_5_5_BuildVisitPass6() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
private static byte[] bels_0 = {0x2C};
private static byte[] bels_1 = {0x2C};
private static byte[] bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_3 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_4 = {0x5F};
private static byte[] bels_5 = {0x73,0x65,0x6C,0x66};
public static BEC_5_5_5_BuildVisitPass6 bevs_inst;
public BEC_5_4_BuildNode bem_accept_1(BEC_5_4_BuildNode beva_node) throws Throwable {
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_v = null;
BEC_6_6_SystemObject bevl_nnode = null;
BEC_6_6_SystemObject bevl_gnext = null;
BEC_9_3_ContainerSet bevl_langs = null;
BEC_5_4_BuildNode bevl_lang = null;
BEC_6_6_SystemObject bevl_doit = null;
BEC_6_6_SystemObject bevl_si = null;
BEC_6_6_SystemObject bevl_snode = null;
BEC_6_6_SystemObject bevl_lnode = null;
BEC_6_6_SystemObject bevl_enode = null;
BEC_6_6_SystemObject bevl_brnode = null;
BEC_6_6_SystemObject bevl_inode = null;
BEC_6_6_SystemObject bevl_nxnode = null;
BEC_6_6_SystemObject bevl_parens = null;
BEC_6_6_SystemObject bevl_nd = null;
BEC_6_6_SystemObject bevl_toremove = null;
BEC_6_6_SystemObject bevl_numargs = null;
BEC_6_6_SystemObject bevl_ii = null;
BEC_6_6_SystemObject bevl_ix = null;
BEC_6_6_SystemObject bevl_vid = null;
BEC_6_6_SystemObject bevl_vinp = null;
BEC_6_6_SystemObject bevl_s = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_20_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_25_tmpvar_phold = null;
BEC_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_29_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_38_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_4_3_MathInt bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_5_4_BuildEmit bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_6_BuildIfEmit bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_71_tmpvar_phold = null;
BEC_4_3_MathInt bevt_72_tmpvar_phold = null;
BEC_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_79_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_81_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_4_3_MathInt bevt_84_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_85_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_9_8_ContainerNodeList bevt_89_tmpvar_phold = null;
BEC_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_92_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_93_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_4_3_MathInt bevt_96_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_97_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_98_tmpvar_phold = null;
BEC_4_3_MathInt bevt_99_tmpvar_phold = null;
BEC_4_3_MathInt bevt_100_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_4_3_MathInt bevt_103_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_4_3_MathInt bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_4_3_MathInt bevt_109_tmpvar_phold = null;
BEC_4_3_MathInt bevt_110_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_113_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_114_tmpvar_phold = null;
BEC_4_3_MathInt bevt_115_tmpvar_phold = null;
BEC_5_10_BuildVisitError bevt_116_tmpvar_phold = null;
BEC_4_6_TextString bevt_117_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_118_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_119_tmpvar_phold = null;
BEC_4_3_MathInt bevt_120_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_124_tmpvar_phold = null;
BEC_4_6_TextString bevt_125_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_126_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_129_tmpvar_phold = null;
BEC_4_3_MathInt bevt_130_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_132_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_137_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_138_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_139_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_5_4_BuildNode bevt_144_tmpvar_phold = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_EMITGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 27 */ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_tmpvar_phold = beva_node.bem_containedGet_0();
if (bevt_12_tmpvar_phold == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_15_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_lengthGet_0();
bevt_16_tmpvar_phold = bevo_0;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_greater_1(bevt_16_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 29 */ {
bevt_20_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_18_tmpvar_phold == null) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 29 */ {
bevt_25_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_firstGet_0();
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_26_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevt_26_tmpvar_phold);
if (bevt_21_tmpvar_phold != null && bevt_21_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_21_tmpvar_phold).bevi_bool) /* Line: 29 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 29 */ {
bevt_30_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_containedGet_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_lengthGet_0();
bevt_31_tmpvar_phold = bevo_1;
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bem_greater_1(bevt_31_tmpvar_phold);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 29 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 29 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 29 */
 else  /* Line: 29 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 29 */ {
bevl_langs = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_34_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_firstGet_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_0_tmpvar_loop = bevt_32_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 32 */ {
bevt_35_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 32 */ {
bevl_lang = (BEC_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_36_tmpvar_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_tmpvar_phold);
} /* Line: 34 */
 else  /* Line: 32 */ {
break;
} /* Line: 32 */
} /* Line: 32 */
bevt_37_tmpvar_phold = (new BEC_4_6_TextString(1, bels_0));
bevl_langs.bem_delete_1(bevt_37_tmpvar_phold);
bevl_doit = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevl_doit != null && bevl_doit instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevl_doit).bevi_bool) /* Line: 38 */ {
bevl_doit = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_39_tmpvar_phold = beva_node.bem_secondGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_containedGet_0();
bevl_i = bevt_38_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 40 */ {
bevt_40_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 40 */ {
bevl_si = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_42_tmpvar_phold = bevl_si.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_43_tmpvar_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_43_tmpvar_phold);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 42 */ {
bevt_44_tmpvar_phold = bevl_si.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
beva_node.bem_heldSet_1(bevt_44_tmpvar_phold);
bevl_doit = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 46 */
} /* Line: 42 */
 else  /* Line: 40 */ {
break;
} /* Line: 40 */
} /* Line: 40 */
} /* Line: 40 */
bevt_45_tmpvar_phold = bevl_doit.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_45_tmpvar_phold != null && bevt_45_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_45_tmpvar_phold).bevi_bool) /* Line: 50 */ {
beva_node.bem_delete_0();
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 52 */
beva_node.bem_containedSet_1(null);
bevt_47_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_46_tmpvar_phold = (new BEC_5_4_BuildEmit()).bem_new_2((BEC_4_6_TextString) bevt_47_tmpvar_phold, bevl_langs);
beva_node.bem_heldSet_1(bevt_46_tmpvar_phold);
} /* Line: 55 */
 else  /* Line: 56 */ {
beva_node.bem_delete_0();
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 58 */
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_tmpvar_phold = bevl_snode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_50_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_50_tmpvar_phold);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 62 */ {
bevl_snode = null;
} /* Line: 63 */
if (bevl_snode == null) {
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 66 */ {
beva_node.bem_delete_0();
bevt_52_tmpvar_phold = bevl_snode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_52_tmpvar_phold.bemd_1(406676794, BEL_4_Base.bevn_addEmit_1, beva_node);
} /* Line: 68 */
return (BEC_5_4_BuildNode) bevl_gnext;
} /* Line: 71 */
 else  /* Line: 27 */ {
bevt_54_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpvar_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_equals_1(bevt_55_tmpvar_phold);
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 72 */ {
bevl_langs = (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_firstGet_0();
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_1_tmpvar_loop = bevt_56_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 75 */ {
bevt_59_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 75 */ {
bevl_lang = (BEC_5_4_BuildNode) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_60_tmpvar_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_tmpvar_phold);
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_lang);
} /* Line: 78 */
 else  /* Line: 75 */ {
break;
} /* Line: 75 */
} /* Line: 75 */
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(1, bels_1));
bevl_langs.bem_delete_1(bevt_61_tmpvar_phold);
bevt_63_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_62_tmpvar_phold = (new BEC_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_4_6_TextString) bevt_63_tmpvar_phold);
beva_node.bem_heldSet_1(bevt_62_tmpvar_phold);
bevl_ii = bevl_toremove.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 82 */ {
bevt_64_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_64_tmpvar_phold != null && bevt_64_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_64_tmpvar_phold).bevi_bool) /* Line: 82 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 84 */
 else  /* Line: 82 */ {
break;
} /* Line: 82 */
} /* Line: 82 */
} /* Line: 82 */
 else  /* Line: 27 */ {
bevt_66_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_67_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bem_equals_1(bevt_67_tmpvar_phold);
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 86 */ {
if (bevl_nnode == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevl_lnode = beva_node;
while (true)
 /* Line: 89 */ {
if (bevl_nnode == null) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 89 */ {
bevt_71_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_72_tmpvar_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_72_tmpvar_phold);
if (bevt_70_tmpvar_phold != null && bevt_70_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_70_tmpvar_phold).bevi_bool) /* Line: 89 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 89 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 89 */
 else  /* Line: 89 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 89 */ {
bevl_enode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_73_tmpvar_phold);
bevl_enode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevl_brnode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_74_tmpvar_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_74_tmpvar_phold);
bevl_inode = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_75_tmpvar_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_75_tmpvar_phold);
bevl_brnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_inode);
bevl_enode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_brnode);
bevt_77_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
if (bevt_77_tmpvar_phold == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 101 */ {
bevt_78_tmpvar_phold = bevl_nnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = bevt_78_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 102 */ {
bevt_79_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_79_tmpvar_phold != null && bevt_79_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_79_tmpvar_phold).bevi_bool) /* Line: 102 */ {
bevt_80_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_inode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevt_80_tmpvar_phold);
} /* Line: 103 */
 else  /* Line: 102 */ {
break;
} /* Line: 102 */
} /* Line: 102 */
} /* Line: 102 */
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_nnode = bevl_nxnode;
} /* Line: 114 */
 else  /* Line: 89 */ {
break;
} /* Line: 89 */
} /* Line: 89 */
if (bevl_nnode == null) {
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_83_tmpvar_phold = bevl_nnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_84_tmpvar_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_84_tmpvar_phold);
if (bevt_82_tmpvar_phold != null && bevt_82_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_82_tmpvar_phold).bevi_bool) /* Line: 116 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
 else  /* Line: 116 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 116 */ {
bevl_nnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_lnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_nnode);
} /* Line: 118 */
} /* Line: 116 */
bevt_85_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpvar_phold;
} /* Line: 121 */
 else  /* Line: 27 */ {
bevt_87_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_88_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_86_tmpvar_phold = bevt_87_tmpvar_phold.bem_equals_1(bevt_88_tmpvar_phold);
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 122 */ {
bevt_89_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_tmpvar_phold.bem_firstGet_0();
bevl_nd = (new BEC_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_90_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (new BEC_4_6_TextString(4, bels_2));
bevl_nd.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_91_tmpvar_phold);
bevl_parens.bemd_1(1007846464, BEL_4_Base.bevn_prepend_1, bevl_nd);
bevl_toremove = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_4_3_MathInt(0));
bevt_92_tmpvar_phold = bevl_parens.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ii = bevt_92_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 131 */ {
bevt_93_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_93_tmpvar_phold != null && bevt_93_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_93_tmpvar_phold).bevi_bool) /* Line: 131 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_ix = bevl_i.bemd_0(124944494, BEL_4_Base.bevn_nextPeerGet_0);
bevt_95_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_96_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_94_tmpvar_phold = bevt_95_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_96_tmpvar_phold);
if (bevt_94_tmpvar_phold != null && bevt_94_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_94_tmpvar_phold).bevi_bool) /* Line: 136 */ {
bevl_toremove.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_i);
} /* Line: 137 */
 else  /* Line: 136 */ {
bevt_98_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_99_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_97_tmpvar_phold = bevt_98_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_99_tmpvar_phold);
if (bevt_97_tmpvar_phold != null && bevt_97_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_97_tmpvar_phold).bevi_bool) /* Line: 138 */ {
bevt_100_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_100_tmpvar_phold);
bevl_v = (new BEC_5_3_BuildVar()).bem_new_0();
bevt_101_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_101_tmpvar_phold);
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_102_tmpvar_phold);
bevl_i.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_v);
bevt_103_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_103_tmpvar_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
} /* Line: 145 */
 else  /* Line: 136 */ {
bevt_105_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_106_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_106_tmpvar_phold);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 146 */ {
bevt_108_tmpvar_phold = bevl_ix.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_109_tmpvar_phold = bevp_ntypes.bem_IDGet_0();
bevt_107_tmpvar_phold = bevt_108_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_109_tmpvar_phold);
if (bevt_107_tmpvar_phold != null && bevt_107_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_107_tmpvar_phold).bevi_bool) /* Line: 147 */ {
bevt_110_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_110_tmpvar_phold);
bevt_111_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_112_tmpvar_phold = bevl_ix.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_111_tmpvar_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_112_tmpvar_phold);
bevt_113_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_114_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_113_tmpvar_phold.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_114_tmpvar_phold);
bevl_i.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevt_115_tmpvar_phold = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_115_tmpvar_phold);
} /* Line: 152 */
 else  /* Line: 153 */ {
bevt_117_tmpvar_phold = (new BEC_4_6_TextString(30, bels_3));
bevt_116_tmpvar_phold = (new BEC_5_10_BuildVisitError()).bem_new_2(bevt_117_tmpvar_phold, bevl_i);
throw new be.BELS_Base.BECS_ThrowBack(bevt_116_tmpvar_phold);
} /* Line: 154 */
} /* Line: 147 */
} /* Line: 136 */
} /* Line: 136 */
} /* Line: 136 */
 else  /* Line: 131 */ {
break;
} /* Line: 131 */
} /* Line: 131 */
bevl_ii = bevl_toremove.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 158 */ {
bevt_118_tmpvar_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_118_tmpvar_phold != null && bevt_118_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_118_tmpvar_phold).bevi_bool) /* Line: 158 */ {
bevl_i = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 160 */
 else  /* Line: 158 */ {
break;
} /* Line: 158 */
} /* Line: 158 */
bevl_s = beva_node.bem_heldGet_0();
bevt_120_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevt_119_tmpvar_phold = bevl_numargs.bemd_1(81310150, BEL_4_Base.bevn_subtract_1, bevt_120_tmpvar_phold);
bevl_s.bemd_1(537631759, BEL_4_Base.bevn_numargsSet_1, bevt_119_tmpvar_phold);
bevt_121_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_s.bemd_1(1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_121_tmpvar_phold);
bevt_124_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_125_tmpvar_phold = (new BEC_4_6_TextString(1, bels_4));
bevt_123_tmpvar_phold = bevt_124_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_125_tmpvar_phold);
bevt_127_tmpvar_phold = bevl_s.bemd_0(548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_126_tmpvar_phold = bevt_127_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_126_tmpvar_phold);
bevl_s.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_122_tmpvar_phold);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_tmpvar_phold = bevl_i.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_130_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
bevt_128_tmpvar_phold = bevt_129_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_130_tmpvar_phold);
if (bevt_128_tmpvar_phold != null && bevt_128_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_128_tmpvar_phold).bevi_bool) /* Line: 167 */ {
bevl_i.bemd_0(1952633087, BEL_4_Base.bevn_resolveNp_0);
bevt_131_tmpvar_phold = bevl_i.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_s.bemd_1(419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_131_tmpvar_phold);
bevt_135_tmpvar_phold = bevl_s.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_136_tmpvar_phold = (new BEC_4_6_TextString(4, bels_5));
bevt_132_tmpvar_phold = bevt_133_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_132_tmpvar_phold != null && bevt_132_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_132_tmpvar_phold).bevi_bool) /* Line: 171 */ {
bevt_137_tmpvar_phold = bevl_s.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_138_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_137_tmpvar_phold.bemd_1(524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_138_tmpvar_phold);
} /* Line: 172 */
bevl_i.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 174 */
bevl_clnode = beva_node.bem_classGet_0();
bevt_140_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_139_tmpvar_phold = bevt_140_tmpvar_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_141_tmpvar_phold = bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_139_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_141_tmpvar_phold, beva_node);
bevt_143_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_142_tmpvar_phold = bevt_143_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_142_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, beva_node);
} /* Line: 178 */
} /* Line: 27 */
} /* Line: 27 */
} /* Line: 27 */
bevt_144_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_144_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {23, 26, 27, 28, 29, 0, 29, 0, 29, 0, 29, 0, 31, 32, 0, 32, 34, 36, 37, 39, 40, 41, 42, 43, 46, 50, 51, 52, 54, 55, 57, 58, 61, 62, 63, 66, 67, 68, 71, 72, 73, 74, 75, 0, 75, 77, 78, 80, 81, 82, 83, 84, 86, 87, 88, 89, 0, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 110, 111, 112, 113, 114, 116, 0, 117, 118, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 154, 158, 159, 160, 162, 163, 164, 165, 166, 167, 168, 170, 171, 172, 174, 176, 177, 178, 180};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186, 186};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
resolveNp 0 23 186
assign 1 26 186
nextPeerGet 0 26 186
assign 1 27 186
typenameGet 0 27 186
assign 1 27 186
EMITGet 0 27 186
assign 1 27 186
equals 1 27 186
assign 1 28 186
nextAscendGet 0 28 186
assign 1 29 186
containedGet 0 29 186
assign 1 29 186
def 1 29 186
assign 1 29 186
containedGet 0 29 186
assign 1 29 186
lengthGet 0 29 186
assign 1 29 186
new 0 29 186
assign 1 29 186
greater 1 29 186
assign 1 0 186
assign 1 0 186
assign 1 0 186
assign 1 29 186
containedGet 0 29 186
assign 1 29 186
firstGet 0 29 186
assign 1 29 186
containedGet 0 29 186
assign 1 29 186
def 1 29 186
assign 1 0 186
assign 1 0 186
assign 1 0 186
assign 1 29 186
containedGet 0 29 186
assign 1 29 186
firstGet 0 29 186
assign 1 29 186
containedGet 0 29 186
assign 1 29 186
lengthGet 0 29 186
assign 1 29 186
new 0 29 186
assign 1 29 186
greater 1 29 186
assign 1 0 186
assign 1 0 186
assign 1 0 186
assign 1 29 186
secondGet 0 29 186
assign 1 29 186
containedGet 0 29 186
assign 1 29 186
lengthGet 0 29 186
assign 1 29 186
new 0 29 186
assign 1 29 186
greater 1 29 186
assign 1 0 186
assign 1 0 186
assign 1 0 186
assign 1 31 186
new 0 31 186
assign 1 32 186
containedGet 0 32 186
assign 1 32 186
firstGet 0 32 186
assign 1 32 186
containedGet 0 32 186
assign 1 32 186
iteratorGet 0 0 186
assign 1 32 186
hasNextGet 0 32 186
assign 1 32 186
nextGet 0 32 186
assign 1 34 186
heldGet 0 34 186
addValue 1 34 186
assign 1 36 186
new 0 36 186
delete 1 36 186
assign 1 37 186
new 0 37 186
assign 1 39 186
new 0 39 186
assign 1 40 186
secondGet 0 40 186
assign 1 40 186
containedGet 0 40 186
assign 1 40 186
iteratorGet 0 40 186
assign 1 40 186
hasNextGet 0 40 186
assign 1 41 186
nextGet 0 41 186
assign 1 42 186
typenameGet 0 42 186
assign 1 42 186
STRINGLGet 0 42 186
assign 1 42 186
equals 1 42 186
assign 1 43 186
heldGet 0 43 186
heldSet 1 43 186
assign 1 46 186
new 0 46 186
assign 1 50 186
not 0 50 186
delete 0 51 186
return 1 52 186
containedSet 1 54 186
assign 1 55 186
heldGet 0 55 186
assign 1 55 186
new 2 55 186
heldSet 1 55 186
delete 0 57 186
return 1 58 186
assign 1 61 186
scopeGet 0 61 186
assign 1 62 186
typenameGet 0 62 186
assign 1 62 186
METHODGet 0 62 186
assign 1 62 186
equals 1 62 186
assign 1 63 186
assign 1 66 186
def 1 66 186
delete 0 67 186
assign 1 68 186
heldGet 0 68 186
addEmit 1 68 186
return 1 71 186
assign 1 72 186
typenameGet 0 72 186
assign 1 72 186
IFEMITGet 0 72 186
assign 1 72 186
equals 1 72 186
assign 1 73 186
new 0 73 186
assign 1 74 186
new 0 74 186
assign 1 75 186
containedGet 0 75 186
assign 1 75 186
firstGet 0 75 186
assign 1 75 186
containedGet 0 75 186
assign 1 75 186
iteratorGet 0 0 186
assign 1 75 186
hasNextGet 0 75 186
assign 1 75 186
nextGet 0 75 186
assign 1 77 186
heldGet 0 77 186
addValue 1 77 186
addValue 1 78 186
assign 1 80 186
new 0 80 186
delete 1 80 186
assign 1 81 186
heldGet 0 81 186
assign 1 81 186
new 2 81 186
heldSet 1 81 186
assign 1 82 186
iteratorGet 0 82 186
assign 1 82 186
hasNextGet 0 82 186
assign 1 83 186
nextGet 0 83 186
delete 0 84 186
assign 1 86 186
typenameGet 0 86 186
assign 1 86 186
IFGet 0 86 186
assign 1 86 186
equals 1 86 186
assign 1 87 186
def 1 87 186
assign 1 88 186
assign 1 89 186
def 1 89 186
assign 1 89 186
typenameGet 0 89 186
assign 1 89 186
ELIFGet 0 89 186
assign 1 89 186
equals 1 89 186
assign 1 0 186
assign 1 0 186
assign 1 0 186
assign 1 90 186
new 1 90 186
assign 1 91 186
ELSEGet 0 91 186
typenameSet 1 91 186
copyLoc 1 92 186
assign 1 93 186
new 1 93 186
copyLoc 1 94 186
assign 1 95 186
BRACESGet 0 95 186
typenameSet 1 95 186
assign 1 96 186
new 1 96 186
copyLoc 1 97 186
assign 1 98 186
IFGet 0 98 186
typenameSet 1 98 186
addValue 1 99 186
addValue 1 100 186
assign 1 101 186
containedGet 0 101 186
assign 1 101 186
def 1 101 186
assign 1 102 186
containedGet 0 102 186
assign 1 102 186
iteratorGet 0 102 186
assign 1 102 186
hasNextGet 0 102 186
assign 1 103 186
nextGet 0 103 186
addValue 1 103 186
addValue 1 110 186
assign 1 111 186
assign 1 112 186
nextPeerGet 0 112 186
delete 0 113 186
assign 1 114 186
assign 1 116 186
def 1 116 186
assign 1 116 186
typenameGet 0 116 186
assign 1 116 186
ELSEGet 0 116 186
assign 1 116 186
equals 1 116 186
assign 1 0 186
assign 1 0 186
assign 1 0 186
delete 0 117 186
addValue 1 118 186
assign 1 121 186
nextDescendGet 0 121 186
return 1 121 186
assign 1 122 186
typenameGet 0 122 186
assign 1 122 186
METHODGet 0 122 186
assign 1 122 186
equals 1 122 186
assign 1 123 186
containedGet 0 123 186
assign 1 123 186
firstGet 0 123 186
assign 1 124 186
new 1 124 186
copyLoc 1 125 186
assign 1 126 186
IDGet 0 126 186
typenameSet 1 126 186
assign 1 127 186
new 0 127 186
heldSet 1 127 186
prepend 1 128 186
assign 1 129 186
new 0 129 186
assign 1 130 186
new 0 130 186
assign 1 131 186
containedGet 0 131 186
assign 1 131 186
iteratorGet 0 131 186
assign 1 131 186
hasNextGet 0 131 186
assign 1 132 186
nextGet 0 132 186
assign 1 133 186
nextPeerGet 0 133 186
assign 1 136 186
typenameGet 0 136 186
assign 1 136 186
COMMAGet 0 136 186
assign 1 136 186
equals 1 136 186
addValue 1 137 186
assign 1 138 186
typenameGet 0 138 186
assign 1 138 186
IDGet 0 138 186
assign 1 138 186
equals 1 138 186
assign 1 139 186
new 0 139 186
assign 1 139 186
add 1 139 186
assign 1 140 186
new 0 140 186
assign 1 141 186
heldGet 0 141 186
nameSet 1 141 186
assign 1 142 186
new 0 142 186
isArgSet 1 142 186
heldSet 1 143 186
assign 1 144 186
VARGet 0 144 186
typenameSet 1 144 186
addVariable 0 145 186
assign 1 146 186
typenameGet 0 146 186
assign 1 146 186
VARGet 0 146 186
assign 1 146 186
equals 1 146 186
assign 1 147 186
typenameGet 0 147 186
assign 1 147 186
IDGet 0 147 186
assign 1 147 186
equals 1 147 186
assign 1 148 186
new 0 148 186
assign 1 148 186
add 1 148 186
assign 1 149 186
heldGet 0 149 186
assign 1 149 186
heldGet 0 149 186
nameSet 1 149 186
assign 1 150 186
heldGet 0 150 186
assign 1 150 186
new 0 150 186
isArgSet 1 150 186
addVariable 0 151 186
assign 1 152 186
COMMAGet 0 152 186
typenameSet 1 152 186
assign 1 154 186
new 0 154 186
assign 1 154 186
new 2 154 186
throw 1 154 186
assign 1 158 186
iteratorGet 0 158 186
assign 1 158 186
hasNextGet 0 158 186
assign 1 159 186
nextGet 0 159 186
delete 0 160 186
assign 1 162 186
heldGet 0 162 186
assign 1 163 186
new 0 163 186
assign 1 163 186
subtract 1 163 186
numargsSet 1 163 186
assign 1 164 186
nameGet 0 164 186
orgNameSet 1 164 186
assign 1 165 186
nameGet 0 165 186
assign 1 165 186
new 0 165 186
assign 1 165 186
add 1 165 186
assign 1 165 186
numargsGet 0 165 186
assign 1 165 186
toString 0 165 186
assign 1 165 186
add 1 165 186
nameSet 1 165 186
assign 1 166 186
secondGet 0 166 186
assign 1 167 186
typenameGet 0 167 186
assign 1 167 186
VARGet 0 167 186
assign 1 167 186
equals 1 167 186
resolveNp 0 168 186
assign 1 170 186
heldGet 0 170 186
rtypeSet 1 170 186
assign 1 171 186
rtypeGet 0 171 186
assign 1 171 186
namepathGet 0 171 186
assign 1 171 186
toString 0 171 186
assign 1 171 186
new 0 171 186
assign 1 171 186
equals 1 171 186
assign 1 172 186
rtypeGet 0 172 186
assign 1 172 186
new 0 172 186
isSelfSet 1 172 186
delete 0 174 186
assign 1 176 186
classGet 0 176 186
assign 1 177 186
heldGet 0 177 186
assign 1 177 186
methodsGet 0 177 186
assign 1 177 186
nameGet 0 177 186
put 2 177 186
assign 1 178 186
heldGet 0 178 186
assign 1 178 186
orderedMethodsGet 0 178 186
addValue 1 178 186
assign 1 180 186
nextDescendGet 0 180 186
return 1 180 186
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1755995201: return bem_transGet_0();
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 644675716: return bem_ntypesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 493012039: return bem_buildGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_5_BuildVisitPass6();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_5_BuildVisitPass6.bevs_inst = (BEC_5_5_5_BuildVisitPass6)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_5_BuildVisitPass6.bevs_inst;
}
}
