package be.BEL_4_Base;
/* File: source/build/CEmitter.be */
public class BEC_5_15_BuildCompilerProfile extends BEC_6_6_SystemObject {
public BEC_5_15_BuildCompilerProfile() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72,0x50,0x72,0x6F,0x66,0x69,0x6C,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2E,0x65,0x78,0x65};
private static byte[] bels_1 = {0x2E,0x6F};
private static byte[] bels_2 = {0x2D,0x49,0x20};
private static byte[] bels_3 = {0x2D,0x44,0x20};
private static byte[] bels_4 = {0x63};
private static byte[] bels_5 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43};
private static byte[] bels_6 = {0x67,0x63,0x63};
private static byte[] bels_7 = {0x67,0x63,0x63};
private static byte[] bels_8 = {0x67,0x63,0x63,0x20};
private static byte[] bels_9 = {0x2E,0x63};
private static byte[] bels_10 = {0x67,0x2B,0x2B};
private static byte[] bels_11 = {0x67,0x2B,0x2B,0x20};
private static byte[] bels_12 = {0x2E,0x63,0x70,0x70};
private static byte[] bels_13 = {0x63,0x2B,0x2B};
private static byte[] bels_14 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bels_15 = {0x61,0x70,0x67,0x63,0x63};
private static byte[] bels_16 = {0x61,0x70,0x67,0x63,0x63,0x20};
private static byte[] bels_17 = {0x2E,0x63};
private static byte[] bels_18 = {0x61,0x70,0x67,0x2B,0x2B};
private static byte[] bels_19 = {0x61,0x70,0x67,0x2B,0x2B,0x20};
private static byte[] bels_20 = {0x2E,0x63,0x70,0x70};
private static byte[] bels_21 = {0x63,0x2B,0x2B};
private static byte[] bels_22 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bels_23 = {0x6D,0x61,0x63,0x6F,0x73};
private static byte[] bels_24 = {0x2E,0x64,0x79,0x6C,0x69,0x62};
private static byte[] bels_25 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_25, 20));
private static byte[] bels_26 = {0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_26, 10));
private static byte[] bels_27 = {0x6C,0x69,0x62,0x74,0x6F,0x6F,0x6C,0x20,0x2D,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6C,0x63,0x63,0x5F,0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x20,0x2D,0x6F,0x20};
private static byte[] bels_28 = {0x20,0x2D,0x6F,0x20};
private static byte[] bels_29 = {0x63,0x70,0x20};
private static byte[] bels_30 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bels_31 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_31, 17));
private static byte[] bels_32 = {0x20,0x2D,0x6F,0x20};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_32, 4));
private static byte[] bels_33 = {0x6C,0x69,0x6E,0x75,0x78};
private static byte[] bels_34 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static byte[] bels_35 = {0x2E,0x73,0x6F};
private static byte[] bels_36 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_36, 20));
private static byte[] bels_37 = {0x20,0x2D,0x66,0x50,0x49,0x43,0x20};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_37, 7));
private static byte[] bels_38 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_38, 17));
private static byte[] bels_39 = {0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_39, 12));
private static byte[] bels_40 = {0x20,0x2D,0x6F,0x20};
private static byte[] bels_41 = {0x63,0x70,0x20};
private static byte[] bels_42 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bels_43 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x4E,0x49,0x58,0x20,0x2D,0x44,0x20};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_43, 17));
private static byte[] bels_44 = {0x20,0x2D,0x6F,0x20};
private static BEC_4_6_TextString bevo_9 = (new BEC_4_6_TextString(bels_44, 4));
private static byte[] bels_45 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_46 = {0x2E,0x65,0x78,0x65};
private static byte[] bels_47 = {0x6D,0x73,0x76,0x63};
private static byte[] bels_48 = {0x63,0x6C,0x20};
private static byte[] bels_49 = {0x2E,0x63,0x70,0x70};
private static byte[] bels_50 = {0x63,0x2B,0x2B};
private static byte[] bels_51 = {0x42,0x45,0x4E,0x4D,0x5F,0x44,0x43,0x50,0x50};
private static byte[] bels_52 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bels_53 = {0x2D,0x6E,0x6F,0x6C,0x6F,0x67,0x6F,0x20,0x2D,0x4D,0x44,0x20,0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x4D,0x53,0x56,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_53, 45));
private static byte[] bels_54 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x53,0x45,0x43,0x55,0x52,0x45,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20,0x2D,0x44,0x20,0x5F,0x43,0x52,0x54,0x5F,0x4E,0x4F,0x4E,0x53,0x54,0x44,0x43,0x5F,0x4E,0x4F,0x5F,0x44,0x45,0x50,0x52,0x45,0x43,0x41,0x54,0x45,0x20};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_54, 76));
private static byte[] bels_55 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x44,0x4C,0x4C,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bels_56 = {0x20,0x2D,0x46,0x6F};
private static byte[] bels_57 = {0x63,0x6F,0x70,0x79,0x20};
private static byte[] bels_58 = {0x6D,0x6B,0x64,0x69,0x72,0x20};
private static byte[] bels_59 = {0x6C,0x69,0x6E,0x6B,0x20,0x2D,0x4D,0x41,0x4E,0x49,0x46,0x45,0x53,0x54,0x20,0x2D,0x4F,0x55,0x54,0x3A};
private static byte[] bels_60 = {0x2E,0x6C,0x69,0x62};
private static byte[] bels_61 = {0x2E,0x64,0x6C,0x6C};
private static byte[] bels_62 = {0x2D,0x63,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_4_6_TextString bevo_12 = (new BEC_4_6_TextString(bels_62, 32));
private static byte[] bels_63 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20};
private static BEC_4_6_TextString bevo_13 = (new BEC_4_6_TextString(bels_63, 19));
private static byte[] bels_64 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x73,0x68,0x61,0x72,0x65,0x64,0x20,0x2D,0x6F,0x20};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_64, 37));
private static byte[] bels_65 = {0x20,0x2D,0x6F,0x20};
private static byte[] bels_66 = {0x63,0x70,0x20};
private static byte[] bels_67 = {0x6D,0x6B,0x64,0x69,0x72,0x20,0x2D,0x70,0x20};
private static byte[] bels_68 = {0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x47,0x43,0x43,0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x49,0x53,0x57,0x49,0x4E,0x20,0x2D,0x44,0x20};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_68, 29));
private static byte[] bels_69 = {0x20,0x2D,0x44,0x20,0x42,0x45,0x4E,0x4D,0x5F,0x44,0x4C,0x4C,0x45,0x58,0x50,0x4F,0x52,0x54,0x20,0x2D,0x6F,0x20};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_69, 22));
private static byte[] bels_70 = {0x65,0x78,0x65,0x45,0x78,0x74,0x4F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x5F};
private static BEC_4_6_TextString bevo_17 = (new BEC_4_6_TextString(bels_70, 15));
public static BEC_5_15_BuildCompilerProfile bevs_inst;
public BEC_4_6_TextString bevp_exeExt;
public BEC_4_6_TextString bevp_libExt;
public BEC_4_6_TextString bevp_ccObj;
public BEC_4_6_TextString bevp_cc;
public BEC_4_6_TextString bevp_cext;
public BEC_4_6_TextString bevp_oext;
public BEC_4_6_TextString bevp_lBuild;
public BEC_4_6_TextString bevp_ccout;
public BEC_4_6_TextString bevp_doCopy;
public BEC_4_6_TextString bevp_mkdirs;
public BEC_4_6_TextString bevp_lexe;
public BEC_4_6_TextString bevp_exeLibExt;
public BEC_4_6_TextString bevp_name;
public BEC_4_6_TextString bevp_di;
public BEC_4_6_TextString bevp_smac;
public BEC_4_6_TextString bevp_dialect;
public BEC_4_6_TextString bevp_compiler;
public BEC_5_15_BuildCompilerProfile bem_new_1(BEC_6_6_SystemObject beva_build) throws Throwable {
BEC_4_6_TextString bevl_dialectMacro = null;
BEC_6_6_SystemObject bevl_exeExtOverride = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_4_6_TextString bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_77_tmpvar_phold = null;
bevp_exeExt = (new BEC_4_6_TextString(4, bels_0));
bevt_2_tmpvar_phold = beva_build.bemd_0(515445972, BEL_4_Base.bevn_platformGet_0);
bevp_name = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_oext = (new BEC_4_6_TextString(2, bels_1));
bevp_di = (new BEC_4_6_TextString(3, bels_2));
bevp_smac = (new BEC_4_6_TextString(3, bels_3));
bevp_dialect = (new BEC_4_6_TextString(1, bels_4));
bevl_dialectMacro = (new BEC_4_6_TextString(7, bels_5));
bevt_4_tmpvar_phold = beva_build.bemd_0(549080104, BEL_4_Base.bevn_compilerGet_0);
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 851 */ {
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(3, bels_6));
beva_build.bemd_1(560162357, BEL_4_Base.bevn_compilerSet_1, bevt_5_tmpvar_phold);
} /* Line: 852 */
bevp_compiler = (BEC_4_6_TextString) beva_build.bemd_0(549080104, BEL_4_Base.bevn_compilerGet_0);
bevt_7_tmpvar_phold = beva_build.bemd_0(549080104, BEL_4_Base.bevn_compilerGet_0);
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(3, bels_7));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 855 */ {
bevp_cc = (new BEC_4_6_TextString(4, bels_8));
bevp_cext = (new BEC_4_6_TextString(2, bels_9));
} /* Line: 857 */
 else  /* Line: 855 */ {
bevt_10_tmpvar_phold = beva_build.bemd_0(549080104, BEL_4_Base.bevn_compilerGet_0);
bevt_11_tmpvar_phold = (new BEC_4_6_TextString(3, bels_10));
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 858 */ {
bevp_cc = (new BEC_4_6_TextString(4, bels_11));
bevp_cext = (new BEC_4_6_TextString(4, bels_12));
bevp_dialect = (new BEC_4_6_TextString(3, bels_13));
bevl_dialectMacro = (new BEC_4_6_TextString(9, bels_14));
} /* Line: 863 */
 else  /* Line: 855 */ {
bevt_13_tmpvar_phold = beva_build.bemd_0(549080104, BEL_4_Base.bevn_compilerGet_0);
bevt_14_tmpvar_phold = (new BEC_4_6_TextString(5, bels_15));
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_14_tmpvar_phold);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 864 */ {
bevp_cc = (new BEC_4_6_TextString(6, bels_16));
bevp_cext = (new BEC_4_6_TextString(2, bels_17));
} /* Line: 867 */
 else  /* Line: 855 */ {
bevt_16_tmpvar_phold = beva_build.bemd_0(549080104, BEL_4_Base.bevn_compilerGet_0);
bevt_17_tmpvar_phold = (new BEC_4_6_TextString(5, bels_18));
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 868 */ {
bevp_cc = (new BEC_4_6_TextString(6, bels_19));
bevp_cext = (new BEC_4_6_TextString(4, bels_20));
bevp_dialect = (new BEC_4_6_TextString(3, bels_21));
bevl_dialectMacro = (new BEC_4_6_TextString(9, bels_22));
} /* Line: 873 */
} /* Line: 855 */
} /* Line: 855 */
} /* Line: 855 */
bevt_20_tmpvar_phold = beva_build.bemd_0(515445972, BEL_4_Base.bevn_platformGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(5, bels_23));
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_21_tmpvar_phold);
if (bevt_18_tmpvar_phold != null && bevt_18_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_18_tmpvar_phold).bevi_bool) /* Line: 875 */ {
bevp_libExt = (new BEC_4_6_TextString(6, bels_24));
bevt_24_tmpvar_phold = bevo_0;
bevt_23_tmpvar_phold = bevp_cc.bem_add_1(bevt_24_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevl_dialectMacro);
bevt_25_tmpvar_phold = bevo_1;
bevp_ccObj = bevt_22_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevp_lBuild = (new BEC_4_6_TextString(33, bels_27));
bevp_ccout = (new BEC_4_6_TextString(4, bels_28));
bevp_doCopy = (new BEC_4_6_TextString(3, bels_29));
bevp_mkdirs = (new BEC_4_6_TextString(9, bels_30));
bevt_28_tmpvar_phold = bevo_2;
bevt_27_tmpvar_phold = bevp_cc.bem_add_1(bevt_28_tmpvar_phold);
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_add_1(bevl_dialectMacro);
bevt_29_tmpvar_phold = bevo_3;
bevp_lexe = bevt_26_tmpvar_phold.bem_add_1(bevt_29_tmpvar_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 883 */
bevt_32_tmpvar_phold = beva_build.bemd_0(515445972, BEL_4_Base.bevn_platformGet_0);
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpvar_phold = (new BEC_4_6_TextString(5, bels_33));
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_33_tmpvar_phold);
if (bevt_30_tmpvar_phold != null && bevt_30_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_30_tmpvar_phold).bevi_bool) /* Line: 885 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 885 */ {
bevt_36_tmpvar_phold = beva_build.bemd_0(515445972, BEL_4_Base.bevn_platformGet_0);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_37_tmpvar_phold = (new BEC_4_6_TextString(7, bels_34));
bevt_34_tmpvar_phold = bevt_35_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_37_tmpvar_phold);
if (bevt_34_tmpvar_phold != null && bevt_34_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_34_tmpvar_phold).bevi_bool) /* Line: 885 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 885 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 885 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 885 */ {
bevp_libExt = (new BEC_4_6_TextString(3, bels_35));
bevt_40_tmpvar_phold = bevo_4;
bevt_39_tmpvar_phold = bevp_cc.bem_add_1(bevt_40_tmpvar_phold);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_add_1(bevl_dialectMacro);
bevt_41_tmpvar_phold = bevo_5;
bevp_ccObj = bevt_38_tmpvar_phold.bem_add_1(bevt_41_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_6;
bevt_43_tmpvar_phold = bevp_cc.bem_add_1(bevt_44_tmpvar_phold);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bem_add_1(bevl_dialectMacro);
bevt_45_tmpvar_phold = bevo_7;
bevp_lBuild = bevt_42_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevp_ccout = (new BEC_4_6_TextString(4, bels_40));
bevp_doCopy = (new BEC_4_6_TextString(3, bels_41));
bevp_mkdirs = (new BEC_4_6_TextString(9, bels_42));
bevt_48_tmpvar_phold = bevo_8;
bevt_47_tmpvar_phold = bevp_cc.bem_add_1(bevt_48_tmpvar_phold);
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bem_add_1(bevl_dialectMacro);
bevt_49_tmpvar_phold = bevo_9;
bevp_lexe = bevt_46_tmpvar_phold.bem_add_1(bevt_49_tmpvar_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 893 */
bevt_52_tmpvar_phold = beva_build.bemd_0(515445972, BEL_4_Base.bevn_platformGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = (new BEC_4_6_TextString(5, bels_45));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_53_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 895 */ {
bevp_exeExt = (new BEC_4_6_TextString(4, bels_46));
bevt_55_tmpvar_phold = beva_build.bemd_0(549080104, BEL_4_Base.bevn_compilerGet_0);
bevt_56_tmpvar_phold = (new BEC_4_6_TextString(4, bels_47));
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_56_tmpvar_phold);
if (bevt_54_tmpvar_phold != null && bevt_54_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_54_tmpvar_phold).bevi_bool) /* Line: 897 */ {
bevp_cc = (new BEC_4_6_TextString(3, bels_48));
bevp_cext = (new BEC_4_6_TextString(4, bels_49));
bevp_dialect = (new BEC_4_6_TextString(3, bels_50));
bevl_dialectMacro = (new BEC_4_6_TextString(9, bels_51));
bevp_libExt = (new BEC_4_6_TextString(4, bels_52));
bevt_59_tmpvar_phold = bevo_10;
bevt_58_tmpvar_phold = bevp_cc.bem_add_1(bevt_59_tmpvar_phold);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bem_add_1(bevl_dialectMacro);
bevt_60_tmpvar_phold = bevo_11;
bevp_ccObj = bevt_57_tmpvar_phold.bem_add_1(bevt_60_tmpvar_phold);
bevp_lBuild = (new BEC_4_6_TextString(25, bels_55));
bevp_ccout = (new BEC_4_6_TextString(4, bels_56));
bevp_doCopy = (new BEC_4_6_TextString(5, bels_57));
bevp_mkdirs = (new BEC_4_6_TextString(6, bels_58));
bevp_lexe = (new BEC_4_6_TextString(20, bels_59));
bevp_exeLibExt = (new BEC_4_6_TextString(4, bels_60));
} /* Line: 909 */
 else  /* Line: 910 */ {
bevp_libExt = (new BEC_4_6_TextString(4, bels_61));
bevt_63_tmpvar_phold = bevo_12;
bevt_62_tmpvar_phold = bevp_cc.bem_add_1(bevt_63_tmpvar_phold);
bevt_61_tmpvar_phold = bevt_62_tmpvar_phold.bem_add_1(bevl_dialectMacro);
bevt_64_tmpvar_phold = bevo_13;
bevp_ccObj = bevt_61_tmpvar_phold.bem_add_1(bevt_64_tmpvar_phold);
bevt_65_tmpvar_phold = bevo_14;
bevp_lBuild = bevp_cc.bem_add_1(bevt_65_tmpvar_phold);
bevp_ccout = (new BEC_4_6_TextString(4, bels_65));
bevp_doCopy = (new BEC_4_6_TextString(3, bels_66));
bevp_mkdirs = (new BEC_4_6_TextString(9, bels_67));
bevt_68_tmpvar_phold = bevo_15;
bevt_67_tmpvar_phold = bevp_cc.bem_add_1(bevt_68_tmpvar_phold);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevl_dialectMacro);
bevt_69_tmpvar_phold = bevo_16;
bevp_lexe = bevt_66_tmpvar_phold.bem_add_1(bevt_69_tmpvar_phold);
bevp_exeLibExt = bevp_libExt;
} /* Line: 918 */
} /* Line: 897 */
bevt_70_tmpvar_phold = beva_build.bemd_0(1695168417, BEL_4_Base.bevn_paramsGet_0);
bevt_72_tmpvar_phold = bevo_17;
bevt_74_tmpvar_phold = beva_build.bemd_0(515445972, BEL_4_Base.bevn_platformGet_0);
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_71_tmpvar_phold = bevt_72_tmpvar_phold.bem_add_1(bevt_73_tmpvar_phold);
bevl_exeExtOverride = bevt_70_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_71_tmpvar_phold);
if (bevl_exeExtOverride == null) {
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_75_tmpvar_phold.bevi_bool) /* Line: 922 */ {
bevt_77_tmpvar_phold = bevl_exeExtOverride.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
if (bevt_77_tmpvar_phold == null) {
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpvar_phold.bevi_bool) /* Line: 922 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 922 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 922 */
 else  /* Line: 922 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 922 */ {
bevp_exeExt = (BEC_4_6_TextString) bevl_exeExtOverride.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 923 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_doMakeDirs_1(BEC_4_6_TextString beva_path) throws Throwable {
BEC_2_4_IOFile bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(beva_path);
bevt_0_tmpvar_phold.bem_makeDirs_0();
return this;
} /*method end*/
public BEC_4_6_TextString bem_exeExtGet_0() throws Throwable {
return bevp_exeExt;
} /*method end*/
public BEC_6_6_SystemObject bem_exeExtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeExt = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_libExtGet_0() throws Throwable {
return bevp_libExt;
} /*method end*/
public BEC_6_6_SystemObject bem_libExtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libExt = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_ccObjGet_0() throws Throwable {
return bevp_ccObj;
} /*method end*/
public BEC_6_6_SystemObject bem_ccObjSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccObj = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_ccGet_0() throws Throwable {
return bevp_cc;
} /*method end*/
public BEC_6_6_SystemObject bem_ccSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_cc = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_cextGet_0() throws Throwable {
return bevp_cext;
} /*method end*/
public BEC_6_6_SystemObject bem_cextSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_cext = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_oextGet_0() throws Throwable {
return bevp_oext;
} /*method end*/
public BEC_6_6_SystemObject bem_oextSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_oext = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_lBuildGet_0() throws Throwable {
return bevp_lBuild;
} /*method end*/
public BEC_6_6_SystemObject bem_lBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lBuild = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_ccoutGet_0() throws Throwable {
return bevp_ccout;
} /*method end*/
public BEC_6_6_SystemObject bem_ccoutSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccout = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_doCopyGet_0() throws Throwable {
return bevp_doCopy;
} /*method end*/
public BEC_6_6_SystemObject bem_doCopySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_doCopy = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_mkdirsGet_0() throws Throwable {
return bevp_mkdirs;
} /*method end*/
public BEC_6_6_SystemObject bem_mkdirsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mkdirs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_lexeGet_0() throws Throwable {
return bevp_lexe;
} /*method end*/
public BEC_6_6_SystemObject bem_lexeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lexe = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_exeLibExtGet_0() throws Throwable {
return bevp_exeLibExt;
} /*method end*/
public BEC_6_6_SystemObject bem_exeLibExtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeLibExt = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_6_6_SystemObject bem_nameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_name = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_diGet_0() throws Throwable {
return bevp_di;
} /*method end*/
public BEC_6_6_SystemObject bem_diSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_di = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_smacGet_0() throws Throwable {
return bevp_smac;
} /*method end*/
public BEC_6_6_SystemObject bem_smacSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_smac = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_dialectGet_0() throws Throwable {
return bevp_dialect;
} /*method end*/
public BEC_6_6_SystemObject bem_dialectSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dialect = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compiler = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {844, 845, 845, 846, 847, 848, 849, 850, 851, 851, 851, 852, 852, 854, 855, 855, 855, 856, 857, 858, 858, 858, 860, 861, 862, 863, 864, 864, 864, 866, 867, 868, 868, 868, 870, 871, 872, 873, 875, 875, 875, 875, 876, 877, 877, 877, 877, 877, 878, 879, 880, 881, 882, 882, 882, 882, 882, 883, 885, 885, 885, 885, 0, 885, 885, 885, 885, 0, 0, 886, 887, 887, 887, 887, 887, 888, 888, 888, 888, 888, 889, 890, 891, 892, 892, 892, 892, 892, 893, 895, 895, 895, 895, 896, 897, 897, 897, 898, 899, 900, 901, 902, 903, 903, 903, 903, 903, 904, 905, 906, 907, 908, 909, 911, 912, 912, 912, 912, 912, 913, 913, 914, 915, 916, 917, 917, 917, 917, 917, 918, 921, 921, 921, 921, 921, 921, 922, 922, 922, 922, 922, 0, 0, 0, 923, 928, 928, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 209, 210, 211, 213, 214, 215, 216, 218, 219, 222, 223, 224, 226, 227, 228, 229, 232, 233, 234, 236, 237, 240, 241, 242, 244, 245, 246, 247, 252, 253, 254, 255, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 274, 275, 276, 277, 279, 282, 283, 284, 285, 287, 290, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 315, 316, 317, 318, 320, 321, 322, 323, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 362, 363, 364, 365, 366, 367, 368, 373, 374, 375, 380, 381, 384, 388, 391, 397, 398, 402, 405, 409, 412, 416, 419, 423, 426, 430, 433, 437, 440, 444, 447, 451, 454, 458, 461, 465, 468, 472, 475, 479, 482, 486, 489, 493, 496, 500, 503, 507, 510, 514, 517};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 844 195
new 0 844 195
assign 1 845 196
platformGet 0 845 196
assign 1 845 197
nameGet 0 845 197
assign 1 846 198
new 0 846 198
assign 1 847 199
new 0 847 199
assign 1 848 200
new 0 848 200
assign 1 849 201
new 0 849 201
assign 1 850 202
new 0 850 202
assign 1 851 203
compilerGet 0 851 203
assign 1 851 204
undef 1 851 209
assign 1 852 210
new 0 852 210
compilerSet 1 852 211
assign 1 854 213
compilerGet 0 854 213
assign 1 855 214
compilerGet 0 855 214
assign 1 855 215
new 0 855 215
assign 1 855 216
equals 1 855 216
assign 1 856 218
new 0 856 218
assign 1 857 219
new 0 857 219
assign 1 858 222
compilerGet 0 858 222
assign 1 858 223
new 0 858 223
assign 1 858 224
equals 1 858 224
assign 1 860 226
new 0 860 226
assign 1 861 227
new 0 861 227
assign 1 862 228
new 0 862 228
assign 1 863 229
new 0 863 229
assign 1 864 232
compilerGet 0 864 232
assign 1 864 233
new 0 864 233
assign 1 864 234
equals 1 864 234
assign 1 866 236
new 0 866 236
assign 1 867 237
new 0 867 237
assign 1 868 240
compilerGet 0 868 240
assign 1 868 241
new 0 868 241
assign 1 868 242
equals 1 868 242
assign 1 870 244
new 0 870 244
assign 1 871 245
new 0 871 245
assign 1 872 246
new 0 872 246
assign 1 873 247
new 0 873 247
assign 1 875 252
platformGet 0 875 252
assign 1 875 253
nameGet 0 875 253
assign 1 875 254
new 0 875 254
assign 1 875 255
equals 1 875 255
assign 1 876 257
new 0 876 257
assign 1 877 258
new 0 877 258
assign 1 877 259
add 1 877 259
assign 1 877 260
add 1 877 260
assign 1 877 261
new 0 877 261
assign 1 877 262
add 1 877 262
assign 1 878 263
new 0 878 263
assign 1 879 264
new 0 879 264
assign 1 880 265
new 0 880 265
assign 1 881 266
new 0 881 266
assign 1 882 267
new 0 882 267
assign 1 882 268
add 1 882 268
assign 1 882 269
add 1 882 269
assign 1 882 270
new 0 882 270
assign 1 882 271
add 1 882 271
assign 1 883 272
assign 1 885 274
platformGet 0 885 274
assign 1 885 275
nameGet 0 885 275
assign 1 885 276
new 0 885 276
assign 1 885 277
equals 1 885 277
assign 1 0 279
assign 1 885 282
platformGet 0 885 282
assign 1 885 283
nameGet 0 885 283
assign 1 885 284
new 0 885 284
assign 1 885 285
equals 1 885 285
assign 1 0 287
assign 1 0 290
assign 1 886 294
new 0 886 294
assign 1 887 295
new 0 887 295
assign 1 887 296
add 1 887 296
assign 1 887 297
add 1 887 297
assign 1 887 298
new 0 887 298
assign 1 887 299
add 1 887 299
assign 1 888 300
new 0 888 300
assign 1 888 301
add 1 888 301
assign 1 888 302
add 1 888 302
assign 1 888 303
new 0 888 303
assign 1 888 304
add 1 888 304
assign 1 889 305
new 0 889 305
assign 1 890 306
new 0 890 306
assign 1 891 307
new 0 891 307
assign 1 892 308
new 0 892 308
assign 1 892 309
add 1 892 309
assign 1 892 310
add 1 892 310
assign 1 892 311
new 0 892 311
assign 1 892 312
add 1 892 312
assign 1 893 313
assign 1 895 315
platformGet 0 895 315
assign 1 895 316
nameGet 0 895 316
assign 1 895 317
new 0 895 317
assign 1 895 318
equals 1 895 318
assign 1 896 320
new 0 896 320
assign 1 897 321
compilerGet 0 897 321
assign 1 897 322
new 0 897 322
assign 1 897 323
equals 1 897 323
assign 1 898 325
new 0 898 325
assign 1 899 326
new 0 899 326
assign 1 900 327
new 0 900 327
assign 1 901 328
new 0 901 328
assign 1 902 329
new 0 902 329
assign 1 903 330
new 0 903 330
assign 1 903 331
add 1 903 331
assign 1 903 332
add 1 903 332
assign 1 903 333
new 0 903 333
assign 1 903 334
add 1 903 334
assign 1 904 335
new 0 904 335
assign 1 905 336
new 0 905 336
assign 1 906 337
new 0 906 337
assign 1 907 338
new 0 907 338
assign 1 908 339
new 0 908 339
assign 1 909 340
new 0 909 340
assign 1 911 343
new 0 911 343
assign 1 912 344
new 0 912 344
assign 1 912 345
add 1 912 345
assign 1 912 346
add 1 912 346
assign 1 912 347
new 0 912 347
assign 1 912 348
add 1 912 348
assign 1 913 349
new 0 913 349
assign 1 913 350
add 1 913 350
assign 1 914 351
new 0 914 351
assign 1 915 352
new 0 915 352
assign 1 916 353
new 0 916 353
assign 1 917 354
new 0 917 354
assign 1 917 355
add 1 917 355
assign 1 917 356
add 1 917 356
assign 1 917 357
new 0 917 357
assign 1 917 358
add 1 917 358
assign 1 918 359
assign 1 921 362
paramsGet 0 921 362
assign 1 921 363
new 0 921 363
assign 1 921 364
platformGet 0 921 364
assign 1 921 365
nameGet 0 921 365
assign 1 921 366
add 1 921 366
assign 1 921 367
get 1 921 367
assign 1 922 368
def 1 922 373
assign 1 922 374
firstGet 0 922 374
assign 1 922 375
def 1 922 380
assign 1 0 381
assign 1 0 384
assign 1 0 388
assign 1 923 391
firstGet 0 923 391
assign 1 928 397
new 1 928 397
makeDirs 0 928 398
return 1 0 402
assign 1 0 405
return 1 0 409
assign 1 0 412
return 1 0 416
assign 1 0 419
return 1 0 423
assign 1 0 426
return 1 0 430
assign 1 0 433
return 1 0 437
assign 1 0 440
return 1 0 444
assign 1 0 447
return 1 0 451
assign 1 0 454
return 1 0 458
assign 1 0 461
return 1 0 465
assign 1 0 468
return 1 0 472
assign 1 0 475
return 1 0 479
assign 1 0 482
return 1 0 486
assign 1 0 489
return 1 0 493
assign 1 0 496
return 1 0 500
assign 1 0 503
return 1 0 507
assign 1 0 510
return 1 0 514
assign 1 0 517
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 398213815: return bem_cextGet_0();
case 1630809090: return bem_diGet_0();
case 792491207: return bem_ccoutGet_0();
case 1081412016: return bem_many_0();
case 1560610755: return bem_mkdirsGet_0();
case 1914544405: return bem_smacGet_0();
case 1431211032: return bem_exeExtGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1211273660: return bem_nameGet_0();
case 786424307: return bem_tagGet_0();
case 452600121: return bem_doCopyGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 85127937: return bem_lexeGet_0();
case 1308786538: return bem_echo_0();
case 703234373: return bem_lBuildGet_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1791921921: return bem_dialectGet_0();
case 696839344: return bem_ccObjGet_0();
case 1517584779: return bem_libExtGet_0();
case 612830891: return bem_oextGet_0();
case 549080104: return bem_compilerGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1327497191: return bem_exeLibExtGet_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 571530503: return bem_ccGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1222355913: return bem_nameSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 57864655: return bem_doMakeDirs_1((BEC_4_6_TextString) bevd_0);
case 781408954: return bem_ccoutSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 1641891343: return bem_diSet_1(bevd_0);
case 582612756: return bem_ccSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 96210190: return bem_lexeSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1316414938: return bem_exeLibExtSet_1(bevd_0);
case 1903462152: return bem_smacSet_1(bevd_0);
case 1803004174: return bem_dialectSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 601748638: return bem_oextSet_1(bevd_0);
case 685757091: return bem_ccObjSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 387131562: return bem_cextSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 441517868: return bem_doCopySet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 714316626: return bem_lBuildSet_1(bevd_0);
case 1571693008: return bem_mkdirsSet_1(bevd_0);
case 1528667032: return bem_libExtSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1442293285: return bem_exeExtSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_15_BuildCompilerProfile();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_15_BuildCompilerProfile.bevs_inst = (BEC_5_15_BuildCompilerProfile)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_15_BuildCompilerProfile.bevs_inst;
}
}
