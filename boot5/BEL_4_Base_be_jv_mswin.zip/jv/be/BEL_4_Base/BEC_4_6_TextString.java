package be.BEL_4_Base;
/* File: source/base/String.be */
public class BEC_4_6_TextString extends BEC_6_6_SystemObject {
public BEC_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_4_6_TextString(byte[] bevi_bytes) {
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_bytes.length);
    }
    public BEC_4_6_TextString(byte[] bevi_bytes, int bevi_length) {
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_length);
    }
    public BEC_4_6_TextString(int bevi_length, byte[] bevi_bytes) {
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_length);
    }
    public BEC_4_6_TextString(String bevi_string) throws Exception {
        byte[] bevi_bytes = bevi_string.getBytes("UTF-8");
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_bytes.length);
    }
    public String bems_toJvString() throws Exception {
        String jvString = new String(bevi_bytes, 0, bevp_size.bevi_int, "UTF-8");
        return jvString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x42,0x75,0x66,0x66,0x65,0x72,0x20,0x72,0x65,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static byte[] bels_1 = {0x0A};
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_8 = (new BEC_4_3_MathInt(57));
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(48));
private static BEC_4_3_MathInt bevo_10 = (new BEC_4_3_MathInt(64));
private static BEC_4_3_MathInt bevo_11 = (new BEC_4_3_MathInt(91));
private static BEC_4_3_MathInt bevo_12 = (new BEC_4_3_MathInt(96));
private static BEC_4_3_MathInt bevo_13 = (new BEC_4_3_MathInt(123));
private static BEC_4_3_MathInt bevo_14 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_15 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_16 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_17 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_18 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_19 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_20 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_21 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_22 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_23 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_24 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_25 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_26 = (new BEC_4_3_MathInt(-1));
private static BEC_4_3_MathInt bevo_27 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_28 = (new BEC_4_3_MathInt(0));
private static byte[] bels_2 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_4_3_MathInt bevo_29 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_30 = (new BEC_4_3_MathInt(1));
public static BEC_4_6_TextString bevs_inst;
public BEC_6_6_SystemObject bevp_vstring;
public BEC_4_3_MathInt bevp_size;
public BEC_4_3_MathInt bevp_capacity;
public BEC_4_3_MathInt bevp_leni;
public BEC_4_3_MathInt bevp_sizi;
public BEC_6_6_SystemObject bem_vstringGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_vstringSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_new_1(BEC_4_3_MathInt beva__capacity) throws Throwable {
this.bem_capacitySet_1(beva__capacity);
bevp_size = (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_4_6_TextString bem_new_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_4_6_TextString bem_capacitySet_1(BEC_4_3_MathInt beva_ncap) throws Throwable {
BEC_4_6_TextString bevl_failed = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
if (bevp_capacity == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_3_tmpvar_phold = bevp_capacity.bem_equals_1(beva_ncap);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 204 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 204 */
 else  /* Line: 204 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 204 */ {
return this;
} /* Line: 205 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        this.bevi_bytes = java.util.Arrays.copyOf(this.bevi_bytes, beva_ncap.bevi_int);
      }
      if (bevl_failed == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 256 */ {
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(26, bels_0));
bevt_5_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 257 */
if (bevp_size == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 259 */ {
bevt_8_tmpvar_phold = bevp_size.bem_greater_1(beva_ncap);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 259 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 259 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 259 */ {
bevp_size = (BEC_4_3_MathInt) beva_ncap.bem_copy_0();
} /* Line: 260 */
bevp_capacity = beva_ncap;
return this;
} /*method end*/
public BEC_4_6_TextString bem_hexNew_1(BEC_4_6_TextString beva_val) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevp_size = (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_setHex_2(bevt_1_tmpvar_phold, beva_val);
return this;
} /*method end*/
public BEC_4_6_TextString bem_getHex_1(BEC_4_3_MathInt beva_pos) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_0();
bevt_1_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
bevt_4_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevt_5_tmpvar_phold = (new BEC_4_3_MathInt(16));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_toString_3(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_setHex_2(BEC_4_3_MathInt beva_pos, BEC_4_6_TextString beva_hval) throws Throwable {
BEC_4_3_MathInt bevl_val = null;
bevl_val = (new BEC_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_4_6_TextString bem_addValue_1(BEC_6_6_SystemObject beva_astr) throws Throwable {
BEC_4_6_TextString bevl_str = null;
BEC_4_3_MathInt bevl_nsize = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_5_SystemTypes bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_6_5_SystemTypes) BEC_6_5_SystemTypes.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_stringGet_0();
bevt_1_tmpvar_phold = beva_astr.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevl_str = (BEC_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 282 */
 else  /* Line: 283 */ {
bevl_str = (BEC_4_6_TextString) beva_astr;
} /* Line: 284 */
if (bevp_leni == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 286 */ {
bevp_leni = (new BEC_4_3_MathInt()).bem_new_0();
bevp_sizi = (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 288 */
bevt_5_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bem_setValue_1(bevt_5_tmpvar_phold);
bevp_sizi.bem_addValue_1(bevp_size);
bevt_6_tmpvar_phold = bevp_capacity.bem_lesser_1(bevp_sizi);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_9_tmpvar_phold = bevo_0;
bevt_8_tmpvar_phold = bevp_sizi.bem_add_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_1;
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_multiply_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_2;
bevl_nsize = bevt_7_tmpvar_phold.bem_divide_1(bevt_11_tmpvar_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 295 */
bevt_12_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_13_tmpvar_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_12_tmpvar_phold, bevt_13_tmpvar_phold, bevp_size);
return this;
} /*method end*/
public BEC_4_6_TextString bem_readBuffer_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_readString_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_write_1(BEC_6_6_SystemObject beva_stri) throws Throwable {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_writeTo_1(BEC_6_6_SystemObject beva_w) throws Throwable {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_close_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_extractString_0() throws Throwable {
BEC_4_6_TextString bevl_str = null;
bevl_str = (BEC_4_6_TextString) this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_4_6_TextString bem_clear_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevp_size.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 331 */ {
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_setIntUnchecked_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevp_size = (new BEC_4_3_MathInt(0));
} /* Line: 333 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_codeNew_1(BEC_6_6_SystemObject beva_codei) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevp_size = (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_setCodeUnchecked_2(bevt_1_tmpvar_phold, (BEC_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public BEC_4_6_TextString bem_chomp_0() throws Throwable {
BEC_4_6_TextString bevl_nl = null;
BEC_6_15_SystemCurrentPlatform bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpvar_phold.bem_newlineGet_0();
bevt_1_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_5_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevp_size.bem_subtract_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = this.bem_substring_2(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 346 */
bevl_nl = (new BEC_4_6_TextString(1, bels_1));
bevt_6_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 349 */ {
bevt_8_tmpvar_phold = bevo_5;
bevt_10_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevp_size.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_substring_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
return bevt_7_tmpvar_phold;
} /* Line: 350 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_4_6_TextString bevl_c = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_c = (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_c.bem_addValue_1(this);
return bevl_c;
} /*method end*/
public BEC_5_4_LogicBool bem_begins_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 363 */ {
bevt_3_tmpvar_phold = bevo_7;
bevt_2_tmpvar_phold = bevl_found.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 363 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 363 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 363 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 364 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_ends_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 370 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 370 */
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevp_size.bem_subtract_1(bevt_3_tmpvar_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpvar_phold);
if (bevl_found == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 372 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 373 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_has_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_str == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 379 */ {
bevt_3_tmpvar_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 379 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 379 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 379 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 379 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 380 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isInteger_0() throws Throwable {
BEC_4_3_MathInt bevl_ic = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
bevl_ic = (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 387 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 387 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevl_ic.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 389 */ {
bevt_5_tmpvar_phold = bevo_9;
bevt_4_tmpvar_phold = bevl_ic.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 389 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 389 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 389 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 390 */
bevl_j.bem_incrementValue_0();
} /* Line: 387 */
 else  /* Line: 387 */ {
break;
} /* Line: 387 */
} /* Line: 387 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_lowerValue_0() throws Throwable {
BEC_4_3_MathInt bevl_vc = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 398 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 398 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 400 */ {
bevt_5_tmpvar_phold = bevo_11;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 400 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 400 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 400 */
 else  /* Line: 400 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 400 */ {
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(32));
bevl_vc.bem_addValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 402 */
bevl_j.bem_incrementValue_0();
} /* Line: 398 */
 else  /* Line: 398 */ {
break;
} /* Line: 398 */
} /* Line: 398 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_lower_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1903477087, BEL_4_Base.bevn_lowerValue_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_upperValue_0() throws Throwable {
BEC_4_3_MathInt bevl_vc = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 413 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 413 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_12;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 415 */ {
bevt_5_tmpvar_phold = bevo_13;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 415 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 415 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 415 */
 else  /* Line: 415 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 415 */ {
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 417 */
bevl_j.bem_incrementValue_0();
} /* Line: 413 */
 else  /* Line: 413 */ {
break;
} /* Line: 413 */
} /* Line: 413 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_upper_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1163089440, BEL_4_Base.bevn_upperValue_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_swap_2(BEC_4_6_TextString beva_from, BEC_4_6_TextString beva_to) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = this.bem_split_1(beva_from);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_to, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_getPoint_1(BEC_4_3_MathInt beva_posi) throws Throwable {
BEC_4_6_TextString bevl_buf = null;
BEC_6_6_SystemObject bevl_j = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_6_TextString bevl_y = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevl_buf = (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 434 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_posi);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 434 */ {
bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 434 */
 else  /* Line: 434 */ {
break;
} /* Line: 434 */
} /* Line: 434 */
bevt_2_tmpvar_phold = bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_y = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
return bevl_y;
} /*method end*/
public BEC_4_3_MathInt bem_hashValue_1(BEC_4_3_MathInt beva_into) throws Throwable {
BEC_4_3_MathInt bevl_c = null;
BEC_4_3_MathInt bevl_j = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_c = (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
beva_into.bem_setValue_1(bevt_0_tmpvar_phold);
bevl_j = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 444 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 444 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpvar_phold);
beva_into.bem_addValue_1(bevl_c);
bevl_j.bem_incrementValue_0();
} /* Line: 444 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
bevt_3_tmpvar_phold = beva_into.bem_absValue_0();
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_hashValue_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_getCode_1(BEC_4_3_MathInt beva_pos) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_getInt_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_14;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 467 */
 else  /* Line: 467 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 467 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 487 */
 else  /* Line: 495 */ {
return null;
} /* Line: 496 */
return beva_into;
} /*method end*/
public BEC_4_3_MathInt bem_getCode_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_15;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 509 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 509 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 509 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 509 */
 else  /* Line: 509 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 509 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int < 0) {
            beva_into.bevi_int += 256;
         }
         } /* Line: 533 */
 else  /* Line: 538 */ {
return null;
} /* Line: 539 */
return beva_into;
} /*method end*/
public BEC_4_6_TextString bem_setInt_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_16;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 545 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 545 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 545 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 545 */
 else  /* Line: 545 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 545 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 546 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_setCode_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_17;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 551 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 551 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 551 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 551 */
 else  /* Line: 551 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 551 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 552 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevp_size.bem_lesserEquals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 557 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 558 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_setIntUnchecked_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_4_6_TextString bem_setCodeUnchecked_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b > 127) {
        twvls_b -= 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_4_3_MathInt bem_reverseFind_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_rfind_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevl_rpos = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(800915430, BEL_4_Base.bevn_reverseBytes_0);
bevt_3_tmpvar_phold = beva_str.bem_copy_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(800915430, BEL_4_Base.bevn_reverseBytes_0);
bevl_rpos = (BEC_4_3_MathInt) bevt_0_tmpvar_phold.bemd_1(1274448085, BEL_4_Base.bevn_find_1, bevt_2_tmpvar_phold);
if (bevl_rpos == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 651 */ {
bevt_5_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpvar_phold;
} /* Line: 653 */
return null;
} /*method end*/
public BEC_4_3_MathInt bem_find_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_19;
bevt_0_tmpvar_phold = this.bem_find_2(beva_str, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_find_2(BEC_4_6_TextString beva_str, BEC_4_3_MathInt beva_start) throws Throwable {
BEC_4_3_MathInt bevl_end = null;
BEC_4_3_MathInt bevl_current = null;
BEC_4_3_MathInt bevl_myval = null;
BEC_4_3_MathInt bevl_strfirst = null;
BEC_4_3_MathInt bevl_strsize = null;
BEC_4_3_MathInt bevl_strval = null;
BEC_4_3_MathInt bevl_current2 = null;
BEC_4_3_MathInt bevl_end2 = null;
BEC_4_3_MathInt bevl_currentstr2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
if (beva_str == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
if (beva_start == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_9_tmpvar_phold = bevo_20;
bevt_8_tmpvar_phold = beva_start.bem_lesser_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_10_tmpvar_phold = beva_start.bem_greaterEquals_1(bevp_size);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_12_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_greater_1(bevp_size);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_14_tmpvar_phold = bevo_21;
bevt_13_tmpvar_phold = bevp_size.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_16_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpvar_phold = bevo_22;
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 665 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 665 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 665 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 665 */ {
return null;
} /* Line: 666 */
bevl_end = bevp_size;
bevl_current = (BEC_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (new BEC_4_3_MathInt()).bem_new_0();
bevl_strfirst = (new BEC_4_3_MathInt()).bem_new_0();
bevt_18_tmpvar_phold = (new BEC_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpvar_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpvar_phold = bevo_23;
bevt_19_tmpvar_phold = bevl_strsize.bem_greater_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 677 */ {
bevl_strval = (new BEC_4_3_MathInt()).bem_new_0();
bevl_current2 = (new BEC_4_3_MathInt()).bem_new_0();
bevl_end2 = (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 680 */
while (true)
 /* Line: 683 */ {
bevt_21_tmpvar_phold = bevl_current.bem_lesser_1(bevl_end);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 683 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
bevt_22_tmpvar_phold = bevl_myval.bem_equals_1(bevl_strfirst);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 685 */ {
bevt_24_tmpvar_phold = bevo_24;
bevt_23_tmpvar_phold = bevl_strsize.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 686 */ {
return bevl_current;
} /* Line: 687 */
bevl_current2.bem_setValue_1(bevl_current);
bevl_current2.bem_incrementValue_0();
bevl_end2.bem_setValue_1(bevl_current);
bevt_25_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_end2.bem_addValue_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_end2.bem_greater_1(bevp_size);
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 693 */ {
return null;
} /* Line: 694 */
bevl_currentstr2 = (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 697 */ {
bevt_27_tmpvar_phold = bevl_current2.bem_lesser_1(bevl_end2);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 697 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
bevt_28_tmpvar_phold = bevl_myval.bem_notEquals_1(bevl_strval);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 700 */ {
break;
} /* Line: 701 */
bevl_current2.bem_incrementValue_0();
bevl_currentstr2.bem_incrementValue_0();
} /* Line: 704 */
 else  /* Line: 697 */ {
break;
} /* Line: 697 */
} /* Line: 697 */
bevt_29_tmpvar_phold = bevl_current2.bem_equals_1(bevl_end2);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 706 */ {
return bevl_current;
} /* Line: 707 */
} /* Line: 706 */
bevl_current.bem_incrementValue_0();
} /* Line: 710 */
 else  /* Line: 683 */ {
break;
} /* Line: 683 */
} /* Line: 683 */
return null;
} /*method end*/
public BEC_6_6_SystemObject bem_split_1(BEC_4_6_TextString beva_delim) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_splits = null;
BEC_4_3_MathInt bevl_last = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_ds = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevl_splits = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 720 */ {
if (bevl_i == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 720 */ {
bevt_1_tmpvar_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpvar_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 723 */
 else  /* Line: 720 */ {
break;
} /* Line: 720 */
} /* Line: 720 */
bevt_2_tmpvar_phold = bevl_last.bem_lesser_1(bevp_size);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 725 */ {
bevt_3_tmpvar_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 726 */
return bevl_splits;
} /*method end*/
public BEC_4_6_TextString bem_join_2(BEC_4_6_TextString beva_delim, BEC_6_6_SystemObject beva_splits) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_splitLines_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_9_TextTokenizer bevt_1_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lineSplitterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_tokenize_1(this);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_3_MathInt bem_compare_1(BEC_6_6_SystemObject beva_stri) throws Throwable {
BEC_4_3_MathInt bevl_mysize = null;
BEC_4_3_MathInt bevl_osize = null;
BEC_4_3_MathInt bevl_maxsize = null;
BEC_4_3_MathInt bevl_myret = null;
BEC_4_3_MathInt bevl_mv = null;
BEC_4_3_MathInt bevl_ov = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 748 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 748 */ {
bevt_2_tmpvar_phold = beva_stri.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 748 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 748 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 748 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 748 */ {
return null;
} /* Line: 749 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevt_3_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 753 */ {
bevl_maxsize = bevl_osize;
} /* Line: 754 */
 else  /* Line: 755 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 756 */
bevl_myret = (new BEC_4_3_MathInt()).bem_new_0();
bevl_mv = (new BEC_4_3_MathInt()).bem_new_0();
bevl_ov = (new BEC_4_3_MathInt()).bem_new_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 761 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(bevl_maxsize);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 761 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
bevt_5_tmpvar_phold = bevl_mv.bem_notEquals_1(bevl_ov);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 764 */ {
bevt_6_tmpvar_phold = bevl_mv.bem_greater_1(bevl_ov);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 765 */ {
bevt_7_tmpvar_phold = (new BEC_4_3_MathInt(1));
return bevt_7_tmpvar_phold;
} /* Line: 766 */
 else  /* Line: 767 */ {
bevt_8_tmpvar_phold = (new BEC_4_3_MathInt(-1));
return bevt_8_tmpvar_phold;
} /* Line: 768 */
} /* Line: 765 */
bevl_i.bem_incrementValue_0();
} /* Line: 761 */
 else  /* Line: 761 */ {
break;
} /* Line: 761 */
} /* Line: 761 */
bevt_10_tmpvar_phold = bevo_25;
bevt_9_tmpvar_phold = bevl_myret.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 772 */ {
bevt_11_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 773 */ {
bevl_myret = (new BEC_4_3_MathInt(1));
} /* Line: 774 */
 else  /* Line: 773 */ {
bevt_12_tmpvar_phold = bevl_osize.bem_greater_1(bevl_mysize);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 775 */ {
bevl_myret = (new BEC_4_3_MathInt(-1));
} /* Line: 776 */
} /* Line: 773 */
} /* Line: 773 */
return bevl_myret;
} /*method end*/
public BEC_5_4_LogicBool bem_lesser_1(BEC_4_6_TextString beva_stri) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 783 */ {
return null;
} /* Line: 783 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_26;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 784 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 785 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_greater_1(BEC_4_6_TextString beva_stri) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 791 */ {
return null;
} /* Line: 791 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_27;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 792 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 793 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_stri) throws Throwable {
BEC_4_3_MathInt bevl_mysize = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 806 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 807 */

  if (beva_stri instanceof BEC_4_6_TextString) {
    BEC_4_6_TextString bevls_stri = (BEC_4_6_TextString) beva_stri;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BELS_Base.BECS_Runtime.boolFalse;
          }
       }
       return be.BELS_Base.BECS_Runtime.boolTrue;
   }
  }
  bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_str) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_str);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_add_1(BEC_6_6_SystemObject beva_astr) throws Throwable {
BEC_4_6_TextString bevl_str = null;
BEC_4_6_TextString bevl_res = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_5_SystemTypes bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
bevt_3_tmpvar_phold = (BEC_6_5_SystemTypes) BEC_6_5_SystemTypes.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_stringGet_0();
bevt_1_tmpvar_phold = beva_astr.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 875 */ {
bevl_str = (BEC_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 876 */
 else  /* Line: 877 */ {
bevl_str = (BEC_4_6_TextString) beva_astr;
} /* Line: 878 */
bevt_5_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevp_size.bem_add_1(bevt_5_tmpvar_phold);
bevl_res = (new BEC_4_6_TextString()).bem_new_1(bevt_4_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_7_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_6_tmpvar_phold, bevp_size, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_9_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold, bevp_size);
return bevl_res;
} /*method end*/
public BEC_6_6_SystemObject bem_create_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_copyValue_4(BEC_4_6_TextString beva_org, BEC_4_3_MathInt beva_starti, BEC_4_3_MathInt beva_endi, BEC_4_3_MathInt beva_dstarti) throws Throwable {
BEC_4_3_MathInt bevl_mleni = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_9_SystemException bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_28;
bevt_1_tmpvar_phold = beva_starti.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 911 */ {
bevt_4_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_3_tmpvar_phold = beva_starti.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 911 */ {
bevt_6_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_5_tmpvar_phold = beva_endi.bem_greater_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 911 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 911 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 911 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 911 */ {
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(31, bels_2));
bevt_7_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_8_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 912 */
 else  /* Line: 913 */ {
if (bevp_leni == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 916 */ {
bevp_leni = (new BEC_4_3_MathInt()).bem_new_0();
bevp_sizi = (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 918 */
bevp_leni.bem_setValue_1(beva_endi);
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bem_setValue_1(beva_dstarti);
bevp_sizi.bem_addValue_1(bevp_leni);
bevt_10_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_capacity);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 927 */ {
bevt_11_tmpvar_phold = bevp_sizi.bem_copy_0();
this.bem_capacitySet_1((BEC_4_3_MathInt) bevt_11_tmpvar_phold);
} /* Line: 928 */

         //source, sourceStart, dest, destStart, length
         System.arraycopy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         bevt_12_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_size);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 983 */ {
bevp_size = (BEC_4_3_MathInt) bevp_sizi.bem_copy_0();
} /* Line: 987 */
return this;
} /* Line: 989 */
} /*method end*/
public BEC_4_6_TextString bem_substring_1(BEC_4_3_MathInt beva_starti) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sizeGet_0();
bevt_0_tmpvar_phold = this.bem_substring_2(beva_starti, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_substring_2(BEC_4_3_MathInt beva_starti, BEC_4_3_MathInt beva_endi) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_output_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevi_bytes.length - 1);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_print_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevp_size.bevi_int);
System.out.write('\n');
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_echo_0() throws Throwable {
this.bem_output_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_12_TextByteIterator bem_byteIteratorGet_0() throws Throwable {
BEC_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() throws Throwable {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_12_TextByteIterator bem_biterGet_0() throws Throwable {
BEC_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_17_TextMultiByteIterator bem_mbiterGet_0() throws Throwable {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_serializeToString_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
if (beva_snw == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1111 */ {
this.bem_new_0();
} /* Line: 1112 */
 else  /* Line: 1113 */ {
bevt_2_tmpvar_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevo_29;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
this.bem_new_1(bevt_1_tmpvar_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1115 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_strip_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_strip_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_reverseBytes_0() throws Throwable {
BEC_4_3_MathInt bevl_vb = null;
BEC_4_3_MathInt bevl_ve = null;
BEC_4_3_MathInt bevl_b = null;
BEC_4_3_MathInt bevl_e = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevl_vb = (new BEC_4_3_MathInt()).bem_new_0();
bevl_ve = (new BEC_4_3_MathInt()).bem_new_0();
bevl_b = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = bevo_30;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpvar_phold);
while (true)
 /* Line: 1132 */ {
bevt_1_tmpvar_phold = bevl_e.bem_greater_1(bevl_b);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1132 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bem_incrementValue_0();
bevl_e.bem_decrementValue_0();
} /* Line: 1138 */
 else  /* Line: 1132 */ {
break;
} /* Line: 1132 */
} /* Line: 1132 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_vstringSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_vstring = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_4_3_MathInt bem_leniGet_0() throws Throwable {
return bevp_leni;
} /*method end*/
public BEC_6_6_SystemObject bem_leniSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_leni = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_siziGet_0() throws Throwable {
return bevp_sizi;
} /*method end*/
public BEC_6_6_SystemObject bem_siziSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sizi = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {176, 186, 190, 190, 204, 204, 204, 0, 0, 0, 205, 256, 256, 257, 257, 257, 259, 259, 0, 259, 0, 0, 260, 262, 266, 266, 267, 268, 268, 272, 272, 272, 272, 272, 272, 272, 276, 277, 281, 281, 281, 281, 282, 284, 286, 286, 287, 288, 290, 290, 291, 293, 294, 294, 294, 294, 294, 294, 295, 297, 297, 297, 302, 306, 310, 314, 325, 326, 327, 331, 331, 332, 332, 332, 333, 338, 338, 339, 340, 340, 344, 344, 345, 346, 346, 346, 346, 346, 348, 349, 350, 350, 350, 350, 350, 352, 356, 356, 356, 357, 358, 362, 363, 363, 0, 363, 363, 0, 0, 364, 364, 366, 366, 370, 370, 370, 370, 371, 371, 371, 372, 372, 373, 373, 375, 375, 379, 379, 0, 379, 379, 379, 0, 0, 380, 380, 382, 382, 386, 387, 387, 388, 389, 389, 0, 389, 389, 0, 0, 390, 390, 387, 393, 393, 397, 398, 398, 399, 400, 400, 400, 400, 0, 0, 0, 401, 401, 402, 398, 408, 408, 408, 412, 413, 413, 414, 415, 415, 415, 415, 0, 0, 0, 416, 416, 417, 413, 423, 423, 423, 427, 427, 427, 427, 432, 432, 433, 434, 434, 435, 434, 437, 437, 438, 442, 443, 443, 444, 444, 445, 446, 446, 447, 444, 449, 449, 453, 453, 453, 457, 457, 457, 467, 467, 467, 0, 0, 0, 496, 498, 509, 509, 509, 0, 0, 0, 539, 541, 545, 545, 545, 0, 0, 0, 546, 551, 551, 551, 0, 0, 0, 552, 557, 557, 558, 558, 560, 560, 643, 643, 649, 649, 649, 649, 649, 651, 651, 652, 652, 653, 653, 655, 659, 659, 659, 665, 665, 0, 665, 665, 0, 0, 0, 665, 665, 0, 0, 0, 665, 0, 0, 0, 665, 665, 0, 0, 0, 665, 665, 0, 0, 0, 665, 665, 665, 0, 0, 666, 669, 670, 671, 672, 673, 673, 675, 677, 677, 678, 679, 680, 683, 684, 685, 686, 686, 687, 689, 690, 691, 692, 692, 693, 694, 696, 697, 698, 699, 700, 703, 704, 706, 707, 710, 712, 716, 717, 718, 719, 720, 720, 721, 721, 722, 723, 725, 726, 726, 728, 732, 732, 732, 736, 736, 736, 736, 740, 748, 748, 0, 748, 0, 0, 749, 751, 752, 753, 754, 756, 758, 759, 760, 761, 761, 762, 763, 764, 765, 766, 766, 768, 768, 761, 772, 772, 773, 774, 775, 776, 779, 783, 783, 783, 784, 784, 784, 785, 785, 787, 787, 791, 791, 791, 792, 792, 792, 793, 793, 795, 795, 806, 806, 807, 807, 866, 866, 871, 871, 871, 875, 875, 875, 875, 876, 878, 880, 880, 880, 881, 881, 881, 882, 882, 882, 883, 886, 886, 911, 911, 0, 911, 911, 0, 911, 911, 0, 0, 0, 0, 912, 912, 912, 916, 916, 917, 918, 920, 921, 922, 924, 925, 927, 928, 928, 983, 987, 989, 994, 994, 994, 998, 998, 998, 998, 998, 1083, 1087, 1087, 1091, 1091, 1095, 1095, 1099, 1099, 1103, 1103, 1107, 1111, 1111, 1112, 1114, 1114, 1114, 1114, 1115, 1120, 1120, 1124, 1124, 1124, 1128, 1129, 1130, 1131, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {86, 87, 92, 93, 107, 112, 113, 115, 118, 122, 125, 133, 138, 139, 140, 141, 143, 148, 149, 152, 154, 157, 161, 163, 169, 170, 171, 172, 173, 183, 184, 185, 186, 187, 188, 189, 193, 194, 214, 215, 216, 217, 219, 222, 224, 229, 230, 231, 233, 234, 235, 236, 238, 239, 240, 241, 242, 243, 244, 246, 247, 248, 252, 255, 258, 262, 273, 274, 275, 282, 283, 285, 286, 287, 288, 295, 296, 297, 298, 299, 315, 316, 317, 319, 320, 321, 322, 323, 325, 326, 328, 329, 330, 331, 332, 334, 340, 341, 342, 343, 344, 354, 355, 360, 361, 364, 365, 367, 370, 374, 375, 377, 378, 389, 394, 395, 396, 398, 399, 400, 401, 406, 407, 408, 410, 411, 420, 425, 426, 429, 430, 435, 436, 439, 443, 444, 446, 447, 460, 461, 464, 466, 467, 468, 470, 473, 474, 476, 479, 483, 484, 486, 492, 493, 505, 506, 509, 511, 512, 513, 515, 516, 518, 521, 525, 528, 529, 530, 532, 543, 544, 545, 557, 558, 561, 563, 564, 565, 567, 568, 570, 573, 577, 580, 581, 582, 584, 595, 596, 597, 603, 604, 605, 606, 616, 617, 618, 619, 622, 624, 625, 631, 632, 633, 642, 643, 644, 645, 648, 650, 651, 652, 653, 654, 660, 661, 666, 667, 668, 673, 674, 675, 682, 683, 685, 687, 690, 694, 701, 703, 710, 711, 713, 715, 718, 722, 732, 734, 741, 742, 744, 746, 749, 753, 756, 765, 766, 768, 770, 773, 777, 780, 789, 790, 792, 793, 795, 796, 814, 815, 826, 827, 828, 829, 830, 831, 836, 837, 838, 839, 840, 842, 847, 848, 849, 891, 896, 897, 900, 905, 906, 909, 913, 916, 917, 919, 922, 926, 929, 931, 934, 938, 941, 942, 944, 947, 951, 954, 955, 957, 960, 964, 967, 968, 969, 971, 974, 978, 980, 981, 982, 983, 984, 985, 986, 987, 988, 990, 991, 992, 996, 998, 999, 1001, 1002, 1004, 1006, 1007, 1008, 1009, 1010, 1011, 1013, 1015, 1018, 1020, 1021, 1022, 1026, 1027, 1033, 1035, 1038, 1044, 1055, 1056, 1057, 1058, 1061, 1066, 1067, 1068, 1069, 1070, 1076, 1078, 1079, 1081, 1086, 1087, 1088, 1094, 1095, 1096, 1097, 1100, 1123, 1128, 1129, 1132, 1134, 1137, 1141, 1143, 1144, 1145, 1147, 1150, 1152, 1153, 1154, 1155, 1158, 1160, 1161, 1162, 1164, 1166, 1167, 1170, 1171, 1174, 1180, 1181, 1183, 1185, 1188, 1190, 1194, 1203, 1208, 1209, 1211, 1212, 1213, 1215, 1216, 1218, 1219, 1228, 1233, 1234, 1236, 1237, 1238, 1240, 1241, 1243, 1244, 1256, 1261, 1262, 1263, 1277, 1278, 1283, 1284, 1285, 1300, 1301, 1302, 1303, 1305, 1308, 1310, 1311, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1323, 1324, 1342, 1343, 1345, 1348, 1349, 1351, 1354, 1355, 1357, 1360, 1364, 1367, 1371, 1372, 1373, 1376, 1381, 1382, 1383, 1385, 1386, 1387, 1388, 1389, 1390, 1392, 1393, 1398, 1400, 1402, 1408, 1409, 1410, 1417, 1418, 1419, 1420, 1421, 1435, 1440, 1441, 1445, 1446, 1450, 1451, 1455, 1456, 1460, 1461, 1464, 1471, 1476, 1477, 1480, 1481, 1482, 1483, 1484, 1490, 1491, 1496, 1497, 1498, 1507, 1508, 1509, 1510, 1511, 1514, 1516, 1517, 1518, 1519, 1520, 1521, 1530, 1534, 1537, 1541, 1544, 1547, 1551, 1554};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
capacitySet 1 176 86
assign 1 186 87
new 0 186 87
assign 1 190 92
new 0 190 92
new 1 190 93
assign 1 204 107
def 1 204 112
assign 1 204 113
equals 1 204 113
assign 1 0 115
assign 1 0 118
assign 1 0 122
return 1 205 125
assign 1 256 133
def 1 256 138
assign 1 257 139
new 0 257 139
assign 1 257 140
new 1 257 140
throw 1 257 141
assign 1 259 143
undef 1 259 148
assign 1 0 149
assign 1 259 152
greater 1 259 152
assign 1 0 154
assign 1 0 157
assign 1 260 161
copy 0 260 161
assign 1 262 163
assign 1 266 169
new 0 266 169
new 1 266 170
assign 1 267 171
new 0 267 171
assign 1 268 172
new 0 268 172
setHex 2 268 173
assign 1 272 183
new 0 272 183
assign 1 272 184
getCode 2 272 184
assign 1 272 185
new 0 272 185
assign 1 272 186
new 0 272 186
assign 1 272 187
new 0 272 187
assign 1 272 188
toString 3 272 188
return 1 272 189
assign 1 276 193
hexNew 1 276 193
setCode 2 277 194
assign 1 281 214
new 0 281 214
assign 1 281 215
stringGet 0 281 215
assign 1 281 216
sameType 1 281 216
assign 1 281 217
not 0 281 217
assign 1 282 219
toString 0 282 219
assign 1 284 222
assign 1 286 224
undef 1 286 229
assign 1 287 230
new 0 287 230
assign 1 288 231
new 0 288 231
assign 1 290 233
sizeGet 0 290 233
setValue 1 290 234
addValue 1 291 235
assign 1 293 236
lesser 1 293 236
assign 1 294 238
new 0 294 238
assign 1 294 239
add 1 294 239
assign 1 294 240
new 0 294 240
assign 1 294 241
multiply 1 294 241
assign 1 294 242
new 0 294 242
assign 1 294 243
divide 1 294 243
capacitySet 1 295 244
assign 1 297 246
new 0 297 246
assign 1 297 247
sizeGet 0 297 247
copyValue 4 297 248
return 1 302 252
return 1 306 255
addValue 1 310 258
write 1 314 262
assign 1 325 273
copy 0 325 273
clear 0 326 274
return 1 327 275
assign 1 331 282
new 0 331 282
assign 1 331 283
greater 1 331 283
assign 1 332 285
new 0 332 285
assign 1 332 286
new 0 332 286
setIntUnchecked 2 332 287
assign 1 333 288
new 0 333 288
assign 1 338 295
new 0 338 295
new 1 338 296
assign 1 339 297
new 0 339 297
assign 1 340 298
new 0 340 298
setCodeUnchecked 2 340 299
assign 1 344 315
new 0 344 315
assign 1 344 316
newlineGet 0 344 316
assign 1 345 317
ends 1 345 317
assign 1 346 319
new 0 346 319
assign 1 346 320
sizeGet 0 346 320
assign 1 346 321
subtract 1 346 321
assign 1 346 322
substring 2 346 322
return 1 346 323
assign 1 348 325
new 0 348 325
assign 1 349 326
ends 1 349 326
assign 1 350 328
new 0 350 328
assign 1 350 329
sizeGet 0 350 329
assign 1 350 330
subtract 1 350 330
assign 1 350 331
substring 2 350 331
return 1 350 332
return 1 352 334
assign 1 356 340
new 0 356 340
assign 1 356 341
add 1 356 341
assign 1 356 342
new 1 356 342
addValue 1 357 343
return 1 358 344
assign 1 362 354
find 1 362 354
assign 1 363 355
undef 1 363 360
assign 1 0 361
assign 1 363 364
new 0 363 364
assign 1 363 365
notEquals 1 363 365
assign 1 0 367
assign 1 0 370
assign 1 364 374
new 0 364 374
return 1 364 375
assign 1 366 377
new 0 366 377
return 1 366 378
assign 1 370 389
undef 1 370 394
assign 1 370 395
new 0 370 395
return 1 370 396
assign 1 371 398
sizeGet 0 371 398
assign 1 371 399
subtract 1 371 399
assign 1 371 400
find 2 371 400
assign 1 372 401
undef 1 372 406
assign 1 373 407
new 0 373 407
return 1 373 408
assign 1 375 410
new 0 375 410
return 1 375 411
assign 1 379 420
undef 1 379 425
assign 1 0 426
assign 1 379 429
find 1 379 429
assign 1 379 430
undef 1 379 435
assign 1 0 436
assign 1 0 439
assign 1 380 443
new 0 380 443
return 1 380 444
assign 1 382 446
new 0 382 446
return 1 382 447
assign 1 386 460
new 0 386 460
assign 1 387 461
new 0 387 461
assign 1 387 464
lesser 1 387 464
getInt 2 388 466
assign 1 389 467
new 0 389 467
assign 1 389 468
greater 1 389 468
assign 1 0 470
assign 1 389 473
new 0 389 473
assign 1 389 474
lesser 1 389 474
assign 1 0 476
assign 1 0 479
assign 1 390 483
new 0 390 483
return 1 390 484
incrementValue 0 387 486
assign 1 393 492
new 0 393 492
return 1 393 493
assign 1 397 505
new 0 397 505
assign 1 398 506
new 0 398 506
assign 1 398 509
lesser 1 398 509
getInt 2 399 511
assign 1 400 512
new 0 400 512
assign 1 400 513
greater 1 400 513
assign 1 400 515
new 0 400 515
assign 1 400 516
lesser 1 400 516
assign 1 0 518
assign 1 0 521
assign 1 0 525
assign 1 401 528
new 0 401 528
addValue 1 401 529
setIntUnchecked 2 402 530
incrementValue 0 398 532
assign 1 408 543
copy 0 408 543
assign 1 408 544
lowerValue 0 408 544
return 1 408 545
assign 1 412 557
new 0 412 557
assign 1 413 558
new 0 413 558
assign 1 413 561
lesser 1 413 561
getInt 2 414 563
assign 1 415 564
new 0 415 564
assign 1 415 565
greater 1 415 565
assign 1 415 567
new 0 415 567
assign 1 415 568
lesser 1 415 568
assign 1 0 570
assign 1 0 573
assign 1 0 577
assign 1 416 580
new 0 416 580
subtractValue 1 416 581
setIntUnchecked 2 417 582
incrementValue 0 413 584
assign 1 423 595
copy 0 423 595
assign 1 423 596
upperValue 0 423 596
return 1 423 597
assign 1 427 603
new 0 427 603
assign 1 427 604
split 1 427 604
assign 1 427 605
join 2 427 605
return 1 427 606
assign 1 432 616
new 0 432 616
assign 1 432 617
new 1 432 617
assign 1 433 618
mbiterGet 0 433 618
assign 1 434 619
new 0 434 619
assign 1 434 622
lesser 1 434 622
next 1 435 624
assign 1 434 625
increment 0 434 625
assign 1 437 631
next 1 437 631
assign 1 437 632
toString 0 437 632
return 1 438 633
assign 1 442 642
new 0 442 642
assign 1 443 643
new 0 443 643
setValue 1 443 644
assign 1 444 645
new 0 444 645
assign 1 444 648
lesser 1 444 648
getInt 2 445 650
assign 1 446 651
new 0 446 651
multiplyValue 1 446 652
addValue 1 447 653
incrementValue 0 444 654
assign 1 449 660
absValue 0 449 660
return 1 449 661
assign 1 453 666
new 0 453 666
assign 1 453 667
hashValue 1 453 667
return 1 453 668
assign 1 457 673
new 0 457 673
assign 1 457 674
getCode 2 457 674
return 1 457 675
assign 1 467 682
new 0 467 682
assign 1 467 683
greaterEquals 1 467 683
assign 1 467 685
greater 1 467 685
assign 1 0 687
assign 1 0 690
assign 1 0 694
return 1 496 701
return 1 498 703
assign 1 509 710
new 0 509 710
assign 1 509 711
greaterEquals 1 509 711
assign 1 509 713
greater 1 509 713
assign 1 0 715
assign 1 0 718
assign 1 0 722
return 1 539 732
return 1 541 734
assign 1 545 741
new 0 545 741
assign 1 545 742
greaterEquals 1 545 742
assign 1 545 744
greater 1 545 744
assign 1 0 746
assign 1 0 749
assign 1 0 753
setIntUnchecked 2 546 756
assign 1 551 765
new 0 551 765
assign 1 551 766
greaterEquals 1 551 766
assign 1 551 768
greater 1 551 768
assign 1 0 770
assign 1 0 773
assign 1 0 777
setCodeUnchecked 2 552 780
assign 1 557 789
new 0 557 789
assign 1 557 790
lesserEquals 1 557 790
assign 1 558 792
new 0 558 792
return 1 558 793
assign 1 560 795
new 0 560 795
return 1 560 796
assign 1 643 814
rfind 1 643 814
return 1 643 815
assign 1 649 826
copy 0 649 826
assign 1 649 827
reverseBytes 0 649 827
assign 1 649 828
copy 0 649 828
assign 1 649 829
reverseBytes 0 649 829
assign 1 649 830
find 1 649 830
assign 1 651 831
def 1 651 836
assign 1 652 837
sizeGet 0 652 837
addValue 1 652 838
assign 1 653 839
subtract 1 653 839
return 1 653 840
return 1 655 842
assign 1 659 847
new 0 659 847
assign 1 659 848
find 2 659 848
return 1 659 849
assign 1 665 891
undef 1 665 896
assign 1 0 897
assign 1 665 900
undef 1 665 905
assign 1 0 906
assign 1 0 909
assign 1 0 913
assign 1 665 916
new 0 665 916
assign 1 665 917
lesser 1 665 917
assign 1 0 919
assign 1 0 922
assign 1 0 926
assign 1 665 929
greaterEquals 1 665 929
assign 1 0 931
assign 1 0 934
assign 1 0 938
assign 1 665 941
sizeGet 0 665 941
assign 1 665 942
greater 1 665 942
assign 1 0 944
assign 1 0 947
assign 1 0 951
assign 1 665 954
new 0 665 954
assign 1 665 955
equals 1 665 955
assign 1 0 957
assign 1 0 960
assign 1 0 964
assign 1 665 967
sizeGet 0 665 967
assign 1 665 968
new 0 665 968
assign 1 665 969
equals 1 665 969
assign 1 0 971
assign 1 0 974
return 1 666 978
assign 1 669 980
assign 1 670 981
copy 0 670 981
assign 1 671 982
new 0 671 982
assign 1 672 983
new 0 672 983
assign 1 673 984
new 0 673 984
getInt 2 673 985
assign 1 675 986
sizeGet 0 675 986
assign 1 677 987
new 0 677 987
assign 1 677 988
greater 1 677 988
assign 1 678 990
new 0 678 990
assign 1 679 991
new 0 679 991
assign 1 680 992
new 0 680 992
assign 1 683 996
lesser 1 683 996
getInt 2 684 998
assign 1 685 999
equals 1 685 999
assign 1 686 1001
new 0 686 1001
assign 1 686 1002
equals 1 686 1002
return 1 687 1004
setValue 1 689 1006
incrementValue 0 690 1007
setValue 1 691 1008
assign 1 692 1009
sizeGet 0 692 1009
addValue 1 692 1010
assign 1 693 1011
greater 1 693 1011
return 1 694 1013
assign 1 696 1015
new 0 696 1015
assign 1 697 1018
lesser 1 697 1018
getInt 2 698 1020
getInt 2 699 1021
assign 1 700 1022
notEquals 1 700 1022
incrementValue 0 703 1026
incrementValue 0 704 1027
assign 1 706 1033
equals 1 706 1033
return 1 707 1035
incrementValue 0 710 1038
return 1 712 1044
assign 1 716 1055
new 0 716 1055
assign 1 717 1056
new 0 717 1056
assign 1 718 1057
find 2 718 1057
assign 1 719 1058
sizeGet 0 719 1058
assign 1 720 1061
def 1 720 1066
assign 1 721 1067
substring 2 721 1067
addValue 1 721 1068
assign 1 722 1069
add 1 722 1069
assign 1 723 1070
find 2 723 1070
assign 1 725 1076
lesser 1 725 1076
assign 1 726 1078
substring 2 726 1078
addValue 1 726 1079
return 1 728 1081
assign 1 732 1086
new 0 732 1086
assign 1 732 1087
join 2 732 1087
return 1 732 1088
assign 1 736 1094
new 0 736 1094
assign 1 736 1095
lineSplitterGet 0 736 1095
assign 1 736 1096
tokenize 1 736 1096
return 1 736 1097
return 1 740 1100
assign 1 748 1123
undef 1 748 1128
assign 1 0 1129
assign 1 748 1132
otherType 1 748 1132
assign 1 0 1134
assign 1 0 1137
return 1 749 1141
assign 1 751 1143
assign 1 752 1144
sizeGet 0 752 1144
assign 1 753 1145
greater 1 753 1145
assign 1 754 1147
assign 1 756 1150
assign 1 758 1152
new 0 758 1152
assign 1 759 1153
new 0 759 1153
assign 1 760 1154
new 0 760 1154
assign 1 761 1155
new 0 761 1155
assign 1 761 1158
lesser 1 761 1158
getCode 2 762 1160
getCode 2 763 1161
assign 1 764 1162
notEquals 1 764 1162
assign 1 765 1164
greater 1 765 1164
assign 1 766 1166
new 0 766 1166
return 1 766 1167
assign 1 768 1170
new 0 768 1170
return 1 768 1171
incrementValue 0 761 1174
assign 1 772 1180
new 0 772 1180
assign 1 772 1181
equals 1 772 1181
assign 1 773 1183
greater 1 773 1183
assign 1 774 1185
new 0 774 1185
assign 1 775 1188
greater 1 775 1188
assign 1 776 1190
new 0 776 1190
return 1 779 1194
assign 1 783 1203
undef 1 783 1208
return 1 783 1209
assign 1 784 1211
compare 1 784 1211
assign 1 784 1212
new 0 784 1212
assign 1 784 1213
equals 1 784 1213
assign 1 785 1215
new 0 785 1215
return 1 785 1216
assign 1 787 1218
new 0 787 1218
return 1 787 1219
assign 1 791 1228
undef 1 791 1233
return 1 791 1234
assign 1 792 1236
compare 1 792 1236
assign 1 792 1237
new 0 792 1237
assign 1 792 1238
equals 1 792 1238
assign 1 793 1240
new 0 793 1240
return 1 793 1241
assign 1 795 1243
new 0 795 1243
return 1 795 1244
assign 1 806 1256
undef 1 806 1261
assign 1 807 1262
new 0 807 1262
return 1 807 1263
assign 1 866 1277
new 0 866 1277
return 1 866 1278
assign 1 871 1283
equals 1 871 1283
assign 1 871 1284
not 0 871 1284
return 1 871 1285
assign 1 875 1300
new 0 875 1300
assign 1 875 1301
stringGet 0 875 1301
assign 1 875 1302
sameType 1 875 1302
assign 1 875 1303
not 0 875 1303
assign 1 876 1305
toString 0 876 1305
assign 1 878 1308
assign 1 880 1310
sizeGet 0 880 1310
assign 1 880 1311
add 1 880 1311
assign 1 880 1312
new 1 880 1312
assign 1 881 1313
new 0 881 1313
assign 1 881 1314
new 0 881 1314
copyValue 4 881 1315
assign 1 882 1316
new 0 882 1316
assign 1 882 1317
sizeGet 0 882 1317
copyValue 4 882 1318
return 1 883 1319
assign 1 886 1323
new 0 886 1323
return 1 886 1324
assign 1 911 1342
new 0 911 1342
assign 1 911 1343
lesser 1 911 1343
assign 1 0 1345
assign 1 911 1348
sizeGet 0 911 1348
assign 1 911 1349
greater 1 911 1349
assign 1 0 1351
assign 1 911 1354
sizeGet 0 911 1354
assign 1 911 1355
greater 1 911 1355
assign 1 0 1357
assign 1 0 1360
assign 1 0 1364
assign 1 0 1367
assign 1 912 1371
new 0 912 1371
assign 1 912 1372
new 1 912 1372
throw 1 912 1373
assign 1 916 1376
undef 1 916 1381
assign 1 917 1382
new 0 917 1382
assign 1 918 1383
new 0 918 1383
setValue 1 920 1385
subtractValue 1 921 1386
assign 1 922 1387
setValue 1 924 1388
addValue 1 925 1389
assign 1 927 1390
greater 1 927 1390
assign 1 928 1392
copy 0 928 1392
capacitySet 1 928 1393
assign 1 983 1398
greater 1 983 1398
assign 1 987 1400
copy 0 987 1400
return 1 989 1402
assign 1 994 1408
sizeGet 0 994 1408
assign 1 994 1409
substring 2 994 1409
return 1 994 1410
assign 1 998 1417
subtract 1 998 1417
assign 1 998 1418
new 1 998 1418
assign 1 998 1419
new 0 998 1419
assign 1 998 1420
copyValue 4 998 1420
return 1 998 1421
output 0 1083 1435
assign 1 1087 1440
new 1 1087 1440
return 1 1087 1441
assign 1 1091 1445
new 1 1091 1445
return 1 1091 1446
assign 1 1095 1450
new 1 1095 1450
return 1 1095 1451
assign 1 1099 1455
new 1 1099 1455
return 1 1099 1456
assign 1 1103 1460
new 1 1103 1460
return 1 1103 1461
return 1 1107 1464
assign 1 1111 1471
undef 1 1111 1476
new 0 1112 1477
assign 1 1114 1480
sizeGet 0 1114 1480
assign 1 1114 1481
new 0 1114 1481
assign 1 1114 1482
add 1 1114 1482
new 1 1114 1483
addValue 1 1115 1484
assign 1 1120 1490
new 0 1120 1490
return 1 1120 1491
assign 1 1124 1496
new 0 1124 1496
assign 1 1124 1497
strip 1 1124 1497
return 1 1124 1498
assign 1 1128 1507
new 0 1128 1507
assign 1 1129 1508
new 0 1129 1508
assign 1 1130 1509
new 0 1130 1509
assign 1 1131 1510
new 0 1131 1510
assign 1 1131 1511
subtract 1 1131 1511
assign 1 1132 1514
greater 1 1132 1514
getInt 2 1133 1516
getInt 2 1134 1517
setInt 2 1135 1518
setInt 2 1136 1519
incrementValue 0 1137 1520
decrementValue 0 1138 1521
assign 1 0 1530
return 1 0 1534
assign 1 0 1537
return 1 0 1541
return 1 0 1544
assign 1 0 1547
return 1 0 1551
assign 1 0 1554
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case 1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case 855090856: return bem_multiByteIteratorGet_0();
case 1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 195899181: return bem_biterGet_0();
case 1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case 729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case 1881757495: return bem_strip_0();
case 139115914: return bem_splitLines_0();
case 1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case 800915430: return bem_reverseBytes_0();
case 1354714650: return bem_copy_0();
case 85457677: return bem_leniGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 599761551: return bem_siziSet_1(bevd_0);
case 1274448085: return bem_find_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1143153819: return bem_codeNew_1(bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_4_3_MathInt) bevd_0);
case 1954998871: return bem_getHex_1((BEC_4_3_MathInt) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1406325780: return bem_writeTo_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2001811380: return bem_split_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_4_6_TextString) bevd_0);
case 636254476: return bem_getPoint_1((BEC_4_3_MathInt) bevd_0);
case 1958502700: return bem_greater_1((BEC_4_6_TextString) bevd_0);
case 1250088509: return bem_substring_1((BEC_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_4_6_TextString) bevd_0);
case 74375424: return bem_leniSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 1298743126: return bem_ends_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 340923733: return bem_getCode_1((BEC_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 825000909: return bem_vstringSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1412717737: return bem_compare_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 477101321: return bem_hexNew_1((BEC_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1395074208: return bem_setInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1154529699: return bem_join_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 889715578: return bem_swap_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1393886412: return bem_setHex_2((BEC_4_3_MathInt) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 761715532: return bem_setIntUnchecked_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1250088508: return bem_substring_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1274448084: return bem_find_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 340923734: return bem_getCode_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1956186668: return bem_getInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 391213135: return bem_copyValue_4((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_6_TextString();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_6_TextString.bevs_inst = (BEC_4_6_TextString)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_6_TextString.bevs_inst;
}
}
