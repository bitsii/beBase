package be.BEL_4_Base;
/* IO:File: source/base/String.be */
public class BEC_4_6_TextString extends BEC_6_6_SystemObject {
public BEC_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_4_6_TextString(byte[] bevi_bytes) {
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_bytes.length);
    }
    public BEC_4_6_TextString(byte[] bevi_bytes, int bevi_length) {
        //no copy, isOnce
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_length);
    }
    public BEC_4_6_TextString(int bevi_length, byte[] bevi_bytes) {
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        System.arraycopy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_length);
    }
    public BEC_4_6_TextString(String bevi_string) throws Exception {
        byte[] bevi_bytes = bevi_string.getBytes("UTF-8");
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_4_3_MathInt(bevi_bytes.length);
        bevp_capacity = new BEC_4_3_MathInt(bevi_bytes.length);
    }
    public String bems_toJvString() throws Exception {
        String jvString = new String(bevi_bytes, 0, bevp_size.bevi_int, "UTF-8");
        return jvString;
    }
    
   private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x42,0x75,0x66,0x66,0x65,0x72,0x20,0x72,0x65,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static byte[] bels_1 = {0x0A};
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_8 = (new BEC_4_3_MathInt(57));
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(48));
private static BEC_4_3_MathInt bevo_10 = (new BEC_4_3_MathInt(64));
private static BEC_4_3_MathInt bevo_11 = (new BEC_4_3_MathInt(91));
private static BEC_4_3_MathInt bevo_12 = (new BEC_4_3_MathInt(96));
private static BEC_4_3_MathInt bevo_13 = (new BEC_4_3_MathInt(123));
private static BEC_4_3_MathInt bevo_14 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_15 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_16 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_17 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_18 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_19 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_20 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_21 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_22 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_23 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_24 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_25 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_26 = (new BEC_4_3_MathInt(-1));
private static BEC_4_3_MathInt bevo_27 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_28 = (new BEC_4_3_MathInt(0));
private static byte[] bels_2 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
private static BEC_4_3_MathInt bevo_29 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_30 = (new BEC_4_3_MathInt(1));
public static BEC_4_6_TextString bevs_inst;
public BEC_6_6_SystemObject bevp_vstring;
public BEC_4_3_MathInt bevp_size;
public BEC_4_3_MathInt bevp_capacity;
public BEC_4_3_MathInt bevp_leni;
public BEC_4_3_MathInt bevp_sizi;
public BEC_6_6_SystemObject bem_vstringGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_vstringSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_new_1(BEC_4_3_MathInt beva__capacity) throws Throwable {
this.bem_capacitySet_1(beva__capacity);
bevp_size = (new BEC_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_4_6_TextString bem_new_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_4_6_TextString bem_capacitySet_1(BEC_4_3_MathInt beva_ncap) throws Throwable {
BEC_4_6_TextString bevl_failed = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
if (bevp_capacity == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_3_tmpvar_phold = bevp_capacity.bem_equals_1(beva_ncap);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 211 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 211 */
 else  /* Line: 211 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 211 */ {
return this;
} /* Line: 212 */

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        this.bevi_bytes = java.util.Arrays.copyOf(this.bevi_bytes, beva_ncap.bevi_int);
      }
      if (bevl_failed == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 263 */ {
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(26, bels_0));
bevt_5_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 264 */
if (bevp_size == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_8_tmpvar_phold = bevp_size.bem_greater_1(beva_ncap);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 266 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 266 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 266 */ {
bevp_size = beva_ncap.bem_copy_0();
} /* Line: 267 */
bevp_capacity = beva_ncap;
return this;
} /*method end*/
public BEC_4_6_TextString bem_hexNew_1(BEC_4_6_TextString beva_val) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevp_size = (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_setHex_2(bevt_1_tmpvar_phold, beva_val);
return this;
} /*method end*/
public BEC_4_6_TextString bem_getHex_1(BEC_4_3_MathInt beva_pos) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_0();
bevt_1_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
bevt_4_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevt_5_tmpvar_phold = (new BEC_4_3_MathInt(16));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_toString_3(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_setHex_2(BEC_4_3_MathInt beva_pos, BEC_4_6_TextString beva_hval) throws Throwable {
BEC_4_3_MathInt bevl_val = null;
bevl_val = (new BEC_4_3_MathInt()).bem_hexNew_1(beva_hval);
this.bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_4_6_TextString bem_addValue_1(BEC_6_6_SystemObject beva_astr) throws Throwable {
BEC_4_6_TextString bevl_str = null;
BEC_4_3_MathInt bevl_nsize = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_str = (BEC_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
if (bevp_leni == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 289 */ {
bevp_leni = (new BEC_4_3_MathInt()).bem_new_0();
bevp_sizi = (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 291 */
bevt_1_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevp_sizi.bem_setValue_1(bevt_1_tmpvar_phold);
bevp_sizi.bem_addValue_1(bevp_size);
bevt_2_tmpvar_phold = bevp_capacity.bem_lesser_1(bevp_sizi);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevt_5_tmpvar_phold = bevo_0;
bevt_4_tmpvar_phold = bevp_sizi.bem_add_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevo_1;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_multiply_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevo_2;
bevl_nsize = bevt_3_tmpvar_phold.bem_divide_1(bevt_7_tmpvar_phold);
this.bem_capacitySet_1(bevl_nsize);
} /* Line: 298 */
bevt_8_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_9_tmpvar_phold = bevl_str.bem_sizeGet_0();
this.bem_copyValue_4(bevl_str, bevt_8_tmpvar_phold, bevt_9_tmpvar_phold, bevp_size);
return this;
} /*method end*/
public BEC_4_6_TextString bem_readBuffer_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_readString_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_write_1(BEC_6_6_SystemObject beva_stri) throws Throwable {
this.bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_writeTo_1(BEC_6_6_SystemObject beva_w) throws Throwable {
beva_w.bemd_1(1603004369, BEL_4_Base.bevn_write_1, this);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_open_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_close_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_extractString_0() throws Throwable {
BEC_4_6_TextString bevl_str = null;
bevl_str = this.bem_copy_0();
this.bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_4_6_TextString bem_clear_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = bevp_size.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 334 */ {
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_setIntUnchecked_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevp_size = (new BEC_4_3_MathInt(0));
} /* Line: 336 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_codeNew_1(BEC_6_6_SystemObject beva_codei) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(1));
this.bem_new_1(bevt_0_tmpvar_phold);
bevp_size = (new BEC_4_3_MathInt(1));
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
this.bem_setCodeUnchecked_2(bevt_1_tmpvar_phold, (BEC_4_3_MathInt) beva_codei);
return this;
} /*method end*/
public BEC_4_6_TextString bem_chomp_0() throws Throwable {
BEC_4_6_TextString bevl_nl = null;
BEC_6_15_SystemCurrentPlatform bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevl_nl = bevt_0_tmpvar_phold.bem_newlineGet_0();
bevt_1_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_5_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_4_tmpvar_phold = bevp_size.bem_subtract_1(bevt_5_tmpvar_phold);
bevt_2_tmpvar_phold = this.bem_substring_2(bevt_3_tmpvar_phold, bevt_4_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /* Line: 349 */
bevl_nl = (new BEC_4_6_TextString(1, bels_1));
bevt_6_tmpvar_phold = this.bem_ends_1(bevl_nl);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevt_8_tmpvar_phold = bevo_5;
bevt_10_tmpvar_phold = bevl_nl.bem_sizeGet_0();
bevt_9_tmpvar_phold = bevp_size.bem_subtract_1(bevt_10_tmpvar_phold);
bevt_7_tmpvar_phold = this.bem_substring_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
return bevt_7_tmpvar_phold;
} /* Line: 353 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_copy_0() throws Throwable {
BEC_4_6_TextString bevl_c = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_c = (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_c.bem_addValue_1(this);
return (BEC_4_6_TextString) bevl_c;
} /*method end*/
public BEC_5_4_LogicBool bem_begins_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_found = this.bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 366 */ {
bevt_3_tmpvar_phold = bevo_7;
bevt_2_tmpvar_phold = bevl_found.bem_notEquals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 366 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 366 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 366 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 367 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_ends_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevl_found = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 373 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 373 */
bevt_3_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_2_tmpvar_phold = bevp_size.bem_subtract_1(bevt_3_tmpvar_phold);
bevl_found = this.bem_find_2(beva_str, bevt_2_tmpvar_phold);
if (bevl_found == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 376 */
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_has_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_str == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 382 */ {
bevt_3_tmpvar_phold = this.bem_find_1(beva_str);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 382 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 382 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 382 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 382 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 383 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isInteger_0() throws Throwable {
BEC_4_3_MathInt bevl_ic = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
bevl_ic = (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 390 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 390 */ {
this.bem_getInt_2(bevl_j, bevl_ic);
bevt_3_tmpvar_phold = bevo_8;
bevt_2_tmpvar_phold = bevl_ic.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 392 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 392 */ {
bevt_5_tmpvar_phold = bevo_9;
bevt_4_tmpvar_phold = bevl_ic.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 392 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 392 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 392 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 392 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 393 */
bevl_j.bem_incrementValue_0();
} /* Line: 390 */
 else  /* Line: 390 */ {
break;
} /* Line: 390 */
} /* Line: 390 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_lowerValue_0() throws Throwable {
BEC_4_3_MathInt bevl_vc = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 401 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 401 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_10;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_5_tmpvar_phold = bevo_11;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 403 */
 else  /* Line: 403 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 403 */ {
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(32));
bevl_vc.bem_addValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 405 */
bevl_j.bem_incrementValue_0();
} /* Line: 401 */
 else  /* Line: 401 */ {
break;
} /* Line: 401 */
} /* Line: 401 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_lower_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_lowerValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_upperValue_0() throws Throwable {
BEC_4_3_MathInt bevl_vc = null;
BEC_4_3_MathInt bevl_j = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevl_vc = (new BEC_4_3_MathInt()).bem_new_0();
bevl_j = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 416 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 416 */ {
this.bem_getInt_2(bevl_j, bevl_vc);
bevt_3_tmpvar_phold = bevo_12;
bevt_2_tmpvar_phold = bevl_vc.bem_greater_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevt_5_tmpvar_phold = bevo_13;
bevt_4_tmpvar_phold = bevl_vc.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 418 */
 else  /* Line: 418 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 418 */ {
bevt_6_tmpvar_phold = (new BEC_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_tmpvar_phold);
this.bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 420 */
bevl_j.bem_incrementValue_0();
} /* Line: 416 */
 else  /* Line: 416 */ {
break;
} /* Line: 416 */
} /* Line: 416 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_upper_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_upperValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_swap_2(BEC_4_6_TextString beva_from, BEC_4_6_TextString beva_to) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_2_tmpvar_phold = this.bem_split_1(beva_from);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_to, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_getPoint_1(BEC_4_3_MathInt beva_posi) throws Throwable {
BEC_4_6_TextString bevl_buf = null;
BEC_6_6_SystemObject bevl_j = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_6_TextString bevl_y = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(2));
bevl_buf = (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevl_j = this.bem_mbiterGet_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 437 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_posi);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 437 */ {
bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 437 */
 else  /* Line: 437 */ {
break;
} /* Line: 437 */
} /* Line: 437 */
bevt_2_tmpvar_phold = bevl_j.bemd_1(1048795675, BEL_4_Base.bevn_next_1, bevl_buf);
bevl_y = (BEC_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
return bevl_y;
} /*method end*/
public BEC_4_3_MathInt bem_hashValue_1(BEC_4_3_MathInt beva_into) throws Throwable {
BEC_4_3_MathInt bevl_c = null;
BEC_4_3_MathInt bevl_j = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevl_c = (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
beva_into.bem_setValue_1(bevt_0_tmpvar_phold);
bevl_j = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 447 */ {
bevt_1_tmpvar_phold = bevl_j.bem_lesser_1(bevp_size);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 447 */ {
this.bem_getInt_2(bevl_j, bevl_c);
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_tmpvar_phold);
beva_into.bem_addValue_1(bevl_c);
bevl_j.bem_incrementValue_0();
} /* Line: 447 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
bevt_3_tmpvar_phold = beva_into.bem_absValue_0();
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_hashValue_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_getCode_1(BEC_4_3_MathInt beva_pos) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_0();
bevt_0_tmpvar_phold = this.bem_getCode_2(beva_pos, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_getInt_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_14;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 470 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 470 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 470 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 470 */
 else  /* Line: 470 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 470 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 490 */
 else  /* Line: 498 */ {
return null;
} /* Line: 499 */
return beva_into;
} /*method end*/
public BEC_4_3_MathInt bem_getCode_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_15;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 512 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 512 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 512 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 512 */
 else  /* Line: 512 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 512 */ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int < 0) {
            beva_into.bevi_int += 256;
         }
         } /* Line: 536 */
 else  /* Line: 541 */ {
return null;
} /* Line: 542 */
return beva_into;
} /*method end*/
public BEC_4_6_TextString bem_setInt_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_16;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 548 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 548 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 548 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 548 */
 else  /* Line: 548 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 548 */ {
this.bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 549 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_setCode_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_17;
bevt_1_tmpvar_phold = beva_pos.bem_greaterEquals_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 554 */ {
bevt_3_tmpvar_phold = bevp_size.bem_greater_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 554 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 554 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 554 */
 else  /* Line: 554 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 554 */ {
this.bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 555 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_18;
bevt_0_tmpvar_phold = bevp_size.bem_lesserEquals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 560 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 561 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_setIntUnchecked_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_4_6_TextString bem_setCodeUnchecked_2(BEC_4_3_MathInt beva_pos, BEC_4_3_MathInt beva_into) throws Throwable {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b > 127) {
        twvls_b -= 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_4_3_MathInt bem_reverseFind_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_rfind_1(beva_str);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_rfind_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevl_rpos = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_reverseBytes_0();
bevt_3_tmpvar_phold = beva_str.bem_copy_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_reverseBytes_0();
bevl_rpos = bevt_0_tmpvar_phold.bem_find_1(bevt_2_tmpvar_phold);
if (bevl_rpos == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 654 */ {
bevt_5_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_rpos.bem_addValue_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_tmpvar_phold;
} /* Line: 656 */
return null;
} /*method end*/
public BEC_4_3_MathInt bem_find_1(BEC_4_6_TextString beva_str) throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_19;
bevt_0_tmpvar_phold = this.bem_find_2(beva_str, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_find_2(BEC_4_6_TextString beva_str, BEC_4_3_MathInt beva_start) throws Throwable {
BEC_4_3_MathInt bevl_end = null;
BEC_4_3_MathInt bevl_current = null;
BEC_4_3_MathInt bevl_myval = null;
BEC_4_3_MathInt bevl_strfirst = null;
BEC_4_3_MathInt bevl_strsize = null;
BEC_4_3_MathInt bevl_strval = null;
BEC_4_3_MathInt bevl_current2 = null;
BEC_4_3_MathInt bevl_end2 = null;
BEC_4_3_MathInt bevl_currentstr2 = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
if (beva_str == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
if (beva_start == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_9_tmpvar_phold = bevo_20;
bevt_8_tmpvar_phold = beva_start.bem_lesser_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_10_tmpvar_phold = beva_start.bem_greaterEquals_1(bevp_size);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_12_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_greater_1(bevp_size);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_14_tmpvar_phold = bevo_21;
bevt_13_tmpvar_phold = bevp_size.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_16_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_17_tmpvar_phold = bevo_22;
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_equals_1(bevt_17_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 668 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 668 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 668 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 668 */ {
return null;
} /* Line: 669 */
bevl_end = bevp_size;
bevl_current = beva_start.bem_copy_0();
bevl_myval = (new BEC_4_3_MathInt()).bem_new_0();
bevl_strfirst = (new BEC_4_3_MathInt()).bem_new_0();
bevt_18_tmpvar_phold = (new BEC_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_tmpvar_phold, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_tmpvar_phold = bevo_23;
bevt_19_tmpvar_phold = bevl_strsize.bem_greater_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 680 */ {
bevl_strval = (new BEC_4_3_MathInt()).bem_new_0();
bevl_current2 = (new BEC_4_3_MathInt()).bem_new_0();
bevl_end2 = (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 683 */
while (true)
 /* Line: 686 */ {
bevt_21_tmpvar_phold = bevl_current.bem_lesser_1(bevl_end);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 686 */ {
this.bem_getInt_2(bevl_current, bevl_myval);
bevt_22_tmpvar_phold = bevl_myval.bem_equals_1(bevl_strfirst);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 688 */ {
bevt_24_tmpvar_phold = bevo_24;
bevt_23_tmpvar_phold = bevl_strsize.bem_equals_1(bevt_24_tmpvar_phold);
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 689 */ {
return bevl_current;
} /* Line: 690 */
bevl_current2.bem_setValue_1(bevl_current);
bevl_current2.bem_incrementValue_0();
bevl_end2.bem_setValue_1(bevl_current);
bevt_25_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_end2.bem_addValue_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_end2.bem_greater_1(bevp_size);
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 696 */ {
return null;
} /* Line: 697 */
bevl_currentstr2 = (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 700 */ {
bevt_27_tmpvar_phold = bevl_current2.bem_lesser_1(bevl_end2);
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 700 */ {
this.bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
bevt_28_tmpvar_phold = bevl_myval.bem_notEquals_1(bevl_strval);
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 703 */ {
break;
} /* Line: 704 */
bevl_current2.bem_incrementValue_0();
bevl_currentstr2.bem_incrementValue_0();
} /* Line: 707 */
 else  /* Line: 700 */ {
break;
} /* Line: 700 */
} /* Line: 700 */
bevt_29_tmpvar_phold = bevl_current2.bem_equals_1(bevl_end2);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 709 */ {
return bevl_current;
} /* Line: 710 */
} /* Line: 709 */
bevl_current.bem_incrementValue_0();
} /* Line: 713 */
 else  /* Line: 686 */ {
break;
} /* Line: 686 */
} /* Line: 686 */
return null;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_split_1(BEC_4_6_TextString beva_delim) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_splits = null;
BEC_4_3_MathInt bevl_last = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_3_MathInt bevl_ds = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
bevl_splits = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (new BEC_4_3_MathInt(0));
bevl_i = this.bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
 /* Line: 723 */ {
if (bevl_i == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 723 */ {
bevt_1_tmpvar_phold = this.bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_tmpvar_phold);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = this.bem_find_2(beva_delim, bevl_last);
} /* Line: 726 */
 else  /* Line: 723 */ {
break;
} /* Line: 723 */
} /* Line: 723 */
bevt_2_tmpvar_phold = bevl_last.bem_lesser_1(bevp_size);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 728 */ {
bevt_3_tmpvar_phold = this.bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_tmpvar_phold);
} /* Line: 729 */
return bevl_splits;
} /*method end*/
public BEC_4_6_TextString bem_join_2(BEC_4_6_TextString beva_delim, BEC_6_6_SystemObject beva_splits) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_join_2(beva_delim, beva_splits);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_splitLines_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_9_TextTokenizer bevt_1_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_lineSplitterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_tokenize_1(this);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_3_MathInt bem_compare_1(BEC_6_6_SystemObject beva_stri) throws Throwable {
BEC_4_3_MathInt bevl_mysize = null;
BEC_4_3_MathInt bevl_osize = null;
BEC_4_3_MathInt bevl_maxsize = null;
BEC_4_3_MathInt bevl_myret = null;
BEC_4_3_MathInt bevl_mv = null;
BEC_4_3_MathInt bevl_ov = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 751 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 751 */ {
bevt_2_tmpvar_phold = beva_stri.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 751 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 751 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 751 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 751 */ {
return null;
} /* Line: 752 */
bevl_mysize = bevp_size;
bevl_osize = (BEC_4_3_MathInt) beva_stri.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevt_3_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 756 */ {
bevl_maxsize = bevl_osize;
} /* Line: 757 */
 else  /* Line: 758 */ {
bevl_maxsize = bevl_mysize;
} /* Line: 759 */
bevl_myret = (new BEC_4_3_MathInt()).bem_new_0();
bevl_mv = (new BEC_4_3_MathInt()).bem_new_0();
bevl_ov = (new BEC_4_3_MathInt()).bem_new_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 764 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(bevl_maxsize);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 764 */ {
this.bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(340923734, BEL_4_Base.bevn_getCode_2, bevl_i, bevl_ov);
bevt_5_tmpvar_phold = bevl_mv.bem_notEquals_1(bevl_ov);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 767 */ {
bevt_6_tmpvar_phold = bevl_mv.bem_greater_1(bevl_ov);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 768 */ {
bevt_7_tmpvar_phold = (new BEC_4_3_MathInt(1));
return bevt_7_tmpvar_phold;
} /* Line: 769 */
 else  /* Line: 770 */ {
bevt_8_tmpvar_phold = (new BEC_4_3_MathInt(-1));
return bevt_8_tmpvar_phold;
} /* Line: 771 */
} /* Line: 768 */
bevl_i.bem_incrementValue_0();
} /* Line: 764 */
 else  /* Line: 764 */ {
break;
} /* Line: 764 */
} /* Line: 764 */
bevt_10_tmpvar_phold = bevo_25;
bevt_9_tmpvar_phold = bevl_myret.bem_equals_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 775 */ {
bevt_11_tmpvar_phold = bevl_mysize.bem_greater_1(bevl_osize);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 776 */ {
bevl_myret = (new BEC_4_3_MathInt(1));
} /* Line: 777 */
 else  /* Line: 776 */ {
bevt_12_tmpvar_phold = bevl_osize.bem_greater_1(bevl_mysize);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 778 */ {
bevl_myret = (new BEC_4_3_MathInt(-1));
} /* Line: 779 */
} /* Line: 776 */
} /* Line: 776 */
return bevl_myret;
} /*method end*/
public BEC_5_4_LogicBool bem_lesser_1(BEC_4_6_TextString beva_stri) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 786 */ {
return null;
} /* Line: 786 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_26;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 787 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 788 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_greater_1(BEC_4_6_TextString beva_stri) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
if (beva_stri == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 794 */ {
return null;
} /* Line: 794 */
bevt_2_tmpvar_phold = this.bem_compare_1(beva_stri);
bevt_3_tmpvar_phold = bevo_27;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 795 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 796 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_stri) throws Throwable {
BEC_4_3_MathInt bevl_mysize = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_stri == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 809 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /* Line: 810 */

  if (beva_stri instanceof BEC_4_6_TextString) {
    BEC_4_6_TextString bevls_stri = (BEC_4_6_TextString) beva_stri;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BELS_Base.BECS_Runtime.boolFalse;
          }
       }
       return be.BELS_Base.BECS_Runtime.boolTrue;
   }
  }
  bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_str) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_str);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_add_1(BEC_6_6_SystemObject beva_astr) throws Throwable {
BEC_4_6_TextString bevl_str = null;
BEC_4_6_TextString bevl_res = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
bevl_str = (BEC_4_6_TextString) beva_astr.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_1_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevt_0_tmpvar_phold = bevp_size.bem_add_1(bevt_1_tmpvar_phold);
bevl_res = (new BEC_4_6_TextString()).bem_new_1(bevt_0_tmpvar_phold);
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_tmpvar_phold, bevp_size, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_5_tmpvar_phold = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_tmpvar_phold, bevt_5_tmpvar_phold, bevp_size);
return bevl_res;
} /*method end*/
public BEC_4_6_TextString bem_create_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_copyValue_4(BEC_4_6_TextString beva_org, BEC_4_3_MathInt beva_starti, BEC_4_3_MathInt beva_endi, BEC_4_3_MathInt beva_dstarti) throws Throwable {
BEC_4_3_MathInt bevl_mleni = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_6_9_SystemException bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_4_3_MathInt bevt_13_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_28;
bevt_1_tmpvar_phold = beva_starti.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_4_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_3_tmpvar_phold = beva_starti.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_6_tmpvar_phold = beva_org.bem_sizeGet_0();
bevt_5_tmpvar_phold = beva_endi.bem_greater_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 910 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 910 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 910 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 910 */ {
bevt_8_tmpvar_phold = (new BEC_4_6_TextString(31, bels_2));
bevt_7_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_8_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 911 */
 else  /* Line: 912 */ {
if (bevp_leni == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 915 */ {
bevp_leni = (new BEC_4_3_MathInt()).bem_new_0();
bevp_sizi = (new BEC_4_3_MathInt()).bem_new_0();
} /* Line: 917 */
bevp_leni.bem_setValue_1(beva_endi);
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bem_setValue_1(beva_dstarti);
bevp_sizi.bem_addValue_1(bevp_leni);
bevt_10_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_capacity);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 926 */ {
bevt_11_tmpvar_phold = bevp_sizi.bem_copy_0();
this.bem_capacitySet_1(bevt_11_tmpvar_phold);
} /* Line: 927 */

         //source, sourceStart, dest, destStart, length
         System.arraycopy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         bevt_12_tmpvar_phold = bevp_sizi.bem_greater_1(bevp_size);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 982 */ {
bevp_size = bevp_sizi.bem_copy_0();
} /* Line: 986 */
return this;
} /* Line: 988 */
} /*method end*/
public BEC_4_6_TextString bem_substring_1(BEC_4_3_MathInt beva_starti) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sizeGet_0();
bevt_0_tmpvar_phold = this.bem_substring_2(beva_starti, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_substring_2(BEC_4_3_MathInt beva_starti, BEC_4_3_MathInt beva_endi) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_endi.bem_subtract_1(beva_starti);
bevt_1_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_output_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevi_bytes.length - 1);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_print_0() throws Throwable {

System.out.write(bevi_bytes, 0, bevp_size.bevi_int);
System.out.write('\n');
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_echo_0() throws Throwable {
this.bem_output_0();
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_12_TextByteIterator bem_byteIteratorGet_0() throws Throwable {
BEC_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() throws Throwable {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_12_TextByteIterator bem_biterGet_0() throws Throwable {
BEC_4_12_TextByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_17_TextMultiByteIterator bem_mbiterGet_0() throws Throwable {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_17_TextMultiByteIterator bem_stringIteratorGet_0() throws Throwable {
BEC_4_17_TextMultiByteIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_serializeToString_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_6_TextString bem_deserializeFromStringNew_1(BEC_4_6_TextString beva_snw) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
if (beva_snw == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 1114 */ {
this.bem_new_0();
} /* Line: 1115 */
 else  /* Line: 1116 */ {
bevt_2_tmpvar_phold = beva_snw.bem_sizeGet_0();
bevt_3_tmpvar_phold = bevo_29;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
this.bem_new_1(bevt_1_tmpvar_phold);
this.bem_addValue_1(beva_snw);
} /* Line: 1118 */
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_strip_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_strip_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_reverseBytes_0() throws Throwable {
BEC_4_3_MathInt bevl_vb = null;
BEC_4_3_MathInt bevl_ve = null;
BEC_4_3_MathInt bevl_b = null;
BEC_4_3_MathInt bevl_e = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevl_vb = (new BEC_4_3_MathInt()).bem_new_0();
bevl_ve = (new BEC_4_3_MathInt()).bem_new_0();
bevl_b = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = bevo_30;
bevl_e = bevp_size.bem_subtract_1(bevt_0_tmpvar_phold);
while (true)
 /* Line: 1135 */ {
bevt_1_tmpvar_phold = bevl_e.bem_greater_1(bevl_b);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 1135 */ {
this.bem_getInt_2(bevl_b, bevl_vb);
this.bem_getInt_2(bevl_e, bevl_ve);
this.bem_setInt_2(bevl_b, bevl_ve);
this.bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bem_incrementValue_0();
bevl_e.bem_decrementValue_0();
} /* Line: 1141 */
 else  /* Line: 1135 */ {
break;
} /* Line: 1135 */
} /* Line: 1135 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_vstringSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_vstring = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_size;
} /*method end*/
public BEC_6_6_SystemObject bem_sizeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_size = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_4_3_MathInt bem_leniGet_0() throws Throwable {
return bevp_leni;
} /*method end*/
public BEC_6_6_SystemObject bem_leniSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_leni = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_siziGet_0() throws Throwable {
return bevp_sizi;
} /*method end*/
public BEC_6_6_SystemObject bem_siziSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sizi = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {183, 193, 197, 197, 211, 211, 211, 0, 0, 0, 212, 263, 263, 264, 264, 264, 266, 266, 0, 266, 0, 0, 267, 269, 273, 273, 274, 275, 275, 279, 279, 279, 279, 279, 279, 279, 283, 284, 288, 289, 289, 290, 291, 293, 293, 294, 296, 297, 297, 297, 297, 297, 297, 298, 300, 300, 300, 305, 309, 313, 317, 328, 329, 330, 334, 334, 335, 335, 335, 336, 341, 341, 342, 343, 343, 347, 347, 348, 349, 349, 349, 349, 349, 351, 352, 353, 353, 353, 353, 353, 355, 359, 359, 359, 360, 361, 365, 366, 366, 0, 366, 366, 0, 0, 367, 367, 369, 369, 373, 373, 373, 373, 374, 374, 374, 375, 375, 376, 376, 378, 378, 382, 382, 0, 382, 382, 382, 0, 0, 383, 383, 385, 385, 389, 390, 390, 391, 392, 392, 0, 392, 392, 0, 0, 393, 393, 390, 396, 396, 400, 401, 401, 402, 403, 403, 403, 403, 0, 0, 0, 404, 404, 405, 401, 411, 411, 411, 415, 416, 416, 417, 418, 418, 418, 418, 0, 0, 0, 419, 419, 420, 416, 426, 426, 426, 430, 430, 430, 430, 435, 435, 436, 437, 437, 438, 437, 440, 440, 441, 445, 446, 446, 447, 447, 448, 449, 449, 450, 447, 452, 452, 456, 456, 456, 460, 460, 460, 470, 470, 470, 0, 0, 0, 499, 501, 512, 512, 512, 0, 0, 0, 542, 544, 548, 548, 548, 0, 0, 0, 549, 554, 554, 554, 0, 0, 0, 555, 560, 560, 561, 561, 563, 563, 646, 646, 652, 652, 652, 652, 652, 654, 654, 655, 655, 656, 656, 658, 662, 662, 662, 668, 668, 0, 668, 668, 0, 0, 0, 668, 668, 0, 0, 0, 668, 0, 0, 0, 668, 668, 0, 0, 0, 668, 668, 0, 0, 0, 668, 668, 668, 0, 0, 669, 672, 673, 674, 675, 676, 676, 678, 680, 680, 681, 682, 683, 686, 687, 688, 689, 689, 690, 692, 693, 694, 695, 695, 696, 697, 699, 700, 701, 702, 703, 706, 707, 709, 710, 713, 715, 719, 720, 721, 722, 723, 723, 724, 724, 725, 726, 728, 729, 729, 731, 735, 735, 735, 739, 739, 739, 739, 743, 751, 751, 0, 751, 0, 0, 752, 754, 755, 756, 757, 759, 761, 762, 763, 764, 764, 765, 766, 767, 768, 769, 769, 771, 771, 764, 775, 775, 776, 777, 778, 779, 782, 786, 786, 786, 787, 787, 787, 788, 788, 790, 790, 794, 794, 794, 795, 795, 795, 796, 796, 798, 798, 809, 809, 810, 810, 869, 869, 874, 874, 874, 878, 879, 879, 879, 880, 880, 880, 881, 881, 881, 882, 885, 885, 910, 910, 0, 910, 910, 0, 910, 910, 0, 0, 0, 0, 911, 911, 911, 915, 915, 916, 917, 919, 920, 921, 923, 924, 926, 927, 927, 982, 986, 988, 993, 993, 993, 997, 997, 997, 997, 997, 1082, 1086, 1086, 1090, 1090, 1094, 1094, 1098, 1098, 1102, 1102, 1106, 1106, 1110, 1114, 1114, 1115, 1117, 1117, 1117, 1117, 1118, 1123, 1123, 1127, 1127, 1127, 1131, 1132, 1133, 1134, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {86, 87, 92, 93, 107, 112, 113, 115, 118, 122, 125, 133, 138, 139, 140, 141, 143, 148, 149, 152, 154, 157, 161, 163, 169, 170, 171, 172, 173, 183, 184, 185, 186, 187, 188, 189, 193, 194, 210, 211, 216, 217, 218, 220, 221, 222, 223, 225, 226, 227, 228, 229, 230, 231, 233, 234, 235, 239, 242, 245, 249, 260, 261, 262, 269, 270, 272, 273, 274, 275, 282, 283, 284, 285, 286, 302, 303, 304, 306, 307, 308, 309, 310, 312, 313, 315, 316, 317, 318, 319, 321, 327, 328, 329, 330, 331, 341, 342, 347, 348, 351, 352, 354, 357, 361, 362, 364, 365, 376, 381, 382, 383, 385, 386, 387, 388, 393, 394, 395, 397, 398, 407, 412, 413, 416, 417, 422, 423, 426, 430, 431, 433, 434, 447, 448, 451, 453, 454, 455, 457, 460, 461, 463, 466, 470, 471, 473, 479, 480, 492, 493, 496, 498, 499, 500, 502, 503, 505, 508, 512, 515, 516, 517, 519, 530, 531, 532, 544, 545, 548, 550, 551, 552, 554, 555, 557, 560, 564, 567, 568, 569, 571, 582, 583, 584, 590, 591, 592, 593, 603, 604, 605, 606, 609, 611, 612, 618, 619, 620, 629, 630, 631, 632, 635, 637, 638, 639, 640, 641, 647, 648, 653, 654, 655, 660, 661, 662, 669, 670, 672, 674, 677, 681, 688, 690, 697, 698, 700, 702, 705, 709, 719, 721, 728, 729, 731, 733, 736, 740, 743, 752, 753, 755, 757, 760, 764, 767, 776, 777, 779, 780, 782, 783, 801, 802, 813, 814, 815, 816, 817, 818, 823, 824, 825, 826, 827, 829, 834, 835, 836, 878, 883, 884, 887, 892, 893, 896, 900, 903, 904, 906, 909, 913, 916, 918, 921, 925, 928, 929, 931, 934, 938, 941, 942, 944, 947, 951, 954, 955, 956, 958, 961, 965, 967, 968, 969, 970, 971, 972, 973, 974, 975, 977, 978, 979, 983, 985, 986, 988, 989, 991, 993, 994, 995, 996, 997, 998, 1000, 1002, 1005, 1007, 1008, 1009, 1013, 1014, 1020, 1022, 1025, 1031, 1042, 1043, 1044, 1045, 1048, 1053, 1054, 1055, 1056, 1057, 1063, 1065, 1066, 1068, 1073, 1074, 1075, 1081, 1082, 1083, 1084, 1087, 1110, 1115, 1116, 1119, 1121, 1124, 1128, 1130, 1131, 1132, 1134, 1137, 1139, 1140, 1141, 1142, 1145, 1147, 1148, 1149, 1151, 1153, 1154, 1157, 1158, 1161, 1167, 1168, 1170, 1172, 1175, 1177, 1181, 1190, 1195, 1196, 1198, 1199, 1200, 1202, 1203, 1205, 1206, 1215, 1220, 1221, 1223, 1224, 1225, 1227, 1228, 1230, 1231, 1243, 1248, 1249, 1250, 1264, 1265, 1270, 1271, 1272, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293, 1297, 1298, 1316, 1317, 1319, 1322, 1323, 1325, 1328, 1329, 1331, 1334, 1338, 1341, 1345, 1346, 1347, 1350, 1355, 1356, 1357, 1359, 1360, 1361, 1362, 1363, 1364, 1366, 1367, 1372, 1374, 1376, 1382, 1383, 1384, 1391, 1392, 1393, 1394, 1395, 1409, 1414, 1415, 1419, 1420, 1424, 1425, 1429, 1430, 1434, 1435, 1439, 1440, 1443, 1450, 1455, 1456, 1459, 1460, 1461, 1462, 1463, 1469, 1470, 1475, 1476, 1477, 1486, 1487, 1488, 1489, 1490, 1493, 1495, 1496, 1497, 1498, 1499, 1500, 1509, 1513, 1516, 1520, 1523, 1526, 1530, 1533};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
capacitySet 1 183 86
assign 1 193 87
new 0 193 87
assign 1 197 92
new 0 197 92
new 1 197 93
assign 1 211 107
def 1 211 112
assign 1 211 113
equals 1 211 113
assign 1 0 115
assign 1 0 118
assign 1 0 122
return 1 212 125
assign 1 263 133
def 1 263 138
assign 1 264 139
new 0 264 139
assign 1 264 140
new 1 264 140
throw 1 264 141
assign 1 266 143
undef 1 266 148
assign 1 0 149
assign 1 266 152
greater 1 266 152
assign 1 0 154
assign 1 0 157
assign 1 267 161
copy 0 267 161
assign 1 269 163
assign 1 273 169
new 0 273 169
new 1 273 170
assign 1 274 171
new 0 274 171
assign 1 275 172
new 0 275 172
setHex 2 275 173
assign 1 279 183
new 0 279 183
assign 1 279 184
getCode 2 279 184
assign 1 279 185
new 0 279 185
assign 1 279 186
new 0 279 186
assign 1 279 187
new 0 279 187
assign 1 279 188
toString 3 279 188
return 1 279 189
assign 1 283 193
hexNew 1 283 193
setCode 2 284 194
assign 1 288 210
toString 0 288 210
assign 1 289 211
undef 1 289 216
assign 1 290 217
new 0 290 217
assign 1 291 218
new 0 291 218
assign 1 293 220
sizeGet 0 293 220
setValue 1 293 221
addValue 1 294 222
assign 1 296 223
lesser 1 296 223
assign 1 297 225
new 0 297 225
assign 1 297 226
add 1 297 226
assign 1 297 227
new 0 297 227
assign 1 297 228
multiply 1 297 228
assign 1 297 229
new 0 297 229
assign 1 297 230
divide 1 297 230
capacitySet 1 298 231
assign 1 300 233
new 0 300 233
assign 1 300 234
sizeGet 0 300 234
copyValue 4 300 235
return 1 305 239
return 1 309 242
addValue 1 313 245
write 1 317 249
assign 1 328 260
copy 0 328 260
clear 0 329 261
return 1 330 262
assign 1 334 269
new 0 334 269
assign 1 334 270
greater 1 334 270
assign 1 335 272
new 0 335 272
assign 1 335 273
new 0 335 273
setIntUnchecked 2 335 274
assign 1 336 275
new 0 336 275
assign 1 341 282
new 0 341 282
new 1 341 283
assign 1 342 284
new 0 342 284
assign 1 343 285
new 0 343 285
setCodeUnchecked 2 343 286
assign 1 347 302
new 0 347 302
assign 1 347 303
newlineGet 0 347 303
assign 1 348 304
ends 1 348 304
assign 1 349 306
new 0 349 306
assign 1 349 307
sizeGet 0 349 307
assign 1 349 308
subtract 1 349 308
assign 1 349 309
substring 2 349 309
return 1 349 310
assign 1 351 312
new 0 351 312
assign 1 352 313
ends 1 352 313
assign 1 353 315
new 0 353 315
assign 1 353 316
sizeGet 0 353 316
assign 1 353 317
subtract 1 353 317
assign 1 353 318
substring 2 353 318
return 1 353 319
return 1 355 321
assign 1 359 327
new 0 359 327
assign 1 359 328
add 1 359 328
assign 1 359 329
new 1 359 329
addValue 1 360 330
return 1 361 331
assign 1 365 341
find 1 365 341
assign 1 366 342
undef 1 366 347
assign 1 0 348
assign 1 366 351
new 0 366 351
assign 1 366 352
notEquals 1 366 352
assign 1 0 354
assign 1 0 357
assign 1 367 361
new 0 367 361
return 1 367 362
assign 1 369 364
new 0 369 364
return 1 369 365
assign 1 373 376
undef 1 373 381
assign 1 373 382
new 0 373 382
return 1 373 383
assign 1 374 385
sizeGet 0 374 385
assign 1 374 386
subtract 1 374 386
assign 1 374 387
find 2 374 387
assign 1 375 388
undef 1 375 393
assign 1 376 394
new 0 376 394
return 1 376 395
assign 1 378 397
new 0 378 397
return 1 378 398
assign 1 382 407
undef 1 382 412
assign 1 0 413
assign 1 382 416
find 1 382 416
assign 1 382 417
undef 1 382 422
assign 1 0 423
assign 1 0 426
assign 1 383 430
new 0 383 430
return 1 383 431
assign 1 385 433
new 0 385 433
return 1 385 434
assign 1 389 447
new 0 389 447
assign 1 390 448
new 0 390 448
assign 1 390 451
lesser 1 390 451
getInt 2 391 453
assign 1 392 454
new 0 392 454
assign 1 392 455
greater 1 392 455
assign 1 0 457
assign 1 392 460
new 0 392 460
assign 1 392 461
lesser 1 392 461
assign 1 0 463
assign 1 0 466
assign 1 393 470
new 0 393 470
return 1 393 471
incrementValue 0 390 473
assign 1 396 479
new 0 396 479
return 1 396 480
assign 1 400 492
new 0 400 492
assign 1 401 493
new 0 401 493
assign 1 401 496
lesser 1 401 496
getInt 2 402 498
assign 1 403 499
new 0 403 499
assign 1 403 500
greater 1 403 500
assign 1 403 502
new 0 403 502
assign 1 403 503
lesser 1 403 503
assign 1 0 505
assign 1 0 508
assign 1 0 512
assign 1 404 515
new 0 404 515
addValue 1 404 516
setIntUnchecked 2 405 517
incrementValue 0 401 519
assign 1 411 530
copy 0 411 530
assign 1 411 531
lowerValue 0 411 531
return 1 411 532
assign 1 415 544
new 0 415 544
assign 1 416 545
new 0 416 545
assign 1 416 548
lesser 1 416 548
getInt 2 417 550
assign 1 418 551
new 0 418 551
assign 1 418 552
greater 1 418 552
assign 1 418 554
new 0 418 554
assign 1 418 555
lesser 1 418 555
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 419 567
new 0 419 567
subtractValue 1 419 568
setIntUnchecked 2 420 569
incrementValue 0 416 571
assign 1 426 582
copy 0 426 582
assign 1 426 583
upperValue 0 426 583
return 1 426 584
assign 1 430 590
new 0 430 590
assign 1 430 591
split 1 430 591
assign 1 430 592
join 2 430 592
return 1 430 593
assign 1 435 603
new 0 435 603
assign 1 435 604
new 1 435 604
assign 1 436 605
mbiterGet 0 436 605
assign 1 437 606
new 0 437 606
assign 1 437 609
lesser 1 437 609
next 1 438 611
assign 1 437 612
increment 0 437 612
assign 1 440 618
next 1 440 618
assign 1 440 619
toString 0 440 619
return 1 441 620
assign 1 445 629
new 0 445 629
assign 1 446 630
new 0 446 630
setValue 1 446 631
assign 1 447 632
new 0 447 632
assign 1 447 635
lesser 1 447 635
getInt 2 448 637
assign 1 449 638
new 0 449 638
multiplyValue 1 449 639
addValue 1 450 640
incrementValue 0 447 641
assign 1 452 647
absValue 0 452 647
return 1 452 648
assign 1 456 653
new 0 456 653
assign 1 456 654
hashValue 1 456 654
return 1 456 655
assign 1 460 660
new 0 460 660
assign 1 460 661
getCode 2 460 661
return 1 460 662
assign 1 470 669
new 0 470 669
assign 1 470 670
greaterEquals 1 470 670
assign 1 470 672
greater 1 470 672
assign 1 0 674
assign 1 0 677
assign 1 0 681
return 1 499 688
return 1 501 690
assign 1 512 697
new 0 512 697
assign 1 512 698
greaterEquals 1 512 698
assign 1 512 700
greater 1 512 700
assign 1 0 702
assign 1 0 705
assign 1 0 709
return 1 542 719
return 1 544 721
assign 1 548 728
new 0 548 728
assign 1 548 729
greaterEquals 1 548 729
assign 1 548 731
greater 1 548 731
assign 1 0 733
assign 1 0 736
assign 1 0 740
setIntUnchecked 2 549 743
assign 1 554 752
new 0 554 752
assign 1 554 753
greaterEquals 1 554 753
assign 1 554 755
greater 1 554 755
assign 1 0 757
assign 1 0 760
assign 1 0 764
setCodeUnchecked 2 555 767
assign 1 560 776
new 0 560 776
assign 1 560 777
lesserEquals 1 560 777
assign 1 561 779
new 0 561 779
return 1 561 780
assign 1 563 782
new 0 563 782
return 1 563 783
assign 1 646 801
rfind 1 646 801
return 1 646 802
assign 1 652 813
copy 0 652 813
assign 1 652 814
reverseBytes 0 652 814
assign 1 652 815
copy 0 652 815
assign 1 652 816
reverseBytes 0 652 816
assign 1 652 817
find 1 652 817
assign 1 654 818
def 1 654 823
assign 1 655 824
sizeGet 0 655 824
addValue 1 655 825
assign 1 656 826
subtract 1 656 826
return 1 656 827
return 1 658 829
assign 1 662 834
new 0 662 834
assign 1 662 835
find 2 662 835
return 1 662 836
assign 1 668 878
undef 1 668 883
assign 1 0 884
assign 1 668 887
undef 1 668 892
assign 1 0 893
assign 1 0 896
assign 1 0 900
assign 1 668 903
new 0 668 903
assign 1 668 904
lesser 1 668 904
assign 1 0 906
assign 1 0 909
assign 1 0 913
assign 1 668 916
greaterEquals 1 668 916
assign 1 0 918
assign 1 0 921
assign 1 0 925
assign 1 668 928
sizeGet 0 668 928
assign 1 668 929
greater 1 668 929
assign 1 0 931
assign 1 0 934
assign 1 0 938
assign 1 668 941
new 0 668 941
assign 1 668 942
equals 1 668 942
assign 1 0 944
assign 1 0 947
assign 1 0 951
assign 1 668 954
sizeGet 0 668 954
assign 1 668 955
new 0 668 955
assign 1 668 956
equals 1 668 956
assign 1 0 958
assign 1 0 961
return 1 669 965
assign 1 672 967
assign 1 673 968
copy 0 673 968
assign 1 674 969
new 0 674 969
assign 1 675 970
new 0 675 970
assign 1 676 971
new 0 676 971
getInt 2 676 972
assign 1 678 973
sizeGet 0 678 973
assign 1 680 974
new 0 680 974
assign 1 680 975
greater 1 680 975
assign 1 681 977
new 0 681 977
assign 1 682 978
new 0 682 978
assign 1 683 979
new 0 683 979
assign 1 686 983
lesser 1 686 983
getInt 2 687 985
assign 1 688 986
equals 1 688 986
assign 1 689 988
new 0 689 988
assign 1 689 989
equals 1 689 989
return 1 690 991
setValue 1 692 993
incrementValue 0 693 994
setValue 1 694 995
assign 1 695 996
sizeGet 0 695 996
addValue 1 695 997
assign 1 696 998
greater 1 696 998
return 1 697 1000
assign 1 699 1002
new 0 699 1002
assign 1 700 1005
lesser 1 700 1005
getInt 2 701 1007
getInt 2 702 1008
assign 1 703 1009
notEquals 1 703 1009
incrementValue 0 706 1013
incrementValue 0 707 1014
assign 1 709 1020
equals 1 709 1020
return 1 710 1022
incrementValue 0 713 1025
return 1 715 1031
assign 1 719 1042
new 0 719 1042
assign 1 720 1043
new 0 720 1043
assign 1 721 1044
find 2 721 1044
assign 1 722 1045
sizeGet 0 722 1045
assign 1 723 1048
def 1 723 1053
assign 1 724 1054
substring 2 724 1054
addValue 1 724 1055
assign 1 725 1056
add 1 725 1056
assign 1 726 1057
find 2 726 1057
assign 1 728 1063
lesser 1 728 1063
assign 1 729 1065
substring 2 729 1065
addValue 1 729 1066
return 1 731 1068
assign 1 735 1073
new 0 735 1073
assign 1 735 1074
join 2 735 1074
return 1 735 1075
assign 1 739 1081
new 0 739 1081
assign 1 739 1082
lineSplitterGet 0 739 1082
assign 1 739 1083
tokenize 1 739 1083
return 1 739 1084
return 1 743 1087
assign 1 751 1110
undef 1 751 1115
assign 1 0 1116
assign 1 751 1119
otherType 1 751 1119
assign 1 0 1121
assign 1 0 1124
return 1 752 1128
assign 1 754 1130
assign 1 755 1131
sizeGet 0 755 1131
assign 1 756 1132
greater 1 756 1132
assign 1 757 1134
assign 1 759 1137
assign 1 761 1139
new 0 761 1139
assign 1 762 1140
new 0 762 1140
assign 1 763 1141
new 0 763 1141
assign 1 764 1142
new 0 764 1142
assign 1 764 1145
lesser 1 764 1145
getCode 2 765 1147
getCode 2 766 1148
assign 1 767 1149
notEquals 1 767 1149
assign 1 768 1151
greater 1 768 1151
assign 1 769 1153
new 0 769 1153
return 1 769 1154
assign 1 771 1157
new 0 771 1157
return 1 771 1158
incrementValue 0 764 1161
assign 1 775 1167
new 0 775 1167
assign 1 775 1168
equals 1 775 1168
assign 1 776 1170
greater 1 776 1170
assign 1 777 1172
new 0 777 1172
assign 1 778 1175
greater 1 778 1175
assign 1 779 1177
new 0 779 1177
return 1 782 1181
assign 1 786 1190
undef 1 786 1195
return 1 786 1196
assign 1 787 1198
compare 1 787 1198
assign 1 787 1199
new 0 787 1199
assign 1 787 1200
equals 1 787 1200
assign 1 788 1202
new 0 788 1202
return 1 788 1203
assign 1 790 1205
new 0 790 1205
return 1 790 1206
assign 1 794 1215
undef 1 794 1220
return 1 794 1221
assign 1 795 1223
compare 1 795 1223
assign 1 795 1224
new 0 795 1224
assign 1 795 1225
equals 1 795 1225
assign 1 796 1227
new 0 796 1227
return 1 796 1228
assign 1 798 1230
new 0 798 1230
return 1 798 1231
assign 1 809 1243
undef 1 809 1248
assign 1 810 1249
new 0 810 1249
return 1 810 1250
assign 1 869 1264
new 0 869 1264
return 1 869 1265
assign 1 874 1270
equals 1 874 1270
assign 1 874 1271
not 0 874 1271
return 1 874 1272
assign 1 878 1283
toString 0 878 1283
assign 1 879 1284
sizeGet 0 879 1284
assign 1 879 1285
add 1 879 1285
assign 1 879 1286
new 1 879 1286
assign 1 880 1287
new 0 880 1287
assign 1 880 1288
new 0 880 1288
copyValue 4 880 1289
assign 1 881 1290
new 0 881 1290
assign 1 881 1291
sizeGet 0 881 1291
copyValue 4 881 1292
return 1 882 1293
assign 1 885 1297
new 0 885 1297
return 1 885 1298
assign 1 910 1316
new 0 910 1316
assign 1 910 1317
lesser 1 910 1317
assign 1 0 1319
assign 1 910 1322
sizeGet 0 910 1322
assign 1 910 1323
greater 1 910 1323
assign 1 0 1325
assign 1 910 1328
sizeGet 0 910 1328
assign 1 910 1329
greater 1 910 1329
assign 1 0 1331
assign 1 0 1334
assign 1 0 1338
assign 1 0 1341
assign 1 911 1345
new 0 911 1345
assign 1 911 1346
new 1 911 1346
throw 1 911 1347
assign 1 915 1350
undef 1 915 1355
assign 1 916 1356
new 0 916 1356
assign 1 917 1357
new 0 917 1357
setValue 1 919 1359
subtractValue 1 920 1360
assign 1 921 1361
setValue 1 923 1362
addValue 1 924 1363
assign 1 926 1364
greater 1 926 1364
assign 1 927 1366
copy 0 927 1366
capacitySet 1 927 1367
assign 1 982 1372
greater 1 982 1372
assign 1 986 1374
copy 0 986 1374
return 1 988 1376
assign 1 993 1382
sizeGet 0 993 1382
assign 1 993 1383
substring 2 993 1383
return 1 993 1384
assign 1 997 1391
subtract 1 997 1391
assign 1 997 1392
new 1 997 1392
assign 1 997 1393
new 0 997 1393
assign 1 997 1394
copyValue 4 997 1394
return 1 997 1395
output 0 1082 1409
assign 1 1086 1414
new 1 1086 1414
return 1 1086 1415
assign 1 1090 1419
new 1 1090 1419
return 1 1090 1420
assign 1 1094 1424
new 1 1094 1424
return 1 1094 1425
assign 1 1098 1429
new 1 1098 1429
return 1 1098 1430
assign 1 1102 1434
new 1 1102 1434
return 1 1102 1435
assign 1 1106 1439
new 1 1106 1439
return 1 1106 1440
return 1 1110 1443
assign 1 1114 1450
undef 1 1114 1455
new 0 1115 1456
assign 1 1117 1459
sizeGet 0 1117 1459
assign 1 1117 1460
new 0 1117 1460
assign 1 1117 1461
add 1 1117 1461
new 1 1117 1462
addValue 1 1118 1463
assign 1 1123 1469
new 0 1123 1469
return 1 1123 1470
assign 1 1127 1475
new 0 1127 1475
assign 1 1127 1476
strip 1 1127 1476
return 1 1127 1477
assign 1 1131 1486
new 0 1131 1486
assign 1 1132 1487
new 0 1132 1487
assign 1 1133 1488
new 0 1133 1488
assign 1 1134 1489
new 0 1134 1489
assign 1 1134 1490
subtract 1 1134 1490
assign 1 1135 1493
greater 1 1135 1493
getInt 2 1136 1495
getInt 2 1137 1496
setInt 2 1138 1497
setInt 2 1139 1498
incrementValue 0 1140 1499
decrementValue 0 1141 1500
assign 1 0 1509
return 1 0 1513
assign 1 0 1516
return 1 0 1520
return 1 0 1523
assign 1 0 1526
return 1 0 1530
assign 1 0 1533
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 751851582: return bem_chomp_0();
case 1325881255: return bem_readBuffer_0();
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 1670870885: return bem_isInteger_0();
case 825000908: return bem_vstringSet_0();
case 813918656: return bem_vstringGet_0();
case 1163089440: return bem_upperValue_0();
case 856777406: return bem_clear_0();
case 347960120: return bem_readString_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 223231021: return bem_upper_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 474162694: return bem_sizeGet_0();
case 1424677667: return bem_extractString_0();
case 855090856: return bem_multiByteIteratorGet_0();
case 1903477087: return bem_lowerValue_0();
case 70183026: return bem_output_0();
case 416660294: return bem_objectIteratorGet_0();
case 195899181: return bem_biterGet_0();
case 1010579589: return bem_open_0();
case 357005938: return bem_lower_0();
case 866536361: return bem_close_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1607888168: return bem_stringIteratorGet_0();
case 1820417453: return bem_create_0();
case 588679298: return bem_siziGet_0();
case 729571811: return bem_serializeToString_0();
case 1343944081: return bem_byteIteratorGet_0();
case 1881757495: return bem_strip_0();
case 139115914: return bem_splitLines_0();
case 1751843603: return bem_capacityGet_0();
case 1896696666: return bem_mbiterGet_0();
case 800915430: return bem_reverseBytes_0();
case 1354714650: return bem_copy_0();
case 85457677: return bem_leniGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 599761551: return bem_siziSet_1(bevd_0);
case 1274448085: return bem_find_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1143153819: return bem_codeNew_1(bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_4_3_MathInt) bevd_0);
case 1954998871: return bem_getHex_1((BEC_4_3_MathInt) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1406325780: return bem_writeTo_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 2001811380: return bem_split_1((BEC_4_6_TextString) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1320649901: return bem_reverseFind_1((BEC_4_6_TextString) bevd_0);
case 636254476: return bem_getPoint_1((BEC_4_3_MathInt) bevd_0);
case 1958502700: return bem_greater_1((BEC_4_6_TextString) bevd_0);
case 1250088509: return bem_substring_1((BEC_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1603004369: return bem_write_1(bevd_0);
case 1489442332: return bem_begins_1((BEC_4_6_TextString) bevd_0);
case 74375424: return bem_leniSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 485244947: return bem_sizeSet_1(bevd_0);
case 1298743126: return bem_ends_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 340923733: return bem_getCode_1((BEC_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 825000909: return bem_vstringSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1412717737: return bem_compare_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1274753013: return bem_hashValue_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 1116723741: return bem_rfind_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 477101321: return bem_hexNew_1((BEC_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1395074208: return bem_setInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 2110339634: return bem_setCodeUnchecked_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1154529699: return bem_join_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 889715578: return bem_swap_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1393886412: return bem_setHex_2((BEC_4_3_MathInt) bevd_0, (BEC_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 761715532: return bem_setIntUnchecked_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1250088508: return bem_substring_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 126306658: return bem_setCode_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1274448084: return bem_find_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 340923734: return bem_getCode_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1956186668: return bem_getInt_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_4(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2, BEC_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 391213135: return bem_copyValue_4((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1, (BEC_4_3_MathInt) bevd_2, (BEC_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_6_TextString();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_6_TextString.bevs_inst = (BEC_4_6_TextString)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_6_TextString.bevs_inst;
}
}
