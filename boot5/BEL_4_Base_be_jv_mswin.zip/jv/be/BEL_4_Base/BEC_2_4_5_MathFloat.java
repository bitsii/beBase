package be.BEL_4_Base;
/* IO:File: source/base/Float.be */
public final class BEC_2_4_5_MathFloat extends BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2D};
private static byte[] bels_1 = {0x2E};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(10));
private static byte[] bels_2 = {0x2E};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_2, 1));
public static BEC_2_4_5_MathFloat bevs_inst;
public BEC_2_6_6_SystemObject bem_vfloatGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vfloatSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) throws Throwable {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_5_MathFloat bevt_21_tmpvar_phold = null;
BEC_2_4_5_MathFloat bevt_22_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_0));
bevt_0_tmpvar_phold = beva_si.bemd_1(1489442332, BEL_4_Base.bevn_begins_1, bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 60 */ {
bevl_neg = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(-1250088509, BEL_4_Base.bevn_substring_1, bevt_2_tmpvar_phold);
} /* Line: 62 */
 else  /* Line: 63 */ {
bevl_neg = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 64 */
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(-1274448085, BEL_4_Base.bevn_find_1, bevt_3_tmpvar_phold);
if (bevl_dec == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 67 */ {
bevt_6_tmpvar_phold = bevo_0;
if (bevl_dec.bevi_int > bevt_6_tmpvar_phold.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevt_8_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_7_tmpvar_phold = beva_si.bemd_2(-1250088508, BEL_4_Base.bevn_substring_2, bevt_8_tmpvar_phold, bevl_dec);
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_tmpvar_phold);
} /* Line: 69 */
 else  /* Line: 70 */ {
bevl_lhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 71 */
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = bevl_dec.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = beva_si.bemd_0(474162694, BEL_4_Base.bevn_sizeGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 73 */ {
bevt_15_tmpvar_phold = bevo_2;
bevt_14_tmpvar_phold = bevl_dec.bem_add_1(bevt_15_tmpvar_phold);
bevt_13_tmpvar_phold = beva_si.bemd_1(-1250088509, BEL_4_Base.bevn_substring_1, bevt_14_tmpvar_phold);
bevl_rhs = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_tmpvar_phold);
} /* Line: 74 */
 else  /* Line: 75 */ {
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 76 */
} /* Line: 73 */
 else  /* Line: 78 */ {
bevl_lhs = (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (new BEC_2_4_3_MathInt(0));
} /* Line: 80 */
bevt_16_tmpvar_phold = bevo_3;
bevt_18_tmpvar_phold = bevl_rhs.bem_toString_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bem_sizeGet_0();
bevl_divby = bevt_16_tmpvar_phold.bem_power_1(bevt_17_tmpvar_phold);
if (bevl_neg.bevi_bool) /* Line: 83 */ {
bevt_19_tmpvar_phold = (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_tmpvar_phold);
} /* Line: 85 */
bevt_21_tmpvar_phold = bevl_rhs.bem_toFloat_0();
bevt_22_tmpvar_phold = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_tmpvar_phold.bem_divide_1(bevt_22_tmpvar_phold);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public BEC_2_4_5_MathFloat bem_create_0() throws Throwable {
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_4_5_MathFloat) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
this.bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() throws Throwable {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toInt_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
BEC_2_4_5_MathFloat bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
bevl_lhi = this.bem_toInt_0();
bevt_0_tmpvar_phold = bevl_lhi.bem_toFloat_0();
bevl_rh = this.bem_subtract_1(bevt_0_tmpvar_phold);
bevt_1_tmpvar_phold = (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_tmpvar_phold);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_tmpvar_phold = bevl_lhi.bem_toString_0();
bevt_5_tmpvar_phold = bevo_4;
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevl_rhi.bem_toString_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_6_tmpvar_phold);
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 140 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 147 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 155 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 162 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 170 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 177 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 185 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 192 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 200 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 207 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
 /* Line: 215 */ {
bevl_res = (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 222 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_4_5_MathFloat bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float == ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float != ((BEC_2_4_5_MathFloat)beva_xi).bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {60, 60, 61, 62, 62, 64, 66, 66, 67, 67, 68, 68, 68, 69, 69, 69, 71, 73, 73, 73, 73, 74, 74, 74, 74, 76, 79, 80, 82, 82, 82, 82, 84, 84, 85, 85, 87, 87, 87, 88, 89, 90, 93, 93, 96, 96, 100, 104, 104, 115, 123, 128, 128, 132, 133, 133, 134, 134, 135, 136, 136, 136, 136, 136, 136, 141, 147, 156, 162, 171, 177, 186, 192, 201, 207, 216, 222, 230, 230, 259, 259, 288, 288, 309, 309, 330, 330, 351, 351, 372, 372};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {62, 63, 65, 66, 67, 70, 72, 73, 74, 79, 80, 81, 86, 87, 88, 89, 92, 94, 95, 96, 97, 99, 100, 101, 102, 105, 109, 110, 112, 113, 114, 115, 117, 118, 119, 120, 122, 123, 124, 125, 126, 127, 131, 132, 136, 137, 140, 145, 146, 150, 151, 155, 156, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 186, 189, 196, 199, 206, 209, 216, 219, 226, 229, 236, 239, 244, 245, 254, 255, 264, 265, 274, 275, 284, 285, 294, 295, 304, 305};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 60 62
new 0 60 62
assign 1 60 63
begins 1 60 63
assign 1 61 65
new 0 61 65
assign 1 62 66
new 0 62 66
assign 1 62 67
substring 1 62 67
assign 1 64 70
new 0 64 70
assign 1 66 72
new 0 66 72
assign 1 66 73
find 1 66 73
assign 1 67 74
def 1 67 79
assign 1 68 80
new 0 68 80
assign 1 68 81
greater 1 68 86
assign 1 69 87
new 0 69 87
assign 1 69 88
substring 2 69 88
assign 1 69 89
new 1 69 89
assign 1 71 92
new 0 71 92
assign 1 73 94
new 0 73 94
assign 1 73 95
add 1 73 95
assign 1 73 96
sizeGet 0 73 96
assign 1 73 97
lesser 1 73 97
assign 1 74 99
new 0 74 99
assign 1 74 100
add 1 74 100
assign 1 74 101
substring 1 74 101
assign 1 74 102
new 1 74 102
assign 1 76 105
new 0 76 105
assign 1 79 109
new 1 79 109
assign 1 80 110
new 0 80 110
assign 1 82 112
new 0 82 112
assign 1 82 113
toString 0 82 113
assign 1 82 114
sizeGet 0 82 114
assign 1 82 115
power 1 82 115
assign 1 84 117
new 0 84 117
multiplyValue 1 84 118
assign 1 85 119
new 0 85 119
multiplyValue 1 85 120
assign 1 87 122
toFloat 0 87 122
assign 1 87 123
toFloat 0 87 123
assign 1 87 124
divide 1 87 124
assign 1 88 125
toFloat 0 88 125
assign 1 89 126
add 1 89 126
return 1 90 127
assign 1 93 131
new 0 93 131
return 1 93 132
assign 1 96 136
toString 0 96 136
return 1 96 137
new 1 100 140
assign 1 104 145
new 0 104 145
return 1 104 146
assign 1 115 150
new 0 115 150
return 1 123 151
assign 1 128 155
toInt 0 128 155
return 1 128 156
assign 1 132 169
toInt 0 132 169
assign 1 133 170
toFloat 0 133 170
assign 1 133 171
subtract 1 133 171
assign 1 134 172
new 0 134 172
assign 1 134 173
multiply 1 134 173
assign 1 135 174
toInt 0 135 174
assign 1 136 175
toString 0 136 175
assign 1 136 176
new 0 136 176
assign 1 136 177
add 1 136 177
assign 1 136 178
toString 0 136 178
assign 1 136 179
add 1 136 179
return 1 136 180
assign 1 141 186
new 0 141 186
return 1 147 189
assign 1 156 196
new 0 156 196
return 1 162 199
assign 1 171 206
new 0 171 206
return 1 177 209
assign 1 186 216
new 0 186 216
return 1 192 219
assign 1 201 226
new 0 201 226
return 1 207 229
assign 1 216 236
new 0 216 236
return 1 222 239
assign 1 230 244
new 0 230 244
return 1 230 245
assign 1 259 254
new 0 259 254
return 1 259 255
assign 1 288 264
new 0 288 264
return 1 288 265
assign 1 309 274
new 0 309 274
return 1 309 275
assign 1 330 284
new 0 330 284
return 1 330 285
assign 1 351 294
new 0 351 294
return 1 351 295
assign 1 372 304
new 0 372 304
return 1 372 305
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case -1046151292: return bem_decrement_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -1175111131: return bem_toInt_0();
case 443668840: return bem_methodNotDefined_0();
case 1679729549: return bem_vfloatSet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1085372256: return bem_increment_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case 1668647297: return bem_vfloatGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case -1551584407: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case 81310150: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 364269035: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case 1265088726: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -979186229: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_5_MathFloat();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_5_MathFloat.bevs_inst = (BEC_2_4_5_MathFloat)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_5_MathFloat.bevs_inst;
}
}
