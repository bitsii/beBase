package be.BEL_4_Base;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_10_JsonMarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_10_JsonMarshaller() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x4D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_1 = {0x31,0x46};
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_2 = {0x46};
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(4));
private static byte[] bels_3 = {0x37};
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_4 = {0x33,0x46};
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_5 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bels_6 = {0x5C,0x75};
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(87));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(13));
private static byte[] bels_7 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bels_8 = {0x44,0x38,0x30,0x30};
private static byte[] bels_9 = {0x66,0x66,0x63,0x30,0x30};
private static byte[] bels_10 = {0x44,0x43,0x30,0x30};
private static byte[] bels_11 = {0x30,0x30,0x33,0x66,0x66};
private static byte[] bels_12 = {0x5C,0x75};
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(87));
private static byte[] bels_13 = {0x5C,0x75};
private static BEC_2_4_3_MathInt bevo_18 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_20 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_21 = (new BEC_2_4_3_MathInt(87));
private static byte[] bels_14 = {0x5B};
private static byte[] bels_15 = {0x2C};
private static byte[] bels_16 = {0x5D};
private static byte[] bels_17 = {0x7B};
private static byte[] bels_18 = {0x2C};
private static byte[] bels_19 = {0x3A};
private static byte[] bels_20 = {0x7D};
public static BEC_2_4_10_JsonMarshaller bevs_inst;
public BEC_2_4_6_TextString bevp_str;
public BEC_2_9_10_ContainerLinkedList bevp_lls;
public BEC_2_9_5_ContainerArray bevp_arr;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_boo;
public BEC_2_4_6_TextString bevp_q;
public BEC_2_4_17_TextMultiByteIterator bevp_mbi;
public BEC_2_4_6_TextString bevp_txtpt;
public BEC_2_4_6_TextString bevp_escaped;
public BEC_2_4_10_JsonMarshaller bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevp_str = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_lls = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevp_arr = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
bevp_boo = (new BEC_2_5_4_LogicBool()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevp_q = bevt_1_tmpvar_phold.bem_quoteGet_0();
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_0();
bevp_txtpt = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_escaped = (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_marshall_1(BEC_2_6_6_SystemObject beva_inst) throws Throwable {
BEC_2_4_6_TextString bevl_bb = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
if (bevp_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 314 */ {
this.bem_new_0();
} /* Line: 315 */
bevl_bb = (new BEC_2_4_6_TextString()).bem_new_0();
this.bem_marshallWriteInst_2(beva_inst, bevl_bb);
bevt_1_tmpvar_phold = bevl_bb.bem_toString_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_marshallWrite_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 323 */ {
this.bem_new_0();
} /* Line: 324 */
this.bem_marshallWriteInst_2(beva_inst, beva_writer);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_marshallWriteInst_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
if (beva_inst == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 330 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_0));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_2_tmpvar_phold);
} /* Line: 331 */
 else  /* Line: 330 */ {
bevt_3_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_str);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 332 */ {
this.bem_marshallWriteString_2((BEC_2_4_6_TextString) beva_inst, beva_writer);
} /* Line: 333 */
 else  /* Line: 330 */ {
bevt_4_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_lls);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 334 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_5_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_arr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 334 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 334 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 334 */ {
this.bem_marshallWriteList_2(beva_inst, beva_writer);
} /* Line: 335 */
 else  /* Line: 330 */ {
bevt_6_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_map);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 336 */ {
this.bem_marshallWriteMap_2(beva_inst, beva_writer);
} /* Line: 337 */
 else  /* Line: 330 */ {
bevt_7_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_int);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 338 */ {
bevt_8_tmpvar_phold = beva_inst.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_8_tmpvar_phold);
} /* Line: 339 */
 else  /* Line: 330 */ {
bevt_9_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_boo);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 340 */ {
bevt_10_tmpvar_phold = beva_inst.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_10_tmpvar_phold);
} /* Line: 341 */
 else  /* Line: 342 */ {
bevt_11_tmpvar_phold = beva_inst.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
this.bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_11_tmpvar_phold, beva_writer);
} /* Line: 343 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_jsonEscapePoint_2(BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_txt) throws Throwable {
BEC_2_4_3_MathInt bevl_rcap = null;
BEC_2_4_3_MathInt bevl_txtsznow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_u = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_7_JsonEscapes bevl_esc = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_first = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpvar_phold = null;
bevl_rcap = (new BEC_2_4_3_MathInt());
bevl_txtsznow = beva_txt.bem_sizeGet_0();
bevl_size = beva_txtpt.bem_sizeGet_0();
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt());
bevl_u = beva_txtpt.bem_getInt_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevt_3_tmpvar_phold = bevo_0;
if (bevl_size.bevi_int == bevt_3_tmpvar_phold.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_1));
bevt_4_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_5_tmpvar_phold);
bevl_value = bevl_u.bem_and_1(bevt_4_tmpvar_phold);
} /* Line: 357 */
 else  /* Line: 355 */ {
bevt_7_tmpvar_phold = bevo_1;
if (bevl_size.bevi_int == bevt_7_tmpvar_phold.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 360 */ {
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_2));
bevt_8_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_9_tmpvar_phold);
bevl_value = bevl_u.bem_and_1(bevt_8_tmpvar_phold);
} /* Line: 361 */
 else  /* Line: 355 */ {
bevt_11_tmpvar_phold = bevo_2;
if (bevl_size.bevi_int == bevt_11_tmpvar_phold.bevi_int) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 364 */ {
bevt_13_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_3));
bevt_12_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_13_tmpvar_phold);
bevl_value = bevl_u.bem_and_1(bevt_12_tmpvar_phold);
} /* Line: 365 */
} /* Line: 355 */
} /* Line: 355 */
bevt_15_tmpvar_phold = bevo_3;
if (bevl_size.bevi_int > bevt_15_tmpvar_phold.bevi_int) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 368 */ {
if (bevl_i.bevi_int < bevl_size.bevi_int) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 369 */ {
beva_txtpt.bem_getInt_2(bevl_i, bevl_u);
bevt_18_tmpvar_phold = (new BEC_2_4_3_MathInt(6));
bevt_17_tmpvar_phold = bevl_value.bem_shiftLeft_1(bevt_18_tmpvar_phold);
bevt_21_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_4));
bevt_20_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_21_tmpvar_phold);
bevt_19_tmpvar_phold = bevl_u.bem_and_1(bevt_20_tmpvar_phold);
bevl_value = bevt_17_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevl_i.bevi_int++;
} /* Line: 368 */
 else  /* Line: 368 */ {
break;
} /* Line: 368 */
} /* Line: 368 */
} /* Line: 368 */
bevt_23_tmpvar_phold = bevo_4;
if (bevl_size.bevi_int == bevt_23_tmpvar_phold.bevi_int) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevl_rcap = (new BEC_2_4_3_MathInt(0));
} /* Line: 376 */
 else  /* Line: 375 */ {
bevt_25_tmpvar_phold = bevo_5;
if (bevl_size.bevi_int == bevt_25_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 377 */ {
bevl_rcap = (new BEC_2_4_3_MathInt(2));
} /* Line: 378 */
 else  /* Line: 379 */ {
bevt_28_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_5));
bevt_27_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_28_tmpvar_phold);
if (bevl_value.bevi_int < bevt_27_tmpvar_phold.bevi_int) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_rcap = (new BEC_2_4_3_MathInt(7));
} /* Line: 381 */
 else  /* Line: 382 */ {
bevl_rcap = (new BEC_2_4_3_MathInt(13));
} /* Line: 383 */
} /* Line: 380 */
} /* Line: 375 */
bevt_31_tmpvar_phold = beva_txt.bem_capacityGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_subtract_1(bevl_txtsznow);
if (bevt_30_tmpvar_phold.bevi_int < bevl_rcap.bevi_int) {
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevt_32_tmpvar_phold = bevl_txtsznow.bem_add_1(bevl_rcap);
beva_txt.bem_capacitySet_1(bevt_32_tmpvar_phold);
} /* Line: 388 */
bevt_34_tmpvar_phold = bevo_6;
if (bevl_rcap.bevi_int == bevt_34_tmpvar_phold.bevi_int) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevl_esc = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bevs_inst;
bevt_35_tmpvar_phold = bevl_esc.bem_toEscapesGet_0();
bevl_escval = (BEC_2_4_6_TextString) bevt_35_tmpvar_phold.bem_get_1(beva_txtpt);
if (bevl_escval == null) {
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 395 */ {
beva_txt.bem_addValue_1(bevl_escval);
} /* Line: 396 */
 else  /* Line: 397 */ {
beva_txt.bem_addValue_1(beva_txtpt);
} /* Line: 399 */
} /* Line: 395 */
 else  /* Line: 391 */ {
bevt_38_tmpvar_phold = bevo_7;
if (bevl_rcap.bevi_int > bevt_38_tmpvar_phold.bevi_int) {
bevt_37_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 401 */ {
bevt_40_tmpvar_phold = bevo_8;
if (bevl_rcap.bevi_int == bevt_40_tmpvar_phold.bevi_int) {
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 402 */ {
bevt_42_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_6));
bevt_41_tmpvar_phold = beva_txt.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_46_tmpvar_phold = bevo_9;
bevt_45_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_46_tmpvar_phold.bem_once_0();
bevt_44_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_45_tmpvar_phold);
bevt_48_tmpvar_phold = bevo_10;
bevt_47_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_48_tmpvar_phold.bem_once_0();
bevt_50_tmpvar_phold = bevo_11;
bevt_49_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_50_tmpvar_phold.bem_once_0();
bevt_52_tmpvar_phold = bevo_12;
bevt_51_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_52_tmpvar_phold.bem_once_0();
bevt_43_tmpvar_phold = bevl_value.bem_toString_4(bevt_44_tmpvar_phold, bevt_47_tmpvar_phold, bevt_49_tmpvar_phold, bevt_51_tmpvar_phold);
bevt_41_tmpvar_phold.bem_addValue_1(bevt_43_tmpvar_phold);
} /* Line: 403 */
 else  /* Line: 402 */ {
bevt_54_tmpvar_phold = bevo_13;
if (bevl_rcap.bevi_int == bevt_54_tmpvar_phold.bevi_int) {
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 404 */ {
bevt_56_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_7));
bevt_55_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_56_tmpvar_phold);
bevl_value.bem_subtractValue_1(bevt_55_tmpvar_phold);
bevt_58_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_8));
bevt_57_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_58_tmpvar_phold);
bevt_62_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_9));
bevt_61_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_tmpvar_phold);
bevt_60_tmpvar_phold = bevl_value.bem_and_1(bevt_61_tmpvar_phold);
bevt_63_tmpvar_phold = (new BEC_2_4_3_MathInt(10));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bem_shiftRight_1(bevt_63_tmpvar_phold);
bevl_first = bevt_57_tmpvar_phold.bem_or_1(bevt_59_tmpvar_phold);
bevt_65_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_10));
bevt_64_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_tmpvar_phold);
bevt_68_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_11));
bevt_67_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_tmpvar_phold);
bevt_66_tmpvar_phold = bevl_value.bem_and_1(bevt_67_tmpvar_phold);
bevl_last = bevt_64_tmpvar_phold.bem_or_1(bevt_66_tmpvar_phold);
bevt_70_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_12));
bevt_69_tmpvar_phold = beva_txt.bem_addValue_1(bevt_70_tmpvar_phold);
bevt_74_tmpvar_phold = bevo_14;
bevt_73_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_74_tmpvar_phold.bem_once_0();
bevt_72_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_73_tmpvar_phold);
bevt_76_tmpvar_phold = bevo_15;
bevt_75_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_76_tmpvar_phold.bem_once_0();
bevt_78_tmpvar_phold = bevo_16;
bevt_77_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_78_tmpvar_phold.bem_once_0();
bevt_80_tmpvar_phold = bevo_17;
bevt_79_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_80_tmpvar_phold.bem_once_0();
bevt_71_tmpvar_phold = bevl_first.bem_toString_4(bevt_72_tmpvar_phold, bevt_75_tmpvar_phold, bevt_77_tmpvar_phold, bevt_79_tmpvar_phold);
bevt_69_tmpvar_phold.bem_addValue_1(bevt_71_tmpvar_phold);
bevt_82_tmpvar_phold = (new BEC_2_4_6_TextString(2, bels_13));
bevt_81_tmpvar_phold = beva_txt.bem_addValue_1(bevt_82_tmpvar_phold);
bevt_86_tmpvar_phold = bevo_18;
bevt_85_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_86_tmpvar_phold.bem_once_0();
bevt_84_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_85_tmpvar_phold);
bevt_88_tmpvar_phold = bevo_19;
bevt_87_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_88_tmpvar_phold.bem_once_0();
bevt_90_tmpvar_phold = bevo_20;
bevt_89_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_90_tmpvar_phold.bem_once_0();
bevt_92_tmpvar_phold = bevo_21;
bevt_91_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_92_tmpvar_phold.bem_once_0();
bevt_83_tmpvar_phold = bevl_last.bem_toString_4(bevt_84_tmpvar_phold, bevt_87_tmpvar_phold, bevt_89_tmpvar_phold, bevt_91_tmpvar_phold);
bevt_81_tmpvar_phold.bem_addValue_1(bevt_83_tmpvar_phold);
} /* Line: 409 */
} /* Line: 402 */
} /* Line: 402 */
} /* Line: 391 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_1(BEC_2_6_6_SystemObject beva_toEscape) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpvar_phold = null;
bevp_escaped.bem_clear_0();
bevt_1_tmpvar_phold = bevp_mbi.bem_new_1((BEC_2_4_6_TextString) beva_toEscape);
bevt_0_tmpvar_phold = this.bem_jsonEscape_3(bevt_1_tmpvar_phold, bevp_txtpt, bevp_escaped);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_jsonEscape_3(BEC_2_4_17_TextMultiByteIterator beva_mbi, BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_escaped) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
while (true)
 /* Line: 420 */ {
bevt_0_tmpvar_phold = beva_mbi.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 420 */ {
beva_mbi.bem_next_1(beva_txtpt);
this.bem_jsonEscapePoint_2(beva_txtpt, beva_escaped);
} /* Line: 422 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
return beva_escaped;
} /*method end*/
public BEC_2_6_6_SystemObject bem_marshallWriteString_2(BEC_2_4_6_TextString beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_q);
bevt_0_tmpvar_phold = this.bem_jsonEscape_1(beva_inst);
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_0_tmpvar_phold);
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_q);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_marshallWriteList_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_instin = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_14));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_1_tmpvar_phold);
bevl_first = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = beva_inst.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 436 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 436 */ {
bevl_instin = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 437 */ {
bevl_first = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 438 */
 else  /* Line: 439 */ {
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_15));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_3_tmpvar_phold);
} /* Line: 440 */
this.bem_marshallWriteInst_2(bevl_instin, beva_writer);
} /* Line: 442 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
bevt_4_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_16));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_4_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_marshallWriteMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) throws Throwable {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_17));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_1_tmpvar_phold);
bevl_first = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = beva_inst.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 450 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 450 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 452 */ {
bevl_first = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 453 */
 else  /* Line: 454 */ {
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_18));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_3_tmpvar_phold);
} /* Line: 455 */
bevt_4_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_4_tmpvar_phold, beva_writer);
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_19));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevl_kv.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_marshallWriteInst_2(bevt_6_tmpvar_phold, beva_writer);
} /* Line: 459 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_20));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_7_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_llsGet_0() throws Throwable {
return bevp_lls;
} /*method end*/
public BEC_2_6_6_SystemObject bem_llsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lls = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_arrGet_0() throws Throwable {
return bevp_arr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_arrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_arr = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_booGet_0() throws Throwable {
return bevp_boo;
} /*method end*/
public BEC_2_6_6_SystemObject bem_booSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_qGet_0() throws Throwable {
return bevp_q;
} /*method end*/
public BEC_2_6_6_SystemObject bem_qSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_q = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiGet_0() throws Throwable {
return bevp_mbi;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mbiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_txtptGet_0() throws Throwable {
return bevp_txtpt;
} /*method end*/
public BEC_2_6_6_SystemObject bem_txtptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_escapedGet_0() throws Throwable {
return bevp_escaped;
} /*method end*/
public BEC_2_6_6_SystemObject bem_escapedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {294, 296, 297, 297, 299, 301, 303, 305, 305, 307, 308, 309, 314, 314, 315, 317, 318, 319, 319, 323, 323, 324, 326, 330, 330, 331, 331, 332, 333, 334, 0, 334, 0, 0, 335, 336, 337, 338, 339, 339, 340, 341, 341, 343, 343, 348, 349, 351, 354, 354, 354, 355, 355, 355, 357, 357, 357, 359, 359, 359, 361, 361, 361, 363, 363, 363, 365, 365, 365, 367, 367, 367, 368, 368, 368, 370, 372, 372, 372, 372, 372, 372, 368, 375, 375, 375, 376, 377, 377, 377, 378, 380, 380, 380, 380, 381, 383, 387, 387, 387, 387, 388, 388, 391, 391, 391, 393, 394, 394, 395, 395, 396, 399, 401, 401, 401, 402, 402, 402, 403, 403, 403, 403, 403, 403, 403, 403, 403, 403, 403, 403, 403, 404, 404, 404, 405, 405, 405, 406, 406, 406, 406, 406, 406, 406, 406, 407, 407, 407, 407, 407, 407, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 408, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 409, 415, 416, 416, 416, 420, 421, 422, 424, 428, 429, 429, 430, 434, 434, 435, 436, 0, 436, 436, 438, 440, 440, 442, 444, 444, 448, 448, 449, 450, 0, 450, 450, 453, 455, 455, 457, 457, 458, 458, 459, 459, 461, 461, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 82, 87, 88, 90, 91, 92, 93, 97, 102, 103, 105, 121, 126, 127, 128, 131, 133, 136, 138, 141, 143, 146, 150, 153, 155, 158, 160, 161, 164, 166, 167, 170, 171, 284, 285, 286, 287, 288, 289, 290, 291, 296, 297, 298, 299, 302, 303, 308, 309, 310, 311, 314, 315, 320, 321, 322, 323, 327, 328, 333, 334, 337, 342, 343, 344, 345, 346, 347, 348, 349, 350, 357, 358, 363, 364, 367, 368, 373, 374, 377, 378, 379, 384, 385, 388, 392, 393, 394, 399, 400, 401, 403, 404, 409, 410, 411, 412, 413, 418, 419, 422, 426, 427, 432, 433, 434, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 455, 456, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 514, 515, 516, 517, 523, 525, 526, 532, 536, 537, 538, 539, 550, 551, 552, 553, 553, 556, 558, 560, 563, 564, 566, 572, 573, 587, 588, 589, 590, 590, 593, 595, 597, 600, 601, 603, 604, 605, 606, 607, 608, 614, 615, 619, 622, 626, 629, 633, 636, 640, 643, 647, 650, 654, 657, 661, 664, 668, 671, 675, 678, 682, 685};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 294 64
new 0 294 64
assign 1 296 65
new 0 296 65
assign 1 297 66
new 0 297 66
assign 1 297 67
new 1 297 67
assign 1 299 68
new 0 299 68
assign 1 301 69
new 0 301 69
assign 1 303 70
new 0 303 70
assign 1 305 71
new 0 305 71
assign 1 305 72
quoteGet 0 305 72
assign 1 307 73
new 0 307 73
assign 1 308 74
new 0 308 74
assign 1 309 75
new 0 309 75
assign 1 314 82
undef 1 314 87
new 0 315 88
assign 1 317 90
new 0 317 90
marshallWriteInst 2 318 91
assign 1 319 92
toString 0 319 92
return 1 319 93
assign 1 323 97
undef 1 323 102
new 0 324 103
marshallWriteInst 2 326 105
assign 1 330 121
undef 1 330 126
assign 1 331 127
new 0 331 127
write 1 331 128
assign 1 332 131
sameType 1 332 131
marshallWriteString 2 333 133
assign 1 334 136
sameType 1 334 136
assign 1 0 138
assign 1 334 141
sameType 1 334 141
assign 1 0 143
assign 1 0 146
marshallWriteList 2 335 150
assign 1 336 153
sameType 1 336 153
marshallWriteMap 2 337 155
assign 1 338 158
sameType 1 338 158
assign 1 339 160
toString 0 339 160
write 1 339 161
assign 1 340 164
sameType 1 340 164
assign 1 341 166
toString 0 341 166
write 1 341 167
assign 1 343 170
toString 0 343 170
marshallWriteString 2 343 171
assign 1 348 284
new 0 348 284
assign 1 349 285
sizeGet 0 349 285
assign 1 351 286
sizeGet 0 351 286
assign 1 354 287
new 0 354 287
assign 1 354 288
new 0 354 288
assign 1 354 289
getInt 2 354 289
assign 1 355 290
new 0 355 290
assign 1 355 291
equals 1 355 296
assign 1 357 297
new 0 357 297
assign 1 357 298
hexNew 1 357 298
assign 1 357 299
and 1 357 299
assign 1 359 302
new 0 359 302
assign 1 359 303
equals 1 359 308
assign 1 361 309
new 0 361 309
assign 1 361 310
hexNew 1 361 310
assign 1 361 311
and 1 361 311
assign 1 363 314
new 0 363 314
assign 1 363 315
equals 1 363 320
assign 1 365 321
new 0 365 321
assign 1 365 322
hexNew 1 365 322
assign 1 365 323
and 1 365 323
assign 1 367 327
new 0 367 327
assign 1 367 328
greater 1 367 333
assign 1 368 334
new 0 368 334
assign 1 368 337
lesser 1 368 342
getInt 2 370 343
assign 1 372 344
new 0 372 344
assign 1 372 345
shiftLeft 1 372 345
assign 1 372 346
new 0 372 346
assign 1 372 347
hexNew 1 372 347
assign 1 372 348
and 1 372 348
assign 1 372 349
add 1 372 349
incrementValue 0 368 350
assign 1 375 357
new 0 375 357
assign 1 375 358
equals 1 375 363
assign 1 376 364
new 0 376 364
assign 1 377 367
new 0 377 367
assign 1 377 368
equals 1 377 373
assign 1 378 374
new 0 378 374
assign 1 380 377
new 0 380 377
assign 1 380 378
hexNew 1 380 378
assign 1 380 379
lesser 1 380 384
assign 1 381 385
new 0 381 385
assign 1 383 388
new 0 383 388
assign 1 387 392
capacityGet 0 387 392
assign 1 387 393
subtract 1 387 393
assign 1 387 394
lesser 1 387 399
assign 1 388 400
add 1 388 400
capacitySet 1 388 401
assign 1 391 403
new 0 391 403
assign 1 391 404
equals 1 391 409
assign 1 393 410
new 0 393 410
assign 1 394 411
toEscapesGet 0 394 411
assign 1 394 412
get 1 394 412
assign 1 395 413
def 1 395 418
addValue 1 396 419
addValue 1 399 422
assign 1 401 426
new 0 401 426
assign 1 401 427
greater 1 401 432
assign 1 402 433
new 0 402 433
assign 1 402 434
equals 1 402 439
assign 1 403 440
new 0 403 440
assign 1 403 441
addValue 1 403 441
assign 1 403 442
new 0 403 442
assign 1 403 443
once 0 403 443
assign 1 403 444
new 1 403 444
assign 1 403 445
new 0 403 445
assign 1 403 446
once 0 403 446
assign 1 403 447
new 0 403 447
assign 1 403 448
once 0 403 448
assign 1 403 449
new 0 403 449
assign 1 403 450
once 0 403 450
assign 1 403 451
toString 4 403 451
addValue 1 403 452
assign 1 404 455
new 0 404 455
assign 1 404 456
equals 1 404 461
assign 1 405 462
new 0 405 462
assign 1 405 463
hexNew 1 405 463
subtractValue 1 405 464
assign 1 406 465
new 0 406 465
assign 1 406 466
hexNew 1 406 466
assign 1 406 467
new 0 406 467
assign 1 406 468
hexNew 1 406 468
assign 1 406 469
and 1 406 469
assign 1 406 470
new 0 406 470
assign 1 406 471
shiftRight 1 406 471
assign 1 406 472
or 1 406 472
assign 1 407 473
new 0 407 473
assign 1 407 474
hexNew 1 407 474
assign 1 407 475
new 0 407 475
assign 1 407 476
hexNew 1 407 476
assign 1 407 477
and 1 407 477
assign 1 407 478
or 1 407 478
assign 1 408 479
new 0 408 479
assign 1 408 480
addValue 1 408 480
assign 1 408 481
new 0 408 481
assign 1 408 482
once 0 408 482
assign 1 408 483
new 1 408 483
assign 1 408 484
new 0 408 484
assign 1 408 485
once 0 408 485
assign 1 408 486
new 0 408 486
assign 1 408 487
once 0 408 487
assign 1 408 488
new 0 408 488
assign 1 408 489
once 0 408 489
assign 1 408 490
toString 4 408 490
addValue 1 408 491
assign 1 409 492
new 0 409 492
assign 1 409 493
addValue 1 409 493
assign 1 409 494
new 0 409 494
assign 1 409 495
once 0 409 495
assign 1 409 496
new 1 409 496
assign 1 409 497
new 0 409 497
assign 1 409 498
once 0 409 498
assign 1 409 499
new 0 409 499
assign 1 409 500
once 0 409 500
assign 1 409 501
new 0 409 501
assign 1 409 502
once 0 409 502
assign 1 409 503
toString 4 409 503
addValue 1 409 504
clear 0 415 514
assign 1 416 515
new 1 416 515
assign 1 416 516
jsonEscape 3 416 516
return 1 416 517
assign 1 420 523
hasNextGet 0 420 523
next 1 421 525
jsonEscapePoint 2 422 526
return 1 424 532
write 1 428 536
assign 1 429 537
jsonEscape 1 429 537
write 1 429 538
write 1 430 539
assign 1 434 550
new 0 434 550
write 1 434 551
assign 1 435 552
new 0 435 552
assign 1 436 553
iteratorGet 0 0 553
assign 1 436 556
hasNextGet 0 436 556
assign 1 436 558
nextGet 0 436 558
assign 1 438 560
new 0 438 560
assign 1 440 563
new 0 440 563
write 1 440 564
marshallWriteInst 2 442 566
assign 1 444 572
new 0 444 572
write 1 444 573
assign 1 448 587
new 0 448 587
write 1 448 588
assign 1 449 589
new 0 449 589
assign 1 450 590
iteratorGet 0 0 590
assign 1 450 593
hasNextGet 0 450 593
assign 1 450 595
nextGet 0 450 595
assign 1 453 597
new 0 453 597
assign 1 455 600
new 0 455 600
write 1 455 601
assign 1 457 603
keyGet 0 457 603
marshallWriteString 2 457 604
assign 1 458 605
new 0 458 605
write 1 458 606
assign 1 459 607
valueGet 0 459 607
marshallWriteInst 2 459 608
assign 1 461 614
new 0 461 614
write 1 461 615
return 1 0 619
assign 1 0 622
return 1 0 626
assign 1 0 629
return 1 0 633
assign 1 0 636
return 1 0 640
assign 1 0 643
return 1 0 647
assign 1 0 650
return 1 0 654
assign 1 0 657
return 1 0 661
assign 1 0 664
return 1 0 668
assign 1 0 671
return 1 0 675
assign 1 0 678
return 1 0 682
assign 1 0 685
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 991179882: return bem_qGet_0();
case 1081412016: return bem_many_0();
case 841474419: return bem_txtptGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 1841486012: return bem_escapedGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1317468250: return bem_arrGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 327849388: return bem_llsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1763354070: return bem_strGet_0();
case 843567219: return bem_mbiGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1971910885: return bem_booGet_0();
case 542323416: return bem_intGet_0();
case 1354714650: return bem_copy_0();
case 156467595: return bem_mapGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1306385997: return bem_arrSet_1(bevd_0);
case 316767135: return bem_llsSet_1(bevd_0);
case 1982993138: return bem_booSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 854649472: return bem_mbiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 303598400: return bem_marshall_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1830403759: return bem_escapedSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 623073531: return bem_jsonEscape_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 553405669: return bem_intSet_1(bevd_0);
case 167549848: return bem_mapSet_1(bevd_0);
case 852556672: return bem_txtptSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1774436323: return bem_strSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1596765547: return bem_marshallWriteString_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1811026786: return bem_marshallWriteMap_2(bevd_0, bevd_1);
case 976327302: return bem_jsonEscapePoint_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 409655350: return bem_marshallWriteInst_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 328385502: return bem_marshallWriteList_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1308979356: return bem_marshallWrite_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 623073533: return bem_jsonEscape_3((BEC_2_4_17_TextMultiByteIterator) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_10_JsonMarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_10_JsonMarshaller.bevs_inst = (BEC_2_4_10_JsonMarshaller)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_10_JsonMarshaller.bevs_inst;
}
}
