package be.BEL_4_Base;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeUrl extends BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(44));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(42));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(32));
private static byte[] bels_0 = {0x2B};
private static byte[] bels_1 = {0x25};
private static byte[] bels_2 = {0x2B};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_2, 1));
private static byte[] bels_3 = {0x25};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_3, 1));
private static byte[] bels_4 = {0x20};
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(3));
private static byte[] bels_5 = {0x2B};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_5, 1));
private static byte[] bels_6 = {0x25};
private static BEC_2_4_6_TextString bevo_19 = (new BEC_2_4_6_TextString(bels_6, 1));
public static BEC_2_6_3_EncodeUrl bevs_inst;
public BEC_2_6_3_EncodeUrl bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_3_EncodeUrl bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
bevt_6_tmpvar_phold = beva_str.bem_sizeGet_0();
bevt_7_tmpvar_phold = bevo_0;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_multiply_1(bevt_7_tmpvar_phold);
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_tmpvar_phold);
bevl_tb = (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevl_pt = (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_tmpvar_phold);
while (true)
 /* Line: 165 */ {
bevt_9_tmpvar_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 165 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_tmpvar_phold);
bevt_12_tmpvar_phold = bevo_1;
if (bevl_ac.bevi_int > bevt_12_tmpvar_phold.bevi_int) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_14_tmpvar_phold = bevo_2;
if (bevl_ac.bevi_int < bevt_14_tmpvar_phold.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_16_tmpvar_phold = bevo_3;
if (bevl_ac.bevi_int > bevt_16_tmpvar_phold.bevi_int) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_18_tmpvar_phold = bevo_4;
if (bevl_ac.bevi_int < bevt_18_tmpvar_phold.bevi_int) {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_20_tmpvar_phold = bevo_5;
if (bevl_ac.bevi_int > bevt_20_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_22_tmpvar_phold = bevo_6;
if (bevl_ac.bevi_int < bevt_22_tmpvar_phold.bevi_int) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_24_tmpvar_phold = bevo_7;
if (bevl_ac.bevi_int > bevt_24_tmpvar_phold.bevi_int) {
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_26_tmpvar_phold = bevo_8;
if (bevl_ac.bevi_int < bevt_26_tmpvar_phold.bevi_int) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
 else  /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_28_tmpvar_phold = bevo_9;
if (bevl_ac.bevi_int == bevt_28_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 168 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 168 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 168 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 168 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 169 */
 else  /* Line: 168 */ {
bevt_30_tmpvar_phold = bevo_10;
if (bevl_ac.bevi_int == bevt_30_tmpvar_phold.bevi_int) {
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 170 */ {
bevt_31_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_0));
bevl_r.bem_addValue_1(bevt_31_tmpvar_phold);
} /* Line: 171 */
 else  /* Line: 172 */ {
bevt_32_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_1));
bevl_r.bem_addValue_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_tmpvar_phold);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 175 */
} /* Line: 168 */
} /* Line: 168 */
 else  /* Line: 165 */ {
break;
} /* Line: 165 */
} /* Line: 165 */
bevt_34_tmpvar_phold = bevl_r.bem_toString_0();
return bevt_34_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_r = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevl_last = (new BEC_2_4_3_MathInt(0));
bevt_3_tmpvar_phold = bevo_11;
bevl_npl = beva_str.bem_find_2(bevt_3_tmpvar_phold, bevl_last);
bevt_4_tmpvar_phold = bevo_12;
bevl_npe = beva_str.bem_find_2(bevt_4_tmpvar_phold, bevl_last);
if (bevl_npe == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
if (bevl_npl == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 191 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 191 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 191 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 191 */ {
bevl_ispl = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 193 */
 else  /* Line: 194 */ {
bevl_ispl = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 196 */
bevl_len = beva_str.bem_sizeGet_0();
while (true)
 /* Line: 200 */ {
if (bevl_i == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 200 */ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevt_10_tmpvar_phold = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_tmpvar_phold);
bevl_last = bevl_i;
} /* Line: 203 */
if (bevl_ispl.bevi_bool) /* Line: 205 */ {
bevt_11_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_4));
bevl_r.bem_addValue_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevo_13;
bevl_last = bevl_i.bem_add_1(bevt_12_tmpvar_phold);
} /* Line: 207 */
 else  /* Line: 208 */ {
bevt_15_tmpvar_phold = bevo_14;
bevt_14_tmpvar_phold = bevl_i.bem_add_1(bevt_15_tmpvar_phold);
if (bevt_14_tmpvar_phold.bevi_int < bevl_len.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 209 */ {
bevt_19_tmpvar_phold = bevo_15;
bevt_18_tmpvar_phold = bevl_i.bem_add_1(bevt_19_tmpvar_phold);
bevt_21_tmpvar_phold = bevo_16;
bevt_20_tmpvar_phold = bevl_i.bem_add_1(bevt_21_tmpvar_phold);
bevt_17_tmpvar_phold = beva_str.bem_substring_2(bevt_18_tmpvar_phold, bevt_20_tmpvar_phold);
bevt_16_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_tmpvar_phold);
bevl_r.bem_addValue_1(bevt_16_tmpvar_phold);
bevt_22_tmpvar_phold = bevo_17;
bevl_last = bevl_i.bem_add_1(bevt_22_tmpvar_phold);
} /* Line: 211 */
} /* Line: 209 */
bevt_23_tmpvar_phold = bevo_18;
bevl_npl = beva_str.bem_find_2(bevt_23_tmpvar_phold, bevl_last);
bevt_24_tmpvar_phold = bevo_19;
bevl_npe = beva_str.bem_find_2(bevt_24_tmpvar_phold, bevl_last);
if (bevl_npe == null) {
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
if (bevl_npl == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 216 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 216 */
 else  /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 216 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 216 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 216 */ {
bevl_ispl = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 218 */
 else  /* Line: 219 */ {
bevl_ispl = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 221 */
} /* Line: 216 */
 else  /* Line: 200 */ {
break;
} /* Line: 200 */
} /* Line: 200 */
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_29_tmpvar_phold = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_tmpvar_phold);
} /* Line: 225 */
bevt_30_tmpvar_phold = bevl_r.bem_toString_0();
return bevt_30_tmpvar_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {162, 162, 162, 162, 163, 164, 164, 165, 166, 167, 167, 168, 168, 168, 168, 168, 168, 0, 0, 0, 0, 168, 168, 168, 168, 168, 168, 0, 0, 0, 0, 0, 0, 168, 168, 168, 168, 168, 168, 0, 0, 0, 0, 0, 0, 168, 168, 168, 168, 168, 168, 0, 0, 0, 0, 0, 0, 168, 168, 168, 0, 0, 169, 170, 170, 170, 171, 171, 173, 173, 174, 174, 175, 178, 178, 182, 182, 183, 189, 189, 190, 190, 191, 191, 0, 191, 191, 191, 191, 0, 0, 0, 0, 0, 192, 193, 195, 196, 199, 200, 200, 201, 201, 202, 202, 203, 206, 206, 207, 207, 209, 209, 209, 209, 210, 210, 210, 210, 210, 210, 210, 211, 211, 214, 214, 215, 215, 216, 216, 0, 216, 216, 216, 216, 0, 0, 0, 0, 0, 217, 218, 220, 221, 224, 224, 225, 225, 227, 227};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {84, 85, 86, 87, 88, 89, 90, 93, 95, 96, 97, 98, 99, 104, 105, 106, 111, 112, 115, 119, 122, 125, 126, 131, 132, 133, 138, 139, 142, 146, 149, 152, 156, 159, 160, 165, 166, 167, 172, 173, 176, 180, 183, 186, 190, 193, 194, 199, 200, 201, 206, 207, 210, 214, 217, 220, 224, 227, 228, 233, 234, 237, 241, 244, 245, 250, 251, 252, 255, 256, 257, 258, 259, 267, 268, 309, 310, 311, 312, 313, 314, 315, 316, 321, 322, 325, 330, 331, 336, 337, 340, 344, 347, 350, 354, 355, 358, 359, 361, 364, 369, 370, 375, 376, 377, 378, 381, 382, 383, 384, 387, 388, 389, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 406, 407, 408, 409, 410, 415, 416, 419, 424, 425, 430, 431, 434, 438, 441, 444, 448, 449, 452, 453, 460, 465, 466, 467, 469, 470};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 162 84
sizeGet 0 162 84
assign 1 162 85
new 0 162 85
assign 1 162 86
multiply 1 162 86
assign 1 162 87
new 1 162 87
assign 1 163 88
new 1 163 88
assign 1 164 89
new 0 164 89
assign 1 164 90
new 1 164 90
assign 1 165 93
hasNextGet 0 165 93
next 1 166 95
assign 1 167 96
new 0 167 96
assign 1 167 97
getCode 1 167 97
assign 1 168 98
new 0 168 98
assign 1 168 99
greater 1 168 104
assign 1 168 105
new 0 168 105
assign 1 168 106
lesser 1 168 111
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 0 122
assign 1 168 125
new 0 168 125
assign 1 168 126
greater 1 168 131
assign 1 168 132
new 0 168 132
assign 1 168 133
lesser 1 168 138
assign 1 0 139
assign 1 0 142
assign 1 0 146
assign 1 0 149
assign 1 0 152
assign 1 0 156
assign 1 168 159
new 0 168 159
assign 1 168 160
greater 1 168 165
assign 1 168 166
new 0 168 166
assign 1 168 167
lesser 1 168 172
assign 1 0 173
assign 1 0 176
assign 1 0 180
assign 1 0 183
assign 1 0 186
assign 1 0 190
assign 1 168 193
new 0 168 193
assign 1 168 194
greater 1 168 199
assign 1 168 200
new 0 168 200
assign 1 168 201
lesser 1 168 206
assign 1 0 207
assign 1 0 210
assign 1 0 214
assign 1 0 217
assign 1 0 220
assign 1 0 224
assign 1 168 227
new 0 168 227
assign 1 168 228
equals 1 168 233
assign 1 0 234
assign 1 0 237
addValue 1 169 241
assign 1 170 244
new 0 170 244
assign 1 170 245
equals 1 170 250
assign 1 171 251
new 0 171 251
addValue 1 171 252
assign 1 173 255
new 0 173 255
addValue 1 173 256
assign 1 174 257
new 0 174 257
assign 1 174 258
getHex 1 174 258
addValue 1 175 259
assign 1 178 267
toString 0 178 267
return 1 178 268
assign 1 182 309
sizeGet 0 182 309
assign 1 182 310
new 1 182 310
assign 1 183 311
new 0 183 311
assign 1 189 312
new 0 189 312
assign 1 189 313
find 2 189 313
assign 1 190 314
new 0 190 314
assign 1 190 315
find 2 190 315
assign 1 191 316
undef 1 191 321
assign 1 0 322
assign 1 191 325
def 1 191 330
assign 1 191 331
lesser 1 191 336
assign 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 0 347
assign 1 0 350
assign 1 192 354
new 0 192 354
assign 1 193 355
assign 1 195 358
new 0 195 358
assign 1 196 359
assign 1 199 361
sizeGet 0 199 361
assign 1 200 364
def 1 200 369
assign 1 201 370
greater 1 201 375
assign 1 202 376
substring 2 202 376
addValue 1 202 377
assign 1 203 378
assign 1 206 381
new 0 206 381
addValue 1 206 382
assign 1 207 383
new 0 207 383
assign 1 207 384
add 1 207 384
assign 1 209 387
new 0 209 387
assign 1 209 388
add 1 209 388
assign 1 209 389
lesser 1 209 394
assign 1 210 395
new 0 210 395
assign 1 210 396
add 1 210 396
assign 1 210 397
new 0 210 397
assign 1 210 398
add 1 210 398
assign 1 210 399
substring 2 210 399
assign 1 210 400
hexNew 1 210 400
addValue 1 210 401
assign 1 211 402
new 0 211 402
assign 1 211 403
add 1 211 403
assign 1 214 406
new 0 214 406
assign 1 214 407
find 2 214 407
assign 1 215 408
new 0 215 408
assign 1 215 409
find 2 215 409
assign 1 216 410
undef 1 216 415
assign 1 0 416
assign 1 216 419
def 1 216 424
assign 1 216 425
lesser 1 216 430
assign 1 0 431
assign 1 0 434
assign 1 0 438
assign 1 0 441
assign 1 0 444
assign 1 217 448
new 0 217 448
assign 1 218 449
assign 1 220 452
new 0 220 452
assign 1 221 453
assign 1 224 460
lesser 1 224 465
assign 1 225 466
substring 2 225 466
addValue 1 225 467
assign 1 227 469
toString 0 227 469
return 1 227 470
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1711217736: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 570808864: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_3_EncodeUrl();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_3_EncodeUrl.bevs_inst = (BEC_2_6_3_EncodeUrl)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_3_EncodeUrl.bevs_inst;
}
}
