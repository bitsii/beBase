package be.BEL_4_Base;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_6_8_SystemBasePath extends BEC_6_6_SystemObject {
public BEC_6_8_SystemBasePath() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x20};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(1));
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(1));
public static BEC_6_8_SystemBasePath bevs_inst;
public BEC_4_6_TextString bevp_separator;
public BEC_4_6_TextString bevp_path;
public BEC_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_new_1(BEC_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_4_6_TextString(1, bels_0));
this.bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromString_1(BEC_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_4_6_TextString bem_toString_1(BEC_4_6_TextString beva_newsep) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_toStringWithSeparator_1(BEC_4_6_TextString beva_newsep) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_4_6_TextString bevl_npath = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_npath = bevt_0_tmpvar_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
return (BEC_4_6_TextString) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_8_SystemBasePath bem_add_1(BEC_6_6_SystemObject beva_other) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_9_10_ContainerLinkedList bevl_spath = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_l = null;
BEC_4_6_TextString bevl_rstr = null;
BEC_6_8_SystemBasePath bevl_rpath = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_9_tmpvar_phold = null;
bevt_1_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_3_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_emptyGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 382 */ {
bevt_4_tmpvar_phold = this.bem_copy_0();
return (BEC_6_8_SystemBasePath) bevt_4_tmpvar_phold;
} /* Line: 383 */
bevt_5_tmpvar_phold = beva_other.bemd_0(1359432006, BEL_4_Base.bevn_isAbsoluteGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 385 */ {
bevt_6_tmpvar_phold = beva_other.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
return (BEC_6_8_SystemBasePath) bevt_6_tmpvar_phold;
} /* Line: 386 */
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpvar_phold = beva_other.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevl_spath = (BEC_9_10_ContainerLinkedList) bevt_7_tmpvar_phold.bemd_1(2001811380, BEL_4_Base.bevn_split_1, bevp_separator);
bevl_i = bevl_spath.bem_iteratorGet_0();
while (true)
 /* Line: 390 */ {
bevt_8_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 390 */ {
bevl_l = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 392 */
 else  /* Line: 390 */ {
break;
} /* Line: 390 */
} /* Line: 390 */
bevt_9_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_rstr = bevt_9_tmpvar_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = (BEC_6_8_SystemBasePath) this.bem_copy_0();
bevl_rpath = (BEC_6_8_SystemBasePath) bevl_rpath.bem_fromString_1(bevl_rstr);
return bevl_rpath;
} /*method end*/
public BEC_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_6_8_SystemBasePath bevl_rpath = null;
BEC_4_3_MathInt bevl_rpl = null;
BEC_4_3_MathInt bevl_c = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_rpath = (BEC_6_8_SystemBasePath) this.bem_copy_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpvar_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_iteratorGet_0();
while (true)
 /* Line: 408 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 408 */ {
bevt_2_tmpvar_phold = bevl_c.bem_lesser_1(bevl_rpl);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevt_3_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_rpath.bem_addStep_1(bevt_3_tmpvar_phold);
} /* Line: 410 */
 else  /* Line: 411 */ {
bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
} /* Line: 412 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 414 */
 else  /* Line: 408 */ {
break;
} /* Line: 408 */
} /* Line: 408 */
bevt_4_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 416 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 417 */
return bevl_rpath;
} /*method end*/
public BEC_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
if (bevp_path == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_4_tmpvar_phold = bevp_path.bem_toString_0();
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_lesser_1(bevt_5_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 423 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 423 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 423 */
bevt_9_tmpvar_phold = bevo_1;
bevt_8_tmpvar_phold = bevp_path.bem_getPoint_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_10_tmpvar_phold;
} /* Line: 425 */
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_11_tmpvar_phold;
} /*method end*/
public BEC_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_isAbsoluteGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 431 */ {
bevt_1_tmpvar_phold = bevo_2;
bevt_2_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
} /* Line: 432 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_isAbsoluteGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 437 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 438 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_trimParents_1(BEC_4_3_MathInt beva_howMany) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_4_3_MathInt bevl_i = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
bevt_0_tmpvar_phold = beva_howMany.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 443 */ {
this.bem_makeNonAbsolute_0();
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 448 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(beva_howMany);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 448 */ {
if (bevl_next == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 449 */ {
break;
} /* Line: 449 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 448 */
 else  /* Line: 448 */ {
break;
} /* Line: 448 */
} /* Line: 448 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 454 */
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_addStep_1(BEC_6_6_SystemObject beva_step) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_4_3_MathInt bevl_fp = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 466 */ {
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevp_path = bevt_1_tmpvar_phold.bem_emptyGet_0();
} /* Line: 467 */
 else  /* Line: 468 */ {
bevt_3_tmpvar_phold = bevo_4;
bevt_2_tmpvar_phold = bevl_fp.bem_add_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpvar_phold, bevt_4_tmpvar_phold);
} /* Line: 469 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addStepList_1(BEC_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_iteratorGet_0();
while (true)
 /* Line: 475 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 475 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_fpath.bem_addValue_1(bevt_1_tmpvar_phold);
} /* Line: 476 */
 else  /* Line: 475 */ {
break;
} /* Line: 475 */
} /* Line: 475 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addSteps_1(BEC_6_6_SystemObject beva_step) throws Throwable {
BEC_6_8_SystemBasePath bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_addStep_1(beva_step);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_addSteps_2(BEC_6_6_SystemObject beva_s1, BEC_6_6_SystemObject beva_s2) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = (BEC_9_10_ContainerLinkedList) bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_6_8_SystemBasePath bevl_other = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_other = (BEC_6_8_SystemBasePath) this.bem_create_0();
this.bem_copyTo_1(bevl_other);
bevt_0_tmpvar_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpvar_phold);
return bevl_other;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_split_1(bevp_separator);
return (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_notEquals_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_not_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_equals_1(BEC_6_6_SystemObject beva_x) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_x == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_3_tmpvar_phold = beva_x.bemd_1(1664117860, BEL_4_Base.bevn_otherType_1, this);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 515 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 515 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 515 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_5_tmpvar_phold = beva_x.bemd_0(400189342, BEL_4_Base.bevn_pathGet_0);
bevt_4_tmpvar_phold = bevp_path.bem_notEquals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 515 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 515 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 515 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_6_tmpvar_phold;
} /* Line: 516 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_subPath_1(BEC_4_3_MathInt beva_start) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_subPath_2(beva_start, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_subPath_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_st = null;
BEC_6_6_SystemObject bevl_ll = null;
BEC_6_6_SystemObject bevl_res = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_st = this.bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 527 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 528 */
 else  /* Line: 529 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 530 */
bevl_res = this.bem_create_0();
bevl_res.bemd_1(410741679, BEL_4_Base.bevn_separatorSet_1, bevp_separator);
bevt_1_tmpvar_phold = BEC_4_7_TextStrings.bevs_inst.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(389107089, BEL_4_Base.bevn_pathSet_1, bevt_1_tmpvar_phold);
return bevl_res;
} /*method end*/
public BEC_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_6_6_SystemObject bem_separatorSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_separator = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_6_6_SystemObject bem_pathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_path = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {343, 343, 347, 348, 352, 356, 360, 360, 364, 365, 365, 366, 370, 370, 374, 374, 374, 378, 378, 378, 382, 382, 382, 382, 383, 383, 385, 386, 386, 388, 389, 389, 390, 390, 391, 392, 394, 394, 395, 396, 398, 402, 403, 404, 404, 405, 406, 407, 408, 408, 409, 410, 410, 412, 414, 416, 417, 419, 423, 423, 0, 423, 423, 423, 423, 0, 0, 423, 423, 424, 424, 424, 425, 425, 427, 427, 431, 432, 432, 432, 437, 437, 438, 443, 443, 444, 445, 447, 448, 448, 449, 449, 450, 451, 452, 448, 454, 459, 460, 461, 465, 466, 466, 467, 467, 469, 469, 469, 469, 474, 475, 475, 476, 476, 478, 482, 482, 486, 487, 488, 489, 493, 494, 495, 495, 496, 500, 500, 504, 504, 508, 508, 508, 515, 515, 0, 515, 0, 0, 0, 515, 515, 0, 0, 516, 516, 518, 518, 522, 522, 526, 527, 527, 528, 530, 532, 533, 534, 534, 535, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 21, 25, 26, 30, 34, 38, 39, 45, 46, 47, 48, 52, 53, 58, 59, 60, 65, 66, 67, 86, 87, 88, 89, 91, 92, 94, 96, 97, 99, 100, 101, 102, 105, 107, 108, 114, 115, 116, 117, 118, 131, 132, 133, 134, 135, 136, 137, 138, 141, 143, 145, 146, 149, 151, 157, 159, 161, 176, 181, 182, 185, 186, 187, 188, 190, 193, 197, 198, 200, 201, 202, 204, 205, 207, 208, 214, 216, 217, 218, 225, 226, 228, 241, 242, 244, 245, 246, 247, 250, 252, 257, 260, 261, 262, 263, 269, 275, 276, 277, 287, 288, 293, 294, 295, 298, 299, 300, 301, 310, 311, 314, 316, 317, 323, 328, 329, 333, 334, 335, 336, 342, 343, 344, 345, 346, 350, 351, 355, 356, 361, 362, 363, 374, 379, 380, 383, 385, 388, 392, 395, 396, 398, 401, 405, 406, 408, 409, 413, 414, 422, 423, 428, 429, 432, 434, 435, 436, 437, 438, 441, 444, 448, 451};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 343 20
new 0 343 20
new 1 343 21
assign 1 347 25
new 0 347 25
fromString 1 348 26
assign 1 352 30
return 1 356 34
assign 1 360 38
toStringWithSeparator 1 360 38
return 1 360 39
assign 1 364 45
split 1 364 45
assign 1 365 46
new 0 365 46
assign 1 365 47
join 2 365 47
return 1 366 48
assign 1 370 52
split 1 370 52
return 1 370 53
assign 1 374 58
split 1 374 58
assign 1 374 59
firstGet 0 374 59
return 1 374 60
assign 1 378 65
split 1 378 65
assign 1 378 66
lastGet 0 378 66
return 1 378 67
assign 1 382 86
pathGet 0 382 86
assign 1 382 87
new 0 382 87
assign 1 382 88
emptyGet 0 382 88
assign 1 382 89
equals 1 382 89
assign 1 383 91
copy 0 383 91
return 1 383 92
assign 1 385 94
isAbsoluteGet 0 385 94
assign 1 386 96
copy 0 386 96
return 1 386 97
assign 1 388 99
split 1 388 99
assign 1 389 100
pathGet 0 389 100
assign 1 389 101
split 1 389 101
assign 1 390 102
iteratorGet 0 390 102
assign 1 390 105
hasNextGet 0 390 105
assign 1 391 107
nextGet 0 391 107
addValue 1 392 108
assign 1 394 114
new 0 394 114
assign 1 394 115
join 2 394 115
assign 1 395 116
copy 0 395 116
assign 1 396 117
fromString 1 396 117
return 1 398 118
assign 1 402 131
split 1 402 131
assign 1 403 132
copy 0 403 132
assign 1 404 133
new 0 404 133
pathSet 1 404 134
assign 1 405 135
lengthGet 0 405 135
assign 1 406 136
decrement 0 406 136
assign 1 407 137
new 0 407 137
assign 1 408 138
iteratorGet 0 408 138
assign 1 408 141
hasNextGet 0 408 141
assign 1 409 143
lesser 1 409 143
assign 1 410 145
nextGet 0 410 145
addStep 1 410 146
nextGet 0 412 149
assign 1 414 151
increment 0 414 151
assign 1 416 157
isAbsoluteGet 0 416 157
makeAbsolute 0 417 159
return 1 419 161
assign 1 423 176
undef 1 423 181
assign 1 0 182
assign 1 423 185
toString 0 423 185
assign 1 423 186
sizeGet 0 423 186
assign 1 423 187
new 0 423 187
assign 1 423 188
lesser 1 423 188
assign 1 0 190
assign 1 0 193
assign 1 423 197
new 0 423 197
return 1 423 198
assign 1 424 200
new 0 424 200
assign 1 424 201
getPoint 1 424 201
assign 1 424 202
equals 1 424 202
assign 1 425 204
new 0 425 204
return 1 425 205
assign 1 427 207
new 0 427 207
return 1 427 208
assign 1 431 214
isAbsoluteGet 0 431 214
assign 1 432 216
new 0 432 216
assign 1 432 217
sizeGet 0 432 217
assign 1 432 218
substring 2 432 218
assign 1 437 225
isAbsoluteGet 0 437 225
assign 1 437 226
not 0 437 226
assign 1 438 228
add 1 438 228
assign 1 443 241
new 0 443 241
assign 1 443 242
greater 1 443 242
makeNonAbsolute 0 444 244
assign 1 445 245
split 1 445 245
assign 1 447 246
firstNodeGet 0 447 246
assign 1 448 247
new 0 448 247
assign 1 448 250
lesser 1 448 250
assign 1 449 252
undef 1 449 257
assign 1 450 260
assign 1 451 261
nextGet 0 451 261
delete 0 452 262
assign 1 448 263
increment 0 448 263
assign 1 454 269
join 2 454 269
assign 1 459 275
split 1 459 275
addValue 1 460 276
assign 1 461 277
join 2 461 277
assign 1 465 287
find 1 465 287
assign 1 466 288
undef 1 466 293
assign 1 467 294
new 0 467 294
assign 1 467 295
emptyGet 0 467 295
assign 1 469 298
new 0 469 298
assign 1 469 299
add 1 469 299
assign 1 469 300
sizeGet 0 469 300
assign 1 469 301
substring 2 469 301
assign 1 474 310
split 1 474 310
assign 1 475 311
iteratorGet 0 475 311
assign 1 475 314
hasNextGet 0 475 314
assign 1 476 316
nextGet 0 476 316
addValue 1 476 317
assign 1 478 323
join 2 478 323
assign 1 482 328
addStep 1 482 328
return 1 482 329
assign 1 486 333
split 1 486 333
addValue 1 487 334
addValue 1 488 335
assign 1 489 336
join 2 489 336
assign 1 493 342
create 0 493 342
copyTo 1 494 343
assign 1 495 344
copy 0 495 344
pathSet 1 495 345
return 1 496 346
assign 1 500 350
split 1 500 350
return 1 500 351
assign 1 504 355
hashGet 0 504 355
return 1 504 356
assign 1 508 361
equals 1 508 361
assign 1 508 362
not 0 508 362
return 1 508 363
assign 1 515 374
undef 1 515 379
assign 1 0 380
assign 1 515 383
otherType 1 515 383
assign 1 0 385
assign 1 0 388
assign 1 0 392
assign 1 515 395
pathGet 0 515 395
assign 1 515 396
notEquals 1 515 396
assign 1 0 398
assign 1 0 401
assign 1 516 405
new 0 516 405
return 1 516 406
assign 1 518 408
new 0 518 408
return 1 518 409
assign 1 522 413
subPath 2 522 413
return 1 522 414
assign 1 526 422
stepsGet 0 526 422
assign 1 527 423
undef 1 527 428
assign 1 528 429
subList 1 528 429
assign 1 530 432
subList 2 530 432
assign 1 532 434
create 0 532 434
separatorSet 1 533 435
assign 1 534 436
join 2 534 436
pathSet 1 534 437
return 1 535 438
return 1 0 441
assign 1 0 444
return 1 0 448
assign 1 0 451
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1359432006: return bem_isAbsoluteGet_0();
case 1571526666: return bem_makeAbsolute_0();
case 399659426: return bem_separatorGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 471950299: return bem_lastStepGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 992607997: return bem_parentGet_0();
case 935459934: return bem_deleteFirstStep_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1719674549: return bem_firstStepGet_0();
case 723109216: return bem_stepsGet_0();
case 1354714650: return bem_copy_0();
case 400189342: return bem_pathGet_0();
case 1826237981: return bem_stepListGet_0();
case 1714716985: return bem_makeNonAbsolute_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 472959: return bem_addStep_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 630006451: return bem_fromString_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 488966921: return bem_subPath_1((BEC_4_3_MathInt) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1774940958: return bem_toString_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 92659731: return bem_add_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 389107089: return bem_pathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1787791811: return bem_addStepList_1((BEC_9_10_ContainerLinkedList) bevd_0);
case 410741679: return bem_separatorSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_4_6_TextString) bevd_0);
case 14682424: return bem_addSteps_1(bevd_0);
case 2006569863: return bem_trimParents_1((BEC_4_3_MathInt) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 450717861: return bem_toStringWithSeparator_1((BEC_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 488966920: return bem_subPath_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 14682425: return bem_addSteps_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_8_SystemBasePath.bevs_inst = (BEC_6_8_SystemBasePath)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_8_SystemBasePath.bevs_inst;
}
}
