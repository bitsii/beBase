package be.BEL_4_Base;
/* IO:File: source/base/Time.be */
public class BEC_4_5_TimeSleep extends BEC_6_6_SystemObject {
public BEC_4_5_TimeSleep() { }
private static byte[] becc_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x6C,0x65,0x65,0x70};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(1000));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(1000));
public static BEC_4_5_TimeSleep bevs_inst;
public BEC_4_5_TimeSleep bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_4_5_TimeSleep bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_sleep_1(BEC_4_8_TimeInterval beva_interval) throws Throwable {
BEC_4_3_MathInt bevl_secs = null;
BEC_4_3_MathInt bevl_millis = null;
BEC_4_3_MathInt bevl_sleepMillis = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_3_MathInt bevt_5_tmpvar_phold = null;
if (beva_interval == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 41 */ {
bevl_secs = beva_interval.bem_secsGet_0();
bevl_millis = beva_interval.bem_millisGet_0();
if (bevl_secs == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 44 */ {
if (bevl_millis == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 44 */
 else  /* Line: 44 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 44 */ {
bevt_5_tmpvar_phold = bevo_0;
bevt_4_tmpvar_phold = bevl_secs.bem_multiply_1(bevt_5_tmpvar_phold);
bevl_sleepMillis = bevt_4_tmpvar_phold.bem_add_1(bevl_millis);
this.bem_sleepMilliseconds_1(bevl_sleepMillis);
} /* Line: 46 */
} /* Line: 44 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_sleepSeconds_1(BEC_4_3_MathInt beva_secs) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_1;
bevt_1_tmpvar_phold = beva_secs.bem_multiply_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_sleepMilliseconds_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_sleepMilliseconds_1(BEC_4_3_MathInt beva_msecs) throws Throwable {

      Thread.sleep(beva_msecs.bevi_int);
      return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {41, 41, 42, 43, 44, 44, 44, 44, 0, 0, 0, 45, 45, 45, 46, 52, 52, 52, 52};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {26, 31, 32, 33, 34, 39, 40, 45, 46, 49, 53, 56, 57, 58, 59, 68, 69, 70, 71};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 41 26
def 1 41 31
assign 1 42 32
secsGet 0 42 32
assign 1 43 33
millisGet 0 43 33
assign 1 44 34
def 1 44 39
assign 1 44 40
def 1 44 45
assign 1 0 46
assign 1 0 49
assign 1 0 53
assign 1 45 56
new 0 45 56
assign 1 45 57
multiply 1 45 57
assign 1 45 58
add 1 45 58
sleepMilliseconds 1 46 59
assign 1 52 68
new 0 52 68
assign 1 52 69
multiply 1 52 69
assign 1 52 70
sleepMilliseconds 1 52 70
return 1 52 71
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 1502128718: return bem_default_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 68248922: return bem_sleepSeconds_1((BEC_4_3_MathInt) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2122915639: return bem_sleep_1((BEC_4_8_TimeInterval) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1189707771: return bem_sleepMilliseconds_1((BEC_4_3_MathInt) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_5_TimeSleep();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_5_TimeSleep.bevs_inst = (BEC_4_5_TimeSleep)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_5_TimeSleep.bevs_inst;
}
}
