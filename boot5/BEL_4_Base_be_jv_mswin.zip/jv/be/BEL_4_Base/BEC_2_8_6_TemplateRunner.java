package be.BEL_4_Base;
/* IO:File: source/extended/Template.be */
public class BEC_2_8_6_TemplateRunner extends BEC_2_6_6_SystemObject {
public BEC_2_8_6_TemplateRunner() { }
private static byte[] becc_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x75,0x6E,0x6E,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_8_6_TemplateRunner bevs_inst;
public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_6_6_SystemObject bevp_output;
public BEC_2_6_6_SystemObject bevp_stepIter;
public BEC_2_9_3_ContainerMap bevp_swap;
public BEC_2_9_3_ContainerMap bevp_handOff;
public BEC_2_8_6_TemplateRunner bevp_baton;
public BEC_2_7_7_ReplaceRunStep bevp_runStep;
public BEC_2_8_6_TemplateRunner bem_new_0() throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep());
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_swapGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_swap == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 185 */ {
bevp_swap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 185 */
return bevp_swap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_handOffGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_handOff == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 190 */ {
bevp_handOff = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 190 */
return bevp_handOff;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_2(BEC_2_4_6_TextString beva_template, BEC_2_6_6_SystemObject beva__output) throws Throwable {
this.bem_new_1(beva_template);
bevp_output = beva__output;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_new_1(BEC_2_4_6_TextString beva_template) throws Throwable {
this.bem_new_0();
this.bem_load_1(beva_template);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_load_1(BEC_2_4_6_TextString beva_template) throws Throwable {
bevp_replace = (new BEC_2_8_7_TemplateReplace()).bem_new_0();
bevp_replace.bem_load_2(beva_template, this);
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_restart_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_baton == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 212 */
bevp_stepIter = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpvar_phold = null;
if (bevp_stepIter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevt_1_tmpvar_phold = bevp_replace.bem_stepsGet_0();
bevp_stepIter = bevt_1_tmpvar_phold.bem_iteratorGet_0();
} /* Line: 219 */
return bevp_stepIter;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentRunnerGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_8_6_TemplateRunner bevt_1_tmpvar_phold = null;
if (bevp_baton == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevt_1_tmpvar_phold = bevp_baton.bem_currentRunnerGet_0();
return bevt_1_tmpvar_phold;
} /* Line: 226 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_8_6_TemplateRunner bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = this.bem_currentRunnerGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_stepIterGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1582066476, BEL_4_Base.bevn_currentNodeGet_0);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
bevl_iter = this.bem_stepIterGet_0();
bevl_iter.bemd_1(1593148729, BEL_4_Base.bevn_currentNodeSet_1, beva_node);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
if (bevp_baton == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_4_tmpvar_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /* Line: 244 */
 else  /* Line: 245 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 248 */
} /* Line: 243 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 252 */ {
bevt_6_tmpvar_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 252 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_8_tmpvar_phold = bevl_s.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 254 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 254 */
 else  /* Line: 254 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 254 */ {
bevt_10_tmpvar_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_9_tmpvar_phold = bevp_handOff.bem_has_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 254 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 254 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 254 */
 else  /* Line: 254 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 254 */ {
bevt_11_tmpvar_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpvar_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpvar_phold = bevp_baton.bem_runToLabel_1(beva_label);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 258 */ {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_13_tmpvar_phold;
} /* Line: 259 */
 else  /* Line: 260 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 263 */
} /* Line: 258 */
 else  /* Line: 254 */ {
bevt_14_tmpvar_phold = bevl_s.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 265 */ {
bevt_16_tmpvar_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_label);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 265 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 265 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 265 */
 else  /* Line: 265 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 265 */ {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_17_tmpvar_phold;
} /* Line: 266 */
 else  /* Line: 267 */ {
bevt_18_tmpvar_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, this);
bevp_output.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_18_tmpvar_phold);
} /* Line: 268 */
} /* Line: 254 */
} /* Line: 254 */
 else  /* Line: 252 */ {
break;
} /* Line: 252 */
} /* Line: 252 */
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_19_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipToLabel_1(BEC_2_4_6_TextString beva_label) throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
if (bevp_baton == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 275 */ {
bevt_4_tmpvar_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 276 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_5_tmpvar_phold;
} /* Line: 277 */
 else  /* Line: 278 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 281 */
} /* Line: 276 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 285 */ {
bevt_6_tmpvar_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 287 */ {
bevt_8_tmpvar_phold = bevl_s.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 287 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 287 */ {
bevt_10_tmpvar_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_9_tmpvar_phold = bevp_handOff.bem_has_1(bevt_10_tmpvar_phold);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 287 */
 else  /* Line: 287 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 287 */ {
bevt_11_tmpvar_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_11_tmpvar_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevt_12_tmpvar_phold = bevp_baton.bem_skipToLabel_1(beva_label);
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 291 */ {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_13_tmpvar_phold;
} /* Line: 292 */
 else  /* Line: 293 */ {
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 296 */
} /* Line: 291 */
 else  /* Line: 287 */ {
bevt_14_tmpvar_phold = bevl_s.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 298 */ {
bevt_16_tmpvar_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, beva_label);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 298 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 298 */
 else  /* Line: 298 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 298 */ {
bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_17_tmpvar_phold;
} /* Line: 299 */
} /* Line: 287 */
} /* Line: 287 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_18_tmpvar_phold;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_run_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
if (bevp_baton == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 306 */ {
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 309 */
bevl_iter = this.bem_stepIterGet_0();
while (true)
 /* Line: 312 */ {
bevt_3_tmpvar_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 312 */ {
bevl_s = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevp_handOff == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_5_tmpvar_phold = bevl_s.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_runStep);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 314 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
 else  /* Line: 314 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 314 */ {
bevt_7_tmpvar_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevt_6_tmpvar_phold = bevp_handOff.bem_has_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 314 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 314 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 314 */
 else  /* Line: 314 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 314 */ {
bevt_8_tmpvar_phold = bevl_s.bemd_0(1763354070, BEL_4_Base.bevn_strGet_0);
bevp_baton = (BEC_2_8_6_TemplateRunner) bevp_handOff.bem_get_1(bevt_8_tmpvar_phold);
bevp_baton.bem_outputSet_1(bevp_output);
bevp_baton.bem_swapSet_1(bevp_swap);
bevp_baton.bem_run_0();
bevp_baton.bem_restart_0();
bevp_baton = null;
} /* Line: 320 */
 else  /* Line: 321 */ {
bevt_9_tmpvar_phold = bevl_s.bemd_1(2068442, BEL_4_Base.bevn_handle_1, this);
bevp_output.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_9_tmpvar_phold);
} /* Line: 322 */
} /* Line: 314 */
 else  /* Line: 312 */ {
break;
} /* Line: 312 */
} /* Line: 312 */
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGet_0() throws Throwable {
return bevp_replace;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputGet_0() throws Throwable {
return bevp_output;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_output = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_stepIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_stepIter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_swap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_handOffSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_handOff = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_batonGet_0() throws Throwable {
return bevp_baton;
} /*method end*/
public BEC_2_6_6_SystemObject bem_batonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_baton = (BEC_2_8_6_TemplateRunner) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_runStepGet_0() throws Throwable {
return bevp_runStep;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runStepSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runStep = (BEC_2_7_7_ReplaceRunStep) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {180, 185, 186, 190, 191, 195, 196, 200, 201, 205, 206, 210, 211, 212, 214, 218, 219, 221, 225, 226, 228, 232, 237, 238, 242, 243, 244, 247, 248, 251, 252, 253, 254, 0, 254, 0, 255, 256, 257, 258, 259, 262, 263, 265, 0, 266, 268, 271, 275, 276, 277, 280, 281, 284, 285, 286, 287, 0, 287, 0, 288, 289, 290, 291, 292, 295, 296, 298, 0, 299, 302, 306, 307, 308, 309, 311, 312, 313, 314, 0, 314, 0, 315, 316, 317, 318, 319, 320, 322, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 180 16
new 0 180 16
assign 1 185 16
undef 1 185 16
assign 1 185 16
new 0 185 16
return 1 186 16
assign 1 190 16
undef 1 190 16
assign 1 190 16
new 0 190 16
return 1 191 16
new 1 195 16
assign 1 196 16
new 0 200 16
load 1 201 16
assign 1 205 16
new 0 205 16
load 2 206 16
assign 1 210 16
def 1 210 16
restart 0 211 16
assign 1 212 16
assign 1 214 16
assign 1 218 16
undef 1 218 16
assign 1 219 16
stepsGet 0 219 16
assign 1 219 16
iteratorGet 0 219 16
return 1 221 16
assign 1 225 16
def 1 225 16
assign 1 226 16
currentRunnerGet 0 226 16
return 1 226 16
return 1 228 16
assign 1 232 16
currentRunnerGet 0 232 16
assign 1 232 16
stepIterGet 0 232 16
assign 1 232 16
currentNodeGet 0 232 16
return 1 232 16
assign 1 237 16
stepIterGet 0 237 16
currentNodeSet 1 238 16
assign 1 242 16
def 1 242 16
assign 1 243 16
runToLabel 1 243 16
assign 1 244 16
new 0 244 16
return 1 244 16
restart 0 247 16
assign 1 248 16
assign 1 251 16
stepIterGet 0 251 16
assign 1 252 16
hasNextGet 0 252 16
assign 1 253 16
nextGet 0 253 16
assign 1 254 16
def 1 254 16
assign 1 254 16
sameType 1 254 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 254 16
strGet 0 254 16
assign 1 254 16
has 1 254 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 255 16
strGet 0 255 16
assign 1 255 16
get 1 255 16
outputSet 1 256 16
swapSet 1 257 16
assign 1 258 16
runToLabel 1 258 16
assign 1 259 16
new 0 259 16
return 1 259 16
restart 0 262 16
assign 1 263 16
assign 1 265 16
sameType 1 265 16
assign 1 265 16
strGet 0 265 16
assign 1 265 16
equals 1 265 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 266 16
new 0 266 16
return 1 266 16
assign 1 268 16
handle 1 268 16
write 1 268 16
assign 1 271 16
new 0 271 16
return 1 271 16
assign 1 275 16
def 1 275 16
assign 1 276 16
skipToLabel 1 276 16
assign 1 277 16
new 0 277 16
return 1 277 16
restart 0 280 16
assign 1 281 16
assign 1 284 16
stepIterGet 0 284 16
assign 1 285 16
hasNextGet 0 285 16
assign 1 286 16
nextGet 0 286 16
assign 1 287 16
def 1 287 16
assign 1 287 16
sameType 1 287 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 287 16
strGet 0 287 16
assign 1 287 16
has 1 287 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 288 16
strGet 0 288 16
assign 1 288 16
get 1 288 16
outputSet 1 289 16
swapSet 1 290 16
assign 1 291 16
skipToLabel 1 291 16
assign 1 292 16
new 0 292 16
return 1 292 16
restart 0 295 16
assign 1 296 16
assign 1 298 16
sameType 1 298 16
assign 1 298 16
strGet 0 298 16
assign 1 298 16
equals 1 298 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 299 16
new 0 299 16
return 1 299 16
assign 1 302 16
new 0 302 16
return 1 302 16
assign 1 306 16
def 1 306 16
run 0 307 16
restart 0 308 16
assign 1 309 16
assign 1 311 16
stepIterGet 0 311 16
assign 1 312 16
hasNextGet 0 312 16
assign 1 313 16
nextGet 0 313 16
assign 1 314 16
def 1 314 16
assign 1 314 16
sameType 1 314 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 314 16
strGet 0 314 16
assign 1 314 16
has 1 314 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 315 16
strGet 0 315 16
assign 1 315 16
get 1 315 16
outputSet 1 316 16
swapSet 1 317 16
run 0 318 16
restart 0 319 16
assign 1 320 16
assign 1 322 16
handle 1 322 16
write 1 322 16
return 1 0 16
assign 1 0 16
return 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
assign 1 0 16
return 1 0 16
assign 1 0 16
return 1 0 16
assign 1 0 16
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1052303331: return bem_stepIterGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1294131276: return bem_swapGet_0();
case 1582066476: return bem_currentNodeGet_0();
case 104713553: return bem_new_0();
case 1941218611: return bem_batonGet_0();
case 287040793: return bem_hashGet_0();
case 108875644: return bem_run_0();
case 1774940957: return bem_toString_0();
case 1858379264: return bem_restart_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 438504243: return bem_replaceGet_0();
case 847016698: return bem_outputGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1032568578: return bem_currentRunnerGet_0();
case 1098633959: return bem_handOffGet_0();
case 1820417453: return bem_create_0();
case 930387920: return bem_runStepGet_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1952300864: return bem_batonSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 941470173: return bem_runStepSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1109716212: return bem_handOffSet_1(bevd_0);
case 449586496: return bem_replaceSet_1(bevd_0);
case 1097519336: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1283049023: return bem_swapSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1593148729: return bem_currentNodeSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 835934445: return bem_outputSet_1(bevd_0);
case 1586884588: return bem_skipToLabel_1((BEC_2_4_6_TextString) bevd_0);
case 1063385584: return bem_stepIterSet_1(bevd_0);
case 2118449056: return bem_runToLabel_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_8_6_TemplateRunner();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_8_6_TemplateRunner.bevs_inst = (BEC_2_8_6_TemplateRunner)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_8_6_TemplateRunner.bevs_inst;
}
}
