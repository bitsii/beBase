package be.BEL_4_Base;
/* IO:File: source/base/Int.be */
public class BEC_2_4_3_MathInt extends BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(24));
private static byte[] bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_0, 39));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_17 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bevo_18 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bevo_20 = (new BEC_2_4_3_MathInt(45));
private static byte[] bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_1, 21));
private static byte[] bels_2 = {0x20};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bels_2, 1));
private static BEC_2_4_3_MathInt bevo_23 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_24 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_25 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_26 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bevo_27 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bevo_28 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bevo_29 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_30 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bevo_31 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_32 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_33 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bevo_34 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bevo_35 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_36 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bevo_37 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_3_MathInt bevs_inst;
public BEC_2_6_6_SystemObject bevp_vint;
public BEC_2_6_6_SystemObject bem_vintGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vintSet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_create_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_new_0();
return (BEC_2_4_3_MathInt) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
this.bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
this.bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevt_5_tmpvar_phold = bevo_2;
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_5_tmpvar_phold.bem_once_0();
bevt_7_tmpvar_phold = bevo_3;
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_7_tmpvar_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpvar_phold, bevt_2_tmpvar_phold, bevt_4_tmpvar_phold, bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_5;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevt_5_tmpvar_phold = bevo_6;
bevt_4_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_5_tmpvar_phold.bem_once_0();
bevt_7_tmpvar_phold = bevo_7;
bevt_6_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_7_tmpvar_phold.bem_once_0();
this.bem_setStringValue_5(beva_str, bevt_0_tmpvar_phold, bevt_2_tmpvar_phold, bevt_4_tmpvar_phold, bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
bevt_1_tmpvar_phold = beva_radix.bem_lesser_1(bevt_2_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 88 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_4_tmpvar_phold = bevo_9;
bevt_3_tmpvar_phold = beva_radix.bem_greater_1(bevt_4_tmpvar_phold);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 88 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 88 */ {
bevt_7_tmpvar_phold = bevo_10;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(beva_radix);
bevt_5_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 89 */
bevt_9_tmpvar_phold = bevo_11;
bevt_8_tmpvar_phold = beva_radix.bem_lesser_1(bevt_9_tmpvar_phold);
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 91 */ {
bevl_max0 = beva_radix.bem_copy_0();
} /* Line: 92 */
 else  /* Line: 93 */ {
bevl_max0 = (new BEC_2_4_3_MathInt(10));
} /* Line: 94 */
bevt_10_tmpvar_phold = (new BEC_2_4_3_MathInt(48));
bevl_max0.bem_addValue_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = bevo_12;
bevt_13_tmpvar_phold = bevo_13;
bevt_12_tmpvar_phold = beva_radix.bem_subtract_1(bevt_13_tmpvar_phold);
bevl_maxA = bevt_11_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
bevt_14_tmpvar_phold = bevo_14;
bevt_16_tmpvar_phold = bevo_15;
bevt_15_tmpvar_phold = beva_radix.bem_subtract_1(bevt_16_tmpvar_phold);
bevl_maxa = bevt_14_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
this.bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) throws Throwable {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
bevt_3_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
this.bem_setValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_str.bem_sizeGet_0();
bevl_j = bevt_4_tmpvar_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (new BEC_2_4_3_MathInt(1));
bevl_ic = (new BEC_2_4_3_MathInt()).bem_new_0();
while (true)
 /* Line: 108 */ {
bevt_6_tmpvar_phold = bevo_16;
bevt_5_tmpvar_phold = bevl_j.bem_greaterEquals_1(bevt_6_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 108 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpvar_phold = bevo_17;
bevt_7_tmpvar_phold = bevl_ic.bem_greater_1(bevt_8_tmpvar_phold);
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_9_tmpvar_phold = bevl_ic.bem_lesser_1(beva_max0);
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 112 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 112 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 112 */
 else  /* Line: 112 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 112 */ {
bevt_10_tmpvar_phold = (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpvar_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bem_addValue_1(bevl_ic);
} /* Line: 115 */
 else  /* Line: 112 */ {
bevt_12_tmpvar_phold = bevo_18;
bevt_11_tmpvar_phold = bevl_ic.bem_greater_1(bevt_12_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_13_tmpvar_phold = bevl_ic.bem_lesser_1(beva_maxA);
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 116 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 116 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 116 */
 else  /* Line: 116 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 116 */ {
bevt_14_tmpvar_phold = (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpvar_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bem_addValue_1(bevl_ic);
} /* Line: 119 */
 else  /* Line: 112 */ {
bevt_16_tmpvar_phold = bevo_19;
bevt_15_tmpvar_phold = bevl_ic.bem_greater_1(bevt_16_tmpvar_phold);
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_17_tmpvar_phold = bevl_ic.bem_lesser_1(beva_maxa);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 120 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 120 */ {
bevt_18_tmpvar_phold = (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpvar_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
this.bem_addValue_1(bevl_ic);
} /* Line: 123 */
 else  /* Line: 112 */ {
bevt_20_tmpvar_phold = bevo_20;
bevt_19_tmpvar_phold = bevl_ic.bem_equals_1(bevt_20_tmpvar_phold);
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_21_tmpvar_phold = (new BEC_2_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_21_tmpvar_phold);
} /* Line: 126 */
 else  /* Line: 127 */ {
bevt_26_tmpvar_phold = bevo_21;
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(beva_str);
bevt_27_tmpvar_phold = bevo_22;
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevl_ic);
bevt_22_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_23_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_22_tmpvar_phold);
} /* Line: 128 */
} /* Line: 112 */
} /* Line: 112 */
} /* Line: 112 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 131 */
 else  /* Line: 108 */ {
break;
} /* Line: 108 */
} /* Line: 108 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
this.bem_new_1(beva_snw);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() throws Throwable {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_4_tmpvar_phold = bevo_23;
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_4_tmpvar_phold.bem_once_0();
bevt_6_tmpvar_phold = bevo_24;
bevt_5_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_6_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_toString_4(bevt_1_tmpvar_phold, bevt_3_tmpvar_phold, bevt_5_tmpvar_phold, null);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_toHexString_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_25;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_2_tmpvar_phold.bem_once_0();
bevt_4_tmpvar_phold = bevo_26;
bevt_3_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_4_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_toString_3(beva_res, bevt_1_tmpvar_phold, bevt_3_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpvar_phold = bevo_27;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_toString_4(bevt_1_tmpvar_phold, beva_zeroPad, beva_radix, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_28;
bevt_1_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_2_tmpvar_phold.bem_once_0();
bevt_0_tmpvar_phold = this.bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) throws Throwable {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
beva_res.bem_clear_0();
bevl_ts = this.bem_abs_0();
bevl_val = (new BEC_2_4_3_MathInt()).bem_new_0();
while (true)
 /* Line: 204 */ {
bevt_1_tmpvar_phold = bevo_29;
bevt_0_tmpvar_phold = bevl_ts.bem_greater_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevl_val.bem_setValue_1(bevl_ts);
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpvar_phold = bevo_30;
bevt_2_tmpvar_phold = bevl_val.bem_lesser_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevt_4_tmpvar_phold = (new BEC_2_4_3_MathInt(48));
bevl_val.bem_addValue_1(bevt_4_tmpvar_phold);
} /* Line: 208 */
 else  /* Line: 209 */ {
bevl_val.bem_addValue_1(beva_alphaStart);
} /* Line: 210 */
bevt_6_tmpvar_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_lesserEquals_1(bevt_7_tmpvar_phold);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 213 */ {
bevt_9_tmpvar_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpvar_phold = bevo_31;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpvar_phold);
} /* Line: 214 */
bevt_11_tmpvar_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpvar_phold, bevl_val);
bevt_13_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpvar_phold = bevo_32;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpvar_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 221 */
 else  /* Line: 204 */ {
break;
} /* Line: 204 */
} /* Line: 204 */
while (true)
 /* Line: 224 */ {
bevt_19_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_lesser_1(beva_zeroPad);
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_21_tmpvar_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bem_lesserEquals_1(bevt_22_tmpvar_phold);
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevt_24_tmpvar_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpvar_phold = bevo_33;
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpvar_phold);
} /* Line: 226 */
bevt_26_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpvar_phold = bevo_34;
bevt_27_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_28_tmpvar_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpvar_phold = bevo_35;
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_add_1(bevt_31_tmpvar_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpvar_phold);
} /* Line: 230 */
 else  /* Line: 224 */ {
break;
} /* Line: 224 */
} /* Line: 224 */
bevt_36_tmpvar_phold = bevo_36;
bevt_35_tmpvar_phold = this.bem_lesser_1(bevt_36_tmpvar_phold);
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_37_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_3));
beva_res.bem_addValue_1(bevt_37_tmpvar_phold);
} /* Line: 235 */
bevt_38_tmpvar_phold = beva_res.bem_reverseBytes_0();
return bevt_38_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_copy_0() throws Throwable {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (new BEC_2_4_3_MathInt()).bem_new_0();
bevl_c.bem_setValue_1(this);
return (BEC_2_4_3_MathInt) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_copy_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bem_absValue_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_37;
bevt_0_tmpvar_phold = this.bem_lesser_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 251 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(-1));
this.bem_multiplyValue_1(bevt_2_tmpvar_phold);
} /* Line: 252 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 272 */ {
bevl_res = (new BEC_2_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /* Line: 279 */
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 287 */ {
bevl_res = (new BEC_2_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /* Line: 294 */
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() throws Throwable {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() throws Throwable {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 330 */ {
bevl_res = (new BEC_2_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /* Line: 337 */
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 359 */ {
bevl_res = (new BEC_2_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /* Line: 366 */
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 388 */ {
bevl_res = (new BEC_2_4_3_MathInt()).bem_new_0();

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /* Line: 395 */
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 417 */ {
bevl_res = (new BEC_2_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /* Line: 429 */
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
 /* Line: 456 */ {
bevl_res = (new BEC_2_4_3_MathInt()).bem_new_0();

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /* Line: 463 */
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt()).bem_new_0();

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt()).bem_new_0();

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt()).bem_new_0();

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (new BEC_2_4_3_MathInt()).bem_new_0();

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) throws Throwable {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_result = (new BEC_2_4_3_MathInt(1));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 604 */ {
bevt_0_tmpvar_phold = bevl_i.bem_lesser_1(beva_other);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 604 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bem_incrementValue_0();
} /* Line: 604 */
 else  /* Line: 604 */ {
break;
} /* Line: 604 */
} /* Line: 604 */
return bevl_result;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (beva_xi instanceof BEC_2_4_3_MathInt && this.bevi_int == ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (!(beva_xi instanceof BEC_2_4_3_MathInt) || this.bevi_int != ((BEC_2_4_3_MathInt)beva_xi).bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vintSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_vint = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {69, 72, 76, 80, 84, 88, 0, 88, 0, 89, 91, 92, 94, 96, 97, 98, 99, 103, 104, 105, 106, 107, 108, 110, 112, 0, 113, 114, 115, 116, 0, 117, 118, 119, 120, 0, 121, 122, 123, 124, 126, 128, 130, 131, 136, 140, 144, 148, 159, 177, 181, 185, 189, 193, 197, 201, 202, 203, 204, 205, 206, 207, 208, 210, 213, 214, 216, 217, 221, 224, 225, 226, 228, 229, 234, 235, 237, 241, 242, 243, 247, 251, 252, 268, 273, 279, 288, 294, 312, 326, 331, 337, 355, 360, 366, 384, 389, 395, 413, 418, 429, 452, 457, 463, 481, 485, 496, 510, 514, 525, 539, 543, 554, 568, 572, 583, 597, 602, 604, 605, 604, 607, 639, 668, 689, 710, 731, 752, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 59, 58, 58, 58, 58, 59, 59, 58, 58, 59, 58, 58, 59, 58, 58, 59, 58, 58, 59, 58, 58, 59, 57, 57, 59, 57, 57, 59, 57, 57, 59, 57, 57, 59, 57, 57, 57, 57, 57, 61, 61, 61, 61, 61, 61, 57};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 69 57
new 0 69 57
return 1 69 57
setStringValueDec 1 72 57
setStringValueHex 1 76 57
assign 1 80 57
new 0 80 57
assign 1 80 57
once 0 80 57
assign 1 80 57
new 0 80 57
assign 1 80 57
once 0 80 57
assign 1 80 57
new 0 80 57
assign 1 80 57
once 0 80 57
assign 1 80 57
new 0 80 57
assign 1 80 57
once 0 80 57
setStringValue 5 80 57
assign 1 84 57
new 0 84 57
assign 1 84 57
once 0 84 57
assign 1 84 57
new 0 84 57
assign 1 84 57
once 0 84 57
assign 1 84 57
new 0 84 57
assign 1 84 57
once 0 84 57
assign 1 84 57
new 0 84 57
assign 1 84 57
once 0 84 57
setStringValue 5 84 57
assign 1 88 57
new 0 88 57
assign 1 88 57
lesser 1 88 57
assign 1 0 57
assign 1 88 57
new 0 88 57
assign 1 88 57
greater 1 88 57
assign 1 0 57
assign 1 0 57
assign 1 89 57
new 0 89 57
assign 1 89 57
add 1 89 57
assign 1 89 57
new 1 89 57
throw 1 89 57
assign 1 91 57
new 0 91 57
assign 1 91 57
lesser 1 91 57
assign 1 92 57
copy 0 92 57
assign 1 94 57
new 0 94 57
assign 1 96 57
new 0 96 57
addValue 1 96 57
assign 1 97 57
new 0 97 57
assign 1 97 57
new 0 97 57
assign 1 97 57
subtract 1 97 57
assign 1 97 57
add 1 97 57
assign 1 98 57
new 0 98 57
assign 1 98 57
new 0 98 57
assign 1 98 57
subtract 1 98 57
assign 1 98 57
add 1 98 57
setStringValue 5 99 57
assign 1 103 57
new 0 103 57
setValue 1 103 57
assign 1 104 57
sizeGet 0 104 57
assign 1 104 57
copy 0 104 57
decrementValue 0 105 57
assign 1 106 57
new 0 106 57
assign 1 107 57
new 0 107 57
assign 1 108 57
new 0 108 57
assign 1 108 57
greaterEquals 1 108 57
getInt 2 110 57
assign 1 112 57
new 0 112 57
assign 1 112 57
greater 1 112 57
assign 1 112 57
lesser 1 112 57
assign 1 0 57
assign 1 0 57
assign 1 0 57
assign 1 113 57
new 0 113 57
subtractValue 1 113 57
multiplyValue 1 114 57
addValue 1 115 57
assign 1 116 57
new 0 116 57
assign 1 116 57
greater 1 116 57
assign 1 116 57
lesser 1 116 57
assign 1 0 57
assign 1 0 57
assign 1 0 57
assign 1 117 57
new 0 117 57
subtractValue 1 117 57
multiplyValue 1 118 57
addValue 1 119 57
assign 1 120 57
new 0 120 57
assign 1 120 57
greater 1 120 57
assign 1 120 57
lesser 1 120 57
assign 1 0 57
assign 1 0 57
assign 1 0 57
assign 1 121 57
new 0 121 57
subtractValue 1 121 57
multiplyValue 1 122 57
addValue 1 123 57
assign 1 124 57
new 0 124 57
assign 1 124 57
equals 1 124 57
assign 1 126 57
new 0 126 57
multiplyValue 1 126 57
assign 1 128 57
new 0 128 57
assign 1 128 57
add 1 128 57
assign 1 128 57
new 0 128 57
assign 1 128 57
add 1 128 57
assign 1 128 57
add 1 128 57
assign 1 128 57
new 1 128 57
throw 1 128 57
decrementValue 0 130 57
multiplyValue 1 131 57
assign 1 136 57
toString 0 136 57
return 1 136 57
new 1 140 57
assign 1 144 57
new 0 144 57
return 1 144 57
return 1 148 57
assign 1 159 57
new 0 159 57
return 1 177 57
assign 1 181 57
new 0 181 57
assign 1 181 57
new 1 181 57
assign 1 181 57
new 0 181 57
assign 1 181 57
once 0 181 57
assign 1 181 57
new 0 181 57
assign 1 181 57
once 0 181 57
assign 1 181 57
toString 4 181 57
return 1 181 57
assign 1 185 57
new 0 185 57
assign 1 185 57
new 1 185 57
assign 1 185 57
toHexString 1 185 57
return 1 185 57
assign 1 189 57
new 0 189 57
assign 1 189 57
once 0 189 57
assign 1 189 57
new 0 189 57
assign 1 189 57
once 0 189 57
assign 1 189 57
toString 3 189 57
return 1 189 57
assign 1 193 57
new 1 193 57
assign 1 193 57
new 0 193 57
assign 1 193 57
once 0 193 57
assign 1 193 57
toString 4 193 57
return 1 193 57
assign 1 197 57
new 0 197 57
assign 1 197 57
once 0 197 57
assign 1 197 57
toString 4 197 57
return 1 197 57
clear 0 201 57
assign 1 202 57
abs 0 202 57
assign 1 203 57
new 0 203 57
assign 1 204 57
new 0 204 57
assign 1 204 57
greater 1 204 57
setValue 1 205 57
modulusValue 1 206 57
assign 1 207 57
new 0 207 57
assign 1 207 57
lesser 1 207 57
assign 1 208 57
new 0 208 57
addValue 1 208 57
addValue 1 210 57
assign 1 213 57
capacityGet 0 213 57
assign 1 213 57
sizeGet 0 213 57
assign 1 213 57
lesserEquals 1 213 57
assign 1 214 57
capacityGet 0 214 57
assign 1 214 57
new 0 214 57
assign 1 214 57
add 1 214 57
capacitySet 1 214 57
assign 1 216 57
sizeGet 0 216 57
setIntUnchecked 2 216 57
assign 1 217 57
sizeGet 0 217 57
assign 1 217 57
new 0 217 57
assign 1 217 57
add 1 217 57
sizeSet 1 217 57
divideValue 1 221 57
assign 1 224 57
sizeGet 0 224 57
assign 1 224 57
lesser 1 224 57
assign 1 225 57
capacityGet 0 225 57
assign 1 225 57
sizeGet 0 225 57
assign 1 225 57
lesserEquals 1 225 57
assign 1 226 57
capacityGet 0 226 57
assign 1 226 57
new 0 226 57
assign 1 226 57
add 1 226 57
capacitySet 1 226 57
assign 1 228 57
sizeGet 0 228 57
assign 1 228 57
new 0 228 57
assign 1 228 57
once 0 228 57
setIntUnchecked 2 228 57
assign 1 229 57
sizeGet 0 229 57
assign 1 229 57
new 0 229 57
assign 1 229 57
add 1 229 57
sizeSet 1 229 57
assign 1 234 57
new 0 234 57
assign 1 234 57
lesser 1 234 57
assign 1 235 57
new 0 235 57
addValue 1 235 57
assign 1 237 57
reverseBytes 0 237 57
return 1 237 57
assign 1 241 57
new 0 241 57
setValue 1 242 57
return 1 243 57
assign 1 247 57
copy 0 247 57
assign 1 247 57
absValue 0 247 57
return 1 247 57
assign 1 251 57
new 0 251 57
assign 1 251 57
lesser 1 251 57
assign 1 252 57
new 0 252 57
multiplyValue 1 252 57
return 1 268 59
assign 1 273 58
new 0 273 58
return 1 279 58
assign 1 288 58
new 0 288 58
return 1 294 58
return 1 312 59
return 1 326 59
assign 1 331 58
new 0 331 58
return 1 337 58
return 1 355 59
assign 1 360 58
new 0 360 58
return 1 366 58
return 1 384 59
assign 1 389 58
new 0 389 58
return 1 395 58
return 1 413 59
assign 1 418 58
new 0 418 58
return 1 429 58
return 1 452 59
assign 1 457 58
new 0 457 58
return 1 463 58
return 1 481 59
assign 1 485 57
new 0 485 57
return 1 496 57
return 1 510 59
assign 1 514 57
new 0 514 57
return 1 525 57
return 1 539 59
assign 1 543 57
new 0 543 57
return 1 554 57
return 1 568 59
assign 1 572 57
new 0 572 57
return 1 583 57
return 1 597 59
assign 1 602 57
new 0 602 57
assign 1 604 57
new 0 604 57
assign 1 604 57
lesser 1 604 57
multiplyValue 1 605 57
incrementValue 0 604 57
return 1 607 57
assign 1 639 61
new 0 639 61
return 1 639 61
assign 1 668 61
new 0 668 61
return 1 668 61
assign 1 689 61
new 0 689 61
return 1 689 61
assign 1 710 61
new 0 710 61
return 1 710 61
assign 1 731 61
new 0 731 61
return 1 731 61
assign 1 752 61
new 0 752 61
return 1 752 61
assign 1 0 57
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1085372256: return bem_increment_0();
case 314718434: return bem_print_0();
case 92614563: return bem_abs_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 1205852557: return bem_incrementValue_0();
case 2011061582: return bem_vintGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 2022143834: return bem_vintSet_0();
case 1046151292: return bem_decrement_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 663753935: return bem_decrementValue_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1717721534: return bem_toHexString_0();
case 1820417453: return bem_create_0();
case 1832132624: return bem_absValue_0();
case 1865310226: return bem_toFloat_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 736217829: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 92659731: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case 1551584407: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 3419349: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 81310150: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case 50808448: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2139839746: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1567199433: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case 202757140: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1580104161: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 696708346: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 364269035: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case 1717721533: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case 2022143835: return bem_vintSet_1(bevd_0);
case 440702026: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case 477101321: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 1265088726: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2116933162: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1958502700: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case 2090192440: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 432448303: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1220624855: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1089696223: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1852231828: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 979186229: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 92957641: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case 436987761: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 387946633: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 1245164300: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1774940959: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1670339153: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 1774940960: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callHash) {
case 1774940961: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 1670339156: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_3_MathInt();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_3_MathInt.bevs_inst = (BEC_2_4_3_MathInt)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_3_MathInt.bevs_inst;
}
}
