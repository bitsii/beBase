package be.BEL_4_Base;
/* IO:File: source/base/LinkedList.be */
public class BEC_9_10_4_ContainerLinkedListNode extends BEC_6_6_SystemObject {
public BEC_9_10_4_ContainerLinkedListNode() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_9_10_4_ContainerLinkedListNode bevs_inst;
public BEC_9_10_4_ContainerLinkedListNode bevp_prior;
public BEC_9_10_4_ContainerLinkedListNode bevp_next;
public BEC_6_6_SystemObject bevp_held;
public BEC_9_10_ContainerLinkedList bevp_mylist;
public BEC_9_10_4_ContainerLinkedListNode bem_new_2(BEC_6_6_SystemObject beva__held, BEC_9_10_ContainerLinkedList beva__mylist) throws Throwable {
bevp_held = beva__held;
bevp_mylist = beva__mylist;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_insertBefore_1(BEC_6_6_SystemObject beva_toIns) throws Throwable {
BEC_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_toIns.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, null);
beva_toIns.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, this);
beva_toIns.bemd_1(1838097046, BEL_4_Base.bevn_mylistSet_1, bevp_mylist);
bevl_p = bevp_prior;
bevp_prior = (BEC_9_10_4_ContainerLinkedListNode) beva_toIns;
if (bevl_p == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 63 */ {
bevp_mylist.bem_firstNodeSet_1(beva_toIns);
} /* Line: 65 */
 else  /* Line: 66 */ {
bevl_p.bem_nextSet_1(beva_toIns);
beva_toIns.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, bevl_p);
} /* Line: 68 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_9_10_4_ContainerLinkedListNode bevl_p = null;
BEC_9_10_4_ContainerLinkedListNode bevl_n = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevl_p = bevp_prior;
bevl_n = bevp_next;
bevp_next = null;
bevp_prior = null;
if (bevl_p == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 77 */ {
bevp_mylist.bem_firstNodeSet_1(bevl_n);
if (bevl_n == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 80 */ {
bevl_n.bem_priorSet_1(null);
} /* Line: 81 */
 else  /* Line: 82 */ {
bevp_mylist.bem_lastNodeSet_1(bevl_n);
} /* Line: 84 */
} /* Line: 80 */
 else  /* Line: 77 */ {
if (bevl_n == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 86 */ {
bevl_p.bem_nextSet_1(bevl_n);
bevp_mylist.bem_lastNodeSet_1(bevl_p);
} /* Line: 89 */
 else  /* Line: 90 */ {
bevl_p.bem_nextSet_1(bevl_n);
bevl_n.bem_priorSet_1(bevl_p);
} /* Line: 93 */
} /* Line: 77 */
bevp_mylist = null;
return this;
} /*method end*/
public BEC_9_10_4_ContainerLinkedListNode bem_priorGet_0() throws Throwable {
return bevp_prior;
} /*method end*/
public BEC_6_6_SystemObject bem_priorSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_prior = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_4_ContainerLinkedListNode bem_nextGet_0() throws Throwable {
return bevp_next;
} /*method end*/
public BEC_6_6_SystemObject bem_nextSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_next = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_6_6_SystemObject bem_heldSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_held = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_mylistGet_0() throws Throwable {
return bevp_mylist;
} /*method end*/
public BEC_6_6_SystemObject bem_mylistSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mylist = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 51, 58, 59, 60, 61, 62, 63, 65, 67, 68, 73, 74, 75, 76, 77, 79, 80, 81, 84, 86, 88, 89, 92, 93, 95, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 13
assign 1 51 13
priorSet 1 58 13
nextSet 1 59 13
mylistSet 1 60 13
assign 1 61 13
assign 1 62 13
assign 1 63 13
undef 1 63 13
firstNodeSet 1 65 13
nextSet 1 67 13
priorSet 1 68 13
assign 1 73 13
assign 1 74 13
assign 1 75 13
assign 1 76 13
assign 1 77 13
undef 1 77 13
firstNodeSet 1 79 13
assign 1 80 13
def 1 80 13
priorSet 1 81 13
lastNodeSet 1 84 13
assign 1 86 13
undef 1 86 13
nextSet 1 88 13
lastNodeSet 1 89 13
nextSet 1 92 13
priorSet 1 93 13
assign 1 95 13
return 1 0 13
assign 1 0 13
return 1 0 13
assign 1 0 13
return 1 0 13
assign 1 0 13
return 1 0 13
assign 1 0 13
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 931239762: return bem_heldGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 946514141: return bem_priorGet_0();
case 729571811: return bem_serializeToString_0();
case 1849179299: return bem_mylistGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case 819712668: return bem_delete_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 957596394: return bem_priorSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1838097046: return bem_mylistSet_1(bevd_0);
case 1505376950: return bem_insertBefore_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, (BEC_9_10_ContainerLinkedList) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_10_4_ContainerLinkedListNode();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_10_4_ContainerLinkedListNode.bevs_inst = (BEC_9_10_4_ContainerLinkedListNode)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_10_4_ContainerLinkedListNode.bevs_inst;
}
}
