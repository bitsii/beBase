package be.BEL_4_Base;
/* IO:File: source/build/Build.be */
public class BEC_5_5_BuildBuild extends BEC_6_6_SystemObject {
public BEC_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_6 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_7, 28));
private static byte[] bels_8 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_9 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_9, 12));
private static byte[] bels_10 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_10, 21));
private static byte[] bels_11 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_11, 6));
private static byte[] bels_12 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_12, 13));
private static byte[] bels_13 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_13, 21));
private static byte[] bels_14 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_14, 6));
private static byte[] bels_15 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_16 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_4_6_TextString bevo_9 = (new BEC_4_6_TextString(bels_16, 5));
private static byte[] bels_17 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_18 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_21 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_22 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_23 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_24 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_25 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_26 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_27 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_30 = {0x74,0x72,0x75,0x65};
private static byte[] bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_51 = {0x72,0x75,0x6E};
private static byte[] bels_52 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_53 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_54 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_55 = {0x67,0x63,0x63};
private static byte[] bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_57 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_58 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_58, 9));
private static byte[] bels_59 = {};
private static byte[] bels_60 = {0x63};
private static byte[] bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_61, 8));
private static byte[] bels_62 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_4_6_TextString bevo_12 = (new BEC_4_6_TextString(bels_62, 7));
private static byte[] bels_63 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_64 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_65 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_13 = (new BEC_4_6_TextString(bels_65, 2));
private static byte[] bels_66 = {0x63,0x73};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_66, 2));
private static byte[] bels_67 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_67, 2));
private static byte[] bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_69 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_69, 19));
private static byte[] bels_70 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_17 = (new BEC_4_6_TextString(bels_70, 31));
private static byte[] bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_18 = (new BEC_4_6_TextString(bels_71, 31));
private static byte[] bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_19 = (new BEC_4_6_TextString(bels_72, 41));
private static byte[] bels_73 = {0x2F};
private static byte[] bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_20 = (new BEC_4_6_TextString(bels_74, 31));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_21 = (new BEC_4_6_TextString(bels_75, 41));
private static byte[] bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_76, 51));
private static byte[] bels_77 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_23 = (new BEC_4_6_TextString(bels_77, 14));
private static byte[] bels_78 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_4_6_TextString bevo_24 = (new BEC_4_6_TextString(bels_78, 19));
private static byte[] bels_79 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_25 = (new BEC_4_6_TextString(bels_79, 9));
private static byte[] bels_80 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_26 = (new BEC_4_6_TextString(bels_80, 13));
private static byte[] bels_81 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_27 = (new BEC_4_6_TextString(bels_81, 2));
private static byte[] bels_82 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_4_6_TextString bevo_28 = (new BEC_4_6_TextString(bels_82, 22));
private static byte[] bels_83 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_29 = (new BEC_4_6_TextString(bels_83, 3));
private static byte[] bels_84 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_4_6_TextString bevo_30 = (new BEC_4_6_TextString(bels_84, 15));
private static byte[] bels_85 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_31 = (new BEC_4_6_TextString(bels_85, 4));
private static byte[] bels_86 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_4_6_TextString bevo_32 = (new BEC_4_6_TextString(bels_86, 15));
private static byte[] bels_87 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_33 = (new BEC_4_6_TextString(bels_87, 5));
private static byte[] bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_4_6_TextString bevo_34 = (new BEC_4_6_TextString(bels_88, 15));
private static byte[] bels_89 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_35 = (new BEC_4_6_TextString(bels_89, 6));
private static byte[] bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_4_6_TextString bevo_36 = (new BEC_4_6_TextString(bels_90, 15));
private static byte[] bels_91 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_37 = (new BEC_4_6_TextString(bels_91, 7));
private static byte[] bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_4_6_TextString bevo_38 = (new BEC_4_6_TextString(bels_92, 15));
private static byte[] bels_93 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_39 = (new BEC_4_6_TextString(bels_93, 8));
private static byte[] bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_4_6_TextString bevo_40 = (new BEC_4_6_TextString(bels_94, 15));
private static byte[] bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_41 = (new BEC_4_6_TextString(bels_95, 9));
private static byte[] bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_4_6_TextString bevo_42 = (new BEC_4_6_TextString(bels_96, 15));
private static byte[] bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_43 = (new BEC_4_6_TextString(bels_97, 10));
private static byte[] bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_4_6_TextString bevo_44 = (new BEC_4_6_TextString(bels_98, 15));
private static byte[] bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_45 = (new BEC_4_6_TextString(bels_99, 11));
private static byte[] bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_4_6_TextString bevo_46 = (new BEC_4_6_TextString(bels_100, 16));
private static byte[] bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_47 = (new BEC_4_6_TextString(bels_101, 12));
private static byte[] bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_4_6_TextString bevo_48 = (new BEC_4_6_TextString(bels_102, 16));
private static byte[] bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_49 = (new BEC_4_6_TextString(bels_103, 13));
private static byte[] bels_104 = {0x20};
private static BEC_4_6_TextString bevo_50 = (new BEC_4_6_TextString(bels_104, 1));
private static byte[] bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_4_6_TextString bevo_51 = (new BEC_4_6_TextString(bels_105, 16));
public static BEC_5_5_BuildBuild bevs_inst;
public BEC_4_6_TextString bevp_mainName;
public BEC_4_6_TextString bevp_libName;
public BEC_4_6_TextString bevp_exeName;
public BEC_6_6_SystemObject bevp_emitFileHeader;
public BEC_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_9_10_ContainerLinkedList bevp_extLibs;
public BEC_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_platform;
public BEC_6_6_SystemObject bevp_outputPlatform;
public BEC_6_6_SystemObject bevp_emitLibrary;
public BEC_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_newline;
public BEC_6_6_SystemObject bevp_runArgs;
public BEC_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_9_5_ContainerArray bevp_args;
public BEC_6_10_SystemParameters bevp_params;
public BEC_5_4_LogicBool bevp_buildSucceeded;
public BEC_4_6_TextString bevp_buildMessage;
public BEC_4_8_TimeInterval bevp_startTime;
public BEC_4_8_TimeInterval bevp_parseTime;
public BEC_4_8_TimeInterval bevp_parseEmitTime;
public BEC_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_2_4_4_IOFilePath bevp_buildPath;
public BEC_6_6_SystemObject bevp_includePath;
public BEC_9_3_ContainerMap bevp_built;
public BEC_9_10_ContainerLinkedList bevp_toBuild;
public BEC_5_4_LogicBool bevp_printSteps;
public BEC_5_4_LogicBool bevp_printPlaces;
public BEC_5_4_LogicBool bevp_printAst;
public BEC_5_4_LogicBool bevp_printAllAst;
public BEC_9_3_ContainerSet bevp_printAstElements;
public BEC_5_4_LogicBool bevp_doEmit;
public BEC_5_4_LogicBool bevp_emitDebug;
public BEC_5_4_LogicBool bevp_parse;
public BEC_5_4_LogicBool bevp_prepMake;
public BEC_5_4_LogicBool bevp_make;
public BEC_5_4_LogicBool bevp_genOnly;
public BEC_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_5_8_BuildEmitData bevp_emitData;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public BEC_6_6_SystemObject bevp_code;
public BEC_4_6_TextString bevp_estr;
public BEC_6_6_SystemObject bevp_sharedEmitter;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_9_TextTokenizer bevp_twtok;
public BEC_4_9_TextTokenizer bevp_lctok;
public BEC_5_7_BuildLibrary bevp_deployLibrary;
public BEC_4_6_TextString bevp_deployPath;
public BEC_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_9_3_ContainerSet bevp_closeLibraries;
public BEC_5_4_LogicBool bevp_run;
public BEC_4_6_TextString bevp_compiler;
public BEC_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_4_6_TextString bevp_makeName;
public BEC_4_6_TextString bevp_makeArgs;
public BEC_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_5_4_LogicBool bevp_ownProcess;
public BEC_4_6_TextString bevp_readBuffer;
public BEC_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(3, bels_0));
bevp_lctok = (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isNewish_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 103 */
 else  /* Line: 103 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 103 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 104 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_process_1(BEC_4_6_TextString beva_arg) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_main_0() throws Throwable {
BEC_9_5_ContainerArray bevl__args = null;
BEC_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst.bem_new_0();
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = this.bem_main_1(bevl__args);
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_main_1(BEC_9_5_ContainerArray beva__args) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_0_tmpvar_phold = this.bem_go_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_go_0() throws Throwable {
BEC_4_3_MathInt bevl_whatResult = null;
BEC_5_4_LogicBool bevl_buildFailed = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (new BEC_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 128 */ {
bevp_buildMessage = (new BEC_4_6_TextString(16, bels_5));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (new BEC_4_6_TextString(14, bels_6));
} /* Line: 131 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_4_3_MathInt(1));
} /* Line: 136 */
if (bevp_printSteps.bevi_bool) /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 138 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 138 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 138 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 139 */
return bevl_whatResult;
} /*method end*/
public BEC_4_6_TextString bem_dllhead_1(BEC_4_6_TextString beva_addTo) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(5, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 151 */
return beva_addTo;
} /*method end*/
public BEC_6_6_SystemObject bem_config_0() throws Throwable {
BEC_4_6_TextString bevl_istr = null;
BEC_9_3_ContainerSet bevl_bfiles = null;
BEC_4_6_TextString bevl_bkey = null;
BEC_9_10_ContainerLinkedList bevl_pacm = null;
BEC_4_6_TextString bevl_pa = null;
BEC_4_6_TextString bevl_outLang = null;
BEC_6_6_SystemObject bevl_platformSources = null;
BEC_6_6_SystemObject bevl_langSources = null;
BEC_6_6_SystemObject bevl_emr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_92_tmpvar_phold = null;
BEC_4_6_TextString bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_95_tmpvar_phold = null;
BEC_4_6_TextString bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_98_tmpvar_phold = null;
BEC_4_6_TextString bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_4_6_TextString bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_106_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_108_tmpvar_phold = null;
BEC_4_6_TextString bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_111_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_112_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_113_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_115_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_116_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_2_4_IOFile bevt_118_tmpvar_phold = null;
BEC_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_120_tmpvar_phold = null;
BEC_2_4_IOFile bevt_121_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_122_tmpvar_phold = null;
bevl_bfiles = (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_4_6_TextString(9, bels_15));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 162 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 162 */ {
bevl_istr = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 165 */
} /* Line: 163 */
 else  /* Line: 162 */ {
break;
} /* Line: 162 */
} /* Line: 162 */
} /* Line: 162 */
bevt_13_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 170 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 171 */
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(7, bels_18));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 174 */ {
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(7, bels_19));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 175 */
 else  /* Line: 176 */ {
bevp_exeName = bevp_libName;
} /* Line: 177 */
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(9, bels_20));
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(6, bels_21));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(6, bels_22));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(11, bels_23));
bevt_31_tmpvar_phold = (new BEC_4_6_TextString(7, bels_24));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(8, bels_25));
bevt_36_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_4_6_TextString(14, bels_26));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_4_6_TextString(16, bels_27));
bevt_44_tmpvar_phold = (new BEC_4_6_TextString(5, bels_28));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (new BEC_4_6_TextString(10, bels_29));
bevt_48_tmpvar_phold = (new BEC_4_6_TextString(4, bels_30));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (new BEC_4_6_TextString(9, bels_31));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (new BEC_4_6_TextString(10, bels_32));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (new BEC_4_6_TextString(10, bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 191 */ {
bevp_usedLibrarysStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 192 */
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(15, bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevp_closeLibrariesStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 196 */
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(14, bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevp_deployFilesFrom = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 200 */
bevt_59_tmpvar_phold = (new BEC_4_6_TextString(12, bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 203 */ {
bevp_deployFilesTo = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 204 */
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(10, bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 207 */ {
bevp_extIncludes = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 208 */
bevt_63_tmpvar_phold = (new BEC_4_6_TextString(9, bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevp_ccObjArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 212 */
bevt_65_tmpvar_phold = (new BEC_4_6_TextString(6, bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 215 */ {
bevp_extLibs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 216 */
bevt_67_tmpvar_phold = (new BEC_4_6_TextString(11, bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevp_linkLibArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 220 */
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(13, bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevp_extLinkObjects = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 224 */
bevt_71_tmpvar_phold = (new BEC_4_6_TextString(14, bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 228 */
bevt_73_tmpvar_phold = (new BEC_4_6_TextString(7, bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 231 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 232 */
 else  /* Line: 233 */ {
bevp_runArgs = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 234 */
bevt_75_tmpvar_phold = (new BEC_4_6_TextString(10, bels_44));
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (new BEC_4_6_TextString(11, bels_45));
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (new BEC_4_6_TextString(8, bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (new BEC_4_6_TextString(11, bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (new BEC_4_6_TextString(15, bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_not_0();
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 242 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 242 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_iteratorGet_0();
while (true)
 /* Line: 243 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 243 */ {
bevl_pa = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 244 */
 else  /* Line: 243 */ {
break;
} /* Line: 243 */
} /* Line: 243 */
} /* Line: 243 */
bevt_86_tmpvar_phold = (new BEC_4_6_TextString(7, bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (new BEC_4_6_TextString(19, bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (new BEC_4_6_TextString(3, bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (new BEC_4_6_TextString(21, bels_52));
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (new BEC_4_6_TextString(8, bels_53));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_93_tmpvar_phold = (new BEC_4_6_TextString(8, bels_54));
bevt_94_tmpvar_phold = (new BEC_4_6_TextString(3, bels_55));
bevt_92_tmpvar_phold = bevp_params.bem_get_2(bevt_93_tmpvar_phold, bevt_94_tmpvar_phold);
bevp_compiler = (BEC_4_6_TextString) bevt_92_tmpvar_phold.bem_firstGet_0();
bevt_96_tmpvar_phold = (new BEC_4_6_TextString(4, bels_56));
bevt_97_tmpvar_phold = (new BEC_4_6_TextString(4, bels_57));
bevt_95_tmpvar_phold = bevp_params.bem_get_2(bevt_96_tmpvar_phold, bevt_97_tmpvar_phold);
bevp_makeName = (BEC_4_6_TextString) bevt_95_tmpvar_phold.bem_firstGet_0();
bevt_100_tmpvar_phold = bevo_10;
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_101_tmpvar_phold = (new BEC_4_6_TextString(0, bels_59));
bevt_98_tmpvar_phold = bevp_params.bem_get_2(bevt_99_tmpvar_phold, bevt_101_tmpvar_phold);
bevp_makeArgs = (BEC_4_6_TextString) bevt_98_tmpvar_phold.bem_firstGet_0();
bevp_parse = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevl_outLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 263 */
 else  /* Line: 264 */ {
bevl_outLang = (new BEC_4_6_TextString(1, bels_60));
} /* Line: 265 */
bevt_105_tmpvar_phold = bevo_11;
bevt_104_tmpvar_phold = bevl_outLang.bem_add_1(bevt_105_tmpvar_phold);
bevt_106_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_103_tmpvar_phold = bevt_104_tmpvar_phold.bem_add_1(bevt_106_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_103_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_108_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_108_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 274 */
bevt_110_tmpvar_phold = bevo_12;
bevt_109_tmpvar_phold = bevl_outLang.bem_add_1(bevt_110_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_109_tmpvar_phold);
if (bevl_langSources == null) {
bevt_111_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_111_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_111_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_112_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_112_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 279 */
bevp_toBuild = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_113_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 283 */ {
bevt_114_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 283 */ {
bevl_istr = (BEC_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_115_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_115_tmpvar_phold);
} /* Line: 284 */
 else  /* Line: 283 */ {
break;
} /* Line: 283 */
} /* Line: 283 */
bevp_newline = (BEC_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_118_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bem_existsGet_0();
bevt_116_tmpvar_phold = bevt_117_tmpvar_phold.bem_not_0();
if (bevt_116_tmpvar_phold.bevi_bool) /* Line: 291 */ {
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_119_tmpvar_phold.bem_makeDirs_0();
} /* Line: 292 */
if (bevp_emitFileHeader == null) {
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpvar_phold.bevi_bool) /* Line: 294 */ {
bevt_121_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_121_tmpvar_phold.bem_readerGet_0();
bevt_122_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_122_tmpvar_phold.bemd_1(347960121, BEL_4_Base.bevn_readString_1, bevp_readBuffer);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 297 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(13, bels_63));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(12, bels_64));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_6_6_SystemObject bem_setClassesToWrite_0() throws Throwable {
BEC_9_3_ContainerSet bevl_toEmit = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_9_3_ContainerSet bevl_usedBy = null;
BEC_4_6_TextString bevl_ub = null;
BEC_9_3_ContainerSet bevl_subClasses = null;
BEC_4_6_TextString bevl_sc = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 311 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 311 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 313 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 316 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_iteratorGet_0();
while (true)
 /* Line: 317 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 317 */ {
bevl_ub = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 318 */
 else  /* Line: 317 */ {
break;
} /* Line: 317 */
} /* Line: 317 */
} /* Line: 317 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 322 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_iteratorGet_0();
while (true)
 /* Line: 323 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_22_tmpvar_phold != null && bevt_22_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_22_tmpvar_phold).bevi_bool) /* Line: 323 */ {
bevl_sc = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 324 */
 else  /* Line: 323 */ {
break;
} /* Line: 323 */
} /* Line: 323 */
} /* Line: 323 */
} /* Line: 322 */
} /* Line: 313 */
 else  /* Line: 311 */ {
break;
} /* Line: 311 */
} /* Line: 311 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 329 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 331 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
return this;
} /*method end*/
public BEC_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_4_6_TextString bevl_emitLang = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 342 */ {
return bevp_emitCommon;
} /* Line: 343 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 348 */ {
bevl_emitLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 350 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 350 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 355 */
 else  /* Line: 356 */ {
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(49, bels_68));
bevt_8_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 357 */
} /* Line: 350 */
} /* Line: 350 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 360 */
return null;
} /*method end*/
public BEC_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_6_6_SystemObject bevl_em = null;
BEC_9_3_ContainerSet bevl_ulibs = null;
BEC_6_6_SystemObject bevl_ups = null;
BEC_6_6_SystemObject bevl_pack = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_tb = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_bp = null;
BEC_6_6_SystemObject bevl_cpFrom = null;
BEC_6_6_SystemObject bevl_cpTo = null;
BEC_6_6_SystemObject bevl_fIter = null;
BEC_6_6_SystemObject bevl_tIter = null;
BEC_4_3_MathInt bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_19_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_20_tmpvar_phold = null;
BEC_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_22_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_26_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_32_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_64_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_4_6_TextString bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
bevp_startTime = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_emitData = (new BEC_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 370 */ {
bevp_deployLibrary = (new BEC_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 373 */ {
bevt_6_tmpvar_phold = bevo_16;
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevp_libName);
bevt_5_tmpvar_phold.bem_print_0();
} /* Line: 374 */
} /* Line: 373 */
bevl_ulibs = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 379 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 379 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 383 */
} /* Line: 380 */
 else  /* Line: 379 */ {
break;
} /* Line: 379 */
} /* Line: 379 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 386 */ {
bevt_10_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 386 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_not_0();
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_13_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_13_tmpvar_phold);
} /* Line: 391 */
} /* Line: 387 */
 else  /* Line: 386 */ {
break;
} /* Line: 386 */
} /* Line: 386 */
if (bevp_parse.bevi_bool) /* Line: 394 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 396 */ {
bevt_14_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 396 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 399 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 401 */
bevt_15_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseTime = bevt_15_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_printSteps.bevi_bool) /* Line: 405 */ {
bevt_17_tmpvar_phold = bevo_17;
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_16_tmpvar_phold.bem_print_0();
} /* Line: 406 */
bevt_19_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_19_tmpvar_phold == null) {
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_20_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_20_tmpvar_phold.bem_doEmit_0();
bevt_21_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_21_tmpvar_phold;
} /* Line: 411 */
if (bevp_doEmit.bevi_bool) /* Line: 413 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_22_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_22_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 417 */ {
bevt_23_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpvar_phold != null && bevt_23_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_23_tmpvar_phold).bevi_bool) /* Line: 417 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 419 */
 else  /* Line: 417 */ {
break;
} /* Line: 417 */
} /* Line: 417 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 423 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 423 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 425 */
 else  /* Line: 423 */ {
break;
} /* Line: 423 */
} /* Line: 423 */
} /* Line: 423 */
bevt_26_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitTime = bevt_26_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 430 */ {
bevt_29_tmpvar_phold = bevo_18;
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_28_tmpvar_phold.bem_print_0();
} /* Line: 431 */
bevt_31_tmpvar_phold = bevo_19;
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_30_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 434 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 436 */
if (bevp_make.bevi_bool) /* Line: 439 */ {
bevt_32_tmpvar_phold = bevp_genOnly.bem_not_0();
if (bevt_32_tmpvar_phold.bevi_bool) /* Line: 440 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 443 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_iteratorGet_0();
while (true)
 /* Line: 444 */ {
bevt_33_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 444 */ {
bevl_bp = bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_34_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_35_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_35_tmpvar_phold.bem_copy_0();
bevt_37_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_36_tmpvar_phold);
bevt_39_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_38_tmpvar_phold != null && bevt_38_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_38_tmpvar_phold).bevi_bool) /* Line: 448 */ {
bevt_40_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_40_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 449 */
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 451 */ {
bevt_44_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_44_tmpvar_phold, bevt_45_tmpvar_phold);
} /* Line: 452 */
} /* Line: 451 */
 else  /* Line: 444 */ {
break;
} /* Line: 444 */
} /* Line: 444 */
} /* Line: 444 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 459 */ {
bevt_46_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_46_tmpvar_phold != null && bevt_46_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_46_tmpvar_phold).bevi_bool) /* Line: 459 */ {
bevt_47_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 459 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 459 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 459 */
 else  /* Line: 459 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 459 */ {
bevt_48_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_48_tmpvar_phold);
bevt_53_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_copy_0();
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_54_tmpvar_phold = (new BEC_4_6_TextString(1, bels_73));
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_54_tmpvar_phold);
bevt_55_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_55_tmpvar_phold);
bevl_cpTo = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_49_tmpvar_phold);
bevt_57_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_56_tmpvar_phold = bevt_57_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_56_tmpvar_phold != null && bevt_56_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_56_tmpvar_phold).bevi_bool) /* Line: 463 */ {
bevt_58_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_58_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 464 */
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 466 */ {
bevt_62_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_62_tmpvar_phold, bevt_63_tmpvar_phold);
} /* Line: 467 */
} /* Line: 466 */
 else  /* Line: 459 */ {
break;
} /* Line: 459 */
} /* Line: 459 */
} /* Line: 459 */
} /* Line: 440 */
bevt_64_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_now_0();
bevp_parseEmitCompileTime = bevt_64_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_65_tmpvar_phold.bevi_bool) /* Line: 474 */ {
bevt_67_tmpvar_phold = bevo_20;
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_66_tmpvar_phold.bem_print_0();
} /* Line: 475 */
if (bevp_parseEmitTime == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 477 */ {
bevt_70_tmpvar_phold = bevo_21;
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_69_tmpvar_phold.bem_print_0();
} /* Line: 478 */
if (bevp_parseEmitCompileTime == null) {
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_71_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_71_tmpvar_phold.bevi_bool) /* Line: 480 */ {
bevt_73_tmpvar_phold = bevo_22;
bevt_72_tmpvar_phold = bevt_73_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_72_tmpvar_phold.bem_print_0();
} /* Line: 481 */
if (bevp_run.bevi_bool) /* Line: 484 */ {
bevt_74_tmpvar_phold = bevo_23;
bevt_74_tmpvar_phold.bem_print_0();
bevl_result = (BEC_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_77_tmpvar_phold = bevo_24;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevl_result);
bevt_78_tmpvar_phold = bevo_25;
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bem_add_1(bevt_78_tmpvar_phold);
bevt_75_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 488 */
bevt_79_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_79_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSyns_1(BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_kls = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 494 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 494 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 498 */
 else  /* Line: 494 */ {
break;
} /* Line: 494 */
} /* Line: 494 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 500 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 500 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 504 */
 else  /* Line: 500 */ {
break;
} /* Line: 500 */
} /* Line: 500 */
bevt_6_tmpvar_phold = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_getSyn_2(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_syn = null;
BEC_6_6_SystemObject bevl_pklass = null;
BEC_6_6_SystemObject bevl_psyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 510 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 511 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 514 */ {
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 515 */
 else  /* Line: 516 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 519 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 521 */
 else  /* Line: 522 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 524 */
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 526 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevt_18_tmpvar_phold, (BEC_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_5_8_BuildClassSyn bem_getSynNp_1(BEC_6_6_SystemObject beva_np) throws Throwable {
BEC_6_6_SystemObject bevl_nps = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 536 */ {
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /* Line: 537 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevl_nps, (BEC_5_8_BuildClassSyn) bevl_syn);
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 552 */ {
bevp_sharedEmitter = (new BEC_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 553 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_doParse_1(BEC_6_6_SystemObject beva_toParse) throws Throwable {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_blank = null;
BEC_6_6_SystemObject bevl_emitter = null;
BEC_5_4_LogicBool bevl_parseThis = null;
BEC_6_6_SystemObject bevl_src = null;
BEC_9_10_ContainerLinkedList bevl_toks = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_ntunode = null;
BEC_6_6_SystemObject bevl_ntt = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 566 */ {
if (bevp_printSteps.bevi_bool) /* Line: 567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 567 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 567 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 567 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 567 */ {
bevt_4_tmpvar_phold = bevo_26;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 568 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 581 */ {
bevt_11_tmpvar_phold = bevo_27;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 582 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 585 */ {
bevt_13_tmpvar_phold = bevo_28;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 587 */
if (bevp_printSteps.bevi_bool) /* Line: 590 */ {
bevt_15_tmpvar_phold = bevo_29;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 591 */
bevt_16_tmpvar_phold = (BEC_5_5_5_BuildVisitPass2) (new BEC_5_5_5_BuildVisitPass2()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 594 */ {
bevt_17_tmpvar_phold = bevo_30;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 596 */
if (bevp_printSteps.bevi_bool) /* Line: 598 */ {
bevt_19_tmpvar_phold = bevo_31;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 599 */
bevt_20_tmpvar_phold = (BEC_5_5_5_BuildVisitPass3) (new BEC_5_5_5_BuildVisitPass3()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 604 */ {
bevt_21_tmpvar_phold = bevo_32;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 606 */
if (bevp_printSteps.bevi_bool) /* Line: 609 */ {
bevt_23_tmpvar_phold = bevo_33;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 610 */
bevt_24_tmpvar_phold = (BEC_5_5_5_BuildVisitPass4) (new BEC_5_5_5_BuildVisitPass4()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 613 */ {
bevt_25_tmpvar_phold = bevo_34;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 615 */
if (bevp_printSteps.bevi_bool) /* Line: 618 */ {
bevt_27_tmpvar_phold = bevo_35;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 619 */
bevt_28_tmpvar_phold = (BEC_5_5_5_BuildVisitPass5) (new BEC_5_5_5_BuildVisitPass5()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 622 */ {
bevt_29_tmpvar_phold = bevo_36;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 624 */
if (bevp_printSteps.bevi_bool) /* Line: 627 */ {
bevt_31_tmpvar_phold = bevo_37;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 628 */
bevt_32_tmpvar_phold = (BEC_5_5_5_BuildVisitPass6) (new BEC_5_5_5_BuildVisitPass6()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 631 */ {
bevt_33_tmpvar_phold = bevo_38;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 633 */
if (bevp_printSteps.bevi_bool) /* Line: 636 */ {
bevt_35_tmpvar_phold = bevo_39;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 637 */
bevt_36_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 640 */ {
bevt_37_tmpvar_phold = bevo_40;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 642 */
if (bevp_printSteps.bevi_bool) /* Line: 645 */ {
bevt_39_tmpvar_phold = bevo_41;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 646 */
bevt_40_tmpvar_phold = (BEC_5_5_5_BuildVisitPass8) (new BEC_5_5_5_BuildVisitPass8()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 649 */ {
bevt_41_tmpvar_phold = bevo_42;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 651 */
if (bevp_printSteps.bevi_bool) /* Line: 654 */ {
bevt_43_tmpvar_phold = bevo_43;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 655 */
bevt_44_tmpvar_phold = (BEC_5_5_5_BuildVisitPass9) (new BEC_5_5_5_BuildVisitPass9()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 658 */ {
bevt_45_tmpvar_phold = bevo_44;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 660 */
if (bevp_printSteps.bevi_bool) /* Line: 663 */ {
bevt_47_tmpvar_phold = bevo_45;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 664 */
bevt_48_tmpvar_phold = (BEC_5_5_6_BuildVisitPass10) (new BEC_5_5_6_BuildVisitPass10()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 667 */ {
bevt_49_tmpvar_phold = bevo_46;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 669 */
if (bevp_printSteps.bevi_bool) /* Line: 671 */ {
bevt_51_tmpvar_phold = bevo_47;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 672 */
bevt_52_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 675 */ {
bevt_53_tmpvar_phold = bevo_48;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 677 */
if (bevp_printSteps.bevi_bool) /* Line: 680 */ {
bevt_55_tmpvar_phold = bevo_49;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_50;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 682 */
bevt_57_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 685 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 685 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 685 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 685 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 685 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 685 */ {
bevt_58_tmpvar_phold = bevo_51;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 687 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 689 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 689 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 700 */
 else  /* Line: 689 */ {
break;
} /* Line: 689 */
} /* Line: 689 */
} /* Line: 689 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_nodify_2(BEC_6_6_SystemObject beva_parnode, BEC_6_6_SystemObject beva_toks) throws Throwable {
BEC_9_8_ContainerNodeList bevl_con = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_4_6_TextString bevl_cr = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_node = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst.bem_new_0();
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 710 */ {
bevt_1_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 710 */ {
bevl_node = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 714 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 715 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 717 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 719 */
} /* Line: 717 */
 else  /* Line: 710 */ {
break;
} /* Line: 710 */
} /* Line: 710 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_6_6_SystemObject bem_mainNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mainName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_6_6_SystemObject bem_exeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_6_6_SystemObject bem_extIncludesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_ccObjArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_6_6_SystemObject bem_extLibsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_linkLibArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_6_6_SystemObject bem_platformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesFromSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerProfileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSucceededSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildSucceeded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_6_6_SystemObject bem_buildMessageSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildMessage = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_6_6_SystemObject bem_startTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_startTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_6_6_SystemObject bem_buildPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_6_6_SystemObject bem_builtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_built = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_6_6_SystemObject bem_toBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_toBuild = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_6_6_SystemObject bem_printStepsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printSteps = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_6_6_SystemObject bem_printPlacesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printPlaces = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAllAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAllAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstElementsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAstElements = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_6_6_SystemObject bem_doEmitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_doEmit = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDebugSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitDebug = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_6_6_SystemObject bem_parseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parse = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_6_6_SystemObject bem_prepMakeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_prepMake = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_6_6_SystemObject bem_makeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_make = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_6_6_SystemObject bem_genOnlySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_genOnly = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDataSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitData = (BEC_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_6_6_SystemObject bem_codeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_6_6_SystemObject bem_estrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_estr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_6_6_SystemObject bem_twtokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_twtok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_6_6_SystemObject bem_lctokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lctok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_deployLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_6_6_SystemObject bem_deployPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployPath = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibraries = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_6_6_SystemObject bem_runSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_run = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compiler = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLangsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLangs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_6_6_SystemObject bem_makeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_makeArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeArgs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_dynConditionsAllGet_0() throws Throwable {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_6_6_SystemObject bem_ownProcessSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ownProcess = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_6_6_SystemObject bem_readBufferSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_readBuffer = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitCommonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {61, 63, 64, 65, 66, 68, 69, 70, 71, 72, 73, 74, 78, 80, 81, 82, 83, 83, 86, 89, 90, 95, 96, 97, 98, 98, 103, 103, 103, 103, 0, 103, 103, 0, 0, 0, 0, 0, 104, 104, 106, 106, 110, 110, 110, 110, 114, 114, 115, 115, 119, 120, 121, 121, 125, 126, 127, 129, 130, 131, 133, 134, 135, 135, 136, 0, 0, 0, 139, 141, 145, 145, 145, 146, 146, 146, 146, 147, 147, 147, 148, 148, 148, 149, 149, 149, 149, 150, 150, 150, 151, 151, 151, 153, 158, 160, 161, 161, 161, 162, 162, 0, 162, 162, 163, 163, 164, 165, 165, 170, 170, 170, 170, 171, 173, 173, 173, 174, 174, 175, 175, 175, 177, 179, 179, 179, 179, 179, 179, 180, 181, 181, 182, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 185, 185, 185, 185, 185, 186, 186, 186, 186, 186, 188, 188, 188, 189, 189, 189, 190, 190, 191, 191, 192, 194, 194, 195, 195, 196, 198, 198, 199, 199, 200, 202, 202, 203, 203, 204, 206, 206, 207, 207, 208, 210, 210, 211, 211, 212, 214, 214, 215, 215, 216, 218, 218, 219, 219, 220, 222, 222, 223, 223, 224, 226, 226, 227, 227, 228, 230, 230, 231, 231, 232, 234, 236, 236, 236, 237, 237, 237, 238, 238, 239, 239, 240, 241, 241, 242, 242, 242, 242, 0, 0, 0, 243, 0, 243, 243, 244, 247, 247, 248, 248, 249, 249, 250, 250, 250, 251, 251, 252, 252, 252, 252, 253, 253, 253, 253, 254, 254, 254, 254, 254, 255, 256, 257, 258, 259, 262, 262, 263, 265, 272, 272, 272, 272, 272, 273, 273, 274, 274, 277, 277, 277, 278, 278, 279, 279, 282, 283, 283, 0, 283, 283, 284, 284, 286, 287, 288, 290, 291, 291, 291, 292, 292, 294, 294, 295, 295, 296, 296, 297, 303, 304, 304, 304, 304, 304, 305, 305, 305, 305, 305, 306, 310, 311, 311, 311, 312, 313, 313, 313, 313, 314, 314, 314, 314, 315, 315, 315, 315, 315, 316, 316, 317, 0, 317, 317, 318, 321, 321, 321, 321, 321, 322, 322, 323, 0, 323, 323, 324, 329, 329, 329, 330, 331, 331, 331, 331, 331, 331, 338, 338, 342, 342, 343, 348, 348, 349, 350, 350, 351, 352, 352, 353, 354, 354, 355, 357, 357, 357, 359, 360, 362, 367, 368, 369, 370, 370, 371, 372, 374, 374, 374, 377, 379, 0, 379, 379, 380, 380, 381, 382, 383, 386, 0, 386, 386, 387, 387, 388, 389, 390, 391, 391, 396, 396, 397, 399, 401, 404, 404, 406, 406, 406, 408, 408, 408, 410, 410, 411, 411, 414, 415, 417, 417, 417, 418, 419, 421, 422, 423, 423, 423, 424, 425, 429, 429, 430, 430, 431, 431, 431, 433, 433, 433, 436, 440, 441, 442, 444, 0, 444, 444, 445, 445, 446, 446, 447, 447, 447, 448, 448, 449, 449, 451, 451, 451, 452, 452, 452, 456, 457, 459, 459, 0, 0, 0, 460, 460, 461, 461, 461, 461, 461, 461, 461, 461, 463, 463, 464, 464, 466, 466, 466, 467, 467, 467, 472, 472, 474, 474, 475, 475, 475, 477, 477, 478, 478, 478, 480, 480, 481, 481, 481, 485, 485, 486, 487, 487, 487, 487, 487, 488, 490, 490, 494, 494, 494, 495, 496, 496, 497, 498, 500, 500, 500, 501, 502, 502, 503, 504, 506, 506, 510, 510, 510, 510, 511, 511, 511, 513, 513, 514, 514, 514, 514, 515, 517, 517, 517, 517, 517, 519, 519, 520, 520, 521, 524, 524, 524, 526, 528, 528, 529, 529, 529, 529, 530, 534, 535, 535, 536, 536, 537, 543, 543, 544, 545, 552, 552, 553, 555, 560, 561, 562, 563, 564, 565, 565, 0, 0, 0, 568, 568, 568, 568, 570, 572, 572, 572, 572, 573, 573, 573, 574, 582, 582, 584, 584, 586, 586, 587, 587, 591, 591, 593, 593, 595, 595, 596, 596, 599, 599, 602, 602, 603, 605, 605, 606, 606, 610, 610, 612, 612, 614, 614, 615, 615, 619, 619, 621, 621, 623, 623, 624, 624, 628, 628, 630, 630, 632, 632, 633, 633, 637, 637, 639, 639, 641, 641, 642, 642, 646, 646, 648, 648, 650, 650, 651, 651, 655, 655, 657, 657, 659, 659, 660, 660, 664, 664, 666, 666, 668, 668, 669, 669, 672, 672, 674, 674, 676, 676, 677, 677, 681, 681, 682, 682, 684, 684, 0, 0, 0, 686, 686, 687, 687, 689, 689, 689, 690, 692, 693, 694, 694, 695, 696, 696, 696, 697, 698, 699, 700, 706, 707, 708, 709, 709, 710, 710, 711, 712, 712, 713, 714, 714, 715, 717, 717, 718, 719, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 274, 279, 280, 281, 283, 286, 287, 289, 292, 296, 299, 303, 306, 307, 309, 310, 316, 317, 318, 319, 325, 326, 327, 328, 332, 333, 334, 335, 343, 344, 345, 347, 348, 349, 353, 354, 355, 356, 357, 360, 364, 367, 371, 373, 393, 394, 395, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 418, 553, 554, 555, 556, 561, 562, 563, 563, 566, 568, 569, 570, 572, 573, 574, 582, 583, 584, 585, 587, 589, 590, 591, 592, 593, 595, 596, 597, 600, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 651, 652, 654, 655, 656, 661, 662, 664, 665, 666, 671, 672, 674, 675, 676, 681, 682, 684, 685, 686, 691, 692, 694, 695, 696, 701, 702, 704, 705, 706, 711, 712, 714, 715, 716, 721, 722, 724, 725, 726, 731, 732, 734, 735, 736, 741, 742, 744, 745, 746, 751, 752, 755, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 775, 776, 777, 779, 782, 786, 789, 789, 792, 794, 795, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 836, 837, 840, 842, 843, 844, 845, 846, 847, 852, 853, 854, 856, 857, 858, 859, 864, 865, 866, 868, 869, 870, 870, 873, 875, 876, 877, 883, 884, 885, 886, 887, 888, 889, 891, 892, 894, 899, 900, 901, 902, 903, 904, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 969, 970, 971, 974, 976, 977, 978, 979, 980, 982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 996, 997, 997, 1000, 1002, 1003, 1010, 1011, 1012, 1013, 1014, 1015, 1020, 1021, 1021, 1024, 1026, 1027, 1040, 1041, 1044, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1062, 1063, 1077, 1082, 1083, 1085, 1090, 1091, 1092, 1093, 1095, 1098, 1099, 1101, 1104, 1105, 1107, 1110, 1111, 1112, 1116, 1117, 1119, 1216, 1217, 1218, 1219, 1224, 1225, 1226, 1228, 1229, 1230, 1233, 1234, 1234, 1237, 1239, 1240, 1241, 1243, 1244, 1245, 1252, 1252, 1255, 1257, 1258, 1259, 1261, 1262, 1263, 1264, 1265, 1273, 1276, 1278, 1279, 1285, 1287, 1288, 1290, 1291, 1292, 1294, 1295, 1300, 1301, 1302, 1303, 1304, 1307, 1308, 1309, 1310, 1313, 1315, 1316, 1322, 1323, 1324, 1325, 1328, 1330, 1331, 1338, 1339, 1340, 1345, 1346, 1347, 1348, 1350, 1351, 1352, 1354, 1357, 1359, 1360, 1362, 1362, 1365, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375, 1376, 1378, 1379, 1381, 1382, 1383, 1385, 1386, 1387, 1395, 1396, 1399, 1401, 1403, 1406, 1410, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1426, 1427, 1429, 1430, 1431, 1433, 1434, 1435, 1444, 1445, 1446, 1451, 1452, 1453, 1454, 1456, 1461, 1462, 1463, 1464, 1466, 1471, 1472, 1473, 1474, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1487, 1488, 1501, 1502, 1505, 1507, 1508, 1509, 1510, 1511, 1517, 1518, 1521, 1523, 1524, 1525, 1526, 1527, 1533, 1534, 1562, 1563, 1564, 1569, 1570, 1571, 1572, 1574, 1575, 1576, 1577, 1578, 1583, 1584, 1587, 1588, 1589, 1590, 1591, 1592, 1597, 1598, 1599, 1600, 1603, 1604, 1605, 1607, 1609, 1610, 1611, 1612, 1613, 1614, 1615, 1623, 1624, 1625, 1626, 1631, 1632, 1634, 1635, 1636, 1637, 1641, 1646, 1647, 1649, 1728, 1729, 1730, 1731, 1732, 1733, 1734, 1737, 1741, 1744, 1748, 1749, 1750, 1751, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1763, 1764, 1766, 1767, 1769, 1770, 1771, 1772, 1775, 1776, 1778, 1779, 1781, 1782, 1783, 1784, 1787, 1788, 1790, 1791, 1792, 1794, 1795, 1796, 1797, 1800, 1801, 1803, 1804, 1806, 1807, 1808, 1809, 1812, 1813, 1815, 1816, 1818, 1819, 1820, 1821, 1824, 1825, 1827, 1828, 1830, 1831, 1832, 1833, 1836, 1837, 1839, 1840, 1842, 1843, 1844, 1845, 1848, 1849, 1851, 1852, 1854, 1855, 1856, 1857, 1860, 1861, 1863, 1864, 1866, 1867, 1868, 1869, 1872, 1873, 1875, 1876, 1878, 1879, 1880, 1881, 1884, 1885, 1887, 1888, 1890, 1891, 1892, 1893, 1896, 1897, 1898, 1899, 1901, 1902, 1904, 1908, 1911, 1915, 1916, 1917, 1918, 1920, 1921, 1924, 1926, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1960, 1961, 1962, 1963, 1964, 1965, 1968, 1970, 1971, 1972, 1973, 1974, 1975, 1977, 1979, 1980, 1982, 1983, 1993, 1996, 2000, 2003, 2007, 2010, 2014, 2017, 2021, 2024, 2028, 2031, 2035, 2038, 2042, 2045, 2049, 2052, 2056, 2059, 2063, 2066, 2070, 2073, 2077, 2080, 2084, 2087, 2091, 2094, 2098, 2101, 2105, 2108, 2112, 2115, 2119, 2122, 2126, 2129, 2133, 2136, 2140, 2143, 2147, 2150, 2154, 2157, 2161, 2164, 2168, 2171, 2175, 2178, 2182, 2185, 2189, 2192, 2196, 2199, 2203, 2206, 2210, 2213, 2217, 2220, 2224, 2227, 2231, 2234, 2238, 2241, 2245, 2248, 2252, 2255, 2259, 2262, 2266, 2269, 2273, 2276, 2280, 2283, 2287, 2290, 2294, 2297, 2301, 2304, 2308, 2311, 2315, 2318, 2322, 2325, 2329, 2332, 2336, 2339, 2343, 2346, 2350, 2353, 2357, 2360, 2364, 2367, 2371, 2374, 2378, 2381, 2385, 2388, 2392, 2395, 2399, 2402, 2406, 2409, 2413, 2416, 2420, 2423, 2427, 2430, 2434, 2437, 2441, 2444, 2448, 2451, 2455, 2458, 2462};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 61 237
new 0 61 237
assign 1 63 238
new 0 63 238
assign 1 64 239
new 0 64 239
assign 1 65 240
new 0 65 240
assign 1 66 241
new 0 66 241
assign 1 68 242
new 0 68 242
assign 1 69 243
new 0 69 243
assign 1 70 244
new 0 70 244
assign 1 71 245
new 0 71 245
assign 1 72 246
new 0 72 246
assign 1 73 247
new 0 73 247
assign 1 74 248
new 0 74 248
assign 1 78 249
new 0 78 249
assign 1 80 250
new 1 80 250
assign 1 81 251
ntypesGet 0 81 251
assign 1 82 252
twtokGet 0 82 252
assign 1 83 253
new 0 83 253
assign 1 83 254
new 1 83 254
assign 1 86 255
new 0 86 255
assign 1 89 256
new 0 89 256
assign 1 90 257
new 0 90 257
assign 1 95 258
new 0 95 258
assign 1 96 259
new 0 96 259
assign 1 97 260
new 0 97 260
assign 1 98 261
new 0 98 261
assign 1 98 262
new 1 98 262
assign 1 103 274
def 1 103 279
assign 1 103 280
new 0 103 280
assign 1 103 281
equals 1 103 281
assign 1 0 283
assign 1 103 286
new 0 103 286
assign 1 103 287
ends 1 103 287
assign 1 0 289
assign 1 0 292
assign 1 0 296
assign 1 0 299
assign 1 0 303
assign 1 104 306
new 0 104 306
return 1 104 307
assign 1 106 309
new 0 106 309
return 1 106 310
assign 1 110 316
new 0 110 316
assign 1 110 317
new 0 110 317
assign 1 110 318
swap 2 110 318
return 1 110 319
assign 1 114 325
new 0 114 325
assign 1 114 326
argsGet 0 114 326
assign 1 115 327
main 1 115 327
return 1 115 328
assign 1 119 332
assign 1 120 333
new 1 120 333
assign 1 121 334
go 0 121 334
return 1 121 335
assign 1 125 343
new 0 125 343
config 0 126 344
assign 1 127 345
new 0 127 345
assign 1 129 347
new 0 129 347
assign 1 130 348
doWhat 0 130 348
assign 1 131 349
new 0 131 349
assign 1 133 353
toString 0 133 353
assign 1 134 354
new 0 134 354
assign 1 135 355
new 0 135 355
assign 1 135 356
add 1 135 356
assign 1 136 357
new 0 136 357
assign 1 0 360
assign 1 0 364
assign 1 0 367
print 0 139 371
return 1 141 373
assign 1 145 393
nameGet 0 145 393
assign 1 145 394
new 0 145 394
assign 1 145 395
equals 1 145 395
assign 1 146 397
new 0 146 397
assign 1 146 398
add 1 146 398
assign 1 146 399
add 1 146 399
assign 1 146 400
add 1 146 400
assign 1 147 401
new 0 147 401
assign 1 147 402
add 1 147 402
assign 1 147 403
add 1 147 403
assign 1 148 404
new 0 148 404
assign 1 148 405
add 1 148 405
assign 1 148 406
add 1 148 406
assign 1 149 407
new 0 149 407
assign 1 149 408
add 1 149 408
assign 1 149 409
add 1 149 409
assign 1 149 410
add 1 149 410
assign 1 150 411
new 0 150 411
assign 1 150 412
add 1 150 412
assign 1 150 413
add 1 150 413
assign 1 151 414
new 0 151 414
assign 1 151 415
add 1 151 415
assign 1 151 416
add 1 151 416
return 1 153 418
assign 1 158 553
new 0 158 553
assign 1 160 554
new 0 160 554
assign 1 161 555
get 1 161 555
assign 1 161 556
def 1 161 561
assign 1 162 562
get 1 162 562
assign 1 162 563
iteratorGet 0 0 563
assign 1 162 566
hasNextGet 0 162 566
assign 1 162 568
nextGet 0 162 568
assign 1 163 569
has 1 163 569
assign 1 163 570
not 0 163 570
put 1 164 572
assign 1 165 573
new 1 165 573
addFile 1 165 574
assign 1 170 582
new 0 170 582
assign 1 170 583
nameGet 0 170 583
assign 1 170 584
new 0 170 584
assign 1 170 585
equals 1 170 585
preProcessorSet 1 171 587
assign 1 173 589
new 0 173 589
assign 1 173 590
get 1 173 590
assign 1 173 591
firstGet 0 173 591
assign 1 174 592
new 0 174 592
assign 1 174 593
has 1 174 593
assign 1 175 595
new 0 175 595
assign 1 175 596
get 1 175 596
assign 1 175 597
firstGet 0 175 597
assign 1 177 600
assign 1 179 602
new 0 179 602
assign 1 179 603
new 0 179 603
assign 1 179 604
get 2 179 604
assign 1 179 605
firstGet 0 179 605
assign 1 179 606
new 1 179 606
assign 1 179 607
pathGet 0 179 607
addStep 1 180 608
assign 1 181 609
new 0 181 609
addStep 1 181 610
assign 1 182 611
new 0 182 611
assign 1 182 612
new 0 182 612
assign 1 182 613
get 2 182 613
assign 1 182 614
firstGet 0 182 614
assign 1 182 615
new 1 182 615
assign 1 182 616
pathGet 0 182 616
assign 1 183 617
new 0 183 617
assign 1 183 618
new 0 183 618
assign 1 183 619
nameGet 0 183 619
assign 1 183 620
get 2 183 620
assign 1 183 621
firstGet 0 183 621
assign 1 183 622
new 1 183 622
assign 1 184 623
new 0 184 623
assign 1 184 624
nameGet 0 184 624
assign 1 184 625
get 2 184 625
assign 1 184 626
firstGet 0 184 626
assign 1 184 627
new 1 184 627
assign 1 185 628
new 0 185 628
assign 1 185 629
new 0 185 629
assign 1 185 630
get 2 185 630
assign 1 185 631
firstGet 0 185 631
assign 1 185 632
new 1 185 632
assign 1 186 633
new 0 186 633
assign 1 186 634
new 0 186 634
assign 1 186 635
get 2 186 635
assign 1 186 636
firstGet 0 186 636
assign 1 186 637
new 1 186 637
assign 1 188 638
new 0 188 638
assign 1 188 639
get 1 188 639
assign 1 188 640
firstGet 0 188 640
assign 1 189 641
new 0 189 641
assign 1 189 642
get 1 189 642
assign 1 189 643
firstGet 0 189 643
assign 1 190 644
new 0 190 644
assign 1 190 645
get 1 190 645
assign 1 191 646
undef 1 191 651
assign 1 192 652
new 0 192 652
assign 1 194 654
new 0 194 654
assign 1 194 655
get 1 194 655
assign 1 195 656
undef 1 195 661
assign 1 196 662
new 0 196 662
assign 1 198 664
new 0 198 664
assign 1 198 665
get 1 198 665
assign 1 199 666
undef 1 199 671
assign 1 200 672
new 0 200 672
assign 1 202 674
new 0 202 674
assign 1 202 675
get 1 202 675
assign 1 203 676
undef 1 203 681
assign 1 204 682
new 0 204 682
assign 1 206 684
new 0 206 684
assign 1 206 685
get 1 206 685
assign 1 207 686
undef 1 207 691
assign 1 208 692
new 0 208 692
assign 1 210 694
new 0 210 694
assign 1 210 695
get 1 210 695
assign 1 211 696
undef 1 211 701
assign 1 212 702
new 0 212 702
assign 1 214 704
new 0 214 704
assign 1 214 705
get 1 214 705
assign 1 215 706
undef 1 215 711
assign 1 216 712
new 0 216 712
assign 1 218 714
new 0 218 714
assign 1 218 715
get 1 218 715
assign 1 219 716
undef 1 219 721
assign 1 220 722
new 0 220 722
assign 1 222 724
new 0 222 724
assign 1 222 725
get 1 222 725
assign 1 223 726
undef 1 223 731
assign 1 224 732
new 0 224 732
assign 1 226 734
new 0 226 734
assign 1 226 735
get 1 226 735
assign 1 227 736
def 1 227 741
assign 1 228 742
firstGet 0 228 742
assign 1 230 744
new 0 230 744
assign 1 230 745
get 1 230 745
assign 1 231 746
def 1 231 751
assign 1 232 752
firstGet 0 232 752
assign 1 234 755
new 0 234 755
assign 1 236 757
new 0 236 757
assign 1 236 758
new 0 236 758
assign 1 236 759
isTrue 2 236 759
assign 1 237 760
new 0 237 760
assign 1 237 761
new 0 237 761
assign 1 237 762
isTrue 2 237 762
assign 1 238 763
new 0 238 763
assign 1 238 764
isTrue 1 238 764
assign 1 239 765
new 0 239 765
assign 1 239 766
isTrue 1 239 766
assign 1 240 767
new 0 240 767
assign 1 241 768
new 0 241 768
assign 1 241 769
get 1 241 769
assign 1 242 770
def 1 242 775
assign 1 242 776
isEmptyGet 0 242 776
assign 1 242 777
not 0 242 777
assign 1 0 779
assign 1 0 782
assign 1 0 786
assign 1 243 789
iteratorGet 0 0 789
assign 1 243 792
hasNextGet 0 243 792
assign 1 243 794
nextGet 0 243 794
put 1 244 795
assign 1 247 802
new 0 247 802
assign 1 247 803
isTrue 1 247 803
assign 1 248 804
new 0 248 804
assign 1 248 805
isTrue 1 248 805
assign 1 249 806
new 0 249 806
assign 1 249 807
isTrue 1 249 807
assign 1 250 808
new 0 250 808
assign 1 250 809
new 0 250 809
assign 1 250 810
isTrue 2 250 810
assign 1 251 811
new 0 251 811
assign 1 251 812
get 1 251 812
assign 1 252 813
new 0 252 813
assign 1 252 814
new 0 252 814
assign 1 252 815
get 2 252 815
assign 1 252 816
firstGet 0 252 816
assign 1 253 817
new 0 253 817
assign 1 253 818
new 0 253 818
assign 1 253 819
get 2 253 819
assign 1 253 820
firstGet 0 253 820
assign 1 254 821
new 0 254 821
assign 1 254 822
add 1 254 822
assign 1 254 823
new 0 254 823
assign 1 254 824
get 2 254 824
assign 1 254 825
firstGet 0 254 825
assign 1 255 826
new 0 255 826
assign 1 256 827
new 0 256 827
assign 1 257 828
new 0 257 828
assign 1 258 829
new 0 258 829
assign 1 259 830
new 0 259 830
assign 1 262 831
def 1 262 836
assign 1 263 837
firstGet 0 263 837
assign 1 265 840
new 0 265 840
assign 1 272 842
new 0 272 842
assign 1 272 843
add 1 272 843
assign 1 272 844
nameGet 0 272 844
assign 1 272 845
add 1 272 845
assign 1 272 846
get 1 272 846
assign 1 273 847
def 1 273 852
assign 1 274 853
orderedGet 0 274 853
addAll 1 274 854
assign 1 277 856
new 0 277 856
assign 1 277 857
add 1 277 857
assign 1 277 858
get 1 277 858
assign 1 278 859
def 1 278 864
assign 1 279 865
orderedGet 0 279 865
addAll 1 279 866
assign 1 282 868
new 0 282 868
assign 1 283 869
orderedGet 0 283 869
assign 1 283 870
iteratorGet 0 0 870
assign 1 283 873
hasNextGet 0 283 873
assign 1 283 875
nextGet 0 283 875
assign 1 284 876
new 1 284 876
addValue 1 284 877
assign 1 286 883
newlineGet 0 286 883
assign 1 287 884
assign 1 288 885
new 1 288 885
assign 1 290 886
copy 0 290 886
assign 1 291 887
fileGet 0 291 887
assign 1 291 888
existsGet 0 291 888
assign 1 291 889
not 0 291 889
assign 1 292 891
fileGet 0 292 891
makeDirs 0 292 892
assign 1 294 894
def 1 294 899
assign 1 295 900
new 1 295 900
assign 1 295 901
readerGet 0 295 901
assign 1 296 902
open 0 296 902
assign 1 296 903
readString 1 296 903
close 0 297 904
assign 1 303 918
classNameGet 0 303 918
assign 1 304 919
add 1 304 919
assign 1 304 920
new 0 304 920
assign 1 304 921
add 1 304 921
assign 1 304 922
toString 0 304 922
assign 1 304 923
add 1 304 923
assign 1 305 924
add 1 305 924
assign 1 305 925
new 0 305 925
assign 1 305 926
add 1 305 926
assign 1 305 927
toString 0 305 927
assign 1 305 928
add 1 305 928
return 1 306 929
assign 1 310 969
new 0 310 969
assign 1 311 970
classesGet 0 311 970
assign 1 311 971
valueIteratorGet 0 311 971
assign 1 311 974
hasNextGet 0 311 974
assign 1 312 976
nextGet 0 312 976
assign 1 313 977
shouldEmitGet 0 313 977
assign 1 313 978
heldGet 0 313 978
assign 1 313 979
fromFileGet 0 313 979
assign 1 313 980
has 1 313 980
assign 1 314 982
heldGet 0 314 982
assign 1 314 983
namepathGet 0 314 983
assign 1 314 984
toString 0 314 984
put 1 314 985
assign 1 315 986
usedByGet 0 315 986
assign 1 315 987
heldGet 0 315 987
assign 1 315 988
namepathGet 0 315 988
assign 1 315 989
toString 0 315 989
assign 1 315 990
get 1 315 990
assign 1 316 991
def 1 316 996
assign 1 317 997
iteratorGet 0 0 997
assign 1 317 1000
hasNextGet 0 317 1000
assign 1 317 1002
nextGet 0 317 1002
put 1 318 1003
assign 1 321 1010
subClassesGet 0 321 1010
assign 1 321 1011
heldGet 0 321 1011
assign 1 321 1012
namepathGet 0 321 1012
assign 1 321 1013
toString 0 321 1013
assign 1 321 1014
get 1 321 1014
assign 1 322 1015
def 1 322 1020
assign 1 323 1021
iteratorGet 0 0 1021
assign 1 323 1024
hasNextGet 0 323 1024
assign 1 323 1026
nextGet 0 323 1026
put 1 324 1027
assign 1 329 1040
classesGet 0 329 1040
assign 1 329 1041
valueIteratorGet 0 329 1041
assign 1 329 1044
hasNextGet 0 329 1044
assign 1 330 1046
nextGet 0 330 1046
assign 1 331 1047
heldGet 0 331 1047
assign 1 331 1048
heldGet 0 331 1048
assign 1 331 1049
namepathGet 0 331 1049
assign 1 331 1050
toString 0 331 1050
assign 1 331 1051
has 1 331 1051
shouldWriteSet 1 331 1052
assign 1 338 1062
new 0 338 1062
return 1 338 1063
assign 1 342 1077
def 1 342 1082
return 1 343 1083
assign 1 348 1085
def 1 348 1090
assign 1 349 1091
firstGet 0 349 1091
assign 1 350 1092
new 0 350 1092
assign 1 350 1093
equals 1 350 1093
assign 1 351 1095
new 1 351 1095
assign 1 352 1098
new 0 352 1098
assign 1 352 1099
equals 1 352 1099
assign 1 353 1101
new 1 353 1101
assign 1 354 1104
new 0 354 1104
assign 1 354 1105
equals 1 354 1105
assign 1 355 1107
new 1 355 1107
assign 1 357 1110
new 0 357 1110
assign 1 357 1111
new 1 357 1111
throw 1 357 1112
dynConditionsAllSet 1 359 1116
return 1 360 1117
return 1 362 1119
assign 1 367 1216
now 0 367 1216
assign 1 368 1217
new 0 368 1217
assign 1 369 1218
emitterGet 0 369 1218
assign 1 370 1219
def 1 370 1224
assign 1 371 1225
new 4 371 1225
put 1 372 1226
assign 1 374 1228
new 0 374 1228
assign 1 374 1229
add 1 374 1229
print 0 374 1230
assign 1 377 1233
new 0 377 1233
assign 1 379 1234
iteratorGet 0 0 1234
assign 1 379 1237
hasNextGet 0 379 1237
assign 1 379 1239
nextGet 0 379 1239
assign 1 380 1240
has 1 380 1240
assign 1 380 1241
not 0 380 1241
put 1 381 1243
assign 1 382 1244
new 2 382 1244
addValue 1 383 1245
assign 1 386 1252
iteratorGet 0 0 1252
assign 1 386 1255
hasNextGet 0 386 1255
assign 1 386 1257
nextGet 0 386 1257
assign 1 387 1258
has 1 387 1258
assign 1 387 1259
not 0 387 1259
put 1 388 1261
assign 1 389 1262
new 2 389 1262
addValue 1 390 1263
assign 1 391 1264
libNameGet 0 391 1264
put 1 391 1265
assign 1 396 1273
iteratorGet 0 396 1273
assign 1 396 1276
hasNextGet 0 396 1276
assign 1 397 1278
nextGet 0 397 1278
doParse 1 399 1279
buildSyns 1 401 1285
assign 1 404 1287
now 0 404 1287
assign 1 404 1288
subtract 1 404 1288
assign 1 406 1290
new 0 406 1290
assign 1 406 1291
add 1 406 1291
print 0 406 1292
assign 1 408 1294
emitCommonGet 0 408 1294
assign 1 408 1295
def 1 408 1300
assign 1 410 1301
emitCommonGet 0 410 1301
doEmit 0 410 1302
assign 1 411 1303
new 0 411 1303
return 1 411 1304
setClassesToWrite 0 414 1307
libnameInfoGet 0 415 1308
assign 1 417 1309
classesGet 0 417 1309
assign 1 417 1310
valueIteratorGet 0 417 1310
assign 1 417 1313
hasNextGet 0 417 1313
assign 1 418 1315
nextGet 0 418 1315
doEmit 1 419 1316
emitMain 0 421 1322
emitCUInit 0 422 1323
assign 1 423 1324
classesGet 0 423 1324
assign 1 423 1325
valueIteratorGet 0 423 1325
assign 1 423 1328
hasNextGet 0 423 1328
assign 1 424 1330
nextGet 0 424 1330
emitSyn 1 425 1331
assign 1 429 1338
now 0 429 1338
assign 1 429 1339
subtract 1 429 1339
assign 1 430 1340
def 1 430 1345
assign 1 431 1346
new 0 431 1346
assign 1 431 1347
add 1 431 1347
print 0 431 1348
assign 1 433 1350
new 0 433 1350
assign 1 433 1351
add 1 433 1351
print 0 433 1352
prepMake 1 436 1354
assign 1 440 1357
not 0 440 1357
make 1 441 1359
deployLibrary 1 442 1360
assign 1 444 1362
iteratorGet 0 0 1362
assign 1 444 1365
hasNextGet 0 444 1365
assign 1 444 1367
nextGet 0 444 1367
assign 1 445 1368
libnameInfoGet 0 445 1368
assign 1 445 1369
unitShlibGet 0 445 1369
assign 1 446 1370
emitPathGet 0 446 1370
assign 1 446 1371
copy 0 446 1371
assign 1 447 1372
stepsGet 0 447 1372
assign 1 447 1373
lastGet 0 447 1373
addStep 1 447 1374
assign 1 448 1375
fileGet 0 448 1375
assign 1 448 1376
existsGet 0 448 1376
assign 1 449 1378
fileGet 0 449 1378
delete 0 449 1379
assign 1 451 1381
fileGet 0 451 1381
assign 1 451 1382
existsGet 0 451 1382
assign 1 451 1383
not 0 451 1383
assign 1 452 1385
fileGet 0 452 1385
assign 1 452 1386
fileGet 0 452 1386
deployFile 2 452 1387
assign 1 456 1395
iteratorGet 0 456 1395
assign 1 457 1396
iteratorGet 0 457 1396
assign 1 459 1399
hasNextGet 0 459 1399
assign 1 459 1401
hasNextGet 0 459 1401
assign 1 0 1403
assign 1 0 1406
assign 1 0 1410
assign 1 460 1413
nextGet 0 460 1413
assign 1 460 1414
apNew 1 460 1414
assign 1 461 1415
emitPathGet 0 461 1415
assign 1 461 1416
copy 0 461 1416
assign 1 461 1417
toString 0 461 1417
assign 1 461 1418
new 0 461 1418
assign 1 461 1419
add 1 461 1419
assign 1 461 1420
nextGet 0 461 1420
assign 1 461 1421
add 1 461 1421
assign 1 461 1422
apNew 1 461 1422
assign 1 463 1423
fileGet 0 463 1423
assign 1 463 1424
existsGet 0 463 1424
assign 1 464 1426
fileGet 0 464 1426
delete 0 464 1427
assign 1 466 1429
fileGet 0 466 1429
assign 1 466 1430
existsGet 0 466 1430
assign 1 466 1431
not 0 466 1431
assign 1 467 1433
fileGet 0 467 1433
assign 1 467 1434
fileGet 0 467 1434
deployFile 2 467 1435
assign 1 472 1444
now 0 472 1444
assign 1 472 1445
subtract 1 472 1445
assign 1 474 1446
def 1 474 1451
assign 1 475 1452
new 0 475 1452
assign 1 475 1453
add 1 475 1453
print 0 475 1454
assign 1 477 1456
def 1 477 1461
assign 1 478 1462
new 0 478 1462
assign 1 478 1463
add 1 478 1463
print 0 478 1464
assign 1 480 1466
def 1 480 1471
assign 1 481 1472
new 0 481 1472
assign 1 481 1473
add 1 481 1473
print 0 481 1474
assign 1 485 1477
new 0 485 1477
print 0 485 1478
assign 1 486 1479
run 2 486 1479
assign 1 487 1480
new 0 487 1480
assign 1 487 1481
add 1 487 1481
assign 1 487 1482
new 0 487 1482
assign 1 487 1483
add 1 487 1483
print 0 487 1484
return 1 488 1485
assign 1 490 1487
new 0 490 1487
return 1 490 1488
assign 1 494 1501
justParsedGet 0 494 1501
assign 1 494 1502
valueIteratorGet 0 494 1502
assign 1 494 1505
hasNextGet 0 494 1505
assign 1 495 1507
nextGet 0 495 1507
assign 1 496 1508
heldGet 0 496 1508
libNameSet 1 496 1509
assign 1 497 1510
getSyn 2 497 1510
libNameSet 1 498 1511
assign 1 500 1517
justParsedGet 0 500 1517
assign 1 500 1518
valueIteratorGet 0 500 1518
assign 1 500 1521
hasNextGet 0 500 1521
assign 1 501 1523
nextGet 0 501 1523
assign 1 502 1524
heldGet 0 502 1524
assign 1 502 1525
synGet 0 502 1525
checkInheritance 2 503 1526
integrate 1 504 1527
assign 1 506 1533
new 0 506 1533
justParsedSet 1 506 1534
assign 1 510 1562
heldGet 0 510 1562
assign 1 510 1563
synGet 0 510 1563
assign 1 510 1564
def 1 510 1569
assign 1 511 1570
heldGet 0 511 1570
assign 1 511 1571
synGet 0 511 1571
return 1 511 1572
assign 1 513 1574
heldGet 0 513 1574
libNameSet 1 513 1575
assign 1 514 1576
heldGet 0 514 1576
assign 1 514 1577
extendsGet 0 514 1577
assign 1 514 1578
undef 1 514 1583
assign 1 515 1584
new 1 515 1584
assign 1 517 1587
classesGet 0 517 1587
assign 1 517 1588
heldGet 0 517 1588
assign 1 517 1589
extendsGet 0 517 1589
assign 1 517 1590
toString 0 517 1590
assign 1 517 1591
get 1 517 1591
assign 1 519 1592
def 1 519 1597
assign 1 520 1598
heldGet 0 520 1598
libNameSet 1 520 1599
assign 1 521 1600
getSyn 2 521 1600
assign 1 524 1603
heldGet 0 524 1603
assign 1 524 1604
extendsGet 0 524 1604
assign 1 524 1605
loadSyn 1 524 1605
assign 1 526 1607
new 2 526 1607
assign 1 528 1609
heldGet 0 528 1609
synSet 1 528 1610
assign 1 529 1611
heldGet 0 529 1611
assign 1 529 1612
namepathGet 0 529 1612
assign 1 529 1613
toString 0 529 1613
addSynClass 2 529 1614
return 1 530 1615
assign 1 534 1623
toString 0 534 1623
assign 1 535 1624
synClassesGet 0 535 1624
assign 1 535 1625
get 1 535 1625
assign 1 536 1626
def 1 536 1631
return 1 537 1632
assign 1 543 1634
emitterGet 0 543 1634
assign 1 543 1635
loadSyn 1 543 1635
addSynClass 2 544 1636
return 1 545 1637
assign 1 552 1641
undef 1 552 1646
assign 1 553 1647
new 1 553 1647
return 1 555 1649
assign 1 560 1728
new 1 560 1728
assign 1 561 1729
new 0 561 1729
assign 1 562 1730
emitterGet 0 562 1730
assign 1 563 1731
assign 1 564 1732
new 0 564 1732
assign 1 565 1733
shouldEmitGet 0 565 1733
put 1 565 1734
assign 1 0 1737
assign 1 0 1741
assign 1 0 1744
assign 1 568 1748
new 0 568 1748
assign 1 568 1749
toString 0 568 1749
assign 1 568 1750
add 1 568 1750
print 0 568 1751
assign 1 570 1753
assign 1 572 1754
fileGet 0 572 1754
assign 1 572 1755
readerGet 0 572 1755
assign 1 572 1756
open 0 572 1756
assign 1 572 1757
readBuffer 1 572 1757
assign 1 573 1758
fileGet 0 573 1758
assign 1 573 1759
readerGet 0 573 1759
close 0 573 1760
assign 1 574 1761
tokenize 1 574 1761
assign 1 582 1763
new 0 582 1763
echo 0 582 1764
assign 1 584 1766
outermostGet 0 584 1766
nodify 2 584 1767
assign 1 586 1769
new 0 586 1769
print 0 586 1770
assign 1 587 1771
new 2 587 1771
traverse 1 587 1772
assign 1 591 1775
new 0 591 1775
echo 0 591 1776
assign 1 593 1778
new 0 593 1778
traverse 1 593 1779
assign 1 595 1781
new 0 595 1781
print 0 595 1782
assign 1 596 1783
new 2 596 1783
traverse 1 596 1784
assign 1 599 1787
new 0 599 1787
echo 0 599 1788
assign 1 602 1790
new 0 602 1790
traverse 1 602 1791
contain 0 603 1792
assign 1 605 1794
new 0 605 1794
print 0 605 1795
assign 1 606 1796
new 2 606 1796
traverse 1 606 1797
assign 1 610 1800
new 0 610 1800
echo 0 610 1801
assign 1 612 1803
new 0 612 1803
traverse 1 612 1804
assign 1 614 1806
new 0 614 1806
print 0 614 1807
assign 1 615 1808
new 2 615 1808
traverse 1 615 1809
assign 1 619 1812
new 0 619 1812
echo 0 619 1813
assign 1 621 1815
new 0 621 1815
traverse 1 621 1816
assign 1 623 1818
new 0 623 1818
print 0 623 1819
assign 1 624 1820
new 2 624 1820
traverse 1 624 1821
assign 1 628 1824
new 0 628 1824
echo 0 628 1825
assign 1 630 1827
new 0 630 1827
traverse 1 630 1828
assign 1 632 1830
new 0 632 1830
print 0 632 1831
assign 1 633 1832
new 2 633 1832
traverse 1 633 1833
assign 1 637 1836
new 0 637 1836
echo 0 637 1837
assign 1 639 1839
new 0 639 1839
traverse 1 639 1840
assign 1 641 1842
new 0 641 1842
print 0 641 1843
assign 1 642 1844
new 2 642 1844
traverse 1 642 1845
assign 1 646 1848
new 0 646 1848
echo 0 646 1849
assign 1 648 1851
new 0 648 1851
traverse 1 648 1852
assign 1 650 1854
new 0 650 1854
print 0 650 1855
assign 1 651 1856
new 2 651 1856
traverse 1 651 1857
assign 1 655 1860
new 0 655 1860
echo 0 655 1861
assign 1 657 1863
new 0 657 1863
traverse 1 657 1864
assign 1 659 1866
new 0 659 1866
print 0 659 1867
assign 1 660 1868
new 2 660 1868
traverse 1 660 1869
assign 1 664 1872
new 0 664 1872
echo 0 664 1873
assign 1 666 1875
new 0 666 1875
traverse 1 666 1876
assign 1 668 1878
new 0 668 1878
print 0 668 1879
assign 1 669 1880
new 2 669 1880
traverse 1 669 1881
assign 1 672 1884
new 0 672 1884
echo 0 672 1885
assign 1 674 1887
new 0 674 1887
traverse 1 674 1888
assign 1 676 1890
new 0 676 1890
print 0 676 1891
assign 1 677 1892
new 2 677 1892
traverse 1 677 1893
assign 1 681 1896
new 0 681 1896
echo 0 681 1897
assign 1 682 1898
new 0 682 1898
print 0 682 1899
assign 1 684 1901
new 0 684 1901
traverse 1 684 1902
assign 1 0 1904
assign 1 0 1908
assign 1 0 1911
assign 1 686 1915
new 0 686 1915
print 0 686 1916
assign 1 687 1917
new 2 687 1917
traverse 1 687 1918
assign 1 689 1920
classesGet 0 689 1920
assign 1 689 1921
valueIteratorGet 0 689 1921
assign 1 689 1924
hasNextGet 0 689 1924
assign 1 690 1926
nextGet 0 690 1926
assign 1 692 1927
transUnitGet 0 692 1927
assign 1 693 1928
new 1 693 1928
assign 1 694 1929
TRANSUNITGet 0 694 1929
typenameSet 1 694 1930
assign 1 695 1931
new 0 695 1931
assign 1 696 1932
heldGet 0 696 1932
assign 1 696 1933
emitsGet 0 696 1933
emitsSet 1 696 1934
heldSet 1 697 1935
delete 0 698 1936
addValue 1 699 1937
copyLoc 1 700 1938
reInitContained 0 706 1960
assign 1 707 1961
containedGet 0 707 1961
assign 1 708 1962
new 0 708 1962
assign 1 709 1963
new 0 709 1963
assign 1 709 1964
crGet 0 709 1964
assign 1 710 1965
iteratorGet 0 710 1965
assign 1 710 1968
hasNextGet 0 710 1968
assign 1 711 1970
new 1 711 1970
assign 1 712 1971
nextGet 0 712 1971
heldSet 1 712 1972
nlcSet 1 713 1973
assign 1 714 1974
heldGet 0 714 1974
assign 1 714 1975
equals 1 714 1975
assign 1 715 1977
increment 0 715 1977
assign 1 717 1979
heldGet 0 717 1979
assign 1 717 1980
notEquals 1 717 1980
addValue 1 718 1982
containerSet 1 719 1983
return 1 0 1993
assign 1 0 1996
return 1 0 2000
assign 1 0 2003
return 1 0 2007
assign 1 0 2010
return 1 0 2014
assign 1 0 2017
return 1 0 2021
assign 1 0 2024
return 1 0 2028
assign 1 0 2031
return 1 0 2035
assign 1 0 2038
return 1 0 2042
assign 1 0 2045
return 1 0 2049
assign 1 0 2052
return 1 0 2056
assign 1 0 2059
return 1 0 2063
assign 1 0 2066
return 1 0 2070
assign 1 0 2073
return 1 0 2077
assign 1 0 2080
return 1 0 2084
assign 1 0 2087
return 1 0 2091
assign 1 0 2094
return 1 0 2098
assign 1 0 2101
return 1 0 2105
assign 1 0 2108
return 1 0 2112
assign 1 0 2115
return 1 0 2119
assign 1 0 2122
return 1 0 2126
assign 1 0 2129
return 1 0 2133
assign 1 0 2136
return 1 0 2140
assign 1 0 2143
return 1 0 2147
assign 1 0 2150
return 1 0 2154
assign 1 0 2157
return 1 0 2161
assign 1 0 2164
return 1 0 2168
assign 1 0 2171
return 1 0 2175
assign 1 0 2178
return 1 0 2182
assign 1 0 2185
return 1 0 2189
assign 1 0 2192
return 1 0 2196
assign 1 0 2199
return 1 0 2203
assign 1 0 2206
return 1 0 2210
assign 1 0 2213
return 1 0 2217
assign 1 0 2220
return 1 0 2224
assign 1 0 2227
return 1 0 2231
assign 1 0 2234
return 1 0 2238
assign 1 0 2241
return 1 0 2245
assign 1 0 2248
return 1 0 2252
assign 1 0 2255
return 1 0 2259
assign 1 0 2262
return 1 0 2266
assign 1 0 2269
return 1 0 2273
assign 1 0 2276
return 1 0 2280
assign 1 0 2283
return 1 0 2287
assign 1 0 2290
return 1 0 2294
assign 1 0 2297
return 1 0 2301
assign 1 0 2304
return 1 0 2308
assign 1 0 2311
return 1 0 2315
assign 1 0 2318
return 1 0 2322
assign 1 0 2325
return 1 0 2329
assign 1 0 2332
return 1 0 2336
assign 1 0 2339
return 1 0 2343
assign 1 0 2346
return 1 0 2350
assign 1 0 2353
return 1 0 2357
assign 1 0 2360
return 1 0 2364
assign 1 0 2367
return 1 0 2371
assign 1 0 2374
return 1 0 2378
assign 1 0 2381
return 1 0 2385
assign 1 0 2388
return 1 0 2392
assign 1 0 2395
return 1 0 2399
assign 1 0 2402
return 1 0 2406
assign 1 0 2409
return 1 0 2413
assign 1 0 2416
return 1 0 2420
assign 1 0 2423
return 1 0 2427
assign 1 0 2430
return 1 0 2434
assign 1 0 2437
return 1 0 2441
assign 1 0 2444
return 1 0 2448
assign 1 0 2451
return 1 0 2455
assign 1 0 2458
assign 1 0 2462
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 404051026: return bem_printPlacesGet_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 902949587: return bem_printStepsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 392968773: return bem_printPlacesSet_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 891867334: return bem_printStepsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_9_5_ContainerArray) bevd_0);
case 593264218: return bem_isNewish_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_BuildBuild.bevs_inst = (BEC_5_5_BuildBuild)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_BuildBuild.bevs_inst;
}
}
