package be.BEL_4_Base;
/* IO:File: source/build/Build.be */
public class BEC_5_5_BuildBuild extends BEC_6_6_SystemObject {
public BEC_5_5_BuildBuild() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bels_1 = {0x6E,0x65,0x77};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_1, 3));
private static byte[] bels_2 = {0x4E,0x65,0x77};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_2, 3));
private static byte[] bels_3 = {0x2F};
private static byte[] bels_4 = {0x5C};
private static byte[] bels_5 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_6 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_4_6_TextString bevo_2 = (new BEC_4_6_TextString(bels_7, 28));
private static byte[] bels_8 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bels_9 = {0x23,0x69,0x66,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_3 = (new BEC_4_6_TextString(bels_9, 12));
private static byte[] bels_10 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x65,0x78,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_4 = (new BEC_4_6_TextString(bels_10, 21));
private static byte[] bels_11 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_5 = (new BEC_4_6_TextString(bels_11, 6));
private static byte[] bels_12 = {0x23,0x69,0x66,0x6E,0x64,0x65,0x66,0x20,0x42,0x45,0x4E,0x43,0x5F};
private static BEC_4_6_TextString bevo_6 = (new BEC_4_6_TextString(bels_12, 13));
private static byte[] bels_13 = {0x5F,0x5F,0x64,0x65,0x63,0x6C,0x73,0x70,0x65,0x63,0x28,0x64,0x6C,0x6C,0x69,0x6D,0x70,0x6F,0x72,0x74,0x29};
private static BEC_4_6_TextString bevo_7 = (new BEC_4_6_TextString(bels_13, 21));
private static byte[] bels_14 = {0x23,0x65,0x6E,0x64,0x69,0x66};
private static BEC_4_6_TextString bevo_8 = (new BEC_4_6_TextString(bels_14, 6));
private static byte[] bels_15 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bels_16 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_4_6_TextString bevo_9 = (new BEC_4_6_TextString(bels_16, 5));
private static byte[] bels_17 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_18 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_19 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bels_20 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bels_21 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_22 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_23 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bels_24 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_25 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_26 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bels_27 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bels_29 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bels_30 = {0x74,0x72,0x75,0x65};
private static byte[] bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bels_51 = {0x72,0x75,0x6E};
private static byte[] bels_52 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bels_53 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bels_54 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bels_55 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bels_56 = {0x67,0x63,0x63};
private static byte[] bels_57 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bels_59 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_4_6_TextString bevo_10 = (new BEC_4_6_TextString(bels_59, 9));
private static byte[] bels_60 = {};
private static byte[] bels_61 = {0x63};
private static byte[] bels_62 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_4_6_TextString bevo_11 = (new BEC_4_6_TextString(bels_62, 8));
private static byte[] bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_4_6_TextString bevo_12 = (new BEC_4_6_TextString(bels_63, 7));
private static byte[] bels_64 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_65 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bels_66 = {0x6A,0x76};
private static BEC_4_6_TextString bevo_13 = (new BEC_4_6_TextString(bels_66, 2));
private static byte[] bels_67 = {0x63,0x73};
private static BEC_4_6_TextString bevo_14 = (new BEC_4_6_TextString(bels_67, 2));
private static byte[] bels_68 = {0x6A,0x73};
private static BEC_4_6_TextString bevo_15 = (new BEC_4_6_TextString(bels_68, 2));
private static byte[] bels_69 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bels_70 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_4_6_TextString bevo_16 = (new BEC_4_6_TextString(bels_70, 19));
private static byte[] bels_71 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_17 = (new BEC_4_6_TextString(bels_71, 31));
private static byte[] bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_18 = (new BEC_4_6_TextString(bels_72, 31));
private static byte[] bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_19 = (new BEC_4_6_TextString(bels_73, 41));
private static byte[] bels_74 = {0x2F};
private static BEC_4_6_TextString bevo_20 = (new BEC_4_6_TextString(bels_74, 1));
private static byte[] bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_21 = (new BEC_4_6_TextString(bels_75, 31));
private static byte[] bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_22 = (new BEC_4_6_TextString(bels_76, 41));
private static byte[] bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_4_6_TextString bevo_23 = (new BEC_4_6_TextString(bels_77, 51));
private static byte[] bels_78 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_24 = (new BEC_4_6_TextString(bels_78, 14));
private static byte[] bels_79 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_4_6_TextString bevo_25 = (new BEC_4_6_TextString(bels_79, 19));
private static byte[] bels_80 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_4_6_TextString bevo_26 = (new BEC_4_6_TextString(bels_80, 9));
private static byte[] bels_81 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_4_6_TextString bevo_27 = (new BEC_4_6_TextString(bels_81, 13));
private static byte[] bels_82 = {0x2E,0x20};
private static BEC_4_6_TextString bevo_28 = (new BEC_4_6_TextString(bels_82, 2));
private static byte[] bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_4_6_TextString bevo_29 = (new BEC_4_6_TextString(bels_83, 22));
private static byte[] bels_84 = {0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_30 = (new BEC_4_6_TextString(bels_84, 3));
private static byte[] bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_4_6_TextString bevo_31 = (new BEC_4_6_TextString(bels_85, 15));
private static byte[] bels_86 = {0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_32 = (new BEC_4_6_TextString(bels_86, 4));
private static byte[] bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_4_6_TextString bevo_33 = (new BEC_4_6_TextString(bels_87, 15));
private static byte[] bels_88 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_34 = (new BEC_4_6_TextString(bels_88, 5));
private static byte[] bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_4_6_TextString bevo_35 = (new BEC_4_6_TextString(bels_89, 15));
private static byte[] bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_36 = (new BEC_4_6_TextString(bels_90, 6));
private static byte[] bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_4_6_TextString bevo_37 = (new BEC_4_6_TextString(bels_91, 15));
private static byte[] bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_38 = (new BEC_4_6_TextString(bels_92, 7));
private static byte[] bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_4_6_TextString bevo_39 = (new BEC_4_6_TextString(bels_93, 15));
private static byte[] bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_40 = (new BEC_4_6_TextString(bels_94, 8));
private static byte[] bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_4_6_TextString bevo_41 = (new BEC_4_6_TextString(bels_95, 15));
private static byte[] bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_42 = (new BEC_4_6_TextString(bels_96, 9));
private static byte[] bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_4_6_TextString bevo_43 = (new BEC_4_6_TextString(bels_97, 15));
private static byte[] bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_44 = (new BEC_4_6_TextString(bels_98, 10));
private static byte[] bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_4_6_TextString bevo_45 = (new BEC_4_6_TextString(bels_99, 15));
private static byte[] bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_46 = (new BEC_4_6_TextString(bels_100, 11));
private static byte[] bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_4_6_TextString bevo_47 = (new BEC_4_6_TextString(bels_101, 16));
private static byte[] bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_48 = (new BEC_4_6_TextString(bels_102, 12));
private static byte[] bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_4_6_TextString bevo_49 = (new BEC_4_6_TextString(bels_103, 16));
private static byte[] bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_4_6_TextString bevo_50 = (new BEC_4_6_TextString(bels_104, 13));
private static byte[] bels_105 = {0x20};
private static BEC_4_6_TextString bevo_51 = (new BEC_4_6_TextString(bels_105, 1));
private static byte[] bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_4_6_TextString bevo_52 = (new BEC_4_6_TextString(bels_106, 16));
public static BEC_5_5_BuildBuild bevs_inst;
public BEC_4_6_TextString bevp_mainName;
public BEC_4_6_TextString bevp_libName;
public BEC_4_6_TextString bevp_exeName;
public BEC_6_6_SystemObject bevp_emitFileHeader;
public BEC_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_9_10_ContainerLinkedList bevp_extLibs;
public BEC_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_platform;
public BEC_6_6_SystemObject bevp_outputPlatform;
public BEC_6_6_SystemObject bevp_emitLibrary;
public BEC_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_4_6_TextString bevp_nl;
public BEC_4_6_TextString bevp_newline;
public BEC_6_6_SystemObject bevp_runArgs;
public BEC_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_9_5_ContainerArray bevp_args;
public BEC_6_10_SystemParameters bevp_params;
public BEC_5_4_LogicBool bevp_buildSucceeded;
public BEC_4_6_TextString bevp_buildMessage;
public BEC_4_8_TimeInterval bevp_startTime;
public BEC_4_8_TimeInterval bevp_parseTime;
public BEC_4_8_TimeInterval bevp_parseEmitTime;
public BEC_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_2_4_4_IOFilePath bevp_buildPath;
public BEC_6_6_SystemObject bevp_includePath;
public BEC_9_3_ContainerMap bevp_built;
public BEC_9_10_ContainerLinkedList bevp_toBuild;
public BEC_5_4_LogicBool bevp_printSteps;
public BEC_5_4_LogicBool bevp_printPlaces;
public BEC_5_4_LogicBool bevp_printAst;
public BEC_5_4_LogicBool bevp_printAllAst;
public BEC_9_3_ContainerSet bevp_printAstElements;
public BEC_5_4_LogicBool bevp_doEmit;
public BEC_5_4_LogicBool bevp_emitDebug;
public BEC_5_4_LogicBool bevp_parse;
public BEC_5_4_LogicBool bevp_prepMake;
public BEC_5_4_LogicBool bevp_make;
public BEC_5_4_LogicBool bevp_genOnly;
public BEC_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_5_8_BuildEmitData bevp_emitData;
public BEC_2_4_4_IOFilePath bevp_emitPath;
public BEC_6_6_SystemObject bevp_code;
public BEC_4_6_TextString bevp_estr;
public BEC_6_6_SystemObject bevp_sharedEmitter;
public BEC_5_9_BuildConstants bevp_constants;
public BEC_5_9_BuildNodeTypes bevp_ntypes;
public BEC_4_9_TextTokenizer bevp_twtok;
public BEC_4_9_TextTokenizer bevp_lctok;
public BEC_5_7_BuildLibrary bevp_deployLibrary;
public BEC_4_6_TextString bevp_deployPath;
public BEC_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_9_3_ContainerSet bevp_closeLibraries;
public BEC_5_4_LogicBool bevp_run;
public BEC_4_6_TextString bevp_compiler;
public BEC_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_4_6_TextString bevp_makeName;
public BEC_4_6_TextString bevp_makeArgs;
public BEC_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_5_4_LogicBool bevp_dynConditionsAll;
public BEC_5_4_LogicBool bevp_ownProcess;
public BEC_4_6_TextString bevp_readBuffer;
public BEC_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
bevp_built = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_parse = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_make = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_genOnly = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(3, bels_0));
bevp_lctok = (new BEC_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpvar_phold);
bevp_usedLibrarys = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_4_6_TextString()).bem_new_1(bevt_1_tmpvar_phold);
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isNewish_1(BEC_4_6_TextString beva_name) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (beva_name == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = beva_name.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_5_tmpvar_phold = bevo_1;
bevt_4_tmpvar_phold = beva_name.bem_ends_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
 else  /* Line: 104 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 104 */ {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_6_tmpvar_phold;
} /* Line: 105 */
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_7_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_process_1(BEC_4_6_TextString beva_arg) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(1, bels_3));
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(1, bels_4));
bevt_0_tmpvar_phold = beva_arg.bem_swap_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_main_0() throws Throwable {
BEC_9_5_ContainerArray bevl__args = null;
BEC_6_7_SystemProcess bevt_0_tmpvar_phold = null;
BEC_6_7_SystemProcess bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst;
bevl__args = bevt_0_tmpvar_phold.bem_argsGet_0();
bevt_1_tmpvar_phold = (BEC_6_7_SystemProcess) BEC_6_7_SystemProcess.bevs_inst;
bevt_2_tmpvar_phold = this.bem_main_1(bevl__args);
bevt_1_tmpvar_phold.bem_exit_1((BEC_4_3_MathInt) bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_main_1(BEC_9_5_ContainerArray beva__args) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_0_tmpvar_phold = this.bem_go_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_go_0() throws Throwable {
BEC_4_3_MathInt bevl_whatResult = null;
BEC_5_4_LogicBool bevl_buildFailed = null;
BEC_6_6_SystemObject bevl_e = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevl_whatResult = (new BEC_4_3_MathInt(1));
this.bem_config_0();
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolFalse;
try  /* Line: 129 */ {
bevp_buildMessage = (new BEC_4_6_TextString(16, bels_5));
bevl_whatResult = this.bem_doWhat_0();
bevp_buildMessage = (new BEC_4_6_TextString(14, bels_6));
} /* Line: 132 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_4_6_TextString) bevl_e.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_buildFailed = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_1_tmpvar_phold = bevo_2;
bevp_buildMessage = bevt_1_tmpvar_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_4_3_MathInt(1));
} /* Line: 137 */
if (bevp_printSteps.bevi_bool) /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 139 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 139 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 140 */
return bevl_whatResult;
} /*method end*/
public BEC_4_6_TextString bem_dllhead_1(BEC_4_6_TextString beva_addTo) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(5, bels_8));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 146 */ {
bevt_5_tmpvar_phold = bevo_3;
bevt_4_tmpvar_phold = beva_addTo.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_3_tmpvar_phold.bem_add_1(bevp_nl);
bevt_7_tmpvar_phold = bevo_4;
bevt_6_tmpvar_phold = beva_addTo.bem_add_1(bevt_7_tmpvar_phold);
beva_addTo = bevt_6_tmpvar_phold.bem_add_1(bevp_nl);
bevt_9_tmpvar_phold = bevo_5;
bevt_8_tmpvar_phold = beva_addTo.bem_add_1(bevt_9_tmpvar_phold);
beva_addTo = bevt_8_tmpvar_phold.bem_add_1(bevp_nl);
bevt_12_tmpvar_phold = bevo_6;
bevt_11_tmpvar_phold = beva_addTo.bem_add_1(bevt_12_tmpvar_phold);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_libName);
beva_addTo = bevt_10_tmpvar_phold.bem_add_1(bevp_nl);
bevt_14_tmpvar_phold = bevo_7;
bevt_13_tmpvar_phold = beva_addTo.bem_add_1(bevt_14_tmpvar_phold);
beva_addTo = bevt_13_tmpvar_phold.bem_add_1(bevp_nl);
bevt_16_tmpvar_phold = bevo_8;
bevt_15_tmpvar_phold = beva_addTo.bem_add_1(bevt_16_tmpvar_phold);
beva_addTo = bevt_15_tmpvar_phold.bem_add_1(bevp_nl);
} /* Line: 152 */
return beva_addTo;
} /*method end*/
public BEC_6_6_SystemObject bem_config_0() throws Throwable {
BEC_4_6_TextString bevl_istr = null;
BEC_9_3_ContainerSet bevl_bfiles = null;
BEC_4_6_TextString bevl_bkey = null;
BEC_9_10_ContainerLinkedList bevl_pacm = null;
BEC_4_6_TextString bevl_pa = null;
BEC_4_6_TextString bevl_outLang = null;
BEC_6_6_SystemObject bevl_platformSources = null;
BEC_6_6_SystemObject bevl_langSources = null;
BEC_6_6_SystemObject bevl_emr = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_5_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_IOFile bevt_10_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_13_tmpvar_phold = null;
BEC_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_15_tmpvar_phold = null;
BEC_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_19_tmpvar_phold = null;
BEC_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_IOFile bevt_21_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_23_tmpvar_phold = null;
BEC_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_IOFile bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_29_tmpvar_phold = null;
BEC_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_6_15_SystemCurrentPlatform bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_4_6_TextString bevt_48_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_49_tmpvar_phold = null;
BEC_4_6_TextString bevt_50_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_4_6_TextString bevt_59_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_4_6_TextString bevt_61_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_4_6_TextString bevt_67_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_74_tmpvar_phold = null;
BEC_4_6_TextString bevt_75_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_82_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_83_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_84_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_4_6_TextString bevt_86_tmpvar_phold = null;
BEC_4_6_TextString bevt_87_tmpvar_phold = null;
BEC_4_6_TextString bevt_88_tmpvar_phold = null;
BEC_4_6_TextString bevt_89_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_4_6_TextString bevt_91_tmpvar_phold = null;
BEC_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_93_tmpvar_phold = null;
BEC_4_6_TextString bevt_94_tmpvar_phold = null;
BEC_4_6_TextString bevt_95_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_96_tmpvar_phold = null;
BEC_4_6_TextString bevt_97_tmpvar_phold = null;
BEC_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_9_10_ContainerLinkedList bevt_99_tmpvar_phold = null;
BEC_4_6_TextString bevt_100_tmpvar_phold = null;
BEC_4_6_TextString bevt_101_tmpvar_phold = null;
BEC_4_6_TextString bevt_102_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_103_tmpvar_phold = null;
BEC_4_6_TextString bevt_104_tmpvar_phold = null;
BEC_4_6_TextString bevt_105_tmpvar_phold = null;
BEC_4_6_TextString bevt_106_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_107_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_108_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_109_tmpvar_phold = null;
BEC_4_6_TextString bevt_110_tmpvar_phold = null;
BEC_4_6_TextString bevt_111_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_112_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_113_tmpvar_phold = null;
BEC_9_5_ContainerArray bevt_114_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_116_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_117_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_4_IOFile bevt_119_tmpvar_phold = null;
BEC_2_4_IOFile bevt_120_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_121_tmpvar_phold = null;
BEC_2_4_IOFile bevt_122_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_123_tmpvar_phold = null;
bevl_bfiles = (new BEC_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_4_6_TextString(9, bels_15));
bevt_5_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpvar_phold == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_6_tmpvar_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpvar_loop = bevt_6_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 163 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 163 */ {
bevl_istr = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_bfiles.bem_has_1(bevl_istr);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_not_0();
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 164 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpvar_phold);
} /* Line: 166 */
} /* Line: 164 */
 else  /* Line: 163 */ {
break;
} /* Line: 163 */
} /* Line: 163 */
} /* Line: 163 */
bevt_13_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_nameGet_0();
bevt_14_tmpvar_phold = bevo_9;
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_equals_1(bevt_14_tmpvar_phold);
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 171 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 172 */
bevt_16_tmpvar_phold = (new BEC_4_6_TextString(11, bels_17));
bevt_15_tmpvar_phold = bevp_params.bem_get_1(bevt_16_tmpvar_phold);
bevp_libName = (BEC_4_6_TextString) bevt_15_tmpvar_phold.bem_firstGet_0();
bevt_18_tmpvar_phold = (new BEC_4_6_TextString(7, bels_18));
bevt_17_tmpvar_phold = bevp_params.bem_has_1(bevt_18_tmpvar_phold);
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 175 */ {
bevt_20_tmpvar_phold = (new BEC_4_6_TextString(7, bels_19));
bevt_19_tmpvar_phold = bevp_params.bem_get_1(bevt_20_tmpvar_phold);
bevp_exeName = (BEC_4_6_TextString) bevt_19_tmpvar_phold.bem_firstGet_0();
} /* Line: 176 */
 else  /* Line: 177 */ {
bevp_exeName = bevp_libName;
} /* Line: 178 */
bevt_24_tmpvar_phold = (new BEC_4_6_TextString(9, bels_20));
bevt_25_tmpvar_phold = (new BEC_4_6_TextString(6, bels_21));
bevt_23_tmpvar_phold = bevp_params.bem_get_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_firstGet_0();
bevt_21_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_22_tmpvar_phold);
bevp_buildPath = bevt_21_tmpvar_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpvar_phold = (new BEC_4_6_TextString(6, bels_22));
bevp_buildPath.bem_addStep_1(bevt_26_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_4_6_TextString(11, bels_23));
bevt_31_tmpvar_phold = (new BEC_4_6_TextString(7, bels_24));
bevt_29_tmpvar_phold = bevp_params.bem_get_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_firstGet_0();
bevt_27_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevt_28_tmpvar_phold);
bevp_includePath = bevt_27_tmpvar_phold.bem_pathGet_0();
bevt_34_tmpvar_phold = (new BEC_4_6_TextString(8, bels_25));
bevt_36_tmpvar_phold = (BEC_6_15_SystemCurrentPlatform) BEC_6_15_SystemCurrentPlatform.bevs_inst.bem_new_0();
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bem_nameGet_0();
bevt_33_tmpvar_phold = bevp_params.bem_get_2(bevt_34_tmpvar_phold, bevt_35_tmpvar_phold);
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_firstGet_0();
bevp_platform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_32_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_4_6_TextString(14, bels_26));
bevt_40_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_38_tmpvar_phold = bevp_params.bem_get_2(bevt_39_tmpvar_phold, (BEC_4_6_TextString) bevt_40_tmpvar_phold);
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_6_8_SystemPlatform()).bem_new_1((BEC_4_6_TextString) bevt_37_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_4_6_TextString(16, bels_27));
bevt_44_tmpvar_phold = (new BEC_4_6_TextString(5, bels_28));
bevt_42_tmpvar_phold = bevp_params.bem_get_2(bevt_43_tmpvar_phold, bevt_44_tmpvar_phold);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_5_4_LogicBool()).bem_new_1(bevt_41_tmpvar_phold);
bevt_47_tmpvar_phold = (new BEC_4_6_TextString(10, bels_29));
bevt_48_tmpvar_phold = (new BEC_4_6_TextString(4, bels_30));
bevt_46_tmpvar_phold = bevp_params.bem_get_2(bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_5_4_LogicBool()).bem_new_1(bevt_45_tmpvar_phold);
bevt_50_tmpvar_phold = (new BEC_4_6_TextString(9, bels_31));
bevt_49_tmpvar_phold = bevp_params.bem_get_1(bevt_50_tmpvar_phold);
bevp_mainName = (BEC_4_6_TextString) bevt_49_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = (new BEC_4_6_TextString(10, bels_32));
bevt_51_tmpvar_phold = bevp_params.bem_get_1(bevt_52_tmpvar_phold);
bevp_deployPath = (BEC_4_6_TextString) bevt_51_tmpvar_phold.bem_firstGet_0();
bevt_53_tmpvar_phold = (new BEC_4_6_TextString(10, bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_53_tmpvar_phold);
if (bevp_usedLibrarysStr == null) {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevp_usedLibrarysStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193 */
bevt_55_tmpvar_phold = (new BEC_4_6_TextString(15, bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_55_tmpvar_phold);
if (bevp_closeLibrariesStr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevp_closeLibrariesStr = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197 */
bevt_57_tmpvar_phold = (new BEC_4_6_TextString(14, bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_57_tmpvar_phold);
if (bevp_deployFilesFrom == null) {
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_58_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 200 */ {
bevp_deployFilesFrom = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201 */
bevt_59_tmpvar_phold = (new BEC_4_6_TextString(12, bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_59_tmpvar_phold);
if (bevp_deployFilesTo == null) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 204 */ {
bevp_deployFilesTo = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205 */
bevt_61_tmpvar_phold = (new BEC_4_6_TextString(10, bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_61_tmpvar_phold);
if (bevp_extIncludes == null) {
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevp_extIncludes = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209 */
bevt_63_tmpvar_phold = (new BEC_4_6_TextString(9, bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_63_tmpvar_phold);
if (bevp_ccObjArgs == null) {
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevp_ccObjArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213 */
bevt_65_tmpvar_phold = (new BEC_4_6_TextString(6, bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_65_tmpvar_phold);
if (bevp_extLibs == null) {
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 216 */ {
bevp_extLibs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217 */
bevt_67_tmpvar_phold = (new BEC_4_6_TextString(11, bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_67_tmpvar_phold);
if (bevp_linkLibArgs == null) {
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevp_linkLibArgs = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221 */
bevt_69_tmpvar_phold = (new BEC_4_6_TextString(13, bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_69_tmpvar_phold);
if (bevp_extLinkObjects == null) {
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevp_extLinkObjects = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 225 */
bevt_71_tmpvar_phold = (new BEC_4_6_TextString(14, bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_71_tmpvar_phold);
if (bevp_emitFileHeader == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 228 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 229 */
bevt_73_tmpvar_phold = (new BEC_4_6_TextString(7, bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_73_tmpvar_phold);
if (bevp_runArgs == null) {
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_74_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_74_tmpvar_phold.bevi_bool) /* Line: 232 */ {
bevp_runArgs = bevp_runArgs.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
} /* Line: 233 */
 else  /* Line: 234 */ {
bevp_runArgs = (new BEC_4_6_TextString()).bem_new_0();
} /* Line: 235 */
bevt_75_tmpvar_phold = (new BEC_4_6_TextString(10, bels_44));
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_75_tmpvar_phold, bevt_76_tmpvar_phold);
bevt_77_tmpvar_phold = (new BEC_4_6_TextString(11, bels_45));
bevt_78_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_77_tmpvar_phold, bevt_78_tmpvar_phold);
bevt_79_tmpvar_phold = (new BEC_4_6_TextString(8, bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_79_tmpvar_phold);
bevt_80_tmpvar_phold = (new BEC_4_6_TextString(11, bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_80_tmpvar_phold);
bevp_printAstElements = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_81_tmpvar_phold = (new BEC_4_6_TextString(15, bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_81_tmpvar_phold);
if (bevl_pacm == null) {
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_82_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_82_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_84_tmpvar_phold = bevl_pacm.bem_isEmptyGet_0();
bevt_83_tmpvar_phold = bevt_84_tmpvar_phold.bem_not_0();
if (bevt_83_tmpvar_phold.bevi_bool) /* Line: 243 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 243 */ {
bevt_1_tmpvar_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 244 */ {
bevt_85_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_85_tmpvar_phold != null && bevt_85_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_85_tmpvar_phold).bevi_bool) /* Line: 244 */ {
bevl_pa = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 245 */
 else  /* Line: 244 */ {
break;
} /* Line: 244 */
} /* Line: 244 */
} /* Line: 244 */
bevt_86_tmpvar_phold = (new BEC_4_6_TextString(7, bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_86_tmpvar_phold);
bevt_87_tmpvar_phold = (new BEC_4_6_TextString(19, bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_87_tmpvar_phold);
bevt_88_tmpvar_phold = (new BEC_4_6_TextString(3, bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_88_tmpvar_phold);
bevt_89_tmpvar_phold = (new BEC_4_6_TextString(21, bels_52));
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_89_tmpvar_phold, bevt_90_tmpvar_phold);
bevt_91_tmpvar_phold = (new BEC_4_6_TextString(8, bels_53));
bevp_emitLangs = bevp_params.bem_get_1(bevt_91_tmpvar_phold);
bevt_92_tmpvar_phold = (new BEC_4_6_TextString(8, bels_54));
bevp_emitFlags = bevp_params.bem_get_1(bevt_92_tmpvar_phold);
bevt_94_tmpvar_phold = (new BEC_4_6_TextString(8, bels_55));
bevt_95_tmpvar_phold = (new BEC_4_6_TextString(3, bels_56));
bevt_93_tmpvar_phold = bevp_params.bem_get_2(bevt_94_tmpvar_phold, bevt_95_tmpvar_phold);
bevp_compiler = (BEC_4_6_TextString) bevt_93_tmpvar_phold.bem_firstGet_0();
bevt_97_tmpvar_phold = (new BEC_4_6_TextString(4, bels_57));
bevt_98_tmpvar_phold = (new BEC_4_6_TextString(4, bels_58));
bevt_96_tmpvar_phold = bevp_params.bem_get_2(bevt_97_tmpvar_phold, bevt_98_tmpvar_phold);
bevp_makeName = (BEC_4_6_TextString) bevt_96_tmpvar_phold.bem_firstGet_0();
bevt_101_tmpvar_phold = bevo_10;
bevt_100_tmpvar_phold = bevt_101_tmpvar_phold.bem_add_1(bevp_makeName);
bevt_102_tmpvar_phold = (new BEC_4_6_TextString(0, bels_60));
bevt_99_tmpvar_phold = bevp_params.bem_get_2(bevt_100_tmpvar_phold, bevt_102_tmpvar_phold);
bevp_makeArgs = (BEC_4_6_TextString) bevt_99_tmpvar_phold.bem_firstGet_0();
bevp_parse = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_doEmit = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_prepMake = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_make = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_103_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_103_tmpvar_phold.bevi_bool) /* Line: 264 */ {
bevl_outLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 265 */
 else  /* Line: 266 */ {
bevl_outLang = (new BEC_4_6_TextString(1, bels_61));
} /* Line: 267 */
bevt_106_tmpvar_phold = bevo_11;
bevt_105_tmpvar_phold = bevl_outLang.bem_add_1(bevt_106_tmpvar_phold);
bevt_107_tmpvar_phold = bevp_platform.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bem_add_1(bevt_107_tmpvar_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_104_tmpvar_phold);
if (bevl_platformSources == null) {
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_108_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_108_tmpvar_phold.bevi_bool) /* Line: 275 */ {
bevt_109_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_109_tmpvar_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 276 */
bevt_111_tmpvar_phold = bevo_12;
bevt_110_tmpvar_phold = bevl_outLang.bem_add_1(bevt_111_tmpvar_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_110_tmpvar_phold);
if (bevl_langSources == null) {
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_112_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_112_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_113_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_113_tmpvar_phold.bem_addAll_1(bevl_langSources);
} /* Line: 281 */
bevp_toBuild = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_114_tmpvar_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpvar_loop = bevt_114_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 285 */ {
bevt_115_tmpvar_phold = bevt_2_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_115_tmpvar_phold != null && bevt_115_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_115_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevl_istr = (BEC_4_6_TextString) bevt_2_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_116_tmpvar_phold = (new BEC_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_116_tmpvar_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
bevp_newline = (BEC_4_6_TextString) bevp_platform.bemd_0(776765523, BEL_4_Base.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_119_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_118_tmpvar_phold = bevt_119_tmpvar_phold.bem_existsGet_0();
bevt_117_tmpvar_phold = bevt_118_tmpvar_phold.bem_not_0();
if (bevt_117_tmpvar_phold.bevi_bool) /* Line: 293 */ {
bevt_120_tmpvar_phold = bevp_emitPath.bem_fileGet_0();
bevt_120_tmpvar_phold.bem_makeDirs_0();
} /* Line: 294 */
if (bevp_emitFileHeader == null) {
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_121_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_121_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevt_122_tmpvar_phold = (new BEC_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_122_tmpvar_phold.bem_readerGet_0();
bevt_123_tmpvar_phold = bevl_emr.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevp_emitFileHeader = bevt_123_tmpvar_phold.bemd_1(347960121, BEL_4_Base.bevn_readString_1, bevp_readBuffer);
bevl_emr.bemd_0(866536361, BEL_4_Base.bevn_close_0);
} /* Line: 299 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_6_6_SystemObject bevl_toRet = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_toRet = this.bem_classNameGet_0();
bevt_1_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(13, bels_64));
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_5_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_nl);
bevt_6_tmpvar_phold = (new BEC_4_6_TextString(12, bels_65));
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_7_tmpvar_phold);
return (BEC_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_6_6_SystemObject bem_setClassesToWrite_0() throws Throwable {
BEC_9_3_ContainerSet bevl_toEmit = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_9_3_ContainerSet bevl_usedBy = null;
BEC_4_6_TextString bevl_ub = null;
BEC_9_3_ContainerSet bevl_subClasses = null;
BEC_4_6_TextString bevl_sc = null;
BEC_9_3_11_ContainerSetKeyIterator bevt_0_tmpvar_loop = null;
BEC_9_3_11_ContainerSetKeyIterator bevt_1_tmpvar_loop = null;
BEC_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_9_3_ContainerSet bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_23_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_29_tmpvar_phold = null;
bevl_toEmit = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 313 */ {
bevt_3_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 313 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_has_1(bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 315 */ {
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpvar_phold);
bevt_11_tmpvar_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_usedBy = (BEC_9_3_ContainerSet) bevt_11_tmpvar_phold.bem_get_1(bevt_12_tmpvar_phold);
if (bevl_usedBy == null) {
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpvar_phold.bevi_bool) /* Line: 318 */ {
bevt_0_tmpvar_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 319 */ {
bevt_16_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 319 */ {
bevl_ub = (BEC_4_6_TextString) bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 320 */
 else  /* Line: 319 */ {
break;
} /* Line: 319 */
} /* Line: 319 */
} /* Line: 319 */
bevt_17_tmpvar_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_subClasses = (BEC_9_3_ContainerSet) bevt_17_tmpvar_phold.bem_get_1(bevt_18_tmpvar_phold);
if (bevl_subClasses == null) {
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 324 */ {
bevt_1_tmpvar_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 325 */ {
bevt_22_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 325 */ {
bevl_sc = (BEC_4_6_TextString) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 326 */
 else  /* Line: 325 */ {
break;
} /* Line: 325 */
} /* Line: 325 */
} /* Line: 325 */
} /* Line: 324 */
} /* Line: 315 */
 else  /* Line: 313 */ {
break;
} /* Line: 313 */
} /* Line: 313 */
bevt_23_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 331 */ {
bevt_24_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_24_tmpvar_phold != null && bevt_24_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_24_tmpvar_phold).bevi_bool) /* Line: 331 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_25_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_26_tmpvar_phold = bevl_toEmit.bem_has_1(bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold.bemd_1(2134225160, BEL_4_Base.bevn_shouldWriteSet_1, bevt_26_tmpvar_phold);
} /* Line: 333 */
 else  /* Line: 331 */ {
break;
} /* Line: 331 */
} /* Line: 331 */
return this;
} /*method end*/
public BEC_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_4_6_TextString bevl_emitLang = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_9_SystemException bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 344 */ {
return bevp_emitCommon;
} /* Line: 345 */
if (bevp_emitLangs == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 350 */ {
bevl_emitLang = (BEC_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpvar_phold = bevo_13;
bevt_2_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 352 */ {
bevt_5_tmpvar_phold = bevo_14;
bevt_4_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpvar_phold);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 355 */
 else  /* Line: 352 */ {
bevt_7_tmpvar_phold = bevo_15;
bevt_6_tmpvar_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) (new BEC_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 357 */
 else  /* Line: 358 */ {
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(49, bels_69));
bevt_8_tmpvar_phold = (new BEC_6_9_SystemException()).bem_new_1(bevt_9_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_8_tmpvar_phold);
} /* Line: 359 */
} /* Line: 352 */
} /* Line: 352 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 362 */
return null;
} /*method end*/
public BEC_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_6_6_SystemObject bevl_em = null;
BEC_9_3_ContainerSet bevl_ulibs = null;
BEC_6_6_SystemObject bevl_ups = null;
BEC_6_6_SystemObject bevl_pack = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevl_tb = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_bp = null;
BEC_6_6_SystemObject bevl_cpFrom = null;
BEC_6_6_SystemObject bevl_cpTo = null;
BEC_6_6_SystemObject bevl_fIter = null;
BEC_6_6_SystemObject bevl_tIter = null;
BEC_4_3_MathInt bevl_result = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_6_6_SystemObject bevt_1_tmpvar_loop = null;
BEC_9_10_8_ContainerLinkedListIterator bevt_2_tmpvar_loop = null;
BEC_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_4_8_TimeInterval bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_16_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_17_tmpvar_phold = null;
BEC_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_20_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_21_tmpvar_phold = null;
BEC_5_10_BuildEmitCommon bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_24_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_26_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_28_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_29_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_38_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_55_tmpvar_phold = null;
BEC_2_4_4_IOFilePath bevt_56_tmpvar_phold = null;
BEC_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_67_tmpvar_phold = null;
BEC_4_8_TimeInterval bevt_68_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_4_6_TextString bevt_73_tmpvar_phold = null;
BEC_4_6_TextString bevt_74_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_4_6_TextString bevt_76_tmpvar_phold = null;
BEC_4_6_TextString bevt_77_tmpvar_phold = null;
BEC_4_6_TextString bevt_78_tmpvar_phold = null;
BEC_4_6_TextString bevt_79_tmpvar_phold = null;
BEC_4_6_TextString bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_3_MathInt bevt_83_tmpvar_phold = null;
bevt_4_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_4_tmpvar_phold.bem_now_0();
bevp_emitData = (new BEC_5_8_BuildEmitData()).bem_new_0();
bevl_em = this.bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 372 */ {
bevp_deployLibrary = (new BEC_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 375 */ {
bevt_7_tmpvar_phold = bevo_16;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_libName);
bevt_6_tmpvar_phold.bem_print_0();
} /* Line: 376 */
} /* Line: 375 */
bevl_ulibs = (new BEC_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpvar_loop = bevp_usedLibrarysStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 381 */ {
bevt_8_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 381 */ {
bevl_ups = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_10_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_not_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 382 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 385 */
} /* Line: 382 */
 else  /* Line: 381 */ {
break;
} /* Line: 381 */
} /* Line: 381 */
bevt_1_tmpvar_loop = bevp_closeLibrariesStr.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 388 */ {
bevt_11_tmpvar_phold = bevt_1_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 388 */ {
bevl_ups = bevt_1_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_13_tmpvar_phold = bevl_ulibs.bem_has_1(bevl_ups);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_not_0();
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 389 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_5_7_BuildLibrary()).bem_new_2((BEC_4_6_TextString) bevl_ups, this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_14_tmpvar_phold = bevl_pack.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_14_tmpvar_phold);
} /* Line: 393 */
} /* Line: 389 */
 else  /* Line: 388 */ {
break;
} /* Line: 388 */
} /* Line: 388 */
if (bevp_parse.bevi_bool) /* Line: 396 */ {
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 398 */ {
bevt_15_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 398 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_doParse_1(bevl_tb);
} /* Line: 401 */
 else  /* Line: 398 */ {
break;
} /* Line: 398 */
} /* Line: 398 */
this.bem_buildSyns_1(bevl_em);
} /* Line: 403 */
bevt_17_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_new_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_now_0();
bevp_parseTime = bevt_16_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_printSteps.bevi_bool) /* Line: 407 */ {
bevt_19_tmpvar_phold = bevo_17;
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_18_tmpvar_phold.bem_print_0();
} /* Line: 408 */
bevt_21_tmpvar_phold = this.bem_emitCommonGet_0();
if (bevt_21_tmpvar_phold == null) {
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpvar_phold.bevi_bool) /* Line: 410 */ {
bevt_22_tmpvar_phold = this.bem_emitCommonGet_0();
bevt_22_tmpvar_phold.bem_doEmit_0();
bevt_23_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_23_tmpvar_phold;
} /* Line: 413 */
if (bevp_doEmit.bevi_bool) /* Line: 415 */ {
this.bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevt_24_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_24_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 419 */ {
bevt_25_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_25_tmpvar_phold != null && bevt_25_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_25_tmpvar_phold).bevi_bool) /* Line: 419 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(4647120, BEL_4_Base.bevn_doEmit_1, bevl_clnode);
} /* Line: 421 */
 else  /* Line: 419 */ {
break;
} /* Line: 419 */
} /* Line: 419 */
bevl_em.bemd_0(1632069411, BEL_4_Base.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEL_4_Base.bevn_emitCUInit_0);
bevt_26_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_26_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 425 */ {
bevt_27_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_27_tmpvar_phold != null && bevt_27_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_27_tmpvar_phold).bevi_bool) /* Line: 425 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEL_4_Base.bevn_emitSyn_1, bevl_clnode);
} /* Line: 427 */
 else  /* Line: 425 */ {
break;
} /* Line: 425 */
} /* Line: 425 */
} /* Line: 425 */
bevt_29_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_30_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 432 */ {
bevt_32_tmpvar_phold = bevo_18;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_31_tmpvar_phold.bem_print_0();
} /* Line: 433 */
bevt_34_tmpvar_phold = bevo_19;
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_33_tmpvar_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 436 */ {
bevl_em.bemd_1(1877358931, BEL_4_Base.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 438 */
if (bevp_make.bevi_bool) /* Line: 441 */ {
bevt_35_tmpvar_phold = bevp_genOnly.bem_not_0();
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevl_em.bemd_1(1081520608, BEL_4_Base.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEL_4_Base.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 445 */ {
bevt_2_tmpvar_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 446 */ {
bevt_36_tmpvar_phold = bevt_2_tmpvar_loop.bem_hasNextGet_0();
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 446 */ {
bevl_bp = bevt_2_tmpvar_loop.bem_nextGet_0();
bevt_37_tmpvar_phold = bevl_bp.bemd_0(1743271113, BEL_4_Base.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_37_tmpvar_phold.bemd_0(159064069, BEL_4_Base.bevn_unitShlibGet_0);
bevt_38_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_38_tmpvar_phold.bem_copy_0();
bevt_40_tmpvar_phold = bevl_cpFrom.bemd_0(723109216, BEL_4_Base.bevn_stepsGet_0);
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEL_4_Base.bevn_addStep_1, bevt_39_tmpvar_phold);
bevt_42_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_41_tmpvar_phold = bevt_42_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_41_tmpvar_phold != null && bevt_41_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_41_tmpvar_phold).bevi_bool) /* Line: 450 */ {
bevt_43_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_43_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 451 */
bevt_46_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_44_tmpvar_phold != null && bevt_44_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_44_tmpvar_phold).bevi_bool) /* Line: 453 */ {
bevt_47_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_48_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_47_tmpvar_phold, bevt_48_tmpvar_phold);
} /* Line: 454 */
} /* Line: 453 */
 else  /* Line: 446 */ {
break;
} /* Line: 446 */
} /* Line: 446 */
} /* Line: 446 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 461 */ {
bevt_49_tmpvar_phold = bevl_fIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_49_tmpvar_phold != null && bevt_49_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_49_tmpvar_phold).bevi_bool) /* Line: 461 */ {
bevt_50_tmpvar_phold = bevl_tIter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 461 */
 else  /* Line: 461 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 461 */ {
bevt_51_tmpvar_phold = bevl_fIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cpFrom = (new BEC_2_4_4_IOFilePath()).bem_apNew_1((BEC_4_6_TextString) bevt_51_tmpvar_phold);
bevt_56_tmpvar_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_copy_0();
bevt_54_tmpvar_phold = bevt_55_tmpvar_phold.bem_toString_0();
bevt_57_tmpvar_phold = bevo_20;
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_add_1(bevt_57_tmpvar_phold);
bevt_58_tmpvar_phold = bevl_tIter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevl_cpTo = (new BEC_2_4_4_IOFilePath()).bem_apNew_1(bevt_52_tmpvar_phold);
bevt_60_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
if (bevt_59_tmpvar_phold != null && bevt_59_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_59_tmpvar_phold).bevi_bool) /* Line: 465 */ {
bevt_61_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_61_tmpvar_phold.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 466 */
bevt_64_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(2072547979, BEL_4_Base.bevn_existsGet_0);
bevt_62_tmpvar_phold = bevt_63_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_62_tmpvar_phold != null && bevt_62_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_62_tmpvar_phold).bevi_bool) /* Line: 468 */ {
bevt_65_tmpvar_phold = bevl_cpFrom.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_66_tmpvar_phold = bevl_cpTo.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevl_em.bemd_2(1249810954, BEL_4_Base.bevn_deployFile_2, bevt_65_tmpvar_phold, bevt_66_tmpvar_phold);
} /* Line: 469 */
} /* Line: 468 */
 else  /* Line: 461 */ {
break;
} /* Line: 461 */
} /* Line: 461 */
} /* Line: 461 */
} /* Line: 442 */
bevt_68_tmpvar_phold = (new BEC_4_8_TimeInterval()).bem_new_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_67_tmpvar_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 476 */ {
bevt_71_tmpvar_phold = bevo_21;
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_add_1(bevp_parseTime);
bevt_70_tmpvar_phold.bem_print_0();
} /* Line: 477 */
if (bevp_parseEmitTime == null) {
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_72_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_74_tmpvar_phold = bevo_22;
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bem_add_1(bevp_parseEmitTime);
bevt_73_tmpvar_phold.bem_print_0();
} /* Line: 480 */
if (bevp_parseEmitCompileTime == null) {
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_75_tmpvar_phold.bevi_bool) /* Line: 482 */ {
bevt_77_tmpvar_phold = bevo_23;
bevt_76_tmpvar_phold = bevt_77_tmpvar_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_76_tmpvar_phold.bem_print_0();
} /* Line: 483 */
if (bevp_run.bevi_bool) /* Line: 486 */ {
bevt_78_tmpvar_phold = bevo_24;
bevt_78_tmpvar_phold.bem_print_0();
bevl_result = (BEC_4_3_MathInt) bevl_em.bemd_2(108875646, BEL_4_Base.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_81_tmpvar_phold = bevo_25;
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bem_add_1(bevl_result);
bevt_82_tmpvar_phold = bevo_26;
bevt_79_tmpvar_phold = bevt_80_tmpvar_phold.bem_add_1(bevt_82_tmpvar_phold);
bevt_79_tmpvar_phold.bem_print_0();
return bevl_result;
} /* Line: 490 */
bevt_83_tmpvar_phold = (new BEC_4_3_MathInt(0));
return bevt_83_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSyns_1(BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_kls = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_6_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 496 */ {
bevt_1_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 496 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_2_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_syn = this.bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
} /* Line: 500 */
 else  /* Line: 496 */ {
break;
} /* Line: 496 */
} /* Line: 496 */
bevt_3_tmpvar_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 502 */ {
bevt_4_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 502 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_kls.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_syn = bevt_5_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEL_4_Base.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEL_4_Base.bevn_integrate_1, this);
} /* Line: 506 */
 else  /* Line: 502 */ {
break;
} /* Line: 502 */
} /* Line: 502 */
bevt_6_tmpvar_phold = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_getSyn_2(BEC_6_6_SystemObject beva_klass, BEC_6_6_SystemObject beva_em) throws Throwable {
BEC_6_6_SystemObject bevl_syn = null;
BEC_6_6_SystemObject bevl_pklass = null;
BEC_6_6_SystemObject bevl_psyn = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 512 */ {
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
return bevt_3_tmpvar_phold;
} /* Line: 513 */
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevt_7_tmpvar_phold == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 517 */
 else  /* Line: 518 */ {
bevt_9_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_pklass = bevt_9_tmpvar_phold.bem_get_1(bevt_10_tmpvar_phold);
if (bevl_pklass == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 521 */ {
bevt_14_tmpvar_phold = bevl_pklass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold.bemd_1(1792397628, BEL_4_Base.bevn_libNameSet_1, bevp_libName);
bevl_psyn = this.bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 523 */
 else  /* Line: 524 */ {
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_psyn = beva_em.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, bevt_15_tmpvar_phold);
} /* Line: 526 */
bevl_syn = (new BEC_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 528 */
bevt_17_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold.bemd_1(1802470828, BEL_4_Base.bevn_synSet_1, bevl_syn);
bevt_20_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevt_18_tmpvar_phold, (BEC_5_8_BuildClassSyn) bevl_syn);
return bevl_syn;
} /*method end*/
public BEC_5_8_BuildClassSyn bem_getSynNp_1(BEC_6_6_SystemObject beva_np) throws Throwable {
BEC_6_6_SystemObject bevl_nps = null;
BEC_6_6_SystemObject bevl_syn = null;
BEC_9_3_ContainerMap bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_0_tmpvar_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpvar_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 538 */ {
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /* Line: 539 */
bevt_2_tmpvar_phold = this.bem_emitterGet_0();
bevl_syn = bevt_2_tmpvar_phold.bemd_1(1378657076, BEL_4_Base.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_4_6_TextString) bevl_nps, (BEC_5_8_BuildClassSyn) bevl_syn);
return (BEC_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 554 */ {
bevp_sharedEmitter = (new BEC_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 555 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_doParse_1(BEC_6_6_SystemObject beva_toParse) throws Throwable {
BEC_6_6_SystemObject bevl_trans = null;
BEC_6_6_SystemObject bevl_blank = null;
BEC_6_6_SystemObject bevl_emitter = null;
BEC_5_4_LogicBool bevl_parseThis = null;
BEC_6_6_SystemObject bevl_src = null;
BEC_9_10_ContainerLinkedList bevl_toks = null;
BEC_6_6_SystemObject bevl_ci = null;
BEC_6_6_SystemObject bevl_clnode = null;
BEC_6_6_SystemObject bevl_tunode = null;
BEC_6_6_SystemObject bevl_ntunode = null;
BEC_6_6_SystemObject bevl_ntt = null;
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_9_3_ContainerSet bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_14_tmpvar_phold = null;
BEC_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass2 bevt_16_tmpvar_phold = null;
BEC_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_18_tmpvar_phold = null;
BEC_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass3 bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_22_tmpvar_phold = null;
BEC_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass4 bevt_24_tmpvar_phold = null;
BEC_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_26_tmpvar_phold = null;
BEC_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass5 bevt_28_tmpvar_phold = null;
BEC_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_30_tmpvar_phold = null;
BEC_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass6 bevt_32_tmpvar_phold = null;
BEC_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_34_tmpvar_phold = null;
BEC_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass7 bevt_36_tmpvar_phold = null;
BEC_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_38_tmpvar_phold = null;
BEC_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass8 bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass9 bevt_44_tmpvar_phold = null;
BEC_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_46_tmpvar_phold = null;
BEC_4_6_TextString bevt_47_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass10 bevt_48_tmpvar_phold = null;
BEC_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_50_tmpvar_phold = null;
BEC_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass11 bevt_52_tmpvar_phold = null;
BEC_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_54_tmpvar_phold = null;
BEC_4_6_TextString bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_5_5_6_BuildVisitPass12 bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_5_5_5_BuildVisitPass1 bevt_59_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_60_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_64_tmpvar_phold = null;
bevl_trans = (new BEC_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_4_6_TextString()).bem_new_0();
bevl_emitter = this.bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_2_tmpvar_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpvar_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 568 */ {
if (bevp_printSteps.bevi_bool) /* Line: 569 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 569 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 569 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 569 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 569 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 569 */ {
bevt_4_tmpvar_phold = bevo_27;
bevt_5_tmpvar_phold = beva_toParse.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold.bem_print_0();
} /* Line: 570 */
bevp_fromFile = beva_toParse;
bevt_8_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1010579589, BEL_4_Base.bevn_open_0);
bevl_src = bevt_6_tmpvar_phold.bemd_1(1325881256, BEL_4_Base.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpvar_phold = beva_toParse.bemd_0(1338882709, BEL_4_Base.bevn_fileGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(371906180, BEL_4_Base.bevn_readerGet_0);
bevt_9_tmpvar_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevl_toks = (BEC_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 583 */ {
bevt_11_tmpvar_phold = bevo_28;
bevt_11_tmpvar_phold.bem_echo_0();
} /* Line: 584 */
bevt_12_tmpvar_phold = bevl_trans.bemd_0(1380522583, BEL_4_Base.bevn_outermostGet_0);
this.bem_nodify_2(bevt_12_tmpvar_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 587 */ {
bevt_13_tmpvar_phold = bevo_29;
bevt_13_tmpvar_phold.bem_print_0();
bevt_14_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_14_tmpvar_phold);
} /* Line: 589 */
if (bevp_printSteps.bevi_bool) /* Line: 592 */ {
bevt_15_tmpvar_phold = bevo_30;
bevt_15_tmpvar_phold.bem_echo_0();
} /* Line: 593 */
bevt_16_tmpvar_phold = (BEC_5_5_5_BuildVisitPass2) (new BEC_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_16_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 596 */ {
bevt_17_tmpvar_phold = bevo_31;
bevt_17_tmpvar_phold.bem_print_0();
bevt_18_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_18_tmpvar_phold);
} /* Line: 598 */
if (bevp_printSteps.bevi_bool) /* Line: 600 */ {
bevt_19_tmpvar_phold = bevo_32;
bevt_19_tmpvar_phold.bem_echo_0();
} /* Line: 601 */
bevt_20_tmpvar_phold = (BEC_5_5_5_BuildVisitPass3) (new BEC_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_20_tmpvar_phold);
bevl_trans.bemd_0(410956923, BEL_4_Base.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 606 */ {
bevt_21_tmpvar_phold = bevo_33;
bevt_21_tmpvar_phold.bem_print_0();
bevt_22_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_22_tmpvar_phold);
} /* Line: 608 */
if (bevp_printSteps.bevi_bool) /* Line: 611 */ {
bevt_23_tmpvar_phold = bevo_34;
bevt_23_tmpvar_phold.bem_echo_0();
} /* Line: 612 */
bevt_24_tmpvar_phold = (BEC_5_5_5_BuildVisitPass4) (new BEC_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_24_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 615 */ {
bevt_25_tmpvar_phold = bevo_35;
bevt_25_tmpvar_phold.bem_print_0();
bevt_26_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_26_tmpvar_phold);
} /* Line: 617 */
if (bevp_printSteps.bevi_bool) /* Line: 620 */ {
bevt_27_tmpvar_phold = bevo_36;
bevt_27_tmpvar_phold.bem_echo_0();
} /* Line: 621 */
bevt_28_tmpvar_phold = (BEC_5_5_5_BuildVisitPass5) (new BEC_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_28_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 624 */ {
bevt_29_tmpvar_phold = bevo_37;
bevt_29_tmpvar_phold.bem_print_0();
bevt_30_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_30_tmpvar_phold);
} /* Line: 626 */
if (bevp_printSteps.bevi_bool) /* Line: 629 */ {
bevt_31_tmpvar_phold = bevo_38;
bevt_31_tmpvar_phold.bem_echo_0();
} /* Line: 630 */
bevt_32_tmpvar_phold = (BEC_5_5_5_BuildVisitPass6) (new BEC_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_32_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 633 */ {
bevt_33_tmpvar_phold = bevo_39;
bevt_33_tmpvar_phold.bem_print_0();
bevt_34_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_34_tmpvar_phold);
} /* Line: 635 */
if (bevp_printSteps.bevi_bool) /* Line: 638 */ {
bevt_35_tmpvar_phold = bevo_40;
bevt_35_tmpvar_phold.bem_echo_0();
} /* Line: 639 */
bevt_36_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_36_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 642 */ {
bevt_37_tmpvar_phold = bevo_41;
bevt_37_tmpvar_phold.bem_print_0();
bevt_38_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_38_tmpvar_phold);
} /* Line: 644 */
if (bevp_printSteps.bevi_bool) /* Line: 647 */ {
bevt_39_tmpvar_phold = bevo_42;
bevt_39_tmpvar_phold.bem_echo_0();
} /* Line: 648 */
bevt_40_tmpvar_phold = (BEC_5_5_5_BuildVisitPass8) (new BEC_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_40_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 651 */ {
bevt_41_tmpvar_phold = bevo_43;
bevt_41_tmpvar_phold.bem_print_0();
bevt_42_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_42_tmpvar_phold);
} /* Line: 653 */
if (bevp_printSteps.bevi_bool) /* Line: 656 */ {
bevt_43_tmpvar_phold = bevo_44;
bevt_43_tmpvar_phold.bem_echo_0();
} /* Line: 657 */
bevt_44_tmpvar_phold = (BEC_5_5_5_BuildVisitPass9) (new BEC_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_44_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 660 */ {
bevt_45_tmpvar_phold = bevo_45;
bevt_45_tmpvar_phold.bem_print_0();
bevt_46_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_46_tmpvar_phold);
} /* Line: 662 */
if (bevp_printSteps.bevi_bool) /* Line: 665 */ {
bevt_47_tmpvar_phold = bevo_46;
bevt_47_tmpvar_phold.bem_echo_0();
} /* Line: 666 */
bevt_48_tmpvar_phold = (BEC_5_5_6_BuildVisitPass10) (new BEC_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_48_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 669 */ {
bevt_49_tmpvar_phold = bevo_47;
bevt_49_tmpvar_phold.bem_print_0();
bevt_50_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_50_tmpvar_phold);
} /* Line: 671 */
if (bevp_printSteps.bevi_bool) /* Line: 673 */ {
bevt_51_tmpvar_phold = bevo_48;
bevt_51_tmpvar_phold.bem_echo_0();
} /* Line: 674 */
bevt_52_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_52_tmpvar_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 677 */ {
bevt_53_tmpvar_phold = bevo_49;
bevt_53_tmpvar_phold.bem_print_0();
bevt_54_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_54_tmpvar_phold);
} /* Line: 679 */
if (bevp_printSteps.bevi_bool) /* Line: 682 */ {
bevt_55_tmpvar_phold = bevo_50;
bevt_55_tmpvar_phold.bem_echo_0();
bevt_56_tmpvar_phold = bevo_51;
bevt_56_tmpvar_phold.bem_print_0();
} /* Line: 684 */
bevt_57_tmpvar_phold = (new BEC_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_57_tmpvar_phold);
if (bevp_printAst.bevi_bool) /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 687 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 687 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 687 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 687 */ {
bevt_58_tmpvar_phold = bevo_52;
bevt_58_tmpvar_phold.bem_print_0();
bevt_59_tmpvar_phold = (new BEC_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEL_4_Base.bevn_traverse_1, bevt_59_tmpvar_phold);
} /* Line: 689 */
bevt_60_tmpvar_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpvar_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 691 */ {
bevt_61_tmpvar_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_61_tmpvar_phold != null && bevt_61_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_61_tmpvar_phold).bevi_bool) /* Line: 691 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(1973596005, BEL_4_Base.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_62_tmpvar_phold);
bevl_ntt = (new BEC_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(568286617, BEL_4_Base.bevn_emitsGet_0);
bevl_ntt.bemd_1(557204364, BEL_4_Base.bevn_emitsSet_1, bevt_63_tmpvar_phold);
bevl_ntunode.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, bevl_clnode);
} /* Line: 702 */
 else  /* Line: 691 */ {
break;
} /* Line: 691 */
} /* Line: 691 */
} /* Line: 691 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_nodify_2(BEC_6_6_SystemObject beva_parnode, BEC_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_9_8_ContainerNodeList bevl_con = null;
BEC_6_6_SystemObject bevl_nlc = null;
BEC_4_6_TextString bevl_cr = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevl_node = null;
BEC_4_7_TextStrings bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
beva_parnode.bemd_0(1461034369, BEL_4_Base.bevn_reInitContained_0);
bevl_con = (BEC_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_nlc = (new BEC_4_3_MathInt(1));
bevt_0_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevl_cr = bevt_0_tmpvar_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 712 */ {
bevt_1_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 712 */ {
bevl_node = (new BEC_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpvar_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_2_tmpvar_phold);
bevl_node.bemd_1(1584180177, BEL_4_Base.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevp_nl);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 716 */ {
bevl_nlc = bevl_nlc.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 717 */
bevt_6_tmpvar_phold = bevl_node.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 719 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, beva_parnode);
} /* Line: 721 */
} /* Line: 719 */
 else  /* Line: 712 */ {
break;
} /* Line: 712 */
} /* Line: 712 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_6_6_SystemObject bem_mainNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mainName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_6_6_SystemObject bem_exeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_exeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFileHeaderSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_6_6_SystemObject bem_extIncludesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extIncludes = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_ccObjArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ccObjArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_6_6_SystemObject bem_extLibsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLibs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_linkLibArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_linkLibArgs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_6_6_SystemObject bem_extLinkObjectsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extLinkObjects = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_6_6_SystemObject bem_platformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_platform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_6_6_SystemObject bem_outputPlatformSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesStrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesFromSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_6_6_SystemObject bem_deployFilesToSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployFilesTo = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_6_6_SystemObject bem_nlSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nl = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_6_6_SystemObject bem_newlineSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newline = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_runArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerProfileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compilerProfile = (BEC_5_15_BuildCompilerProfile) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_6_6_SystemObject bem_argsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_args = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_6_6_SystemObject bem_paramsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_params = (BEC_6_10_SystemParameters) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_6_6_SystemObject bem_buildSucceededSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildSucceeded = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_6_6_SystemObject bem_buildMessageSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildMessage = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_6_6_SystemObject bem_startTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_startTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_6_6_SystemObject bem_parseEmitCompileTimeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_4_8_TimeInterval) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_6_6_SystemObject bem_buildPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_buildPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_6_6_SystemObject bem_includePathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_includePath = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_6_6_SystemObject bem_builtSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_built = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_6_6_SystemObject bem_toBuildSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_toBuild = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_6_6_SystemObject bem_printStepsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printSteps = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_6_6_SystemObject bem_printPlacesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printPlaces = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_6_6_SystemObject bem_printAllAstSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAllAst = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_6_6_SystemObject bem_printAstElementsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_printAstElements = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_6_6_SystemObject bem_doEmitSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_doEmit = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDebugSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitDebug = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_6_6_SystemObject bem_parseSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_parse = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_6_6_SystemObject bem_prepMakeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_prepMake = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_6_6_SystemObject bem_makeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_make = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_6_6_SystemObject bem_genOnlySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_genOnly = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_deployUsedLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_6_6_SystemObject bem_emitDataSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitData = (BEC_5_8_BuildEmitData) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_6_6_SystemObject bem_emitPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitPath = (BEC_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_6_6_SystemObject bem_codeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_code = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_6_6_SystemObject bem_estrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_estr = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_6_6_SystemObject bem_sharedEmitterSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_6_6_SystemObject bem_constantsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_6_6_SystemObject bem_ntypesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_6_6_SystemObject bem_twtokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_twtok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_6_6_SystemObject bem_lctokSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lctok = (BEC_4_9_TextTokenizer) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_6_6_SystemObject bem_deployLibrarySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployLibrary = (BEC_5_7_BuildLibrary) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_6_6_SystemObject bem_deployPathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_deployPath = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_6_6_SystemObject bem_usedLibrarysSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_usedLibrarys = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_6_6_SystemObject bem_closeLibrariesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_closeLibraries = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_6_6_SystemObject bem_runSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_run = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_6_6_SystemObject bem_compilerSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_compiler = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_6_6_SystemObject bem_emitLangsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitLangs = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_6_6_SystemObject bem_emitFlagsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitFlags = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_6_6_SystemObject bem_makeNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeName = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_6_6_SystemObject bem_makeArgsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_makeArgs = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_6_6_SystemObject bem_putLineNumbersInTraceSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_dynConditionsAllGet_0() throws Throwable {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_6_6_SystemObject bem_dynConditionsAllSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_dynConditionsAll = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_6_6_SystemObject bem_ownProcessSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ownProcess = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_6_6_SystemObject bem_readBufferSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_readBuffer = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_emitCommonSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitCommon = (BEC_5_10_BuildEmitCommon) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {61, 63, 64, 65, 66, 68, 69, 70, 71, 72, 73, 74, 78, 80, 81, 82, 83, 83, 86, 89, 90, 96, 97, 98, 99, 99, 104, 104, 104, 104, 0, 104, 104, 0, 0, 0, 0, 0, 105, 105, 107, 107, 111, 111, 111, 111, 115, 115, 116, 116, 116, 120, 121, 122, 122, 126, 127, 128, 130, 131, 132, 134, 135, 136, 136, 137, 0, 0, 0, 140, 142, 146, 146, 146, 147, 147, 147, 147, 148, 148, 148, 149, 149, 149, 150, 150, 150, 150, 151, 151, 151, 152, 152, 152, 154, 159, 161, 162, 162, 162, 163, 163, 0, 163, 163, 164, 164, 165, 166, 166, 171, 171, 171, 171, 172, 174, 174, 174, 175, 175, 176, 176, 176, 178, 180, 180, 180, 180, 180, 180, 181, 182, 182, 183, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 184, 185, 185, 185, 185, 185, 186, 186, 186, 186, 186, 187, 187, 187, 187, 187, 189, 189, 189, 190, 190, 190, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 231, 232, 232, 233, 235, 237, 237, 237, 238, 238, 238, 239, 239, 240, 240, 241, 242, 242, 243, 243, 243, 243, 0, 0, 0, 244, 0, 244, 244, 245, 248, 248, 249, 249, 250, 250, 251, 251, 251, 252, 252, 253, 253, 254, 254, 254, 254, 255, 255, 255, 255, 256, 256, 256, 256, 256, 257, 258, 259, 260, 261, 264, 264, 265, 267, 274, 274, 274, 274, 274, 275, 275, 276, 276, 279, 279, 279, 280, 280, 281, 281, 284, 285, 285, 0, 285, 285, 286, 286, 288, 289, 290, 292, 293, 293, 293, 294, 294, 296, 296, 297, 297, 298, 298, 299, 305, 306, 306, 306, 306, 306, 307, 307, 307, 307, 307, 308, 312, 313, 313, 313, 314, 315, 315, 315, 315, 316, 316, 316, 316, 317, 317, 317, 317, 317, 318, 318, 319, 0, 319, 319, 320, 323, 323, 323, 323, 323, 324, 324, 325, 0, 325, 325, 326, 331, 331, 331, 332, 333, 333, 333, 333, 333, 333, 340, 340, 344, 344, 345, 350, 350, 351, 352, 352, 353, 354, 354, 355, 356, 356, 357, 359, 359, 359, 361, 362, 364, 369, 369, 370, 371, 372, 372, 373, 374, 376, 376, 376, 379, 381, 0, 381, 381, 382, 382, 383, 384, 385, 388, 0, 388, 388, 389, 389, 390, 391, 392, 393, 393, 398, 398, 399, 401, 403, 406, 406, 406, 408, 408, 408, 410, 410, 410, 412, 412, 413, 413, 416, 417, 419, 419, 419, 420, 421, 423, 424, 425, 425, 425, 426, 427, 431, 431, 431, 432, 432, 433, 433, 433, 435, 435, 435, 438, 442, 443, 444, 446, 0, 446, 446, 447, 447, 448, 448, 449, 449, 449, 450, 450, 451, 451, 453, 453, 453, 454, 454, 454, 458, 459, 461, 461, 0, 0, 0, 462, 462, 463, 463, 463, 463, 463, 463, 463, 463, 465, 465, 466, 466, 468, 468, 468, 469, 469, 469, 474, 474, 474, 476, 476, 477, 477, 477, 479, 479, 480, 480, 480, 482, 482, 483, 483, 483, 487, 487, 488, 489, 489, 489, 489, 489, 490, 492, 492, 496, 496, 496, 497, 498, 498, 499, 500, 502, 502, 502, 503, 504, 504, 505, 506, 508, 508, 512, 512, 512, 512, 513, 513, 513, 515, 515, 516, 516, 516, 516, 517, 519, 519, 519, 519, 519, 521, 521, 522, 522, 523, 526, 526, 526, 528, 530, 530, 531, 531, 531, 531, 532, 536, 537, 537, 538, 538, 539, 545, 545, 546, 547, 554, 554, 555, 557, 562, 563, 564, 565, 566, 567, 567, 0, 0, 0, 570, 570, 570, 570, 572, 574, 574, 574, 574, 575, 575, 575, 576, 584, 584, 586, 586, 588, 588, 589, 589, 593, 593, 595, 595, 597, 597, 598, 598, 601, 601, 604, 604, 605, 607, 607, 608, 608, 612, 612, 614, 614, 616, 616, 617, 617, 621, 621, 623, 623, 625, 625, 626, 626, 630, 630, 632, 632, 634, 634, 635, 635, 639, 639, 641, 641, 643, 643, 644, 644, 648, 648, 650, 650, 652, 652, 653, 653, 657, 657, 659, 659, 661, 661, 662, 662, 666, 666, 668, 668, 670, 670, 671, 671, 674, 674, 676, 676, 678, 678, 679, 679, 683, 683, 684, 684, 686, 686, 0, 0, 0, 688, 688, 689, 689, 691, 691, 691, 692, 694, 695, 696, 696, 697, 698, 698, 698, 699, 700, 701, 702, 708, 709, 710, 711, 711, 712, 712, 713, 714, 714, 715, 716, 716, 717, 719, 719, 720, 721, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 277, 282, 283, 284, 286, 289, 290, 292, 295, 299, 302, 306, 309, 310, 312, 313, 319, 320, 321, 322, 329, 330, 331, 332, 333, 338, 339, 340, 341, 349, 350, 351, 353, 354, 355, 359, 360, 361, 362, 363, 366, 370, 373, 377, 379, 399, 400, 401, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 424, 560, 561, 562, 563, 568, 569, 570, 570, 573, 575, 576, 577, 579, 580, 581, 589, 590, 591, 592, 594, 596, 597, 598, 599, 600, 602, 603, 604, 607, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 658, 659, 661, 662, 663, 668, 669, 671, 672, 673, 678, 679, 681, 682, 683, 688, 689, 691, 692, 693, 698, 699, 701, 702, 703, 708, 709, 711, 712, 713, 718, 719, 721, 722, 723, 728, 729, 731, 732, 733, 738, 739, 741, 742, 743, 748, 749, 751, 752, 753, 758, 759, 762, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 782, 783, 784, 786, 789, 793, 796, 796, 799, 801, 802, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 845, 846, 849, 851, 852, 853, 854, 855, 856, 861, 862, 863, 865, 866, 867, 868, 873, 874, 875, 877, 878, 879, 879, 882, 884, 885, 886, 892, 893, 894, 895, 896, 897, 898, 900, 901, 903, 908, 909, 910, 911, 912, 913, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 978, 979, 980, 983, 985, 986, 987, 988, 989, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000, 1005, 1006, 1006, 1009, 1011, 1012, 1019, 1020, 1021, 1022, 1023, 1024, 1029, 1030, 1030, 1033, 1035, 1036, 1049, 1050, 1053, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1071, 1072, 1086, 1091, 1092, 1094, 1099, 1100, 1101, 1102, 1104, 1107, 1108, 1110, 1113, 1114, 1116, 1119, 1120, 1121, 1125, 1126, 1128, 1229, 1230, 1231, 1232, 1233, 1238, 1239, 1240, 1242, 1243, 1244, 1247, 1248, 1248, 1251, 1253, 1254, 1255, 1257, 1258, 1259, 1266, 1266, 1269, 1271, 1272, 1273, 1275, 1276, 1277, 1278, 1279, 1287, 1290, 1292, 1293, 1299, 1301, 1302, 1303, 1305, 1306, 1307, 1309, 1310, 1315, 1316, 1317, 1318, 1319, 1322, 1323, 1324, 1325, 1328, 1330, 1331, 1337, 1338, 1339, 1340, 1343, 1345, 1346, 1353, 1354, 1355, 1356, 1361, 1362, 1363, 1364, 1366, 1367, 1368, 1370, 1373, 1375, 1376, 1378, 1378, 1381, 1383, 1384, 1385, 1386, 1387, 1388, 1389, 1390, 1391, 1392, 1394, 1395, 1397, 1398, 1399, 1401, 1402, 1403, 1411, 1412, 1415, 1417, 1419, 1422, 1426, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1442, 1443, 1445, 1446, 1447, 1449, 1450, 1451, 1460, 1461, 1462, 1463, 1468, 1469, 1470, 1471, 1473, 1478, 1479, 1480, 1481, 1483, 1488, 1489, 1490, 1491, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1502, 1504, 1505, 1518, 1519, 1522, 1524, 1525, 1526, 1527, 1528, 1534, 1535, 1538, 1540, 1541, 1542, 1543, 1544, 1550, 1551, 1579, 1580, 1581, 1586, 1587, 1588, 1589, 1591, 1592, 1593, 1594, 1595, 1600, 1601, 1604, 1605, 1606, 1607, 1608, 1609, 1614, 1615, 1616, 1617, 1620, 1621, 1622, 1624, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1640, 1641, 1642, 1643, 1648, 1649, 1651, 1652, 1653, 1654, 1658, 1663, 1664, 1666, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1754, 1758, 1761, 1765, 1766, 1767, 1768, 1770, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1778, 1780, 1781, 1783, 1784, 1786, 1787, 1788, 1789, 1792, 1793, 1795, 1796, 1798, 1799, 1800, 1801, 1804, 1805, 1807, 1808, 1809, 1811, 1812, 1813, 1814, 1817, 1818, 1820, 1821, 1823, 1824, 1825, 1826, 1829, 1830, 1832, 1833, 1835, 1836, 1837, 1838, 1841, 1842, 1844, 1845, 1847, 1848, 1849, 1850, 1853, 1854, 1856, 1857, 1859, 1860, 1861, 1862, 1865, 1866, 1868, 1869, 1871, 1872, 1873, 1874, 1877, 1878, 1880, 1881, 1883, 1884, 1885, 1886, 1889, 1890, 1892, 1893, 1895, 1896, 1897, 1898, 1901, 1902, 1904, 1905, 1907, 1908, 1909, 1910, 1913, 1914, 1915, 1916, 1918, 1919, 1921, 1925, 1928, 1932, 1933, 1934, 1935, 1937, 1938, 1941, 1943, 1944, 1945, 1946, 1947, 1948, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1977, 1978, 1979, 1980, 1981, 1982, 1985, 1987, 1988, 1989, 1990, 1991, 1992, 1994, 1996, 1997, 1999, 2000, 2010, 2013, 2017, 2020, 2024, 2027, 2031, 2034, 2038, 2041, 2045, 2048, 2052, 2055, 2059, 2062, 2066, 2069, 2073, 2076, 2080, 2083, 2087, 2090, 2094, 2097, 2101, 2104, 2108, 2111, 2115, 2118, 2122, 2125, 2129, 2132, 2136, 2139, 2143, 2146, 2150, 2153, 2157, 2160, 2164, 2167, 2171, 2174, 2178, 2181, 2185, 2188, 2192, 2195, 2199, 2202, 2206, 2209, 2213, 2216, 2220, 2223, 2227, 2230, 2234, 2237, 2241, 2244, 2248, 2251, 2255, 2258, 2262, 2265, 2269, 2272, 2276, 2279, 2283, 2286, 2290, 2293, 2297, 2300, 2304, 2307, 2311, 2314, 2318, 2321, 2325, 2328, 2332, 2335, 2339, 2342, 2346, 2349, 2353, 2356, 2360, 2363, 2367, 2370, 2374, 2377, 2381, 2384, 2388, 2391, 2395, 2398, 2402, 2405, 2409, 2412, 2416, 2419, 2423, 2426, 2430, 2433, 2437, 2440, 2444, 2447, 2451, 2454, 2458, 2461, 2465, 2468, 2472, 2475, 2479, 2482, 2486};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 61 240
new 0 61 240
assign 1 63 241
new 0 63 241
assign 1 64 242
new 0 64 242
assign 1 65 243
new 0 65 243
assign 1 66 244
new 0 66 244
assign 1 68 245
new 0 68 245
assign 1 69 246
new 0 69 246
assign 1 70 247
new 0 70 247
assign 1 71 248
new 0 71 248
assign 1 72 249
new 0 72 249
assign 1 73 250
new 0 73 250
assign 1 74 251
new 0 74 251
assign 1 78 252
new 0 78 252
assign 1 80 253
new 1 80 253
assign 1 81 254
ntypesGet 0 81 254
assign 1 82 255
twtokGet 0 82 255
assign 1 83 256
new 0 83 256
assign 1 83 257
new 1 83 257
assign 1 86 258
new 0 86 258
assign 1 89 259
new 0 89 259
assign 1 90 260
new 0 90 260
assign 1 96 261
new 0 96 261
assign 1 97 262
new 0 97 262
assign 1 98 263
new 0 98 263
assign 1 99 264
new 0 99 264
assign 1 99 265
new 1 99 265
assign 1 104 277
def 1 104 282
assign 1 104 283
new 0 104 283
assign 1 104 284
equals 1 104 284
assign 1 0 286
assign 1 104 289
new 0 104 289
assign 1 104 290
ends 1 104 290
assign 1 0 292
assign 1 0 295
assign 1 0 299
assign 1 0 302
assign 1 0 306
assign 1 105 309
new 0 105 309
return 1 105 310
assign 1 107 312
new 0 107 312
return 1 107 313
assign 1 111 319
new 0 111 319
assign 1 111 320
new 0 111 320
assign 1 111 321
swap 2 111 321
return 1 111 322
assign 1 115 329
new 0 115 329
assign 1 115 330
argsGet 0 115 330
assign 1 116 331
new 0 116 331
assign 1 116 332
main 1 116 332
exit 1 116 333
assign 1 120 338
assign 1 121 339
new 1 121 339
assign 1 122 340
go 0 122 340
return 1 122 341
assign 1 126 349
new 0 126 349
config 0 127 350
assign 1 128 351
new 0 128 351
assign 1 130 353
new 0 130 353
assign 1 131 354
doWhat 0 131 354
assign 1 132 355
new 0 132 355
assign 1 134 359
toString 0 134 359
assign 1 135 360
new 0 135 360
assign 1 136 361
new 0 136 361
assign 1 136 362
add 1 136 362
assign 1 137 363
new 0 137 363
assign 1 0 366
assign 1 0 370
assign 1 0 373
print 0 140 377
return 1 142 379
assign 1 146 399
nameGet 0 146 399
assign 1 146 400
new 0 146 400
assign 1 146 401
equals 1 146 401
assign 1 147 403
new 0 147 403
assign 1 147 404
add 1 147 404
assign 1 147 405
add 1 147 405
assign 1 147 406
add 1 147 406
assign 1 148 407
new 0 148 407
assign 1 148 408
add 1 148 408
assign 1 148 409
add 1 148 409
assign 1 149 410
new 0 149 410
assign 1 149 411
add 1 149 411
assign 1 149 412
add 1 149 412
assign 1 150 413
new 0 150 413
assign 1 150 414
add 1 150 414
assign 1 150 415
add 1 150 415
assign 1 150 416
add 1 150 416
assign 1 151 417
new 0 151 417
assign 1 151 418
add 1 151 418
assign 1 151 419
add 1 151 419
assign 1 152 420
new 0 152 420
assign 1 152 421
add 1 152 421
assign 1 152 422
add 1 152 422
return 1 154 424
assign 1 159 560
new 0 159 560
assign 1 161 561
new 0 161 561
assign 1 162 562
get 1 162 562
assign 1 162 563
def 1 162 568
assign 1 163 569
get 1 163 569
assign 1 163 570
iteratorGet 0 0 570
assign 1 163 573
hasNextGet 0 163 573
assign 1 163 575
nextGet 0 163 575
assign 1 164 576
has 1 164 576
assign 1 164 577
not 0 164 577
put 1 165 579
assign 1 166 580
new 1 166 580
addFile 1 166 581
assign 1 171 589
new 0 171 589
assign 1 171 590
nameGet 0 171 590
assign 1 171 591
new 0 171 591
assign 1 171 592
equals 1 171 592
preProcessorSet 1 172 594
assign 1 174 596
new 0 174 596
assign 1 174 597
get 1 174 597
assign 1 174 598
firstGet 0 174 598
assign 1 175 599
new 0 175 599
assign 1 175 600
has 1 175 600
assign 1 176 602
new 0 176 602
assign 1 176 603
get 1 176 603
assign 1 176 604
firstGet 0 176 604
assign 1 178 607
assign 1 180 609
new 0 180 609
assign 1 180 610
new 0 180 610
assign 1 180 611
get 2 180 611
assign 1 180 612
firstGet 0 180 612
assign 1 180 613
new 1 180 613
assign 1 180 614
pathGet 0 180 614
addStep 1 181 615
assign 1 182 616
new 0 182 616
addStep 1 182 617
assign 1 183 618
new 0 183 618
assign 1 183 619
new 0 183 619
assign 1 183 620
get 2 183 620
assign 1 183 621
firstGet 0 183 621
assign 1 183 622
new 1 183 622
assign 1 183 623
pathGet 0 183 623
assign 1 184 624
new 0 184 624
assign 1 184 625
new 0 184 625
assign 1 184 626
nameGet 0 184 626
assign 1 184 627
get 2 184 627
assign 1 184 628
firstGet 0 184 628
assign 1 184 629
new 1 184 629
assign 1 185 630
new 0 185 630
assign 1 185 631
nameGet 0 185 631
assign 1 185 632
get 2 185 632
assign 1 185 633
firstGet 0 185 633
assign 1 185 634
new 1 185 634
assign 1 186 635
new 0 186 635
assign 1 186 636
new 0 186 636
assign 1 186 637
get 2 186 637
assign 1 186 638
firstGet 0 186 638
assign 1 186 639
new 1 186 639
assign 1 187 640
new 0 187 640
assign 1 187 641
new 0 187 641
assign 1 187 642
get 2 187 642
assign 1 187 643
firstGet 0 187 643
assign 1 187 644
new 1 187 644
assign 1 189 645
new 0 189 645
assign 1 189 646
get 1 189 646
assign 1 189 647
firstGet 0 189 647
assign 1 190 648
new 0 190 648
assign 1 190 649
get 1 190 649
assign 1 190 650
firstGet 0 190 650
assign 1 191 651
new 0 191 651
assign 1 191 652
get 1 191 652
assign 1 192 653
undef 1 192 658
assign 1 193 659
new 0 193 659
assign 1 195 661
new 0 195 661
assign 1 195 662
get 1 195 662
assign 1 196 663
undef 1 196 668
assign 1 197 669
new 0 197 669
assign 1 199 671
new 0 199 671
assign 1 199 672
get 1 199 672
assign 1 200 673
undef 1 200 678
assign 1 201 679
new 0 201 679
assign 1 203 681
new 0 203 681
assign 1 203 682
get 1 203 682
assign 1 204 683
undef 1 204 688
assign 1 205 689
new 0 205 689
assign 1 207 691
new 0 207 691
assign 1 207 692
get 1 207 692
assign 1 208 693
undef 1 208 698
assign 1 209 699
new 0 209 699
assign 1 211 701
new 0 211 701
assign 1 211 702
get 1 211 702
assign 1 212 703
undef 1 212 708
assign 1 213 709
new 0 213 709
assign 1 215 711
new 0 215 711
assign 1 215 712
get 1 215 712
assign 1 216 713
undef 1 216 718
assign 1 217 719
new 0 217 719
assign 1 219 721
new 0 219 721
assign 1 219 722
get 1 219 722
assign 1 220 723
undef 1 220 728
assign 1 221 729
new 0 221 729
assign 1 223 731
new 0 223 731
assign 1 223 732
get 1 223 732
assign 1 224 733
undef 1 224 738
assign 1 225 739
new 0 225 739
assign 1 227 741
new 0 227 741
assign 1 227 742
get 1 227 742
assign 1 228 743
def 1 228 748
assign 1 229 749
firstGet 0 229 749
assign 1 231 751
new 0 231 751
assign 1 231 752
get 1 231 752
assign 1 232 753
def 1 232 758
assign 1 233 759
firstGet 0 233 759
assign 1 235 762
new 0 235 762
assign 1 237 764
new 0 237 764
assign 1 237 765
new 0 237 765
assign 1 237 766
isTrue 2 237 766
assign 1 238 767
new 0 238 767
assign 1 238 768
new 0 238 768
assign 1 238 769
isTrue 2 238 769
assign 1 239 770
new 0 239 770
assign 1 239 771
isTrue 1 239 771
assign 1 240 772
new 0 240 772
assign 1 240 773
isTrue 1 240 773
assign 1 241 774
new 0 241 774
assign 1 242 775
new 0 242 775
assign 1 242 776
get 1 242 776
assign 1 243 777
def 1 243 782
assign 1 243 783
isEmptyGet 0 243 783
assign 1 243 784
not 0 243 784
assign 1 0 786
assign 1 0 789
assign 1 0 793
assign 1 244 796
linkedListIteratorGet 0 0 796
assign 1 244 799
hasNextGet 0 244 799
assign 1 244 801
nextGet 0 244 801
put 1 245 802
assign 1 248 809
new 0 248 809
assign 1 248 810
isTrue 1 248 810
assign 1 249 811
new 0 249 811
assign 1 249 812
isTrue 1 249 812
assign 1 250 813
new 0 250 813
assign 1 250 814
isTrue 1 250 814
assign 1 251 815
new 0 251 815
assign 1 251 816
new 0 251 816
assign 1 251 817
isTrue 2 251 817
assign 1 252 818
new 0 252 818
assign 1 252 819
get 1 252 819
assign 1 253 820
new 0 253 820
assign 1 253 821
get 1 253 821
assign 1 254 822
new 0 254 822
assign 1 254 823
new 0 254 823
assign 1 254 824
get 2 254 824
assign 1 254 825
firstGet 0 254 825
assign 1 255 826
new 0 255 826
assign 1 255 827
new 0 255 827
assign 1 255 828
get 2 255 828
assign 1 255 829
firstGet 0 255 829
assign 1 256 830
new 0 256 830
assign 1 256 831
add 1 256 831
assign 1 256 832
new 0 256 832
assign 1 256 833
get 2 256 833
assign 1 256 834
firstGet 0 256 834
assign 1 257 835
new 0 257 835
assign 1 258 836
new 0 258 836
assign 1 259 837
new 0 259 837
assign 1 260 838
new 0 260 838
assign 1 261 839
new 0 261 839
assign 1 264 840
def 1 264 845
assign 1 265 846
firstGet 0 265 846
assign 1 267 849
new 0 267 849
assign 1 274 851
new 0 274 851
assign 1 274 852
add 1 274 852
assign 1 274 853
nameGet 0 274 853
assign 1 274 854
add 1 274 854
assign 1 274 855
get 1 274 855
assign 1 275 856
def 1 275 861
assign 1 276 862
orderedGet 0 276 862
addAll 1 276 863
assign 1 279 865
new 0 279 865
assign 1 279 866
add 1 279 866
assign 1 279 867
get 1 279 867
assign 1 280 868
def 1 280 873
assign 1 281 874
orderedGet 0 281 874
addAll 1 281 875
assign 1 284 877
new 0 284 877
assign 1 285 878
orderedGet 0 285 878
assign 1 285 879
iteratorGet 0 0 879
assign 1 285 882
hasNextGet 0 285 882
assign 1 285 884
nextGet 0 285 884
assign 1 286 885
new 1 286 885
addValue 1 286 886
assign 1 288 892
newlineGet 0 288 892
assign 1 289 893
assign 1 290 894
new 1 290 894
assign 1 292 895
copy 0 292 895
assign 1 293 896
fileGet 0 293 896
assign 1 293 897
existsGet 0 293 897
assign 1 293 898
not 0 293 898
assign 1 294 900
fileGet 0 294 900
makeDirs 0 294 901
assign 1 296 903
def 1 296 908
assign 1 297 909
new 1 297 909
assign 1 297 910
readerGet 0 297 910
assign 1 298 911
open 0 298 911
assign 1 298 912
readString 1 298 912
close 0 299 913
assign 1 305 927
classNameGet 0 305 927
assign 1 306 928
add 1 306 928
assign 1 306 929
new 0 306 929
assign 1 306 930
add 1 306 930
assign 1 306 931
toString 0 306 931
assign 1 306 932
add 1 306 932
assign 1 307 933
add 1 307 933
assign 1 307 934
new 0 307 934
assign 1 307 935
add 1 307 935
assign 1 307 936
toString 0 307 936
assign 1 307 937
add 1 307 937
return 1 308 938
assign 1 312 978
new 0 312 978
assign 1 313 979
classesGet 0 313 979
assign 1 313 980
valueIteratorGet 0 313 980
assign 1 313 983
hasNextGet 0 313 983
assign 1 314 985
nextGet 0 314 985
assign 1 315 986
shouldEmitGet 0 315 986
assign 1 315 987
heldGet 0 315 987
assign 1 315 988
fromFileGet 0 315 988
assign 1 315 989
has 1 315 989
assign 1 316 991
heldGet 0 316 991
assign 1 316 992
namepathGet 0 316 992
assign 1 316 993
toString 0 316 993
put 1 316 994
assign 1 317 995
usedByGet 0 317 995
assign 1 317 996
heldGet 0 317 996
assign 1 317 997
namepathGet 0 317 997
assign 1 317 998
toString 0 317 998
assign 1 317 999
get 1 317 999
assign 1 318 1000
def 1 318 1005
assign 1 319 1006
setIteratorGet 0 0 1006
assign 1 319 1009
hasNextGet 0 319 1009
assign 1 319 1011
nextGet 0 319 1011
put 1 320 1012
assign 1 323 1019
subClassesGet 0 323 1019
assign 1 323 1020
heldGet 0 323 1020
assign 1 323 1021
namepathGet 0 323 1021
assign 1 323 1022
toString 0 323 1022
assign 1 323 1023
get 1 323 1023
assign 1 324 1024
def 1 324 1029
assign 1 325 1030
setIteratorGet 0 0 1030
assign 1 325 1033
hasNextGet 0 325 1033
assign 1 325 1035
nextGet 0 325 1035
put 1 326 1036
assign 1 331 1049
classesGet 0 331 1049
assign 1 331 1050
valueIteratorGet 0 331 1050
assign 1 331 1053
hasNextGet 0 331 1053
assign 1 332 1055
nextGet 0 332 1055
assign 1 333 1056
heldGet 0 333 1056
assign 1 333 1057
heldGet 0 333 1057
assign 1 333 1058
namepathGet 0 333 1058
assign 1 333 1059
toString 0 333 1059
assign 1 333 1060
has 1 333 1060
shouldWriteSet 1 333 1061
assign 1 340 1071
new 0 340 1071
return 1 340 1072
assign 1 344 1086
def 1 344 1091
return 1 345 1092
assign 1 350 1094
def 1 350 1099
assign 1 351 1100
firstGet 0 351 1100
assign 1 352 1101
new 0 352 1101
assign 1 352 1102
equals 1 352 1102
assign 1 353 1104
new 1 353 1104
assign 1 354 1107
new 0 354 1107
assign 1 354 1108
equals 1 354 1108
assign 1 355 1110
new 1 355 1110
assign 1 356 1113
new 0 356 1113
assign 1 356 1114
equals 1 356 1114
assign 1 357 1116
new 1 357 1116
assign 1 359 1119
new 0 359 1119
assign 1 359 1120
new 1 359 1120
throw 1 359 1121
dynConditionsAllSet 1 361 1125
return 1 362 1126
return 1 364 1128
assign 1 369 1229
new 0 369 1229
assign 1 369 1230
now 0 369 1230
assign 1 370 1231
new 0 370 1231
assign 1 371 1232
emitterGet 0 371 1232
assign 1 372 1233
def 1 372 1238
assign 1 373 1239
new 4 373 1239
put 1 374 1240
assign 1 376 1242
new 0 376 1242
assign 1 376 1243
add 1 376 1243
print 0 376 1244
assign 1 379 1247
new 0 379 1247
assign 1 381 1248
iteratorGet 0 0 1248
assign 1 381 1251
hasNextGet 0 381 1251
assign 1 381 1253
nextGet 0 381 1253
assign 1 382 1254
has 1 382 1254
assign 1 382 1255
not 0 382 1255
put 1 383 1257
assign 1 384 1258
new 2 384 1258
addValue 1 385 1259
assign 1 388 1266
iteratorGet 0 0 1266
assign 1 388 1269
hasNextGet 0 388 1269
assign 1 388 1271
nextGet 0 388 1271
assign 1 389 1272
has 1 389 1272
assign 1 389 1273
not 0 389 1273
put 1 390 1275
assign 1 391 1276
new 2 391 1276
addValue 1 392 1277
assign 1 393 1278
libNameGet 0 393 1278
put 1 393 1279
assign 1 398 1287
iteratorGet 0 398 1287
assign 1 398 1290
hasNextGet 0 398 1290
assign 1 399 1292
nextGet 0 399 1292
doParse 1 401 1293
buildSyns 1 403 1299
assign 1 406 1301
new 0 406 1301
assign 1 406 1302
now 0 406 1302
assign 1 406 1303
subtract 1 406 1303
assign 1 408 1305
new 0 408 1305
assign 1 408 1306
add 1 408 1306
print 0 408 1307
assign 1 410 1309
emitCommonGet 0 410 1309
assign 1 410 1310
def 1 410 1315
assign 1 412 1316
emitCommonGet 0 412 1316
doEmit 0 412 1317
assign 1 413 1318
new 0 413 1318
return 1 413 1319
setClassesToWrite 0 416 1322
libnameInfoGet 0 417 1323
assign 1 419 1324
classesGet 0 419 1324
assign 1 419 1325
valueIteratorGet 0 419 1325
assign 1 419 1328
hasNextGet 0 419 1328
assign 1 420 1330
nextGet 0 420 1330
doEmit 1 421 1331
emitMain 0 423 1337
emitCUInit 0 424 1338
assign 1 425 1339
classesGet 0 425 1339
assign 1 425 1340
valueIteratorGet 0 425 1340
assign 1 425 1343
hasNextGet 0 425 1343
assign 1 426 1345
nextGet 0 426 1345
emitSyn 1 427 1346
assign 1 431 1353
new 0 431 1353
assign 1 431 1354
now 0 431 1354
assign 1 431 1355
subtract 1 431 1355
assign 1 432 1356
def 1 432 1361
assign 1 433 1362
new 0 433 1362
assign 1 433 1363
add 1 433 1363
print 0 433 1364
assign 1 435 1366
new 0 435 1366
assign 1 435 1367
add 1 435 1367
print 0 435 1368
prepMake 1 438 1370
assign 1 442 1373
not 0 442 1373
make 1 443 1375
deployLibrary 1 444 1376
assign 1 446 1378
linkedListIteratorGet 0 0 1378
assign 1 446 1381
hasNextGet 0 446 1381
assign 1 446 1383
nextGet 0 446 1383
assign 1 447 1384
libnameInfoGet 0 447 1384
assign 1 447 1385
unitShlibGet 0 447 1385
assign 1 448 1386
emitPathGet 0 448 1386
assign 1 448 1387
copy 0 448 1387
assign 1 449 1388
stepsGet 0 449 1388
assign 1 449 1389
lastGet 0 449 1389
addStep 1 449 1390
assign 1 450 1391
fileGet 0 450 1391
assign 1 450 1392
existsGet 0 450 1392
assign 1 451 1394
fileGet 0 451 1394
delete 0 451 1395
assign 1 453 1397
fileGet 0 453 1397
assign 1 453 1398
existsGet 0 453 1398
assign 1 453 1399
not 0 453 1399
assign 1 454 1401
fileGet 0 454 1401
assign 1 454 1402
fileGet 0 454 1402
deployFile 2 454 1403
assign 1 458 1411
iteratorGet 0 458 1411
assign 1 459 1412
iteratorGet 0 459 1412
assign 1 461 1415
hasNextGet 0 461 1415
assign 1 461 1417
hasNextGet 0 461 1417
assign 1 0 1419
assign 1 0 1422
assign 1 0 1426
assign 1 462 1429
nextGet 0 462 1429
assign 1 462 1430
apNew 1 462 1430
assign 1 463 1431
emitPathGet 0 463 1431
assign 1 463 1432
copy 0 463 1432
assign 1 463 1433
toString 0 463 1433
assign 1 463 1434
new 0 463 1434
assign 1 463 1435
add 1 463 1435
assign 1 463 1436
nextGet 0 463 1436
assign 1 463 1437
add 1 463 1437
assign 1 463 1438
apNew 1 463 1438
assign 1 465 1439
fileGet 0 465 1439
assign 1 465 1440
existsGet 0 465 1440
assign 1 466 1442
fileGet 0 466 1442
delete 0 466 1443
assign 1 468 1445
fileGet 0 468 1445
assign 1 468 1446
existsGet 0 468 1446
assign 1 468 1447
not 0 468 1447
assign 1 469 1449
fileGet 0 469 1449
assign 1 469 1450
fileGet 0 469 1450
deployFile 2 469 1451
assign 1 474 1460
new 0 474 1460
assign 1 474 1461
now 0 474 1461
assign 1 474 1462
subtract 1 474 1462
assign 1 476 1463
def 1 476 1468
assign 1 477 1469
new 0 477 1469
assign 1 477 1470
add 1 477 1470
print 0 477 1471
assign 1 479 1473
def 1 479 1478
assign 1 480 1479
new 0 480 1479
assign 1 480 1480
add 1 480 1480
print 0 480 1481
assign 1 482 1483
def 1 482 1488
assign 1 483 1489
new 0 483 1489
assign 1 483 1490
add 1 483 1490
print 0 483 1491
assign 1 487 1494
new 0 487 1494
print 0 487 1495
assign 1 488 1496
run 2 488 1496
assign 1 489 1497
new 0 489 1497
assign 1 489 1498
add 1 489 1498
assign 1 489 1499
new 0 489 1499
assign 1 489 1500
add 1 489 1500
print 0 489 1501
return 1 490 1502
assign 1 492 1504
new 0 492 1504
return 1 492 1505
assign 1 496 1518
justParsedGet 0 496 1518
assign 1 496 1519
valueIteratorGet 0 496 1519
assign 1 496 1522
hasNextGet 0 496 1522
assign 1 497 1524
nextGet 0 497 1524
assign 1 498 1525
heldGet 0 498 1525
libNameSet 1 498 1526
assign 1 499 1527
getSyn 2 499 1527
libNameSet 1 500 1528
assign 1 502 1534
justParsedGet 0 502 1534
assign 1 502 1535
valueIteratorGet 0 502 1535
assign 1 502 1538
hasNextGet 0 502 1538
assign 1 503 1540
nextGet 0 503 1540
assign 1 504 1541
heldGet 0 504 1541
assign 1 504 1542
synGet 0 504 1542
checkInheritance 2 505 1543
integrate 1 506 1544
assign 1 508 1550
new 0 508 1550
justParsedSet 1 508 1551
assign 1 512 1579
heldGet 0 512 1579
assign 1 512 1580
synGet 0 512 1580
assign 1 512 1581
def 1 512 1586
assign 1 513 1587
heldGet 0 513 1587
assign 1 513 1588
synGet 0 513 1588
return 1 513 1589
assign 1 515 1591
heldGet 0 515 1591
libNameSet 1 515 1592
assign 1 516 1593
heldGet 0 516 1593
assign 1 516 1594
extendsGet 0 516 1594
assign 1 516 1595
undef 1 516 1600
assign 1 517 1601
new 1 517 1601
assign 1 519 1604
classesGet 0 519 1604
assign 1 519 1605
heldGet 0 519 1605
assign 1 519 1606
extendsGet 0 519 1606
assign 1 519 1607
toString 0 519 1607
assign 1 519 1608
get 1 519 1608
assign 1 521 1609
def 1 521 1614
assign 1 522 1615
heldGet 0 522 1615
libNameSet 1 522 1616
assign 1 523 1617
getSyn 2 523 1617
assign 1 526 1620
heldGet 0 526 1620
assign 1 526 1621
extendsGet 0 526 1621
assign 1 526 1622
loadSyn 1 526 1622
assign 1 528 1624
new 2 528 1624
assign 1 530 1626
heldGet 0 530 1626
synSet 1 530 1627
assign 1 531 1628
heldGet 0 531 1628
assign 1 531 1629
namepathGet 0 531 1629
assign 1 531 1630
toString 0 531 1630
addSynClass 2 531 1631
return 1 532 1632
assign 1 536 1640
toString 0 536 1640
assign 1 537 1641
synClassesGet 0 537 1641
assign 1 537 1642
get 1 537 1642
assign 1 538 1643
def 1 538 1648
return 1 539 1649
assign 1 545 1651
emitterGet 0 545 1651
assign 1 545 1652
loadSyn 1 545 1652
addSynClass 2 546 1653
return 1 547 1654
assign 1 554 1658
undef 1 554 1663
assign 1 555 1664
new 1 555 1664
return 1 557 1666
assign 1 562 1745
new 1 562 1745
assign 1 563 1746
new 0 563 1746
assign 1 564 1747
emitterGet 0 564 1747
assign 1 565 1748
assign 1 566 1749
new 0 566 1749
assign 1 567 1750
shouldEmitGet 0 567 1750
put 1 567 1751
assign 1 0 1754
assign 1 0 1758
assign 1 0 1761
assign 1 570 1765
new 0 570 1765
assign 1 570 1766
toString 0 570 1766
assign 1 570 1767
add 1 570 1767
print 0 570 1768
assign 1 572 1770
assign 1 574 1771
fileGet 0 574 1771
assign 1 574 1772
readerGet 0 574 1772
assign 1 574 1773
open 0 574 1773
assign 1 574 1774
readBuffer 1 574 1774
assign 1 575 1775
fileGet 0 575 1775
assign 1 575 1776
readerGet 0 575 1776
close 0 575 1777
assign 1 576 1778
tokenize 1 576 1778
assign 1 584 1780
new 0 584 1780
echo 0 584 1781
assign 1 586 1783
outermostGet 0 586 1783
nodify 2 586 1784
assign 1 588 1786
new 0 588 1786
print 0 588 1787
assign 1 589 1788
new 2 589 1788
traverse 1 589 1789
assign 1 593 1792
new 0 593 1792
echo 0 593 1793
assign 1 595 1795
new 0 595 1795
traverse 1 595 1796
assign 1 597 1798
new 0 597 1798
print 0 597 1799
assign 1 598 1800
new 2 598 1800
traverse 1 598 1801
assign 1 601 1804
new 0 601 1804
echo 0 601 1805
assign 1 604 1807
new 0 604 1807
traverse 1 604 1808
contain 0 605 1809
assign 1 607 1811
new 0 607 1811
print 0 607 1812
assign 1 608 1813
new 2 608 1813
traverse 1 608 1814
assign 1 612 1817
new 0 612 1817
echo 0 612 1818
assign 1 614 1820
new 0 614 1820
traverse 1 614 1821
assign 1 616 1823
new 0 616 1823
print 0 616 1824
assign 1 617 1825
new 2 617 1825
traverse 1 617 1826
assign 1 621 1829
new 0 621 1829
echo 0 621 1830
assign 1 623 1832
new 0 623 1832
traverse 1 623 1833
assign 1 625 1835
new 0 625 1835
print 0 625 1836
assign 1 626 1837
new 2 626 1837
traverse 1 626 1838
assign 1 630 1841
new 0 630 1841
echo 0 630 1842
assign 1 632 1844
new 0 632 1844
traverse 1 632 1845
assign 1 634 1847
new 0 634 1847
print 0 634 1848
assign 1 635 1849
new 2 635 1849
traverse 1 635 1850
assign 1 639 1853
new 0 639 1853
echo 0 639 1854
assign 1 641 1856
new 0 641 1856
traverse 1 641 1857
assign 1 643 1859
new 0 643 1859
print 0 643 1860
assign 1 644 1861
new 2 644 1861
traverse 1 644 1862
assign 1 648 1865
new 0 648 1865
echo 0 648 1866
assign 1 650 1868
new 0 650 1868
traverse 1 650 1869
assign 1 652 1871
new 0 652 1871
print 0 652 1872
assign 1 653 1873
new 2 653 1873
traverse 1 653 1874
assign 1 657 1877
new 0 657 1877
echo 0 657 1878
assign 1 659 1880
new 0 659 1880
traverse 1 659 1881
assign 1 661 1883
new 0 661 1883
print 0 661 1884
assign 1 662 1885
new 2 662 1885
traverse 1 662 1886
assign 1 666 1889
new 0 666 1889
echo 0 666 1890
assign 1 668 1892
new 0 668 1892
traverse 1 668 1893
assign 1 670 1895
new 0 670 1895
print 0 670 1896
assign 1 671 1897
new 2 671 1897
traverse 1 671 1898
assign 1 674 1901
new 0 674 1901
echo 0 674 1902
assign 1 676 1904
new 0 676 1904
traverse 1 676 1905
assign 1 678 1907
new 0 678 1907
print 0 678 1908
assign 1 679 1909
new 2 679 1909
traverse 1 679 1910
assign 1 683 1913
new 0 683 1913
echo 0 683 1914
assign 1 684 1915
new 0 684 1915
print 0 684 1916
assign 1 686 1918
new 0 686 1918
traverse 1 686 1919
assign 1 0 1921
assign 1 0 1925
assign 1 0 1928
assign 1 688 1932
new 0 688 1932
print 0 688 1933
assign 1 689 1934
new 2 689 1934
traverse 1 689 1935
assign 1 691 1937
classesGet 0 691 1937
assign 1 691 1938
valueIteratorGet 0 691 1938
assign 1 691 1941
hasNextGet 0 691 1941
assign 1 692 1943
nextGet 0 692 1943
assign 1 694 1944
transUnitGet 0 694 1944
assign 1 695 1945
new 1 695 1945
assign 1 696 1946
TRANSUNITGet 0 696 1946
typenameSet 1 696 1947
assign 1 697 1948
new 0 697 1948
assign 1 698 1949
heldGet 0 698 1949
assign 1 698 1950
emitsGet 0 698 1950
emitsSet 1 698 1951
heldSet 1 699 1952
delete 0 700 1953
addValue 1 701 1954
copyLoc 1 702 1955
reInitContained 0 708 1977
assign 1 709 1978
containedGet 0 709 1978
assign 1 710 1979
new 0 710 1979
assign 1 711 1980
new 0 711 1980
assign 1 711 1981
crGet 0 711 1981
assign 1 712 1982
linkedListIteratorGet 0 712 1982
assign 1 712 1985
hasNextGet 0 712 1985
assign 1 713 1987
new 1 713 1987
assign 1 714 1988
nextGet 0 714 1988
heldSet 1 714 1989
nlcSet 1 715 1990
assign 1 716 1991
heldGet 0 716 1991
assign 1 716 1992
equals 1 716 1992
assign 1 717 1994
increment 0 717 1994
assign 1 719 1996
heldGet 0 719 1996
assign 1 719 1997
notEquals 1 719 1997
addValue 1 720 1999
containerSet 1 721 2000
return 1 0 2010
assign 1 0 2013
return 1 0 2017
assign 1 0 2020
return 1 0 2024
assign 1 0 2027
return 1 0 2031
assign 1 0 2034
return 1 0 2038
assign 1 0 2041
return 1 0 2045
assign 1 0 2048
return 1 0 2052
assign 1 0 2055
return 1 0 2059
assign 1 0 2062
return 1 0 2066
assign 1 0 2069
return 1 0 2073
assign 1 0 2076
return 1 0 2080
assign 1 0 2083
return 1 0 2087
assign 1 0 2090
return 1 0 2094
assign 1 0 2097
return 1 0 2101
assign 1 0 2104
return 1 0 2108
assign 1 0 2111
return 1 0 2115
assign 1 0 2118
return 1 0 2122
assign 1 0 2125
return 1 0 2129
assign 1 0 2132
return 1 0 2136
assign 1 0 2139
return 1 0 2143
assign 1 0 2146
return 1 0 2150
assign 1 0 2153
return 1 0 2157
assign 1 0 2160
return 1 0 2164
assign 1 0 2167
return 1 0 2171
assign 1 0 2174
return 1 0 2178
assign 1 0 2181
return 1 0 2185
assign 1 0 2188
return 1 0 2192
assign 1 0 2195
return 1 0 2199
assign 1 0 2202
return 1 0 2206
assign 1 0 2209
return 1 0 2213
assign 1 0 2216
return 1 0 2220
assign 1 0 2223
return 1 0 2227
assign 1 0 2230
return 1 0 2234
assign 1 0 2237
return 1 0 2241
assign 1 0 2244
return 1 0 2248
assign 1 0 2251
return 1 0 2255
assign 1 0 2258
return 1 0 2262
assign 1 0 2265
return 1 0 2269
assign 1 0 2272
return 1 0 2276
assign 1 0 2279
return 1 0 2283
assign 1 0 2286
return 1 0 2290
assign 1 0 2293
return 1 0 2297
assign 1 0 2300
return 1 0 2304
assign 1 0 2307
return 1 0 2311
assign 1 0 2314
return 1 0 2318
assign 1 0 2321
return 1 0 2325
assign 1 0 2328
return 1 0 2332
assign 1 0 2335
return 1 0 2339
assign 1 0 2342
return 1 0 2346
assign 1 0 2349
return 1 0 2353
assign 1 0 2356
return 1 0 2360
assign 1 0 2363
return 1 0 2367
assign 1 0 2370
return 1 0 2374
assign 1 0 2377
return 1 0 2381
assign 1 0 2384
return 1 0 2388
assign 1 0 2391
return 1 0 2395
assign 1 0 2398
return 1 0 2402
assign 1 0 2405
return 1 0 2409
assign 1 0 2412
return 1 0 2416
assign 1 0 2419
return 1 0 2423
assign 1 0 2426
return 1 0 2430
assign 1 0 2433
return 1 0 2437
assign 1 0 2440
return 1 0 2444
assign 1 0 2447
return 1 0 2451
assign 1 0 2454
return 1 0 2458
assign 1 0 2461
return 1 0 2465
assign 1 0 2468
return 1 0 2472
assign 1 0 2475
return 1 0 2479
assign 1 0 2482
assign 1 0 2486
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1308786538: return bem_echo_0();
case 404051026: return bem_printPlacesGet_0();
case 729571811: return bem_serializeToString_0();
case 2113443821: return bem_deployLibraryGet_0();
case 34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case 340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case 580139405: return bem_config_0();
case 2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case 1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case 1803479881: return bem_libNameGet_0();
case 314718434: return bem_print_0();
case 2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case 186098742: return bem_exeNameGet_0();
case 1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case 829911139: return bem_compilerProfileGet_0();
case 1012494862: return bem_once_0();
case 1081412016: return bem_many_0();
case 1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case 658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case 2082855574: return bem_emitDataGet_0();
case 786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case 2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case 271866114: return bem_ownProcessGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case 1919619119: return bem_setClassesToWrite_0();
case 2127864150: return bem_argsGet_0();
case 400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case 1003238764: return bem_parseGet_0();
case 902949587: return bem_printStepsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case 1505775346: return bem_putLineNumbersInTraceGet_0();
case 1713520961: return bem_linkLibArgsGet_0();
case 1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case 644675716: return bem_ntypesGet_0();
case 1185503219: return bem_deployFilesFromGet_0();
case 1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case 1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case 1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case 560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case 733055122: return bem_makeNameGet_0();
case 328200718: return bem_printAstGet_0();
case 126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case 1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case 1458327669: return bem_emitFileHeaderGet_0();
case 1220511308: return bem_buildSucceededGet_0();
case 845792839: return bem_iteratorGet_0();
case 1149621350: return bem_codeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 505952126: return bem_copyTo_1(bevd_0);
case 392968773: return bem_printPlacesSet_1(bevd_0);
case 2071773321: return bem_emitDataSet_1(bevd_0);
case 1467862522: return bem_printAllAstSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 1702438708: return bem_linkLibArgsSet_1(bevd_0);
case 891867334: return bem_printStepsSet_1(bevd_0);
case 647691617: return bem_usedLibrarysSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 721972869: return bem_makeNameSet_1(bevd_0);
case 175016489: return bem_exeNameSet_1(bevd_0);
case 972018826: return bem_dllhead_1((BEC_4_6_TextString) bevd_0);
case 317118465: return bem_printAstSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case 2014823769: return bem_includePathSet_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 115429536: return bem_outputPlatformSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 818828886: return bem_compilerProfileSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case 1685807348: return bem_emitLibrarySet_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1094759839: return bem_process_1((BEC_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1012817098: return bem_doEmitSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case 706249818: return bem_getSynNp_1(bevd_0);
case 1310359934: return bem_emitLangsSet_1(bevd_0);
case 329197947: return bem_startTimeSet_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 549675370: return bem_emitCommonSet_1(bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case 1209429055: return bem_buildSucceededSet_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case 1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 389838008: return bem_estrSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case 2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1138539097: return bem_codeSet_1(bevd_0);
case 23863370: return bem_builtSet_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case 2036609109: return bem_buildSyns_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case 992156511: return bem_parseSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case 1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case 260783861: return bem_ownProcessSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
case 1495142466: return bem_readBufferSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case 2116781897: return bem_argsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1081571541: return bem_main_1((BEC_9_5_ContainerArray) bevd_0);
case 593264218: return bem_isNewish_1((BEC_4_6_TextString) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2102361568: return bem_deployLibrarySet_1(bevd_0);
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case 2085986340: return bem_emitPathSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_9_10_ContainerLinkedList) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_BuildBuild.bevs_inst = (BEC_5_5_BuildBuild)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_BuildBuild.bevs_inst;
}
}
