package be.BEL_4_Base;
/* IO:File: source/base/Array.be */
public class BEC_2_9_5_ContainerArray extends BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerArray() { }

   
    public BEC_2_6_6_SystemObject[] bevi_array;
    
   
   
   public BEC_2_9_5_ContainerArray(BEC_2_6_6_SystemObject[] bevi_array) {
        this.bevi_array = bevi_array;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_array.length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_array.length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x41,0x72,0x72,0x61,0x79,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(16));
private static byte[] bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bevo_7 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bevo_15 = (new BEC_2_4_3_MathInt(2));
public static BEC_2_9_5_ContainerArray bevs_inst;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public BEC_2_9_5_ContainerArray bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_1_tmpvar_phold.bem_once_0();
bevt_3_tmpvar_phold = bevo_1;
bevt_2_tmpvar_phold = (BEC_2_4_3_MathInt) bevt_3_tmpvar_phold.bem_once_0();
this.bem_new_2(bevt_0_tmpvar_phold, bevt_2_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_new_1(BEC_2_4_3_MathInt beva_leni) throws Throwable {
this.bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
if (beva_leni == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
if (beva_capi == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 145 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 145 */ {
bevt_4_tmpvar_phold = (new BEC_2_4_6_TextString(61, bels_0));
bevt_3_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 146 */
if (bevp_length == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 148 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 151 */ {
return this;
} /* Line: 152 */
} /* Line: 151 */

      bevi_array = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = beva_leni.bem_copy_0();
bevp_capacity = beva_capi.bem_copy_0();
bevp_multiplier = bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 179 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 180 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_varrayGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_varraySet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_length.bem_toString_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
this.bem_new_1(bevt_0_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_4;
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_5;
bevt_1_tmpvar_phold = bevp_length.bem_subtract_1(bevt_2_tmpvar_phold);
bevt_0_tmpvar_phold = this.bem_get_1(bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 212 */ {
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(36, bels_1));
bevt_2_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_2_tmpvar_phold);
} /* Line: 213 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 215 */ {
bevt_6_tmpvar_phold = bevo_7;
bevt_5_tmpvar_phold = beva_posi.bem_add_1(bevt_6_tmpvar_phold);
this.bem_lengthSet_1(bevt_5_tmpvar_phold);
} /* Line: 216 */

      this.bevi_array[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) throws Throwable {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_2_tmpvar_phold = bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 227 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 227 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 227 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 227 */
 else  /* Line: 227 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 227 */ {

      bevl_val = this.bevi_array[beva_posi.bevi_int];
      } /* Line: 228 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_1_tmpvar_phold = bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpvar_phold);
bevl_i = beva_pos;
while (true)
 /* Line: 240 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 240 */ {
bevt_5_tmpvar_phold = bevo_10;
bevt_4_tmpvar_phold = bevl_i.bem_add_1(bevt_5_tmpvar_phold);
bevt_3_tmpvar_phold = this.bem_get_1(bevt_4_tmpvar_phold);
this.bem_put_2(bevl_i, bevt_3_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 240 */
 else  /* Line: 240 */ {
break;
} /* Line: 240 */
} /* Line: 240 */
this.bem_put_2(bevl_fl, null);
bevt_7_tmpvar_phold = bevo_11;
bevt_6_tmpvar_phold = bevp_length.bem_subtract_1(bevt_7_tmpvar_phold);
this.bem_lengthSet_1(bevt_6_tmpvar_phold);
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_8_tmpvar_phold;
} /* Line: 245 */
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_3_9_5_8_ContainerArrayIterator bem_arrayIteratorGet_0() throws Throwable {
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_3_9_5_8_ContainerArrayIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_clear_0() throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 259 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 259 */ {
this.bem_put_2(bevl_i, null);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 259 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_copy_0() throws Throwable {
BEC_2_9_5_ContainerArray bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevl_n = this.bem_create_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 266 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 266 */ {
bevt_1_tmpvar_phold = this.bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpvar_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 266 */
 else  /* Line: 266 */ {
break;
} /* Line: 266 */
} /* Line: 266 */
return (BEC_2_9_5_ContainerArray) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) throws Throwable {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_9_5_ContainerArray()).bem_new_1(beva_len);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_create_0() throws Throwable {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevp_length);
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_add_1(BEC_2_9_5_ContainerArray beva_xi) throws Throwable {
BEC_2_9_5_ContainerArray bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_1_tmpvar_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_4_tmpvar_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpvar_phold = bevp_length.bem_add_1(bevt_4_tmpvar_phold);
bevl_yi = (new BEC_2_9_5_ContainerArray()).bem_new_2(bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
bevt_0_tmpvar_loop = this.bem_arrayIteratorGet_0();
while (true)
 /* Line: 278 */ {
bevt_5_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevl_c = bevt_0_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 279 */
 else  /* Line: 278 */ {
break;
} /* Line: 278 */
} /* Line: 278 */
bevt_1_tmpvar_loop = beva_xi.bem_arrayIteratorGet_0();
while (true)
 /* Line: 281 */ {
bevt_6_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevl_c = bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 282 */
 else  /* Line: 281 */ {
break;
} /* Line: 281 */
} /* Line: 281 */
return (BEC_2_9_5_ContainerArray) bevl_yi;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_sort_0() throws Throwable {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_mergeSort_0();
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_sortValue_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
this.bem_sortValue_2(bevt_0_tmpvar_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevl_i = beva_start;
while (true)
 /* Line: 296 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevl_c = bevl_i;
bevl_j = bevl_i;
while (true)
 /* Line: 298 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 298 */ {
bevt_3_tmpvar_phold = this.bem_get_1(bevl_j);
bevt_4_tmpvar_phold = this.bem_get_1(bevl_c);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 299 */ {
bevl_c = bevl_j;
} /* Line: 300 */
bevl_j = bevl_j.bem_increment_0();
} /* Line: 298 */
 else  /* Line: 298 */ {
break;
} /* Line: 298 */
} /* Line: 298 */
bevl_hold = this.bem_get_1(bevl_i);
bevt_5_tmpvar_phold = this.bem_get_1(bevl_c);
this.bem_put_2(bevl_i, bevt_5_tmpvar_phold);
this.bem_put_2(bevl_c, bevl_hold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 296 */
 else  /* Line: 296 */ {
break;
} /* Line: 296 */
} /* Line: 296 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mergeIn_2(BEC_2_9_5_ContainerArray beva_first, BEC_2_9_5_ContainerArray beva_second) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
bevl_fi = (new BEC_2_4_3_MathInt(0));
bevl_si = (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 315 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 315 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 316 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 316 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 316 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 316 */
 else  /* Line: 316 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 316 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpvar_phold = bevl_so.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_fo);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 319 */ {
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 321 */
 else  /* Line: 322 */ {
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 324 */
} /* Line: 319 */
 else  /* Line: 316 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 326 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si = bevl_si.bem_increment_0();
this.bem_put_2(bevl_i, bevl_so);
} /* Line: 329 */
 else  /* Line: 316 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 330 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi = bevl_fi.bem_increment_0();
this.bem_put_2(bevl_i, bevl_fo);
} /* Line: 333 */
} /* Line: 316 */
} /* Line: 316 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 335 */
 else  /* Line: 315 */ {
break;
} /* Line: 315 */
} /* Line: 315 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mergeSort_0() throws Throwable {
BEC_2_9_5_ContainerArray bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_0_tmpvar_phold = this.bem_mergeSort_2(bevt_1_tmpvar_phold, bevp_length);
return (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_5_ContainerArray bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_5_ContainerArray bevl_fa = null;
BEC_2_9_5_ContainerArray bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpvar_phold = bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevt_3_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_2_tmpvar_phold = this.bem_create_1(bevt_3_tmpvar_phold);
return (BEC_2_9_5_ContainerArray) bevt_2_tmpvar_phold;
} /* Line: 346 */
 else  /* Line: 345 */ {
bevt_5_tmpvar_phold = bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpvar_phold.bevi_int) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 347 */ {
bevt_6_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_5_ContainerArray) this.bem_create_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_8_tmpvar_phold = this.bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpvar_phold, bevt_8_tmpvar_phold);
return (BEC_2_9_5_ContainerArray) bevl_ra;
} /* Line: 350 */
 else  /* Line: 351 */ {
bevt_9_tmpvar_phold = bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpvar_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = this.bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = this.bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_5_ContainerArray) this.bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_5_ContainerArray) bevl_ra;
} /* Line: 359 */
} /* Line: 345 */
} /*method end*/
public BEC_2_6_6_SystemObject bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 364 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_2));
bevt_1_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 365 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) throws Throwable {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 371 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         this.bevi_array = java.util.Arrays.copyOf(this.bevi_array, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 388 */
while (true)
 /* Line: 391 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 391 */ {

         this.bevi_array[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 397 */
 else  /* Line: 391 */ {
break;
} /* Line: 391 */
} /* Line: 391 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 403 */ {
while (true)
 /* Line: 404 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 404 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 405 */
 else  /* Line: 404 */ {
break;
} /* Line: 404 */
} /* Line: 404 */
} /* Line: 404 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_addAll_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 411 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 412 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 417 */ {

       this.bevi_array[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 423 */
 else  /* Line: 424 */ {
bevt_1_tmpvar_phold = bevp_length.bem_copy_0();
this.bem_put_2(bevt_1_tmpvar_phold, beva_val);
} /* Line: 426 */
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_addValue_1(BEC_2_6_6_SystemObject beva_val) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 431 */ {
bevt_2_tmpvar_phold = beva_val.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 431 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 431 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 431 */
 else  /* Line: 431 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 431 */ {
this.bem_addAll_1(beva_val);
} /* Line: 432 */
 else  /* Line: 433 */ {
this.bem_addValueWhole_1(beva_val);
} /* Line: 434 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 440 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 440 */ {
bevl_aval = this.bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 442 */ {
bevt_3_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 442 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 442 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 442 */
 else  /* Line: 442 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 442 */ {
return bevl_i;
} /* Line: 443 */
bevl_i.bevi_int++;
} /* Line: 440 */
 else  /* Line: 440 */ {
break;
} /* Line: 440 */
} /* Line: 440 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_find_1(beva_value);
if (bevt_1_tmpvar_phold == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 450 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 451 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_0_tmpvar_phold = this.bem_sortedFind_2(beva_value, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) throws Throwable {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
bevl_high = bevp_length;
bevl_low = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 470 */ {
bevt_3_tmpvar_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpvar_phold = bevo_15;
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_divide_1(bevt_4_tmpvar_phold);
bevl_mid = bevt_2_tmpvar_phold.bem_add_1(bevl_low);
bevl_aval = this.bem_get_1(bevl_mid);
bevt_5_tmpvar_phold = beva_value.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevl_aval);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 473 */ {
return bevl_mid;
} /* Line: 474 */
 else  /* Line: 473 */ {
bevt_6_tmpvar_phold = beva_value.bemd_1(1958502700, BEL_4_Base.bevn_greater_1, bevl_aval);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 475 */ {
bevl_low = bevl_mid;
} /* Line: 477 */
 else  /* Line: 473 */ {
bevt_7_tmpvar_phold = beva_value.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_aval);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 478 */ {
bevl_high = bevl_mid;
} /* Line: 480 */
} /* Line: 473 */
} /* Line: 473 */
if (bevl_lastMid == null) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 483 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 483 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 483 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 483 */
 else  /* Line: 483 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 483 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 484 */ {
bevt_11_tmpvar_phold = this.bem_get_1(bevl_low);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, beva_value);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 484 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 484 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 484 */
 else  /* Line: 484 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 484 */ {
return bevl_low;
} /* Line: 485 */
return null;
} /* Line: 487 */
bevl_lastMid = bevl_mid;
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 490 */ {
return null;
} /* Line: 491 */
} /* Line: 490 */
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() throws Throwable {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() throws Throwable {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() throws Throwable {
return bevp_multiplier;
} /*method end*/
public BEC_2_6_6_SystemObject bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {137, 137, 137, 137, 137, 141, 145, 145, 0, 145, 145, 0, 0, 146, 146, 146, 148, 148, 151, 151, 152, 168, 169, 170, 175, 179, 179, 179, 180, 180, 182, 182, 192, 192, 196, 196, 200, 200, 204, 204, 204, 208, 208, 208, 208, 212, 212, 212, 213, 213, 213, 215, 215, 216, 216, 216, 227, 227, 227, 227, 227, 0, 0, 0, 234, 238, 238, 239, 239, 240, 240, 240, 241, 241, 241, 241, 240, 243, 244, 244, 244, 245, 245, 247, 247, 251, 251, 255, 255, 259, 259, 259, 260, 259, 265, 266, 266, 266, 267, 267, 266, 269, 272, 272, 274, 274, 277, 277, 277, 277, 278, 0, 278, 278, 279, 281, 0, 281, 281, 282, 284, 288, 288, 292, 292, 296, 296, 296, 297, 298, 298, 298, 299, 299, 299, 300, 298, 303, 304, 304, 305, 296, 310, 311, 312, 313, 314, 315, 315, 316, 316, 316, 316, 0, 0, 0, 317, 318, 319, 320, 321, 323, 324, 326, 326, 327, 328, 329, 330, 330, 331, 332, 333, 335, 340, 340, 340, 344, 345, 345, 345, 346, 346, 346, 347, 347, 347, 348, 348, 349, 349, 349, 350, 352, 352, 353, 354, 355, 356, 357, 358, 359, 364, 365, 365, 365, 371, 371, 372, 388, 391, 391, 397, 399, 403, 403, 404, 405, 405, 411, 411, 412, 412, 417, 417, 423, 426, 426, 431, 431, 431, 0, 0, 0, 432, 434, 440, 440, 440, 441, 442, 442, 442, 0, 0, 0, 443, 440, 446, 450, 450, 450, 451, 451, 453, 453, 459, 459, 459, 466, 467, 471, 471, 471, 471, 472, 473, 474, 475, 477, 478, 480, 483, 483, 483, 483, 0, 0, 0, 484, 484, 0, 0, 0, 485, 487, 489, 490, 491, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {48, 49, 50, 51, 52, 56, 67, 72, 73, 76, 81, 82, 85, 89, 90, 91, 93, 98, 99, 104, 105, 110, 111, 112, 116, 123, 124, 129, 130, 131, 133, 134, 144, 145, 149, 150, 155, 156, 161, 162, 163, 169, 170, 171, 172, 182, 183, 188, 189, 190, 191, 193, 198, 199, 200, 201, 213, 214, 219, 220, 225, 226, 229, 233, 239, 254, 259, 260, 261, 262, 265, 270, 271, 272, 273, 274, 275, 281, 282, 283, 284, 285, 286, 288, 289, 293, 294, 298, 299, 304, 307, 312, 313, 314, 327, 328, 331, 336, 337, 338, 339, 345, 349, 350, 354, 355, 367, 368, 369, 370, 371, 371, 374, 376, 377, 383, 383, 386, 388, 389, 395, 399, 400, 404, 405, 419, 422, 427, 428, 429, 432, 437, 438, 439, 440, 442, 444, 450, 451, 452, 453, 454, 477, 478, 479, 480, 481, 484, 489, 490, 495, 496, 501, 502, 505, 509, 512, 513, 514, 516, 517, 520, 521, 525, 530, 531, 532, 533, 536, 541, 542, 543, 544, 548, 559, 560, 561, 581, 582, 583, 588, 589, 590, 591, 594, 595, 600, 601, 602, 603, 604, 605, 606, 609, 610, 611, 612, 613, 614, 615, 616, 617, 625, 627, 628, 629, 637, 642, 643, 646, 650, 655, 658, 664, 671, 676, 679, 681, 682, 694, 699, 700, 701, 708, 713, 716, 719, 720, 728, 733, 734, 736, 739, 743, 746, 749, 760, 763, 768, 769, 770, 775, 776, 778, 781, 785, 788, 790, 796, 803, 804, 809, 810, 811, 813, 814, 819, 820, 821, 842, 843, 846, 847, 848, 849, 850, 851, 853, 856, 858, 861, 863, 867, 872, 873, 878, 879, 882, 886, 890, 891, 893, 896, 900, 903, 905, 907, 908, 910, 915, 918, 921, 924};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 137 48
new 0 137 48
assign 1 137 49
once 0 137 49
assign 1 137 50
new 0 137 50
assign 1 137 51
once 0 137 51
new 2 137 52
new 2 141 56
assign 1 145 67
undef 1 145 72
assign 1 0 73
assign 1 145 76
undef 1 145 81
assign 1 0 82
assign 1 0 85
assign 1 146 89
new 0 146 89
assign 1 146 90
new 1 146 90
throw 1 146 91
assign 1 148 93
def 1 148 98
assign 1 151 99
equals 1 151 104
return 1 152 105
assign 1 168 110
copy 0 168 110
assign 1 169 111
copy 0 169 111
assign 1 170 112
new 0 170 112
return 1 175 116
assign 1 179 123
new 0 179 123
assign 1 179 124
equals 1 179 129
assign 1 180 130
new 0 180 130
return 1 180 131
assign 1 182 133
new 0 182 133
return 1 182 134
assign 1 192 144
toString 0 192 144
return 1 192 145
assign 1 196 149
new 1 196 149
new 1 196 150
assign 1 200 155
iteratorGet 0 200 155
return 1 200 156
assign 1 204 161
new 0 204 161
assign 1 204 162
get 1 204 162
return 1 204 163
assign 1 208 169
new 0 208 169
assign 1 208 170
subtract 1 208 170
assign 1 208 171
get 1 208 171
return 1 208 172
assign 1 212 182
new 0 212 182
assign 1 212 183
lesser 1 212 188
assign 1 213 189
new 0 213 189
assign 1 213 190
new 1 213 190
throw 1 213 191
assign 1 215 193
greaterEquals 1 215 198
assign 1 216 199
new 0 216 199
assign 1 216 200
add 1 216 200
lengthSet 1 216 201
assign 1 227 213
new 0 227 213
assign 1 227 214
greaterEquals 1 227 219
assign 1 227 220
lesser 1 227 225
assign 1 0 226
assign 1 0 229
assign 1 0 233
return 1 234 239
assign 1 238 254
lesser 1 238 259
assign 1 239 260
new 0 239 260
assign 1 239 261
subtract 1 239 261
assign 1 240 262
assign 1 240 265
lesser 1 240 270
assign 1 241 271
new 0 241 271
assign 1 241 272
add 1 241 272
assign 1 241 273
get 1 241 273
put 2 241 274
assign 1 240 275
increment 0 240 275
put 2 243 281
assign 1 244 282
new 0 244 282
assign 1 244 283
subtract 1 244 283
lengthSet 1 244 284
assign 1 245 285
new 0 245 285
return 1 245 286
assign 1 247 288
new 0 247 288
return 1 247 289
assign 1 251 293
new 1 251 293
return 1 251 294
assign 1 255 298
new 1 255 298
return 1 255 299
assign 1 259 304
new 0 259 304
assign 1 259 307
lesser 1 259 312
put 2 260 313
assign 1 259 314
increment 0 259 314
assign 1 265 327
create 0 265 327
assign 1 266 328
new 0 266 328
assign 1 266 331
lesser 1 266 336
assign 1 267 337
get 1 267 337
put 2 267 338
assign 1 266 339
increment 0 266 339
return 1 269 345
assign 1 272 349
new 1 272 349
return 1 272 350
assign 1 274 354
new 1 274 354
return 1 274 355
assign 1 277 367
new 0 277 367
assign 1 277 368
lengthGet 0 277 368
assign 1 277 369
add 1 277 369
assign 1 277 370
new 2 277 370
assign 1 278 371
arrayIteratorGet 0 0 371
assign 1 278 374
hasNextGet 0 278 374
assign 1 278 376
nextGet 0 278 376
addValueWhole 1 279 377
assign 1 281 383
arrayIteratorGet 0 0 383
assign 1 281 386
hasNextGet 0 281 386
assign 1 281 388
nextGet 0 281 388
addValueWhole 1 282 389
return 1 284 395
assign 1 288 399
mergeSort 0 288 399
return 1 288 400
assign 1 292 404
new 0 292 404
sortValue 2 292 405
assign 1 296 419
assign 1 296 422
lesser 1 296 427
assign 1 297 428
assign 1 298 429
assign 1 298 432
lesser 1 298 437
assign 1 299 438
get 1 299 438
assign 1 299 439
get 1 299 439
assign 1 299 440
lesser 1 299 440
assign 1 300 442
assign 1 298 444
increment 0 298 444
assign 1 303 450
get 1 303 450
assign 1 304 451
get 1 304 451
put 2 304 452
put 2 305 453
assign 1 296 454
increment 0 296 454
assign 1 310 477
new 0 310 477
assign 1 311 478
new 0 311 478
assign 1 312 479
new 0 312 479
assign 1 313 480
lengthGet 0 313 480
assign 1 314 481
lengthGet 0 314 481
assign 1 315 484
lesser 1 315 489
assign 1 316 490
lesser 1 316 495
assign 1 316 496
lesser 1 316 501
assign 1 0 502
assign 1 0 505
assign 1 0 509
assign 1 317 512
get 1 317 512
assign 1 318 513
get 1 318 513
assign 1 319 514
lesser 1 319 514
assign 1 320 516
increment 0 320 516
put 2 321 517
assign 1 323 520
increment 0 323 520
put 2 324 521
assign 1 326 525
lesser 1 326 530
assign 1 327 531
get 1 327 531
assign 1 328 532
increment 0 328 532
put 2 329 533
assign 1 330 536
lesser 1 330 541
assign 1 331 542
get 1 331 542
assign 1 332 543
increment 0 332 543
put 2 333 544
assign 1 335 548
increment 0 335 548
assign 1 340 559
new 0 340 559
assign 1 340 560
mergeSort 2 340 560
return 1 340 561
assign 1 344 581
subtract 1 344 581
assign 1 345 582
new 0 345 582
assign 1 345 583
equals 1 345 588
assign 1 346 589
new 0 346 589
assign 1 346 590
create 1 346 590
return 1 346 591
assign 1 347 594
new 0 347 594
assign 1 347 595
equals 1 347 600
assign 1 348 601
new 0 348 601
assign 1 348 602
create 1 348 602
assign 1 349 603
new 0 349 603
assign 1 349 604
get 1 349 604
put 2 349 605
return 1 350 606
assign 1 352 609
new 0 352 609
assign 1 352 610
divide 1 352 610
assign 1 353 611
subtract 1 353 611
assign 1 354 612
add 1 354 612
assign 1 355 613
mergeSort 2 355 613
assign 1 356 614
mergeSort 2 356 614
assign 1 357 615
create 1 357 615
mergeIn 2 358 616
return 1 359 617
assign 1 364 625
new 0 364 625
assign 1 365 627
new 0 365 627
assign 1 365 628
new 1 365 628
throw 1 365 629
assign 1 371 637
greater 1 371 642
assign 1 372 643
multiply 1 372 643
assign 1 388 646
assign 1 391 650
lesser 1 391 655
incrementValue 0 397 658
setValue 1 399 664
assign 1 403 671
def 1 403 676
assign 1 404 679
hasNextGet 0 404 679
assign 1 405 681
nextGet 0 405 681
addValueWhole 1 405 682
assign 1 411 694
def 1 411 699
assign 1 412 700
iteratorGet 0 412 700
iterateAdd 1 412 701
assign 1 417 708
lesser 1 417 713
incrementValue 0 423 716
assign 1 426 719
copy 0 426 719
put 2 426 720
assign 1 431 728
def 1 431 733
assign 1 431 734
sameType 1 431 734
assign 1 0 736
assign 1 0 739
assign 1 0 743
addAll 1 432 746
addValueWhole 1 434 749
assign 1 440 760
new 0 440 760
assign 1 440 763
lesser 1 440 768
assign 1 441 769
get 1 441 769
assign 1 442 770
def 1 442 775
assign 1 442 776
equals 1 442 776
assign 1 0 778
assign 1 0 781
assign 1 0 785
return 1 443 788
incrementValue 0 440 790
return 1 446 796
assign 1 450 803
find 1 450 803
assign 1 450 804
def 1 450 809
assign 1 451 810
new 0 451 810
return 1 451 811
assign 1 453 813
new 0 453 813
return 1 453 814
assign 1 459 819
new 0 459 819
assign 1 459 820
sortedFind 2 459 820
return 1 459 821
assign 1 466 842
assign 1 467 843
new 0 467 843
assign 1 471 846
subtract 1 471 846
assign 1 471 847
new 0 471 847
assign 1 471 848
divide 1 471 848
assign 1 471 849
add 1 471 849
assign 1 472 850
get 1 472 850
assign 1 473 851
equals 1 473 851
return 1 474 853
assign 1 475 856
greater 1 475 856
assign 1 477 858
assign 1 478 861
lesser 1 478 861
assign 1 480 863
assign 1 483 867
def 1 483 872
assign 1 483 873
equals 1 483 878
assign 1 0 879
assign 1 0 882
assign 1 0 886
assign 1 484 890
get 1 484 890
assign 1 484 891
lesser 1 484 891
assign 1 0 893
assign 1 0 896
assign 1 0 900
return 1 485 903
return 1 487 905
assign 1 489 907
assign 1 490 908
new 0 490 908
return 1 491 910
return 1 0 915
return 1 0 918
return 1 0 921
assign 1 0 924
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1081412016: return bem_many_0();
case 1089531140: return bem_isEmptyGet_0();
case 188061735: return bem_mergeSort_0();
case 856777406: return bem_clear_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 1616433729: return bem_lengthGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 183400265: return bem_firstGet_0();
case 314718434: return bem_print_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1525854240: return bem_arrayIteratorGet_0();
case 474162694: return bem_sizeGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1484114352: return bem_varraySet_0();
case 1473032100: return bem_varrayGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 1478277476: return bem_sortValue_0();
case 729571811: return bem_serializeToString_0();
case 1990707345: return bem_lastGet_0();
case 1479417926: return bem_multiplierGet_0();
case 1751843603: return bem_capacityGet_0();
case 1354714650: return bem_copy_0();
case 896593457: return bem_sort_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 819712669: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 1627515982: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1820417454: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case 1740761350: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 1490500179: return bem_multiplierSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1274448085: return bem_find_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 99049420: return bem_has_1(bevd_0);
case 92659731: return bem_add_1((BEC_2_9_5_ContainerArray) bevd_0);
case 228068295: return bem_addValueWhole_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 518108232: return bem_sortedFind_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 518108233: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 188061737: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 104713555: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1478277478: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 107034370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1626710000: return bem_mergeIn_2((BEC_2_9_5_ContainerArray) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_5_ContainerArray();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_5_ContainerArray.bevs_inst = (BEC_2_9_5_ContainerArray)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_5_ContainerArray.bevs_inst;
}
}
