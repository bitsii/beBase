package be.BEL_4_Base;
/* IO:File: source/build/Pass12.be */
public class BEC_3_5_5_9_BuildVisitTypeCheck extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_9_BuildVisitTypeCheck() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x54,0x79,0x70,0x65,0x43,0x68,0x65,0x63,0x6B};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x43,0x61,0x74,0x63,0x68,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x73,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x75,0x6E,0x74,0x79,0x70,0x65,0x64,0x20,0x28,0x76,0x61,0x72,0x29};
private static byte[] bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_2 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_3 = {0x53,0x65,0x6C,0x66,0x20,0x6F,0x76,0x61,0x72,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x73,0x79,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bels_4 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x61,0x73,0x73,0x69,0x67,0x6E,0x6D,0x65,0x6E,0x74,0x2C,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_4, 30));
private static byte[] bels_5 = {0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x73,0x74,0x20,0x74,0x6F,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_5, 19));
private static byte[] bels_6 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_8 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x65,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x63,0x61,0x73,0x74,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x73,0x65,0x6C,0x66,0x20,0x74,0x79,0x70,0x65,0x2E,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_8, 67));
private static byte[] bels_9 = {0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_9, 1));
private static byte[] bels_10 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6F,0x6E,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2E};
private static byte[] bels_11 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bels_12 = {0x6E,0x65,0x77,0x4E,0x70,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x77,0x68,0x69,0x6C,0x65,0x20,0x74,0x79,0x70,0x65,0x63,0x68,0x65,0x63,0x6B,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_13 = {0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bels_14 = {0x47,0x6F,0x74,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6E,0x6E,0x6F,0x64,0x65};
private static byte[] bels_15 = {0x6E,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_15, 19));
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x61,0x74,0x69,0x62,0x6C,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x66,0x6F,0x72,0x20,0x63,0x61,0x6C,0x6C,0x2C,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_16, 52));
private static byte[] bels_17 = {0x20,0x67,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_17, 5));
public static BEC_3_5_5_9_BuildVisitTypeCheck bevs_inst;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_4_BuildNode bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_4_3_MathInt bevp_cpos;
public BEC_3_5_5_9_BuildVisitTypeCheck bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_cci = null;
BEC_2_5_4_BuildNode bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tvar = null;
BEC_2_6_6_SystemObject bevl_ovar = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_5_4_BuildNode bevl_ctarg = null;
BEC_2_6_6_SystemObject bevl_cvar = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_5_4_BuildNode bevl_org = null;
BEC_2_5_4_LogicBool bevl_castForSelf = null;
BEC_2_6_6_SystemObject bevl_ovnp = null;
BEC_2_6_6_SystemObject bevl_targsyn = null;
BEC_2_9_4_ContainerList bevl_argSyns = null;
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_6_BuildVarSyn bevl_marg = null;
BEC_2_5_3_BuildVar bevl_carg = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_16_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_87_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_91_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_92_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_97_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_98_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_103_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpvar_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_106_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_116_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_119_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_120_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_121_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_122_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_123_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_124_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_125_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_126_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_132_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_136_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_152_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_157_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_158_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_167_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_176_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_177_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_178_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_179_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_180_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_181_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_182_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_183_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_184_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_185_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_186_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_188_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_192_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_193_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_194_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_195_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_196_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_197_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_199_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_200_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_202_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_203_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_204_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_205_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_206_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_207_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_208_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_209_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_210_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_211_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_212_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_213_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_214_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_215_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_216_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_217_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_218_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_219_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_220_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_221_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_222_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_223_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_224_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_225_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_226_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_227_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_228_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_229_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_230_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_231_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_232_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_233_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_234_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_235_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_236_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_237_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_238_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_239_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_240_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_241_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_242_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_243_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_244_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_245_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_246_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_247_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_248_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_249_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_250_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_251_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_252_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_253_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_254_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_255_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_256_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_257_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_258_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_259_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_260_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_261_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_262_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_263_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_264_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_265_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_266_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_267_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_268_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_269_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_270_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_271_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_272_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_273_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_274_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_275_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_276_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_277_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_278_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_279_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_280_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_281_tmpvar_phold = null;
BEC_2_5_4_BuildNode bevt_282_tmpvar_phold = null;
bevt_9_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpvar_phold = bevp_ntypes.bem_CATCHGet_0();
if (bevt_9_tmpvar_phold.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpvar_phold.bevi_bool) /* Line: 381 */ {
bevt_16_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_firstGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 382 */ {
bevt_18_tmpvar_phold = (new BEC_2_4_6_TextString(46, bels_0));
bevt_17_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 383 */
} /* Line: 382 */
bevt_20_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_20_tmpvar_phold.bevi_int == bevt_21_tmpvar_phold.bevi_int) {
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpvar_phold.bevi_bool) /* Line: 386 */ {
bevp_inClass = beva_node;
bevt_22_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_23_tmpvar_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_23_tmpvar_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
} /* Line: 389 */
bevt_25_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_26_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_25_tmpvar_phold.bevi_int == bevt_26_tmpvar_phold.bevi_int) {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevp_cpos = (new BEC_2_4_3_MathInt(0));
} /* Line: 392 */
bevt_28_tmpvar_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_28_tmpvar_phold.bevi_int == bevt_29_tmpvar_phold.bevi_int) {
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpvar_phold.bevi_bool) /* Line: 394 */ {
bevt_30_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_30_tmpvar_phold.bemd_1(2117282045, BEL_4_Base.bevn_cposSet_1, bevp_cpos);
bevp_cpos = bevp_cpos.bem_increment_0();
bevt_31_tmpvar_phold = beva_node.bem_containedGet_0();
bevt_0_tmpvar_loop = bevt_31_tmpvar_phold.bem_iteratorGet_0();
while (true)
 /* Line: 397 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 397 */ {
bevl_cci = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_cci.bem_typenameGet_0();
bevt_35_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_34_tmpvar_phold.bevi_int == bevt_35_tmpvar_phold.bevi_int) {
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 398 */ {
bevt_36_tmpvar_phold = bevl_cci.bem_heldGet_0();
bevt_36_tmpvar_phold.bemd_1(474935663, BEL_4_Base.bevn_addCall_1, beva_node);
} /* Line: 399 */
} /* Line: 398 */
 else  /* Line: 397 */ {
break;
} /* Line: 397 */
} /* Line: 397 */
bevt_39_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_40_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_1));
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_40_tmpvar_phold);
if (bevt_37_tmpvar_phold != null && bevt_37_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_37_tmpvar_phold).bevi_bool) /* Line: 410 */ {
bevt_41_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_41_tmpvar_phold.bem_firstGet_0();
bevt_43_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_42_tmpvar_phold != null && bevt_42_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_42_tmpvar_phold).bevi_bool) /* Line: 413 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 414 */
 else  /* Line: 415 */ {
bevt_45_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_47_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_46_tmpvar_phold);
bevl_tvar = bevt_44_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 416 */
bevt_49_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_48_tmpvar_phold != null && bevt_48_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_48_tmpvar_phold).bevi_bool) /* Line: 419 */ {
bevt_50_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_51_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_50_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_51_tmpvar_phold);
} /* Line: 420 */
 else  /* Line: 421 */ {
bevl_org = beva_node.bem_secondGet_0();
bevt_53_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_54_tmpvar_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_53_tmpvar_phold.bevi_int == bevt_54_tmpvar_phold.bevi_int) {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_56_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_57_tmpvar_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_56_tmpvar_phold.bevi_int == bevt_57_tmpvar_phold.bevi_int) {
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_55_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 423 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 423 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 423 */ {
bevt_58_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_58_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_59_tmpvar_phold);
} /* Line: 425 */
 else  /* Line: 426 */ {
bevt_61_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_62_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpvar_phold.bevi_int == bevt_62_tmpvar_phold.bevi_int) {
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 427 */ {
bevt_64_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_63_tmpvar_phold != null && bevt_63_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_63_tmpvar_phold).bevi_bool) /* Line: 428 */ {
bevl_ovar = bevl_org.bem_heldGet_0();
} /* Line: 429 */
 else  /* Line: 430 */ {
bevt_66_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_68_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_67_tmpvar_phold);
bevl_ovar = bevt_65_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 432 */
} /* Line: 428 */
 else  /* Line: 427 */ {
bevt_70_tmpvar_phold = bevl_org.bem_typenameGet_0();
bevt_71_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_70_tmpvar_phold.bevi_int == bevt_71_tmpvar_phold.bevi_int) {
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_69_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_69_tmpvar_phold.bevi_bool) /* Line: 435 */ {
bevt_72_tmpvar_phold = bevl_org.bem_containedGet_0();
bevl_ctarg = (BEC_2_5_4_BuildNode) bevt_72_tmpvar_phold.bem_firstGet_0();
bevt_74_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_73_tmpvar_phold != null && bevt_73_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_73_tmpvar_phold).bevi_bool) /* Line: 438 */ {
bevl_cvar = bevl_ctarg.bem_heldGet_0();
} /* Line: 440 */
 else  /* Line: 441 */ {
bevt_76_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_78_tmpvar_phold = bevl_ctarg.bem_heldGet_0();
bevt_77_tmpvar_phold = bevt_78_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_75_tmpvar_phold = bevt_76_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_77_tmpvar_phold);
bevl_cvar = bevt_75_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 443 */
bevl_syn = null;
bevt_81_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_80_tmpvar_phold = bevt_81_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_80_tmpvar_phold == null) {
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_79_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_79_tmpvar_phold.bevi_bool) /* Line: 447 */ {
bevt_83_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_82_tmpvar_phold = bevt_83_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_82_tmpvar_phold);
} /* Line: 448 */
 else  /* Line: 447 */ {
bevt_84_tmpvar_phold = bevl_cvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_84_tmpvar_phold != null && bevt_84_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_84_tmpvar_phold).bevi_bool) /* Line: 449 */ {
bevt_85_tmpvar_phold = bevl_cvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_85_tmpvar_phold);
} /* Line: 451 */
} /* Line: 447 */
if (bevl_syn == null) {
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_86_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_86_tmpvar_phold.bevi_bool) /* Line: 453 */ {
bevt_87_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_89_tmpvar_phold = bevl_org.bem_heldGet_0();
bevt_88_tmpvar_phold = bevt_89_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_87_tmpvar_phold.bem_get_1(bevt_88_tmpvar_phold);
if (bevl_mtdc == null) {
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_90_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_90_tmpvar_phold.bevi_bool) /* Line: 455 */ {
bevt_92_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_2));
bevt_91_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_92_tmpvar_phold, bevl_org);
throw new be.BELS_Base.BECS_ThrowBack(bevt_91_tmpvar_phold);
} /* Line: 456 */
 else  /* Line: 457 */ {
bevl_ovar = bevl_mtdc.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
} /* Line: 458 */
} /* Line: 455 */
} /* Line: 453 */
} /* Line: 427 */
if (bevl_ovar == null) {
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_93_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_93_tmpvar_phold.bevi_bool) /* Line: 462 */ {
bevt_94_tmpvar_phold = bevl_ovar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_94_tmpvar_phold != null && bevt_94_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_94_tmpvar_phold).bevi_bool) /* Line: 462 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 462 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_95_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_95_tmpvar_phold != null && bevt_95_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_95_tmpvar_phold).bevi_bool) /* Line: 465 */ {
if (bevl_syn == null) {
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_96_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_96_tmpvar_phold.bevi_bool) /* Line: 467 */ {
bevt_98_tmpvar_phold = (new BEC_2_4_6_TextString(28, bels_3));
bevt_97_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_98_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_97_tmpvar_phold);
} /* Line: 468 */
bevt_100_tmpvar_phold = bevl_mtdc.bemd_0(1707345409, BEL_4_Base.bevn_originGet_0);
bevt_101_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_99_tmpvar_phold = bevt_100_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_101_tmpvar_phold);
if (bevt_99_tmpvar_phold != null && bevt_99_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_99_tmpvar_phold).bevi_bool) /* Line: 473 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 475 */
 else  /* Line: 473 */ {
bevt_103_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
if (bevt_103_tmpvar_phold == null) {
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_102_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_102_tmpvar_phold.bevi_bool) /* Line: 476 */ {
bevt_106_tmpvar_phold = bevp_build.bem_emitCommonGet_0();
bevt_105_tmpvar_phold = bevt_106_tmpvar_phold.bem_covariantReturnsGet_0();
bevt_104_tmpvar_phold = bevt_105_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_104_tmpvar_phold != null && bevt_104_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_104_tmpvar_phold).bevi_bool) /* Line: 476 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 476 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 476 */
 else  /* Line: 476 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 476 */ {
bevl_castForSelf = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 477 */
} /* Line: 473 */
} /* Line: 473 */
 else  /* Line: 465 */ {
if (bevl_mtdc == null) {
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_107_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_107_tmpvar_phold.bevi_bool) /* Line: 479 */ {
bevt_108_tmpvar_phold = bevl_mtdc.bemd_2(583049050, BEL_4_Base.bevn_getEmitReturnType_2, bevl_syn, bevp_build);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_108_tmpvar_phold);
} /* Line: 480 */
 else  /* Line: 481 */ {
bevt_109_tmpvar_phold = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_109_tmpvar_phold);
} /* Line: 482 */
} /* Line: 465 */
bevt_111_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_110_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_111_tmpvar_phold);
if (bevt_110_tmpvar_phold != null && bevt_110_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_110_tmpvar_phold).bevi_bool) /* Line: 486 */ {
bevt_112_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_113_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_112_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_113_tmpvar_phold);
} /* Line: 488 */
 else  /* Line: 489 */ {
bevt_114_tmpvar_phold = bevl_ovar.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_114_tmpvar_phold != null && bevt_114_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpvar_phold).bevi_bool) /* Line: 490 */ {
bevl_ovnp = bevl_syn.bem_namepathGet_0();
} /* Line: 491 */
 else  /* Line: 492 */ {
bevl_ovnp = bevl_ovar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
} /* Line: 493 */
bevt_115_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_115_tmpvar_phold);
bevt_116_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevl_ovnp);
if (bevt_116_tmpvar_phold != null && bevt_116_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_116_tmpvar_phold).bevi_bool) /* Line: 496 */ {
bevt_117_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_118_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_117_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_118_tmpvar_phold);
} /* Line: 498 */
 else  /* Line: 499 */ {
bevt_123_tmpvar_phold = bevo_0;
bevt_125_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_124_tmpvar_phold = bevt_125_tmpvar_phold.bem_toString_0();
bevt_122_tmpvar_phold = bevt_123_tmpvar_phold.bem_add_1(bevt_124_tmpvar_phold);
bevt_126_tmpvar_phold = bevo_1;
bevt_121_tmpvar_phold = bevt_122_tmpvar_phold.bem_add_1(bevt_126_tmpvar_phold);
bevt_127_tmpvar_phold = bevl_ovnp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_120_tmpvar_phold = bevt_121_tmpvar_phold.bem_add_1(bevt_127_tmpvar_phold);
bevt_119_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_120_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_119_tmpvar_phold);
} /* Line: 500 */
} /* Line: 496 */
if (bevl_castForSelf.bevi_bool) /* Line: 504 */ {
bevt_128_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_129_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_128_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_129_tmpvar_phold);
} /* Line: 506 */
} /* Line: 504 */
bevt_132_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_131_tmpvar_phold = bevt_132_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevt_131_tmpvar_phold == null) {
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_130_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_130_tmpvar_phold.bevi_bool) /* Line: 509 */ {
} /* Line: 509 */
} /* Line: 509 */
} /* Line: 423 */
} /* Line: 419 */
 else  /* Line: 410 */ {
bevt_135_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_134_tmpvar_phold = bevt_135_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_136_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_6));
bevt_133_tmpvar_phold = bevt_134_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_136_tmpvar_phold);
if (bevt_133_tmpvar_phold != null && bevt_133_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_133_tmpvar_phold).bevi_bool) /* Line: 514 */ {
bevl_targ = beva_node.bem_secondGet_0();
bevt_138_tmpvar_phold = bevl_targ.bem_typenameGet_0();
bevt_139_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_138_tmpvar_phold.bevi_int == bevt_139_tmpvar_phold.bevi_int) {
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_137_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_137_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_141_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_140_tmpvar_phold = bevt_141_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_140_tmpvar_phold != null && bevt_140_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_140_tmpvar_phold).bevi_bool) /* Line: 517 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 518 */
 else  /* Line: 519 */ {
bevt_143_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_145_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_144_tmpvar_phold = bevt_145_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_142_tmpvar_phold = bevt_143_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_144_tmpvar_phold);
bevl_tvar = bevt_142_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 520 */
bevl_mtdmy = beva_node.bem_scopeGet_0();
bevt_147_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_146_tmpvar_phold = bevt_147_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_146_tmpvar_phold != null && bevt_146_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_146_tmpvar_phold).bevi_bool) /* Line: 524 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 525 */
 else  /* Line: 526 */ {
bevt_149_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_151_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_150_tmpvar_phold = bevt_151_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_148_tmpvar_phold = bevt_149_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_150_tmpvar_phold);
bevl_tvar = bevt_148_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 527 */
bevt_154_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_153_tmpvar_phold = bevt_154_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_153_tmpvar_phold == null) {
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_152_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_152_tmpvar_phold.bevi_bool) /* Line: 530 */ {
bevt_157_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_156_tmpvar_phold = bevt_157_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_155_tmpvar_phold = bevt_156_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_155_tmpvar_phold != null && bevt_155_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_155_tmpvar_phold).bevi_bool) /* Line: 530 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 530 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 530 */
 else  /* Line: 530 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 530 */ {
bevt_159_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_158_tmpvar_phold = bevt_159_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_158_tmpvar_phold != null && bevt_158_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_158_tmpvar_phold).bevi_bool) /* Line: 531 */ {
bevt_160_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_161_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_160_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_161_tmpvar_phold);
} /* Line: 533 */
 else  /* Line: 534 */ {
bevt_164_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_163_tmpvar_phold = bevt_164_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_162_tmpvar_phold = bevt_163_tmpvar_phold.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_162_tmpvar_phold != null && bevt_162_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_162_tmpvar_phold).bevi_bool) /* Line: 537 */ {
bevt_166_tmpvar_phold = bevl_tvar.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_167_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_7));
bevt_165_tmpvar_phold = bevt_166_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_167_tmpvar_phold);
if (bevt_165_tmpvar_phold != null && bevt_165_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_165_tmpvar_phold).bevi_bool) /* Line: 538 */ {
bevt_168_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_169_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_168_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_169_tmpvar_phold);
} /* Line: 540 */
 else  /* Line: 541 */ {
bevt_170_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_targsyn = bevp_build.bem_getSynNp_1(bevt_170_tmpvar_phold);
bevt_172_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_171_tmpvar_phold = bevp_inClassSyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_172_tmpvar_phold);
if (bevt_171_tmpvar_phold != null && bevt_171_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_171_tmpvar_phold).bevi_bool) /* Line: 543 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_174_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_173_tmpvar_phold = bevl_targsyn.bemd_1(1118052001, BEL_4_Base.bevn_castsTo_1, bevt_174_tmpvar_phold);
if (bevt_173_tmpvar_phold != null && bevt_173_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_173_tmpvar_phold).bevi_bool) /* Line: 543 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 543 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 543 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 543 */ {
bevt_175_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_176_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_175_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_176_tmpvar_phold);
} /* Line: 545 */
 else  /* Line: 546 */ {
bevt_181_tmpvar_phold = bevo_2;
bevt_182_tmpvar_phold = bevp_inClassSyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_180_tmpvar_phold = bevt_181_tmpvar_phold.bem_add_1(bevt_182_tmpvar_phold);
bevt_183_tmpvar_phold = bevo_3;
bevt_179_tmpvar_phold = bevt_180_tmpvar_phold.bem_add_1(bevt_183_tmpvar_phold);
bevt_184_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_178_tmpvar_phold = bevt_179_tmpvar_phold.bem_add_1(bevt_184_tmpvar_phold);
bevt_177_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_178_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_177_tmpvar_phold);
} /* Line: 547 */
} /* Line: 543 */
} /* Line: 538 */
 else  /* Line: 550 */ {
bevt_185_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_185_tmpvar_phold);
bevt_189_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_188_tmpvar_phold = bevt_189_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_187_tmpvar_phold = bevt_188_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_186_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_187_tmpvar_phold);
if (bevt_186_tmpvar_phold != null && bevt_186_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_186_tmpvar_phold).bevi_bool) /* Line: 552 */ {
bevt_190_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_191_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_190_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_191_tmpvar_phold);
} /* Line: 554 */
 else  /* Line: 555 */ {
bevt_194_tmpvar_phold = bevl_mtdmy.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_193_tmpvar_phold = bevt_194_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_192_tmpvar_phold = bevt_193_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_192_tmpvar_phold);
bevt_196_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_195_tmpvar_phold = bevl_syn.bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevt_196_tmpvar_phold);
if (bevt_195_tmpvar_phold != null && bevt_195_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_195_tmpvar_phold).bevi_bool) /* Line: 557 */ {
bevt_197_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_198_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_197_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_198_tmpvar_phold);
} /* Line: 559 */
 else  /* Line: 560 */ {
bevt_200_tmpvar_phold = (new BEC_2_4_6_TextString(25, bels_10));
bevt_199_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_200_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_199_tmpvar_phold);
} /* Line: 561 */
} /* Line: 557 */
} /* Line: 552 */
} /* Line: 537 */
} /* Line: 531 */
 else  /* Line: 566 */ {
bevt_201_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_202_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_201_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_202_tmpvar_phold);
} /* Line: 568 */
} /* Line: 530 */
 else  /* Line: 570 */ {
bevt_203_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_204_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_203_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_204_tmpvar_phold);
} /* Line: 571 */
} /* Line: 516 */
 else  /* Line: 573 */ {
bevt_205_tmpvar_phold = beva_node.bem_containedGet_0();
bevl_targ = (BEC_2_5_4_BuildNode) bevt_205_tmpvar_phold.bem_firstGet_0();
bevt_207_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_206_tmpvar_phold = bevt_207_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_206_tmpvar_phold != null && bevt_206_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_206_tmpvar_phold).bevi_bool) /* Line: 576 */ {
bevl_tvar = bevl_targ.bem_heldGet_0();
} /* Line: 577 */
 else  /* Line: 578 */ {
bevt_209_tmpvar_phold = bevp_inClassSyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_211_tmpvar_phold = bevl_targ.bem_heldGet_0();
bevt_210_tmpvar_phold = bevt_211_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_208_tmpvar_phold = bevt_209_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_210_tmpvar_phold);
bevl_tvar = bevt_208_tmpvar_phold.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
} /* Line: 579 */
bevt_213_tmpvar_phold = bevl_tvar.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_212_tmpvar_phold = bevt_213_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_212_tmpvar_phold != null && bevt_212_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_212_tmpvar_phold).bevi_bool) /* Line: 582 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 582 */ {
bevt_216_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_215_tmpvar_phold = bevt_216_tmpvar_phold.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_217_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_11));
bevt_214_tmpvar_phold = bevt_215_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_217_tmpvar_phold);
if (bevt_214_tmpvar_phold != null && bevt_214_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_214_tmpvar_phold).bevi_bool) /* Line: 582 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 582 */ {
bevt_6_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 582 */
if (bevt_6_tmpvar_anchor.bevi_bool) /* Line: 582 */ {
bevt_218_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_219_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_218_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_219_tmpvar_phold);
} /* Line: 583 */
 else  /* Line: 584 */ {
bevt_220_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_221_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_220_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_221_tmpvar_phold);
bevt_223_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_222_tmpvar_phold = bevt_223_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_222_tmpvar_phold != null && bevt_222_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_222_tmpvar_phold).bevi_bool) /* Line: 586 */ {
bevt_226_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_225_tmpvar_phold = bevt_226_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_225_tmpvar_phold == null) {
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_224_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_224_tmpvar_phold.bevi_bool) /* Line: 587 */ {
bevt_228_tmpvar_phold = (new BEC_2_4_6_TextString(49, bels_12));
bevt_227_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_228_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_227_tmpvar_phold);
} /* Line: 588 */
bevt_230_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_229_tmpvar_phold = bevt_230_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_229_tmpvar_phold);
bevt_231_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_233_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_232_tmpvar_phold = bevt_233_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_231_tmpvar_phold.bem_get_1(bevt_232_tmpvar_phold);
} /* Line: 591 */
 else  /* Line: 592 */ {
bevt_234_tmpvar_phold = bevl_tvar.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_syn = bevp_build.bem_getSynNp_1(bevt_234_tmpvar_phold);
bevt_235_tmpvar_phold = bevl_syn.bem_mtdMapGet_0();
bevt_237_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_236_tmpvar_phold = bevt_237_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdc = bevt_235_tmpvar_phold.bem_get_1(bevt_236_tmpvar_phold);
} /* Line: 594 */
if (bevl_mtdc == null) {
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_238_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_238_tmpvar_phold.bevi_bool) /* Line: 596 */ {
bevt_240_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_13));
bevt_239_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_240_tmpvar_phold, beva_node);
throw new be.BELS_Base.BECS_ThrowBack(bevt_239_tmpvar_phold);
} /* Line: 597 */
bevl_argSyns = (BEC_2_9_4_ContainerList) bevl_mtdc.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_nnode = bevl_targ.bem_nextPeerGet_0();
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 601 */ {
bevt_242_tmpvar_phold = bevl_argSyns.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_242_tmpvar_phold.bevi_int) {
bevt_241_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_241_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_241_tmpvar_phold.bevi_bool) /* Line: 601 */ {
bevl_marg = (BEC_2_5_6_BuildVarSyn) bevl_argSyns.bem_get_1(bevl_i);
bevt_243_tmpvar_phold = bevl_marg.bem_isTypedGet_0();
if (bevt_243_tmpvar_phold.bevi_bool) /* Line: 603 */ {
if (bevl_nnode == null) {
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_244_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_244_tmpvar_phold.bevi_bool) /* Line: 604 */ {
bevt_246_tmpvar_phold = (new BEC_2_4_6_TextString(16, bels_14));
bevt_245_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_246_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_245_tmpvar_phold);
} /* Line: 605 */
 else  /* Line: 604 */ {
bevt_248_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_249_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_248_tmpvar_phold.bevi_int != bevt_249_tmpvar_phold.bevi_int) {
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_247_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_247_tmpvar_phold.bevi_bool) /* Line: 606 */ {
bevt_251_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_252_tmpvar_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_251_tmpvar_phold.bevi_int != bevt_252_tmpvar_phold.bevi_int) {
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_250_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_250_tmpvar_phold.bevi_bool) /* Line: 606 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 606 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 606 */
 else  /* Line: 606 */ {
bevt_7_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpvar_anchor.bevi_bool) /* Line: 606 */ {
bevt_255_tmpvar_phold = bevo_4;
bevt_257_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_256_tmpvar_phold = bevt_257_tmpvar_phold.bem_toString_0();
bevt_254_tmpvar_phold = bevt_255_tmpvar_phold.bem_add_1(bevt_256_tmpvar_phold);
bevt_253_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_254_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_253_tmpvar_phold);
} /* Line: 607 */
} /* Line: 604 */
bevt_259_tmpvar_phold = bevl_nnode.bem_typenameGet_0();
bevt_260_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_259_tmpvar_phold.bevi_int == bevt_260_tmpvar_phold.bevi_int) {
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_258_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_258_tmpvar_phold.bevi_bool) /* Line: 609 */ {
bevl_carg = (BEC_2_5_3_BuildVar) bevl_nnode.bem_heldGet_0();
bevt_262_tmpvar_phold = bevl_carg.bem_isTypedGet_0();
if (bevt_262_tmpvar_phold.bevi_bool) {
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_261_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_261_tmpvar_phold.bevi_bool) /* Line: 611 */ {
bevt_263_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_264_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_263_tmpvar_phold.bemd_1(666397123, BEL_4_Base.bevn_checkTypesSet_1, bevt_264_tmpvar_phold);
bevt_266_tmpvar_phold = beva_node.bem_heldGet_0();
bevt_265_tmpvar_phold = bevt_266_tmpvar_phold.bemd_0(1018900425, BEL_4_Base.bevn_argCastsGet_0);
bevt_267_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_265_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_i, bevt_267_tmpvar_phold);
} /* Line: 613 */
 else  /* Line: 615 */ {
bevt_268_tmpvar_phold = bevl_carg.bem_namepathGet_0();
bevl_syn = bevp_build.bem_getSynNp_1(bevt_268_tmpvar_phold);
bevt_271_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_270_tmpvar_phold = bevl_syn.bem_castsTo_1(bevt_271_tmpvar_phold);
bevt_269_tmpvar_phold = bevt_270_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_269_tmpvar_phold != null && bevt_269_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_269_tmpvar_phold).bevi_bool) /* Line: 617 */ {
bevt_276_tmpvar_phold = bevo_5;
bevt_278_tmpvar_phold = bevl_syn.bem_namepathGet_0();
bevt_277_tmpvar_phold = bevt_278_tmpvar_phold.bem_toString_0();
bevt_275_tmpvar_phold = bevt_276_tmpvar_phold.bem_add_1(bevt_277_tmpvar_phold);
bevt_279_tmpvar_phold = bevo_6;
bevt_274_tmpvar_phold = bevt_275_tmpvar_phold.bem_add_1(bevt_279_tmpvar_phold);
bevt_281_tmpvar_phold = bevl_marg.bem_namepathGet_0();
bevt_280_tmpvar_phold = bevt_281_tmpvar_phold.bem_toString_0();
bevt_273_tmpvar_phold = bevt_274_tmpvar_phold.bem_add_1(bevt_280_tmpvar_phold);
bevt_272_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_273_tmpvar_phold, bevl_nnode);
throw new be.BELS_Base.BECS_ThrowBack(bevt_272_tmpvar_phold);
} /* Line: 618 */
} /* Line: 617 */
} /* Line: 611 */
} /* Line: 609 */
bevl_nnode = bevl_nnode.bem_nextPeerGet_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 601 */
 else  /* Line: 601 */ {
break;
} /* Line: 601 */
} /* Line: 601 */
} /* Line: 601 */
} /* Line: 582 */
} /* Line: 410 */
} /* Line: 410 */
bevt_282_tmpvar_phold = beva_node.bem_nextDescendGet_0();
return bevt_282_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
return bevp_emitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emitter = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inClassGet_0() throws Throwable {
return bevp_inClass;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClass = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() throws Throwable {
return bevp_inClassSyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassSyn = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_cposGet_0() throws Throwable {
return bevp_cpos;
} /*method end*/
public BEC_2_6_6_SystemObject bem_cposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_cpos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {381, 381, 381, 381, 382, 382, 382, 382, 382, 382, 383, 383, 383, 386, 386, 386, 386, 387, 388, 388, 389, 389, 391, 391, 391, 391, 392, 394, 394, 394, 394, 395, 395, 396, 397, 397, 0, 397, 397, 398, 398, 398, 398, 399, 399, 410, 410, 410, 410, 411, 411, 413, 413, 414, 416, 416, 416, 416, 416, 419, 419, 420, 420, 420, 422, 423, 423, 423, 423, 0, 423, 423, 423, 423, 0, 0, 425, 425, 425, 427, 427, 427, 427, 428, 428, 429, 432, 432, 432, 432, 432, 435, 435, 435, 435, 436, 436, 438, 438, 440, 443, 443, 443, 443, 443, 446, 447, 447, 447, 447, 448, 448, 448, 449, 451, 451, 453, 453, 454, 454, 454, 454, 455, 455, 456, 456, 456, 458, 462, 462, 462, 0, 0, 0, 464, 465, 467, 467, 468, 468, 468, 473, 473, 473, 475, 476, 476, 476, 476, 476, 476, 0, 0, 0, 477, 479, 479, 480, 480, 482, 482, 486, 486, 488, 488, 488, 490, 491, 493, 495, 495, 496, 498, 498, 498, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 506, 506, 506, 509, 509, 509, 509, 514, 514, 514, 514, 515, 516, 516, 516, 516, 517, 517, 518, 520, 520, 520, 520, 520, 523, 524, 524, 525, 527, 527, 527, 527, 527, 530, 530, 530, 530, 530, 530, 530, 0, 0, 0, 531, 531, 533, 533, 533, 537, 537, 537, 538, 538, 538, 540, 540, 540, 542, 542, 543, 543, 0, 543, 543, 0, 0, 545, 545, 545, 547, 547, 547, 547, 547, 547, 547, 547, 547, 551, 551, 552, 552, 552, 552, 554, 554, 554, 556, 556, 556, 556, 557, 557, 559, 559, 559, 561, 561, 561, 568, 568, 568, 571, 571, 571, 574, 574, 576, 576, 577, 579, 579, 579, 579, 579, 582, 582, 0, 582, 582, 582, 582, 0, 0, 583, 583, 583, 585, 585, 585, 586, 586, 587, 587, 587, 587, 588, 588, 588, 590, 590, 590, 591, 591, 591, 591, 593, 593, 594, 594, 594, 594, 596, 596, 597, 597, 597, 599, 600, 601, 601, 601, 601, 602, 603, 604, 604, 605, 605, 605, 606, 606, 606, 606, 606, 606, 606, 606, 0, 0, 0, 607, 607, 607, 607, 607, 607, 609, 609, 609, 609, 610, 611, 611, 611, 612, 612, 612, 613, 613, 613, 613, 616, 616, 617, 617, 617, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 627, 601, 632, 632, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {343, 344, 345, 350, 351, 352, 353, 354, 355, 356, 358, 359, 360, 363, 364, 365, 370, 371, 372, 373, 374, 375, 377, 378, 379, 384, 385, 387, 388, 389, 394, 395, 396, 397, 398, 399, 399, 402, 404, 405, 406, 407, 412, 413, 414, 421, 422, 423, 424, 426, 427, 428, 429, 431, 434, 435, 436, 437, 438, 440, 441, 443, 444, 445, 448, 449, 450, 451, 456, 457, 460, 461, 462, 467, 468, 471, 475, 476, 477, 480, 481, 482, 487, 488, 489, 491, 494, 495, 496, 497, 498, 502, 503, 504, 509, 510, 511, 512, 513, 515, 518, 519, 520, 521, 522, 524, 525, 526, 527, 532, 533, 534, 535, 538, 540, 541, 544, 549, 550, 551, 552, 553, 554, 559, 560, 561, 562, 565, 570, 575, 576, 578, 581, 585, 588, 589, 591, 596, 597, 598, 599, 601, 602, 603, 605, 608, 609, 614, 615, 616, 617, 619, 622, 626, 629, 634, 639, 640, 641, 644, 645, 648, 649, 651, 652, 653, 656, 658, 661, 663, 664, 665, 667, 668, 669, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 685, 686, 687, 690, 691, 692, 697, 703, 704, 705, 706, 708, 709, 710, 711, 716, 717, 718, 720, 723, 724, 725, 726, 727, 729, 730, 731, 733, 736, 737, 738, 739, 740, 742, 743, 744, 749, 750, 751, 752, 754, 757, 761, 764, 765, 767, 768, 769, 772, 773, 774, 776, 777, 778, 780, 781, 782, 785, 786, 787, 788, 790, 793, 794, 796, 799, 803, 804, 805, 808, 809, 810, 811, 812, 813, 814, 815, 816, 821, 822, 823, 824, 825, 826, 828, 829, 830, 833, 834, 835, 836, 837, 838, 840, 841, 842, 845, 846, 847, 854, 855, 856, 860, 861, 862, 866, 867, 868, 869, 871, 874, 875, 876, 877, 878, 880, 881, 883, 886, 887, 888, 889, 891, 894, 898, 899, 900, 903, 904, 905, 906, 907, 909, 910, 911, 916, 917, 918, 919, 921, 922, 923, 924, 925, 926, 927, 930, 931, 932, 933, 934, 935, 937, 942, 943, 944, 945, 947, 948, 949, 952, 953, 958, 959, 960, 962, 967, 968, 969, 970, 973, 974, 975, 980, 981, 982, 983, 988, 989, 992, 996, 999, 1000, 1001, 1002, 1003, 1004, 1007, 1008, 1009, 1014, 1015, 1016, 1017, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1032, 1033, 1034, 1035, 1036, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1053, 1054, 1064, 1065, 1068, 1071, 1075, 1078, 1082, 1085, 1089, 1092, 1096, 1099};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 381 343
typenameGet 0 381 343
assign 1 381 344
CATCHGet 0 381 344
assign 1 381 345
equals 1 381 350
assign 1 382 351
containedGet 0 382 351
assign 1 382 352
firstGet 0 382 352
assign 1 382 353
containedGet 0 382 353
assign 1 382 354
firstGet 0 382 354
assign 1 382 355
heldGet 0 382 355
assign 1 382 356
isTypedGet 0 382 356
assign 1 383 358
new 0 383 358
assign 1 383 359
new 1 383 359
throw 1 383 360
assign 1 386 363
typenameGet 0 386 363
assign 1 386 364
CLASSGet 0 386 364
assign 1 386 365
equals 1 386 370
assign 1 387 371
assign 1 388 372
heldGet 0 388 372
assign 1 388 373
namepathGet 0 388 373
assign 1 389 374
heldGet 0 389 374
assign 1 389 375
synGet 0 389 375
assign 1 391 377
typenameGet 0 391 377
assign 1 391 378
METHODGet 0 391 378
assign 1 391 379
equals 1 391 384
assign 1 392 385
new 0 392 385
assign 1 394 387
typenameGet 0 394 387
assign 1 394 388
CALLGet 0 394 388
assign 1 394 389
equals 1 394 394
assign 1 395 395
heldGet 0 395 395
cposSet 1 395 396
assign 1 396 397
increment 0 396 397
assign 1 397 398
containedGet 0 397 398
assign 1 397 399
iteratorGet 0 0 399
assign 1 397 402
hasNextGet 0 397 402
assign 1 397 404
nextGet 0 397 404
assign 1 398 405
typenameGet 0 398 405
assign 1 398 406
VARGet 0 398 406
assign 1 398 407
equals 1 398 412
assign 1 399 413
heldGet 0 399 413
addCall 1 399 414
assign 1 410 421
heldGet 0 410 421
assign 1 410 422
orgNameGet 0 410 422
assign 1 410 423
new 0 410 423
assign 1 410 424
equals 1 410 424
assign 1 411 426
containedGet 0 411 426
assign 1 411 427
firstGet 0 411 427
assign 1 413 428
heldGet 0 413 428
assign 1 413 429
isDeclaredGet 0 413 429
assign 1 414 431
heldGet 0 414 431
assign 1 416 434
ptyMapGet 0 416 434
assign 1 416 435
heldGet 0 416 435
assign 1 416 436
nameGet 0 416 436
assign 1 416 437
get 1 416 437
assign 1 416 438
memSynGet 0 416 438
assign 1 419 440
isTypedGet 0 419 440
assign 1 419 441
not 0 419 441
assign 1 420 443
heldGet 0 420 443
assign 1 420 444
new 0 420 444
checkTypesSet 1 420 445
assign 1 422 448
secondGet 0 422 448
assign 1 423 449
typenameGet 0 423 449
assign 1 423 450
TRUEGet 0 423 450
assign 1 423 451
equals 1 423 456
assign 1 0 457
assign 1 423 460
typenameGet 0 423 460
assign 1 423 461
FALSEGet 0 423 461
assign 1 423 462
equals 1 423 467
assign 1 0 468
assign 1 0 471
assign 1 425 475
heldGet 0 425 475
assign 1 425 476
new 0 425 476
checkTypesSet 1 425 477
assign 1 427 480
typenameGet 0 427 480
assign 1 427 481
VARGet 0 427 481
assign 1 427 482
equals 1 427 487
assign 1 428 488
heldGet 0 428 488
assign 1 428 489
isDeclaredGet 0 428 489
assign 1 429 491
heldGet 0 429 491
assign 1 432 494
ptyMapGet 0 432 494
assign 1 432 495
heldGet 0 432 495
assign 1 432 496
nameGet 0 432 496
assign 1 432 497
get 1 432 497
assign 1 432 498
memSynGet 0 432 498
assign 1 435 502
typenameGet 0 435 502
assign 1 435 503
CALLGet 0 435 503
assign 1 435 504
equals 1 435 509
assign 1 436 510
containedGet 0 436 510
assign 1 436 511
firstGet 0 436 511
assign 1 438 512
heldGet 0 438 512
assign 1 438 513
isDeclaredGet 0 438 513
assign 1 440 515
heldGet 0 440 515
assign 1 443 518
ptyMapGet 0 443 518
assign 1 443 519
heldGet 0 443 519
assign 1 443 520
nameGet 0 443 520
assign 1 443 521
get 1 443 521
assign 1 443 522
memSynGet 0 443 522
assign 1 446 524
assign 1 447 525
heldGet 0 447 525
assign 1 447 526
newNpGet 0 447 526
assign 1 447 527
def 1 447 532
assign 1 448 533
heldGet 0 448 533
assign 1 448 534
newNpGet 0 448 534
assign 1 448 535
getSynNp 1 448 535
assign 1 449 538
isTypedGet 0 449 538
assign 1 451 540
namepathGet 0 451 540
assign 1 451 541
getSynNp 1 451 541
assign 1 453 544
def 1 453 549
assign 1 454 550
mtdMapGet 0 454 550
assign 1 454 551
heldGet 0 454 551
assign 1 454 552
nameGet 0 454 552
assign 1 454 553
get 1 454 553
assign 1 455 554
undef 1 455 559
assign 1 456 560
new 0 456 560
assign 1 456 561
new 2 456 561
throw 1 456 562
assign 1 458 565
rsynGet 0 458 565
assign 1 462 570
def 1 462 575
assign 1 462 576
isTypedGet 0 462 576
assign 1 0 578
assign 1 0 581
assign 1 0 585
assign 1 464 588
new 0 464 588
assign 1 465 589
isSelfGet 0 465 589
assign 1 467 591
undef 1 467 596
assign 1 468 597
new 0 468 597
assign 1 468 598
new 1 468 598
throw 1 468 599
assign 1 473 601
originGet 0 473 601
assign 1 473 602
namepathGet 0 473 602
assign 1 473 603
notEquals 1 473 603
assign 1 475 605
new 0 475 605
assign 1 476 608
emitCommonGet 0 476 608
assign 1 476 609
def 1 476 614
assign 1 476 615
emitCommonGet 0 476 615
assign 1 476 616
covariantReturnsGet 0 476 616
assign 1 476 617
not 0 476 617
assign 1 0 619
assign 1 0 622
assign 1 0 626
assign 1 477 629
new 0 477 629
assign 1 479 634
def 1 479 639
assign 1 480 640
getEmitReturnType 2 480 640
assign 1 480 641
getSynNp 1 480 641
assign 1 482 644
namepathGet 0 482 644
assign 1 482 645
getSynNp 1 482 645
assign 1 486 648
namepathGet 0 486 648
assign 1 486 649
castsTo 1 486 649
assign 1 488 651
heldGet 0 488 651
assign 1 488 652
new 0 488 652
checkTypesSet 1 488 653
assign 1 490 656
isSelfGet 0 490 656
assign 1 491 658
namepathGet 0 491 658
assign 1 493 661
namepathGet 0 493 661
assign 1 495 663
namepathGet 0 495 663
assign 1 495 664
getSynNp 1 495 664
assign 1 496 665
castsTo 1 496 665
assign 1 498 667
heldGet 0 498 667
assign 1 498 668
new 0 498 668
checkTypesSet 1 498 669
assign 1 500 672
new 0 500 672
assign 1 500 673
namepathGet 0 500 673
assign 1 500 674
toString 0 500 674
assign 1 500 675
add 1 500 675
assign 1 500 676
new 0 500 676
assign 1 500 677
add 1 500 677
assign 1 500 678
toString 0 500 678
assign 1 500 679
add 1 500 679
assign 1 500 680
new 2 500 680
throw 1 500 681
assign 1 506 685
heldGet 0 506 685
assign 1 506 686
new 0 506 686
checkTypesSet 1 506 687
assign 1 509 690
heldGet 0 509 690
assign 1 509 691
namepathGet 0 509 691
assign 1 509 692
def 1 509 697
assign 1 514 703
heldGet 0 514 703
assign 1 514 704
orgNameGet 0 514 704
assign 1 514 705
new 0 514 705
assign 1 514 706
equals 1 514 706
assign 1 515 708
secondGet 0 515 708
assign 1 516 709
typenameGet 0 516 709
assign 1 516 710
VARGet 0 516 710
assign 1 516 711
equals 1 516 716
assign 1 517 717
heldGet 0 517 717
assign 1 517 718
isDeclaredGet 0 517 718
assign 1 518 720
heldGet 0 518 720
assign 1 520 723
ptyMapGet 0 520 723
assign 1 520 724
heldGet 0 520 724
assign 1 520 725
nameGet 0 520 725
assign 1 520 726
get 1 520 726
assign 1 520 727
memSynGet 0 520 727
assign 1 523 729
scopeGet 0 523 729
assign 1 524 730
heldGet 0 524 730
assign 1 524 731
isDeclaredGet 0 524 731
assign 1 525 733
heldGet 0 525 733
assign 1 527 736
ptyMapGet 0 527 736
assign 1 527 737
heldGet 0 527 737
assign 1 527 738
nameGet 0 527 738
assign 1 527 739
get 1 527 739
assign 1 527 740
memSynGet 0 527 740
assign 1 530 742
heldGet 0 530 742
assign 1 530 743
rtypeGet 0 530 743
assign 1 530 744
def 1 530 749
assign 1 530 750
heldGet 0 530 750
assign 1 530 751
rtypeGet 0 530 751
assign 1 530 752
isTypedGet 0 530 752
assign 1 0 754
assign 1 0 757
assign 1 0 761
assign 1 531 764
isTypedGet 0 531 764
assign 1 531 765
not 0 531 765
assign 1 533 767
heldGet 0 533 767
assign 1 533 768
new 0 533 768
checkTypesSet 1 533 769
assign 1 537 772
heldGet 0 537 772
assign 1 537 773
rtypeGet 0 537 773
assign 1 537 774
isSelfGet 0 537 774
assign 1 538 776
nameGet 0 538 776
assign 1 538 777
new 0 538 777
assign 1 538 778
equals 1 538 778
assign 1 540 780
heldGet 0 540 780
assign 1 540 781
new 0 540 781
checkTypesSet 1 540 782
assign 1 542 785
namepathGet 0 542 785
assign 1 542 786
getSynNp 1 542 786
assign 1 543 787
namepathGet 0 543 787
assign 1 543 788
castsTo 1 543 788
assign 1 0 790
assign 1 543 793
namepathGet 0 543 793
assign 1 543 794
castsTo 1 543 794
assign 1 0 796
assign 1 0 799
assign 1 545 803
heldGet 0 545 803
assign 1 545 804
new 0 545 804
checkTypesSet 1 545 805
assign 1 547 808
new 0 547 808
assign 1 547 809
namepathGet 0 547 809
assign 1 547 810
add 1 547 810
assign 1 547 811
new 0 547 811
assign 1 547 812
add 1 547 812
assign 1 547 813
namepathGet 0 547 813
assign 1 547 814
add 1 547 814
assign 1 547 815
new 2 547 815
throw 1 547 816
assign 1 551 821
namepathGet 0 551 821
assign 1 551 822
getSynNp 1 551 822
assign 1 552 823
heldGet 0 552 823
assign 1 552 824
rtypeGet 0 552 824
assign 1 552 825
namepathGet 0 552 825
assign 1 552 826
castsTo 1 552 826
assign 1 554 828
heldGet 0 554 828
assign 1 554 829
new 0 554 829
checkTypesSet 1 554 830
assign 1 556 833
heldGet 0 556 833
assign 1 556 834
rtypeGet 0 556 834
assign 1 556 835
namepathGet 0 556 835
assign 1 556 836
getSynNp 1 556 836
assign 1 557 837
namepathGet 0 557 837
assign 1 557 838
castsTo 1 557 838
assign 1 559 840
heldGet 0 559 840
assign 1 559 841
new 0 559 841
checkTypesSet 1 559 842
assign 1 561 845
new 0 561 845
assign 1 561 846
new 2 561 846
throw 1 561 847
assign 1 568 854
heldGet 0 568 854
assign 1 568 855
new 0 568 855
checkTypesSet 1 568 856
assign 1 571 860
heldGet 0 571 860
assign 1 571 861
new 0 571 861
checkTypesSet 1 571 862
assign 1 574 866
containedGet 0 574 866
assign 1 574 867
firstGet 0 574 867
assign 1 576 868
heldGet 0 576 868
assign 1 576 869
isDeclaredGet 0 576 869
assign 1 577 871
heldGet 0 577 871
assign 1 579 874
ptyMapGet 0 579 874
assign 1 579 875
heldGet 0 579 875
assign 1 579 876
nameGet 0 579 876
assign 1 579 877
get 1 579 877
assign 1 579 878
memSynGet 0 579 878
assign 1 582 880
isTypedGet 0 582 880
assign 1 582 881
not 0 582 881
assign 1 0 883
assign 1 582 886
heldGet 0 582 886
assign 1 582 887
orgNameGet 0 582 887
assign 1 582 888
new 0 582 888
assign 1 582 889
equals 1 582 889
assign 1 0 891
assign 1 0 894
assign 1 583 898
heldGet 0 583 898
assign 1 583 899
new 0 583 899
checkTypesSet 1 583 900
assign 1 585 903
heldGet 0 585 903
assign 1 585 904
new 0 585 904
checkTypesSet 1 585 905
assign 1 586 906
heldGet 0 586 906
assign 1 586 907
isConstructGet 0 586 907
assign 1 587 909
heldGet 0 587 909
assign 1 587 910
newNpGet 0 587 910
assign 1 587 911
undef 1 587 916
assign 1 588 917
new 0 588 917
assign 1 588 918
new 1 588 918
throw 1 588 919
assign 1 590 921
heldGet 0 590 921
assign 1 590 922
newNpGet 0 590 922
assign 1 590 923
getSynNp 1 590 923
assign 1 591 924
mtdMapGet 0 591 924
assign 1 591 925
heldGet 0 591 925
assign 1 591 926
nameGet 0 591 926
assign 1 591 927
get 1 591 927
assign 1 593 930
namepathGet 0 593 930
assign 1 593 931
getSynNp 1 593 931
assign 1 594 932
mtdMapGet 0 594 932
assign 1 594 933
heldGet 0 594 933
assign 1 594 934
nameGet 0 594 934
assign 1 594 935
get 1 594 935
assign 1 596 937
undef 1 596 942
assign 1 597 943
new 0 597 943
assign 1 597 944
new 2 597 944
throw 1 597 945
assign 1 599 947
argSynsGet 0 599 947
assign 1 600 948
nextPeerGet 0 600 948
assign 1 601 949
new 0 601 949
assign 1 601 952
lengthGet 0 601 952
assign 1 601 953
lesser 1 601 958
assign 1 602 959
get 1 602 959
assign 1 603 960
isTypedGet 0 603 960
assign 1 604 962
undef 1 604 967
assign 1 605 968
new 0 605 968
assign 1 605 969
new 2 605 969
throw 1 605 970
assign 1 606 973
typenameGet 0 606 973
assign 1 606 974
VARGet 0 606 974
assign 1 606 975
notEquals 1 606 980
assign 1 606 981
typenameGet 0 606 981
assign 1 606 982
NULLGet 0 606 982
assign 1 606 983
notEquals 1 606 988
assign 1 0 989
assign 1 0 992
assign 1 0 996
assign 1 607 999
new 0 607 999
assign 1 607 1000
typenameGet 0 607 1000
assign 1 607 1001
toString 0 607 1001
assign 1 607 1002
add 1 607 1002
assign 1 607 1003
new 2 607 1003
throw 1 607 1004
assign 1 609 1007
typenameGet 0 609 1007
assign 1 609 1008
VARGet 0 609 1008
assign 1 609 1009
equals 1 609 1014
assign 1 610 1015
heldGet 0 610 1015
assign 1 611 1016
isTypedGet 0 611 1016
assign 1 611 1017
not 0 611 1022
assign 1 612 1023
heldGet 0 612 1023
assign 1 612 1024
new 0 612 1024
checkTypesSet 1 612 1025
assign 1 613 1026
heldGet 0 613 1026
assign 1 613 1027
argCastsGet 0 613 1027
assign 1 613 1028
namepathGet 0 613 1028
put 2 613 1029
assign 1 616 1032
namepathGet 0 616 1032
assign 1 616 1033
getSynNp 1 616 1033
assign 1 617 1034
namepathGet 0 617 1034
assign 1 617 1035
castsTo 1 617 1035
assign 1 617 1036
not 0 617 1036
assign 1 618 1038
new 0 618 1038
assign 1 618 1039
namepathGet 0 618 1039
assign 1 618 1040
toString 0 618 1040
assign 1 618 1041
add 1 618 1041
assign 1 618 1042
new 0 618 1042
assign 1 618 1043
add 1 618 1043
assign 1 618 1044
namepathGet 0 618 1044
assign 1 618 1045
toString 0 618 1045
assign 1 618 1046
add 1 618 1046
assign 1 618 1047
new 2 618 1047
throw 1 618 1048
assign 1 627 1053
nextPeerGet 0 627 1053
assign 1 601 1054
increment 0 601 1054
assign 1 632 1064
nextDescendGet 0 632 1064
return 1 632 1065
return 1 0 1068
assign 1 0 1071
return 1 0 1075
assign 1 0 1078
return 1 0 1082
assign 1 0 1085
return 1 0 1089
assign 1 0 1092
return 1 0 1096
assign 1 0 1099
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 493012039: return bem_buildGet_0();
case 2028575047: return bem_emitterGet_0();
case 1308786538: return bem_echo_0();
case 1437330926: return bem_inClassNpGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2128364298: return bem_cposGet_0();
case 2055025483: return bem_serializeContents_0();
case 2041762316: return bem_inClassGet_0();
case 1012494862: return bem_once_0();
case 997464046: return bem_inClassSynGet_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1755995201: return bem_transGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 1354714650: return bem_copy_0();
case 229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 2030680063: return bem_inClassSet_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 218876431: return bem_constSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1744912948: return bem_transSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 986381793: return bem_inClassSynSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 2017492794: return bem_emitterSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 229048805: return bem_begin_1(bevd_0);
case 2117282045: return bem_cposSet_1(bevd_0);
case 2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_9_BuildVisitTypeCheck();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst = (BEC_3_5_5_9_BuildVisitTypeCheck)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_9_BuildVisitTypeCheck.bevs_inst;
}
}
