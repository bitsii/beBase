package be.BEL_4_Base;
/* IO:File: source/base/LinkedList.be */
public class BEC_9_10_ContainerLinkedList extends BEC_6_6_SystemObject {
public BEC_9_10_ContainerLinkedList() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(1));
public static BEC_9_10_ContainerLinkedList bevs_inst;
public BEC_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_6_6_SystemObject beva_toHold) throws Throwable {
BEC_9_10_4_ContainerLinkedListNode bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_9_10_ContainerLinkedList bevl_other = null;
BEC_10_8_LinkedListIterator bevl_iter = null;
BEC_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_other = (BEC_9_10_ContainerLinkedList) this.bem_create_0();
bevl_iter = (BEC_10_8_LinkedListIterator) this.bem_iteratorGet_0();
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 141 */ {
return bevl_other;
} /* Line: 142 */
while (true)
 /* Line: 146 */ {
if (bevl_f == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 146 */ {
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 148 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 149 */
if (bevl_fnode == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 152 */ {
bevl_fnode = bevl_f;
} /* Line: 153 */
bevl_last = bevl_f;
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 156 */
 else  /* Line: 146 */ {
break;
} /* Line: 146 */
} /* Line: 146 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return bevl_other;
} /*method end*/
public BEC_6_6_SystemObject bem_appendNode_1(BEC_6_6_SystemObject beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_lastNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 165 */ {
beva_node.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 168 */
 else  /* Line: 169 */ {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 171 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_prependNode_1(BEC_6_6_SystemObject beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 177 */ {
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 180 */
 else  /* Line: 181 */ {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 183 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_deleteNode_1(BEC_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_insertBeforeNode_2(BEC_6_6_SystemObject beva_toIns, BEC_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, beva_toIns);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_get_1(BEC_4_3_MathInt beva_pos) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_10_8_LinkedListIterator bevl_iter = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = beva_pos.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 196 */ {
bevt_2_tmpvar_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpvar_phold;
} /* Line: 197 */
bevl_i = (new BEC_4_3_MathInt(0));
bevl_iter = (BEC_10_8_LinkedListIterator) this.bem_iteratorGet_0();
while (true)
 /* Line: 200 */ {
bevt_3_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 200 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(beva_pos);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 201 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 202 */
 else  /* Line: 203 */ {
break;
} /* Line: 204 */
bevl_i.bem_incrementValue_0();
} /* Line: 206 */
 else  /* Line: 200 */ {
break;
} /* Line: 200 */
} /* Line: 200 */
bevt_5_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 208 */ {
return null;
} /* Line: 209 */
bevt_6_tmpvar_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_put_2(BEC_4_3_MathInt beva_pos, BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_10_8_LinkedListIterator bevl_iter = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpvar_phold);
bevl_i = (new BEC_4_3_MathInt(0));
bevl_iter = (BEC_10_8_LinkedListIterator) this.bem_iteratorGet_0();
while (true)
 /* Line: 217 */ {
bevt_1_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 217 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(beva_pos);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 218 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 219 */
 else  /* Line: 220 */ {
break;
} /* Line: 221 */
bevl_i.bem_incrementValue_0();
} /* Line: 223 */
 else  /* Line: 217 */ {
break;
} /* Line: 217 */
} /* Line: 217 */
bevt_3_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 225 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 226 */
bevt_5_tmpvar_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 232 */ {
return null;
} /* Line: 232 */
bevt_1_tmpvar_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_5_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_3_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 237 */ {
bevt_5_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_heldGet_0();
return bevt_4_tmpvar_phold;
} /* Line: 238 */
return null;
} /*method end*/
public BEC_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_6_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_9_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_10_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 244 */ {
bevt_4_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 244 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 244 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 244 */
 else  /* Line: 244 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 244 */ {
bevt_7_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_nextGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 244 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 244 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 244 */
 else  /* Line: 244 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 244 */ {
bevt_10_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_nextGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_heldGet_0();
return bevt_8_tmpvar_phold;
} /* Line: 245 */
return null;
} /*method end*/
public BEC_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 251 */ {
return null;
} /* Line: 251 */
bevt_1_tmpvar_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_getNode_1(BEC_6_6_SystemObject beva_pos) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_10_8_LinkedListIterator bevl_iter = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = beva_pos.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 256 */ {
return bevp_firstNode;
} /* Line: 257 */
bevl_i = (new BEC_4_3_MathInt(0));
bevl_iter = (BEC_10_8_LinkedListIterator) this.bem_iteratorGet_0();
while (true)
 /* Line: 260 */ {
bevt_2_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevt_3_tmpvar_phold = bevl_i.bem_lesser_1((BEC_4_3_MathInt) beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 262 */
 else  /* Line: 263 */ {
break;
} /* Line: 264 */
bevl_i.bem_incrementValue_0();
} /* Line: 266 */
 else  /* Line: 260 */ {
break;
} /* Line: 260 */
} /* Line: 260 */
bevt_4_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 268 */ {
return null;
} /* Line: 269 */
bevt_5_tmpvar_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_addValueWhole_1(BEC_6_6_SystemObject beva_held) throws Throwable {
BEC_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addValue_1(BEC_6_6_SystemObject beva_held) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_held == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 280 */ {
bevt_2_tmpvar_phold = beva_held.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 280 */
 else  /* Line: 280 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 280 */ {
this.bem_addAll_1(beva_held);
} /* Line: 281 */
 else  /* Line: 282 */ {
this.bem_addValueWhole_1(beva_held);
} /* Line: 283 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_iterateAdd_1(BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 288 */ {
while (true)
 /* Line: 289 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 289 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 290 */
 else  /* Line: 289 */ {
break;
} /* Line: 289 */
} /* Line: 289 */
} /* Line: 289 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addAll_1(BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 296 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 297 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_prepend_1(BEC_6_6_SystemObject beva_held) throws Throwable {
BEC_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_4_3_MathInt bevl_cnt = null;
BEC_6_6_SystemObject bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_cnt = (new BEC_4_3_MathInt(0));
bevl_i = this.bem_iteratorGet_0();
while (true)
 /* Line: 308 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 308 */ {
bevl_i.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_cnt.bem_incrementValue_0();
} /* Line: 310 */
 else  /* Line: 308 */ {
break;
} /* Line: 308 */
} /* Line: 308 */
return bevl_cnt;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_lengthGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_1_tmpvar_phold;
} /* Line: 321 */
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_9_5_ContainerArray bem_toNodeArray_0() throws Throwable {
BEC_4_3_MathInt bevl_len = null;
BEC_9_5_ContainerArray bevl_toret = null;
BEC_4_3_MathInt bevl_cnt = null;
BEC_10_8_LinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (new BEC_9_5_ContainerArray()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_4_3_MathInt(0));
bevl_i = (BEC_10_8_LinkedListIterator) this.bem_iteratorGet_0();
while (true)
 /* Line: 330 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 330 */ {
bevt_1_tmpvar_phold = bevl_cnt.bem_lesser_1(bevl_len);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 331 */ {
bevt_2_tmpvar_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpvar_phold);
} /* Line: 332 */
bevl_cnt.bem_incrementValue_0();
} /* Line: 334 */
 else  /* Line: 330 */ {
break;
} /* Line: 330 */
} /* Line: 330 */
return bevl_toret;
} /*method end*/
public BEC_9_5_ContainerArray bem_toArray_0() throws Throwable {
BEC_4_3_MathInt bevl_len = null;
BEC_9_5_ContainerArray bevl_toret = null;
BEC_4_3_MathInt bevl_cnt = null;
BEC_10_8_LinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (new BEC_9_5_ContainerArray()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_4_3_MathInt(0));
bevl_i = (BEC_10_8_LinkedListIterator) this.bem_iteratorGet_0();
while (true)
 /* Line: 343 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 343 */ {
bevt_1_tmpvar_phold = bevl_cnt.bem_lesser_1(bevl_len);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 344 */ {
bevt_3_tmpvar_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpvar_phold);
} /* Line: 345 */
bevl_cnt.bem_incrementValue_0();
} /* Line: 347 */
 else  /* Line: 343 */ {
break;
} /* Line: 343 */
} /* Line: 343 */
return bevl_toret;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_10_8_LinkedListIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_10_8_LinkedListIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_subList_1(BEC_4_3_MathInt beva_start) throws Throwable {
BEC_9_10_ContainerLinkedList bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_4_MathInts bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_4_MathInts) BEC_4_4_MathInts.bevs_inst.bem_new_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_maxGet_0();
bevt_0_tmpvar_phold = this.bem_subList_2(beva_start, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_subList_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_res = null;
BEC_6_6_SystemObject bevl_iter = null;
BEC_4_3_MathInt bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_res = (BEC_9_10_ContainerLinkedList) this.bem_create_0();
bevt_0_tmpvar_phold = beva_end.bem_lesserEquals_1(beva_start);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 366 */ {
return bevl_res;
} /* Line: 367 */
bevl_iter = this.bem_iteratorGet_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 370 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_end);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 370 */ {
bevt_3_tmpvar_phold = bevl_iter.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 371 */ {
return bevl_res;
} /* Line: 372 */
bevl_x = bevl_iter.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_i.bem_greaterEquals_1(beva_start);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 376 */
bevl_i.bem_incrementValue_0();
} /* Line: 370 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
return bevl_res;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_1_tmpvar_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 419 */ {
if (bevl_current == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 419 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpvar_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpvar_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 424 */
 else  /* Line: 419 */ {
break;
} /* Line: 419 */
} /* Line: 419 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_6_6_SystemObject bem_firstNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_6_6_SystemObject bem_lastNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {133, 133, 138, 139, 140, 141, 141, 142, 146, 146, 147, 148, 148, 149, 152, 152, 153, 155, 156, 158, 159, 160, 164, 165, 165, 166, 167, 168, 170, 171, 176, 177, 177, 178, 179, 180, 182, 183, 188, 192, 196, 196, 197, 197, 199, 200, 200, 201, 202, 206, 208, 209, 211, 211, 215, 215, 216, 217, 217, 218, 219, 223, 225, 226, 226, 228, 228, 232, 232, 232, 233, 233, 237, 237, 237, 237, 237, 0, 0, 0, 238, 238, 238, 240, 244, 244, 244, 244, 244, 0, 0, 0, 244, 244, 244, 244, 0, 0, 0, 245, 245, 245, 245, 247, 251, 251, 251, 252, 252, 256, 256, 257, 259, 260, 260, 261, 262, 266, 268, 269, 271, 271, 275, 276, 280, 280, 280, 0, 0, 0, 281, 283, 288, 288, 289, 290, 290, 296, 296, 297, 297, 302, 303, 307, 308, 308, 309, 310, 312, 316, 316, 320, 320, 321, 321, 323, 323, 327, 328, 329, 330, 330, 331, 332, 332, 334, 336, 340, 341, 342, 343, 343, 344, 345, 345, 345, 347, 349, 353, 353, 357, 357, 361, 361, 361, 361, 365, 366, 367, 369, 370, 370, 371, 371, 372, 374, 375, 376, 370, 379, 417, 418, 419, 419, 420, 421, 421, 422, 423, 424, 426, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 30, 31, 32, 33, 38, 39, 43, 48, 49, 50, 55, 56, 58, 63, 64, 66, 67, 73, 74, 75, 79, 80, 85, 86, 87, 88, 91, 92, 98, 99, 104, 105, 106, 107, 110, 111, 116, 120, 133, 134, 136, 137, 139, 140, 143, 145, 147, 152, 158, 160, 162, 163, 174, 175, 176, 177, 180, 182, 184, 189, 195, 197, 198, 200, 201, 206, 211, 212, 214, 215, 224, 229, 230, 231, 236, 237, 240, 244, 247, 248, 249, 251, 265, 270, 271, 272, 277, 278, 281, 285, 288, 289, 290, 295, 296, 299, 303, 306, 307, 308, 309, 311, 316, 321, 322, 324, 325, 336, 337, 339, 341, 342, 345, 347, 349, 354, 360, 362, 364, 365, 369, 370, 377, 382, 383, 385, 388, 392, 395, 398, 406, 411, 414, 416, 417, 429, 434, 435, 436, 442, 443, 450, 451, 454, 456, 457, 463, 467, 468, 474, 479, 480, 481, 483, 484, 494, 495, 496, 497, 500, 502, 504, 505, 507, 513, 524, 525, 526, 527, 530, 532, 534, 535, 536, 538, 544, 548, 549, 553, 554, 560, 561, 562, 563, 575, 576, 578, 580, 581, 584, 586, 587, 589, 591, 592, 594, 596, 602, 610, 611, 614, 619, 620, 621, 622, 623, 624, 625, 631, 635, 638, 642, 645};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 133 17
new 2 133 17
return 1 133 18
assign 1 138 30
create 0 138 30
assign 1 139 31
iteratorGet 0 139 31
assign 1 140 32
nextNodeGet 0 140 32
assign 1 141 33
undef 1 141 38
return 1 142 39
assign 1 146 43
def 1 146 48
assign 1 147 49
copy 0 147 49
assign 1 148 50
def 1 148 55
nextSet 1 149 56
assign 1 152 58
undef 1 152 63
assign 1 153 64
assign 1 155 66
assign 1 156 67
nextNodeGet 0 156 67
firstNodeSet 1 158 73
lastNodeSet 1 159 74
return 1 160 75
nextSet 1 164 79
assign 1 165 80
def 1 165 85
priorSet 1 166 86
nextSet 1 167 87
assign 1 168 88
assign 1 170 91
assign 1 171 92
nextSet 1 176 98
assign 1 177 99
def 1 177 104
nextSet 1 178 105
priorSet 1 179 106
assign 1 180 107
assign 1 182 110
assign 1 183 111
delete 0 188 116
insertBefore 1 192 120
assign 1 196 133
new 0 196 133
assign 1 196 134
equals 1 196 134
assign 1 197 136
heldGet 0 197 136
return 1 197 137
assign 1 199 139
new 0 199 139
assign 1 200 140
iteratorGet 0 200 140
assign 1 200 143
hasNextGet 0 200 143
assign 1 201 145
lesser 1 201 145
nextGet 0 202 147
incrementValue 0 206 152
assign 1 208 158
notEquals 1 208 158
return 1 209 160
assign 1 211 162
nextGet 0 211 162
return 1 211 163
assign 1 215 174
new 0 215 174
assign 1 215 175
add 1 215 175
assign 1 216 176
new 0 216 176
assign 1 217 177
iteratorGet 0 217 177
assign 1 217 180
hasNextGet 0 217 180
assign 1 218 182
lesser 1 218 182
nextGet 0 219 184
incrementValue 0 223 189
assign 1 225 195
notEquals 1 225 195
assign 1 226 197
new 0 226 197
return 1 226 198
assign 1 228 200
currentSet 1 228 200
return 1 228 201
assign 1 232 206
undef 1 232 211
return 1 232 212
assign 1 233 214
heldGet 0 233 214
return 1 233 215
assign 1 237 224
def 1 237 229
assign 1 237 230
nextGet 0 237 230
assign 1 237 231
def 1 237 236
assign 1 0 237
assign 1 0 240
assign 1 0 244
assign 1 238 247
nextGet 0 238 247
assign 1 238 248
heldGet 0 238 248
return 1 238 249
return 1 240 251
assign 1 244 265
def 1 244 270
assign 1 244 271
nextGet 0 244 271
assign 1 244 272
def 1 244 277
assign 1 0 278
assign 1 0 281
assign 1 0 285
assign 1 244 288
nextGet 0 244 288
assign 1 244 289
nextGet 0 244 289
assign 1 244 290
def 1 244 295
assign 1 0 296
assign 1 0 299
assign 1 0 303
assign 1 245 306
nextGet 0 245 306
assign 1 245 307
nextGet 0 245 307
assign 1 245 308
heldGet 0 245 308
return 1 245 309
return 1 247 311
assign 1 251 316
undef 1 251 321
return 1 251 322
assign 1 252 324
heldGet 0 252 324
return 1 252 325
assign 1 256 336
new 0 256 336
assign 1 256 337
equals 1 256 337
return 1 257 339
assign 1 259 341
new 0 259 341
assign 1 260 342
iteratorGet 0 260 342
assign 1 260 345
hasNextGet 0 260 345
assign 1 261 347
lesser 1 261 347
nextGet 0 262 349
incrementValue 0 266 354
assign 1 268 360
notEquals 1 268 360
return 1 269 362
assign 1 271 364
nextNodeGet 0 271 364
return 1 271 365
assign 1 275 369
newNode 1 275 369
appendNode 1 276 370
assign 1 280 377
def 1 280 382
assign 1 280 383
sameType 1 280 383
assign 1 0 385
assign 1 0 388
assign 1 0 392
addAll 1 281 395
addValueWhole 1 283 398
assign 1 288 406
def 1 288 411
assign 1 289 414
hasNextGet 0 289 414
assign 1 290 416
nextGet 0 290 416
addValueWhole 1 290 417
assign 1 296 429
def 1 296 434
assign 1 297 435
iteratorGet 0 297 435
iterateAdd 1 297 436
assign 1 302 442
newNode 1 302 442
prependNode 1 303 443
assign 1 307 450
new 0 307 450
assign 1 308 451
iteratorGet 0 308 451
assign 1 308 454
hasNextGet 0 308 454
nextGet 0 309 456
incrementValue 0 310 457
return 1 312 463
assign 1 316 467
lengthGet 0 316 467
return 1 316 468
assign 1 320 474
undef 1 320 479
assign 1 321 480
new 0 321 480
return 1 321 481
assign 1 323 483
new 0 323 483
return 1 323 484
assign 1 327 494
lengthGet 0 327 494
assign 1 328 495
new 1 328 495
assign 1 329 496
new 0 329 496
assign 1 330 497
iteratorGet 0 330 497
assign 1 330 500
hasNextGet 0 330 500
assign 1 331 502
lesser 1 331 502
assign 1 332 504
nextNodeGet 0 332 504
put 2 332 505
incrementValue 0 334 507
return 1 336 513
assign 1 340 524
lengthGet 0 340 524
assign 1 341 525
new 1 341 525
assign 1 342 526
new 0 342 526
assign 1 343 527
iteratorGet 0 343 527
assign 1 343 530
hasNextGet 0 343 530
assign 1 344 532
lesser 1 344 532
assign 1 345 534
nextNodeGet 0 345 534
assign 1 345 535
heldGet 0 345 535
put 2 345 536
incrementValue 0 347 538
return 1 349 544
assign 1 353 548
new 1 353 548
return 1 353 549
assign 1 357 553
iteratorGet 0 357 553
return 1 357 554
assign 1 361 560
new 0 361 560
assign 1 361 561
maxGet 0 361 561
assign 1 361 562
subList 2 361 562
return 1 361 563
assign 1 365 575
create 0 365 575
assign 1 366 576
lesserEquals 1 366 576
return 1 367 578
assign 1 369 580
iteratorGet 0 369 580
assign 1 370 581
new 0 370 581
assign 1 370 584
lesser 1 370 584
assign 1 371 586
hasNextGet 0 371 586
assign 1 371 587
not 0 371 587
return 1 372 589
assign 1 374 591
nextGet 0 374 591
assign 1 375 592
greaterEquals 1 375 592
addValue 1 376 594
incrementValue 0 370 596
return 1 379 602
assign 1 417 610
assign 1 418 611
assign 1 419 614
def 1 419 619
assign 1 420 620
nextGet 0 420 620
assign 1 421 621
priorGet 0 421 621
nextSet 1 421 622
priorSet 1 422 623
assign 1 423 624
assign 1 424 625
assign 1 426 631
return 1 0 635
assign 1 0 638
return 1 0 642
assign 1 0 645
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 789570067: return bem_toNodeArray_0();
case 390409747: return bem_reverse_0();
case 1696089045: return bem_firstNodeGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1616433729: return bem_lengthGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1897309391: return bem_toArray_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 978128800: return bem_thirdGet_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case 1990707345: return bem_lastGet_0();
case 1351154001: return bem_lastNodeGet_0();
case 786424307: return bem_tagGet_0();
case 242848115: return bem_secondGet_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 228068295: return bem_addValueWhole_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 908228929: return bem_deleteNode_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1707171298: return bem_firstNodeSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 655844394: return bem_getNode_1(bevd_0);
case 596113616: return bem_subList_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 743891212: return bem_newNode_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1167376622: return bem_appendNode_1(bevd_0);
case 1340071748: return bem_lastNodeSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1007846464: return bem_prepend_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1142954398: return bem_prependNode_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 107034370: return bem_put_2((BEC_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 596113615: return bem_subList_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1098622227: return bem_insertBeforeNode_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_10_ContainerLinkedList.bevs_inst = (BEC_9_10_ContainerLinkedList)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_10_ContainerLinkedList.bevs_inst;
}
}
