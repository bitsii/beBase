package be.BEL_4_Base;
/* IO:File: source/base/LinkedList.be */
public class BEC_9_10_ContainerLinkedList extends BEC_6_6_SystemObject {
public BEC_9_10_ContainerLinkedList() { }
private static byte[] becc_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(1));
public static BEC_9_10_ContainerLinkedList bevs_inst;
public BEC_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_9_10_4_ContainerLinkedListNode bevp_lastNode;
public BEC_9_10_ContainerLinkedList bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_6_6_SystemObject beva_toHold) throws Throwable {
BEC_9_10_4_ContainerLinkedListNode bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_copy_0() throws Throwable {
BEC_9_10_ContainerLinkedList bevl_other = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevl_other = (BEC_9_10_ContainerLinkedList) this.bem_create_0();
bevl_iter = this.bem_linkedListIteratorGet_0();
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 142 */ {
return (BEC_9_10_ContainerLinkedList) bevl_other;
} /* Line: 143 */
while (true)
 /* Line: 147 */ {
if (bevl_f == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 147 */ {
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 149 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 150 */
if (bevl_fnode == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 153 */ {
bevl_fnode = bevl_f;
} /* Line: 154 */
bevl_last = bevl_f;
bevl_f = (BEC_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 157 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_9_10_ContainerLinkedList) bevl_other;
} /*method end*/
public BEC_6_6_SystemObject bem_appendNode_1(BEC_6_6_SystemObject beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_lastNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 166 */ {
beva_node.bemd_1(957596394, BEL_4_Base.bevn_priorSet_1, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 169 */
 else  /* Line: 170 */ {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 172 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_prependNode_1(BEC_6_6_SystemObject beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, null);
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 178 */ {
beva_node.bemd_1(1205705825, BEL_4_Base.bevn_nextSet_1, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 181 */
 else  /* Line: 182 */ {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 184 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_deleteNode_1(BEC_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_insertBeforeNode_2(BEC_6_6_SystemObject beva_toIns, BEC_6_6_SystemObject beva_node) throws Throwable {
beva_node.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, beva_toIns);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_get_1(BEC_4_3_MathInt beva_pos) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = beva_pos.bem_equals_1(bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 197 */ {
bevt_2_tmpvar_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpvar_phold;
} /* Line: 198 */
bevl_i = (new BEC_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 201 */ {
bevt_3_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 201 */ {
bevt_4_tmpvar_phold = bevl_i.bem_lesser_1(beva_pos);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 203 */
 else  /* Line: 204 */ {
break;
} /* Line: 205 */
bevl_i.bem_incrementValue_0();
} /* Line: 207 */
 else  /* Line: 201 */ {
break;
} /* Line: 201 */
} /* Line: 201 */
bevt_5_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 209 */ {
return null;
} /* Line: 210 */
bevt_6_tmpvar_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_put_2(BEC_4_3_MathInt beva_pos, BEC_6_6_SystemObject beva_value) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpvar_phold);
bevl_i = (new BEC_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 218 */ {
bevt_1_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 218 */ {
bevt_2_tmpvar_phold = bevl_i.bem_lesser_1(beva_pos);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 219 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 220 */
 else  /* Line: 221 */ {
break;
} /* Line: 222 */
bevl_i.bem_incrementValue_0();
} /* Line: 224 */
 else  /* Line: 218 */ {
break;
} /* Line: 218 */
} /* Line: 218 */
bevt_3_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 226 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 227 */
bevt_5_tmpvar_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_firstGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 233 */ {
return null;
} /* Line: 233 */
bevt_1_tmpvar_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_secondGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_5_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_3_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 238 */
 else  /* Line: 238 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 238 */ {
bevt_5_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_heldGet_0();
return bevt_4_tmpvar_phold;
} /* Line: 239 */
return null;
} /*method end*/
public BEC_6_6_SystemObject bem_thirdGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_4_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_6_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_9_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_10_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_4_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_7_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_nextGet_0();
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 245 */ {
bevt_10_tmpvar_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_nextGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_heldGet_0();
return bevt_8_tmpvar_phold;
} /* Line: 246 */
return null;
} /*method end*/
public BEC_6_6_SystemObject bem_lastGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 252 */ {
return null;
} /* Line: 252 */
bevt_1_tmpvar_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_getNode_1(BEC_6_6_SystemObject beva_pos) throws Throwable {
BEC_4_3_MathInt bevl_i = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = beva_pos.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_1_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 257 */ {
return bevp_firstNode;
} /* Line: 258 */
bevl_i = (new BEC_4_3_MathInt(0));
bevl_iter = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 261 */ {
bevt_2_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 261 */ {
bevt_3_tmpvar_phold = bevl_i.bem_lesser_1((BEC_4_3_MathInt) beva_pos);
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 263 */
 else  /* Line: 264 */ {
break;
} /* Line: 265 */
bevl_i.bem_incrementValue_0();
} /* Line: 267 */
 else  /* Line: 261 */ {
break;
} /* Line: 261 */
} /* Line: 261 */
bevt_4_tmpvar_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 269 */ {
return null;
} /* Line: 270 */
bevt_5_tmpvar_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_addValueWhole_1(BEC_6_6_SystemObject beva_held) throws Throwable {
BEC_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addValue_1(BEC_6_6_SystemObject beva_held) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_held == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 281 */ {
bevt_2_tmpvar_phold = beva_held.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, this);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 281 */
 else  /* Line: 281 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 281 */ {
this.bem_addAll_1(beva_held);
} /* Line: 282 */
 else  /* Line: 283 */ {
this.bem_addValueWhole_1(beva_held);
} /* Line: 284 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_iterateAdd_1(BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 289 */ {
while (true)
 /* Line: 290 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_2_tmpvar_phold = beva_val.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
this.bem_addValueWhole_1(bevt_2_tmpvar_phold);
} /* Line: 291 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
} /* Line: 290 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addAll_1(BEC_6_6_SystemObject beva_val) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
if (beva_val == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 297 */ {
bevt_1_tmpvar_phold = beva_val.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
this.bem_iterateAdd_1(bevt_1_tmpvar_phold);
} /* Line: 298 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_prepend_1(BEC_6_6_SystemObject beva_held) throws Throwable {
BEC_6_6_SystemObject bevl_nn = null;
bevl_nn = this.bem_newNode_1(beva_held);
this.bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public BEC_4_3_MathInt bem_lengthGet_0() throws Throwable {
BEC_4_3_MathInt bevl_cnt = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_cnt = (new BEC_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 309 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 309 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bem_incrementValue_0();
} /* Line: 311 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
return bevl_cnt;
} /*method end*/
public BEC_4_3_MathInt bem_sizeGet_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_lengthGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_5_4_LogicBool bem_isEmptyGet_0() throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 321 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_1_tmpvar_phold;
} /* Line: 322 */
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_9_5_ContainerArray bem_toNodeArray_0() throws Throwable {
BEC_4_3_MathInt bevl_len = null;
BEC_9_5_ContainerArray bevl_toret = null;
BEC_4_3_MathInt bevl_cnt = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (new BEC_9_5_ContainerArray()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 331 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 331 */ {
bevt_1_tmpvar_phold = bevl_cnt.bem_lesser_1(bevl_len);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 332 */ {
bevt_2_tmpvar_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpvar_phold);
} /* Line: 333 */
bevl_cnt.bem_incrementValue_0();
} /* Line: 335 */
 else  /* Line: 331 */ {
break;
} /* Line: 331 */
} /* Line: 331 */
return bevl_toret;
} /*method end*/
public BEC_9_5_ContainerArray bem_toArray_0() throws Throwable {
BEC_4_3_MathInt bevl_len = null;
BEC_9_5_ContainerArray bevl_toret = null;
BEC_4_3_MathInt bevl_cnt = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_len = this.bem_lengthGet_0();
bevl_toret = (new BEC_9_5_ContainerArray()).bem_new_1(bevl_len);
bevl_cnt = (new BEC_4_3_MathInt(0));
bevl_i = this.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 344 */ {
bevt_0_tmpvar_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 344 */ {
bevt_1_tmpvar_phold = bevl_cnt.bem_lesser_1(bevl_len);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 345 */ {
bevt_3_tmpvar_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpvar_phold);
} /* Line: 346 */
bevl_cnt.bem_incrementValue_0();
} /* Line: 348 */
 else  /* Line: 344 */ {
break;
} /* Line: 344 */
} /* Line: 344 */
return bevl_toret;
} /*method end*/
public BEC_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() throws Throwable {
BEC_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_iteratorGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_subList_1(BEC_4_3_MathInt beva_start) throws Throwable {
BEC_9_10_ContainerLinkedList bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_4_4_MathInts bevt_2_tmpvar_phold = null;
bevt_2_tmpvar_phold = (BEC_4_4_MathInts) BEC_4_4_MathInts.bevs_inst;
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_maxGet_0();
bevt_0_tmpvar_phold = this.bem_subList_2(beva_start, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_subList_2(BEC_4_3_MathInt beva_start, BEC_4_3_MathInt beva_end) throws Throwable {
BEC_9_10_ContainerLinkedList bevl_res = null;
BEC_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_4_3_MathInt bevl_i = null;
BEC_6_6_SystemObject bevl_x = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
bevl_res = (BEC_9_10_ContainerLinkedList) this.bem_create_0();
bevt_0_tmpvar_phold = beva_end.bem_lesserEquals_1(beva_start);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 371 */ {
return bevl_res;
} /* Line: 372 */
bevl_iter = this.bem_linkedListIteratorGet_0();
bevl_i = (new BEC_4_3_MathInt(0));
while (true)
 /* Line: 375 */ {
bevt_1_tmpvar_phold = bevl_i.bem_lesser_1(beva_end);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevt_3_tmpvar_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 376 */ {
return bevl_res;
} /* Line: 377 */
bevl_x = bevl_iter.bem_nextGet_0();
bevt_4_tmpvar_phold = bevl_i.bem_greaterEquals_1(beva_start);
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 381 */
bevl_i.bem_incrementValue_0();
} /* Line: 375 */
 else  /* Line: 375 */ {
break;
} /* Line: 375 */
} /* Line: 375 */
return bevl_res;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_reverse_0() throws Throwable {
BEC_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_9_10_4_ContainerLinkedListNode bevt_1_tmpvar_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 424 */ {
if (bevl_current == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 424 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpvar_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpvar_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 429 */
 else  /* Line: 424 */ {
break;
} /* Line: 424 */
} /* Line: 424 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public BEC_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() throws Throwable {
return bevp_firstNode;
} /*method end*/
public BEC_6_6_SystemObject bem_firstNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_firstNode = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() throws Throwable {
return bevp_lastNode;
} /*method end*/
public BEC_6_6_SystemObject bem_lastNodeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lastNode = (BEC_9_10_4_ContainerLinkedListNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {134, 134, 139, 140, 141, 142, 142, 143, 147, 147, 148, 149, 149, 150, 153, 153, 154, 156, 157, 159, 160, 161, 165, 166, 166, 167, 168, 169, 171, 172, 177, 178, 178, 179, 180, 181, 183, 184, 189, 193, 197, 197, 198, 198, 200, 201, 201, 202, 203, 207, 209, 210, 212, 212, 216, 216, 217, 218, 218, 219, 220, 224, 226, 227, 227, 229, 229, 233, 233, 233, 234, 234, 238, 238, 238, 238, 238, 0, 0, 0, 239, 239, 239, 241, 245, 245, 245, 245, 245, 0, 0, 0, 245, 245, 245, 245, 0, 0, 0, 246, 246, 246, 246, 248, 252, 252, 252, 253, 253, 257, 257, 258, 260, 261, 261, 262, 263, 267, 269, 270, 272, 272, 276, 277, 281, 281, 281, 0, 0, 0, 282, 284, 289, 289, 290, 291, 291, 297, 297, 298, 298, 303, 304, 308, 309, 309, 310, 311, 313, 317, 317, 321, 321, 322, 322, 324, 324, 328, 329, 330, 331, 331, 332, 333, 333, 335, 337, 341, 342, 343, 344, 344, 345, 346, 346, 346, 348, 350, 354, 354, 358, 358, 362, 362, 366, 366, 366, 366, 370, 371, 372, 374, 375, 375, 376, 376, 377, 379, 380, 381, 375, 384, 422, 423, 424, 424, 425, 426, 426, 427, 428, 429, 431, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 30, 31, 32, 33, 38, 39, 43, 48, 49, 50, 55, 56, 58, 63, 64, 66, 67, 73, 74, 75, 79, 80, 85, 86, 87, 88, 91, 92, 98, 99, 104, 105, 106, 107, 110, 111, 116, 120, 133, 134, 136, 137, 139, 140, 143, 145, 147, 152, 158, 160, 162, 163, 174, 175, 176, 177, 180, 182, 184, 189, 195, 197, 198, 200, 201, 206, 211, 212, 214, 215, 224, 229, 230, 231, 236, 237, 240, 244, 247, 248, 249, 251, 265, 270, 271, 272, 277, 278, 281, 285, 288, 289, 290, 295, 296, 299, 303, 306, 307, 308, 309, 311, 316, 321, 322, 324, 325, 336, 337, 339, 341, 342, 345, 347, 349, 354, 360, 362, 364, 365, 369, 370, 377, 382, 383, 385, 388, 392, 395, 398, 406, 411, 414, 416, 417, 429, 434, 435, 436, 442, 443, 450, 451, 454, 456, 457, 463, 467, 468, 474, 479, 480, 481, 483, 484, 494, 495, 496, 497, 500, 502, 504, 505, 507, 513, 524, 525, 526, 527, 530, 532, 534, 535, 536, 538, 544, 548, 549, 553, 554, 558, 559, 565, 566, 567, 568, 580, 581, 583, 585, 586, 589, 591, 592, 594, 596, 597, 599, 601, 607, 615, 616, 619, 624, 625, 626, 627, 628, 629, 630, 636, 640, 643, 647, 650};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 134 17
new 2 134 17
return 1 134 18
assign 1 139 30
create 0 139 30
assign 1 140 31
linkedListIteratorGet 0 140 31
assign 1 141 32
nextNodeGet 0 141 32
assign 1 142 33
undef 1 142 38
return 1 143 39
assign 1 147 43
def 1 147 48
assign 1 148 49
copy 0 148 49
assign 1 149 50
def 1 149 55
nextSet 1 150 56
assign 1 153 58
undef 1 153 63
assign 1 154 64
assign 1 156 66
assign 1 157 67
nextNodeGet 0 157 67
firstNodeSet 1 159 73
lastNodeSet 1 160 74
return 1 161 75
nextSet 1 165 79
assign 1 166 80
def 1 166 85
priorSet 1 167 86
nextSet 1 168 87
assign 1 169 88
assign 1 171 91
assign 1 172 92
nextSet 1 177 98
assign 1 178 99
def 1 178 104
nextSet 1 179 105
priorSet 1 180 106
assign 1 181 107
assign 1 183 110
assign 1 184 111
delete 0 189 116
insertBefore 1 193 120
assign 1 197 133
new 0 197 133
assign 1 197 134
equals 1 197 134
assign 1 198 136
heldGet 0 198 136
return 1 198 137
assign 1 200 139
new 0 200 139
assign 1 201 140
linkedListIteratorGet 0 201 140
assign 1 201 143
hasNextGet 0 201 143
assign 1 202 145
lesser 1 202 145
nextGet 0 203 147
incrementValue 0 207 152
assign 1 209 158
notEquals 1 209 158
return 1 210 160
assign 1 212 162
nextGet 0 212 162
return 1 212 163
assign 1 216 174
new 0 216 174
assign 1 216 175
add 1 216 175
assign 1 217 176
new 0 217 176
assign 1 218 177
linkedListIteratorGet 0 218 177
assign 1 218 180
hasNextGet 0 218 180
assign 1 219 182
lesser 1 219 182
nextGet 0 220 184
incrementValue 0 224 189
assign 1 226 195
notEquals 1 226 195
assign 1 227 197
new 0 227 197
return 1 227 198
assign 1 229 200
currentSet 1 229 200
return 1 229 201
assign 1 233 206
undef 1 233 211
return 1 233 212
assign 1 234 214
heldGet 0 234 214
return 1 234 215
assign 1 238 224
def 1 238 229
assign 1 238 230
nextGet 0 238 230
assign 1 238 231
def 1 238 236
assign 1 0 237
assign 1 0 240
assign 1 0 244
assign 1 239 247
nextGet 0 239 247
assign 1 239 248
heldGet 0 239 248
return 1 239 249
return 1 241 251
assign 1 245 265
def 1 245 270
assign 1 245 271
nextGet 0 245 271
assign 1 245 272
def 1 245 277
assign 1 0 278
assign 1 0 281
assign 1 0 285
assign 1 245 288
nextGet 0 245 288
assign 1 245 289
nextGet 0 245 289
assign 1 245 290
def 1 245 295
assign 1 0 296
assign 1 0 299
assign 1 0 303
assign 1 246 306
nextGet 0 246 306
assign 1 246 307
nextGet 0 246 307
assign 1 246 308
heldGet 0 246 308
return 1 246 309
return 1 248 311
assign 1 252 316
undef 1 252 321
return 1 252 322
assign 1 253 324
heldGet 0 253 324
return 1 253 325
assign 1 257 336
new 0 257 336
assign 1 257 337
equals 1 257 337
return 1 258 339
assign 1 260 341
new 0 260 341
assign 1 261 342
linkedListIteratorGet 0 261 342
assign 1 261 345
hasNextGet 0 261 345
assign 1 262 347
lesser 1 262 347
nextGet 0 263 349
incrementValue 0 267 354
assign 1 269 360
notEquals 1 269 360
return 1 270 362
assign 1 272 364
nextNodeGet 0 272 364
return 1 272 365
assign 1 276 369
newNode 1 276 369
appendNode 1 277 370
assign 1 281 377
def 1 281 382
assign 1 281 383
sameType 1 281 383
assign 1 0 385
assign 1 0 388
assign 1 0 392
addAll 1 282 395
addValueWhole 1 284 398
assign 1 289 406
def 1 289 411
assign 1 290 414
hasNextGet 0 290 414
assign 1 291 416
nextGet 0 291 416
addValueWhole 1 291 417
assign 1 297 429
def 1 297 434
assign 1 298 435
iteratorGet 0 298 435
iterateAdd 1 298 436
assign 1 303 442
newNode 1 303 442
prependNode 1 304 443
assign 1 308 450
new 0 308 450
assign 1 309 451
linkedListIteratorGet 0 309 451
assign 1 309 454
hasNextGet 0 309 454
nextGet 0 310 456
incrementValue 0 311 457
return 1 313 463
assign 1 317 467
lengthGet 0 317 467
return 1 317 468
assign 1 321 474
undef 1 321 479
assign 1 322 480
new 0 322 480
return 1 322 481
assign 1 324 483
new 0 324 483
return 1 324 484
assign 1 328 494
lengthGet 0 328 494
assign 1 329 495
new 1 329 495
assign 1 330 496
new 0 330 496
assign 1 331 497
linkedListIteratorGet 0 331 497
assign 1 331 500
hasNextGet 0 331 500
assign 1 332 502
lesser 1 332 502
assign 1 333 504
nextNodeGet 0 333 504
put 2 333 505
incrementValue 0 335 507
return 1 337 513
assign 1 341 524
lengthGet 0 341 524
assign 1 342 525
new 1 342 525
assign 1 343 526
new 0 343 526
assign 1 344 527
linkedListIteratorGet 0 344 527
assign 1 344 530
hasNextGet 0 344 530
assign 1 345 532
lesser 1 345 532
assign 1 346 534
nextNodeGet 0 346 534
assign 1 346 535
heldGet 0 346 535
put 2 346 536
incrementValue 0 348 538
return 1 350 544
assign 1 354 548
new 1 354 548
return 1 354 549
assign 1 358 553
new 1 358 553
return 1 358 554
assign 1 362 558
iteratorGet 0 362 558
return 1 362 559
assign 1 366 565
new 0 366 565
assign 1 366 566
maxGet 0 366 566
assign 1 366 567
subList 2 366 567
return 1 366 568
assign 1 370 580
create 0 370 580
assign 1 371 581
lesserEquals 1 371 581
return 1 372 583
assign 1 374 585
linkedListIteratorGet 0 374 585
assign 1 375 586
new 0 375 586
assign 1 375 589
lesser 1 375 589
assign 1 376 591
hasNextGet 0 376 591
assign 1 376 592
not 0 376 592
return 1 377 594
assign 1 379 596
nextGet 0 379 596
assign 1 380 597
greaterEquals 1 380 597
addValue 1 381 599
incrementValue 0 375 601
return 1 384 607
assign 1 422 615
assign 1 423 616
assign 1 424 619
def 1 424 624
assign 1 425 625
nextGet 0 425 625
assign 1 426 626
priorGet 0 426 626
nextSet 1 426 627
priorSet 1 427 628
assign 1 428 629
assign 1 429 630
assign 1 431 636
return 1 0 640
assign 1 0 643
return 1 0 647
assign 1 0 650
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 845792839: return bem_iteratorGet_0();
case 1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 789570067: return bem_toNodeArray_0();
case 390409747: return bem_reverse_0();
case 1696089045: return bem_firstNodeGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case 1616433729: return bem_lengthGet_0();
case 729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case 1012494862: return bem_once_0();
case 1897309391: return bem_toArray_0();
case 1081412016: return bem_many_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 978128800: return bem_thirdGet_0();
case 1089531140: return bem_isEmptyGet_0();
case 474162694: return bem_sizeGet_0();
case 1820417453: return bem_create_0();
case 1990707345: return bem_lastGet_0();
case 1351154001: return bem_lastNodeGet_0();
case 786424307: return bem_tagGet_0();
case 242848115: return bem_secondGet_0();
case 1354714650: return bem_copy_0();
case 874473310: return bem_linkedListIteratorGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 228068295: return bem_addValueWhole_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 908228929: return bem_deleteNode_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1707171298: return bem_firstNodeSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1263766286: return bem_addAll_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 655844394: return bem_getNode_1(bevd_0);
case 596113616: return bem_subList_1((BEC_4_3_MathInt) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 743891212: return bem_newNode_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 196223929: return bem_iterateAdd_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1167376622: return bem_appendNode_1(bevd_0);
case 1340071748: return bem_lastNodeSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 2139839746: return bem_addValue_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 98246024: return bem_get_1((BEC_4_3_MathInt) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1007846464: return bem_prepend_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1142954398: return bem_prependNode_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 107034370: return bem_put_2((BEC_4_3_MathInt) bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 596113615: return bem_subList_2((BEC_4_3_MathInt) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 1098622227: return bem_insertBeforeNode_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_9_10_ContainerLinkedList();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_9_10_ContainerLinkedList.bevs_inst = (BEC_9_10_ContainerLinkedList)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_9_10_ContainerLinkedList.bevs_inst;
}
}
