package be.BEL_4_Base;
/* IO:File: source/build/BuildTypes.be */
public class BEC_5_5_BuildClass extends BEC_6_6_SystemObject {
public BEC_5_5_BuildClass() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static BEC_4_6_TextString bevo_0 = (new BEC_4_6_TextString(bels_2, 11));
private static byte[] bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
private static BEC_4_6_TextString bevo_1 = (new BEC_4_6_TextString(bels_3, 10));
public static BEC_5_5_BuildClass bevs_inst;
public BEC_5_8_BuildNamePath bevp_extends;
public BEC_9_10_ContainerLinkedList bevp_emits;
public BEC_4_6_TextString bevp_name;
public BEC_5_8_BuildNamePath bevp_namepath;
public BEC_5_8_BuildClassSyn bevp_syn;
public BEC_6_6_SystemObject bevp_fromFile;
public BEC_6_6_SystemObject bevp_libName;
public BEC_9_3_ContainerMap bevp_methods;
public BEC_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_9_10_ContainerLinkedList bevp_used;
public BEC_9_3_ContainerMap bevp_varMap;
public BEC_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_5_4_LogicBool bevp_isFinal;
public BEC_5_4_LogicBool bevp_isLocal;
public BEC_5_4_LogicBool bevp_isNotNull;
public BEC_5_4_LogicBool bevp_freeFirstSlot;
public BEC_5_4_LogicBool bevp_firstSlotNative;
public BEC_4_3_MathInt bevp_nativeSlots;
public BEC_5_4_LogicBool bevp_isArray;
public BEC_4_3_MathInt bevp_onceEvalCount;
public BEC_9_3_ContainerSet bevp_referencedProperties;
public BEC_5_4_LogicBool bevp_shouldWrite;
public BEC_4_3_MathInt bevp_belsCount;
public BEC_5_5_BuildClass bem_new_0() throws Throwable {
BEC_5_8_BuildNamePath bevl_np = null;
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
bevp_methods = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_varMap = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isLocal = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isNotNull = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_firstSlotNative = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_nativeSlots = (new BEC_4_3_MathInt(0));
bevp_isArray = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (new BEC_4_3_MathInt(0));
bevp_referencedProperties = (new BEC_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_belsCount = (new BEC_4_3_MathInt(0));
bevl_np = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_0_tmpvar_phold = (new BEC_4_6_TextString(10, bels_0));
bevl_np.bem_fromString_1(bevt_0_tmpvar_phold);
this.bem_addUsed_1(bevl_np);
bevl_np = (BEC_5_8_BuildNamePath) (new BEC_5_8_BuildNamePath()).bem_new_0();
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(11, bels_1));
bevl_np.bem_fromString_1(bevt_1_tmpvar_phold);
this.bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addUsed_1(BEC_6_6_SystemObject beva_touse) throws Throwable {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_addEmit_1(BEC_6_6_SystemObject beva_node) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_emits == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevp_emits = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 146 */
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public BEC_4_6_TextString bem_toString_0() throws Throwable {
BEC_4_6_TextString bevl_ret = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevl_ret = this.bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 153 */ {
bevt_2_tmpvar_phold = bevo_0;
bevt_1_tmpvar_phold = bevl_ret.bem_add_1(bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_tmpvar_phold.bem_add_1(bevt_3_tmpvar_phold);
if (bevp_extends == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 155 */ {
bevt_6_tmpvar_phold = bevo_1;
bevt_5_tmpvar_phold = bevl_ret.bem_add_1(bevt_6_tmpvar_phold);
bevt_7_tmpvar_phold = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
} /* Line: 156 */
} /* Line: 155 */
return bevl_ret;
} /*method end*/
public BEC_5_8_BuildNamePath bem_extendsGet_0() throws Throwable {
return bevp_extends;
} /*method end*/
public BEC_6_6_SystemObject bem_extendsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_extends = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_emitsGet_0() throws Throwable {
return bevp_emits;
} /*method end*/
public BEC_6_6_SystemObject bem_emitsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_emits = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_6_6_SystemObject bem_nameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_name = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_6_6_SystemObject bem_namepathSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_namepath = (BEC_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_6_6_SystemObject bem_synSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_syn = (BEC_5_8_BuildClassSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_6_6_SystemObject bem_fromFileSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_6_6_SystemObject bem_libNameSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_methodsGet_0() throws Throwable {
return bevp_methods;
} /*method end*/
public BEC_6_6_SystemObject bem_methodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_methods = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_orderedMethodsGet_0() throws Throwable {
return bevp_orderedMethods;
} /*method end*/
public BEC_6_6_SystemObject bem_orderedMethodsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_orderedMethods = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_usedGet_0() throws Throwable {
return bevp_used;
} /*method end*/
public BEC_6_6_SystemObject bem_usedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_used = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_varMapGet_0() throws Throwable {
return bevp_varMap;
} /*method end*/
public BEC_6_6_SystemObject bem_varMapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_varMap = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_orderedVarsGet_0() throws Throwable {
return bevp_orderedVars;
} /*method end*/
public BEC_6_6_SystemObject bem_orderedVarsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_orderedVars = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_6_6_SystemObject bem_isFinalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isFinal = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_6_6_SystemObject bem_isLocalSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isLocal = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_6_6_SystemObject bem_isNotNullSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isNotNull = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_freeFirstSlotGet_0() throws Throwable {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_6_6_SystemObject bem_freeFirstSlotSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_freeFirstSlot = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_firstSlotNativeGet_0() throws Throwable {
return bevp_firstSlotNative;
} /*method end*/
public BEC_6_6_SystemObject bem_firstSlotNativeSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_firstSlotNative = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_nativeSlotsGet_0() throws Throwable {
return bevp_nativeSlots;
} /*method end*/
public BEC_6_6_SystemObject bem_nativeSlotsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nativeSlots = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_isArrayGet_0() throws Throwable {
return bevp_isArray;
} /*method end*/
public BEC_6_6_SystemObject bem_isArraySet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isArray = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_onceEvalCountGet_0() throws Throwable {
return bevp_onceEvalCount;
} /*method end*/
public BEC_6_6_SystemObject bem_onceEvalCountSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_onceEvalCount = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerSet bem_referencedPropertiesGet_0() throws Throwable {
return bevp_referencedProperties;
} /*method end*/
public BEC_6_6_SystemObject bem_referencedPropertiesSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_referencedProperties = (BEC_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_shouldWriteGet_0() throws Throwable {
return bevp_shouldWrite;
} /*method end*/
public BEC_6_6_SystemObject bem_shouldWriteSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_shouldWrite = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_belsCountGet_0() throws Throwable {
return bevp_belsCount;
} /*method end*/
public BEC_6_6_SystemObject bem_belsCountSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_belsCount = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 131, 132, 132, 133, 135, 136, 136, 137, 141, 145, 145, 146, 148, 152, 153, 153, 154, 154, 154, 154, 155, 155, 156, 156, 156, 156, 159, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 68, 73, 78, 79, 81, 94, 95, 100, 101, 102, 103, 104, 105, 110, 111, 112, 113, 114, 117, 120, 123, 127, 130, 134, 137, 141, 144, 148, 151, 155, 158, 162, 165, 169, 172, 176, 179, 183, 186, 190, 193, 197, 200, 204, 207, 211, 214, 218, 221, 225, 228, 232, 235, 239, 242, 246, 249, 253, 256, 260, 263, 267, 270, 274, 277};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 111 41
new 0 111 41
assign 1 112 42
new 0 112 42
assign 1 113 43
new 0 113 43
assign 1 114 44
new 0 114 44
assign 1 115 45
new 0 115 45
assign 1 116 46
new 0 116 46
assign 1 117 47
new 0 117 47
assign 1 118 48
new 0 118 48
assign 1 119 49
new 0 119 49
assign 1 120 50
new 0 120 50
assign 1 121 51
new 0 121 51
assign 1 122 52
new 0 122 52
assign 1 123 53
new 0 123 53
assign 1 124 54
new 0 124 54
assign 1 125 55
new 0 125 55
assign 1 126 56
new 0 126 56
assign 1 131 57
new 0 131 57
assign 1 132 58
new 0 132 58
fromString 1 132 59
addUsed 1 133 60
assign 1 135 61
new 0 135 61
assign 1 136 62
new 0 136 62
fromString 1 136 63
addUsed 1 137 64
addValue 1 141 68
assign 1 145 73
undef 1 145 78
assign 1 146 79
new 0 146 79
addValue 1 148 81
assign 1 152 94
classNameGet 0 152 94
assign 1 153 95
def 1 153 100
assign 1 154 101
new 0 154 101
assign 1 154 102
add 1 154 102
assign 1 154 103
toString 0 154 103
assign 1 154 104
add 1 154 104
assign 1 155 105
def 1 155 110
assign 1 156 111
new 0 156 111
assign 1 156 112
add 1 156 112
assign 1 156 113
toString 0 156 113
assign 1 156 114
add 1 156 114
return 1 159 117
return 1 0 120
assign 1 0 123
return 1 0 127
assign 1 0 130
return 1 0 134
assign 1 0 137
return 1 0 141
assign 1 0 144
return 1 0 148
assign 1 0 151
return 1 0 155
assign 1 0 158
return 1 0 162
assign 1 0 165
return 1 0 169
assign 1 0 172
return 1 0 176
assign 1 0 179
return 1 0 183
assign 1 0 186
return 1 0 190
assign 1 0 193
return 1 0 197
assign 1 0 200
return 1 0 204
assign 1 0 207
return 1 0 211
assign 1 0 214
return 1 0 218
assign 1 0 221
return 1 0 225
assign 1 0 228
return 1 0 232
assign 1 0 235
return 1 0 239
assign 1 0 242
return 1 0 246
assign 1 0 249
return 1 0 253
assign 1 0 256
return 1 0 260
assign 1 0 263
return 1 0 267
assign 1 0 270
return 1 0 274
assign 1 0 277
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 87592446: return bem_orderedMethodsGet_0();
case 287367803: return bem_isFinalGet_0();
case 363636983: return bem_isNotNullGet_0();
case 287040793: return bem_hashGet_0();
case 1791388575: return bem_synGet_0();
case 429326446: return bem_extendsGet_0();
case 1820417453: return bem_create_0();
case 786424307: return bem_tagGet_0();
case 845792839: return bem_iteratorGet_0();
case 1081760974: return bem_orderedVarsGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 2055025483: return bem_serializeContents_0();
case 795036897: return bem_fromFileGet_0();
case 83882038: return bem_usedGet_0();
case 1774940957: return bem_toString_0();
case 568286617: return bem_emitsGet_0();
case 1012494862: return bem_once_0();
case 2123142907: return bem_shouldWriteGet_0();
case 368256414: return bem_belsCountGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 842582618: return bem_isLocalGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 428778779: return bem_freeFirstSlotGet_0();
case 1104169470: return bem_firstSlotNativeGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
case 81548343: return bem_nativeSlotsGet_0();
case 1081412016: return bem_many_0();
case 1859739893: return bem_methodsGet_0();
case 314718434: return bem_print_0();
case 1803479881: return bem_libNameGet_0();
case 1458936917: return bem_onceEvalCountGet_0();
case 354142775: return bem_namepathGet_0();
case 1211273660: return bem_nameGet_0();
case 443668840: return bem_methodNotDefined_0();
case 1155896786: return bem_varMapGet_0();
case 1308786538: return bem_echo_0();
case 1450142629: return bem_referencedPropertiesGet_0();
case 729571811: return bem_serializeToString_0();
case 936200056: return bem_isArrayGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 406676794: return bem_addEmit_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 1802470828: return bem_synSet_1(bevd_0);
case 440408699: return bem_extendsSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 72799785: return bem_usedSet_1(bevd_0);
case 1092843227: return bem_orderedVarsSet_1(bevd_0);
case 557204364: return bem_emitsSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 357174161: return bem_belsCountSet_1(bevd_0);
case 2134225160: return bem_shouldWriteSet_1(bevd_0);
case 831500365: return bem_isLocalSet_1(bevd_0);
case 417696526: return bem_freeFirstSlotSet_1(bevd_0);
case 1093087217: return bem_firstSlotNativeSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 70466090: return bem_nativeSlotsSet_1(bevd_0);
case 56796208: return bem_addUsed_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1439060376: return bem_referencedPropertiesSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1470019170: return bem_onceEvalCountSet_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 1166979039: return bem_varMapSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 76510193: return bem_orderedMethodsSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 947282309: return bem_isArraySet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_5_5_BuildClass();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_5_5_BuildClass.bevs_inst = (BEC_5_5_BuildClass)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_5_5_BuildClass.bevs_inst;
}
}
