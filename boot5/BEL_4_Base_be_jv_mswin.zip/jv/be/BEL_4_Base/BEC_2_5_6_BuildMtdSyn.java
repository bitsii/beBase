package be.BEL_4_Base;
/* IO:File: source/build/Syns.be */
public final class BEC_2_5_6_BuildMtdSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMtdSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x74,0x64,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_0, 6));
private static byte[] bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_1, 4));
private static byte[] bels_2 = {0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_2, 7));
private static byte[] bels_3 = {0x6E,0x75,0x6D,0x61,0x72,0x67,0x73};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_3, 7));
private static byte[] bels_4 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bels_5 = {0x6C,0x61,0x73,0x74,0x44,0x65,0x66};
private static byte[] bels_6 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bels_7 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bels_8 = {0x69,0x73,0x47,0x65,0x6E,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bels_9 = {0x72,0x73,0x79,0x6E};
private static byte[] bels_10 = {0x76,0x61,0x72};
private static byte[] bels_11 = {0x61,0x72,0x67,0x54,0x79,0x70,0x65};
private static byte[] bels_12 = {0x76,0x61,0x72};
public static BEC_2_5_6_BuildMtdSyn bevs_inst;
public BEC_2_4_3_MathInt bevp_hpos;
public BEC_2_4_3_MathInt bevp_mtdx;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_9_4_ContainerList bevp_argSyns;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_5_4_LogicBool bevp_lastDef;
public BEC_2_5_4_LogicBool bevp_isOverride;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_6_TextString bevp_propertyName;
public BEC_2_5_6_BuildVarSyn bevp_rsyn;
public BEC_2_5_6_BuildMtdSyn bem_new_2(BEC_2_6_6_SystemObject beva_snode, BEC_2_6_6_SystemObject beva__origin) throws Throwable {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_args = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_5_6_BuildVarSyn bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
bevl_s = beva_snode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_numargs = (BEC_2_4_3_MathInt) bevl_s.bemd_0(-548714012, BEL_4_Base.bevn_numargsGet_0);
bevp_name = (BEC_2_4_6_TextString) bevl_s.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_orgName = (BEC_2_4_6_TextString) bevl_s.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(1714571098, BEL_4_Base.bevn_isGenAccessorGet_0);
bevt_1_tmpvar_phold = bevo_0;
bevt_0_tmpvar_phold = bevp_numargs.bem_add_1(bevt_1_tmpvar_phold);
bevp_argSyns = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpvar_phold);
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_lastDef = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_isOverride = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_isFinal = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_3_tmpvar_phold = bevl_s.bemd_0(-1041978190, BEL_4_Base.bevn_propertyGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 426 */ {
bevt_4_tmpvar_phold = bevl_s.bemd_0(-1041978190, BEL_4_Base.bevn_propertyGet_0);
bevp_propertyName = (BEC_2_4_6_TextString) bevt_4_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
} /* Line: 427 */
bevt_6_tmpvar_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 429 */ {
bevt_7_tmpvar_phold = bevl_s.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevp_rsyn = (new BEC_2_5_6_BuildVarSyn()).bem_varNew_1((BEC_2_5_3_BuildVar) bevt_7_tmpvar_phold);
} /* Line: 430 */
bevt_9_tmpvar_phold = beva_snode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevl_args = bevt_8_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 435 */ {
bevt_11_tmpvar_phold = bevp_argSyns.bem_lengthGet_0();
bevt_10_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_11_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 435 */ {
bevt_14_tmpvar_phold = bevl_args.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_12_tmpvar_phold = (new BEC_2_5_6_BuildVarSyn()).bem_varNew_1((BEC_2_5_3_BuildVar) bevt_13_tmpvar_phold);
bevp_argSyns.bem_put_2((BEC_2_4_3_MathInt) bevl_i, bevt_12_tmpvar_phold);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 435 */
 else  /* Line: 435 */ {
break;
} /* Line: 435 */
} /* Line: 435 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_arg = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_4_7_TextStrings bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_62_tmpvar_phold = null;
bevt_1_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevl_nl = bevt_1_tmpvar_phold.bem_newlineGet_0();
bevt_14_tmpvar_phold = bevo_1;
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevl_nl);
bevt_15_tmpvar_phold = bevo_2;
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_add_1(bevt_15_tmpvar_phold);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bem_add_1(bevl_nl);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bem_add_1(bevp_name);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevl_nl);
bevt_16_tmpvar_phold = bevo_3;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_16_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevl_nl);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevp_orgName);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevl_nl);
bevt_17_tmpvar_phold = bevo_4;
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bem_add_1(bevl_nl);
bevt_18_tmpvar_phold = bevp_numargs.bem_toString_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_add_1(bevt_18_tmpvar_phold);
bevl_toRet = bevt_2_tmpvar_phold.bem_add_1(bevl_nl);
bevt_22_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_4));
bevt_21_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_22_tmpvar_phold);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_23_tmpvar_phold = bevp_origin.bem_toString_0();
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevl_toRet = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_27_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_5));
bevt_26_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_27_tmpvar_phold);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_28_tmpvar_phold = bevp_lastDef.bem_toString_0();
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_28_tmpvar_phold);
bevl_toRet = bevt_24_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_32_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_6));
bevt_31_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_32_tmpvar_phold);
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_33_tmpvar_phold = bevp_isFinal.bem_toString_0();
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpvar_phold);
bevl_toRet = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
if (bevp_propertyName == null) {
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_34_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_34_tmpvar_phold.bevi_bool) /* Line: 447 */ {
bevt_38_tmpvar_phold = (new BEC_2_4_6_TextString(12, bels_7));
bevt_37_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_38_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_35_tmpvar_phold = bevt_36_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_propertyName);
bevl_toRet = bevt_35_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 448 */
bevt_42_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_8));
bevt_41_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_42_tmpvar_phold);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_43_tmpvar_phold = bevp_isGenAccessor.bem_toString_0();
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_43_tmpvar_phold);
bevl_toRet = bevt_39_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_45_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_9));
bevt_44_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_45_tmpvar_phold);
bevl_toRet = bevt_44_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
if (bevp_rsyn == null) {
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 452 */ {
bevt_47_tmpvar_phold = bevp_rsyn.bem_isTypedGet_0();
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 452 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 452 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 452 */
 else  /* Line: 452 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 452 */ {
bevt_50_tmpvar_phold = bevp_rsyn.bem_namepathGet_0();
bevt_49_tmpvar_phold = bevt_50_tmpvar_phold.bem_toString_0();
bevt_48_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_49_tmpvar_phold);
bevl_toRet = bevt_48_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 453 */
 else  /* Line: 454 */ {
bevt_52_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_10));
bevt_51_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_52_tmpvar_phold);
bevl_toRet = bevt_51_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 455 */
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 457 */ {
bevt_54_tmpvar_phold = bevp_argSyns.bem_lengthGet_0();
bevt_53_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_54_tmpvar_phold);
if (bevt_53_tmpvar_phold != null && bevt_53_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_53_tmpvar_phold).bevi_bool) /* Line: 457 */ {
bevl_arg = bevp_argSyns.bem_get_1((BEC_2_4_3_MathInt) bevl_i);
bevt_56_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_11));
bevt_55_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_56_tmpvar_phold);
bevl_toRet = bevt_55_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
bevt_57_tmpvar_phold = bevl_arg.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_57_tmpvar_phold != null && bevt_57_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_57_tmpvar_phold).bevi_bool) /* Line: 461 */ {
bevt_60_tmpvar_phold = bevl_arg.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_58_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_59_tmpvar_phold);
bevl_toRet = bevt_58_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 462 */
 else  /* Line: 463 */ {
bevt_62_tmpvar_phold = (new BEC_2_4_6_TextString(3, bels_12));
bevt_61_tmpvar_phold = bevl_toRet.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_62_tmpvar_phold);
bevl_toRet = bevt_61_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_nl);
} /* Line: 464 */
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 457 */
 else  /* Line: 457 */ {
break;
} /* Line: 457 */
} /* Line: 457 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_getEmitReturnType_2(BEC_2_5_8_BuildClassSyn beva_csyn, BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_4_LogicBool bevl_covariantReturns = null;
BEC_2_5_10_BuildEmitCommon bevl_ec = null;
BEC_2_5_8_BuildClassSyn bevl_cs = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_3_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_7_tmpvar_phold = null;
BEC_2_5_6_BuildVarSyn bevt_8_tmpvar_phold = null;
bevl_covariantReturns = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_ec = beva_build.bem_emitCommonGet_0();
if (bevl_ec == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 473 */ {
bevl_covariantReturns = (BEC_2_5_4_LogicBool) bevl_ec.bem_covariantReturnsGet_0();
} /* Line: 474 */
if (bevp_rsyn == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 476 */ {
if (bevl_covariantReturns.bevi_bool) /* Line: 477 */ {
bevt_2_tmpvar_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 478 */ {
bevt_3_tmpvar_phold = beva_csyn.bem_namepathGet_0();
return bevt_3_tmpvar_phold;
} /* Line: 479 */
 else  /* Line: 480 */ {
bevt_4_tmpvar_phold = bevp_rsyn.bem_namepathGet_0();
return bevt_4_tmpvar_phold;
} /* Line: 481 */
} /* Line: 478 */
 else  /* Line: 483 */ {
bevt_5_tmpvar_phold = bevp_rsyn.bem_isSelfGet_0();
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 484 */ {
return bevp_declaration;
} /* Line: 485 */
 else  /* Line: 486 */ {
bevl_cs = beva_build.bem_getSynNp_1(bevp_declaration);
bevt_6_tmpvar_phold = bevl_cs.bem_mtdMapGet_0();
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevt_6_tmpvar_phold.bem_get_1(bevp_name);
bevt_8_tmpvar_phold = bevl_ms.bem_rsynGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_namepathGet_0();
return bevt_7_tmpvar_phold;
} /* Line: 489 */
} /* Line: 484 */
} /* Line: 477 */
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_hposGet_0() throws Throwable {
return bevp_hpos;
} /*method end*/
public BEC_2_6_6_SystemObject bem_hposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxGet_0() throws Throwable {
return bevp_mtdx;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mtdxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() throws Throwable {
return bevp_numargs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() throws Throwable {
return bevp_orgName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() throws Throwable {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argSynsGet_0() throws Throwable {
return bevp_argSyns;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() throws Throwable {
return bevp_origin;
} /*method end*/
public BEC_2_6_6_SystemObject bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public BEC_2_6_6_SystemObject bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lastDefGet_0() throws Throwable {
return bevp_lastDef;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastDefSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOverrideGet_0() throws Throwable {
return bevp_isOverride;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isOverrideSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_propertyNameGet_0() throws Throwable {
return bevp_propertyName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_propertyNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_rsynGet_0() throws Throwable {
return bevp_rsyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rsynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {409, 415, 416, 417, 418, 419, 419, 419, 421, 423, 424, 425, 426, 426, 426, 427, 427, 429, 429, 429, 430, 430, 434, 434, 434, 435, 435, 435, 436, 436, 436, 436, 435, 442, 442, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 444, 444, 444, 444, 444, 444, 445, 445, 445, 445, 445, 445, 446, 446, 446, 446, 446, 446, 447, 447, 448, 448, 448, 448, 448, 450, 450, 450, 450, 450, 450, 451, 451, 451, 452, 452, 452, 0, 0, 0, 453, 453, 453, 453, 455, 455, 455, 457, 457, 457, 458, 460, 460, 460, 461, 462, 462, 462, 462, 464, 464, 464, 457, 467, 471, 472, 473, 473, 474, 476, 476, 478, 479, 479, 481, 481, 484, 485, 487, 488, 488, 489, 489, 489, 493, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 77, 78, 79, 81, 82, 87, 88, 89, 91, 92, 93, 94, 97, 98, 100, 101, 102, 103, 104, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 223, 224, 225, 226, 227, 228, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 244, 245, 247, 250, 254, 257, 258, 259, 260, 263, 264, 265, 267, 270, 271, 273, 274, 275, 276, 277, 279, 280, 281, 282, 285, 286, 287, 289, 295, 311, 312, 313, 318, 319, 321, 326, 328, 330, 331, 334, 335, 339, 341, 344, 345, 346, 347, 348, 349, 353, 356, 359, 363, 366, 370, 373, 377, 380, 384, 387, 391, 394, 398, 401, 405, 408, 412, 415, 419, 422, 426, 429, 433, 436, 440, 443, 447, 450};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 409 59
heldGet 0 409 59
assign 1 415 60
numargsGet 0 415 60
assign 1 416 61
nameGet 0 416 61
assign 1 417 62
orgNameGet 0 417 62
assign 1 418 63
isGenAccessorGet 0 418 63
assign 1 419 64
new 0 419 64
assign 1 419 65
add 1 419 65
assign 1 419 66
new 1 419 66
assign 1 421 67
assign 1 423 68
new 0 423 68
assign 1 424 69
new 0 424 69
assign 1 425 70
isFinalGet 0 425 70
assign 1 426 71
propertyGet 0 426 71
assign 1 426 72
def 1 426 77
assign 1 427 78
propertyGet 0 427 78
assign 1 427 79
nameGet 0 427 79
assign 1 429 81
rtypeGet 0 429 81
assign 1 429 82
def 1 429 87
assign 1 430 88
rtypeGet 0 430 88
assign 1 430 89
varNew 1 430 89
assign 1 434 91
containedGet 0 434 91
assign 1 434 92
firstGet 0 434 92
assign 1 434 93
containedGet 0 434 93
assign 1 435 94
new 0 435 94
assign 1 435 97
lengthGet 0 435 97
assign 1 435 98
lesser 1 435 98
assign 1 436 100
get 1 436 100
assign 1 436 101
heldGet 0 436 101
assign 1 436 102
varNew 1 436 102
put 2 436 103
assign 1 435 104
increment 0 435 104
assign 1 442 180
new 0 442 180
assign 1 442 181
newlineGet 0 442 181
assign 1 443 182
new 0 443 182
assign 1 443 183
add 1 443 183
assign 1 443 184
new 0 443 184
assign 1 443 185
add 1 443 185
assign 1 443 186
add 1 443 186
assign 1 443 187
add 1 443 187
assign 1 443 188
add 1 443 188
assign 1 443 189
new 0 443 189
assign 1 443 190
add 1 443 190
assign 1 443 191
add 1 443 191
assign 1 443 192
add 1 443 192
assign 1 443 193
add 1 443 193
assign 1 443 194
new 0 443 194
assign 1 443 195
add 1 443 195
assign 1 443 196
add 1 443 196
assign 1 443 197
toString 0 443 197
assign 1 443 198
add 1 443 198
assign 1 443 199
add 1 443 199
assign 1 444 200
new 0 444 200
assign 1 444 201
add 1 444 201
assign 1 444 202
add 1 444 202
assign 1 444 203
toString 0 444 203
assign 1 444 204
add 1 444 204
assign 1 444 205
add 1 444 205
assign 1 445 206
new 0 445 206
assign 1 445 207
add 1 445 207
assign 1 445 208
add 1 445 208
assign 1 445 209
toString 0 445 209
assign 1 445 210
add 1 445 210
assign 1 445 211
add 1 445 211
assign 1 446 212
new 0 446 212
assign 1 446 213
add 1 446 213
assign 1 446 214
add 1 446 214
assign 1 446 215
toString 0 446 215
assign 1 446 216
add 1 446 216
assign 1 446 217
add 1 446 217
assign 1 447 218
def 1 447 223
assign 1 448 224
new 0 448 224
assign 1 448 225
add 1 448 225
assign 1 448 226
add 1 448 226
assign 1 448 227
add 1 448 227
assign 1 448 228
add 1 448 228
assign 1 450 230
new 0 450 230
assign 1 450 231
add 1 450 231
assign 1 450 232
add 1 450 232
assign 1 450 233
toString 0 450 233
assign 1 450 234
add 1 450 234
assign 1 450 235
add 1 450 235
assign 1 451 236
new 0 451 236
assign 1 451 237
add 1 451 237
assign 1 451 238
add 1 451 238
assign 1 452 239
def 1 452 244
assign 1 452 245
isTypedGet 0 452 245
assign 1 0 247
assign 1 0 250
assign 1 0 254
assign 1 453 257
namepathGet 0 453 257
assign 1 453 258
toString 0 453 258
assign 1 453 259
add 1 453 259
assign 1 453 260
add 1 453 260
assign 1 455 263
new 0 455 263
assign 1 455 264
add 1 455 264
assign 1 455 265
add 1 455 265
assign 1 457 267
new 0 457 267
assign 1 457 270
lengthGet 0 457 270
assign 1 457 271
lesser 1 457 271
assign 1 458 273
get 1 458 273
assign 1 460 274
new 0 460 274
assign 1 460 275
add 1 460 275
assign 1 460 276
add 1 460 276
assign 1 461 277
isTypedGet 0 461 277
assign 1 462 279
namepathGet 0 462 279
assign 1 462 280
toString 0 462 280
assign 1 462 281
add 1 462 281
assign 1 462 282
add 1 462 282
assign 1 464 285
new 0 464 285
assign 1 464 286
add 1 464 286
assign 1 464 287
add 1 464 287
assign 1 457 289
increment 0 457 289
return 1 467 295
assign 1 471 311
new 0 471 311
assign 1 472 312
emitCommonGet 0 472 312
assign 1 473 313
def 1 473 318
assign 1 474 319
covariantReturnsGet 0 474 319
assign 1 476 321
def 1 476 326
assign 1 478 328
isSelfGet 0 478 328
assign 1 479 330
namepathGet 0 479 330
return 1 479 331
assign 1 481 334
namepathGet 0 481 334
return 1 481 335
assign 1 484 339
isSelfGet 0 484 339
return 1 485 341
assign 1 487 344
getSynNp 1 487 344
assign 1 488 345
mtdMapGet 0 488 345
assign 1 488 346
get 1 488 346
assign 1 489 347
rsynGet 0 489 347
assign 1 489 348
namepathGet 0 489 348
return 1 489 349
return 1 493 353
return 1 0 356
assign 1 0 359
return 1 0 363
assign 1 0 366
return 1 0 370
assign 1 0 373
return 1 0 377
assign 1 0 380
return 1 0 384
assign 1 0 387
return 1 0 391
assign 1 0 394
return 1 0 398
assign 1 0 401
return 1 0 405
assign 1 0 408
return 1 0 412
assign 1 0 415
return 1 0 419
assign 1 0 422
return 1 0 426
assign 1 0 429
return 1 0 433
assign 1 0 436
return 1 0 440
assign 1 0 443
return 1 0 447
assign 1 0 450
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 1820417453: return bem_create_0();
case -1187343513: return bem_propertyNameGet_0();
case 1211273660: return bem_nameGet_0();
case 443668840: return bem_methodNotDefined_0();
case -1376225844: return bem_mtdxGet_0();
case -786424307: return bem_tagGet_0();
case -82450415: return bem_isOverrideGet_0();
case -845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1707345409: return bem_originGet_0();
case 1714571098: return bem_isGenAccessorGet_0();
case -1081412016: return bem_many_0();
case -1391492296: return bem_orgNameGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 287367803: return bem_isFinalGet_0();
case 287040793: return bem_hashGet_0();
case -729571811: return bem_serializeToString_0();
case 1900010001: return bem_rsynGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case -548714012: return bem_numargsGet_0();
case -896461779: return bem_declarationGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case 815066086: return bem_argSynsGet_0();
case -314718434: return bem_print_0();
case 1719265275: return bem_hposGet_0();
case -1100651208: return bem_lastDefGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1911092254: return bem_rsynSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1718427662: return bem_originSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 826148339: return bem_argSynsSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -71368162: return bem_isOverrideSet_1(bevd_0);
case -1365143591: return bem_mtdxSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1730347528: return bem_hposSet_1(bevd_0);
case 1222355913: return bem_nameSet_1(bevd_0);
case -1380410043: return bem_orgNameSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -537631759: return bem_numargsSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1089568955: return bem_lastDefSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 1725653351: return bem_isGenAccessorSet_1(bevd_0);
case -1176261260: return bem_propertyNameSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -885379526: return bem_declarationSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case -583049050: return bem_getEmitReturnType_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_6_BuildMtdSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_6_BuildMtdSyn.bevs_inst = (BEC_2_5_6_BuildMtdSyn)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_6_BuildMtdSyn.bevs_inst;
}
}
