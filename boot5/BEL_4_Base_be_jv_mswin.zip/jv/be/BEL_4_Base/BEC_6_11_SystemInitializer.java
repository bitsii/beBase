package be.BEL_4_Base;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_6_11_SystemInitializer extends BEC_6_6_SystemObject {
public BEC_6_11_SystemInitializer() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
private static byte[] bels_1 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
public static BEC_6_11_SystemInitializer bevs_inst;
public BEC_6_6_SystemObject bem_initializeIfShould_1(BEC_6_6_SystemObject beva_inst) throws Throwable {
BEC_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(7, bels_0));
bevt_2_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_0_tmpvar_phold = beva_inst.bemd_2(94427011, BEL_4_Base.bevn_can_2, bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 50 */ {
bevt_3_tmpvar_phold = this.bem_initializeIt_1(beva_inst);
return bevt_3_tmpvar_phold;
} /* Line: 51 */
return beva_inst;
} /*method end*/
public BEC_6_6_SystemObject bem_notNullInitConstruct_1(BEC_6_6_SystemObject beva_inst) throws Throwable {
BEC_6_6_SystemObject bevl_init = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 78 */ {
bevl_init = beva_inst;

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 86 */
return bevl_init;
} /*method end*/
public BEC_6_6_SystemObject bem_notNullInitDefault_1(BEC_6_6_SystemObject beva_inst) throws Throwable {
BEC_6_6_SystemObject bevl_init = null;

      bevl_init = beva_inst.bemc_getInitial();
      bevl_init.bemd_0(1502128718, BEL_4_Base.bevn_default_0);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_notNullInitIt_1(BEC_6_6_SystemObject beva_inst) throws Throwable {
BEC_6_6_SystemObject bevl_init = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 139 */ {
bevl_init = beva_inst;
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(7, bels_1));
bevt_3_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_1_tmpvar_phold = bevl_init.bemd_2(94427011, BEL_4_Base.bevn_can_2, bevt_2_tmpvar_phold, bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 141 */ {
bevl_init.bemd_0(1502128718, BEL_4_Base.bevn_default_0);
} /* Line: 142 */

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 150 */
return bevl_init;
} /*method end*/
public BEC_6_6_SystemObject bem_initializeIt_1(BEC_6_6_SystemObject beva_inst) throws Throwable {
BEC_6_6_SystemObject bevl_init = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 179 */ {
bevl_init = beva_inst;
bevl_init.bemd_0(1502128718, BEL_4_Base.bevn_default_0);

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 188 */
return bevl_init;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 50, 50, 51, 51, 53, 78, 78, 79, 92, 115, 139, 139, 140, 141, 141, 141, 142, 156, 179, 179, 180, 181, 194};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 21, 22, 24, 31, 36, 37, 41, 47, 58, 63, 64, 65, 66, 67, 69, 74, 81, 86, 87, 88, 92};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 17
new 0 50 17
assign 1 50 18
new 0 50 18
assign 1 50 19
can 2 50 19
assign 1 51 21
initializeIt 1 51 21
return 1 51 22
return 1 53 24
assign 1 78 31
undef 1 78 36
assign 1 79 37
return 1 92 41
default 0 115 47
assign 1 139 58
undef 1 139 63
assign 1 140 64
assign 1 141 65
new 0 141 65
assign 1 141 66
new 0 141 66
assign 1 141 67
can 2 141 67
default 0 142 69
return 1 156 74
assign 1 179 81
undef 1 179 86
assign 1 180 87
default 0 181 88
return 1 194 92
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1289267097: return bem_notNullInitIt_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 691874391: return bem_notNullInitDefault_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 1348139154: return bem_initializeIfShould_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 2065592781: return bem_initializeIt_1(bevd_0);
case 323080129: return bem_notNullInitConstruct_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_6_11_SystemInitializer();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_6_11_SystemInitializer.bevs_inst = (BEC_6_11_SystemInitializer)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_6_11_SystemInitializer.bevs_inst;
}
}
