package be.BEL_4_Base;
/* IO:File: source/build/Nodes.be */
public class BEC_2_5_4_BuildNode extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_BuildNode() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x3C};
private static byte[] bels_1 = {0x3E};
private static byte[] bels_2 = {0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bels_3 = {0x20,0x49,0x6E,0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bels_4 = {0x20,0x49,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bels_5 = {0x20};
private static byte[] bels_6 = {0x3C};
private static byte[] bels_7 = {0x3E};
private static byte[] bels_8 = {0x20,0x6C,0x69,0x6E,0x65,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_8, 7));
private static byte[] bels_9 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_9, 8));
private static byte[] bels_10 = {0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_10, 1));
private static byte[] bels_11 = {0x20,0x20};
private static byte[] bels_12 = {0x74,0x6D,0x70,0x56,0x61,0x72,0x20,0x73,0x63,0x6F,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x20,0x73,0x75,0x62};
private static byte[] bels_13 = {0x5F,0x74,0x6D,0x70,0x76,0x61,0x72,0x5F};
private static byte[] bels_14 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x61,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bels_15 = {0x44,0x75,0x70,0x6C,0x69,0x63,0x61,0x74,0x65,0x20,0x76,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bels_16 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x61,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x69,0x6E,0x20,0x73,0x79,0x6E,0x63,0x41,0x64,0x64,0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65};
private static byte[] bels_17 = {0x46,0x6F,0x75,0x6E,0x64,0x20,0x4E,0x50,0x20,0x74,0x6F,0x6F,0x20,0x6C,0x61,0x74,0x65,0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_17, 18));
private static byte[] bels_18 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_19 = {0x4E,0x6F,0x20,0x61,0x6E,0x63,0x68,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bels_20 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static BEC_2_9_3_ContainerSet bevo_4;
private static BEC_2_9_3_ContainerSet bevo_5;
private static BEC_2_9_3_ContainerSet bevo_6;
private static BEC_2_9_3_ContainerSet bevo_7;
private static BEC_2_9_3_ContainerSet bevo_8;
private static BEC_2_4_3_MathInt bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_21 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_22 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bels_23 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bels_24 = {0x61,0x64,0x64,0x5F,0x31};
private static byte[] bels_25 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x31};
private static byte[] bels_26 = {0x70,0x72,0x69,0x6E,0x74,0x5F,0x30};
private static byte[] bels_27 = {0x65,0x63,0x68,0x6F,0x5F,0x30};
private static byte[] bels_28 = {0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x5F,0x30};
private static byte[] bels_29 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x31};
private static byte[] bels_30 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x31};
private static byte[] bels_31 = {0x70,0x6F,0x77,0x65,0x72,0x5F,0x31};
private static byte[] bels_32 = {0x63,0x6F,0x6D,0x70,0x61,0x72,0x65,0x5F,0x31};
private static byte[] bels_33 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x31};
private static byte[] bels_34 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x31};
private static byte[] bels_35 = {0x65,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_36 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_37 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_38 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73,0x5F,0x31};
private static byte[] bels_39 = {0x66,0x69,0x6E,0x64,0x5F,0x32};
private static byte[] bels_40 = {0x66,0x69,0x6E,0x64,0x5F,0x31};
private static byte[] bels_41 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_42 = {0x69,0x73,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x5F,0x30};
private static byte[] bels_43 = {0x67,0x65,0x74,0x50,0x6F,0x69,0x6E,0x74,0x5F,0x31};
private static byte[] bels_44 = {0x65,0x6E,0x64,0x73,0x5F,0x31};
private static byte[] bels_45 = {0x62,0x65,0x67,0x69,0x6E,0x73,0x5F,0x31};
private static byte[] bels_46 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x31};
private static byte[] bels_47 = {0x73,0x75,0x62,0x73,0x74,0x72,0x69,0x6E,0x67,0x5F,0x32};
private static byte[] bels_48 = {0x73,0x69,0x7A,0x65,0x47,0x65,0x74,0x5F,0x30};
private static byte[] bels_49 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] bels_50 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] bels_51 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_52 = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x41,0x72,0x72,0x61,0x79};
private static byte[] bels_53 = {0x67,0x65,0x74,0x5F,0x31};
private static byte[] bels_54 = {0x68,0x61,0x73,0x5F,0x31};
private static byte[] bels_55 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static BEC_2_5_4_BuildNode bevs_inst;
public BEC_2_9_8_ContainerNodeList bevp_contained;
public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_6_6_SystemObject bevp_held;
public BEC_2_6_6_SystemObject bevp_heldBy;
public BEC_2_6_6_SystemObject bevp_condvar;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public BEC_2_6_6_SystemObject bevp_typeDetail;
public BEC_2_5_4_LogicBool bevp_delayDelete;
public BEC_2_4_3_MathInt bevp_nlc;
public BEC_2_4_3_MathInt bevp_nlec;
public BEC_2_5_4_LogicBool bevp_wideString;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_3_MathInt bevp_typename;
public BEC_2_5_4_LogicBool bevp_inlined;
public BEC_2_5_4_BuildNode bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_delayDelete = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_nlc = (new BEC_2_4_3_MathInt(0));
bevp_nlec = (new BEC_2_4_3_MathInt(0));
bevp_wideString = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_build = beva__build;
bevp_constants = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_typename = bevp_ntypes.bem_TOKENGet_0();
bevp_inlined = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyLoc_1(BEC_2_5_4_BuildNode beva_fromNode) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_fromNode.bem_nlcGet_0();
bevp_nlc = bevt_0_tmpvar_phold.bem_copy_0();
bevt_1_tmpvar_phold = beva_fromNode.bem_nlecGet_0();
bevp_nlec = bevt_1_tmpvar_phold.bem_copy_0();
bevp_inClassNp = beva_fromNode.bem_inClassNpGet_0();
bevp_inFile = beva_fromNode.bem_inFileGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextDescendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_4_tmpvar_phold = bevp_contained.bem_firstGet_0();
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 53 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 53 */ {
bevt_5_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_5_tmpvar_phold;
} /* Line: 54 */
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 58 */ {
if (bevl_ret == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 58 */ {
if (bevl_con == null) {
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 58 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 58 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 58 */
 else  /* Line: 58 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 58 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 60 */
 else  /* Line: 58 */ {
break;
} /* Line: 58 */
} /* Line: 58 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextAscendGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_ret = null;
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
bevl_ret = this.bem_nextPeerGet_0();
bevl_con = bevp_container;
while (true)
 /* Line: 68 */ {
if (bevl_ret == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 68 */ {
if (bevl_con == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 68 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 68 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 68 */
 else  /* Line: 68 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 68 */ {
bevl_ret = bevl_con.bem_nextPeerGet_0();
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 70 */
 else  /* Line: 68 */ {
break;
} /* Line: 68 */
} /* Line: 68 */
return bevl_ret;
} /*method end*/
public BEC_2_5_4_BuildNode bem_nextPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 76 */ {
return null;
} /* Line: 77 */
bevl_hh = bevp_heldBy.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 80 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 81 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_2_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_priorPeerGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_hh = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 87 */ {
return null;
} /* Line: 88 */
bevl_hh = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevl_hh == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 91 */ {
return (BEC_2_5_4_BuildNode) bevl_hh;
} /* Line: 92 */
bevt_2_tmpvar_phold = bevl_hh.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
return (BEC_2_5_4_BuildNode) bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_firstGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_firstGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_secondGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_secondGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_thirdGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_contained.bem_thirdGet_0();
return (BEC_2_5_4_BuildNode) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFirstGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 110 */ {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_1_tmpvar_phold;
} /* Line: 111 */
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_2_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSecondGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 117 */ {
bevt_3_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_3_tmpvar_phold == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 117 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 117 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 117 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 117 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_4_tmpvar_phold;
} /* Line: 118 */
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThirdGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_4_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_4_tmpvar_phold == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_7_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_6_tmpvar_phold == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 124 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 124 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 125 */
bevt_12_tmpvar_phold = bevp_heldBy.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(946514141, BEL_4_Base.bevn_priorGet_0);
if (bevt_10_tmpvar_phold == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
return bevt_9_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delayDelete_0() throws Throwable {
bevp_delayDelete = be.BELS_Base.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 135 */ {
return null;
} /* Line: 136 */
bevp_heldBy.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
bevp_container = null;
bevp_heldBy = null;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_beforeInsert_1(BEC_2_5_4_BuildNode beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 144 */ {
return null;
} /* Line: 145 */
bevt_2_tmpvar_phold = bevp_heldBy.bemd_0(1849179299, BEL_4_Base.bevn_mylistGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(743891212, BEL_4_Base.bevn_newNode_1, beva_x);
bevp_heldBy.bemd_1(1505376950, BEL_4_Base.bevn_insertBefore_1, bevt_1_tmpvar_phold);
beva_x.bem_containerSet_1(bevp_container);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepend_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 152 */ {
this.bem_initContained_0();
} /* Line: 153 */
bevp_contained.bem_prepend_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addValue_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 160 */ {
this.bem_initContained_0();
} /* Line: 161 */
bevp_contained.bem_addValue_1(beva_node);
beva_node.bem_containerSet_1(this);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_reInitContained_0() throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initContained_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_contained == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 172 */ {
bevp_contained = (BEC_2_9_8_ContainerNodeList) (new BEC_2_9_8_ContainerNodeList()).bem_new_0();
} /* Line: 173 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevl_res = null;
try  /* Line: 179 */ {
bevl_res = this.bem_toStringCompact_0();
} /* Line: 180 */
 catch (Throwable beve_0) {
bevl_e = (be.BELS_Base.BECS_ThrowBack.handleThrow(beve_0));
bevl_e.bemd_0(314718434, BEL_4_Base.bevn_print_0);
throw new be.BELS_Base.BECS_ThrowBack(bevl_e);
} /* Line: 183 */
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringBig_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_6_6_SystemObject bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_7_TextStrings bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_3_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_0));
bevt_2_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_1));
bevl_ret = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_5_tmpvar_phold);
bevt_10_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_newlineGet_0();
bevt_8_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_11_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_2));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_12_tmpvar_phold);
if (bevp_inClassNp == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 192 */ {
if (bevp_inFile == null) {
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 192 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 192 */ {
bevt_22_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_newlineGet_0();
bevt_20_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_21_tmpvar_phold);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_23_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_3));
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_4));
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_25_tmpvar_phold);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevp_inFile);
bevt_27_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_26_tmpvar_phold = bevt_27_tmpvar_phold.bem_newlineGet_0();
bevl_ret = bevt_15_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_26_tmpvar_phold);
} /* Line: 193 */
if (bevp_held == null) {
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 195 */ {
bevt_32_tmpvar_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_31_tmpvar_phold = bevt_32_tmpvar_phold.bem_newlineGet_0();
bevt_30_tmpvar_phold = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_31_tmpvar_phold);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_prefix);
bevt_33_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_5));
bevl_ret = bevt_29_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevl_ret.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_34_tmpvar_phold);
} /* Line: 197 */
return (BEC_2_4_6_TextString) bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringCompact_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_prefix = null;
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
bevl_prefix = this.bem_prefixGet_0();
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_6));
bevt_1_tmpvar_phold = bevl_prefix.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_2_tmpvar_phold);
bevt_3_tmpvar_phold = bevp_typename.bem_toString_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_4_6_TextString(1, bels_7));
bevl_ret = (BEC_2_4_6_TextString) bevt_0_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_4_tmpvar_phold);
if (bevp_nlc == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_7_tmpvar_phold = bevo_0;
bevt_6_tmpvar_phold = bevl_ret.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevp_nlc.bem_toString_0();
bevl_ret = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
} /* Line: 206 */
if (bevp_inClassNp == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 208 */ {
bevt_11_tmpvar_phold = bevo_1;
bevt_10_tmpvar_phold = bevl_ret.bem_add_1(bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = bevp_inClassNp.bem_toString_0();
bevl_ret = bevt_10_tmpvar_phold.bem_add_1(bevt_12_tmpvar_phold);
} /* Line: 209 */
if (bevp_held == null) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 211 */ {
bevt_15_tmpvar_phold = bevo_2;
bevt_14_tmpvar_phold = bevl_ret.bem_add_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = bevp_held.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevl_ret = bevt_14_tmpvar_phold.bem_add_1(bevt_16_tmpvar_phold);
} /* Line: 212 */
return bevl_ret;
} /*method end*/
public BEC_2_6_6_SystemObject bem_depthGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_d = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevl_d = (new BEC_2_4_3_MathInt(0));
bevl_c = bevp_container;
while (true)
 /* Line: 220 */ {
if (bevl_c == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 220 */ {
bevl_d = bevl_d.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevl_c = bevl_c.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 222 */
 else  /* Line: 220 */ {
break;
} /* Line: 220 */
} /* Line: 220 */
return bevl_d;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prefixGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_d = null;
BEC_2_6_6_SystemObject bevl_p = null;
BEC_2_6_6_SystemObject bevl_q = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevl_d = this.bem_depthGet_0();
bevl_p = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_q = (new BEC_2_4_6_TextString(2, bels_11));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 231 */ {
bevt_0_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevl_d);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 231 */ {
bevl_p = bevl_p.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevl_q);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 231 */
 else  /* Line: 231 */ {
break;
} /* Line: 231 */
} /* Line: 231 */
return bevl_p;
} /*method end*/
public BEC_2_6_6_SystemObject bem_transUnitGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 239 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 239 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 239 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 239 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 239 */
 else  /* Line: 239 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 239 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 240 */
 else  /* Line: 239 */ {
break;
} /* Line: 239 */
} /* Line: 239 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tmpVar_2(BEC_2_6_6_SystemObject beva_suffix, BEC_2_6_6_SystemObject beva_build) throws Throwable {
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tmpvarn = null;
BEC_2_6_6_SystemObject bevl_tmpvar = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_3_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
bevl_clnode = this.bem_scopeGet_0();
bevt_1_tmpvar_phold = bevl_clnode.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_2_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 247 */ {
bevt_4_tmpvar_phold = (new BEC_2_4_6_TextString(22, bels_12));
bevt_3_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_4_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_3_tmpvar_phold);
} /* Line: 248 */
bevt_6_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevl_tmpvarn = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_0(230507477, BEL_4_Base.bevn_tmpCntGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
bevt_7_tmpvar_phold.bemd_1(241589730, BEL_4_Base.bevn_tmpCntSet_1, bevt_8_tmpvar_phold);
bevl_tmpvar = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_tmpvar.bemd_1(1124689062, BEL_4_Base.bevn_isTmpVarSet_1, bevt_11_tmpvar_phold);
bevl_tmpvar.bemd_1(2093073725, BEL_4_Base.bevn_suffixSet_1, beva_suffix);
bevt_14_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_13));
bevt_13_tmpvar_phold = bevl_tmpvarn.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_14_tmpvar_phold);
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, beva_suffix);
bevl_tmpvar.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_12_tmpvar_phold);
return bevl_tmpvar;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inPropertiesGet_0() throws Throwable {
BEC_2_5_4_BuildNode bevl_con = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
bevl_con = bevp_container;
while (true)
 /* Line: 261 */ {
if (bevl_con == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 261 */ {
bevt_2_tmpvar_phold = bevl_con.bem_typenameGet_0();
bevt_3_tmpvar_phold = bevp_ntypes.bem_PROPERTIESGet_0();
if (bevt_2_tmpvar_phold.bevi_int == bevt_3_tmpvar_phold.bevi_int) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 262 */ {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_4_tmpvar_phold;
} /* Line: 263 */
bevl_con = bevl_con.bem_containerGet_0();
} /* Line: 265 */
 else  /* Line: 261 */ {
break;
} /* Line: 261 */
} /* Line: 261 */
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_2_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 272 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_3_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevt_5_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 275 */ {
bevt_8_tmpvar_phold = (new BEC_2_4_6_TextString(54, bels_14));
bevt_7_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_8_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_7_tmpvar_phold);
} /* Line: 276 */
bevt_9_tmpvar_phold = this.bem_inPropertiesGet_0();
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 278 */ {
bevt_11_tmpvar_phold = bevl_v.bemd_0(1135771315, BEL_4_Base.bevn_isTmpVarGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 278 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 278 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 278 */
 else  /* Line: 278 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 278 */ {
bevl_sco = this.bem_classGet_0();
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_12_tmpvar_phold);
} /* Line: 280 */
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_15_tmpvar_phold);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 283 */ {
bevt_17_tmpvar_phold = (new BEC_2_4_6_TextString(30, bels_15));
bevt_16_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_17_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_16_tmpvar_phold);
} /* Line: 284 */
bevt_18_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_19_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_18_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_19_tmpvar_phold, this);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_20_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 287 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_syncAddVariable_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_sco = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
bevl_v = bevp_held;
bevt_1_tmpvar_phold = bevl_v.bemd_0(495053105, BEL_4_Base.bevn_isAddedGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 293 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(506135358, BEL_4_Base.bevn_isAddedSet_1, bevt_2_tmpvar_phold);
bevl_sco = this.bem_scopeGet_0();
bevl_sc = bevl_sco.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_5_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_5_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 297 */ {
bevt_6_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_7_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
} /* Line: 298 */
 else  /* Line: 299 */ {
bevt_8_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_11_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_11_tmpvar_phold);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 301 */ {
bevt_12_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_13_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_held = bevt_12_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_13_tmpvar_phold);
} /* Line: 302 */
 else  /* Line: 303 */ {
bevt_14_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_15_tmpvar_phold = bevl_v.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_14_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_15_tmpvar_phold, this);
bevt_16_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_16_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
bevt_18_tmpvar_phold = bevl_sco.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_19_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_19_tmpvar_phold);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 306 */ {
bevt_21_tmpvar_phold = (new BEC_2_4_6_TextString(35, bels_16));
bevt_20_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 307 */
} /* Line: 306 */
} /* Line: 301 */
} /* Line: 297 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_syncVariable_1(BEC_3_5_5_7_BuildVisitVisitor beva_visit) throws Throwable {
BEC_2_6_6_SystemObject bevl_vname = null;
BEC_2_6_6_SystemObject bevl_sc = null;
BEC_2_6_6_SystemObject bevl_cl = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
bevl_vname = bevp_held;
bevt_0_tmpvar_phold = this.bem_scopeGet_0();
bevl_sc = bevt_0_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_2_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 318 */ {
bevt_4_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_3_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 319 */
 else  /* Line: 320 */ {
bevt_5_tmpvar_phold = this.bem_classGet_0();
bevl_cl = bevt_5_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevl_vname);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 322 */ {
bevt_9_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
bevp_held = bevt_8_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
} /* Line: 323 */
 else  /* Line: 324 */ {
bevl_tunode = this.bem_transUnitGet_0();
bevt_11_tmpvar_phold = bevl_tunode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1385290712, BEL_4_Base.bevn_aliasedGet_0);
bevl_np = bevt_10_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_vname);
if (bevl_np == null) {
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpvar_phold.bevi_bool) /* Line: 327 */ {
bevt_15_tmpvar_phold = bevo_3;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevl_np);
bevt_13_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_14_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_13_tmpvar_phold);
} /* Line: 328 */
 else  /* Line: 329 */ {
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_v.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevl_vname);
bevt_17_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_18));
bevt_16_tmpvar_phold = bevl_vname.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_17_tmpvar_phold);
if (bevt_16_tmpvar_phold != null && bevt_16_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_16_tmpvar_phold).bevi_bool) /* Line: 333 */ {
bevp_held = bevl_v;
bevt_18_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = bevl_cl.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
bevl_v.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = bevl_sc.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_20_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_21_tmpvar_phold = bevl_sc.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_21_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 338 */
 else  /* Line: 339 */ {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_v.bemd_1(1465928304, BEL_4_Base.bevn_isDeclaredSet_1, bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_v.bemd_1(1137515957, BEL_4_Base.bevn_isPropertySet_1, bevt_23_tmpvar_phold);
bevp_held = bevl_v;
bevt_24_tmpvar_phold = bevl_cl.bemd_0(1155896786, BEL_4_Base.bevn_varMapGet_0);
bevt_24_tmpvar_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevl_vname, this);
bevt_25_tmpvar_phold = bevl_cl.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevt_25_tmpvar_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, this);
} /* Line: 344 */
} /* Line: 333 */
} /* Line: 327 */
} /* Line: 322 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_anchorGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
bevl_node = this;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 353 */ {
while (true)
 /* Line: 354 */ {
bevt_2_tmpvar_phold = bevp_constants.bem_anchorTypesGet_0();
bevt_3_tmpvar_phold = bevl_node.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_has_1(bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 355 */ {
return bevl_node;
} /* Line: 356 */
 else  /* Line: 357 */ {
bevl_node = bevl_node.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
if (bevl_node == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 359 */ {
bevt_6_tmpvar_phold = (new BEC_2_4_6_TextString(18, bels_19));
bevt_5_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_6_tmpvar_phold, this);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 360 */
} /* Line: 359 */
} /* Line: 355 */
} /* Line: 354 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_classGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 369 */ {
if (bevl_targ == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 369 */ {
bevt_3_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_4_tmpvar_phold);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 369 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 369 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 369 */
 else  /* Line: 369 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 369 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 370 */
 else  /* Line: 369 */ {
break;
} /* Line: 369 */
} /* Line: 369 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_scopeGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
bevl_targ = this;
while (true)
 /* Line: 377 */ {
if (bevl_targ == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 377 */ {
bevt_5_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_6_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_6_tmpvar_phold);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 377 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 377 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 377 */
 else  /* Line: 377 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 377 */ {
bevt_8_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_9_tmpvar_phold = bevp_ntypes.bem_METHODGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_9_tmpvar_phold);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 377 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 377 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 377 */
 else  /* Line: 377 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 377 */ {
bevt_11_tmpvar_phold = bevl_targ.bemd_0(2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_12_tmpvar_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_12_tmpvar_phold);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 377 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 377 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 377 */
 else  /* Line: 377 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 377 */ {
bevl_targ = bevl_targ.bemd_0(833063302, BEL_4_Base.bevn_containerGet_0);
} /* Line: 378 */
 else  /* Line: 377 */ {
break;
} /* Line: 377 */
} /* Line: 377 */
return bevl_targ;
} /*method end*/
public BEC_2_6_6_SystemObject bem_replaceWith_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_heldBy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 384 */ {
return null;
} /* Line: 385 */
beva_other.bem_containerSet_1(bevp_container);
bevp_heldBy.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, beva_other);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deleteAndAppend_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
beva_other.bem_delete_0();
this.bem_addValue_1(beva_other);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_takeContents_1(BEC_2_5_4_BuildNode beva_other) throws Throwable {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
bevp_contained = beva_other.bem_containedGet_0();
bevl_it = bevp_contained.bem_iteratorGet_0();
while (true)
 /* Line: 398 */ {
bevt_0_tmpvar_phold = bevl_it.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_0_tmpvar_phold != null && bevt_0_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpvar_phold).bevi_bool) /* Line: 398 */ {
bevl_i = bevl_it.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i.bemd_1(844145555, BEL_4_Base.bevn_containerSet_1, this);
} /* Line: 400 */
 else  /* Line: 398 */ {
break;
} /* Line: 398 */
} /* Line: 398 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_resolveNp_0() throws Throwable {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevp_typename.bevi_int == bevt_1_tmpvar_phold.bevi_int) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held;
if (bevl_np == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 409 */
} /* Line: 408 */
bevt_4_tmpvar_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevp_typename.bevi_int == bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 412 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpvar_phold.bevi_bool) /* Line: 414 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 415 */
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(429326446, BEL_4_Base.bevn_extendsGet_0);
if (bevl_np == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 418 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 419 */
bevt_8_tmpvar_phold = bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_held.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_7_tmpvar_phold);
} /* Line: 421 */
bevt_10_tmpvar_phold = bevp_ntypes.bem_VARGet_0();
if (bevp_typename.bevi_int == bevt_10_tmpvar_phold.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 423 */ {
bevl_np = (BEC_2_5_8_BuildNamePath) bevp_held.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
if (bevl_np == null) {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpvar_phold.bevi_bool) /* Line: 425 */ {
bevl_np.bem_resolve_1(this);
} /* Line: 426 */
} /* Line: 425 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_callIsSafe_1(BEC_2_5_4_BuildNode beva_call) throws Throwable {
BEC_2_9_3_ContainerSet bevl_alwaysOkCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses = null;
BEC_2_9_3_ContainerSet bevl_okCalls = null;
BEC_2_9_3_ContainerSet bevl_okClasses2 = null;
BEC_2_9_3_ContainerSet bevl_okCalls2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_29_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_30_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_35_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_36_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_45_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_54_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_61_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpvar_phold = null;
BEC_2_9_8_ContainerNodeList bevt_71_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 436 */ {
bevt_6_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bemd_0(1583922395, BEL_4_Base.bevn_newNpGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_20));
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_7_tmpvar_phold);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 436 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 436 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 436 */
 else  /* Line: 436 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 436 */ {
bevt_8_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_8_tmpvar_phold;
} /* Line: 437 */
synchronized (BEC_2_5_4_BuildNode.class) {
if (bevo_4 == null) {
bevo_4 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_alwaysOkCalls = bevo_4;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bevo_5 == null) {
bevo_5 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses = bevo_5;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bevo_6 == null) {
bevo_6 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls = bevo_6;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bevo_7 == null) {
bevo_7 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okClasses2 = bevo_7;
synchronized (BEC_2_5_4_BuildNode.class) {
if (bevo_8 == null) {
bevo_8 = (new BEC_2_9_3_ContainerSet()).bem_new_0();
}
}
bevl_okCalls2 = bevo_8;
bevt_10_tmpvar_phold = bevl_okClasses.bem_sizeGet_0();
bevt_11_tmpvar_phold = bevo_9;
if (bevt_10_tmpvar_phold.bevi_int == bevt_11_tmpvar_phold.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 445 */ {
bevt_12_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_21));
bevl_alwaysOkCalls.bem_put_1(bevt_12_tmpvar_phold);
bevt_13_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_22));
bevl_okClasses.bem_put_1(bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_23));
bevl_okClasses.bem_put_1(bevt_14_tmpvar_phold);
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_24));
bevl_okCalls.bem_put_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_25));
bevl_okCalls.bem_put_1(bevt_16_tmpvar_phold);
bevt_17_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_26));
bevl_okCalls.bem_put_1(bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_27));
bevl_okCalls.bem_put_1(bevt_18_tmpvar_phold);
bevt_19_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_28));
bevl_okCalls.bem_put_1(bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_29));
bevl_okCalls.bem_put_1(bevt_20_tmpvar_phold);
bevt_21_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_30));
bevl_okCalls.bem_put_1(bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_31));
bevl_okCalls.bem_put_1(bevt_22_tmpvar_phold);
bevt_23_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_32));
bevl_okCalls.bem_put_1(bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_33));
bevl_okCalls.bem_put_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_34));
bevl_okCalls.bem_put_1(bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_35));
bevl_okCalls.bem_put_1(bevt_26_tmpvar_phold);
bevt_27_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_36));
bevl_okCalls.bem_put_1(bevt_27_tmpvar_phold);
bevt_28_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_37));
bevl_okCalls.bem_put_1(bevt_28_tmpvar_phold);
bevt_29_tmpvar_phold = (new BEC_2_4_6_TextString(14, bels_38));
bevl_okCalls.bem_put_1(bevt_29_tmpvar_phold);
bevt_30_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_39));
bevl_okCalls.bem_put_1(bevt_30_tmpvar_phold);
bevt_31_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_40));
bevl_okCalls.bem_put_1(bevt_31_tmpvar_phold);
bevt_32_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_41));
bevl_okCalls.bem_put_1(bevt_32_tmpvar_phold);
bevt_33_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_42));
bevl_okCalls.bem_put_1(bevt_33_tmpvar_phold);
bevt_34_tmpvar_phold = (new BEC_2_4_6_TextString(10, bels_43));
bevl_okCalls.bem_put_1(bevt_34_tmpvar_phold);
bevt_35_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_44));
bevl_okCalls.bem_put_1(bevt_35_tmpvar_phold);
bevt_36_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_45));
bevl_okCalls.bem_put_1(bevt_36_tmpvar_phold);
bevt_37_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_46));
bevl_okCalls.bem_put_1(bevt_37_tmpvar_phold);
bevt_38_tmpvar_phold = (new BEC_2_4_6_TextString(11, bels_47));
bevl_okCalls.bem_put_1(bevt_38_tmpvar_phold);
bevt_39_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_48));
bevl_okCalls.bem_put_1(bevt_39_tmpvar_phold);
bevt_40_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_49));
bevl_okClasses2.bem_put_1(bevt_40_tmpvar_phold);
bevt_41_tmpvar_phold = (new BEC_2_4_6_TextString(13, bels_50));
bevl_okClasses2.bem_put_1(bevt_41_tmpvar_phold);
bevt_42_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_51));
bevl_okClasses2.bem_put_1(bevt_42_tmpvar_phold);
bevt_43_tmpvar_phold = (new BEC_2_4_6_TextString(15, bels_52));
bevl_okClasses2.bem_put_1(bevt_43_tmpvar_phold);
bevt_44_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_53));
bevl_okCalls2.bem_put_1(bevt_44_tmpvar_phold);
bevt_45_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_54));
bevl_okCalls2.bem_put_1(bevt_45_tmpvar_phold);
} /* Line: 495 */
bevt_48_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_47_tmpvar_phold = bevt_48_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_46_tmpvar_phold = bevl_alwaysOkCalls.bem_has_1(bevt_47_tmpvar_phold);
if (bevt_46_tmpvar_phold.bevi_bool) /* Line: 499 */ {
bevt_49_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_49_tmpvar_phold;
} /* Line: 501 */
bevt_54_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_firstGet_0();
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_50_tmpvar_phold = bevt_51_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 505 */ {
bevt_55_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_55_tmpvar_phold;
} /* Line: 507 */
bevt_61_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_firstGet_0();
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_57_tmpvar_phold = bevt_58_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_56_tmpvar_phold = bevl_okClasses.bem_has_1(bevt_57_tmpvar_phold);
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 515 */ {
bevt_64_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_62_tmpvar_phold = bevl_okCalls.bem_has_1(bevt_63_tmpvar_phold);
if (bevt_62_tmpvar_phold.bevi_bool) /* Line: 516 */ {
bevt_65_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_65_tmpvar_phold;
} /* Line: 518 */
 else  /* Line: 519 */ {
} /* Line: 519 */
} /* Line: 516 */
bevt_71_tmpvar_phold = beva_call.bem_containedGet_0();
bevt_70_tmpvar_phold = bevt_71_tmpvar_phold.bem_firstGet_0();
bevt_69_tmpvar_phold = bevt_70_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_68_tmpvar_phold = bevt_69_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_67_tmpvar_phold = bevt_68_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_66_tmpvar_phold = bevl_okClasses2.bem_has_1(bevt_67_tmpvar_phold);
if (bevt_66_tmpvar_phold.bevi_bool) /* Line: 523 */ {
bevt_74_tmpvar_phold = beva_call.bem_heldGet_0();
bevt_73_tmpvar_phold = bevt_74_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_72_tmpvar_phold = bevl_okCalls2.bem_has_1(bevt_73_tmpvar_phold);
if (bevt_72_tmpvar_phold.bevi_bool) /* Line: 524 */ {
bevt_75_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_75_tmpvar_phold;
} /* Line: 526 */
 else  /* Line: 527 */ {
} /* Line: 527 */
} /* Line: 524 */
bevt_76_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_76_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLiteralOnceGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_BuildNode bevl_c0 = null;
BEC_2_5_4_BuildNode bevl_c1 = null;
BEC_2_5_4_BuildNode bevl_call = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpvar_phold = null;
bevl_result = be.BELS_Base.BECS_Runtime.boolFalse;
bevt_4_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevp_typename.bevi_int != bevt_4_tmpvar_phold.bevi_int) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 548 */ {
bevt_5_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_5_tmpvar_phold;
} /* Line: 548 */
bevt_7_tmpvar_phold = bevp_held.bemd_0(1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_8_tmpvar_phold = (new BEC_2_4_6_TextString(6, bels_55));
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_8_tmpvar_phold);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 549 */ {
bevl_c0 = (BEC_2_5_4_BuildNode) bevp_contained.bem_firstGet_0();
bevl_c1 = (BEC_2_5_4_BuildNode) bevp_contained.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 552 */ {
bevt_11_tmpvar_phold = bevl_c1.bem_typenameGet_0();
bevt_12_tmpvar_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_11_tmpvar_phold.bevi_int == bevt_12_tmpvar_phold.bevi_int) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 552 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 552 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 552 */
 else  /* Line: 552 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 552 */ {
bevt_14_tmpvar_phold = bevl_c1.bem_heldGet_0();
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1569395810, BEL_4_Base.bevn_isLiteralGet_0);
if (bevt_13_tmpvar_phold != null && bevt_13_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_13_tmpvar_phold).bevi_bool) /* Line: 553 */ {
bevt_17_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bemd_0(1126433704, BEL_4_Base.bevn_isPropertyGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 553 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 553 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 553 */
 else  /* Line: 553 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 553 */ {
bevl_result = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_19_tmpvar_phold = bevl_c0.bem_heldGet_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(2024716595, BEL_4_Base.bevn_allCallsGet_0);
bevt_0_tmpvar_loop = bevt_18_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 555 */ {
bevt_20_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 555 */ {
bevl_call = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_21_tmpvar_phold = bevl_call.bem_notEquals_1(this);
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 556 */ {
bevt_23_tmpvar_phold = this.bem_callIsSafe_1(bevl_call);
if (bevt_23_tmpvar_phold.bevi_bool) {
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 557 */ {
bevt_24_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_24_tmpvar_phold;
} /* Line: 558 */
} /* Line: 557 */
} /* Line: 556 */
 else  /* Line: 555 */ {
break;
} /* Line: 555 */
} /* Line: 555 */
} /* Line: 555 */
} /* Line: 553 */
} /* Line: 552 */
return bevl_result;
} /*method end*/
public BEC_2_9_8_ContainerNodeList bem_containedGet_0() throws Throwable {
return bevp_contained;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_contained = (BEC_2_9_8_ContainerNodeList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() throws Throwable {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldGet_0() throws Throwable {
return bevp_held;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_held = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldByGet_0() throws Throwable {
return bevp_heldBy;
} /*method end*/
public BEC_2_6_6_SystemObject bem_heldBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_heldBy = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condvarGet_0() throws Throwable {
return bevp_condvar;
} /*method end*/
public BEC_2_6_6_SystemObject bem_condvarSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_condvar = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() throws Throwable {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() throws Throwable {
return bevp_inFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailGet_0() throws Throwable {
return bevp_typeDetail;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typeDetailSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_typeDetail = bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_delayDeleteGet_0() throws Throwable {
return bevp_delayDelete;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delayDeleteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_delayDelete = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlcGet_0() throws Throwable {
return bevp_nlc;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nlc = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nlecGet_0() throws Throwable {
return bevp_nlec;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlecSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_nlec = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_wideStringGet_0() throws Throwable {
return bevp_wideString;
} /*method end*/
public BEC_2_6_6_SystemObject bem_wideStringSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_wideString = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_6_6_SystemObject bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_typenameGet_0() throws Throwable {
return bevp_typename;
} /*method end*/
public BEC_2_6_6_SystemObject bem_typenameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_typename = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inlinedGet_0() throws Throwable {
return bevp_inlined;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inlinedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_inlined = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {32, 33, 34, 35, 37, 38, 39, 40, 41, 46, 46, 47, 47, 48, 49, 53, 53, 53, 53, 53, 0, 0, 0, 54, 54, 56, 57, 58, 58, 58, 58, 0, 0, 0, 59, 60, 62, 66, 67, 68, 68, 68, 68, 0, 0, 0, 69, 70, 72, 76, 76, 77, 79, 80, 80, 81, 83, 83, 87, 87, 88, 90, 91, 91, 92, 94, 94, 98, 98, 102, 102, 106, 106, 110, 110, 111, 111, 113, 113, 113, 117, 117, 0, 117, 117, 117, 0, 0, 118, 118, 120, 120, 120, 120, 124, 124, 0, 124, 124, 124, 0, 0, 0, 124, 124, 124, 124, 0, 0, 125, 125, 127, 127, 127, 127, 127, 131, 135, 135, 136, 138, 139, 140, 144, 144, 145, 147, 147, 147, 148, 152, 152, 153, 155, 156, 160, 160, 161, 163, 164, 168, 172, 172, 173, 180, 182, 183, 185, 189, 190, 190, 190, 190, 190, 190, 191, 191, 191, 191, 191, 191, 191, 191, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 193, 193, 193, 193, 193, 193, 193, 193, 193, 193, 193, 195, 195, 196, 196, 196, 196, 196, 196, 197, 197, 199, 203, 204, 204, 204, 204, 204, 204, 205, 205, 206, 206, 206, 206, 208, 208, 209, 209, 209, 209, 211, 211, 212, 212, 212, 212, 214, 218, 219, 220, 220, 221, 222, 224, 228, 229, 230, 231, 231, 232, 231, 234, 238, 239, 239, 239, 239, 239, 0, 0, 0, 240, 242, 246, 247, 247, 247, 248, 248, 248, 250, 250, 250, 251, 251, 251, 251, 251, 252, 253, 253, 254, 255, 255, 255, 255, 256, 260, 261, 261, 262, 262, 262, 262, 263, 263, 265, 267, 267, 271, 272, 272, 273, 273, 274, 275, 275, 275, 276, 276, 276, 278, 278, 278, 0, 0, 0, 279, 280, 280, 282, 283, 283, 283, 284, 284, 284, 286, 286, 286, 287, 287, 292, 293, 293, 294, 294, 295, 296, 297, 297, 297, 298, 298, 298, 300, 300, 301, 301, 301, 302, 302, 302, 304, 304, 304, 305, 305, 306, 306, 306, 307, 307, 307, 316, 317, 317, 318, 318, 319, 319, 319, 321, 321, 322, 322, 323, 323, 323, 325, 326, 326, 326, 327, 327, 328, 328, 328, 328, 331, 332, 333, 333, 334, 335, 335, 336, 336, 337, 337, 338, 338, 340, 340, 341, 341, 342, 343, 343, 344, 344, 352, 353, 355, 355, 355, 356, 358, 359, 359, 360, 360, 360, 368, 369, 369, 369, 369, 369, 0, 0, 0, 370, 372, 376, 377, 377, 377, 377, 377, 0, 0, 0, 377, 377, 377, 0, 0, 0, 377, 377, 377, 0, 0, 0, 378, 380, 384, 384, 385, 387, 388, 392, 393, 397, 398, 398, 399, 400, 406, 406, 406, 407, 408, 408, 409, 412, 412, 412, 413, 414, 414, 415, 417, 418, 418, 419, 421, 421, 421, 423, 423, 423, 424, 425, 425, 426, 436, 436, 436, 436, 436, 436, 436, 0, 0, 0, 437, 437, 440, 441, 442, 443, 444, 445, 445, 445, 445, 452, 452, 455, 455, 456, 456, 458, 458, 459, 459, 460, 460, 461, 461, 462, 462, 463, 463, 464, 464, 465, 465, 466, 466, 467, 467, 468, 468, 469, 469, 470, 470, 471, 471, 472, 472, 473, 473, 474, 474, 475, 475, 476, 476, 477, 477, 478, 478, 479, 479, 480, 480, 481, 481, 482, 482, 486, 486, 487, 487, 488, 488, 489, 489, 494, 494, 495, 495, 499, 499, 499, 501, 501, 505, 505, 505, 505, 505, 507, 507, 515, 515, 515, 515, 515, 515, 516, 516, 516, 518, 518, 523, 523, 523, 523, 523, 523, 524, 524, 524, 526, 526, 532, 532, 543, 548, 548, 548, 548, 548, 549, 549, 549, 550, 551, 552, 552, 552, 552, 552, 552, 0, 0, 0, 553, 553, 553, 553, 553, 0, 0, 0, 554, 555, 555, 555, 0, 555, 555, 556, 557, 557, 557, 558, 558, 569, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {92, 93, 94, 95, 96, 97, 98, 99, 100, 106, 107, 108, 109, 110, 111, 125, 130, 131, 132, 137, 138, 141, 145, 148, 149, 151, 152, 155, 160, 161, 166, 167, 170, 174, 177, 178, 184, 192, 193, 196, 201, 202, 207, 208, 211, 215, 218, 219, 225, 232, 237, 238, 240, 241, 246, 247, 249, 250, 257, 262, 263, 265, 266, 271, 272, 274, 275, 279, 280, 284, 285, 289, 290, 297, 302, 303, 304, 306, 307, 312, 323, 328, 329, 332, 333, 338, 339, 342, 346, 347, 349, 350, 351, 356, 372, 377, 378, 381, 382, 387, 388, 391, 395, 398, 399, 400, 405, 406, 409, 413, 414, 416, 417, 418, 419, 424, 427, 432, 437, 438, 440, 441, 442, 449, 454, 455, 457, 458, 459, 460, 465, 470, 471, 473, 474, 479, 484, 485, 487, 488, 492, 497, 502, 503, 511, 515, 516, 518, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 578, 579, 584, 585, 588, 592, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 610, 615, 616, 617, 618, 619, 620, 621, 622, 623, 625, 647, 648, 649, 650, 651, 652, 653, 654, 659, 660, 661, 662, 663, 665, 670, 671, 672, 673, 674, 676, 681, 682, 683, 684, 685, 687, 693, 694, 697, 702, 703, 704, 710, 718, 719, 720, 721, 724, 726, 727, 733, 742, 745, 750, 751, 752, 753, 755, 758, 762, 765, 771, 792, 793, 794, 795, 797, 798, 799, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 827, 830, 835, 836, 837, 838, 843, 844, 845, 847, 853, 854, 881, 882, 883, 885, 886, 887, 888, 889, 890, 892, 893, 894, 896, 898, 899, 901, 904, 908, 911, 912, 913, 915, 916, 917, 918, 920, 921, 922, 924, 925, 926, 927, 928, 959, 960, 961, 963, 964, 965, 966, 967, 968, 969, 971, 972, 973, 976, 977, 978, 979, 980, 982, 983, 984, 987, 988, 989, 990, 991, 992, 993, 994, 996, 997, 998, 1038, 1039, 1040, 1041, 1042, 1044, 1045, 1046, 1049, 1050, 1051, 1052, 1054, 1055, 1056, 1059, 1060, 1061, 1062, 1063, 1068, 1069, 1070, 1071, 1072, 1075, 1076, 1077, 1078, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1115, 1116, 1120, 1121, 1122, 1124, 1127, 1128, 1133, 1134, 1135, 1136, 1150, 1153, 1158, 1159, 1160, 1161, 1163, 1166, 1170, 1173, 1179, 1196, 1199, 1204, 1205, 1206, 1207, 1209, 1212, 1216, 1219, 1220, 1221, 1223, 1226, 1230, 1233, 1234, 1235, 1237, 1240, 1244, 1247, 1253, 1257, 1262, 1263, 1265, 1266, 1270, 1271, 1278, 1279, 1282, 1284, 1285, 1307, 1308, 1313, 1314, 1315, 1320, 1321, 1324, 1325, 1330, 1331, 1332, 1337, 1338, 1340, 1341, 1346, 1347, 1349, 1350, 1351, 1353, 1354, 1359, 1360, 1361, 1366, 1367, 1455, 1456, 1458, 1459, 1460, 1461, 1462, 1464, 1467, 1471, 1474, 1475, 1477, 1483, 1489, 1495, 1501, 1507, 1508, 1509, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1584, 1585, 1586, 1588, 1589, 1591, 1592, 1593, 1594, 1595, 1597, 1598, 1600, 1601, 1602, 1603, 1604, 1605, 1607, 1608, 1609, 1611, 1612, 1617, 1618, 1619, 1620, 1621, 1622, 1624, 1625, 1626, 1628, 1629, 1634, 1635, 1667, 1668, 1669, 1674, 1675, 1676, 1678, 1679, 1680, 1682, 1683, 1684, 1689, 1690, 1691, 1692, 1697, 1698, 1701, 1705, 1708, 1709, 1711, 1712, 1713, 1715, 1718, 1722, 1725, 1726, 1727, 1728, 1728, 1731, 1733, 1734, 1736, 1737, 1742, 1743, 1744, 1755, 1758, 1761, 1765, 1768, 1772, 1775, 1779, 1782, 1786, 1789, 1793, 1796, 1800, 1803, 1807, 1810, 1814, 1817, 1821, 1824, 1828, 1831, 1835, 1838, 1842, 1845, 1849, 1852, 1856, 1859, 1863, 1866, 1870, 1873};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 32 92
new 0 32 92
assign 1 33 93
new 0 33 93
assign 1 34 94
new 0 34 94
assign 1 35 95
new 0 35 95
assign 1 37 96
assign 1 38 97
constantsGet 0 38 97
assign 1 39 98
ntypesGet 0 39 98
assign 1 40 99
TOKENGet 0 40 99
assign 1 41 100
new 0 41 100
assign 1 46 106
nlcGet 0 46 106
assign 1 46 107
copy 0 46 107
assign 1 47 108
nlecGet 0 47 108
assign 1 47 109
copy 0 47 109
assign 1 48 110
inClassNpGet 0 48 110
assign 1 49 111
inFileGet 0 49 111
assign 1 53 125
def 1 53 130
assign 1 53 131
firstGet 0 53 131
assign 1 53 132
def 1 53 137
assign 1 0 138
assign 1 0 141
assign 1 0 145
assign 1 54 148
firstGet 0 54 148
return 1 54 149
assign 1 56 151
nextPeerGet 0 56 151
assign 1 57 152
assign 1 58 155
undef 1 58 160
assign 1 58 161
def 1 58 166
assign 1 0 167
assign 1 0 170
assign 1 0 174
assign 1 59 177
nextPeerGet 0 59 177
assign 1 60 178
containerGet 0 60 178
return 1 62 184
assign 1 66 192
nextPeerGet 0 66 192
assign 1 67 193
assign 1 68 196
undef 1 68 201
assign 1 68 202
def 1 68 207
assign 1 0 208
assign 1 0 211
assign 1 0 215
assign 1 69 218
nextPeerGet 0 69 218
assign 1 70 219
containerGet 0 70 219
return 1 72 225
assign 1 76 232
undef 1 76 237
return 1 77 238
assign 1 79 240
nextGet 0 79 240
assign 1 80 241
undef 1 80 246
return 1 81 247
assign 1 83 249
heldGet 0 83 249
return 1 83 250
assign 1 87 257
undef 1 87 262
return 1 88 263
assign 1 90 265
priorGet 0 90 265
assign 1 91 266
undef 1 91 271
return 1 92 272
assign 1 94 274
heldGet 0 94 274
return 1 94 275
assign 1 98 279
firstGet 0 98 279
return 1 98 280
assign 1 102 284
secondGet 0 102 284
return 1 102 285
assign 1 106 289
thirdGet 0 106 289
return 1 106 290
assign 1 110 297
undef 1 110 302
assign 1 111 303
new 0 111 303
return 1 111 304
assign 1 113 306
priorGet 0 113 306
assign 1 113 307
undef 1 113 312
return 1 113 312
assign 1 117 323
undef 1 117 328
assign 1 0 329
assign 1 117 332
priorGet 0 117 332
assign 1 117 333
undef 1 117 338
assign 1 0 339
assign 1 0 342
assign 1 118 346
new 0 118 346
return 1 118 347
assign 1 120 349
priorGet 0 120 349
assign 1 120 350
priorGet 0 120 350
assign 1 120 351
undef 1 120 356
return 1 120 356
assign 1 124 372
undef 1 124 377
assign 1 0 378
assign 1 124 381
priorGet 0 124 381
assign 1 124 382
undef 1 124 387
assign 1 0 388
assign 1 0 391
assign 1 0 395
assign 1 124 398
priorGet 0 124 398
assign 1 124 399
priorGet 0 124 399
assign 1 124 400
undef 1 124 405
assign 1 0 406
assign 1 0 409
assign 1 125 413
new 0 125 413
return 1 125 414
assign 1 127 416
priorGet 0 127 416
assign 1 127 417
priorGet 0 127 417
assign 1 127 418
priorGet 0 127 418
assign 1 127 419
undef 1 127 424
return 1 127 424
assign 1 131 427
new 0 131 427
assign 1 135 432
undef 1 135 437
return 1 136 438
delete 0 138 440
assign 1 139 441
assign 1 140 442
assign 1 144 449
undef 1 144 454
return 1 145 455
assign 1 147 457
mylistGet 0 147 457
assign 1 147 458
newNode 1 147 458
insertBefore 1 147 459
containerSet 1 148 460
assign 1 152 465
undef 1 152 470
initContained 0 153 471
prepend 1 155 473
containerSet 1 156 474
assign 1 160 479
undef 1 160 484
initContained 0 161 485
addValue 1 163 487
containerSet 1 164 488
assign 1 168 492
new 0 168 492
assign 1 172 497
undef 1 172 502
assign 1 173 503
new 0 173 503
assign 1 180 511
toStringCompact 0 180 511
print 0 182 515
throw 1 183 516
return 1 185 518
assign 1 189 558
prefixGet 0 189 558
assign 1 190 559
new 0 190 559
assign 1 190 560
add 1 190 560
assign 1 190 561
toString 0 190 561
assign 1 190 562
add 1 190 562
assign 1 190 563
new 0 190 563
assign 1 190 564
add 1 190 564
assign 1 191 565
new 0 191 565
assign 1 191 566
newlineGet 0 191 566
assign 1 191 567
add 1 191 567
assign 1 191 568
add 1 191 568
assign 1 191 569
new 0 191 569
assign 1 191 570
add 1 191 570
assign 1 191 571
toString 0 191 571
assign 1 191 572
add 1 191 572
assign 1 192 573
def 1 192 578
assign 1 192 579
def 1 192 584
assign 1 0 585
assign 1 0 588
assign 1 0 592
assign 1 193 595
new 0 193 595
assign 1 193 596
newlineGet 0 193 596
assign 1 193 597
add 1 193 597
assign 1 193 598
add 1 193 598
assign 1 193 599
new 0 193 599
assign 1 193 600
add 1 193 600
assign 1 193 601
toString 0 193 601
assign 1 193 602
add 1 193 602
assign 1 193 603
new 0 193 603
assign 1 193 604
add 1 193 604
assign 1 193 605
add 1 193 605
assign 1 193 606
new 0 193 606
assign 1 193 607
newlineGet 0 193 607
assign 1 193 608
add 1 193 608
assign 1 195 610
def 1 195 615
assign 1 196 616
new 0 196 616
assign 1 196 617
newlineGet 0 196 617
assign 1 196 618
add 1 196 618
assign 1 196 619
add 1 196 619
assign 1 196 620
new 0 196 620
assign 1 196 621
add 1 196 621
assign 1 197 622
toString 0 197 622
assign 1 197 623
add 1 197 623
return 1 199 625
assign 1 203 647
prefixGet 0 203 647
assign 1 204 648
new 0 204 648
assign 1 204 649
add 1 204 649
assign 1 204 650
toString 0 204 650
assign 1 204 651
add 1 204 651
assign 1 204 652
new 0 204 652
assign 1 204 653
add 1 204 653
assign 1 205 654
def 1 205 659
assign 1 206 660
new 0 206 660
assign 1 206 661
add 1 206 661
assign 1 206 662
toString 0 206 662
assign 1 206 663
add 1 206 663
assign 1 208 665
def 1 208 670
assign 1 209 671
new 0 209 671
assign 1 209 672
add 1 209 672
assign 1 209 673
toString 0 209 673
assign 1 209 674
add 1 209 674
assign 1 211 676
def 1 211 681
assign 1 212 682
new 0 212 682
assign 1 212 683
add 1 212 683
assign 1 212 684
toString 0 212 684
assign 1 212 685
add 1 212 685
return 1 214 687
assign 1 218 693
new 0 218 693
assign 1 219 694
assign 1 220 697
def 1 220 702
assign 1 221 703
increment 0 221 703
assign 1 222 704
containerGet 0 222 704
return 1 224 710
assign 1 228 718
depthGet 0 228 718
assign 1 229 719
new 0 229 719
assign 1 230 720
new 0 230 720
assign 1 231 721
new 0 231 721
assign 1 231 724
lesser 1 231 724
assign 1 232 726
add 1 232 726
assign 1 231 727
increment 0 231 727
return 1 234 733
assign 1 238 742
assign 1 239 745
def 1 239 750
assign 1 239 751
typenameGet 0 239 751
assign 1 239 752
TRANSUNITGet 0 239 752
assign 1 239 753
notEquals 1 239 753
assign 1 0 755
assign 1 0 758
assign 1 0 762
assign 1 240 765
containerGet 0 240 765
return 1 242 771
assign 1 246 792
scopeGet 0 246 792
assign 1 247 793
typenameGet 0 247 793
assign 1 247 794
METHODGet 0 247 794
assign 1 247 795
notEquals 1 247 795
assign 1 248 797
new 0 248 797
assign 1 248 798
new 2 248 798
throw 1 248 799
assign 1 250 801
heldGet 0 250 801
assign 1 250 802
tmpCntGet 0 250 802
assign 1 250 803
toString 0 250 803
assign 1 251 804
heldGet 0 251 804
assign 1 251 805
heldGet 0 251 805
assign 1 251 806
tmpCntGet 0 251 806
assign 1 251 807
increment 0 251 807
tmpCntSet 1 251 808
assign 1 252 809
new 0 252 809
assign 1 253 810
new 0 253 810
isTmpVarSet 1 253 811
suffixSet 1 254 812
assign 1 255 813
new 0 255 813
assign 1 255 814
add 1 255 814
assign 1 255 815
add 1 255 815
nameSet 1 255 816
return 1 256 817
assign 1 260 827
assign 1 261 830
def 1 261 835
assign 1 262 836
typenameGet 0 262 836
assign 1 262 837
PROPERTIESGet 0 262 837
assign 1 262 838
equals 1 262 843
assign 1 263 844
new 0 263 844
return 1 263 845
assign 1 265 847
containerGet 0 265 847
assign 1 267 853
new 0 267 853
return 1 267 854
assign 1 271 881
assign 1 272 882
isAddedGet 0 272 882
assign 1 272 883
not 0 272 883
assign 1 273 885
new 0 273 885
isAddedSet 1 273 886
assign 1 274 887
scopeGet 0 274 887
assign 1 275 888
typenameGet 0 275 888
assign 1 275 889
CLASSGet 0 275 889
assign 1 275 890
equals 1 275 890
assign 1 276 892
new 0 276 892
assign 1 276 893
new 2 276 893
throw 1 276 894
assign 1 278 896
inPropertiesGet 0 278 896
assign 1 278 898
isTmpVarGet 0 278 898
assign 1 278 899
not 0 278 899
assign 1 0 901
assign 1 0 904
assign 1 0 908
assign 1 279 911
classGet 0 279 911
assign 1 280 912
new 0 280 912
isPropertySet 1 280 913
assign 1 282 915
heldGet 0 282 915
assign 1 283 916
varMapGet 0 283 916
assign 1 283 917
nameGet 0 283 917
assign 1 283 918
has 1 283 918
assign 1 284 920
new 0 284 920
assign 1 284 921
new 2 284 921
throw 1 284 922
assign 1 286 924
varMapGet 0 286 924
assign 1 286 925
nameGet 0 286 925
put 2 286 926
assign 1 287 927
orderedVarsGet 0 287 927
addValue 1 287 928
assign 1 292 959
assign 1 293 960
isAddedGet 0 293 960
assign 1 293 961
not 0 293 961
assign 1 294 963
new 0 294 963
isAddedSet 1 294 964
assign 1 295 965
scopeGet 0 295 965
assign 1 296 966
heldGet 0 296 966
assign 1 297 967
varMapGet 0 297 967
assign 1 297 968
nameGet 0 297 968
assign 1 297 969
has 1 297 969
assign 1 298 971
varMapGet 0 298 971
assign 1 298 972
nameGet 0 298 972
assign 1 298 973
get 1 298 973
assign 1 300 976
classGet 0 300 976
assign 1 300 977
heldGet 0 300 977
assign 1 301 978
varMapGet 0 301 978
assign 1 301 979
nameGet 0 301 979
assign 1 301 980
has 1 301 980
assign 1 302 982
varMapGet 0 302 982
assign 1 302 983
nameGet 0 302 983
assign 1 302 984
get 1 302 984
assign 1 304 987
varMapGet 0 304 987
assign 1 304 988
nameGet 0 304 988
put 2 304 989
assign 1 305 990
orderedVarsGet 0 305 990
addValue 1 305 991
assign 1 306 992
typenameGet 0 306 992
assign 1 306 993
CLASSGet 0 306 993
assign 1 306 994
equals 1 306 994
assign 1 307 996
new 0 307 996
assign 1 307 997
new 2 307 997
throw 1 307 998
assign 1 316 1038
assign 1 317 1039
scopeGet 0 317 1039
assign 1 317 1040
heldGet 0 317 1040
assign 1 318 1041
varMapGet 0 318 1041
assign 1 318 1042
has 1 318 1042
assign 1 319 1044
varMapGet 0 319 1044
assign 1 319 1045
get 1 319 1045
assign 1 319 1046
heldGet 0 319 1046
assign 1 321 1049
classGet 0 321 1049
assign 1 321 1050
heldGet 0 321 1050
assign 1 322 1051
varMapGet 0 322 1051
assign 1 322 1052
has 1 322 1052
assign 1 323 1054
varMapGet 0 323 1054
assign 1 323 1055
get 1 323 1055
assign 1 323 1056
heldGet 0 323 1056
assign 1 325 1059
transUnitGet 0 325 1059
assign 1 326 1060
heldGet 0 326 1060
assign 1 326 1061
aliasedGet 0 326 1061
assign 1 326 1062
get 1 326 1062
assign 1 327 1063
def 1 327 1068
assign 1 328 1069
new 0 328 1069
assign 1 328 1070
add 1 328 1070
assign 1 328 1071
new 2 328 1071
throw 1 328 1072
assign 1 331 1075
new 0 331 1075
nameSet 1 332 1076
assign 1 333 1077
new 0 333 1077
assign 1 333 1078
equals 1 333 1078
assign 1 334 1080
assign 1 335 1081
new 0 335 1081
isTypedSet 1 335 1082
assign 1 336 1083
extendsGet 0 336 1083
namepathSet 1 336 1084
assign 1 337 1085
varMapGet 0 337 1085
put 2 337 1086
assign 1 338 1087
orderedVarsGet 0 338 1087
addValue 1 338 1088
assign 1 340 1091
new 0 340 1091
isDeclaredSet 1 340 1092
assign 1 341 1093
new 0 341 1093
isPropertySet 1 341 1094
assign 1 342 1095
assign 1 343 1096
varMapGet 0 343 1096
put 2 343 1097
assign 1 344 1098
orderedVarsGet 0 344 1098
addValue 1 344 1099
assign 1 352 1115
assign 1 353 1116
new 0 353 1116
assign 1 355 1120
anchorTypesGet 0 355 1120
assign 1 355 1121
typenameGet 0 355 1121
assign 1 355 1122
has 1 355 1122
return 1 356 1124
assign 1 358 1127
containerGet 0 358 1127
assign 1 359 1128
undef 1 359 1133
assign 1 360 1134
new 0 360 1134
assign 1 360 1135
new 2 360 1135
throw 1 360 1136
assign 1 368 1150
assign 1 369 1153
def 1 369 1158
assign 1 369 1159
typenameGet 0 369 1159
assign 1 369 1160
CLASSGet 0 369 1160
assign 1 369 1161
notEquals 1 369 1161
assign 1 0 1163
assign 1 0 1166
assign 1 0 1170
assign 1 370 1173
containerGet 0 370 1173
return 1 372 1179
assign 1 376 1196
assign 1 377 1199
def 1 377 1204
assign 1 377 1205
typenameGet 0 377 1205
assign 1 377 1206
CLASSGet 0 377 1206
assign 1 377 1207
notEquals 1 377 1207
assign 1 0 1209
assign 1 0 1212
assign 1 0 1216
assign 1 377 1219
typenameGet 0 377 1219
assign 1 377 1220
METHODGet 0 377 1220
assign 1 377 1221
notEquals 1 377 1221
assign 1 0 1223
assign 1 0 1226
assign 1 0 1230
assign 1 377 1233
typenameGet 0 377 1233
assign 1 377 1234
TRANSUNITGet 0 377 1234
assign 1 377 1235
notEquals 1 377 1235
assign 1 0 1237
assign 1 0 1240
assign 1 0 1244
assign 1 378 1247
containerGet 0 378 1247
return 1 380 1253
assign 1 384 1257
undef 1 384 1262
return 1 385 1263
containerSet 1 387 1265
heldSet 1 388 1266
delete 0 392 1270
addValue 1 393 1271
assign 1 397 1278
containedGet 0 397 1278
assign 1 398 1279
iteratorGet 0 398 1279
assign 1 398 1282
hasNextGet 0 398 1282
assign 1 399 1284
nextGet 0 399 1284
containerSet 1 400 1285
assign 1 406 1307
NAMEPATHGet 0 406 1307
assign 1 406 1308
equals 1 406 1313
assign 1 407 1314
assign 1 408 1315
def 1 408 1320
resolve 1 409 1321
assign 1 412 1324
CLASSGet 0 412 1324
assign 1 412 1325
equals 1 412 1330
assign 1 413 1331
namepathGet 0 413 1331
assign 1 414 1332
def 1 414 1337
resolve 1 415 1338
assign 1 417 1340
extendsGet 0 417 1340
assign 1 418 1341
def 1 418 1346
resolve 1 419 1347
assign 1 421 1349
namepathGet 0 421 1349
assign 1 421 1350
toString 0 421 1350
nameSet 1 421 1351
assign 1 423 1353
VARGet 0 423 1353
assign 1 423 1354
equals 1 423 1359
assign 1 424 1360
namepathGet 0 424 1360
assign 1 425 1361
def 1 425 1366
resolve 1 426 1367
assign 1 436 1455
heldGet 0 436 1455
assign 1 436 1456
isConstructGet 0 436 1456
assign 1 436 1458
heldGet 0 436 1458
assign 1 436 1459
newNpGet 0 436 1459
assign 1 436 1460
toString 0 436 1460
assign 1 436 1461
new 0 436 1461
assign 1 436 1462
equals 1 436 1462
assign 1 0 1464
assign 1 0 1467
assign 1 0 1471
assign 1 437 1474
new 0 437 1474
return 1 437 1475
assign 1 440 1477
new 0 440 1477
assign 1 441 1483
new 0 441 1483
assign 1 442 1489
new 0 442 1489
assign 1 443 1495
new 0 443 1495
assign 1 444 1501
new 0 444 1501
assign 1 445 1507
sizeGet 0 445 1507
assign 1 445 1508
new 0 445 1508
assign 1 445 1509
equals 1 445 1514
assign 1 452 1515
new 0 452 1515
put 1 452 1516
assign 1 455 1517
new 0 455 1517
put 1 455 1518
assign 1 456 1519
new 0 456 1519
put 1 456 1520
assign 1 458 1521
new 0 458 1521
put 1 458 1522
assign 1 459 1523
new 0 459 1523
put 1 459 1524
assign 1 460 1525
new 0 460 1525
put 1 460 1526
assign 1 461 1527
new 0 461 1527
put 1 461 1528
assign 1 462 1529
new 0 462 1529
put 1 462 1530
assign 1 463 1531
new 0 463 1531
put 1 463 1532
assign 1 464 1533
new 0 464 1533
put 1 464 1534
assign 1 465 1535
new 0 465 1535
put 1 465 1536
assign 1 466 1537
new 0 466 1537
put 1 466 1538
assign 1 467 1539
new 0 467 1539
put 1 467 1540
assign 1 468 1541
new 0 468 1541
put 1 468 1542
assign 1 469 1543
new 0 469 1543
put 1 469 1544
assign 1 470 1545
new 0 470 1545
put 1 470 1546
assign 1 471 1547
new 0 471 1547
put 1 471 1548
assign 1 472 1549
new 0 472 1549
put 1 472 1550
assign 1 473 1551
new 0 473 1551
put 1 473 1552
assign 1 474 1553
new 0 474 1553
put 1 474 1554
assign 1 475 1555
new 0 475 1555
put 1 475 1556
assign 1 476 1557
new 0 476 1557
put 1 476 1558
assign 1 477 1559
new 0 477 1559
put 1 477 1560
assign 1 478 1561
new 0 478 1561
put 1 478 1562
assign 1 479 1563
new 0 479 1563
put 1 479 1564
assign 1 480 1565
new 0 480 1565
put 1 480 1566
assign 1 481 1567
new 0 481 1567
put 1 481 1568
assign 1 482 1569
new 0 482 1569
put 1 482 1570
assign 1 486 1571
new 0 486 1571
put 1 486 1572
assign 1 487 1573
new 0 487 1573
put 1 487 1574
assign 1 488 1575
new 0 488 1575
put 1 488 1576
assign 1 489 1577
new 0 489 1577
put 1 489 1578
assign 1 494 1579
new 0 494 1579
put 1 494 1580
assign 1 495 1581
new 0 495 1581
put 1 495 1582
assign 1 499 1584
heldGet 0 499 1584
assign 1 499 1585
nameGet 0 499 1585
assign 1 499 1586
has 1 499 1586
assign 1 501 1588
new 0 501 1588
return 1 501 1589
assign 1 505 1591
containedGet 0 505 1591
assign 1 505 1592
firstGet 0 505 1592
assign 1 505 1593
heldGet 0 505 1593
assign 1 505 1594
isTypedGet 0 505 1594
assign 1 505 1595
not 0 505 1595
assign 1 507 1597
new 0 507 1597
return 1 507 1598
assign 1 515 1600
containedGet 0 515 1600
assign 1 515 1601
firstGet 0 515 1601
assign 1 515 1602
heldGet 0 515 1602
assign 1 515 1603
namepathGet 0 515 1603
assign 1 515 1604
toString 0 515 1604
assign 1 515 1605
has 1 515 1605
assign 1 516 1607
heldGet 0 516 1607
assign 1 516 1608
nameGet 0 516 1608
assign 1 516 1609
has 1 516 1609
assign 1 518 1611
new 0 518 1611
return 1 518 1612
assign 1 523 1617
containedGet 0 523 1617
assign 1 523 1618
firstGet 0 523 1618
assign 1 523 1619
heldGet 0 523 1619
assign 1 523 1620
namepathGet 0 523 1620
assign 1 523 1621
toString 0 523 1621
assign 1 523 1622
has 1 523 1622
assign 1 524 1624
heldGet 0 524 1624
assign 1 524 1625
nameGet 0 524 1625
assign 1 524 1626
has 1 524 1626
assign 1 526 1628
new 0 526 1628
return 1 526 1629
assign 1 532 1634
new 0 532 1634
return 1 532 1635
assign 1 543 1667
new 0 543 1667
assign 1 548 1668
CALLGet 0 548 1668
assign 1 548 1669
notEquals 1 548 1674
assign 1 548 1675
new 0 548 1675
return 1 548 1676
assign 1 549 1678
orgNameGet 0 549 1678
assign 1 549 1679
new 0 549 1679
assign 1 549 1680
equals 1 549 1680
assign 1 550 1682
firstGet 0 550 1682
assign 1 551 1683
secondGet 0 551 1683
assign 1 552 1684
def 1 552 1689
assign 1 552 1690
typenameGet 0 552 1690
assign 1 552 1691
CALLGet 0 552 1691
assign 1 552 1692
equals 1 552 1697
assign 1 0 1698
assign 1 0 1701
assign 1 0 1705
assign 1 553 1708
heldGet 0 553 1708
assign 1 553 1709
isLiteralGet 0 553 1709
assign 1 553 1711
heldGet 0 553 1711
assign 1 553 1712
isPropertyGet 0 553 1712
assign 1 553 1713
not 0 553 1713
assign 1 0 1715
assign 1 0 1718
assign 1 0 1722
assign 1 554 1725
new 0 554 1725
assign 1 555 1726
heldGet 0 555 1726
assign 1 555 1727
allCallsGet 0 555 1727
assign 1 555 1728
iteratorGet 0 0 1728
assign 1 555 1731
hasNextGet 0 555 1731
assign 1 555 1733
nextGet 0 555 1733
assign 1 556 1734
notEquals 1 556 1734
assign 1 557 1736
callIsSafe 1 557 1736
assign 1 557 1737
not 0 557 1742
assign 1 558 1743
new 0 558 1743
return 1 558 1744
return 1 569 1755
return 1 0 1758
assign 1 0 1761
return 1 0 1765
assign 1 0 1768
return 1 0 1772
assign 1 0 1775
return 1 0 1779
assign 1 0 1782
return 1 0 1786
assign 1 0 1789
return 1 0 1793
assign 1 0 1796
return 1 0 1800
assign 1 0 1803
return 1 0 1807
assign 1 0 1810
return 1 0 1814
assign 1 0 1817
return 1 0 1821
assign 1 0 1824
return 1 0 1828
assign 1 0 1831
return 1 0 1835
assign 1 0 1838
return 1 0 1842
assign 1 0 1845
return 1 0 1849
assign 1 0 1852
return 1 0 1856
assign 1 0 1859
return 1 0 1863
assign 1 0 1866
return 1 0 1870
assign 1 0 1873
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 339997707: return bem_nlecGet_0();
case 1820417453: return bem_create_0();
case 822104518: return bem_inFileGet_0();
case 443668840: return bem_methodNotDefined_0();
case 202810500: return bem_depthGet_0();
case 1595262430: return bem_nlcGet_0();
case 786424307: return bem_tagGet_0();
case 1740134355: return bem_syncAddVariable_0();
case 845792839: return bem_iteratorGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1522157789: return bem_wideStringGet_0();
case 68392679: return bem_delayDeleteGet_0();
case 1973596005: return bem_transUnitGet_0();
case 2110470555: return bem_priorPeerGet_0();
case 1081412016: return bem_many_0();
case 931239762: return bem_heldGet_0();
case 312889617: return bem_classGet_0();
case 1236878826: return bem_nextAscendGet_0();
case 1823343663: return bem_inPropertiesGet_0();
case 1014444004: return bem_typeDetailGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 1167184407: return bem_isSecondGet_0();
case 1193143594: return bem_isThirdGet_0();
case 1692872440: return bem_toStringCompact_0();
case 1437330926: return bem_inClassNpGet_0();
case 516830146: return bem_condvarGet_0();
case 576537281: return bem_delayDelete_0();
case 830625628: return bem_inlinedGet_0();
case 432255188: return bem_containedGet_0();
case 287040793: return bem_hashGet_0();
case 729571811: return bem_serializeToString_0();
case 1987872129: return bem_isFirstGet_0();
case 183400265: return bem_firstGet_0();
case 1758195374: return bem_addVariable_0();
case 242848115: return bem_secondGet_0();
case 1952633087: return bem_resolveNp_0();
case 1471053772: return bem_initContained_0();
case 1866790687: return bem_isLiteralOnceGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 819712668: return bem_delete_0();
case 978128800: return bem_thirdGet_0();
case 1461034369: return bem_reInitContained_0();
case 1354714650: return bem_copy_0();
case 104713553: return bem_new_0();
case 1898686885: return bem_toStringBig_0();
case 1566845998: return bem_anchorGet_0();
case 213728365: return bem_scopeGet_0();
case 1956934267: return bem_heldByGet_0();
case 1388725781: return bem_prefixGet_0();
case 1779180144: return bem_nextDescendGet_0();
case 644675716: return bem_ntypesGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1102720804: return bem_classNameGet_0();
case 2087681086: return bem_typenameGet_0();
case 927274360: return bem_constantsGet_0();
case 1012494862: return bem_once_0();
case 493012039: return bem_buildGet_0();
case 314718434: return bem_print_0();
case 124944494: return bem_nextPeerGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1279784069: return bem_defined_1(bevd_0);
case 57310426: return bem_delayDeleteSet_1(bevd_0);
case 844145555: return bem_containerSet_1(bevd_0);
case 875977779: return bem_takeContents_1((BEC_2_5_4_BuildNode) bevd_0);
case 443337441: return bem_containedSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 633593463: return bem_ntypesSet_1(bevd_0);
case 833186771: return bem_inFileSet_1(bevd_0);
case 205397975: return bem_syncVariable_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 351079960: return bem_nlecSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1170500300: return bem_replaceWith_1((BEC_2_5_4_BuildNode) bevd_0);
case 1671186230: return bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevd_0);
case 1487970429: return bem_copyLoc_1((BEC_2_5_4_BuildNode) bevd_0);
case 841707881: return bem_inlinedSet_1(bevd_0);
case 1003361751: return bem_typeDetailSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 481929786: return bem_buildSet_1(bevd_0);
case 1426248673: return bem_inClassNpSet_1(bevd_0);
case 2076598833: return bem_typenameSet_1(bevd_0);
case 527912399: return bem_condvarSet_1(bevd_0);
case 1668215656: return bem_deleteAndAppend_1((BEC_2_5_4_BuildNode) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1968016520: return bem_heldBySet_1(bevd_0);
case 167727545: return bem_callIsSafe_1((BEC_2_5_4_BuildNode) bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1584180177: return bem_nlcSet_1(bevd_0);
case 1007846464: return bem_prepend_1((BEC_2_5_4_BuildNode) bevd_0);
case 2139839746: return bem_addValue_1((BEC_2_5_4_BuildNode) bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1511075536: return bem_wideStringSet_1(bevd_0);
case 942322015: return bem_heldSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1545079363: return bem_tmpVar_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_BuildNode();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_BuildNode.bevs_inst = (BEC_2_5_4_BuildNode)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_BuildNode.bevs_inst;
}
}
