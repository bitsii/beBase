package be.BEL_4_Base;
/* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject extends be.BELS_Base.BECS_Object {
public BEC_2_6_6_SystemObject() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x69,0x6E,0x20,0x61,0x20,0x63,0x6F,0x6E,0x74,0x65,0x78,0x74,0x20,0x77,0x68,0x65,0x72,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x20,0x77,0x65,0x72,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x76,0x61,0x69,0x6C,0x61,0x62,0x6C,0x65,0x20,0x66,0x72,0x6F,0x6D,0x20,0x74,0x68,0x65,0x20,0x73,0x74,0x61,0x63,0x6B};
private static byte[] bels_1 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64};
private static byte[] bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_2, 8));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_3, 23));
private static byte[] bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_5, 16));
private static byte[] bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x5F};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_8, 1));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(7));
private static byte[] bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_11 = {0x5F};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_11, 1));
public static BEC_2_6_6_SystemObject bevs_inst;
public BEC_2_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_methodNotDefined_0() throws Throwable {
BEC_2_6_11_SystemForwardCall bevl_forwardCall = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_forwardCall = (new BEC_2_6_11_SystemForwardCall()).bem_new_0();
bevt_0_tmpvar_phold = bevl_forwardCall.bem_notReadyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 75 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(86, bels_0));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 76 */
bevt_3_tmpvar_phold = this.bem_methodNotDefined_1(bevl_forwardCall);
return bevt_3_tmpvar_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_methodNotDefined_1(BEC_2_6_11_SystemForwardCall beva_forwardCall) throws Throwable {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_1));
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = this.bem_can_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 82 */ {
bevl_s = this;
bevl_result = bevl_s.bemd_1(2097807671, BEL_4_Base.bevn_forward_1, beva_forwardCall);
return bevl_result;
} /* Line: 86 */
 else  /* Line: 82 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 87 */ {
bevt_8_tmpvar_phold = bevo_0;
bevt_9_tmpvar_phold = beva_forwardCall.bem_nameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_1;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = this.bem_classNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 88 */
} /* Line: 82 */
return bevl_result;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_phold = this.bem_createInstance_2(beva_cname, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_4_3_MathInt bevl_mhash = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_11_SystemInitializer bevt_9_tmpvar_phold = null;
if (beva_cname == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 113 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(18, bels_4));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 114 */
bevl_result = null;

        String key = new String(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int, "UTF-8");
        Class ti = be.BELS_Base.BECS_Runtime.typeInstances.get(key);
        if (ti != null) {
            //System.out.println("Getting new instance for |" + key + "|");
            bevl_result = (BEC_2_6_6_SystemObject) ti.newInstance();
        } 
        //else {
        //    System.out.println("No typeInstance for |" + key + "|");
        //}
        if (bevl_result == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 192 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 193 */ {
bevt_7_tmpvar_phold = bevo_2;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(beva_cname);
bevt_5_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 194 */
 else  /* Line: 195 */ {
return null;
} /* Line: 196 */
} /* Line: 193 */
bevt_9_tmpvar_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_initializeIfShould_1(bevl_result);
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 234 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(23, bels_6));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 235 */
if (beva_args == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 237 */ {
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(32, bels_7));
bevt_4_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 238 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpvar_phold = bevo_3;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();
 /* Line: 247 */ {
bevt_10_tmpvar_phold = bevo_4;
if (bevl_numargs.bevi_int > bevt_10_tmpvar_phold.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 248 */ {
bevt_12_tmpvar_phold = bevo_5;
bevt_11_tmpvar_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpvar_phold);
bevl_args2 = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_tmpvar_phold);
bevl_i = (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 250 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 250 */ {
bevt_15_tmpvar_phold = bevo_6;
bevt_14_tmpvar_phold = bevl_i.bem_subtract_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpvar_phold, bevt_16_tmpvar_phold);
bevl_i.bevi_int++;
} /* Line: 250 */
 else  /* Line: 250 */ {
break;
} /* Line: 250 */
} /* Line: 250 */
} /* Line: 250 */
} /* Line: 248 */

        int ci = be.BELS_Base.BECS_Ids.callIds.get(new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8"));
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(bevl_chash.bevi_int, ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(bevl_chash.bevi_int, ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 376 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 378 */
return bevl_rval;
} /*method end*/
public BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 405 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(18, bels_9));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 406 */
if (beva_numargs == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 408 */ {
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(21, bels_10));
bevt_4_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 409 */
bevt_7_tmpvar_phold = bevo_7;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      String name = "bem_" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      java.lang.reflect.Method[] methods = this.getClass().getMethods();
      for (int i = 0;i < methods.length;i++) {
        if (methods[i].getName().equals(name)) {
            return be.BELS_Base.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 465 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 466 */
if (bevl_rval == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 468 */ {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /* Line: 469 */
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /*method end*/
public final BEC_2_4_6_TextString bem_classNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clname();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      return bevl_xi;
} /*method end*/
public final BEC_2_4_6_TextString bem_sourceFileNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clfile();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      return bevl_xi;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tagGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_print_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_echo_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_echo_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_create_0();
bevt_0_tmpvar_phold = this.bem_copyTo_1(bevt_1_tmpvar_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
if (beva_copy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 689 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 690 */
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpvar_phold);
while (true)
 /* Line: 694 */ {
bevt_3_tmpvar_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 694 */ {
bevt_4_tmpvar_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpvar_phold);
} /* Line: 695 */
 else  /* Line: 694 */ {
break;
} /* Line: 694 */
} /* Line: 694 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_objectIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && this.getClass().equals(beva_other.getClass())) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameClass_1(beva_other);
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && beva_other.getClass().isAssignableFrom(this.getClass())) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameType_1(beva_other);
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_once_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_many_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {35, 35, 46, 46, 57, 57, 68, 68, 73, 75, 76, 76, 76, 78, 78, 82, 82, 82, 84, 85, 86, 87, 88, 88, 88, 88, 88, 88, 88, 88, 88, 90, 94, 94, 94, 113, 113, 114, 114, 114, 116, 192, 192, 194, 194, 194, 194, 196, 199, 199, 199, 234, 234, 235, 235, 235, 237, 237, 238, 238, 238, 240, 241, 241, 241, 241, 242, 248, 248, 248, 249, 249, 249, 250, 250, 250, 251, 251, 251, 251, 250, 376, 378, 380, 405, 405, 406, 406, 406, 408, 408, 409, 409, 409, 411, 411, 411, 411, 412, 465, 466, 468, 468, 469, 469, 471, 471, 505, 527, 559, 559, 591, 591, 602, 628, 639, 665, 669, 669, 669, 673, 673, 677, 677, 681, 681, 685, 685, 685, 689, 689, 690, 692, 692, 693, 693, 694, 695, 695, 701, 701, 707, 713, 713, 717, 717, 721, 721, 725, 725, 748, 795, 795, 799, 799, 799, 854, 854, 858, 858, 858};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {33, 34, 38, 39, 43, 44, 48, 49, 57, 58, 60, 61, 62, 64, 65, 82, 83, 84, 86, 87, 88, 91, 93, 94, 95, 96, 97, 98, 99, 100, 101, 104, 109, 110, 111, 128, 133, 134, 135, 136, 138, 149, 154, 156, 157, 158, 159, 162, 165, 166, 167, 194, 199, 200, 201, 202, 204, 209, 210, 211, 212, 214, 215, 216, 217, 218, 219, 221, 222, 227, 228, 229, 230, 231, 234, 239, 240, 241, 242, 243, 244, 274, 276, 278, 297, 302, 303, 304, 305, 307, 312, 313, 314, 315, 317, 318, 319, 320, 321, 330, 332, 334, 339, 340, 341, 343, 344, 351, 358, 366, 367, 375, 376, 380, 383, 387, 390, 395, 396, 401, 405, 406, 410, 411, 416, 417, 423, 424, 425, 435, 440, 441, 443, 444, 445, 446, 449, 451, 452, 462, 463, 469, 476, 477, 481, 482, 486, 487, 491, 492, 498, 506, 507, 512, 513, 518, 526, 527, 532, 533, 538};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 35 33
new 0 35 33
return 1 35 34
assign 1 46 38
new 0 46 38
return 1 46 39
assign 1 57 43
new 0 57 43
return 1 57 44
assign 1 68 48
new 0 68 48
return 1 68 49
assign 1 73 57
new 0 73 57
assign 1 75 58
notReadyGet 0 75 58
assign 1 76 60
new 0 76 60
assign 1 76 61
new 1 76 61
throw 1 76 62
assign 1 78 64
methodNotDefined 1 78 64
return 1 78 65
assign 1 82 82
new 0 82 82
assign 1 82 83
new 0 82 83
assign 1 82 84
can 2 82 84
assign 1 84 86
assign 1 85 87
forward 1 85 87
return 1 86 88
assign 1 87 91
new 0 87 91
assign 1 88 93
new 0 88 93
assign 1 88 94
nameGet 0 88 94
assign 1 88 95
add 1 88 95
assign 1 88 96
new 0 88 96
assign 1 88 97
add 1 88 97
assign 1 88 98
classNameGet 0 88 98
assign 1 88 99
add 1 88 99
assign 1 88 100
new 1 88 100
throw 1 88 101
return 1 90 104
assign 1 94 109
new 0 94 109
assign 1 94 110
createInstance 2 94 110
return 1 94 111
assign 1 113 128
undef 1 113 133
assign 1 114 134
new 0 114 134
assign 1 114 135
new 1 114 135
throw 1 114 136
assign 1 116 138
assign 1 192 149
undef 1 192 154
assign 1 194 156
new 0 194 156
assign 1 194 157
add 1 194 157
assign 1 194 158
new 1 194 158
throw 1 194 159
return 1 196 162
assign 1 199 165
new 0 199 165
assign 1 199 166
initializeIfShould 1 199 166
return 1 199 167
assign 1 234 194
undef 1 234 199
assign 1 235 200
new 0 235 200
assign 1 235 201
new 1 235 201
throw 1 235 202
assign 1 237 204
undef 1 237 209
assign 1 238 210
new 0 238 210
assign 1 238 211
new 1 238 211
throw 1 238 212
assign 1 240 214
lengthGet 0 240 214
assign 1 241 215
new 0 241 215
assign 1 241 216
add 1 241 216
assign 1 241 217
toString 0 241 217
assign 1 241 218
add 1 241 218
assign 1 242 219
hashGet 0 242 219
assign 1 248 221
new 0 248 221
assign 1 248 222
greater 1 248 227
assign 1 249 228
new 0 249 228
assign 1 249 229
subtract 1 249 229
assign 1 249 230
new 1 249 230
assign 1 250 231
new 0 250 231
assign 1 250 234
lesser 1 250 239
assign 1 251 240
new 0 251 240
assign 1 251 241
subtract 1 251 241
assign 1 251 242
get 1 251 242
put 2 251 243
incrementValue 0 250 244
assign 1 376 274
new 0 376 274
toString 0 378 276
return 1 380 278
assign 1 405 297
undef 1 405 302
assign 1 406 303
new 0 406 303
assign 1 406 304
new 1 406 304
throw 1 406 305
assign 1 408 307
undef 1 408 312
assign 1 409 313
new 0 409 313
assign 1 409 314
new 1 409 314
throw 1 409 315
assign 1 411 317
new 0 411 317
assign 1 411 318
add 1 411 318
assign 1 411 319
toString 0 411 319
assign 1 411 320
add 1 411 320
assign 1 412 321
hashGet 0 412 321
assign 1 465 330
new 0 465 330
toString 0 466 332
assign 1 468 334
def 1 468 339
assign 1 469 340
new 0 469 340
return 1 469 341
assign 1 471 343
new 0 471 343
return 1 471 344
return 1 505 351
return 1 527 358
assign 1 559 366
new 0 559 366
return 1 559 367
assign 1 591 375
new 0 591 375
return 1 591 376
assign 1 602 380
new 0 602 380
return 1 628 383
assign 1 639 387
new 0 639 387
return 1 665 390
assign 1 669 395
equals 1 669 395
assign 1 669 396
not 0 669 401
return 1 669 401
assign 1 673 405
classNameGet 0 673 405
return 1 673 406
assign 1 677 410
toString 0 677 410
print 0 677 411
assign 1 681 416
toString 0 681 416
echo 0 681 417
assign 1 685 423
create 0 685 423
assign 1 685 424
copyTo 1 685 424
return 1 685 425
assign 1 689 435
undef 1 689 440
return 1 690 441
assign 1 692 443
new 0 692 443
assign 1 692 444
new 2 692 444
assign 1 693 445
new 0 693 445
assign 1 693 446
new 2 693 446
assign 1 694 449
hasNextGet 0 694 449
assign 1 695 451
nextGet 0 695 451
nextSet 1 695 452
assign 1 701 462
classNameGet 0 701 462
return 1 701 463
return 1 707 469
assign 1 713 476
new 1 713 476
return 1 713 477
assign 1 717 481
new 1 717 481
return 1 717 482
assign 1 721 486
new 1 721 486
return 1 721 487
assign 1 725 491
new 0 725 491
return 1 725 492
return 1 748 498
assign 1 795 506
new 0 795 506
return 1 795 507
assign 1 799 512
sameClass 1 799 512
assign 1 799 513
not 0 799 518
return 1 799 518
assign 1 854 526
new 0 854 526
return 1 854 527
assign 1 858 532
sameType 1 858 532
assign 1 858 533
not 0 858 538
return 1 858 538
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemObject();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemObject.bevs_inst = becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemObject.bevs_inst;
}
}
