package be.BEL_4_Base;
/* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject extends be.BELS_Base.BECS_Object {
public BEC_2_6_6_SystemObject() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x69,0x6E,0x20,0x61,0x20,0x63,0x6F,0x6E,0x74,0x65,0x78,0x74,0x20,0x77,0x68,0x65,0x72,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x20,0x77,0x65,0x72,0x65,0x20,0x6E,0x6F,0x74,0x20,0x61,0x76,0x61,0x69,0x6C,0x61,0x62,0x6C,0x65,0x20,0x66,0x72,0x6F,0x6D,0x20,0x74,0x68,0x65,0x20,0x73,0x74,0x61,0x63,0x6B};
private static byte[] bels_1 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64};
private static byte[] bels_2 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_2, 8));
private static byte[] bels_3 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_3, 23));
private static byte[] bels_4 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_5 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_5, 16));
private static byte[] bels_6 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_7 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x41,0x72,0x72,0x61,0x79,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x5F};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_8, 1));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(7));
private static byte[] bels_9 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_10 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_11 = {0x5F};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_11, 1));
public static BEC_2_6_6_SystemObject bevs_inst;
public BEC_2_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNotDefined_0() throws Throwable {
BEC_2_6_11_SystemForwardCall bevl_forwardCall = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
bevl_forwardCall = (new BEC_2_6_11_SystemForwardCall()).bem_new_0();
bevt_0_tmpvar_phold = bevl_forwardCall.bem_notReadyGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 76 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(86, bels_0));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 77 */
bevt_3_tmpvar_phold = this.bem_methodNotDefined_1(bevl_forwardCall);
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNotDefined_1(BEC_2_6_11_SystemForwardCall beva_forwardCall) throws Throwable {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_1));
bevt_2_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpvar_phold = this.bem_can_2(bevt_1_tmpvar_phold, bevt_2_tmpvar_phold);
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 83 */ {
bevl_s = this;
bevl_result = bevl_s.bemd_1(2097807671, BEL_4_Base.bevn_forward_1, beva_forwardCall);
return bevl_result;
} /* Line: 87 */
 else  /* Line: 83 */ {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 88 */ {
bevt_8_tmpvar_phold = bevo_0;
bevt_9_tmpvar_phold = beva_forwardCall.bem_nameGet_0();
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = bevo_1;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(bevt_10_tmpvar_phold);
bevt_11_tmpvar_phold = this.bem_classNameGet_0();
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_4_tmpvar_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 89 */
} /* Line: 83 */
return bevl_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_phold = this.bem_createInstance_2(beva_cname, bevt_1_tmpvar_phold);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_4_3_MathInt bevl_mhash = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_11_SystemInitializer bevt_9_tmpvar_phold = null;
if (beva_cname == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 114 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(18, bels_4));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 115 */
bevl_result = null;

        String key = new String(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int, "UTF-8");
        Class ti = be.BELS_Base.BECS_Runtime.typeInstances.get(key);
        if (ti != null) {
            //System.out.println("Getting new instance for |" + key + "|");
            bevl_result = (BEC_2_6_6_SystemObject) ti.newInstance();
        } 
        //else {
        //    System.out.println("No typeInstance for |" + key + "|");
        //}
        if (bevl_result == null) {
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpvar_phold.bevi_bool) /* Line: 193 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 194 */ {
bevt_7_tmpvar_phold = bevo_2;
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bem_add_1(beva_cname);
bevt_5_tmpvar_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_5_tmpvar_phold);
} /* Line: 195 */
 else  /* Line: 196 */ {
return null;
} /* Line: 197 */
} /* Line: 194 */
bevt_9_tmpvar_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_initializeIfShould_1(bevl_result);
return bevt_8_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_5_ContainerArray beva_args) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_5_ContainerArray bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 235 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(23, bels_6));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 236 */
if (beva_args == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 238 */ {
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(33, bels_7));
bevt_4_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 239 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpvar_phold = bevo_3;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();
 /* Line: 248 */ {
bevt_10_tmpvar_phold = bevo_4;
if (bevl_numargs.bevi_int > bevt_10_tmpvar_phold.bevi_int) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 249 */ {
bevt_12_tmpvar_phold = bevo_5;
bevt_11_tmpvar_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpvar_phold);
bevl_args2 = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_11_tmpvar_phold);
bevl_i = (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 251 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpvar_phold.bevi_bool) /* Line: 251 */ {
bevt_15_tmpvar_phold = bevo_6;
bevt_14_tmpvar_phold = bevl_i.bem_subtract_1(bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpvar_phold, bevt_16_tmpvar_phold);
bevl_i.bevi_int++;
} /* Line: 251 */
 else  /* Line: 251 */ {
break;
} /* Line: 251 */
} /* Line: 251 */
} /* Line: 251 */
} /* Line: 249 */

        int ci = be.BELS_Base.BECS_Ids.callIds.get(new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8"));
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(bevl_chash.bevi_int, ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(bevl_chash.bevi_int, ci, beva_args.bevi_array[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5], beva_args.bevi_array[6]);
        } else {
            bevl_rval = bemd_x(bevl_chash.bevi_int, ci, beva_args.bevi_array[0], beva_args.bevi_array[1], beva_args.bevi_array[2], beva_args.bevi_array[3], beva_args.bevi_array[4], beva_args.bevi_array[5], beva_args.bevi_array[6], bevl_args2.bevi_array);
        }
        bevt_17_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_17_tmpvar_phold.bevi_bool) /* Line: 377 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 379 */
return bevl_rval;
} /*method end*/
public BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpvar_phold = null;
if (beva_name == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 406 */ {
bevt_2_tmpvar_phold = (new BEC_2_4_6_TextString(18, bels_9));
bevt_1_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_1_tmpvar_phold);
} /* Line: 407 */
if (beva_numargs == null) {
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 409 */ {
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(21, bels_10));
bevt_4_tmpvar_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 410 */
bevt_7_tmpvar_phold = bevo_7;
bevt_6_tmpvar_phold = beva_name.bem_add_1(bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpvar_phold.bem_add_1(bevt_8_tmpvar_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      String name = "bem_" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      java.lang.reflect.Method[] methods = this.getClass().getMethods();
      for (int i = 0;i < methods.length;i++) {
        if (methods[i].getName().equals(name)) {
            return be.BELS_Base.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 466 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 467 */
if (bevl_rval == null) {
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 469 */ {
bevt_11_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_11_tmpvar_phold;
} /* Line: 470 */
bevt_12_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_12_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clname();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      return bevl_xi;
} /*method end*/
public BEC_2_4_6_TextString bem_sourceFileNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clfile();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      return bevl_xi;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (this != beva_x) {
        return be.BELS_Base.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_tagGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_tagGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_equals_1(beva_x);
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_print_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_echo_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_toString_0();
bevt_0_tmpvar_phold.bem_echo_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_create_0();
bevt_0_tmpvar_phold = this.bem_copyTo_1(bevt_1_tmpvar_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
if (beva_copy == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 657 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 658 */
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpvar_phold);
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpvar_phold);
while (true)
 /* Line: 662 */ {
bevt_3_tmpvar_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpvar_phold.bevi_bool) /* Line: 662 */ {
bevt_4_tmpvar_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpvar_phold);
} /* Line: 663 */
 else  /* Line: 662 */ {
break;
} /* Line: 662 */
} /* Line: 662 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = this.bem_classNameGet_0();
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_objectIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && this.getClass().equals(beva_other.getClass())) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameClass_1(beva_other);
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;

      if (beva_other != null && beva_other.getClass().isAssignableFrom(this.getClass())) {
        return be.BELS_Base.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
bevt_1_tmpvar_phold = this.bem_sameType_1(beva_other);
if (bevt_1_tmpvar_phold.bevi_bool) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_once_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_many_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {36, 36, 47, 47, 58, 58, 69, 69, 74, 76, 77, 77, 77, 79, 79, 83, 83, 83, 85, 86, 87, 88, 89, 89, 89, 89, 89, 89, 89, 89, 89, 91, 95, 95, 95, 114, 114, 115, 115, 115, 117, 193, 193, 195, 195, 195, 195, 197, 200, 200, 200, 235, 235, 236, 236, 236, 238, 238, 239, 239, 239, 241, 242, 242, 242, 242, 243, 249, 249, 249, 250, 250, 250, 251, 251, 251, 252, 252, 252, 252, 251, 377, 379, 381, 406, 406, 407, 407, 407, 409, 409, 410, 410, 410, 412, 412, 412, 412, 413, 466, 467, 469, 469, 470, 470, 472, 472, 506, 528, 560, 560, 592, 592, 603, 629, 633, 633, 637, 637, 637, 641, 641, 645, 645, 649, 649, 653, 653, 653, 657, 657, 658, 660, 660, 661, 661, 662, 663, 663, 669, 669, 675, 681, 681, 685, 685, 689, 689, 693, 693, 716, 763, 763, 767, 767, 767, 822, 822, 826, 826, 826};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {33, 34, 38, 39, 43, 44, 48, 49, 57, 58, 60, 61, 62, 64, 65, 82, 83, 84, 86, 87, 88, 91, 93, 94, 95, 96, 97, 98, 99, 100, 101, 104, 109, 110, 111, 128, 133, 134, 135, 136, 138, 149, 154, 156, 157, 158, 159, 162, 165, 166, 167, 194, 199, 200, 201, 202, 204, 209, 210, 211, 212, 214, 215, 216, 217, 218, 219, 221, 222, 227, 228, 229, 230, 231, 234, 239, 240, 241, 242, 243, 244, 274, 276, 278, 297, 302, 303, 304, 305, 307, 312, 313, 314, 315, 317, 318, 319, 320, 321, 330, 332, 334, 339, 340, 341, 343, 344, 351, 358, 366, 367, 375, 376, 380, 383, 387, 388, 393, 394, 399, 403, 404, 408, 409, 414, 415, 421, 422, 423, 433, 438, 439, 441, 442, 443, 444, 447, 449, 450, 460, 461, 467, 474, 475, 479, 480, 484, 485, 489, 490, 496, 504, 505, 510, 511, 516, 524, 525, 530, 531, 536};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 36 33
new 0 36 33
return 1 36 34
assign 1 47 38
new 0 47 38
return 1 47 39
assign 1 58 43
new 0 58 43
return 1 58 44
assign 1 69 48
new 0 69 48
return 1 69 49
assign 1 74 57
new 0 74 57
assign 1 76 58
notReadyGet 0 76 58
assign 1 77 60
new 0 77 60
assign 1 77 61
new 1 77 61
throw 1 77 62
assign 1 79 64
methodNotDefined 1 79 64
return 1 79 65
assign 1 83 82
new 0 83 82
assign 1 83 83
new 0 83 83
assign 1 83 84
can 2 83 84
assign 1 85 86
assign 1 86 87
forward 1 86 87
return 1 87 88
assign 1 88 91
new 0 88 91
assign 1 89 93
new 0 89 93
assign 1 89 94
nameGet 0 89 94
assign 1 89 95
add 1 89 95
assign 1 89 96
new 0 89 96
assign 1 89 97
add 1 89 97
assign 1 89 98
classNameGet 0 89 98
assign 1 89 99
add 1 89 99
assign 1 89 100
new 1 89 100
throw 1 89 101
return 1 91 104
assign 1 95 109
new 0 95 109
assign 1 95 110
createInstance 2 95 110
return 1 95 111
assign 1 114 128
undef 1 114 133
assign 1 115 134
new 0 115 134
assign 1 115 135
new 1 115 135
throw 1 115 136
assign 1 117 138
assign 1 193 149
undef 1 193 154
assign 1 195 156
new 0 195 156
assign 1 195 157
add 1 195 157
assign 1 195 158
new 1 195 158
throw 1 195 159
return 1 197 162
assign 1 200 165
new 0 200 165
assign 1 200 166
initializeIfShould 1 200 166
return 1 200 167
assign 1 235 194
undef 1 235 199
assign 1 236 200
new 0 236 200
assign 1 236 201
new 1 236 201
throw 1 236 202
assign 1 238 204
undef 1 238 209
assign 1 239 210
new 0 239 210
assign 1 239 211
new 1 239 211
throw 1 239 212
assign 1 241 214
lengthGet 0 241 214
assign 1 242 215
new 0 242 215
assign 1 242 216
add 1 242 216
assign 1 242 217
toString 0 242 217
assign 1 242 218
add 1 242 218
assign 1 243 219
hashGet 0 243 219
assign 1 249 221
new 0 249 221
assign 1 249 222
greater 1 249 227
assign 1 250 228
new 0 250 228
assign 1 250 229
subtract 1 250 229
assign 1 250 230
new 1 250 230
assign 1 251 231
new 0 251 231
assign 1 251 234
lesser 1 251 239
assign 1 252 240
new 0 252 240
assign 1 252 241
subtract 1 252 241
assign 1 252 242
get 1 252 242
put 2 252 243
incrementValue 0 251 244
assign 1 377 274
new 0 377 274
toString 0 379 276
return 1 381 278
assign 1 406 297
undef 1 406 302
assign 1 407 303
new 0 407 303
assign 1 407 304
new 1 407 304
throw 1 407 305
assign 1 409 307
undef 1 409 312
assign 1 410 313
new 0 410 313
assign 1 410 314
new 1 410 314
throw 1 410 315
assign 1 412 317
new 0 412 317
assign 1 412 318
add 1 412 318
assign 1 412 319
toString 0 412 319
assign 1 412 320
add 1 412 320
assign 1 413 321
hashGet 0 413 321
assign 1 466 330
new 0 466 330
toString 0 467 332
assign 1 469 334
def 1 469 339
assign 1 470 340
new 0 470 340
return 1 470 341
assign 1 472 343
new 0 472 343
return 1 472 344
return 1 506 351
return 1 528 358
assign 1 560 366
new 0 560 366
return 1 560 367
assign 1 592 375
new 0 592 375
return 1 592 376
assign 1 603 380
new 0 603 380
return 1 629 383
assign 1 633 387
tagGet 0 633 387
return 1 633 388
assign 1 637 393
equals 1 637 393
assign 1 637 394
not 0 637 399
return 1 637 399
assign 1 641 403
classNameGet 0 641 403
return 1 641 404
assign 1 645 408
toString 0 645 408
print 0 645 409
assign 1 649 414
toString 0 649 414
echo 0 649 415
assign 1 653 421
create 0 653 421
assign 1 653 422
copyTo 1 653 422
return 1 653 423
assign 1 657 433
undef 1 657 438
return 1 658 439
assign 1 660 441
new 0 660 441
assign 1 660 442
new 2 660 442
assign 1 661 443
new 0 661 443
assign 1 661 444
new 2 661 444
assign 1 662 447
hasNextGet 0 662 447
assign 1 663 449
nextGet 0 663 449
nextSet 1 663 450
assign 1 669 460
classNameGet 0 669 460
return 1 669 461
return 1 675 467
assign 1 681 474
new 1 681 474
return 1 681 475
assign 1 685 479
new 1 685 479
return 1 685 480
assign 1 689 484
new 1 689 484
return 1 689 485
assign 1 693 489
new 0 693 489
return 1 693 490
return 1 716 496
assign 1 763 504
new 0 763 504
return 1 763 505
assign 1 767 510
sameClass 1 767 510
assign 1 767 511
not 0 767 516
return 1 767 516
assign 1 822 524
new 0 822 524
return 1 822 525
assign 1 826 530
sameType 1 826 530
assign 1 826 531
not 0 826 536
return 1 826 536
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 786424307: return bem_tagGet_0();
case 1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1081412016: return bem_many_0();
case 845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case 729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 1102720804: return bem_classNameGet_0();
case 1012494862: return bem_once_0();
case 314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case 1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemObject();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemObject.bevs_inst = becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemObject.bevs_inst;
}
}
