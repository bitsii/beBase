package be.BEL_4_Base;
/* IO:File: source/extended/Json.be */
public class BEC_4_10_JsonMarshaller extends BEC_6_6_SystemObject {
public BEC_4_10_JsonMarshaller() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x4D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_4_3_MathInt bevo_0 = (new BEC_4_3_MathInt(2));
private static byte[] bels_1 = {0x31,0x46};
private static BEC_4_3_MathInt bevo_1 = (new BEC_4_3_MathInt(3));
private static byte[] bels_2 = {0x46};
private static BEC_4_3_MathInt bevo_2 = (new BEC_4_3_MathInt(4));
private static byte[] bels_3 = {0x37};
private static BEC_4_3_MathInt bevo_3 = (new BEC_4_3_MathInt(1));
private static byte[] bels_4 = {0x33,0x46};
private static BEC_4_3_MathInt bevo_4 = (new BEC_4_3_MathInt(0));
private static BEC_4_3_MathInt bevo_5 = (new BEC_4_3_MathInt(1));
private static byte[] bels_5 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_4_3_MathInt bevo_6 = (new BEC_4_3_MathInt(2));
private static BEC_4_3_MathInt bevo_7 = (new BEC_4_3_MathInt(3));
private static BEC_4_3_MathInt bevo_8 = (new BEC_4_3_MathInt(7));
private static byte[] bels_6 = {0x5C,0x75};
private static BEC_4_3_MathInt bevo_9 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_10 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_11 = (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_12 = (new BEC_4_3_MathInt(87));
private static BEC_4_3_MathInt bevo_13 = (new BEC_4_3_MathInt(13));
private static byte[] bels_7 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bels_8 = {0x44,0x38,0x30,0x30};
private static byte[] bels_9 = {0x66,0x66,0x63,0x30,0x30};
private static byte[] bels_10 = {0x44,0x43,0x30,0x30};
private static byte[] bels_11 = {0x30,0x30,0x33,0x66,0x66};
private static byte[] bels_12 = {0x5C,0x75};
private static BEC_4_3_MathInt bevo_14 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_15 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_16 = (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_17 = (new BEC_4_3_MathInt(87));
private static byte[] bels_13 = {0x5C,0x75};
private static BEC_4_3_MathInt bevo_18 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_19 = (new BEC_4_3_MathInt(4));
private static BEC_4_3_MathInt bevo_20 = (new BEC_4_3_MathInt(16));
private static BEC_4_3_MathInt bevo_21 = (new BEC_4_3_MathInt(87));
private static byte[] bels_14 = {0x5B};
private static byte[] bels_15 = {0x2C};
private static byte[] bels_16 = {0x5D};
private static byte[] bels_17 = {0x7B};
private static byte[] bels_18 = {0x2C};
private static byte[] bels_19 = {0x3A};
private static byte[] bels_20 = {0x7D};
public static BEC_4_10_JsonMarshaller bevs_inst;
public BEC_4_6_TextString bevp_str;
public BEC_9_10_ContainerLinkedList bevp_lls;
public BEC_9_5_ContainerArray bevp_arr;
public BEC_9_3_ContainerMap bevp_map;
public BEC_4_3_MathInt bevp_int;
public BEC_5_4_LogicBool bevp_boo;
public BEC_4_6_TextString bevp_q;
public BEC_4_17_TextMultiByteIterator bevp_mbi;
public BEC_4_6_TextString bevp_txtpt;
public BEC_4_6_TextString bevp_escaped;
public BEC_4_10_JsonMarshaller bem_new_0() throws Throwable {
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_7_TextStrings bevt_1_tmpvar_phold = null;
bevp_str = (new BEC_4_6_TextString()).bem_new_0();
bevp_lls = (new BEC_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(1));
bevp_arr = (new BEC_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
bevp_map = (new BEC_9_3_ContainerMap()).bem_new_0();
bevp_int = (new BEC_4_3_MathInt()).bem_new_0();
bevp_boo = (new BEC_5_4_LogicBool()).bem_new_0();
bevt_1_tmpvar_phold = (BEC_4_7_TextStrings) BEC_4_7_TextStrings.bevs_inst;
bevp_q = bevt_1_tmpvar_phold.bem_quoteGet_0();
bevp_mbi = (BEC_4_17_TextMultiByteIterator) (new BEC_4_17_TextMultiByteIterator()).bem_new_0();
bevp_txtpt = (new BEC_4_6_TextString()).bem_new_0();
bevp_escaped = (new BEC_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public BEC_4_6_TextString bem_marshall_1(BEC_6_6_SystemObject beva_inst) throws Throwable {
BEC_4_6_TextString bevl_bb = null;
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
if (bevp_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 314 */ {
this.bem_new_0();
} /* Line: 315 */
bevl_bb = (new BEC_4_6_TextString()).bem_new_0();
this.bem_marshallWriteInst_2(beva_inst, bevl_bb);
bevt_1_tmpvar_phold = bevl_bb.bem_toString_0();
return bevt_1_tmpvar_phold;
} /*method end*/
public BEC_6_6_SystemObject bem_marshallWrite_2(BEC_6_6_SystemObject beva_inst, BEC_6_6_SystemObject beva_writer) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
if (bevp_str == null) {
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 323 */ {
this.bem_new_0();
} /* Line: 324 */
this.bem_marshallWriteInst_2(beva_inst, beva_writer);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_marshallWriteInst_2(BEC_6_6_SystemObject beva_inst, BEC_6_6_SystemObject beva_writer) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_4_6_TextString bevt_2_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_11_tmpvar_phold = null;
if (beva_inst == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 330 */ {
bevt_2_tmpvar_phold = (new BEC_4_6_TextString(4, bels_0));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_2_tmpvar_phold);
} /* Line: 331 */
 else  /* Line: 330 */ {
bevt_3_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_str);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 332 */ {
this.bem_marshallWriteString_2((BEC_4_6_TextString) beva_inst, beva_writer);
} /* Line: 333 */
 else  /* Line: 330 */ {
bevt_4_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_lls);
if (bevt_4_tmpvar_phold != null && bevt_4_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_4_tmpvar_phold).bevi_bool) /* Line: 334 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_5_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_arr);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 334 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 334 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 334 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 334 */ {
this.bem_marshallWriteList_2(beva_inst, beva_writer);
} /* Line: 335 */
 else  /* Line: 330 */ {
bevt_6_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_map);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 336 */ {
this.bem_marshallWriteMap_2(beva_inst, beva_writer);
} /* Line: 337 */
 else  /* Line: 330 */ {
bevt_7_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_int);
if (bevt_7_tmpvar_phold != null && bevt_7_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_7_tmpvar_phold).bevi_bool) /* Line: 338 */ {
bevt_8_tmpvar_phold = beva_inst.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_8_tmpvar_phold);
} /* Line: 339 */
 else  /* Line: 330 */ {
bevt_9_tmpvar_phold = beva_inst.bemd_1(1697252238, BEL_4_Base.bevn_sameType_1, bevp_boo);
if (bevt_9_tmpvar_phold != null && bevt_9_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_9_tmpvar_phold).bevi_bool) /* Line: 340 */ {
bevt_10_tmpvar_phold = beva_inst.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_10_tmpvar_phold);
} /* Line: 341 */
 else  /* Line: 342 */ {
bevt_11_tmpvar_phold = beva_inst.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
this.bem_marshallWriteString_2((BEC_4_6_TextString) bevt_11_tmpvar_phold, beva_writer);
} /* Line: 343 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_jsonEscapePoint_2(BEC_4_6_TextString beva_txtpt, BEC_4_6_TextString beva_txt) throws Throwable {
BEC_4_3_MathInt bevl_rcap = null;
BEC_4_3_MathInt bevl_txtsznow = null;
BEC_4_3_MathInt bevl_size = null;
BEC_4_3_MathInt bevl_value = null;
BEC_4_3_MathInt bevl_u = null;
BEC_4_3_MathInt bevl_i = null;
BEC_4_7_JsonEscapes bevl_esc = null;
BEC_4_6_TextString bevl_escval = null;
BEC_4_3_MathInt bevl_first = null;
BEC_4_3_MathInt bevl_last = null;
BEC_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_4_3_MathInt bevt_1_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_4_3_MathInt bevt_7_tmpvar_phold = null;
BEC_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_10_tmpvar_phold = null;
BEC_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_4_3_MathInt bevt_15_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_4_3_MathInt bevt_17_tmpvar_phold = null;
BEC_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_4_3_MathInt bevt_19_tmpvar_phold = null;
BEC_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_4_3_MathInt bevt_23_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_24_tmpvar_phold = null;
BEC_4_3_MathInt bevt_25_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_4_3_MathInt bevt_27_tmpvar_phold = null;
BEC_4_6_TextString bevt_28_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_4_3_MathInt bevt_30_tmpvar_phold = null;
BEC_4_3_MathInt bevt_31_tmpvar_phold = null;
BEC_4_3_MathInt bevt_32_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_33_tmpvar_phold = null;
BEC_4_3_MathInt bevt_34_tmpvar_phold = null;
BEC_9_3_ContainerMap bevt_35_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_4_3_MathInt bevt_38_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_39_tmpvar_phold = null;
BEC_4_3_MathInt bevt_40_tmpvar_phold = null;
BEC_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_4_6_TextString bevt_43_tmpvar_phold = null;
BEC_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_4_3_MathInt bevt_45_tmpvar_phold = null;
BEC_4_3_MathInt bevt_46_tmpvar_phold = null;
BEC_4_3_MathInt bevt_47_tmpvar_phold = null;
BEC_4_3_MathInt bevt_48_tmpvar_phold = null;
BEC_4_3_MathInt bevt_49_tmpvar_phold = null;
BEC_4_3_MathInt bevt_50_tmpvar_phold = null;
BEC_4_3_MathInt bevt_51_tmpvar_phold = null;
BEC_4_3_MathInt bevt_52_tmpvar_phold = null;
BEC_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_4_3_MathInt bevt_54_tmpvar_phold = null;
BEC_4_3_MathInt bevt_55_tmpvar_phold = null;
BEC_4_6_TextString bevt_56_tmpvar_phold = null;
BEC_4_3_MathInt bevt_57_tmpvar_phold = null;
BEC_4_6_TextString bevt_58_tmpvar_phold = null;
BEC_4_3_MathInt bevt_59_tmpvar_phold = null;
BEC_4_3_MathInt bevt_60_tmpvar_phold = null;
BEC_4_3_MathInt bevt_61_tmpvar_phold = null;
BEC_4_6_TextString bevt_62_tmpvar_phold = null;
BEC_4_3_MathInt bevt_63_tmpvar_phold = null;
BEC_4_3_MathInt bevt_64_tmpvar_phold = null;
BEC_4_6_TextString bevt_65_tmpvar_phold = null;
BEC_4_3_MathInt bevt_66_tmpvar_phold = null;
BEC_4_3_MathInt bevt_67_tmpvar_phold = null;
BEC_4_6_TextString bevt_68_tmpvar_phold = null;
BEC_4_6_TextString bevt_69_tmpvar_phold = null;
BEC_4_6_TextString bevt_70_tmpvar_phold = null;
BEC_4_6_TextString bevt_71_tmpvar_phold = null;
BEC_4_6_TextString bevt_72_tmpvar_phold = null;
BEC_4_3_MathInt bevt_73_tmpvar_phold = null;
BEC_4_3_MathInt bevt_74_tmpvar_phold = null;
BEC_4_3_MathInt bevt_75_tmpvar_phold = null;
BEC_4_3_MathInt bevt_76_tmpvar_phold = null;
BEC_4_3_MathInt bevt_77_tmpvar_phold = null;
BEC_4_3_MathInt bevt_78_tmpvar_phold = null;
BEC_4_3_MathInt bevt_79_tmpvar_phold = null;
BEC_4_3_MathInt bevt_80_tmpvar_phold = null;
BEC_4_6_TextString bevt_81_tmpvar_phold = null;
BEC_4_6_TextString bevt_82_tmpvar_phold = null;
BEC_4_6_TextString bevt_83_tmpvar_phold = null;
BEC_4_6_TextString bevt_84_tmpvar_phold = null;
BEC_4_3_MathInt bevt_85_tmpvar_phold = null;
BEC_4_3_MathInt bevt_86_tmpvar_phold = null;
BEC_4_3_MathInt bevt_87_tmpvar_phold = null;
BEC_4_3_MathInt bevt_88_tmpvar_phold = null;
BEC_4_3_MathInt bevt_89_tmpvar_phold = null;
BEC_4_3_MathInt bevt_90_tmpvar_phold = null;
BEC_4_3_MathInt bevt_91_tmpvar_phold = null;
BEC_4_3_MathInt bevt_92_tmpvar_phold = null;
bevl_rcap = (new BEC_4_3_MathInt()).bem_new_0();
bevl_txtsznow = beva_txt.bem_sizeGet_0();
bevl_size = beva_txtpt.bem_sizeGet_0();
bevt_0_tmpvar_phold = (new BEC_4_3_MathInt(0));
bevt_1_tmpvar_phold = (new BEC_4_3_MathInt()).bem_new_0();
bevl_u = beva_txtpt.bem_getInt_2(bevt_0_tmpvar_phold, bevt_1_tmpvar_phold);
bevt_3_tmpvar_phold = bevo_0;
bevt_2_tmpvar_phold = bevl_size.bem_equals_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 356 */ {
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(2, bels_1));
bevt_4_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_5_tmpvar_phold);
bevl_value = bevl_u.bem_and_1(bevt_4_tmpvar_phold);
} /* Line: 357 */
 else  /* Line: 355 */ {
bevt_7_tmpvar_phold = bevo_1;
bevt_6_tmpvar_phold = bevl_size.bem_equals_1(bevt_7_tmpvar_phold);
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 360 */ {
bevt_9_tmpvar_phold = (new BEC_4_6_TextString(1, bels_2));
bevt_8_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_9_tmpvar_phold);
bevl_value = bevl_u.bem_and_1(bevt_8_tmpvar_phold);
} /* Line: 361 */
 else  /* Line: 355 */ {
bevt_11_tmpvar_phold = bevo_2;
bevt_10_tmpvar_phold = bevl_size.bem_equals_1(bevt_11_tmpvar_phold);
if (bevt_10_tmpvar_phold.bevi_bool) /* Line: 364 */ {
bevt_13_tmpvar_phold = (new BEC_4_6_TextString(1, bels_3));
bevt_12_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_13_tmpvar_phold);
bevl_value = bevl_u.bem_and_1(bevt_12_tmpvar_phold);
} /* Line: 365 */
} /* Line: 355 */
} /* Line: 355 */
bevt_15_tmpvar_phold = bevo_3;
bevt_14_tmpvar_phold = bevl_size.bem_greater_1(bevt_15_tmpvar_phold);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 367 */ {
bevl_i = (new BEC_4_3_MathInt(1));
while (true)
 /* Line: 368 */ {
bevt_16_tmpvar_phold = bevl_i.bem_lesser_1(bevl_size);
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 369 */ {
beva_txtpt.bem_getInt_2(bevl_i, bevl_u);
bevt_18_tmpvar_phold = (new BEC_4_3_MathInt(6));
bevt_17_tmpvar_phold = bevl_value.bem_shiftLeft_1(bevt_18_tmpvar_phold);
bevt_21_tmpvar_phold = (new BEC_4_6_TextString(2, bels_4));
bevt_20_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_21_tmpvar_phold);
bevt_19_tmpvar_phold = bevl_u.bem_and_1(bevt_20_tmpvar_phold);
bevl_value = bevt_17_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevl_i.bem_incrementValue_0();
} /* Line: 368 */
 else  /* Line: 368 */ {
break;
} /* Line: 368 */
} /* Line: 368 */
} /* Line: 368 */
bevt_23_tmpvar_phold = bevo_4;
bevt_22_tmpvar_phold = bevl_size.bem_equals_1(bevt_23_tmpvar_phold);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 375 */ {
bevl_rcap = (new BEC_4_3_MathInt(0));
} /* Line: 376 */
 else  /* Line: 375 */ {
bevt_25_tmpvar_phold = bevo_5;
bevt_24_tmpvar_phold = bevl_size.bem_equals_1(bevt_25_tmpvar_phold);
if (bevt_24_tmpvar_phold.bevi_bool) /* Line: 377 */ {
bevl_rcap = (new BEC_4_3_MathInt(2));
} /* Line: 378 */
 else  /* Line: 379 */ {
bevt_28_tmpvar_phold = (new BEC_4_6_TextString(5, bels_5));
bevt_27_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_28_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_value.bem_lesser_1(bevt_27_tmpvar_phold);
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevl_rcap = (new BEC_4_3_MathInt(7));
} /* Line: 381 */
 else  /* Line: 382 */ {
bevl_rcap = (new BEC_4_3_MathInt(13));
} /* Line: 383 */
} /* Line: 380 */
} /* Line: 375 */
bevt_31_tmpvar_phold = beva_txt.bem_capacityGet_0();
bevt_30_tmpvar_phold = bevt_31_tmpvar_phold.bem_subtract_1(bevl_txtsznow);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bem_lesser_1(bevl_rcap);
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 387 */ {
bevt_32_tmpvar_phold = bevl_txtsznow.bem_add_1(bevl_rcap);
beva_txt.bem_capacitySet_1(bevt_32_tmpvar_phold);
} /* Line: 388 */
bevt_34_tmpvar_phold = bevo_6;
bevt_33_tmpvar_phold = bevl_rcap.bem_equals_1(bevt_34_tmpvar_phold);
if (bevt_33_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevl_esc = (BEC_4_7_JsonEscapes) BEC_4_7_JsonEscapes.bevs_inst;
bevt_35_tmpvar_phold = bevl_esc.bem_toEscapesGet_0();
bevl_escval = (BEC_4_6_TextString) bevt_35_tmpvar_phold.bem_get_1(beva_txtpt);
if (bevl_escval == null) {
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 395 */ {
beva_txt.bem_addValue_1(bevl_escval);
} /* Line: 396 */
 else  /* Line: 397 */ {
beva_txt.bem_addValue_1(beva_txtpt);
} /* Line: 399 */
} /* Line: 395 */
 else  /* Line: 391 */ {
bevt_38_tmpvar_phold = bevo_7;
bevt_37_tmpvar_phold = bevl_rcap.bem_greater_1(bevt_38_tmpvar_phold);
if (bevt_37_tmpvar_phold.bevi_bool) /* Line: 401 */ {
bevt_40_tmpvar_phold = bevo_8;
bevt_39_tmpvar_phold = bevl_rcap.bem_equals_1(bevt_40_tmpvar_phold);
if (bevt_39_tmpvar_phold.bevi_bool) /* Line: 402 */ {
bevt_42_tmpvar_phold = (new BEC_4_6_TextString(2, bels_6));
bevt_41_tmpvar_phold = beva_txt.bem_addValue_1(bevt_42_tmpvar_phold);
bevt_46_tmpvar_phold = bevo_9;
bevt_45_tmpvar_phold = (BEC_4_3_MathInt) bevt_46_tmpvar_phold.bem_once_0();
bevt_44_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(bevt_45_tmpvar_phold);
bevt_48_tmpvar_phold = bevo_10;
bevt_47_tmpvar_phold = (BEC_4_3_MathInt) bevt_48_tmpvar_phold.bem_once_0();
bevt_50_tmpvar_phold = bevo_11;
bevt_49_tmpvar_phold = (BEC_4_3_MathInt) bevt_50_tmpvar_phold.bem_once_0();
bevt_52_tmpvar_phold = bevo_12;
bevt_51_tmpvar_phold = (BEC_4_3_MathInt) bevt_52_tmpvar_phold.bem_once_0();
bevt_43_tmpvar_phold = bevl_value.bem_toString_4(bevt_44_tmpvar_phold, bevt_47_tmpvar_phold, bevt_49_tmpvar_phold, bevt_51_tmpvar_phold);
bevt_41_tmpvar_phold.bem_addValue_1(bevt_43_tmpvar_phold);
} /* Line: 403 */
 else  /* Line: 402 */ {
bevt_54_tmpvar_phold = bevo_13;
bevt_53_tmpvar_phold = bevl_rcap.bem_equals_1(bevt_54_tmpvar_phold);
if (bevt_53_tmpvar_phold.bevi_bool) /* Line: 404 */ {
bevt_56_tmpvar_phold = (new BEC_4_6_TextString(5, bels_7));
bevt_55_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_56_tmpvar_phold);
bevl_value.bem_subtractValue_1(bevt_55_tmpvar_phold);
bevt_58_tmpvar_phold = (new BEC_4_6_TextString(4, bels_8));
bevt_57_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_58_tmpvar_phold);
bevt_62_tmpvar_phold = (new BEC_4_6_TextString(5, bels_9));
bevt_61_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_62_tmpvar_phold);
bevt_60_tmpvar_phold = bevl_value.bem_and_1(bevt_61_tmpvar_phold);
bevt_63_tmpvar_phold = (new BEC_4_3_MathInt(10));
bevt_59_tmpvar_phold = bevt_60_tmpvar_phold.bem_shiftRight_1(bevt_63_tmpvar_phold);
bevl_first = bevt_57_tmpvar_phold.bem_or_1(bevt_59_tmpvar_phold);
bevt_65_tmpvar_phold = (new BEC_4_6_TextString(4, bels_10));
bevt_64_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_65_tmpvar_phold);
bevt_68_tmpvar_phold = (new BEC_4_6_TextString(5, bels_11));
bevt_67_tmpvar_phold = (new BEC_4_3_MathInt()).bem_hexNew_1(bevt_68_tmpvar_phold);
bevt_66_tmpvar_phold = bevl_value.bem_and_1(bevt_67_tmpvar_phold);
bevl_last = bevt_64_tmpvar_phold.bem_or_1(bevt_66_tmpvar_phold);
bevt_70_tmpvar_phold = (new BEC_4_6_TextString(2, bels_12));
bevt_69_tmpvar_phold = beva_txt.bem_addValue_1(bevt_70_tmpvar_phold);
bevt_74_tmpvar_phold = bevo_14;
bevt_73_tmpvar_phold = (BEC_4_3_MathInt) bevt_74_tmpvar_phold.bem_once_0();
bevt_72_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(bevt_73_tmpvar_phold);
bevt_76_tmpvar_phold = bevo_15;
bevt_75_tmpvar_phold = (BEC_4_3_MathInt) bevt_76_tmpvar_phold.bem_once_0();
bevt_78_tmpvar_phold = bevo_16;
bevt_77_tmpvar_phold = (BEC_4_3_MathInt) bevt_78_tmpvar_phold.bem_once_0();
bevt_80_tmpvar_phold = bevo_17;
bevt_79_tmpvar_phold = (BEC_4_3_MathInt) bevt_80_tmpvar_phold.bem_once_0();
bevt_71_tmpvar_phold = bevl_first.bem_toString_4(bevt_72_tmpvar_phold, bevt_75_tmpvar_phold, bevt_77_tmpvar_phold, bevt_79_tmpvar_phold);
bevt_69_tmpvar_phold.bem_addValue_1(bevt_71_tmpvar_phold);
bevt_82_tmpvar_phold = (new BEC_4_6_TextString(2, bels_13));
bevt_81_tmpvar_phold = beva_txt.bem_addValue_1(bevt_82_tmpvar_phold);
bevt_86_tmpvar_phold = bevo_18;
bevt_85_tmpvar_phold = (BEC_4_3_MathInt) bevt_86_tmpvar_phold.bem_once_0();
bevt_84_tmpvar_phold = (new BEC_4_6_TextString()).bem_new_1(bevt_85_tmpvar_phold);
bevt_88_tmpvar_phold = bevo_19;
bevt_87_tmpvar_phold = (BEC_4_3_MathInt) bevt_88_tmpvar_phold.bem_once_0();
bevt_90_tmpvar_phold = bevo_20;
bevt_89_tmpvar_phold = (BEC_4_3_MathInt) bevt_90_tmpvar_phold.bem_once_0();
bevt_92_tmpvar_phold = bevo_21;
bevt_91_tmpvar_phold = (BEC_4_3_MathInt) bevt_92_tmpvar_phold.bem_once_0();
bevt_83_tmpvar_phold = bevl_last.bem_toString_4(bevt_84_tmpvar_phold, bevt_87_tmpvar_phold, bevt_89_tmpvar_phold, bevt_91_tmpvar_phold);
bevt_81_tmpvar_phold.bem_addValue_1(bevt_83_tmpvar_phold);
} /* Line: 409 */
} /* Line: 402 */
} /* Line: 402 */
} /* Line: 391 */
return this;
} /*method end*/
public BEC_4_6_TextString bem_jsonEscape_1(BEC_6_6_SystemObject beva_toEscape) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_4_17_TextMultiByteIterator bevt_1_tmpvar_phold = null;
bevp_escaped.bem_clear_0();
bevt_1_tmpvar_phold = bevp_mbi.bem_new_1((BEC_4_6_TextString) beva_toEscape);
bevt_0_tmpvar_phold = this.bem_jsonEscape_3(bevt_1_tmpvar_phold, bevp_txtpt, bevp_escaped);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_4_6_TextString bem_jsonEscape_3(BEC_4_17_TextMultiByteIterator beva_mbi, BEC_4_6_TextString beva_txtpt, BEC_4_6_TextString beva_escaped) throws Throwable {
BEC_5_4_LogicBool bevt_0_tmpvar_phold = null;
while (true)
 /* Line: 420 */ {
bevt_0_tmpvar_phold = beva_mbi.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 420 */ {
beva_mbi.bem_next_1(beva_txtpt);
this.bem_jsonEscapePoint_2(beva_txtpt, beva_escaped);
} /* Line: 422 */
 else  /* Line: 420 */ {
break;
} /* Line: 420 */
} /* Line: 420 */
return beva_escaped;
} /*method end*/
public BEC_6_6_SystemObject bem_marshallWriteString_2(BEC_4_6_TextString beva_inst, BEC_6_6_SystemObject beva_writer) throws Throwable {
BEC_4_6_TextString bevt_0_tmpvar_phold = null;
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_q);
bevt_0_tmpvar_phold = this.bem_jsonEscape_1(beva_inst);
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_0_tmpvar_phold);
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevp_q);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_marshallWriteList_2(BEC_6_6_SystemObject beva_inst, BEC_6_6_SystemObject beva_writer) throws Throwable {
BEC_5_4_LogicBool bevl_first = null;
BEC_6_6_SystemObject bevl_instin = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_4_6_TextString bevt_4_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(1, bels_14));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_1_tmpvar_phold);
bevl_first = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = beva_inst.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 436 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 436 */ {
bevl_instin = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 437 */ {
bevl_first = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 438 */
 else  /* Line: 439 */ {
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(1, bels_15));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_3_tmpvar_phold);
} /* Line: 440 */
this.bem_marshallWriteInst_2(bevl_instin, beva_writer);
} /* Line: 442 */
 else  /* Line: 436 */ {
break;
} /* Line: 436 */
} /* Line: 436 */
bevt_4_tmpvar_phold = (new BEC_4_6_TextString(1, bels_16));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_4_tmpvar_phold);
return this;
} /*method end*/
public BEC_6_6_SystemObject bem_marshallWriteMap_2(BEC_6_6_SystemObject beva_inst, BEC_6_6_SystemObject beva_writer) throws Throwable {
BEC_5_4_LogicBool bevl_first = null;
BEC_6_6_SystemObject bevl_kv = null;
BEC_6_6_SystemObject bevt_0_tmpvar_loop = null;
BEC_4_6_TextString bevt_1_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_4_6_TextString bevt_3_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_4_6_TextString bevt_7_tmpvar_phold = null;
bevt_1_tmpvar_phold = (new BEC_4_6_TextString(1, bels_17));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_1_tmpvar_phold);
bevl_first = be.BELS_Base.BECS_Runtime.boolTrue;
bevt_0_tmpvar_loop = beva_inst.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 450 */ {
bevt_2_tmpvar_phold = bevt_0_tmpvar_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_5_4_LogicBool && ((BEC_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 450 */ {
bevl_kv = bevt_0_tmpvar_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 452 */ {
bevl_first = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 453 */
 else  /* Line: 454 */ {
bevt_3_tmpvar_phold = (new BEC_4_6_TextString(1, bels_18));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_3_tmpvar_phold);
} /* Line: 455 */
bevt_4_tmpvar_phold = bevl_kv.bemd_0(478524008, BEL_4_Base.bevn_keyGet_0);
this.bem_marshallWriteString_2((BEC_4_6_TextString) bevt_4_tmpvar_phold, beva_writer);
bevt_5_tmpvar_phold = (new BEC_4_6_TextString(1, bels_19));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = bevl_kv.bemd_0(2020727446, BEL_4_Base.bevn_valueGet_0);
this.bem_marshallWriteInst_2(bevt_6_tmpvar_phold, beva_writer);
} /* Line: 459 */
 else  /* Line: 450 */ {
break;
} /* Line: 450 */
} /* Line: 450 */
bevt_7_tmpvar_phold = (new BEC_4_6_TextString(1, bels_20));
beva_writer.bemd_1(1603004369, BEL_4_Base.bevn_write_1, bevt_7_tmpvar_phold);
return this;
} /*method end*/
public BEC_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_6_6_SystemObject bem_strSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_str = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_10_ContainerLinkedList bem_llsGet_0() throws Throwable {
return bevp_lls;
} /*method end*/
public BEC_6_6_SystemObject bem_llsSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_lls = (BEC_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_5_ContainerArray bem_arrGet_0() throws Throwable {
return bevp_arr;
} /*method end*/
public BEC_6_6_SystemObject bem_arrSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_arr = (BEC_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_6_6_SystemObject bem_mapSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_map = (BEC_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_3_MathInt bem_intGet_0() throws Throwable {
return bevp_int;
} /*method end*/
public BEC_6_6_SystemObject bem_intSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_int = (BEC_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_5_4_LogicBool bem_booGet_0() throws Throwable {
return bevp_boo;
} /*method end*/
public BEC_6_6_SystemObject bem_booSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_boo = (BEC_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_qGet_0() throws Throwable {
return bevp_q;
} /*method end*/
public BEC_6_6_SystemObject bem_qSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_q = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_17_TextMultiByteIterator bem_mbiGet_0() throws Throwable {
return bevp_mbi;
} /*method end*/
public BEC_6_6_SystemObject bem_mbiSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mbi = (BEC_4_17_TextMultiByteIterator) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_txtptGet_0() throws Throwable {
return bevp_txtpt;
} /*method end*/
public BEC_6_6_SystemObject bem_txtptSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_txtpt = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_4_6_TextString bem_escapedGet_0() throws Throwable {
return bevp_escaped;
} /*method end*/
public BEC_6_6_SystemObject bem_escapedSet_1(BEC_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_escaped = (BEC_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {294, 296, 297, 299, 301, 303, 305, 307, 308, 309, 314, 315, 317, 318, 319, 323, 324, 326, 330, 331, 332, 333, 334, 0, 334, 0, 335, 336, 337, 338, 339, 340, 341, 343, 348, 349, 351, 354, 355, 357, 359, 361, 363, 365, 367, 368, 370, 372, 368, 375, 376, 377, 378, 380, 381, 383, 387, 388, 391, 393, 394, 395, 396, 399, 401, 402, 403, 404, 405, 406, 407, 408, 409, 415, 416, 420, 421, 422, 424, 428, 429, 430, 434, 435, 436, 0, 436, 438, 440, 442, 444, 448, 449, 450, 0, 450, 453, 455, 457, 458, 459, 461, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 66, 66, 66, 66, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 294 64
new 0 294 64
assign 1 296 64
new 0 296 64
assign 1 297 64
new 0 297 64
assign 1 297 64
new 1 297 64
assign 1 299 64
new 0 299 64
assign 1 301 64
new 0 301 64
assign 1 303 64
new 0 303 64
assign 1 305 64
new 0 305 64
assign 1 305 64
quoteGet 0 305 64
assign 1 307 64
new 0 307 64
assign 1 308 64
new 0 308 64
assign 1 309 64
new 0 309 64
assign 1 314 64
undef 1 314 64
new 0 315 64
assign 1 317 64
new 0 317 64
marshallWriteInst 2 318 64
assign 1 319 64
toString 0 319 64
return 1 319 64
assign 1 323 64
undef 1 323 64
new 0 324 64
marshallWriteInst 2 326 64
assign 1 330 64
undef 1 330 64
assign 1 331 64
new 0 331 64
write 1 331 64
assign 1 332 64
sameType 1 332 64
marshallWriteString 2 333 64
assign 1 334 64
sameType 1 334 64
assign 1 0 64
assign 1 334 64
sameType 1 334 64
assign 1 0 64
assign 1 0 64
marshallWriteList 2 335 64
assign 1 336 64
sameType 1 336 64
marshallWriteMap 2 337 64
assign 1 338 64
sameType 1 338 64
assign 1 339 64
toString 0 339 64
write 1 339 64
assign 1 340 64
sameType 1 340 64
assign 1 341 64
toString 0 341 64
write 1 341 64
assign 1 343 64
toString 0 343 64
marshallWriteString 2 343 64
assign 1 348 64
new 0 348 64
assign 1 349 64
sizeGet 0 349 64
assign 1 351 64
sizeGet 0 351 64
assign 1 354 64
new 0 354 64
assign 1 354 64
new 0 354 64
assign 1 354 64
getInt 2 354 64
assign 1 355 64
new 0 355 64
assign 1 355 64
equals 1 355 64
assign 1 357 64
new 0 357 64
assign 1 357 64
hexNew 1 357 64
assign 1 357 64
and 1 357 64
assign 1 359 64
new 0 359 64
assign 1 359 64
equals 1 359 64
assign 1 361 64
new 0 361 64
assign 1 361 64
hexNew 1 361 64
assign 1 361 64
and 1 361 64
assign 1 363 64
new 0 363 64
assign 1 363 64
equals 1 363 64
assign 1 365 64
new 0 365 64
assign 1 365 64
hexNew 1 365 64
assign 1 365 64
and 1 365 64
assign 1 367 64
new 0 367 64
assign 1 367 64
greater 1 367 64
assign 1 368 64
new 0 368 64
assign 1 368 64
lesser 1 368 64
getInt 2 370 64
assign 1 372 64
new 0 372 64
assign 1 372 64
shiftLeft 1 372 64
assign 1 372 64
new 0 372 64
assign 1 372 64
hexNew 1 372 64
assign 1 372 64
and 1 372 64
assign 1 372 64
add 1 372 64
incrementValue 0 368 64
assign 1 375 64
new 0 375 64
assign 1 375 64
equals 1 375 64
assign 1 376 64
new 0 376 64
assign 1 377 64
new 0 377 64
assign 1 377 64
equals 1 377 64
assign 1 378 64
new 0 378 64
assign 1 380 64
new 0 380 64
assign 1 380 64
hexNew 1 380 64
assign 1 380 64
lesser 1 380 64
assign 1 381 64
new 0 381 64
assign 1 383 64
new 0 383 64
assign 1 387 64
capacityGet 0 387 64
assign 1 387 64
subtract 1 387 64
assign 1 387 64
lesser 1 387 64
assign 1 388 64
add 1 388 64
capacitySet 1 388 64
assign 1 391 64
new 0 391 64
assign 1 391 64
equals 1 391 64
assign 1 393 64
new 0 393 64
assign 1 394 64
toEscapesGet 0 394 64
assign 1 394 64
get 1 394 64
assign 1 395 64
def 1 395 64
addValue 1 396 64
addValue 1 399 64
assign 1 401 64
new 0 401 64
assign 1 401 64
greater 1 401 64
assign 1 402 64
new 0 402 64
assign 1 402 64
equals 1 402 64
assign 1 403 64
new 0 403 64
assign 1 403 64
addValue 1 403 64
assign 1 403 64
new 0 403 64
assign 1 403 64
once 0 403 64
assign 1 403 64
new 1 403 64
assign 1 403 64
new 0 403 64
assign 1 403 64
once 0 403 64
assign 1 403 64
new 0 403 64
assign 1 403 64
once 0 403 64
assign 1 403 64
new 0 403 64
assign 1 403 64
once 0 403 64
assign 1 403 64
toString 4 403 64
addValue 1 403 64
assign 1 404 64
new 0 404 64
assign 1 404 64
equals 1 404 64
assign 1 405 64
new 0 405 64
assign 1 405 64
hexNew 1 405 64
subtractValue 1 405 64
assign 1 406 64
new 0 406 64
assign 1 406 64
hexNew 1 406 64
assign 1 406 64
new 0 406 64
assign 1 406 64
hexNew 1 406 64
assign 1 406 64
and 1 406 64
assign 1 406 64
new 0 406 64
assign 1 406 64
shiftRight 1 406 64
assign 1 406 64
or 1 406 64
assign 1 407 64
new 0 407 64
assign 1 407 64
hexNew 1 407 64
assign 1 407 64
new 0 407 64
assign 1 407 64
hexNew 1 407 64
assign 1 407 64
and 1 407 64
assign 1 407 64
or 1 407 64
assign 1 408 64
new 0 408 64
assign 1 408 64
addValue 1 408 64
assign 1 408 64
new 0 408 64
assign 1 408 64
once 0 408 64
assign 1 408 64
new 1 408 64
assign 1 408 64
new 0 408 64
assign 1 408 64
once 0 408 64
assign 1 408 64
new 0 408 64
assign 1 408 64
once 0 408 64
assign 1 408 64
new 0 408 64
assign 1 408 64
once 0 408 64
assign 1 408 64
toString 4 408 64
addValue 1 408 64
assign 1 409 64
new 0 409 64
assign 1 409 64
addValue 1 409 64
assign 1 409 64
new 0 409 64
assign 1 409 64
once 0 409 64
assign 1 409 64
new 1 409 64
assign 1 409 64
new 0 409 64
assign 1 409 64
once 0 409 64
assign 1 409 64
new 0 409 64
assign 1 409 64
once 0 409 64
assign 1 409 64
new 0 409 64
assign 1 409 64
once 0 409 64
assign 1 409 64
toString 4 409 64
addValue 1 409 64
clear 0 415 64
assign 1 416 64
new 1 416 64
assign 1 416 64
jsonEscape 3 416 64
return 1 416 64
assign 1 420 66
hasNextGet 0 420 66
next 1 421 66
jsonEscapePoint 2 422 66
return 1 424 66
write 1 428 64
assign 1 429 64
jsonEscape 1 429 64
write 1 429 64
write 1 430 64
assign 1 434 64
new 0 434 64
write 1 434 64
assign 1 435 64
new 0 435 64
assign 1 436 64
iteratorGet 0 0 64
assign 1 436 64
hasNextGet 0 436 64
assign 1 436 64
nextGet 0 436 64
assign 1 438 64
new 0 438 64
assign 1 440 64
new 0 440 64
write 1 440 64
marshallWriteInst 2 442 64
assign 1 444 64
new 0 444 64
write 1 444 64
assign 1 448 64
new 0 448 64
write 1 448 64
assign 1 449 64
new 0 449 64
assign 1 450 64
iteratorGet 0 0 64
assign 1 450 64
hasNextGet 0 450 64
assign 1 450 64
nextGet 0 450 64
assign 1 453 64
new 0 453 64
assign 1 455 64
new 0 455 64
write 1 455 64
assign 1 457 64
keyGet 0 457 64
marshallWriteString 2 457 64
assign 1 458 64
new 0 458 64
write 1 458 64
assign 1 459 64
valueGet 0 459 64
marshallWriteInst 2 459 64
assign 1 461 64
new 0 461 64
write 1 461 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
return 1 0 64
assign 1 0 64
END LINEINFO */
public BEC_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 991179882: return bem_qGet_0();
case 1081412016: return bem_many_0();
case 841474419: return bem_txtptGet_0();
case 104713553: return bem_new_0();
case 1774940957: return bem_toString_0();
case 443668840: return bem_methodNotDefined_0();
case 1102720804: return bem_classNameGet_0();
case 1841486012: return bem_escapedGet_0();
case 845792839: return bem_iteratorGet_0();
case 786424307: return bem_tagGet_0();
case 1317468250: return bem_arrGet_0();
case 1012494862: return bem_once_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1308786538: return bem_echo_0();
case 2055025483: return bem_serializeContents_0();
case 314718434: return bem_print_0();
case 327849388: return bem_llsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1763354070: return bem_strGet_0();
case 843567219: return bem_mbiGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
case 1820417453: return bem_create_0();
case 729571811: return bem_serializeToString_0();
case 1971910885: return bem_booGet_0();
case 542323416: return bem_intGet_0();
case 1354714650: return bem_copy_0();
case 156467595: return bem_mapGet_0();
case 287040793: return bem_hashGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_6_6_SystemObject bemd_1(int callHash, int callId, BEC_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1306385997: return bem_arrSet_1(bevd_0);
case 316767135: return bem_llsSet_1(bevd_0);
case 1982993138: return bem_booSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 854649472: return bem_mbiSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_4_6_TextString) bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_4_6_TextString) bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 303598400: return bem_marshall_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1830403759: return bem_escapedSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 623073531: return bem_jsonEscape_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 553405669: return bem_intSet_1(bevd_0);
case 167549848: return bem_mapSet_1(bevd_0);
case 852556672: return bem_txtptSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 980097629: return bem_qSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_4_6_TextString) bevd_0);
case 1774436323: return bem_strSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_6_6_SystemObject bemd_2(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1596765547: return bem_marshallWriteString_2((BEC_4_6_TextString) bevd_0, bevd_1);
case 1811026786: return bem_marshallWriteMap_2(bevd_0, bevd_1);
case 976327302: return bem_jsonEscapePoint_2((BEC_4_6_TextString) bevd_0, (BEC_4_6_TextString) bevd_1);
case 409655350: return bem_marshallWriteInst_2(bevd_0, bevd_1);
case 94427011: return bem_can_2((BEC_4_6_TextString) bevd_0, (BEC_4_3_MathInt) bevd_1);
case 328385502: return bem_marshallWriteList_2(bevd_0, bevd_1);
case 636686891: return bem_invoke_2((BEC_4_6_TextString) bevd_0, (BEC_9_5_ContainerArray) bevd_1);
case 1567407836: return bem_createInstance_2((BEC_4_6_TextString) bevd_0, (BEC_5_4_LogicBool) bevd_1);
case 1308979356: return bem_marshallWrite_2(bevd_0, bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_6_6_SystemObject bemd_3(int callHash, int callId, BEC_6_6_SystemObject bevd_0, BEC_6_6_SystemObject bevd_1, BEC_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 623073533: return bem_jsonEscape_3((BEC_4_17_TextMultiByteIterator) bevd_0, (BEC_4_6_TextString) bevd_1, (BEC_4_6_TextString) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_4_10_JsonMarshaller();
}
public void bemc_setInitial(BEC_6_6_SystemObject becc_inst) throws Throwable {
BEC_4_10_JsonMarshaller.bevs_inst = (BEC_4_10_JsonMarshaller)becc_inst;
}
public BEC_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_4_10_JsonMarshaller.bevs_inst;
}
}
