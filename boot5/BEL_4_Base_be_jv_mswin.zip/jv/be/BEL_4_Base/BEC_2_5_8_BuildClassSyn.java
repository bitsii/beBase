package be.BEL_4_Base;
/* IO:File: source/build/Syns.be */
public class BEC_2_5_8_BuildClassSyn extends BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 9));
private static byte[] bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_2, 9));
private static byte[] bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_3, 44));
private static byte[] bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_4, 78));
private static byte[] bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_5, 12));
private static byte[] bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_6, 38));
private static byte[] bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_7, 68));
private static byte[] bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_8, 75));
private static byte[] bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_9, 13));
private static byte[] bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_10, 65));
private static byte[] bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_11, 11));
private static byte[] bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_12, 33));
private static byte[] bels_13 = {0x20};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_13, 1));
private static byte[] bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_14, 95));
private static byte[] bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_15, 84));
private static byte[] bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_16, 80));
private static byte[] bels_17 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_17, 9));
private static byte[] bels_18 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_18, 26));
private static BEC_2_9_5_ContainerArray bevo_18;
private static BEC_2_4_3_MathInt bevo_19 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_19 = {0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
private static byte[] bels_20 = {0x64,0x65,0x70,0x74,0x68};
private static byte[] bels_21 = {0x66,0x72,0x6F,0x6D,0x46,0x69,0x6C,0x65};
private static byte[] bels_22 = {0x6C,0x69,0x62,0x4E,0x61,0x6D,0x65};
private static byte[] bels_23 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bels_24 = {0x69,0x73,0x4C,0x6F,0x63,0x61,0x6C};
private static byte[] bels_25 = {0x73,0x75,0x70,0x65,0x72,0x4C,0x69,0x73,0x74};
private static byte[] bels_26 = {0x75,0x73,0x65,0x73};
private static byte[] bels_27 = {0x70,0x74,0x79,0x4C,0x69,0x73,0x74};
private static byte[] bels_28 = {0x6D,0x74,0x64,0x4C,0x69,0x73,0x74};
private static byte[] bels_29 = {0x61,0x6C,0x6C,0x41,0x6E,0x63,0x65,0x73,0x74,0x6F,0x72,0x73,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bels_30 = {0x69,0x73,0x4E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
public static BEC_2_5_8_BuildClassSyn bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_5_ContainerArray bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_5_ContainerArray bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public BEC_2_5_8_BuildClassSyn bem_new_0() throws Throwable {
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BELS_Base.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpvar_phold = null;
bevl_maxMtdx = (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 104 */ {
bevt_0_tmpvar_phold = bevl_vi.bem_hasNextGet_0();
if (bevt_0_tmpvar_phold.bevi_bool) /* Line: 104 */ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_tmpvar_phold = bevl_ms.bem_mtdxGet_0();
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bem_greater_1(bevl_maxMtdx);
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 106 */ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 107 */
} /* Line: 106 */
 else  /* Line: 104 */ {
break;
} /* Line: 104 */
} /* Line: 104 */
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevo_0;
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_tmpvar_phold);
if (bevl_dmtd == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 115 */ {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
return bevt_2_tmpvar_phold;
} /* Line: 117 */
bevt_3_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
return bevt_3_tmpvar_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
this.bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) throws Throwable {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_50_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_51_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_52_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_53_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_57_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpvar_phold = null;
bevp_allTypes = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_integrated = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_signatureChanged = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_signatureChecked = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_uses = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpvar_phold = beva_psyn.bemd_0(1974592946, BEL_4_Base.bevn_superListGet_0);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_3_tmpvar_phold = beva_psyn.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevp_superList.bem_addValue_1(bevt_3_tmpvar_phold);
bevt_4_tmpvar_phold = beva_psyn.bemd_0(1477961836, BEL_4_Base.bevn_mtdListGet_0);
bevp_mtdList = (BEC_2_9_5_ContainerArray) bevt_4_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_5_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevp_ptyList = (BEC_2_9_5_ContainerArray) bevt_5_tmpvar_phold.bemd_0(1354714650, BEL_4_Base.bevn_copy_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 142 */ {
bevt_8_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 142 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = beva_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_9_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_10_tmpvar_phold);
bevt_14_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_1));
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_15_tmpvar_phold);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 145 */ {
if (bevl_pv == null) {
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 145 */
 else  /* Line: 145 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 145 */ {
bevt_19_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_17_tmpvar_phold != null && bevt_17_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_17_tmpvar_phold).bevi_bool) /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 145 */
 else  /* Line: 145 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 145 */ {
bevt_24_tmpvar_phold = bevo_1;
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_23_tmpvar_phold = bevt_24_tmpvar_phold.bem_add_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevo_2;
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_28_tmpvar_phold = bevt_29_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_add_1(bevt_28_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_20_tmpvar_phold);
} /* Line: 146 */
} /* Line: 145 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevt_31_tmpvar_phold = beva_psyn.bemd_0(2033393684, BEL_4_Base.bevn_ptyListGet_0);
bevl_iv = bevt_31_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 151 */ {
bevt_32_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 151 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_34_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_33_tmpvar_phold != null && bevt_33_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_33_tmpvar_phold).bevi_bool) /* Line: 153 */ {
bevt_35_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpvar_phold = bevl_ov.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_35_tmpvar_phold.bemd_1(56796208, BEL_4_Base.bevn_addUsed_1, bevt_36_tmpvar_phold);
} /* Line: 154 */
} /* Line: 153 */
 else  /* Line: 151 */ {
break;
} /* Line: 151 */
} /* Line: 151 */
bevt_39_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_38_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 158 */ {
bevt_40_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_40_tmpvar_phold != null && bevt_40_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_40_tmpvar_phold).bevi_bool) /* Line: 158 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_41_tmpvar_phold = beva_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_41_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_42_tmpvar_phold);
if (bevl_pm == null) {
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_44_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_44_tmpvar_phold.bevi_bool) /* Line: 161 */ {
bevt_46_tmpvar_phold = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
if (bevt_46_tmpvar_phold == null) {
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpvar_phold.bevi_bool) /* Line: 162 */ {
bevt_49_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevt_48_tmpvar_phold == null) {
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_47_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_47_tmpvar_phold.bevi_bool) /* Line: 163 */ {
bevt_54_tmpvar_phold = bevo_3;
bevt_56_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_53_tmpvar_phold = bevt_54_tmpvar_phold.bem_add_1(bevt_55_tmpvar_phold);
bevt_57_tmpvar_phold = bevo_4;
bevt_52_tmpvar_phold = bevt_53_tmpvar_phold.bem_add_1(bevt_57_tmpvar_phold);
bevt_59_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bem_add_1(bevt_58_tmpvar_phold);
bevt_50_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_50_tmpvar_phold);
} /* Line: 164 */
} /* Line: 163 */
} /* Line: 162 */
} /* Line: 161 */
 else  /* Line: 158 */ {
break;
} /* Line: 158 */
} /* Line: 158 */
this.bem_loadClass_1(beva_klass);
bevt_60_tmpvar_phold = beva_psyn.bemd_0(202810500, BEL_4_Base.bevn_depthGet_0);
bevt_61_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_tmpvar_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_61_tmpvar_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpvar_phold = null;
bevt_0_tmpvar_phold = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_tmpvar_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) throws Throwable {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_3_9_5_8_ContainerArrayIterator bevt_0_tmpvar_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpvar_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_9_tmpvar_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_9_5_ContainerArray bevt_13_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_17_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_31_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_32_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_33_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_34_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_42_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_45_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_9_3_ContainerMap bevt_48_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_49_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpvar_phold = null;
BEC_2_9_3_ContainerSet bevt_55_tmpvar_phold = null;
BEC_2_5_8_BuildEmitData bevt_56_tmpvar_phold = null;
BEC_2_5_11_BuildMethodIndex bevt_57_tmpvar_phold = null;
if (bevp_integrated.bevi_bool) /* Line: 178 */ {
return this;
} /* Line: 178 */
bevp_integrated = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directProperties = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_directMethods = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpvar_phold.bevi_bool) /* Line: 183 */ {
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_tmpvar_loop = bevp_mtdList.bem_arrayIteratorGet_0();
while (true)
 /* Line: 188 */ {
bevt_7_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 188 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpvar_loop.bem_nextGet_0();
bevt_9_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_methodIndexesGet_0();
bevt_10_tmpvar_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_tmpvar_phold.bem_put_1(bevt_10_tmpvar_phold);
} /* Line: 189 */
 else  /* Line: 188 */ {
break;
} /* Line: 188 */
} /* Line: 188 */
return this;
} /* Line: 191 */
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (new BEC_2_4_3_MathInt(0));
bevt_11_tmpvar_phold = bevp_ptyList.bem_sizeGet_0();
bevt_13_tmpvar_phold = bevl_psyn.bem_ptyListGet_0();
bevt_12_tmpvar_phold = bevt_13_tmpvar_phold.bem_sizeGet_0();
bevp_newMbrs = bevt_11_tmpvar_phold.bem_subtract_1(bevt_12_tmpvar_phold);
bevt_15_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_equals_1(bevp_libName);
if (bevt_14_tmpvar_phold.bevi_bool) /* Line: 198 */ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 198 */
bevt_16_tmpvar_phold = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 199 */ {
bevt_19_tmpvar_phold = bevo_5;
bevt_20_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_18_tmpvar_phold = bevt_19_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_17_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_17_tmpvar_phold);
} /* Line: 200 */
bevt_21_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_23_tmpvar_phold = bevl_psyn.bem_libNameGet_0();
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bem_notEquals_1(bevp_libName);
if (bevt_22_tmpvar_phold.bevi_bool) /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 202 */
 else  /* Line: 202 */ {
bevt_2_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpvar_anchor.bevi_bool) /* Line: 202 */ {
bevt_26_tmpvar_phold = bevo_6;
bevt_27_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_25_tmpvar_phold = bevt_26_tmpvar_phold.bem_add_1(bevt_27_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_24_tmpvar_phold);
} /* Line: 203 */
bevt_28_tmpvar_phold = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_29_tmpvar_phold = bevp_isLocal.bem_not_0();
if (bevt_29_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_4_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpvar_anchor.bevi_bool) /* Line: 205 */ {
bevt_30_tmpvar_phold = bevp_isFinal.bem_not_0();
if (bevt_30_tmpvar_phold.bevi_bool) /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 205 */
 else  /* Line: 205 */ {
bevt_3_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpvar_anchor.bevi_bool) /* Line: 205 */ {
bevt_33_tmpvar_phold = bevo_7;
bevt_34_tmpvar_phold = bevp_namepath.bem_toString_0();
bevt_32_tmpvar_phold = bevt_33_tmpvar_phold.bem_add_1(bevt_34_tmpvar_phold);
bevt_31_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_31_tmpvar_phold);
} /* Line: 206 */
bevt_1_tmpvar_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 208 */ {
bevt_35_tmpvar_phold = bevt_1_tmpvar_loop.bem_hasNextGet_0();
if (bevt_35_tmpvar_phold != null && bevt_35_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_35_tmpvar_phold).bevi_bool) /* Line: 208 */ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_tmpvar_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_39_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_37_tmpvar_phold = bevt_38_tmpvar_phold.bem_has_1(bevt_39_tmpvar_phold);
bevt_36_tmpvar_phold = bevt_37_tmpvar_phold.bem_not_0();
if (bevt_36_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_41_tmpvar_phold = bevl_pn.bem_toString_0();
bevt_42_tmpvar_phold = bevo_8;
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_notEquals_1(bevt_42_tmpvar_phold);
if (bevt_40_tmpvar_phold.bevi_bool) /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 210 */
 else  /* Line: 210 */ {
bevt_5_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpvar_anchor.bevi_bool) /* Line: 210 */ {
bevp_directProperties = be.BELS_Base.BECS_Runtime.boolFalse;
bevp_directMethods = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 213 */
bevt_45_tmpvar_phold = beva_build.bem_closeLibrariesGet_0();
bevt_46_tmpvar_phold = bevl_pnsyn.bem_libNameGet_0();
bevt_44_tmpvar_phold = bevt_45_tmpvar_phold.bem_has_1(bevt_46_tmpvar_phold);
bevt_43_tmpvar_phold = bevt_44_tmpvar_phold.bem_not_0();
if (bevt_43_tmpvar_phold.bevi_bool) /* Line: 215 */ {
bevp_allAncestorsClose = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 216 */
} /* Line: 215 */
 else  /* Line: 208 */ {
break;
} /* Line: 208 */
} /* Line: 208 */
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
 /* Line: 220 */ {
bevt_47_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_47_tmpvar_phold != null && bevt_47_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_47_tmpvar_phold).bevi_bool) /* Line: 220 */ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_48_tmpvar_phold = bevl_psyn.bem_mtdMapGet_0();
bevt_49_tmpvar_phold = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_tmpvar_phold.bem_get_1(bevt_49_tmpvar_phold);
if (bevl_pm == null) {
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpvar_phold.bevi_bool) /* Line: 223 */ {
bevt_51_tmpvar_phold = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_tmpvar_phold.bevi_bool) /* Line: 224 */ {
bevt_52_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_tmpvar_phold);
bevt_53_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_tmpvar_phold);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 227 */
} /* Line: 224 */
 else  /* Line: 229 */ {
bevt_54_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_tmpvar_phold);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_tmpvar_phold = beva_build.bem_emitDataGet_0();
bevt_55_tmpvar_phold = bevt_56_tmpvar_phold.bem_methodIndexesGet_0();
bevt_57_tmpvar_phold = (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_tmpvar_phold.bem_put_1(bevt_57_tmpvar_phold);
} /* Line: 233 */
} /* Line: 223 */
 else  /* Line: 220 */ {
break;
} /* Line: 220 */
} /* Line: 220 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_37_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_38_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_39_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_40_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_41_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_44_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_58_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_62_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_63_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_64_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpvar_phold = null;
if (bevp_iChecked.bevi_bool) /* Line: 240 */ {
return this;
} /* Line: 240 */
bevp_iChecked = be.BELS_Base.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 242 */ {
return this;
} /* Line: 242 */
bevl_psyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevp_superNp);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_3_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 244 */ {
bevt_5_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpvar_phold != null && bevt_5_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpvar_phold).bevi_bool) /* Line: 244 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_6_tmpvar_phold = bevl_psyn.bemd_0(153365600, BEL_4_Base.bevn_ptyMapGet_0);
bevt_8_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pv = bevt_6_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_7_tmpvar_phold);
if (bevl_pv == null) {
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpvar_phold.bevi_bool) /* Line: 247 */ {
bevt_11_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 248 */ {
bevt_16_tmpvar_phold = bevo_9;
bevt_18_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_17_tmpvar_phold = bevt_18_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bem_add_1(bevt_17_tmpvar_phold);
bevt_19_tmpvar_phold = bevo_10;
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bem_add_1(bevt_19_tmpvar_phold);
bevt_22_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_20_tmpvar_phold = bevt_21_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bem_add_1(bevt_20_tmpvar_phold);
bevt_12_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_13_tmpvar_phold);
throw new be.BELS_Base.BECS_ThrowBack(bevt_12_tmpvar_phold);
} /* Line: 249 */
 else  /* Line: 250 */ {
bevt_23_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_25_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_24_tmpvar_phold = bevt_25_tmpvar_phold.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_23_tmpvar_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_24_tmpvar_phold);
bevt_26_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_28_tmpvar_phold = bevl_pv.bemd_0(1444794516, BEL_4_Base.bevn_memSynGet_0);
bevt_27_tmpvar_phold = bevt_28_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpvar_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_27_tmpvar_phold);
} /* Line: 252 */
} /* Line: 248 */
} /* Line: 247 */
 else  /* Line: 244 */ {
break;
} /* Line: 244 */
} /* Line: 244 */
bevt_30_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_29_tmpvar_phold = bevt_30_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_29_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 256 */ {
bevt_31_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_31_tmpvar_phold != null && bevt_31_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpvar_phold).bevi_bool) /* Line: 256 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_32_tmpvar_phold = bevl_psyn.bemd_0(244359240, BEL_4_Base.bevn_mtdMapGet_0);
bevt_34_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_33_tmpvar_phold = bevt_34_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_pm = bevt_32_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevt_33_tmpvar_phold);
if (bevl_pm == null) {
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
 } else { 
bevt_35_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
}
if (bevt_35_tmpvar_phold.bevi_bool) /* Line: 259 */ {
bevt_36_tmpvar_phold = bevl_pm.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
if (bevt_36_tmpvar_phold != null && bevt_36_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpvar_phold).bevi_bool) /* Line: 260 */ {
bevt_41_tmpvar_phold = bevo_11;
bevt_43_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpvar_phold = bevt_43_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_40_tmpvar_phold = bevt_41_tmpvar_phold.bem_add_1(bevt_42_tmpvar_phold);
bevt_44_tmpvar_phold = bevo_12;
bevt_39_tmpvar_phold = bevt_40_tmpvar_phold.bem_add_1(bevt_44_tmpvar_phold);
bevt_47_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_46_tmpvar_phold = bevt_47_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_45_tmpvar_phold = bevt_46_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_38_tmpvar_phold = bevt_39_tmpvar_phold.bem_add_1(bevt_45_tmpvar_phold);
bevt_37_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_38_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_37_tmpvar_phold);
} /* Line: 261 */
bevt_49_tmpvar_phold = bevl_om.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_48_tmpvar_phold = bevt_49_tmpvar_phold.bemd_0(183400265, BEL_4_Base.bevn_firstGet_0);
bevl_oa = bevt_48_tmpvar_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 264 */ {
bevt_52_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevt_51_tmpvar_phold = bevt_52_tmpvar_phold.bemd_0(1616433729, BEL_4_Base.bevn_lengthGet_0);
bevt_50_tmpvar_phold = bevl_i.bemd_1(2090192440, BEL_4_Base.bevn_lesser_1, bevt_51_tmpvar_phold);
if (bevt_50_tmpvar_phold != null && bevt_50_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_50_tmpvar_phold).bevi_bool) /* Line: 264 */ {
bevt_53_tmpvar_phold = bevl_pm.bemd_0(815066086, BEL_4_Base.bevn_argSynsGet_0);
bevl_pmr = bevt_53_tmpvar_phold.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevt_54_tmpvar_phold = bevl_oa.bemd_1(98246024, BEL_4_Base.bevn_get_1, bevl_i);
bevl_omr = bevt_54_tmpvar_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
this.bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(1085372256, BEL_4_Base.bevn_increment_0);
} /* Line: 264 */
 else  /* Line: 264 */ {
break;
} /* Line: 264 */
} /* Line: 264 */
bevl_pmr = bevl_pm.bemd_0(1900010001, BEL_4_Base.bevn_rsynGet_0);
bevt_55_tmpvar_phold = bevl_om.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevl_omr = bevt_55_tmpvar_phold.bemd_0(430935493, BEL_4_Base.bevn_rtypeGet_0);
if (bevl_pmr == null) {
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
if (bevl_omr == null) {
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpvar_phold.bevi_bool) /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 272 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 272 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 272 */ {
if (bevl_pmr == null) {
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
bevt_58_tmpvar_phold = bevt_59_tmpvar_phold.bem_not_0();
if (bevt_58_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
if (bevl_omr == null) {
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
bevt_60_tmpvar_phold = bevt_61_tmpvar_phold.bem_not_0();
if (bevt_60_tmpvar_phold.bevi_bool) /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 273 */ {
bevt_1_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 273 */
if (bevt_1_tmpvar_anchor.bevi_bool) /* Line: 273 */ {
bevt_64_tmpvar_phold = bevo_13;
bevt_67_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_66_tmpvar_phold = bevt_67_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_65_tmpvar_phold = bevt_66_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_63_tmpvar_phold = bevt_64_tmpvar_phold.bem_add_1(bevt_65_tmpvar_phold);
bevt_62_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_63_tmpvar_phold, bevl_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_62_tmpvar_phold);
} /* Line: 274 */
} /* Line: 273 */
 else  /* Line: 276 */ {
this.bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 278 */
} /* Line: 272 */
} /* Line: 259 */
 else  /* Line: 256 */ {
break;
} /* Line: 256 */
} /* Line: 256 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) throws Throwable {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpvar_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_20_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
bevt_2_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_3_tmpvar_phold = beva_omr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
bevt_1_tmpvar_phold = bevt_2_tmpvar_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_3_tmpvar_phold);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 285 */ {
bevt_6_tmpvar_phold = bevo_14;
bevt_9_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_5_tmpvar_phold = bevt_6_tmpvar_phold.bem_add_1(bevt_7_tmpvar_phold);
bevt_4_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_4_tmpvar_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
bevt_10_tmpvar_phold = beva_pmr.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_10_tmpvar_phold != null && bevt_10_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_10_tmpvar_phold).bevi_bool) /* Line: 287 */ {
bevt_11_tmpvar_phold = beva_pmr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_11_tmpvar_phold != null && bevt_11_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_11_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_12_tmpvar_phold = beva_omr.bemd_0(535212143, BEL_4_Base.bevn_isSelfGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 290 */
 else  /* Line: 290 */ {
bevt_0_tmpvar_anchor = be.BELS_Base.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpvar_anchor.bevi_bool) /* Line: 290 */ {
return this;
} /* Line: 291 */
bevt_13_tmpvar_phold = beva_omr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_osyn = beva_build.bemd_1(706249818, BEL_4_Base.bevn_getSynNp_1, bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = bevl_osyn.bemd_0(986531569, BEL_4_Base.bevn_allTypesGet_0);
bevt_17_tmpvar_phold = beva_pmr.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_17_tmpvar_phold);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 294 */ {
bevt_20_tmpvar_phold = bevo_15;
bevt_23_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_22_tmpvar_phold = bevt_23_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_19_tmpvar_phold = bevt_20_tmpvar_phold.bem_add_1(bevt_21_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_tmpvar_phold, beva_om);
throw new be.BELS_Base.BECS_ThrowBack(bevt_18_tmpvar_phold);
} /* Line: 295 */
} /* Line: 294 */
} /* Line: 285 */
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_5_10_BuildVisitError bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpvar_phold = null;
this.bem_new_0();
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_0_tmpvar_phold = bevt_1_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_0_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 302 */ {
bevt_2_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_2_tmpvar_phold != null && bevt_2_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpvar_phold).bevi_bool) /* Line: 302 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_5_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_4_tmpvar_phold = bevt_5_tmpvar_phold.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
bevt_3_tmpvar_phold = bevt_4_tmpvar_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_3_tmpvar_phold != null && bevt_3_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_3_tmpvar_phold).bevi_bool) /* Line: 304 */ {
bevt_10_tmpvar_phold = bevo_16;
bevt_12_tmpvar_phold = bevl_ov.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpvar_phold = bevt_12_tmpvar_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpvar_phold = bevt_10_tmpvar_phold.bem_add_1(bevt_11_tmpvar_phold);
bevt_13_tmpvar_phold = bevo_17;
bevt_8_tmpvar_phold = bevt_9_tmpvar_phold.bem_add_1(bevt_13_tmpvar_phold);
bevt_16_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpvar_phold = bevt_16_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_14_tmpvar_phold = bevt_15_tmpvar_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_add_1(bevt_14_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_tmpvar_phold, bevl_ov);
throw new be.BELS_Base.BECS_ThrowBack(bevt_6_tmpvar_phold);
} /* Line: 305 */
} /* Line: 304 */
 else  /* Line: 302 */ {
break;
} /* Line: 302 */
} /* Line: 302 */
this.bem_loadClass_1(beva_klass);
bevp_depth = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
bevt_0_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_phold.bemd_0(795036897, BEL_4_Base.bevn_fromFileGet_0);
bevt_1_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_tmpvar_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_2_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_tmpvar_phold.bemd_0(1803479881, BEL_4_Base.bevn_libNameGet_0);
bevt_3_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_tmpvar_phold.bemd_0(287367803, BEL_4_Base.bevn_isFinalGet_0);
bevt_4_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_tmpvar_phold.bemd_0(842582618, BEL_4_Base.bevn_isLocalGet_0);
bevt_5_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_tmpvar_phold.bemd_0(363636983, BEL_4_Base.bevn_isNotNullGet_0);
bevt_7_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_6_tmpvar_phold = bevt_7_tmpvar_phold.bemd_0(83882038, BEL_4_Base.bevn_usedGet_0);
bevl_iu = bevt_6_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 320 */ {
bevt_8_tmpvar_phold = bevl_iu.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_8_tmpvar_phold != null && bevt_8_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_8_tmpvar_phold).bevi_bool) /* Line: 320 */ {
bevl_ou = bevl_iu.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ou.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevp_uses.bem_put_1(bevt_9_tmpvar_phold);
} /* Line: 322 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
bevt_11_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_10_tmpvar_phold = bevt_11_tmpvar_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_iv = bevt_10_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 324 */ {
bevt_12_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_12_tmpvar_phold != null && bevt_12_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_12_tmpvar_phold).bevi_bool) /* Line: 324 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 327 */
 else  /* Line: 324 */ {
break;
} /* Line: 324 */
} /* Line: 324 */
bevt_14_tmpvar_phold = beva_klass.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_13_tmpvar_phold = bevt_14_tmpvar_phold.bemd_0(87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevl_im = bevt_13_tmpvar_phold.bemd_0(845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 329 */ {
bevt_15_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_15_tmpvar_phold != null && bevt_15_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_15_tmpvar_phold).bevi_bool) /* Line: 329 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 332 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
this.bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_postLoad_0() throws Throwable {
BEC_2_9_5_ContainerArray bevl_nptyList = null;
BEC_2_9_5_ContainerArray bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpvar_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_27_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_28_tmpvar_phold = null;
BEC_2_5_8_BuildNamePath bevt_29_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpvar_phold = null;
bevl_nptyList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_mtdnList = (new BEC_2_9_5_ContainerArray()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 342 */ {
bevt_1_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpvar_phold != null && bevt_1_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpvar_phold).bevi_bool) /* Line: 342 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_4_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_3_tmpvar_phold = bevp_ptyMap.bem_has_1(bevt_4_tmpvar_phold);
bevt_2_tmpvar_phold = bevt_3_tmpvar_phold.bem_not_0();
if (bevt_2_tmpvar_phold.bevi_bool) /* Line: 344 */ {
bevt_5_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_ptyMap.bem_put_2(bevt_5_tmpvar_phold, bevl_ov);
} /* Line: 346 */
} /* Line: 344 */
 else  /* Line: 342 */ {
break;
} /* Line: 342 */
} /* Line: 342 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 352 */ {
bevt_6_tmpvar_phold = bevl_iv.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_6_tmpvar_phold != null && bevt_6_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_6_tmpvar_phold).bevi_bool) /* Line: 352 */ {
bevl_ov = bevl_iv.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_8_tmpvar_phold = bevl_unq.bem_has_1(bevt_9_tmpvar_phold);
bevt_7_tmpvar_phold = bevt_8_tmpvar_phold.bem_not_0();
if (bevt_7_tmpvar_phold.bevi_bool) /* Line: 354 */ {
bevt_10_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_tmpvar_phold);
bevl_nom.bemd_1(1283009805, BEL_4_Base.bevn_mposSet_1, bevl_mpos);
bevt_11_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_11_tmpvar_phold);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_13_tmpvar_phold = bevl_ov.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
} /* Line: 359 */
} /* Line: 354 */
 else  /* Line: 352 */ {
break;
} /* Line: 352 */
} /* Line: 352 */
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 366 */ {
bevt_14_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_14_tmpvar_phold != null && bevt_14_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_14_tmpvar_phold).bevi_bool) /* Line: 366 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_15_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevp_mtdMap.bem_put_2(bevt_15_tmpvar_phold, bevl_om);
bevt_18_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_17_tmpvar_phold = bevl_mtdOmap.bem_has_1(bevt_18_tmpvar_phold);
bevt_16_tmpvar_phold = bevt_17_tmpvar_phold.bem_not_0();
if (bevt_16_tmpvar_phold.bevi_bool) /* Line: 371 */ {
bevt_19_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_mtdOmap.bem_put_2(bevt_19_tmpvar_phold, bevl_om);
} /* Line: 372 */
} /* Line: 371 */
 else  /* Line: 366 */ {
break;
} /* Line: 366 */
} /* Line: 366 */
bevl_unq = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
 /* Line: 378 */ {
bevt_20_tmpvar_phold = bevl_im.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_20_tmpvar_phold != null && bevt_20_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpvar_phold).bevi_bool) /* Line: 378 */ {
bevl_om = bevl_im.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_23_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_22_tmpvar_phold = bevl_unq.bem_has_1(bevt_23_tmpvar_phold);
bevt_21_tmpvar_phold = bevt_22_tmpvar_phold.bem_not_0();
if (bevt_21_tmpvar_phold.bevi_bool) /* Line: 380 */ {
bevt_24_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_tmpvar_phold);
bevt_25_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_tmpvar_phold);
bevt_27_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
if (bevt_27_tmpvar_phold == null) {
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpvar_phold.bevi_bool) /* Line: 391 */ {
bevt_28_tmpvar_phold = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_tmpvar_phold);
} /* Line: 392 */
bevt_29_tmpvar_phold = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(885379526, BEL_4_Base.bevn_declarationSet_1, bevt_29_tmpvar_phold);
bevl_oma.bemd_1(1365143591, BEL_4_Base.bevn_mtdxSet_1, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_31_tmpvar_phold = bevl_om.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevl_unq.bem_put_2(bevt_30_tmpvar_phold, bevt_31_tmpvar_phold);
} /* Line: 398 */
} /* Line: 380 */
 else  /* Line: 378 */ {
break;
} /* Line: 378 */
} /* Line: 378 */
bevp_mtdList = bevl_mtdnList;
bevt_0_tmpvar_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 403 */ {
bevt_32_tmpvar_phold = bevt_0_tmpvar_loop.bem_hasNextGet_0();
if (bevt_32_tmpvar_phold != null && bevt_32_tmpvar_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpvar_phold).bevi_bool) /* Line: 403 */ {
bevl_s = bevt_0_tmpvar_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 405 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_9_5_ContainerArray bevl_names = null;
BEC_2_4_3_MathInt bevt_0_tmpvar_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_5_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_7_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_9_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_11_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_13_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_15_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_17_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_19_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_21_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_23_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_25_tmpvar_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpvar_phold = null;
BEC_2_4_6_TextString bevt_27_tmpvar_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpvar_phold = null;
bevt_0_tmpvar_phold = (new BEC_2_4_3_MathInt(12));
synchronized (BEC_2_5_8_BuildClassSyn.class) {
if (bevo_18 == null) {
bevo_18 = (new BEC_2_9_5_ContainerArray()).bem_new_1(bevt_0_tmpvar_phold);
}
}
bevl_names = bevo_18;
bevt_3_tmpvar_phold = bevo_19;
bevt_2_tmpvar_phold = bevl_names.bem_get_1(bevt_3_tmpvar_phold);
if (bevt_2_tmpvar_phold == null) {
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpvar_phold = be.BELS_Base.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpvar_phold.bevi_bool) /* Line: 413 */ {
bevt_4_tmpvar_phold = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_19));
bevl_names.bem_put_2(bevt_4_tmpvar_phold, bevt_5_tmpvar_phold);
bevt_6_tmpvar_phold = (new BEC_2_4_3_MathInt(1));
bevt_7_tmpvar_phold = (new BEC_2_4_6_TextString(5, bels_20));
bevl_names.bem_put_2(bevt_6_tmpvar_phold, bevt_7_tmpvar_phold);
bevt_8_tmpvar_phold = (new BEC_2_4_3_MathInt(2));
bevt_9_tmpvar_phold = (new BEC_2_4_6_TextString(8, bels_21));
bevl_names.bem_put_2(bevt_8_tmpvar_phold, bevt_9_tmpvar_phold);
bevt_10_tmpvar_phold = (new BEC_2_4_3_MathInt(3));
bevt_11_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_22));
bevl_names.bem_put_2(bevt_10_tmpvar_phold, bevt_11_tmpvar_phold);
bevt_12_tmpvar_phold = (new BEC_2_4_3_MathInt(4));
bevt_13_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_23));
bevl_names.bem_put_2(bevt_12_tmpvar_phold, bevt_13_tmpvar_phold);
bevt_14_tmpvar_phold = (new BEC_2_4_3_MathInt(5));
bevt_15_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_24));
bevl_names.bem_put_2(bevt_14_tmpvar_phold, bevt_15_tmpvar_phold);
bevt_16_tmpvar_phold = (new BEC_2_4_3_MathInt(6));
bevt_17_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_25));
bevl_names.bem_put_2(bevt_16_tmpvar_phold, bevt_17_tmpvar_phold);
bevt_18_tmpvar_phold = (new BEC_2_4_3_MathInt(7));
bevt_19_tmpvar_phold = (new BEC_2_4_6_TextString(4, bels_26));
bevl_names.bem_put_2(bevt_18_tmpvar_phold, bevt_19_tmpvar_phold);
bevt_20_tmpvar_phold = (new BEC_2_4_3_MathInt(8));
bevt_21_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_27));
bevl_names.bem_put_2(bevt_20_tmpvar_phold, bevt_21_tmpvar_phold);
bevt_22_tmpvar_phold = (new BEC_2_4_3_MathInt(9));
bevt_23_tmpvar_phold = (new BEC_2_4_6_TextString(7, bels_28));
bevl_names.bem_put_2(bevt_22_tmpvar_phold, bevt_23_tmpvar_phold);
bevt_24_tmpvar_phold = (new BEC_2_4_3_MathInt(10));
bevt_25_tmpvar_phold = (new BEC_2_4_6_TextString(17, bels_29));
bevl_names.bem_put_2(bevt_24_tmpvar_phold, bevt_25_tmpvar_phold);
bevt_26_tmpvar_phold = (new BEC_2_4_3_MathInt(11));
bevt_27_tmpvar_phold = (new BEC_2_4_6_TextString(9, bels_30));
bevl_names.bem_put_2(bevt_26_tmpvar_phold, bevt_27_tmpvar_phold);
} /* Line: 425 */
bevt_28_tmpvar_phold = (new BEC_2_6_23_SystemNamedPropertiesIterator()).bem_new_2(this, bevl_names);
return bevt_28_tmpvar_phold;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() throws Throwable {
return bevp_superNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() throws Throwable {
return bevp_depth;
} /*method end*/
public BEC_2_6_6_SystemObject bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() throws Throwable {
return bevp_namepath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() throws Throwable {
return bevp_isLocal;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() throws Throwable {
return bevp_isNotNull;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() throws Throwable {
return bevp_newMbrs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() throws Throwable {
return bevp_newMtds;
} /*method end*/
public BEC_2_6_6_SystemObject bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() throws Throwable {
return bevp_defMtds;
} /*method end*/
public BEC_2_6_6_SystemObject bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() throws Throwable {
return bevp_directProperties;
} /*method end*/
public BEC_2_6_6_SystemObject bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() throws Throwable {
return bevp_directMethods;
} /*method end*/
public BEC_2_6_6_SystemObject bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() throws Throwable {
return bevp_allTypes;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() throws Throwable {
return bevp_superList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() throws Throwable {
return bevp_mtdMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_mtdListGet_0() throws Throwable {
return bevp_mtdList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_mtdList = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() throws Throwable {
return bevp_ptyMap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerArray bem_ptyListGet_0() throws Throwable {
return bevp_ptyList;
} /*method end*/
public BEC_2_6_6_SystemObject bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_ptyList = (BEC_2_9_5_ContainerArray) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() throws Throwable {
return bevp_allNames;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() throws Throwable {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_6_6_SystemObject bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() throws Throwable {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() throws Throwable {
return bevp_integrated;
} /*method end*/
public BEC_2_6_6_SystemObject bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() throws Throwable {
return bevp_iChecked;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() throws Throwable {
return bevp_uses;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() throws Throwable {
return bevp_isFinal;
} /*method end*/
public BEC_2_6_6_SystemObject bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() throws Throwable {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_6_6_SystemObject bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() throws Throwable {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_6_6_SystemObject bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpvar_SET) throws Throwable {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_tmpvar_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {80, 82, 84, 86, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 98, 103, 104, 105, 106, 107, 110, 114, 115, 117, 119, 122, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 142, 143, 144, 145, 0, 145, 0, 146, 151, 152, 153, 154, 158, 159, 160, 161, 162, 163, 164, 169, 170, 174, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 0, 188, 189, 191, 193, 194, 195, 197, 198, 199, 200, 202, 0, 203, 205, 0, 205, 0, 206, 208, 0, 208, 209, 210, 0, 212, 213, 215, 216, 220, 221, 222, 223, 224, 225, 226, 227, 230, 231, 232, 233, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 251, 252, 256, 257, 258, 259, 260, 261, 263, 264, 265, 266, 268, 264, 270, 271, 272, 0, 272, 0, 273, 0, 273, 0, 274, 278, 285, 286, 287, 290, 0, 291, 293, 294, 295, 301, 302, 303, 304, 305, 308, 309, 314, 315, 316, 317, 318, 319, 320, 321, 322, 324, 325, 326, 327, 329, 330, 331, 332, 334, 338, 339, 342, 343, 344, 346, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 362, 364, 366, 367, 369, 371, 372, 376, 377, 378, 379, 380, 381, 390, 391, 392, 394, 395, 396, 397, 398, 401, 403, 0, 403, 404, 405, 408, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 427, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87, 87};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 80 87
new 0 80 87
assign 1 82 87
new 0 82 87
assign 1 84 87
new 0 84 87
assign 1 86 87
new 0 86 87
assign 1 87 87
new 0 87 87
assign 1 88 87
new 0 88 87
assign 1 89 87
new 0 89 87
assign 1 90 87
new 0 90 87
assign 1 91 87
new 0 91 87
assign 1 92 87
new 0 92 87
assign 1 93 87
new 0 93 87
assign 1 95 87
new 0 95 87
assign 1 96 87
new 0 96 87
assign 1 97 87
new 0 97 87
assign 1 98 87
new 0 98 87
assign 1 103 87
new 0 103 87
assign 1 104 87
valueIteratorGet 0 104 87
assign 1 104 87
hasNextGet 0 104 87
assign 1 105 87
nextGet 0 105 87
assign 1 106 87
mtdxGet 0 106 87
assign 1 106 87
greater 1 106 87
assign 1 107 87
mtdxGet 0 107 87
return 1 110 87
assign 1 114 87
new 0 114 87
assign 1 114 87
get 1 114 87
assign 1 115 87
def 1 115 87
assign 1 117 87
new 0 117 87
return 1 117 87
assign 1 119 87
new 0 119 87
return 1 119 87
new 0 122 87
assign 1 125 87
new 0 125 87
assign 1 126 87
new 0 126 87
assign 1 127 87
new 0 127 87
assign 1 128 87
new 0 128 87
assign 1 129 87
new 0 129 87
assign 1 130 87
new 0 130 87
assign 1 131 87
new 0 131 87
assign 1 132 87
new 0 132 87
assign 1 133 87
new 0 133 87
assign 1 134 87
new 0 134 87
assign 1 135 87
new 0 135 87
assign 1 136 87
superListGet 0 136 87
assign 1 136 87
copy 0 136 87
assign 1 137 87
namepathGet 0 137 87
addValue 1 137 87
assign 1 138 87
mtdListGet 0 138 87
assign 1 138 87
copy 0 138 87
assign 1 139 87
ptyListGet 0 139 87
assign 1 139 87
copy 0 139 87
assign 1 142 87
heldGet 0 142 87
assign 1 142 87
orderedVarsGet 0 142 87
assign 1 142 87
iteratorGet 0 142 87
assign 1 142 87
hasNextGet 0 142 87
assign 1 143 87
nextGet 0 143 87
assign 1 144 87
ptyMapGet 0 144 87
assign 1 144 87
heldGet 0 144 87
assign 1 144 87
nameGet 0 144 87
assign 1 144 87
get 1 144 87
assign 1 145 87
heldGet 0 145 87
assign 1 145 87
nameGet 0 145 87
assign 1 145 87
new 0 145 87
assign 1 145 87
notEquals 1 145 87
assign 1 145 87
undef 1 145 87
assign 1 0 87
assign 1 0 87
assign 1 0 87
assign 1 145 87
heldGet 0 145 87
assign 1 145 87
isDeclaredGet 0 145 87
assign 1 145 87
not 0 145 87
assign 1 0 87
assign 1 0 87
assign 1 0 87
assign 1 146 87
new 0 146 87
assign 1 146 87
heldGet 0 146 87
assign 1 146 87
nameGet 0 146 87
assign 1 146 87
add 1 146 87
assign 1 146 87
new 0 146 87
assign 1 146 87
add 1 146 87
assign 1 146 87
heldGet 0 146 87
assign 1 146 87
namepathGet 0 146 87
assign 1 146 87
toString 0 146 87
assign 1 146 87
add 1 146 87
assign 1 146 87
new 2 146 87
throw 1 146 87
assign 1 151 87
ptyListGet 0 151 87
assign 1 151 87
iteratorGet 0 151 87
assign 1 151 87
hasNextGet 0 151 87
assign 1 152 87
nextGet 0 152 87
assign 1 153 87
memSynGet 0 153 87
assign 1 153 87
isTypedGet 0 153 87
assign 1 154 87
heldGet 0 154 87
assign 1 154 87
memSynGet 0 154 87
assign 1 154 87
namepathGet 0 154 87
addUsed 1 154 87
assign 1 158 87
heldGet 0 158 87
assign 1 158 87
orderedMethodsGet 0 158 87
assign 1 158 87
iteratorGet 0 158 87
assign 1 158 87
hasNextGet 0 158 87
assign 1 159 87
nextGet 0 159 87
assign 1 160 87
mtdMapGet 0 160 87
assign 1 160 87
heldGet 0 160 87
assign 1 160 87
nameGet 0 160 87
assign 1 160 87
get 1 160 87
assign 1 161 87
def 1 161 87
assign 1 162 87
rsynGet 0 162 87
assign 1 162 87
def 1 162 87
assign 1 163 87
heldGet 0 163 87
assign 1 163 87
rtypeGet 0 163 87
assign 1 163 87
undef 1 163 87
assign 1 164 87
new 0 164 87
assign 1 164 87
heldGet 0 164 87
assign 1 164 87
nameGet 0 164 87
assign 1 164 87
add 1 164 87
assign 1 164 87
new 0 164 87
assign 1 164 87
add 1 164 87
assign 1 164 87
heldGet 0 164 87
assign 1 164 87
nameGet 0 164 87
assign 1 164 87
add 1 164 87
assign 1 164 87
new 2 164 87
throw 1 164 87
loadClass 1 169 87
assign 1 170 87
depthGet 0 170 87
assign 1 170 87
new 0 170 87
assign 1 170 87
add 1 170 87
assign 1 174 87
has 1 174 87
return 1 174 87
return 1 178 88
assign 1 179 88
new 0 179 88
assign 1 180 88
new 0 180 88
assign 1 181 88
new 0 181 88
assign 1 182 88
new 0 182 88
assign 1 183 88
undef 1 183 88
assign 1 184 88
new 0 184 88
assign 1 185 88
sizeGet 0 185 88
assign 1 186 88
sizeGet 0 186 88
assign 1 187 88
assign 1 188 88
arrayIteratorGet 0 0 88
assign 1 188 88
hasNextGet 0 188 88
assign 1 188 88
nextGet 0 188 88
assign 1 189 88
emitDataGet 0 189 88
assign 1 189 88
methodIndexesGet 0 189 88
assign 1 189 88
new 2 189 88
put 1 189 88
return 1 191 88
assign 1 193 88
getSynNp 1 193 88
assign 1 194 88
new 0 194 88
assign 1 195 88
new 0 195 88
assign 1 197 88
sizeGet 0 197 88
assign 1 197 88
ptyListGet 0 197 88
assign 1 197 88
sizeGet 0 197 88
assign 1 197 88
subtract 1 197 88
assign 1 198 88
libNameGet 0 198 88
assign 1 198 88
equals 1 198 88
integrate 1 198 88
assign 1 199 88
isFinalGet 0 199 88
assign 1 200 88
new 0 200 88
assign 1 200 88
toString 0 200 88
assign 1 200 88
add 1 200 88
assign 1 200 88
new 1 200 88
throw 1 200 88
assign 1 202 88
isLocalGet 0 202 88
assign 1 202 88
libNameGet 0 202 88
assign 1 202 88
notEquals 1 202 88
assign 1 0 88
assign 1 0 88
assign 1 0 88
assign 1 203 88
new 0 203 88
assign 1 203 88
toString 0 203 88
assign 1 203 88
add 1 203 88
assign 1 203 88
new 1 203 88
throw 1 203 88
assign 1 205 88
isLocalGet 0 205 88
assign 1 205 88
not 0 205 88
assign 1 0 88
assign 1 0 88
assign 1 0 88
assign 1 205 88
not 0 205 88
assign 1 0 88
assign 1 0 88
assign 1 0 88
assign 1 206 88
new 0 206 88
assign 1 206 88
toString 0 206 88
assign 1 206 88
add 1 206 88
assign 1 206 88
new 1 206 88
throw 1 206 88
assign 1 208 88
linkedListIteratorGet 0 0 88
assign 1 208 88
hasNextGet 0 208 88
assign 1 208 88
nextGet 0 208 88
assign 1 209 88
getSynNp 1 209 88
assign 1 210 88
closeLibrariesGet 0 210 88
assign 1 210 88
libNameGet 0 210 88
assign 1 210 88
has 1 210 88
assign 1 210 88
not 0 210 88
assign 1 210 88
toString 0 210 88
assign 1 210 88
new 0 210 88
assign 1 210 88
notEquals 1 210 88
assign 1 0 88
assign 1 0 88
assign 1 0 88
assign 1 212 88
new 0 212 88
assign 1 213 88
new 0 213 88
assign 1 215 88
closeLibrariesGet 0 215 88
assign 1 215 88
libNameGet 0 215 88
assign 1 215 88
has 1 215 88
assign 1 215 88
not 0 215 88
assign 1 216 88
new 0 216 88
assign 1 220 88
valueIteratorGet 0 220 88
assign 1 220 88
hasNextGet 0 220 88
assign 1 221 88
nextGet 0 221 88
assign 1 222 88
mtdMapGet 0 222 88
assign 1 222 88
nameGet 0 222 88
assign 1 222 88
get 1 222 88
assign 1 223 88
def 1 223 88
assign 1 224 88
notEquals 1 224 88
assign 1 225 88
new 0 225 88
lastDefSet 1 225 88
assign 1 226 88
new 0 226 88
isOverrideSet 1 226 88
assign 1 227 88
increment 0 227 88
assign 1 230 88
new 0 230 88
isOverrideSet 1 230 88
assign 1 231 88
increment 0 231 88
assign 1 232 88
increment 0 232 88
assign 1 233 88
emitDataGet 0 233 88
assign 1 233 88
methodIndexesGet 0 233 88
assign 1 233 88
new 2 233 88
put 1 233 88
return 1 240 88
assign 1 241 88
new 0 241 88
assign 1 242 88
undef 1 242 88
return 1 242 88
assign 1 243 88
getSynNp 1 243 88
assign 1 244 88
heldGet 0 244 88
assign 1 244 88
orderedVarsGet 0 244 88
assign 1 244 88
iteratorGet 0 244 88
assign 1 244 88
hasNextGet 0 244 88
assign 1 245 88
nextGet 0 245 88
assign 1 246 88
ptyMapGet 0 246 88
assign 1 246 88
heldGet 0 246 88
assign 1 246 88
nameGet 0 246 88
assign 1 246 88
get 1 246 88
assign 1 247 88
def 1 247 88
assign 1 248 88
heldGet 0 248 88
assign 1 248 88
isDeclaredGet 0 248 88
assign 1 249 88
new 0 249 88
assign 1 249 88
heldGet 0 249 88
assign 1 249 88
nameGet 0 249 88
assign 1 249 88
add 1 249 88
assign 1 249 88
new 0 249 88
assign 1 249 88
add 1 249 88
assign 1 249 88
heldGet 0 249 88
assign 1 249 88
namepathGet 0 249 88
assign 1 249 88
toString 0 249 88
assign 1 249 88
add 1 249 88
assign 1 249 88
new 1 249 88
throw 1 249 88
assign 1 251 88
heldGet 0 251 88
assign 1 251 88
memSynGet 0 251 88
assign 1 251 88
isTypedGet 0 251 88
isTypedSet 1 251 88
assign 1 252 88
heldGet 0 252 88
assign 1 252 88
memSynGet 0 252 88
assign 1 252 88
namepathGet 0 252 88
namepathSet 1 252 88
assign 1 256 88
heldGet 0 256 88
assign 1 256 88
orderedMethodsGet 0 256 88
assign 1 256 88
iteratorGet 0 256 88
assign 1 256 88
hasNextGet 0 256 88
assign 1 257 88
nextGet 0 257 88
assign 1 258 88
mtdMapGet 0 258 88
assign 1 258 88
heldGet 0 258 88
assign 1 258 88
nameGet 0 258 88
assign 1 258 88
get 1 258 88
assign 1 259 88
def 1 259 88
assign 1 260 88
isFinalGet 0 260 88
assign 1 261 88
new 0 261 88
assign 1 261 88
heldGet 0 261 88
assign 1 261 88
nameGet 0 261 88
assign 1 261 88
add 1 261 88
assign 1 261 88
new 0 261 88
assign 1 261 88
add 1 261 88
assign 1 261 88
heldGet 0 261 88
assign 1 261 88
namepathGet 0 261 88
assign 1 261 88
toString 0 261 88
assign 1 261 88
add 1 261 88
assign 1 261 88
new 2 261 88
throw 1 261 88
assign 1 263 88
containedGet 0 263 88
assign 1 263 88
firstGet 0 263 88
assign 1 263 88
containedGet 0 263 88
assign 1 264 88
new 0 264 88
assign 1 264 88
argSynsGet 0 264 88
assign 1 264 88
lengthGet 0 264 88
assign 1 264 88
lesser 1 264 88
assign 1 265 88
argSynsGet 0 265 88
assign 1 265 88
get 1 265 88
assign 1 266 88
get 1 266 88
assign 1 266 88
heldGet 0 266 88
checkTypes 5 268 88
assign 1 264 88
increment 0 264 88
assign 1 270 88
rsynGet 0 270 88
assign 1 271 88
heldGet 0 271 88
assign 1 271 88
rtypeGet 0 271 88
assign 1 272 88
undef 1 272 88
assign 1 0 88
assign 1 272 88
undef 1 272 88
assign 1 0 88
assign 1 0 88
assign 1 273 88
undef 1 273 88
assign 1 273 88
not 0 273 88
assign 1 0 88
assign 1 273 88
undef 1 273 88
assign 1 273 88
not 0 273 88
assign 1 0 88
assign 1 0 88
assign 1 274 88
new 0 274 88
assign 1 274 88
heldGet 0 274 88
assign 1 274 88
namepathGet 0 274 88
assign 1 274 88
toString 0 274 88
assign 1 274 88
add 1 274 88
assign 1 274 88
new 2 274 88
throw 1 274 88
checkTypes 5 278 88
assign 1 285 87
isTypedGet 0 285 87
assign 1 285 87
isTypedGet 0 285 87
assign 1 285 87
notEquals 1 285 87
assign 1 286 87
new 0 286 87
assign 1 286 87
heldGet 0 286 87
assign 1 286 87
namepathGet 0 286 87
assign 1 286 87
toString 0 286 87
assign 1 286 87
add 1 286 87
assign 1 286 87
new 2 286 87
throw 1 286 87
assign 1 287 87
isTypedGet 0 287 87
assign 1 290 87
isSelfGet 0 290 87
assign 1 290 87
isSelfGet 0 290 87
assign 1 0 87
assign 1 0 87
assign 1 0 87
return 1 291 87
assign 1 293 87
namepathGet 0 293 87
assign 1 293 87
getSynNp 1 293 87
assign 1 294 87
allTypesGet 0 294 87
assign 1 294 87
namepathGet 0 294 87
assign 1 294 87
has 1 294 87
assign 1 294 87
not 0 294 87
assign 1 295 87
new 0 295 87
assign 1 295 87
heldGet 0 295 87
assign 1 295 87
namepathGet 0 295 87
assign 1 295 87
toString 0 295 87
assign 1 295 87
add 1 295 87
assign 1 295 87
new 2 295 87
throw 1 295 87
new 0 301 87
assign 1 302 87
heldGet 0 302 87
assign 1 302 87
orderedVarsGet 0 302 87
assign 1 302 87
iteratorGet 0 302 87
assign 1 302 87
hasNextGet 0 302 87
assign 1 303 87
nextGet 0 303 87
assign 1 304 87
heldGet 0 304 87
assign 1 304 87
isDeclaredGet 0 304 87
assign 1 304 87
not 0 304 87
assign 1 305 87
new 0 305 87
assign 1 305 87
heldGet 0 305 87
assign 1 305 87
nameGet 0 305 87
assign 1 305 87
add 1 305 87
assign 1 305 87
new 0 305 87
assign 1 305 87
add 1 305 87
assign 1 305 87
heldGet 0 305 87
assign 1 305 87
namepathGet 0 305 87
assign 1 305 87
toString 0 305 87
assign 1 305 87
add 1 305 87
assign 1 305 87
new 2 305 87
throw 1 305 87
loadClass 1 308 87
assign 1 309 87
new 0 309 87
assign 1 314 87
heldGet 0 314 87
assign 1 314 87
fromFileGet 0 314 87
assign 1 315 87
heldGet 0 315 87
assign 1 315 87
namepathGet 0 315 87
assign 1 316 87
heldGet 0 316 87
assign 1 316 87
libNameGet 0 316 87
assign 1 317 87
heldGet 0 317 87
assign 1 317 87
isFinalGet 0 317 87
assign 1 318 87
heldGet 0 318 87
assign 1 318 87
isLocalGet 0 318 87
assign 1 319 87
heldGet 0 319 87
assign 1 319 87
isNotNullGet 0 319 87
assign 1 320 87
heldGet 0 320 87
assign 1 320 87
usedGet 0 320 87
assign 1 320 87
iteratorGet 0 320 87
assign 1 320 87
hasNextGet 0 320 87
assign 1 321 87
nextGet 0 321 87
assign 1 322 87
toString 0 322 87
put 1 322 87
assign 1 324 87
heldGet 0 324 87
assign 1 324 87
orderedVarsGet 0 324 87
assign 1 324 87
iteratorGet 0 324 87
assign 1 324 87
hasNextGet 0 324 87
assign 1 325 87
nextGet 0 325 87
assign 1 326 87
new 2 326 87
addValue 1 327 87
assign 1 329 87
heldGet 0 329 87
assign 1 329 87
orderedMethodsGet 0 329 87
assign 1 329 87
iteratorGet 0 329 87
assign 1 329 87
hasNextGet 0 329 87
assign 1 330 87
nextGet 0 330 87
assign 1 331 87
new 2 331 87
addValue 1 332 87
postLoad 0 334 87
assign 1 338 87
new 0 338 87
assign 1 339 87
new 0 339 87
assign 1 342 87
iteratorGet 0 342 87
assign 1 342 87
hasNextGet 0 342 87
assign 1 343 87
nextGet 0 343 87
assign 1 344 87
nameGet 0 344 87
assign 1 344 87
has 1 344 87
assign 1 344 87
not 0 344 87
assign 1 346 87
nameGet 0 346 87
put 2 346 87
assign 1 350 87
new 0 350 87
assign 1 351 87
new 0 351 87
assign 1 352 87
iteratorGet 0 352 87
assign 1 352 87
hasNextGet 0 352 87
assign 1 353 87
nextGet 0 353 87
assign 1 354 87
nameGet 0 354 87
assign 1 354 87
has 1 354 87
assign 1 354 87
not 0 354 87
assign 1 355 87
nameGet 0 355 87
assign 1 355 87
get 1 355 87
mposSet 1 356 87
assign 1 357 87
new 0 357 87
assign 1 357 87
add 1 357 87
addValue 1 358 87
assign 1 359 87
nameGet 0 359 87
assign 1 359 87
nameGet 0 359 87
put 2 359 87
assign 1 362 87
assign 1 364 87
new 0 364 87
assign 1 366 87
iteratorGet 0 366 87
assign 1 366 87
hasNextGet 0 366 87
assign 1 367 87
nextGet 0 367 87
assign 1 369 87
nameGet 0 369 87
put 2 369 87
assign 1 371 87
nameGet 0 371 87
assign 1 371 87
has 1 371 87
assign 1 371 87
not 0 371 87
assign 1 372 87
nameGet 0 372 87
put 2 372 87
assign 1 376 87
new 0 376 87
assign 1 377 87
new 0 377 87
assign 1 378 87
iteratorGet 0 378 87
assign 1 378 87
hasNextGet 0 378 87
assign 1 379 87
nextGet 0 379 87
assign 1 380 87
nameGet 0 380 87
assign 1 380 87
has 1 380 87
assign 1 380 87
not 0 380 87
assign 1 381 87
nameGet 0 381 87
assign 1 381 87
get 1 381 87
assign 1 390 87
nameGet 0 390 87
assign 1 390 87
get 1 390 87
assign 1 391 87
declarationGet 0 391 87
assign 1 391 87
undef 1 391 87
assign 1 392 87
originGet 0 392 87
declarationSet 1 392 87
assign 1 394 87
declarationGet 0 394 87
declarationSet 1 394 87
mtdxSet 1 395 87
assign 1 396 87
increment 0 396 87
addValue 1 397 87
assign 1 398 87
nameGet 0 398 87
assign 1 398 87
nameGet 0 398 87
put 2 398 87
assign 1 401 87
assign 1 403 87
linkedListIteratorGet 0 0 87
assign 1 403 87
hasNextGet 0 403 87
assign 1 403 87
nextGet 0 403 87
put 2 404 87
assign 1 405 87
put 2 408 87
assign 1 412 87
new 0 412 87
assign 1 412 87
new 1 412 87
assign 1 413 87
new 0 413 87
assign 1 413 87
get 1 413 87
assign 1 413 87
undef 1 413 87
assign 1 414 87
new 0 414 87
assign 1 414 87
new 0 414 87
put 2 414 87
assign 1 415 87
new 0 415 87
assign 1 415 87
new 0 415 87
put 2 415 87
assign 1 416 87
new 0 416 87
assign 1 416 87
new 0 416 87
put 2 416 87
assign 1 417 87
new 0 417 87
assign 1 417 87
new 0 417 87
put 2 417 87
assign 1 418 87
new 0 418 87
assign 1 418 87
new 0 418 87
put 2 418 87
assign 1 419 87
new 0 419 87
assign 1 419 87
new 0 419 87
put 2 419 87
assign 1 420 87
new 0 420 87
assign 1 420 87
new 0 420 87
put 2 420 87
assign 1 421 87
new 0 421 87
assign 1 421 87
new 0 421 87
put 2 421 87
assign 1 422 87
new 0 422 87
assign 1 422 87
new 0 422 87
put 2 422 87
assign 1 423 87
new 0 423 87
assign 1 423 87
new 0 423 87
put 2 423 87
assign 1 424 87
new 0 424 87
assign 1 424 87
new 0 424 87
put 2 424 87
assign 1 425 87
new 0 425 87
assign 1 425 87
new 0 425 87
put 2 425 87
assign 1 427 87
new 2 427 87
return 1 427 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
return 1 0 87
assign 1 0 87
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case 153365600: return bem_ptyMapGet_0();
case 1314364113: return bem_newMbrsGet_0();
case 2097069068: return bem_integratedGet_0();
case 1803479881: return bem_libNameGet_0();
case 287040793: return bem_hashGet_0();
case 1443447938: return bem_directMethodsGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2033393684: return bem_ptyListGet_0();
case 842582618: return bem_isLocalGet_0();
case 416660294: return bem_objectIteratorGet_0();
case 311680096: return bem_allNamesGet_0();
case 2058095605: return bem_signatureChangedGet_0();
case 1774940957: return bem_toString_0();
case 786424307: return bem_tagGet_0();
case 492006165: return bem_directPropertiesGet_0();
case 834964524: return bem_defMtdsGet_0();
case 1820417453: return bem_create_0();
case 1974592946: return bem_superListGet_0();
case 1760712968: return bem_signatureCheckedGet_0();
case 1274615854: return bem_allAncestorsCloseGet_0();
case 363636983: return bem_isNotNullGet_0();
case 1081412016: return bem_many_0();
case 104713553: return bem_new_0();
case 1012494862: return bem_once_0();
case 1631955979: return bem_foreignClassesGet_0();
case 1214937871: return bem_newMtdsGet_0();
case 795036897: return bem_fromFileGet_0();
case 845792839: return bem_iteratorGet_0();
case 71634217: return bem_iCheckedGet_0();
case 287367803: return bem_isFinalGet_0();
case 354142775: return bem_namepathGet_0();
case 202810500: return bem_depthGet_0();
case 1477961836: return bem_mtdListGet_0();
case 345555227: return bem_usesGet_0();
case 1308786538: return bem_echo_0();
case 314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case 244359240: return bem_mtdMapGet_0();
case 2055025483: return bem_serializeContents_0();
case 443668840: return bem_methodNotDefined_0();
case 986531569: return bem_allTypesGet_0();
case 481879936: return bem_hasDefaultGet_0();
case 1413594071: return bem_postLoad_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 729571811: return bem_serializeToString_0();
case 1354714650: return bem_copy_0();
case 68632810: return bem_superNpGet_0();
case 1495449800: return bem_maxMtdxGet_0();
case 35631997: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 1118052001: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 82716470: return bem_iCheckedSet_1(bevd_0);
case 1432365685: return bem_directMethodsSet_1(bevd_0);
case 374719236: return bem_isNotNullSet_1(bevd_0);
case 298450056: return bem_isFinalSet_1(bevd_0);
case 356637480: return bem_usesSet_1(bevd_0);
case 975449316: return bem_allTypesSet_1(bevd_0);
case 142283347: return bem_ptyMapSet_1(bevd_0);
case 79715063: return bem_superNpSet_1(bevd_0);
case 1749630715: return bem_signatureCheckedSet_1(bevd_0);
case 1279784069: return bem_defined_1(bevd_0);
case 2085986815: return bem_integratedSet_1(bevd_0);
case 505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case 2047013352: return bem_signatureChangedSet_1(bevd_0);
case 255441493: return bem_mtdMapSet_1(bevd_0);
case 300597843: return bem_allNamesSet_1(bevd_0);
case 846046777: return bem_defMtdsSet_1(bevd_0);
case 831500365: return bem_isLocalSet_1(bevd_0);
case 480923912: return bem_directPropertiesSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1489044089: return bem_mtdListSet_1(bevd_0);
case 458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1203855618: return bem_newMtdsSet_1(bevd_0);
case 104713554: return bem_new_1(bevd_0);
case 1963510693: return bem_superListSet_1(bevd_0);
case 2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1285698107: return bem_allAncestorsCloseSet_1(bevd_0);
case 1697252238: return bem_sameType_1(bevd_0);
case 340843364: return bem_loadClass_1(bevd_0);
case 1792397628: return bem_libNameSet_1(bevd_0);
case 1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1211344638: return bem_undefined_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1156342947: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1325446366: return bem_newMbrsSet_1(bevd_0);
case 365225028: return bem_namepathSet_1(bevd_0);
case 1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 213892753: return bem_depthSet_1(bevd_0);
case 1620873726: return bem_foreignClassesSet_1(bevd_0);
case 291583106: return bem_undef_1(bevd_0);
case 2044475937: return bem_ptyListSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 104713555: return bem_new_2(bevd_0, bevd_1);
case 1694832085: return bem_checkInheritance_2(bevd_0, bevd_1);
case 1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_5_ContainerArray) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case 913726521: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_8_BuildClassSyn();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_8_BuildClassSyn.bevs_inst = (BEC_2_5_8_BuildClassSyn)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_8_BuildClassSyn.bevs_inst;
}
}
