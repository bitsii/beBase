package be;
/* IO:File: source/build/Pass12.be */
public final class BEC_3_5_5_6_BuildVisitPass12 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass12() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x32};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_1 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_2 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_5 = {0x47,0x45,0x54};
private static byte[] bels_6 = {0x5F,0x30};
private static byte[] bels_7 = {0x53,0x45,0x54};
private static byte[] bels_8 = {0x5F,0x31};
private static byte[] bels_9 = {0x53,0x45,0x54};
private static byte[] bels_10 = {0x43,0x61,0x6C,0x6C,0x20,0x68,0x65,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_11 = {0x73,0x65,0x6C,0x66};
private static byte[] bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_12, 64));
private static byte[] bels_13 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x70,0x72,0x6F,0x62,0x61,0x62,0x6C,0x79,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x65,0x78,0x69,0x73,0x74,0x2C,0x20,0x76,0x65,0x72,0x69,0x66,0x79,0x20,0x6E,0x61,0x6D,0x65,0x20,0x61,0x6E,0x64,0x20,0x75,0x73,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] bels_14 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_14, 52));
private static byte[] bels_15 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74};
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bels_16 = {0x5F};
private static byte[] bels_17 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bels_18 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bels_19 = {0x6D,0x61,0x6E,0x79,0x5F,0x30};
public static BEC_3_5_5_6_BuildVisitPass12 bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_classnp;
public BEC_3_5_5_6_BuildVisitPass12 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAccessor_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_myselfn = null;
BEC_2_6_6_SystemObject bevl_myself = null;
BEC_2_6_6_SystemObject bevl_mtdmyn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_6_6_SystemObject bevl_myparn = null;
BEC_2_6_6_SystemObject bevl_mybr = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_3_BuildVar bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevl_myselfn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_myselfn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpany_phold);
bevl_myself = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_0));
bevl_myself.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_2_tmpany_phold);
bevl_myself.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevp_classnp);
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_3_tmpany_phold);
bevl_myselfn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_myself);
bevl_mtdmyn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_4_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mtdmyn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_4_tmpany_phold);
bevl_mtdmy = (new BEC_2_5_6_BuildMethod()).bem_new_0();
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_mtdmy.bemd_1(1725653351, BEL_4_Base.bevn_isGenAccessorSet_1, bevt_5_tmpany_phold);
bevl_mtdmyn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_mtdmy);
bevl_myparn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_6_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_myparn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_6_tmpany_phold);
bevl_myparn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_myselfn);
bevl_mtdmyn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_myparn);
bevl_myselfn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_mybr = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_7_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_mybr.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_7_tmpany_phold);
bevl_mtdmyn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_mybr);
bevt_8_tmpany_phold = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_mtdmy.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevl_mtdmy.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_9_tmpany_phold.bemd_1(-524129890, BEL_4_Base.bevn_isSelfSet_1, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_mtdmy.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_11_tmpany_phold.bemd_1(606514572, BEL_4_Base.bevn_isThisSet_1, bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bevl_mtdmy.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_13_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevl_mtdmy.bemd_0(-430935493, BEL_4_Base.bevn_rtypeGet_0);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_1));
bevt_16_tmpany_phold = (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_17_tmpany_phold);
bevt_15_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevt_16_tmpany_phold);
return bevl_mtdmyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getRetNode_1(BEC_2_6_6_SystemObject beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_retnoden = null;
BEC_2_6_6_SystemObject bevl_retnode = null;
BEC_2_6_6_SystemObject bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_retnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_retnoden.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpany_phold);
bevl_retnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_2));
bevl_retnode.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpany_phold);
bevl_retnoden.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_retnode);
bevl_sn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_sn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_3));
bevl_sn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_3_tmpany_phold);
bevl_retnoden.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_sn);
return bevl_retnoden;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAsNode_1(BEC_2_6_6_SystemObject beva_selfnode) throws Throwable {
BEC_2_6_6_SystemObject bevl_asnoden = null;
BEC_2_6_6_SystemObject bevl_asnode = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_asnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asnoden.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_0_tmpany_phold);
bevl_asnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_4));
bevl_asnode.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_1_tmpany_phold);
bevl_asnoden.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_asnode);
return bevl_asnoden;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevl_ia = null;
BEC_2_6_6_SystemObject bevl_tst = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ename = null;
BEC_2_6_6_SystemObject bevl_anode = null;
BEC_2_6_6_SystemObject bevl_rettnode = null;
BEC_2_6_6_SystemObject bevl_rin = null;
BEC_2_6_6_SystemObject bevl_sv = null;
BEC_2_6_6_SystemObject bevl_svn = null;
BEC_2_6_6_SystemObject bevl_svn2 = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_newNp = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_c1 = null;
BEC_2_6_6_SystemObject bevl_bn = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpany_phold = null;
BEC_2_4_6_TextString bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpany_phold = null;
BEC_2_4_6_TextString bevt_156_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_157_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_4_6_TextString bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_174_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpany_phold = null;
BEC_2_4_6_TextString bevt_178_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_180_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_182_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_183_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_184_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_185_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_186_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_188_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_191_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_192_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_195_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_196_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_197_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_200_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_203_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_204_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_205_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_13_tmpany_phold = beva_node.bem_containedGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_firstGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevl_ia = bevt_11_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bevl_ia.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_14_tmpany_phold.bemd_1(1204395540, BEL_4_Base.bevn_isTypedSet_1, bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevl_ia.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpany_phold.bemd_1(365225028, BEL_4_Base.bevn_namepathSet_1, bevp_classnp);
} /* Line: 80 */
 else  /* Line: 77 */ {
bevt_18_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_18_tmpany_phold.bevi_int == bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_20_tmpany_phold = beva_node.bem_heldGet_0();
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_20_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_tst = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_22_tmpany_phold = beva_node.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1081760974, BEL_4_Base.bevn_orderedVarsGet_0);
bevl_ii = bevt_21_tmpany_phold.bemd_0(-845792839, BEL_4_Base.bevn_iteratorGet_0);
while (true)
 /* Line: 87 */ {
bevt_23_tmpany_phold = bevl_ii.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_23_tmpany_phold).bevi_bool) /* Line: 87 */ {
bevt_24_tmpany_phold = bevl_ii.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevl_i = bevt_24_tmpany_phold.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_26_tmpany_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_25_tmpany_phold);
bevt_27_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_5));
bevl_tst.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_27_tmpany_phold);
bevl_tst.bemd_0(-173192194, BEL_4_Base.bevn_toAccessorName_0);
bevl_ename = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_29_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_6));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_30_tmpany_phold);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_28_tmpany_phold);
bevt_31_tmpany_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_31_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevt_35_tmpany_phold = beva_node.bem_heldGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_36_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_36_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_32_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevl_anode = this.bem_getAccessor_1(beva_node);
bevt_37_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpany_phold.bemd_1(-1030895937, BEL_4_Base.bevn_propertySet_1, bevl_i);
bevt_38_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_38_tmpany_phold.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_ename);
bevt_39_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_40_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_39_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_40_tmpany_phold);
bevt_41_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_42_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_41_tmpany_phold.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_42_tmpany_phold);
bevt_44_tmpany_phold = beva_node.bem_heldGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_46_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_43_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_45_tmpany_phold, bevl_anode);
bevt_48_tmpany_phold = beva_node.bem_heldGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_47_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_50_tmpany_phold = beva_node.bem_containedGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_lastGet_0();
bevt_49_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevl_rettnode = this.bem_getRetNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_51_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_51_tmpany_phold);
bevt_53_tmpany_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevl_rin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_52_tmpany_phold);
bevl_rettnode.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rin);
bevt_55_tmpany_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevt_54_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rettnode);
bevt_57_tmpany_phold = bevl_rettnode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_56_tmpany_phold.bemd_1(-205397975, BEL_4_Base.bevn_syncVariable_1, this);
bevl_rin.bemd_1(-205397975, BEL_4_Base.bevn_syncVariable_1, this);
bevt_58_tmpany_phold = bevl_i.bemd_0(1193313287, BEL_4_Base.bevn_isTypedGet_0);
if (bevt_58_tmpany_phold != null && bevt_58_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_58_tmpany_phold).bevi_bool) /* Line: 113 */ {
bevt_59_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_59_tmpany_phold.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, bevl_i);
} /* Line: 114 */
 else  /* Line: 115 */ {
bevt_60_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_60_tmpany_phold.bemd_1(-419853240, BEL_4_Base.bevn_rtypeSet_1, null);
} /* Line: 116 */
} /* Line: 113 */
bevt_62_tmpany_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_61_tmpany_phold);
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_7));
bevl_tst.bemd_1(794751475, BEL_4_Base.bevn_accessorTypeSet_1, bevt_63_tmpany_phold);
bevl_tst.bemd_0(-173192194, BEL_4_Base.bevn_toAccessorName_0);
bevl_ename = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_65_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_66_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_8));
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_66_tmpany_phold);
bevl_tst.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_64_tmpany_phold);
bevt_67_tmpany_phold = bevl_i.bemd_0(1454846051, BEL_4_Base.bevn_isDeclaredGet_0);
if (bevt_67_tmpany_phold != null && bevt_67_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_67_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevt_71_tmpany_phold = beva_node.bem_heldGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_72_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_1(99049420, BEL_4_Base.bevn_has_1, bevt_72_tmpany_phold);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_68_tmpany_phold != null && bevt_68_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_68_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 126 */ {
bevl_anode = this.bem_getAccessor_1(beva_node);
bevt_73_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_73_tmpany_phold.bemd_1(-1030895937, BEL_4_Base.bevn_propertySet_1, bevl_i);
bevt_74_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_74_tmpany_phold.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevl_ename);
bevt_75_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_76_tmpany_phold = bevl_tst.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_75_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_78_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_77_tmpany_phold.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_78_tmpany_phold);
bevt_80_tmpany_phold = beva_node.bem_heldGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bemd_0(1859739893, BEL_4_Base.bevn_methodsGet_0);
bevt_82_tmpany_phold = bevl_anode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_79_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_81_tmpany_phold, bevl_anode);
bevt_84_tmpany_phold = beva_node.bem_heldGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(-87592446, BEL_4_Base.bevn_orderedMethodsGet_0);
bevt_83_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_86_tmpany_phold = beva_node.bem_containedGet_0();
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_lastGet_0();
bevt_85_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_anode);
bevt_87_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_9));
bevl_sv = bevl_anode.bemd_2(1545079363, BEL_4_Base.bevn_tmpVar_2, bevt_87_tmpany_phold, bevp_build);
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_sv.bemd_1(1880390184, BEL_4_Base.bevn_isArgSet_1, bevt_88_tmpany_phold);
bevl_svn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_svn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_89_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_89_tmpany_phold);
bevl_svn.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_sv);
bevt_91_tmpany_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_90_tmpany_phold = bevt_91_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_90_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_svn);
bevl_svn2 = (new BEC_2_5_4_BuildNode());
bevl_svn2.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_92_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn2.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_92_tmpany_phold);
bevl_svn2.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevl_sv);
bevl_asn = this.bem_getAsNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
bevt_93_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_93_tmpany_phold);
bevt_95_tmpany_phold = bevl_i.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_0(-1354714650, BEL_4_Base.bevn_copy_0);
bevl_rin.bemd_1(942322015, BEL_4_Base.bevn_heldSet_1, bevt_94_tmpany_phold);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_rin);
bevl_asn.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_svn2);
bevt_97_tmpany_phold = bevl_anode.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bemd_0(1990707345, BEL_4_Base.bevn_lastGet_0);
bevt_96_tmpany_phold.bemd_1(2139839746, BEL_4_Base.bevn_addValue_1, bevl_asn);
bevl_svn.bemd_0(1758195374, BEL_4_Base.bevn_addVariable_0);
bevl_rin.bemd_1(-205397975, BEL_4_Base.bevn_syncVariable_1, this);
} /* Line: 160 */
} /* Line: 126 */
 else  /* Line: 87 */ {
break;
} /* Line: 87 */
} /* Line: 87 */
} /* Line: 87 */
 else  /* Line: 77 */ {
bevt_99_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_100_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_99_tmpany_phold.bevi_int == bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_102_tmpany_phold = beva_node.bem_heldGet_0();
if (bevt_102_tmpany_phold == null) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_104_tmpany_phold = (new BEC_2_4_6_TextString(17, bels_10));
bevt_103_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_104_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_103_tmpany_phold);
} /* Line: 168 */
bevt_106_tmpany_phold = beva_node.bem_heldGet_0();
bevt_105_tmpany_phold = bevt_106_tmpany_phold.bemd_0(202317754, BEL_4_Base.bevn_isConstructGet_0);
if (bevt_105_tmpany_phold != null && bevt_105_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_105_tmpany_phold).bevi_bool) /* Line: 170 */ {
bevt_109_tmpany_phold = beva_node.bem_heldGet_0();
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bemd_0(-1583922395, BEL_4_Base.bevn_newNpGet_0);
if (bevt_108_tmpany_phold == null) {
bevt_107_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_107_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_107_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 170 */
 else  /* Line: 170 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 170 */ {
bevt_110_tmpany_phold = beva_node.bem_containedGet_0();
bevl_newNp = bevt_110_tmpany_phold.bem_firstGet_0();
bevt_112_tmpany_phold = bevl_newNp.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_113_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_113_tmpany_phold);
if (bevt_111_tmpany_phold != null && bevt_111_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_111_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevt_115_tmpany_phold = bevl_newNp.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_116_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_116_tmpany_phold);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_114_tmpany_phold).bevi_bool) /* Line: 173 */ {
bevt_119_tmpany_phold = bevl_newNp.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_118_tmpany_phold = bevt_119_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_120_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_11));
bevt_117_tmpany_phold = bevt_118_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_120_tmpany_phold);
if (bevt_117_tmpany_phold != null && bevt_117_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_117_tmpany_phold).bevi_bool) /* Line: 173 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 173 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 173 */
 else  /* Line: 173 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 173 */ {
bevl_newNp = beva_node.bem_secondGet_0();
bevt_122_tmpany_phold = bevl_newNp.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_123_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_121_tmpany_phold = bevt_122_tmpany_phold.bemd_1(1000416164, BEL_4_Base.bevn_notEquals_1, bevt_123_tmpany_phold);
if (bevt_121_tmpany_phold != null && bevt_121_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_121_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevt_125_tmpany_phold = bevo_0;
bevt_126_tmpany_phold = bevl_newNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_124_tmpany_phold = bevt_125_tmpany_phold.bem_add_1(bevt_126_tmpany_phold);
bevt_124_tmpany_phold.bem_print_0();
bevt_128_tmpany_phold = (new BEC_2_4_6_TextString(131, bels_13));
bevt_127_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_128_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_127_tmpany_phold);
} /* Line: 177 */
} /* Line: 175 */
 else  /* Line: 179 */ {
bevt_130_tmpany_phold = bevo_1;
bevt_131_tmpany_phold = bevl_newNp.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_129_tmpany_phold = bevt_130_tmpany_phold.bem_add_1(bevt_131_tmpany_phold);
bevt_129_tmpany_phold.bem_print_0();
bevt_133_tmpany_phold = (new BEC_2_4_6_TextString(51, bels_15));
bevt_132_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_133_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_132_tmpany_phold);
} /* Line: 181 */
} /* Line: 173 */
bevt_134_tmpany_phold = beva_node.bem_heldGet_0();
bevt_135_tmpany_phold = bevl_newNp.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_134_tmpany_phold.bemd_1(-1572840142, BEL_4_Base.bevn_newNpSet_1, bevt_135_tmpany_phold);
bevl_newNp.bemd_0(819712668, BEL_4_Base.bevn_delete_0);
} /* Line: 185 */
bevt_136_tmpany_phold = beva_node.bem_heldGet_0();
bevt_139_tmpany_phold = beva_node.bem_containedGet_0();
bevt_138_tmpany_phold = bevt_139_tmpany_phold.bem_lengthGet_0();
bevt_140_tmpany_phold = bevo_2;
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bem_subtract_1(bevt_140_tmpany_phold);
bevt_136_tmpany_phold.bemd_1(-537631759, BEL_4_Base.bevn_numargsSet_1, bevt_137_tmpany_phold);
bevt_141_tmpany_phold = beva_node.bem_heldGet_0();
bevt_143_tmpany_phold = beva_node.bem_heldGet_0();
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_141_tmpany_phold.bemd_1(-1380410043, BEL_4_Base.bevn_orgNameSet_1, bevt_142_tmpany_phold);
bevt_144_tmpany_phold = beva_node.bem_heldGet_0();
bevt_148_tmpany_phold = beva_node.bem_heldGet_0();
bevt_147_tmpany_phold = bevt_148_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_149_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_16));
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_149_tmpany_phold);
bevt_152_tmpany_phold = beva_node.bem_heldGet_0();
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_0(-548714012, BEL_4_Base.bevn_numargsGet_0);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(92659731, BEL_4_Base.bevn_add_1, bevt_150_tmpany_phold);
bevt_144_tmpany_phold.bemd_1(1222355913, BEL_4_Base.bevn_nameSet_1, bevt_145_tmpany_phold);
bevt_155_tmpany_phold = beva_node.bem_heldGet_0();
bevt_154_tmpany_phold = bevt_155_tmpany_phold.bemd_0(-1391492296, BEL_4_Base.bevn_orgNameGet_0);
bevt_156_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_17));
bevt_153_tmpany_phold = bevt_154_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_156_tmpany_phold);
if (bevt_153_tmpany_phold != null && bevt_153_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_153_tmpany_phold).bevi_bool) /* Line: 190 */ {
bevt_157_tmpany_phold = beva_node.bem_containedGet_0();
bevl_c0 = bevt_157_tmpany_phold.bem_firstGet_0();
if (bevl_c0 == null) {
bevt_158_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_158_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_158_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_160_tmpany_phold = bevl_c0.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_161_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_159_tmpany_phold = bevt_160_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_161_tmpany_phold);
if (bevt_159_tmpany_phold != null && bevt_159_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_159_tmpany_phold).bevi_bool) /* Line: 192 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 192 */ {
bevt_163_tmpany_phold = bevl_c0.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(389100841, BEL_4_Base.bevn_numAssignsGet_0);
bevt_162_tmpany_phold.bemd_0(-1205852557, BEL_4_Base.bevn_incrementValue_0);
} /* Line: 193 */
bevt_164_tmpany_phold = beva_node.bem_containedGet_0();
bevl_c1 = bevt_164_tmpany_phold.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_165_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_165_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevt_167_tmpany_phold = bevl_c1.bemd_0(-2087681086, BEL_4_Base.bevn_typenameGet_0);
bevt_168_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_168_tmpany_phold);
if (bevt_166_tmpany_phold != null && bevt_166_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_166_tmpany_phold).bevi_bool) /* Line: 196 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 196 */ {
bevt_171_tmpany_phold = bevl_c1.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_172_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_18));
bevt_169_tmpany_phold = bevt_170_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_172_tmpany_phold);
if (bevt_169_tmpany_phold != null && bevt_169_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_169_tmpany_phold).bevi_bool) /* Line: 201 */ {
bevt_173_tmpany_phold = beva_node.bem_heldGet_0();
bevt_174_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_173_tmpany_phold.bemd_1(1489916809, BEL_4_Base.bevn_isOnceSet_1, bevt_174_tmpany_phold);
} /* Line: 202 */
bevt_177_tmpany_phold = bevl_c1.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_176_tmpany_phold = bevt_177_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_178_tmpany_phold = (new BEC_2_4_6_TextString(6, bels_19));
bevt_175_tmpany_phold = bevt_176_tmpany_phold.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_178_tmpany_phold);
if (bevt_175_tmpany_phold != null && bevt_175_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_175_tmpany_phold).bevi_bool) /* Line: 204 */ {
bevt_179_tmpany_phold = beva_node.bem_heldGet_0();
bevt_180_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_179_tmpany_phold.bemd_1(1373349483, BEL_4_Base.bevn_isManySet_1, bevt_180_tmpany_phold);
} /* Line: 205 */
} /* Line: 204 */
} /* Line: 196 */
} /* Line: 190 */
 else  /* Line: 77 */ {
bevt_182_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_183_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_182_tmpany_phold.bevi_int == bevt_183_tmpany_phold.bevi_int) {
bevt_181_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_181_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_181_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevl_bn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_185_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_185_tmpany_phold == null) {
bevt_184_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_184_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_184_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevt_188_tmpany_phold = beva_node.bem_containedGet_0();
bevt_187_tmpany_phold = bevt_188_tmpany_phold.bem_lastGet_0();
if (bevt_187_tmpany_phold == null) {
bevt_186_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_186_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_186_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 211 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 211 */
 else  /* Line: 211 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 211 */ {
bevt_191_tmpany_phold = beva_node.bem_containedGet_0();
bevt_190_tmpany_phold = bevt_191_tmpany_phold.bem_lastGet_0();
bevt_189_tmpany_phold = bevt_190_tmpany_phold.bemd_0(-1595262430, BEL_4_Base.bevn_nlcGet_0);
bevl_bn.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevt_189_tmpany_phold);
} /* Line: 212 */
 else  /* Line: 213 */ {
bevl_bn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
} /* Line: 214 */
bevt_192_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
bevl_bn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_192_tmpany_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_bn);
} /* Line: 217 */
 else  /* Line: 77 */ {
bevt_194_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_195_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_194_tmpany_phold.bevi_int == bevt_195_tmpany_phold.bevi_int) {
bevt_193_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_193_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_193_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevl_pn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_197_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_197_tmpany_phold == null) {
bevt_196_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_196_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_196_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_200_tmpany_phold = beva_node.bem_containedGet_0();
bevt_199_tmpany_phold = bevt_200_tmpany_phold.bem_lastGet_0();
if (bevt_199_tmpany_phold == null) {
bevt_198_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_198_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_198_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_203_tmpany_phold = beva_node.bem_containedGet_0();
bevt_202_tmpany_phold = bevt_203_tmpany_phold.bem_lastGet_0();
bevt_201_tmpany_phold = bevt_202_tmpany_phold.bemd_0(-1595262430, BEL_4_Base.bevn_nlcGet_0);
bevl_pn.bemd_1(-1584180177, BEL_4_Base.bevn_nlcSet_1, bevt_201_tmpany_phold);
} /* Line: 221 */
 else  /* Line: 222 */ {
bevl_pn.bemd_1(1487970429, BEL_4_Base.bevn_copyLoc_1, beva_node);
} /* Line: 223 */
bevt_204_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
bevl_pn.bemd_1(-2076598833, BEL_4_Base.bevn_typenameSet_1, bevt_204_tmpany_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_pn);
} /* Line: 226 */
} /* Line: 77 */
} /* Line: 77 */
} /* Line: 77 */
} /* Line: 77 */
bevt_205_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_205_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_classnpGet_0() throws Throwable {
return bevp_classnp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass12 bem_classnpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {21, 22, 22, 23, 24, 24, 25, 25, 26, 27, 27, 28, 29, 30, 30, 31, 32, 32, 33, 34, 35, 35, 36, 37, 38, 39, 40, 40, 41, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 46, 47, 51, 52, 52, 53, 54, 54, 55, 56, 57, 57, 58, 58, 59, 60, 64, 65, 65, 66, 67, 67, 68, 69, 77, 77, 77, 77, 78, 78, 78, 78, 79, 79, 79, 80, 80, 84, 84, 84, 84, 85, 85, 86, 87, 87, 87, 87, 88, 88, 89, 89, 89, 90, 90, 91, 92, 93, 93, 93, 93, 94, 94, 94, 94, 94, 94, 0, 0, 0, 96, 97, 97, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 101, 101, 102, 102, 102, 103, 103, 103, 104, 105, 106, 107, 107, 108, 108, 108, 109, 110, 110, 110, 111, 111, 111, 112, 113, 114, 114, 116, 116, 121, 121, 121, 122, 122, 123, 124, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 0, 0, 0, 128, 129, 129, 130, 130, 131, 131, 131, 132, 132, 132, 133, 133, 133, 133, 133, 134, 134, 134, 135, 135, 135, 137, 137, 138, 138, 139, 140, 141, 141, 142, 144, 144, 144, 145, 146, 147, 147, 148, 150, 151, 152, 153, 153, 154, 154, 154, 155, 156, 157, 157, 157, 159, 160, 166, 166, 166, 166, 167, 167, 167, 168, 168, 168, 170, 170, 170, 170, 170, 170, 0, 0, 0, 171, 171, 172, 172, 172, 173, 173, 173, 173, 173, 173, 173, 0, 0, 0, 174, 175, 175, 175, 176, 176, 176, 176, 177, 177, 177, 180, 180, 180, 180, 181, 181, 181, 184, 184, 184, 185, 187, 187, 187, 187, 187, 187, 188, 188, 188, 188, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 190, 190, 190, 190, 191, 191, 192, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 195, 195, 196, 196, 196, 196, 196, 0, 0, 0, 201, 201, 201, 201, 202, 202, 202, 204, 204, 204, 204, 205, 205, 205, 209, 209, 209, 209, 210, 211, 211, 211, 211, 211, 211, 211, 0, 0, 0, 212, 212, 212, 212, 214, 216, 216, 217, 218, 218, 218, 218, 219, 220, 220, 220, 220, 220, 220, 220, 0, 0, 0, 221, 221, 221, 221, 223, 225, 225, 226, 228, 228, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 134, 135, 136, 137, 138, 139, 140, 141, 367, 368, 369, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 386, 387, 388, 393, 394, 395, 396, 397, 398, 399, 402, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 419, 420, 421, 422, 423, 425, 428, 432, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 475, 476, 479, 480, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 496, 497, 498, 499, 500, 502, 505, 509, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 574, 575, 576, 581, 582, 583, 588, 589, 590, 591, 593, 594, 596, 597, 598, 603, 604, 607, 611, 614, 615, 616, 617, 618, 620, 621, 622, 624, 625, 626, 627, 629, 632, 636, 639, 640, 641, 642, 644, 645, 646, 647, 648, 649, 650, 654, 655, 656, 657, 658, 659, 660, 663, 664, 665, 666, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 693, 694, 695, 700, 701, 702, 703, 705, 708, 712, 715, 716, 717, 719, 720, 721, 726, 727, 728, 729, 731, 734, 738, 741, 742, 743, 744, 746, 747, 748, 750, 751, 752, 753, 755, 756, 757, 763, 764, 765, 770, 771, 772, 773, 778, 779, 780, 781, 786, 787, 790, 794, 797, 798, 799, 800, 803, 805, 806, 807, 810, 811, 812, 817, 818, 819, 820, 825, 826, 827, 828, 833, 834, 837, 841, 844, 845, 846, 847, 850, 852, 853, 854, 860, 861, 864, 867};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 21 60
new 1 21 60
assign 1 22 61
VARGet 0 22 61
typenameSet 1 22 62
assign 1 23 63
new 0 23 63
assign 1 24 64
new 0 24 64
nameSet 1 24 65
assign 1 25 66
new 0 25 66
isTypedSet 1 25 67
namepathSet 1 26 68
assign 1 27 69
new 0 27 69
isArgSet 1 27 70
heldSet 1 28 71
assign 1 29 72
new 1 29 72
assign 1 30 73
METHODGet 0 30 73
typenameSet 1 30 74
assign 1 31 75
new 0 31 75
assign 1 32 76
new 0 32 76
isGenAccessorSet 1 32 77
heldSet 1 33 78
assign 1 34 79
new 1 34 79
assign 1 35 80
PARENSGet 0 35 80
typenameSet 1 35 81
addValue 1 36 82
addValue 1 37 83
addVariable 0 38 84
assign 1 39 85
new 1 39 85
assign 1 40 86
BRACESGet 0 40 86
typenameSet 1 40 87
addValue 1 41 88
assign 1 42 89
new 0 42 89
rtypeSet 1 42 90
assign 1 43 91
rtypeGet 0 43 91
assign 1 43 92
new 0 43 92
isSelfSet 1 43 93
assign 1 44 94
rtypeGet 0 44 94
assign 1 44 95
new 0 44 95
isThisSet 1 44 96
assign 1 45 97
rtypeGet 0 45 97
assign 1 45 98
new 0 45 98
isTypedSet 1 45 99
assign 1 46 100
rtypeGet 0 46 100
assign 1 46 101
new 0 46 101
assign 1 46 102
new 1 46 102
namepathSet 1 46 103
return 1 47 104
assign 1 51 114
new 1 51 114
assign 1 52 115
CALLGet 0 52 115
typenameSet 1 52 116
assign 1 53 117
new 0 53 117
assign 1 54 118
new 0 54 118
nameSet 1 54 119
heldSet 1 55 120
assign 1 56 121
new 1 56 121
assign 1 57 122
VARGet 0 57 122
typenameSet 1 57 123
assign 1 58 124
new 0 58 124
heldSet 1 58 125
addValue 1 59 126
return 1 60 127
assign 1 64 134
new 1 64 134
assign 1 65 135
CALLGet 0 65 135
typenameSet 1 65 136
assign 1 66 137
new 0 66 137
assign 1 67 138
new 0 67 138
nameSet 1 67 139
heldSet 1 68 140
return 1 69 141
assign 1 77 367
typenameGet 0 77 367
assign 1 77 368
METHODGet 0 77 368
assign 1 77 369
equals 1 77 374
assign 1 78 375
containedGet 0 78 375
assign 1 78 376
firstGet 0 78 376
assign 1 78 377
containedGet 0 78 377
assign 1 78 378
firstGet 0 78 378
assign 1 79 379
heldGet 0 79 379
assign 1 79 380
new 0 79 380
isTypedSet 1 79 381
assign 1 80 382
heldGet 0 80 382
namepathSet 1 80 383
assign 1 84 386
typenameGet 0 84 386
assign 1 84 387
CLASSGet 0 84 387
assign 1 84 388
equals 1 84 393
assign 1 85 394
heldGet 0 85 394
assign 1 85 395
namepathGet 0 85 395
assign 1 86 396
new 0 86 396
assign 1 87 397
heldGet 0 87 397
assign 1 87 398
orderedVarsGet 0 87 398
assign 1 87 399
iteratorGet 0 87 399
assign 1 87 402
hasNextGet 0 87 402
assign 1 88 404
nextGet 0 88 404
assign 1 88 405
heldGet 0 88 405
assign 1 89 406
nameGet 0 89 406
assign 1 89 407
copy 0 89 407
nameSet 1 89 408
assign 1 90 409
new 0 90 409
accessorTypeSet 1 90 410
toAccessorName 0 91 411
assign 1 92 412
nameGet 0 92 412
assign 1 93 413
nameGet 0 93 413
assign 1 93 414
new 0 93 414
assign 1 93 415
add 1 93 415
nameSet 1 93 416
assign 1 94 417
isDeclaredGet 0 94 417
assign 1 94 419
heldGet 0 94 419
assign 1 94 420
methodsGet 0 94 420
assign 1 94 421
nameGet 0 94 421
assign 1 94 422
has 1 94 422
assign 1 94 423
not 0 94 423
assign 1 0 425
assign 1 0 428
assign 1 0 432
assign 1 96 435
getAccessor 1 96 435
assign 1 97 436
heldGet 0 97 436
propertySet 1 97 437
assign 1 98 438
heldGet 0 98 438
orgNameSet 1 98 439
assign 1 99 440
heldGet 0 99 440
assign 1 99 441
nameGet 0 99 441
nameSet 1 99 442
assign 1 100 443
heldGet 0 100 443
assign 1 100 444
new 0 100 444
numargsSet 1 100 445
assign 1 101 446
heldGet 0 101 446
assign 1 101 447
methodsGet 0 101 447
assign 1 101 448
heldGet 0 101 448
assign 1 101 449
nameGet 0 101 449
put 2 101 450
assign 1 102 451
heldGet 0 102 451
assign 1 102 452
orderedMethodsGet 0 102 452
addValue 1 102 453
assign 1 103 454
containedGet 0 103 454
assign 1 103 455
lastGet 0 103 455
addValue 1 103 456
assign 1 104 457
getRetNode 1 104 457
assign 1 105 458
new 1 105 458
copyLoc 1 106 459
assign 1 107 460
VARGet 0 107 460
typenameSet 1 107 461
assign 1 108 462
nameGet 0 108 462
assign 1 108 463
copy 0 108 463
heldSet 1 108 464
addValue 1 109 465
assign 1 110 466
containedGet 0 110 466
assign 1 110 467
lastGet 0 110 467
addValue 1 110 468
assign 1 111 469
containedGet 0 111 469
assign 1 111 470
firstGet 0 111 470
syncVariable 1 111 471
syncVariable 1 112 472
assign 1 113 473
isTypedGet 0 113 473
assign 1 114 475
heldGet 0 114 475
rtypeSet 1 114 476
assign 1 116 479
heldGet 0 116 479
rtypeSet 1 116 480
assign 1 121 483
nameGet 0 121 483
assign 1 121 484
copy 0 121 484
nameSet 1 121 485
assign 1 122 486
new 0 122 486
accessorTypeSet 1 122 487
toAccessorName 0 123 488
assign 1 124 489
nameGet 0 124 489
assign 1 125 490
nameGet 0 125 490
assign 1 125 491
new 0 125 491
assign 1 125 492
add 1 125 492
nameSet 1 125 493
assign 1 126 494
isDeclaredGet 0 126 494
assign 1 126 496
heldGet 0 126 496
assign 1 126 497
methodsGet 0 126 497
assign 1 126 498
nameGet 0 126 498
assign 1 126 499
has 1 126 499
assign 1 126 500
not 0 126 500
assign 1 0 502
assign 1 0 505
assign 1 0 509
assign 1 128 512
getAccessor 1 128 512
assign 1 129 513
heldGet 0 129 513
propertySet 1 129 514
assign 1 130 515
heldGet 0 130 515
orgNameSet 1 130 516
assign 1 131 517
heldGet 0 131 517
assign 1 131 518
nameGet 0 131 518
nameSet 1 131 519
assign 1 132 520
heldGet 0 132 520
assign 1 132 521
new 0 132 521
numargsSet 1 132 522
assign 1 133 523
heldGet 0 133 523
assign 1 133 524
methodsGet 0 133 524
assign 1 133 525
heldGet 0 133 525
assign 1 133 526
nameGet 0 133 526
put 2 133 527
assign 1 134 528
heldGet 0 134 528
assign 1 134 529
orderedMethodsGet 0 134 529
addValue 1 134 530
assign 1 135 531
containedGet 0 135 531
assign 1 135 532
lastGet 0 135 532
addValue 1 135 533
assign 1 137 534
new 0 137 534
assign 1 137 535
tmpVar 2 137 535
assign 1 138 536
new 0 138 536
isArgSet 1 138 537
assign 1 139 538
new 1 139 538
copyLoc 1 140 539
assign 1 141 540
VARGet 0 141 540
typenameSet 1 141 541
heldSet 1 142 542
assign 1 144 543
containedGet 0 144 543
assign 1 144 544
firstGet 0 144 544
addValue 1 144 545
assign 1 145 546
new 0 145 546
copyLoc 1 146 547
assign 1 147 548
VARGet 0 147 548
typenameSet 1 147 549
heldSet 1 148 550
assign 1 150 551
getAsNode 1 150 551
assign 1 151 552
new 1 151 552
copyLoc 1 152 553
assign 1 153 554
VARGet 0 153 554
typenameSet 1 153 555
assign 1 154 556
nameGet 0 154 556
assign 1 154 557
copy 0 154 557
heldSet 1 154 558
addValue 1 155 559
addValue 1 156 560
assign 1 157 561
containedGet 0 157 561
assign 1 157 562
lastGet 0 157 562
addValue 1 157 563
addVariable 0 159 564
syncVariable 1 160 565
assign 1 166 574
typenameGet 0 166 574
assign 1 166 575
CALLGet 0 166 575
assign 1 166 576
equals 1 166 581
assign 1 167 582
heldGet 0 167 582
assign 1 167 583
undef 1 167 588
assign 1 168 589
new 0 168 589
assign 1 168 590
new 2 168 590
throw 1 168 591
assign 1 170 593
heldGet 0 170 593
assign 1 170 594
isConstructGet 0 170 594
assign 1 170 596
heldGet 0 170 596
assign 1 170 597
newNpGet 0 170 597
assign 1 170 598
undef 1 170 603
assign 1 0 604
assign 1 0 607
assign 1 0 611
assign 1 171 614
containedGet 0 171 614
assign 1 171 615
firstGet 0 171 615
assign 1 172 616
typenameGet 0 172 616
assign 1 172 617
NAMEPATHGet 0 172 617
assign 1 172 618
notEquals 1 172 618
assign 1 173 620
typenameGet 0 173 620
assign 1 173 621
VARGet 0 173 621
assign 1 173 622
equals 1 173 622
assign 1 173 624
heldGet 0 173 624
assign 1 173 625
nameGet 0 173 625
assign 1 173 626
new 0 173 626
assign 1 173 627
equals 1 173 627
assign 1 0 629
assign 1 0 632
assign 1 0 636
assign 1 174 639
secondGet 0 174 639
assign 1 175 640
typenameGet 0 175 640
assign 1 175 641
NAMEPATHGet 0 175 641
assign 1 175 642
notEquals 1 175 642
assign 1 176 644
new 0 176 644
assign 1 176 645
toString 0 176 645
assign 1 176 646
add 1 176 646
print 0 176 647
assign 1 177 648
new 0 177 648
assign 1 177 649
new 2 177 649
throw 1 177 650
assign 1 180 654
new 0 180 654
assign 1 180 655
toString 0 180 655
assign 1 180 656
add 1 180 656
print 0 180 657
assign 1 181 658
new 0 181 658
assign 1 181 659
new 2 181 659
throw 1 181 660
assign 1 184 663
heldGet 0 184 663
assign 1 184 664
heldGet 0 184 664
newNpSet 1 184 665
delete 0 185 666
assign 1 187 668
heldGet 0 187 668
assign 1 187 669
containedGet 0 187 669
assign 1 187 670
lengthGet 0 187 670
assign 1 187 671
new 0 187 671
assign 1 187 672
subtract 1 187 672
numargsSet 1 187 673
assign 1 188 674
heldGet 0 188 674
assign 1 188 675
heldGet 0 188 675
assign 1 188 676
nameGet 0 188 676
orgNameSet 1 188 677
assign 1 189 678
heldGet 0 189 678
assign 1 189 679
heldGet 0 189 679
assign 1 189 680
nameGet 0 189 680
assign 1 189 681
new 0 189 681
assign 1 189 682
add 1 189 682
assign 1 189 683
heldGet 0 189 683
assign 1 189 684
numargsGet 0 189 684
assign 1 189 685
toString 0 189 685
assign 1 189 686
add 1 189 686
nameSet 1 189 687
assign 1 190 688
heldGet 0 190 688
assign 1 190 689
orgNameGet 0 190 689
assign 1 190 690
new 0 190 690
assign 1 190 691
equals 1 190 691
assign 1 191 693
containedGet 0 191 693
assign 1 191 694
firstGet 0 191 694
assign 1 192 695
def 1 192 700
assign 1 192 701
typenameGet 0 192 701
assign 1 192 702
VARGet 0 192 702
assign 1 192 703
equals 1 192 703
assign 1 0 705
assign 1 0 708
assign 1 0 712
assign 1 193 715
heldGet 0 193 715
assign 1 193 716
numAssignsGet 0 193 716
incrementValue 0 193 717
assign 1 195 719
containedGet 0 195 719
assign 1 195 720
secondGet 0 195 720
assign 1 196 721
def 1 196 726
assign 1 196 727
typenameGet 0 196 727
assign 1 196 728
CALLGet 0 196 728
assign 1 196 729
equals 1 196 729
assign 1 0 731
assign 1 0 734
assign 1 0 738
assign 1 201 741
heldGet 0 201 741
assign 1 201 742
nameGet 0 201 742
assign 1 201 743
new 0 201 743
assign 1 201 744
equals 1 201 744
assign 1 202 746
heldGet 0 202 746
assign 1 202 747
new 0 202 747
isOnceSet 1 202 748
assign 1 204 750
heldGet 0 204 750
assign 1 204 751
nameGet 0 204 751
assign 1 204 752
new 0 204 752
assign 1 204 753
equals 1 204 753
assign 1 205 755
heldGet 0 205 755
assign 1 205 756
new 0 205 756
isManySet 1 205 757
assign 1 209 763
typenameGet 0 209 763
assign 1 209 764
BRACESGet 0 209 764
assign 1 209 765
equals 1 209 770
assign 1 210 771
new 1 210 771
assign 1 211 772
containedGet 0 211 772
assign 1 211 773
def 1 211 778
assign 1 211 779
containedGet 0 211 779
assign 1 211 780
lastGet 0 211 780
assign 1 211 781
def 1 211 786
assign 1 0 787
assign 1 0 790
assign 1 0 794
assign 1 212 797
containedGet 0 212 797
assign 1 212 798
lastGet 0 212 798
assign 1 212 799
nlcGet 0 212 799
nlcSet 1 212 800
copyLoc 1 214 803
assign 1 216 805
RBRACESGet 0 216 805
typenameSet 1 216 806
addValue 1 217 807
assign 1 218 810
typenameGet 0 218 810
assign 1 218 811
PARENSGet 0 218 811
assign 1 218 812
equals 1 218 817
assign 1 219 818
new 1 219 818
assign 1 220 819
containedGet 0 220 819
assign 1 220 820
def 1 220 825
assign 1 220 826
containedGet 0 220 826
assign 1 220 827
lastGet 0 220 827
assign 1 220 828
def 1 220 833
assign 1 0 834
assign 1 0 837
assign 1 0 841
assign 1 221 844
containedGet 0 221 844
assign 1 221 845
lastGet 0 221 845
assign 1 221 846
nlcGet 0 221 846
nlcSet 1 221 847
copyLoc 1 223 850
assign 1 225 852
RPARENSGet 0 225 852
typenameSet 1 225 853
addValue 1 226 854
assign 1 228 860
nextDescendGet 0 228 860
return 1 228 861
return 1 0 864
assign 1 0 867
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1755995201: return bem_transGet_0();
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -644675716: return bem_ntypesGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case 487303277: return bem_classnpGet_0();
case -493012039: return bem_buildGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
case -229958684: return bem_constGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1658666490: return bem_otherClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -2055890305: return bem_getRetNode_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 498385530: return bem_classnpSet_1(bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 654182780: return bem_getAsNode_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case -1438955473: return bem_getAccessor_1(bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass12();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass12.bevs_inst = (BEC_3_5_5_6_BuildVisitPass12)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass12.bevs_inst;
}
}
