package be;
/* IO:File: source/base/Logic.be */
public final class BEC_2_5_4_LogicBool extends BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }

   
    public boolean bevi_bool;
    public BEC_2_5_4_LogicBool(boolean bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bels_2 = {0x31};
private static byte[] bels_3 = {0x30};
private static byte[] bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bels_5 = {0x74,0x72,0x75,0x65};
private static byte[] bels_6 = {0x66,0x61,0x6C,0x73,0x65};
public static BEC_2_5_4_LogicBool bevs_inst;
public BEC_2_5_4_LogicBool bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 46 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 47 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(581408689, BEL_4_Base.bevn_equals_1, bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 53 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 53 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 54 */
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (this.bevi_bool) /* Line: 64 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_2));
return bevt_0_tmpany_phold;
} /* Line: 65 */
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_3));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_4));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (this.bevi_bool) /* Line: 75 */ {
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 76 */
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (this.bevi_bool) /* Line: 90 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 91 */
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (this.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_5));
return bevt_0_tmpany_phold;
} /* Line: 98 */
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_6));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_copy_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {46, 46, 47, 47, 49, 49, 53, 53, 53, 53, 0, 0, 0, 54, 54, 56, 56, 60, 60, 65, 65, 67, 67, 71, 71, 76, 76, 78, 78, 82, 82, 86, 86, 91, 91, 93, 93, 98, 98, 100, 100, 104};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {28, 29, 31, 32, 34, 35, 44, 49, 50, 51, 53, 56, 60, 63, 64, 66, 67, 71, 72, 78, 79, 81, 82, 86, 87, 93, 94, 96, 97, 101, 102, 106, 107, 113, 114, 116, 117, 123, 124, 126, 127, 130};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 46 28
new 0 46 28
assign 1 46 29
equals 1 46 29
assign 1 47 31
new 0 47 31
return 1 47 32
assign 1 49 34
new 0 49 34
return 1 49 35
assign 1 53 44
def 1 53 49
assign 1 53 50
new 0 53 50
assign 1 53 51
equals 1 53 51
assign 1 0 53
assign 1 0 56
assign 1 0 60
assign 1 54 63
new 0 54 63
return 1 54 64
assign 1 56 66
new 0 56 66
return 1 56 67
assign 1 60 71
new 0 60 71
return 1 60 72
assign 1 65 78
new 0 65 78
return 1 65 79
assign 1 67 81
new 0 67 81
return 1 67 82
assign 1 71 86
new 0 71 86
return 1 71 87
assign 1 76 93
new 0 76 93
return 1 76 94
assign 1 78 96
new 0 78 96
return 1 78 97
assign 1 82 101
new 0 82 101
return 1 82 102
assign 1 86 106
new 0 86 106
return 1 86 107
assign 1 91 113
new 0 91 113
return 1 91 114
assign 1 93 116
new 0 93 116
return 1 93 117
assign 1 98 123
new 0 98 123
return 1 98 124
assign 1 100 126
new 0 100 126
return 1 100 127
return 1 104 130
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 105008580: return bem_not_0();
case -1046151292: return bem_decrement_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case 443668840: return bem_methodNotDefined_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1085372256: return bem_increment_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1254042251: return bem_checkDefNew_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_4_LogicBool();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_4_LogicBool.bevs_inst = (BEC_2_5_4_LogicBool)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_4_LogicBool.bevs_inst;
}
}
