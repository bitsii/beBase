package be;
/* IO:File: source/extended/Serialize.be */
public class BEC_3_6_10_7_SystemSerializerSession extends BEC_2_6_6_SystemObject {
public BEC_3_6_10_7_SystemSerializerSession() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x3A,0x53,0x65,0x73,0x73,0x69,0x6F,0x6E};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static BEC_3_6_10_7_SystemSerializerSession bevs_inst;
public BEC_2_9_3_ContainerMap bevp_classTagMap;
public BEC_2_4_3_MathInt bevp_classTagCount;
public BEC_2_4_3_MathInt bevp_serialCount;
public BEC_2_9_11_ContainerIdentityMap bevp_unique;
public BEC_2_6_6_SystemObject bevp_instWriter;
public BEC_3_6_10_7_SystemSerializerSession bem_new_0() throws Throwable {
bevp_classTagMap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classTagCount = (new BEC_2_4_3_MathInt(1));
bevp_serialCount = (new BEC_2_4_3_MathInt(1));
bevp_unique = (new BEC_2_9_11_ContainerIdentityMap()).bem_new_0();
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_new_1(BEC_2_6_6_SystemObject beva__instWriter) throws Throwable {
this.bem_new_0();
bevp_instWriter = beva__instWriter;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classTagMapGet_0() throws Throwable {
return bevp_classTagMap;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_classTagCountGet_0() throws Throwable {
return bevp_classTagCount;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_serialCountGet_0() throws Throwable {
return bevp_serialCount;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_serialCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_uniqueGet_0() throws Throwable {
return bevp_unique;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_uniqueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instWriterGet_0() throws Throwable {
return bevp_instWriter;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_instWriterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_instWriter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {30, 31, 32, 33, 39, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 16, 17, 21, 22, 26, 29, 33, 36, 40, 43, 47, 50, 54, 57};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 30 14
new 0 30 14
assign 1 31 15
new 0 31 15
assign 1 32 16
new 0 32 16
assign 1 33 17
new 0 33 17
new 0 39 21
assign 1 40 22
return 1 0 26
assign 1 0 29
return 1 0 33
assign 1 0 36
return 1 0 40
assign 1 0 43
return 1 0 47
assign 1 0 50
return 1 0 54
assign 1 0 57
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case -1942660042: return bem_uniqueGet_0();
case 1916882605: return bem_classTagMapGet_0();
case 1940066990: return bem_instWriterGet_0();
case 104713553: return bem_new_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case -1516029350: return bem_classTagCountGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 589965004: return bem_serialCountGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -1504947097: return bem_classTagCountSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 601047257: return bem_serialCountSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1951149243: return bem_instWriterSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1931577789: return bem_uniqueSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1927964858: return bem_classTagMapSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 104713554: return bem_new_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_6_10_7_SystemSerializerSession();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_6_10_7_SystemSerializerSession.bevs_inst = (BEC_3_6_10_7_SystemSerializerSession)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_6_10_7_SystemSerializerSession.bevs_inst;
}
}
