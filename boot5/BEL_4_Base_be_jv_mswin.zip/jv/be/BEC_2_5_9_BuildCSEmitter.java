package be;
/* IO:File: source/build/CSEmitter.be */
public final class BEC_2_5_9_BuildCSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x63,0x73};
private static byte[] bels_1 = {0x2E,0x63,0x73};
private static byte[] bels_2 = {};
private static byte[] bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_3, 5));
private static byte[] bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bels_5 = {0x29,0x20,0x7B};
private static byte[] bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_6, 31));
private static byte[] bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_7, 2));
private static byte[] bels_8 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bels_9 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bels_10 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bels_11 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bels_12 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bels_13 = {0x62,0x61,0x73,0x65};
private static byte[] bels_14 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_14, 15));
private static byte[] bels_15 = {0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_15, 1));
private static byte[] bels_16 = {0x30,0x78};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_16, 2));
private static byte[] bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_6 = (new BEC_2_4_6_TextString(bels_17, 18));
private static byte[] bels_18 = {0x20};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_18, 1));
private static byte[] bels_19 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_19, 38));
private static byte[] bels_20 = {0x20,0x7B};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_20, 2));
private static byte[] bels_21 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bels_22 = {0x29,0x29,0x20,0x7B};
private static byte[] bels_23 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bels_25 = {0x22,0x3B};
private static byte[] bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6E,0x65,0x77,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bels_27 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_27, 10));
private static byte[] bels_28 = {0x20,0x7B};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_28, 2));
private static byte[] bels_29 = {0x7D};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_29, 1));
private static byte[] bels_30 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_30, 3));
public static BEC_2_5_9_BuildCSEmitter bevs_inst;
public BEC_2_6_6_SystemObject bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bels_2));
super.bem_new_1(beva__build);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch = bevp_methodCatch.bem_increment_0();
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(25, bels_4));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_5));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold, bevt_12_tmpany_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_8));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 43 */
 else  /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 43 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 43 */ {
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(7, bels_9));
return bevt_4_tmpany_phold;
} /* Line: 44 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(15, bels_10));
return bevt_5_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(23, bels_11));
return bevt_3_tmpany_phold;
} /* Line: 51 */
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(16, bels_12));
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_13));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(13, bels_21));
bevt_6_tmpany_phold = bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_22));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(28, bels_23));
bevt_9_tmpany_phold = bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(32, bels_24));
bevt_13_tmpany_phold = bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_25));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public BEC_2_4_6_TextString bem_overrideSmtdDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(18, bels_26));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = this.bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevo_10;
bevt_4_tmpany_phold = this.bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 21, 22, 26, 30, 30, 30, 31, 32, 32, 32, 32, 32, 32, 34, 34, 34, 34, 34, 34, 34, 34, 34, 34, 39, 39, 43, 0, 43, 43, 43, 0, 0, 0, 0, 0, 44, 44, 46, 46, 50, 50, 50, 0, 0, 0, 51, 51, 53, 53, 57, 57, 61, 61, 61, 61, 61, 66, 67, 68, 68, 68, 69, 75, 75, 75, 75, 75, 75, 79, 79, 79, 79, 79, 80, 80, 80, 80, 80, 80, 81, 81, 81, 82, 82, 82, 82, 82, 82, 82, 82, 83, 87, 87, 91, 91, 91, 95, 95, 95, 95, 95, 95, 95, 99, 99, 103, 103, 103, 107, 107, 107, 107, 112, 112};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {54, 55, 56, 57, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 102, 103, 112, 114, 117, 122, 123, 125, 128, 132, 135, 138, 142, 143, 145, 146, 154, 159, 160, 162, 165, 169, 172, 173, 175, 176, 180, 181, 188, 189, 190, 191, 192, 198, 199, 200, 201, 202, 203, 212, 213, 214, 215, 216, 217, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 265, 266, 271, 272, 273, 282, 283, 284, 285, 286, 287, 288, 292, 293, 298, 299, 300, 306, 307, 308, 309, 313, 314};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 54
new 0 20 54
assign 1 21 55
new 0 21 55
assign 1 22 56
new 0 22 56
new 1 26 57
assign 1 30 78
new 0 30 78
assign 1 30 79
toString 0 30 79
assign 1 30 80
add 1 30 80
assign 1 31 81
increment 0 31 81
assign 1 32 82
new 0 32 82
assign 1 32 83
addValue 1 32 83
assign 1 32 84
addValue 1 32 84
assign 1 32 85
new 0 32 85
assign 1 32 86
addValue 1 32 86
addValue 1 32 87
assign 1 34 88
containedGet 0 34 88
assign 1 34 89
firstGet 0 34 89
assign 1 34 90
containedGet 0 34 90
assign 1 34 91
firstGet 0 34 91
assign 1 34 92
new 0 34 92
assign 1 34 93
add 1 34 93
assign 1 34 94
new 0 34 94
assign 1 34 95
add 1 34 95
assign 1 34 96
finalAssign 3 34 96
addValue 1 34 97
assign 1 39 102
new 0 39 102
return 1 39 103
assign 1 43 112
isFinalGet 0 43 112
assign 1 0 114
assign 1 43 117
def 1 43 122
assign 1 43 123
isFinalGet 0 43 123
assign 1 0 125
assign 1 0 128
assign 1 0 132
assign 1 0 135
assign 1 0 138
assign 1 44 142
new 0 44 142
return 1 44 143
assign 1 46 145
new 0 46 145
return 1 46 146
assign 1 50 154
def 1 50 159
assign 1 50 160
isFinalGet 0 50 160
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 51 172
new 0 51 172
return 1 51 173
assign 1 53 175
new 0 53 175
return 1 53 176
assign 1 57 180
new 0 57 180
return 1 57 181
assign 1 61 188
new 0 61 188
assign 1 61 189
add 1 61 189
assign 1 61 190
new 0 61 190
assign 1 61 191
add 1 61 191
return 1 61 192
getCode 2 66 198
assign 1 67 199
toHexString 1 67 199
assign 1 68 200
new 0 68 200
assign 1 68 201
once 0 68 201
addValue 1 68 202
addValue 1 69 203
assign 1 75 212
new 0 75 212
assign 1 75 213
add 1 75 213
assign 1 75 214
new 0 75 214
assign 1 75 215
add 1 75 215
assign 1 75 216
add 1 75 216
return 1 75 217
assign 1 79 239
new 0 79 239
assign 1 79 240
add 1 79 240
assign 1 79 241
new 0 79 241
assign 1 79 242
add 1 79 242
assign 1 79 243
add 1 79 243
assign 1 80 244
new 0 80 244
assign 1 80 245
addValue 1 80 245
assign 1 80 246
addValue 1 80 246
assign 1 80 247
new 0 80 247
assign 1 80 248
addValue 1 80 248
addValue 1 80 249
assign 1 81 250
new 0 81 250
assign 1 81 251
addValue 1 81 251
addValue 1 81 252
assign 1 82 253
new 0 82 253
assign 1 82 254
addValue 1 82 254
assign 1 82 255
outputPlatformGet 0 82 255
assign 1 82 256
nameGet 0 82 256
assign 1 82 257
addValue 1 82 257
assign 1 82 258
new 0 82 258
assign 1 82 259
addValue 1 82 259
addValue 1 82 260
return 1 83 261
assign 1 87 265
new 0 87 265
return 1 87 266
assign 1 91 271
libNameGet 0 91 271
assign 1 91 272
beginNs 1 91 272
return 1 91 273
assign 1 95 282
new 0 95 282
assign 1 95 283
libNs 1 95 283
assign 1 95 284
add 1 95 284
assign 1 95 285
new 0 95 285
assign 1 95 286
add 1 95 286
assign 1 95 287
add 1 95 287
return 1 95 288
assign 1 99 292
getNameSpace 1 99 292
return 1 99 293
assign 1 103 298
new 0 103 298
assign 1 103 299
add 1 103 299
return 1 103 300
assign 1 107 306
new 0 107 306
assign 1 107 307
once 0 107 307
assign 1 107 308
add 1 107 308
return 1 107 309
assign 1 112 313
new 0 112 313
return 1 112 314
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1109279973: return bem_spropDecGet_0();
case -397629001: return bem_maxSpillArgsLenGet_0();
case -229958684: return bem_constGet_0();
case -944442837: return bem_classConfGet_0();
case 362974009: return bem_parentConfGet_0();
case -1413054881: return bem_smnlcsGet_0();
case -103017121: return bem_runtimeInitGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1859739893: return bem_methodsGet_0();
case 1529527065: return bem_onceCountGet_0();
case -1947619572: return bem_msynGet_0();
case 89706405: return bem_ccCacheGet_0();
case -1967844855: return bem_initialDecGet_0();
case 1774940957: return bem_toString_0();
case 1074463609: return bem_saveSyns_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case -4647121: return bem_doEmit_0();
case -2039613615: return bem_instanceNotEqualGet_0();
case -955058175: return bem_lastMethodBodyLinesGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2001798761: return bem_nlGet_0();
case -1711936384: return bem_baseSmtdDecGet_0();
case -1308786538: return bem_echo_0();
case 1372235405: return bem_superCallsGet_0();
case -1786051763: return bem_methodCatchGet_0();
case -1081275759: return bem_classesInDepthOrderGet_0();
case 1380285640: return bem_objectCcGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 604504089: return bem_falseValueGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case -378762597: return bem_boolNpGet_0();
case -1727672536: return bem_propDecGet_0();
case -628036310: return bem_lastMethodsSizeGet_0();
case -1487140092: return bem_classEndGet_0();
case 104713553: return bem_new_0();
case -402158238: return bem_inFilePathedGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1177623581: return bem_callNamesGet_0();
case -991179882: return bem_qGet_0();
case -644675716: return bem_ntypesGet_0();
case -1081412016: return bem_many_0();
case 1638160588: return bem_lineCountGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 772789066: return bem_libEmitPathGet_0();
case 2055025483: return bem_serializeContents_0();
case 1312373307: return bem_buildCreate_0();
case -1703922349: return bem_fullLibEmitNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case 36542021: return bem_mainEndGet_0();
case 916491491: return bem_emitLib_0();
case -1747980150: return bem_smnlecsGet_0();
case -1841706211: return bem_returnTypeGet_0();
case -1073009537: return bem_beginNs_0();
case -2085643372: return bem_stringNpGet_0();
case -1500143225: return bem_useDynMethodsGet_0();
case -1052944126: return bem_csynGet_0();
case -1607412815: return bem_endNs_0();
case -86482693: return bem_overrideSmtdDecGet_0();
case -1923547459: return bem_boolCcGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 498080472: return bem_mnodeGet_0();
case 1820417453: return bem_create_0();
case -946095539: return bem_mainInClassGet_0();
case -681402717: return bem_boolTypeGet_0();
case -101343106: return bem_nativeCSlotsGet_0();
case -493012039: return bem_buildGet_0();
case -206157822: return bem_coanyiantReturnsGet_0();
case -1354714650: return bem_copy_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case 361542143: return bem_classEmitsGet_0();
case -902412214: return bem_classCallsGet_0();
case -294732055: return bem_floatNpGet_0();
case -729571811: return bem_serializeToString_0();
case -1831751774: return bem_cnodeGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -622039562: return bem_intNpGet_0();
case 1240611285: return bem_onceDecsGet_0();
case -786424307: return bem_tagGet_0();
case -991255330: return bem_mainStartGet_0();
case -722876119: return bem_buildClassInfo_0();
case -1910715228: return bem_libEmitNameGet_0();
case -797225458: return bem_dynMethodsGet_0();
case 1181505319: return bem_buildInitial_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1755995201: return bem_transGet_0();
case -1449942744: return bem_instanceEqualGet_0();
case -1012494862: return bem_once_0();
case -1369896794: return bem_objectNpGet_0();
case -1498619679: return bem_getLibOutput_0();
case 287040793: return bem_hashGet_0();
case -1317806639: return bem_baseMtdDecGet_0();
case 483359873: return bem_superNameGet_0();
case -1241388883: return bem_lastMethodBodySizeGet_0();
case -1795655423: return bem_propertyDecsGet_0();
case -1152064310: return bem_instOfGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1102720804: return bem_classNameGet_0();
case -727049506: return bem_exceptDecGet_0();
case 57260628: return bem_getClassOutput_0();
case -388723214: return bem_preClassGet_0();
case 1327064356: return bem_methodBodyGet_0();
case -1926693913: return bem_synEmitPathGet_0();
case -1064889660: return bem_trueValueGet_0();
case -314718434: return bem_print_0();
case -220901978: return bem_emitLangGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -1053807407: return bem_trueValueSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2144776371: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case -1915611660: return bem_synEmitPathSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case -1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case -610957309: return bem_intNpSet_1(bevd_0);
case -386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case -891329961: return bem_classCallsSet_1(bevd_0);
case -1887784556: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -980097629: return bem_qSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1820669521: return bem_cnodeSet_1(bevd_0);
case -945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case -1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -90260853: return bem_nativeCSlotsSet_1(bevd_0);
case -1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case -1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case -596365949: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1912465206: return bem_boolCcSet_1(bevd_0);
case -377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case -943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case -1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case -16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case -1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1936537319: return bem_msynSet_1(bevd_0);
case -551679723: return bem_formCast_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1438860491: return bem_instanceEqualSet_1(bevd_0);
case -1899632975: return bem_libEmitNameSet_1(bevd_0);
case -478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -193407613: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -391075985: return bem_inFilePathedSet_1(bevd_0);
case -36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1041861873: return bem_csynSet_1(bevd_0);
case -1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -715967253: return bem_exceptDecSet_1(bevd_0);
case -1830623958: return bem_returnTypeSet_1(bevd_0);
case -1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case -1774969510: return bem_methodCatchSet_1(bevd_0);
case 2118534024: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case -1358814541: return bem_objectNpSet_1(bevd_0);
case -1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case -2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case -65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_5_8_BuildNamePath) bevd_1);
case -1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -722876117: return bem_buildClassInfo_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case -316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildCSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildCSEmitter.bevs_inst = (BEC_2_5_9_BuildCSEmitter)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildCSEmitter.bevs_inst;
}
}
