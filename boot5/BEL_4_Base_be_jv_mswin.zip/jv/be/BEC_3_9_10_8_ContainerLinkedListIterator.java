package be;
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_8_ContainerLinkedListIterator extends BEC_2_6_6_SystemObject {
public BEC_3_9_10_8_ContainerLinkedListIterator() { }
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static BEC_3_9_10_8_ContainerLinkedListIterator bevs_inst;
public BEC_2_9_10_ContainerLinkedList bevp_list;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_currNode;
public BEC_2_5_4_LogicBool bevp_starting;
public BEC_3_9_10_8_ContainerLinkedListIterator bem_new_1(BEC_2_9_10_ContainerLinkedList beva_l) throws Throwable {
bevp_list = beva_l;
bevp_starting = be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_containerGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_6_6_SystemObject bem_hasCurrentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 448 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 449 */
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 455 */ {
bevt_2_tmpany_phold = bevp_list.bem_firstNodeGet_0();
if (bevt_2_tmpany_phold == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /* Line: 457 */
 else  /* Line: 458 */ {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 459 */
} /* Line: 456 */
if (bevp_currNode == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_7_tmpany_phold = bevp_currNode.bem_nextGet_0();
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 463 */
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_9_tmpany_phold;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_nxnode = (BEC_3_9_10_4_ContainerLinkedListNode) this.bem_nextNodeGet_0();
if (bevl_nxnode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevp_list.bem_addValue_1(beva_value);
this.bem_nextNodeGet_0();
} /* Line: 472 */
 else  /* Line: 473 */ {
bevl_nxnode.bem_heldSet_1(beva_value);
} /* Line: 474 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextNodeGet_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 480 */ {
bevp_starting = be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 482 */
 else  /* Line: 483 */ {
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 485 */
} /* Line: 484 */
bevp_currNode = bevl_nxnode;
return bevp_currNode;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentNodeGet_0() throws Throwable {
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva__currNode) throws Throwable {
bevp_starting = be.BECS_Runtime.boolFalse;
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva__currNode;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 502 */ {
return null;
} /* Line: 503 */
bevt_1_tmpany_phold = bevp_currNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 509 */ {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 510 */
bevp_currNode.bem_heldSet_1(beva_x);
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 518 */ {
bevp_starting = be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 520 */
 else  /* Line: 521 */ {
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 523 */
} /* Line: 522 */
bevp_currNode = bevl_nxnode;
if (bevp_currNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 527 */ {
bevt_2_tmpany_phold = bevp_currNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 528 */
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) throws Throwable {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 534 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 534 */ {
this.bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 534 */
 else  /* Line: 534 */ {
break;
} /* Line: 534 */
} /* Line: 534 */
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGet_0() throws Throwable {
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_currNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startingGet_0() throws Throwable {
return bevp_starting;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_startingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {436, 438, 444, 448, 448, 449, 449, 451, 451, 456, 456, 456, 457, 457, 459, 459, 462, 462, 0, 462, 462, 462, 0, 0, 463, 463, 465, 465, 469, 470, 470, 471, 472, 474, 481, 482, 484, 484, 485, 488, 489, 493, 497, 498, 502, 502, 503, 505, 505, 509, 509, 510, 510, 512, 513, 513, 519, 520, 522, 522, 523, 526, 527, 527, 528, 528, 530, 534, 534, 534, 535, 534, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {12, 13, 17, 23, 28, 29, 30, 32, 33, 47, 48, 53, 54, 55, 58, 59, 62, 67, 68, 71, 72, 77, 78, 81, 85, 86, 88, 89, 94, 95, 100, 101, 102, 105, 113, 114, 117, 122, 123, 126, 127, 130, 133, 134, 140, 145, 146, 148, 149, 155, 160, 161, 162, 164, 165, 166, 174, 175, 178, 183, 184, 187, 188, 193, 194, 195, 197, 202, 205, 210, 211, 212, 221, 224, 228, 231, 235, 238};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 436 12
assign 1 438 13
new 0 438 13
return 1 444 17
assign 1 448 23
undef 1 448 28
assign 1 449 29
new 0 449 29
return 1 449 30
assign 1 451 32
new 0 451 32
return 1 451 33
assign 1 456 47
firstNodeGet 0 456 47
assign 1 456 48
undef 1 456 53
assign 1 457 54
new 0 457 54
return 1 457 55
assign 1 459 58
new 0 459 58
return 1 459 59
assign 1 462 62
undef 1 462 67
assign 1 0 68
assign 1 462 71
nextGet 0 462 71
assign 1 462 72
undef 1 462 77
assign 1 0 78
assign 1 0 81
assign 1 463 85
new 0 463 85
return 1 463 86
assign 1 465 88
new 0 465 88
return 1 465 89
assign 1 469 94
nextNodeGet 0 469 94
assign 1 470 95
undef 1 470 100
addValue 1 471 101
nextNodeGet 0 472 102
heldSet 1 474 105
assign 1 481 113
new 0 481 113
assign 1 482 114
firstNodeGet 0 482 114
assign 1 484 117
def 1 484 122
assign 1 485 123
nextGet 0 485 123
assign 1 488 126
return 1 489 127
return 1 493 130
assign 1 497 133
new 0 497 133
assign 1 498 134
assign 1 502 140
undef 1 502 145
return 1 503 146
assign 1 505 148
heldGet 0 505 148
return 1 505 149
assign 1 509 155
undef 1 509 160
assign 1 510 161
new 0 510 161
return 1 510 162
heldSet 1 512 164
assign 1 513 165
new 0 513 165
return 1 513 166
assign 1 519 174
new 0 519 174
assign 1 520 175
firstNodeGet 0 520 175
assign 1 522 178
def 1 522 183
assign 1 523 184
nextGet 0 523 184
assign 1 526 187
assign 1 527 188
def 1 527 193
assign 1 528 194
heldGet 0 528 194
return 1 528 195
return 1 530 197
assign 1 534 202
new 0 534 202
assign 1 534 205
lesser 1 534 210
nextSet 1 535 211
incrementValue 0 534 212
return 1 0 221
assign 1 0 224
return 1 0 228
assign 1 0 231
return 1 0 235
assign 1 0 238
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 1582066476: return bem_currentNodeGet_0();
case -1816451342: return bem_nextNodeGet_0();
case 104713553: return bem_new_0();
case 1766138515: return bem_currNodeGet_0();
case -1246679159: return bem_listGet_0();
case -1693924536: return bem_hasCurrentGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 232617255: return bem_startingGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case 1446310798: return bem_currentGet_0();
case -1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case 108485850: return bem_hasNextGet_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 1205705825: return bem_nextSet_1(bevd_0);
case 1593148729: return bem_currentNodeSet_1(bevd_0);
case -900559503: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1457393051: return bem_currentSet_1(bevd_0);
case 1777220768: return bem_currNodeSet_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1235596906: return bem_listSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 243699508: return bem_startingSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(29, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_9_10_8_ContainerLinkedListIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_9_10_8_ContainerLinkedListIterator.bevs_inst = (BEC_3_9_10_8_ContainerLinkedListIterator)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_9_10_8_ContainerLinkedListIterator.bevs_inst;
}
}
