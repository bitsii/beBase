package be;
/* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_12_TextByteIterator bevs_inst;
public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public BEC_2_4_12_TextByteIterator bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_emptyGet_0();
this.bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_containerGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
this.bem_new_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_str = beva__str;
bevp_pos = (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1257 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 1258 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = this.bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1268 */ {
bevt_3_tmpany_phold = beva_buf.bem_capacityGet_0();
bevt_4_tmpany_phold = bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1269 */ {
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 1270 */
bevt_7_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_8_tmpany_phold = bevo_1;
if (bevt_7_tmpany_phold.bevi_int != bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1272 */ {
bevt_9_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_11_tmpany_phold = bevo_2;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_9_tmpany_phold.bevi_int = bevt_10_tmpany_phold.bevi_int;
} /* Line: 1273 */
bevt_12_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_13_tmpany_phold = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevp_pos.bevi_int++;
} /* Line: 1279 */
return beva_buf;
} /*method end*/
public BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1285 */ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1287 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_3;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1293 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1293 */
 else  /* Line: 1293 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1293 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1296 */
return beva_into;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_4;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1302 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1302 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1302 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1302 */
 else  /* Line: 1302 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1302 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1305 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGet_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1233, 1233, 1233, 1237, 1241, 1245, 1250, 1251, 1252, 1257, 1257, 1257, 1258, 1258, 1260, 1260, 1264, 1264, 1264, 1264, 1268, 1268, 1268, 1269, 1269, 1269, 1269, 1270, 1270, 1272, 1272, 1272, 1272, 1273, 1273, 1273, 1273, 1275, 1275, 1275, 1279, 1281, 1285, 1285, 1285, 1286, 1287, 1289, 1293, 1293, 1293, 1293, 1293, 1293, 0, 0, 0, 1294, 1295, 1296, 1298, 1302, 1302, 1302, 1302, 1302, 1302, 0, 0, 0, 1303, 1304, 1305, 1311, 1315, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 25, 28, 31, 35, 36, 37, 45, 46, 51, 52, 53, 55, 56, 62, 63, 64, 65, 84, 85, 90, 91, 92, 93, 98, 99, 100, 102, 103, 104, 109, 110, 111, 112, 113, 115, 116, 117, 118, 120, 125, 126, 131, 132, 133, 135, 143, 144, 149, 150, 151, 156, 157, 160, 164, 167, 168, 169, 171, 179, 180, 185, 186, 187, 192, 193, 196, 200, 203, 204, 205, 210, 213, 216, 219, 223, 226, 230, 233};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1233 19
new 0 1233 19
assign 1 1233 20
emptyGet 0 1233 20
new 1 1233 21
return 1 1237 25
return 1 1241 28
new 1 1245 31
assign 1 1250 35
assign 1 1251 36
new 0 1251 36
assign 1 1252 37
new 0 1252 37
assign 1 1257 45
sizeGet 0 1257 45
assign 1 1257 46
greater 1 1257 51
assign 1 1258 52
new 0 1258 52
return 1 1258 53
assign 1 1260 55
new 0 1260 55
return 1 1260 56
assign 1 1264 62
new 0 1264 62
assign 1 1264 63
new 1 1264 63
assign 1 1264 64
next 1 1264 64
return 1 1264 65
assign 1 1268 84
sizeGet 0 1268 84
assign 1 1268 85
greater 1 1268 90
assign 1 1269 91
capacityGet 0 1269 91
assign 1 1269 92
new 0 1269 92
assign 1 1269 93
lesser 1 1269 98
assign 1 1270 99
new 0 1270 99
capacitySet 1 1270 100
assign 1 1272 102
sizeGet 0 1272 102
assign 1 1272 103
new 0 1272 103
assign 1 1272 104
notEquals 1 1272 109
assign 1 1273 110
sizeGet 0 1273 110
assign 1 1273 111
new 0 1273 111
assign 1 1273 112
once 0 1273 112
setValue 1 1273 113
assign 1 1275 115
new 0 1275 115
assign 1 1275 116
getInt 2 1275 116
setIntUnchecked 2 1275 117
incrementValue 0 1279 118
return 1 1281 120
assign 1 1285 125
sizeGet 0 1285 125
assign 1 1285 126
greater 1 1285 131
getInt 2 1286 132
incrementValue 0 1287 133
return 1 1289 135
assign 1 1293 143
new 0 1293 143
assign 1 1293 144
greater 1 1293 149
assign 1 1293 150
sizeGet 0 1293 150
assign 1 1293 151
greaterEquals 1 1293 156
assign 1 0 157
assign 1 0 160
assign 1 0 164
decrementValue 0 1294 167
getInt 2 1295 168
incrementValue 0 1296 169
return 1 1298 171
assign 1 1302 179
new 0 1302 179
assign 1 1302 180
greater 1 1302 185
assign 1 1302 186
sizeGet 0 1302 186
assign 1 1302 187
greaterEquals 1 1302 192
assign 1 0 193
assign 1 0 196
assign 1 0 200
decrementValue 0 1303 203
setIntUnchecked 2 1304 204
incrementValue 0 1305 205
return 1 1311 210
return 1 1315 213
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1308786538: return bem_echo_0();
case 104713553: return bem_new_0();
case 715968403: return bem_posGet_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -248879165: return bem_byteIteratorIteratorGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -729571811: return bem_serializeToString_0();
case 478622533: return bem_sourceFileNameGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case 1194623572: return bem_nextGet_0();
case 1763354070: return bem_strGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case -230685860: return bem_vcopyGet_0();
case 833063302: return bem_containerGet_0();
case 1820417453: return bem_create_0();
case -786424307: return bem_tagGet_0();
case 108485850: return bem_hasNextGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1774436323: return bem_strSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -219603607: return bem_vcopySet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1488067202: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 727050656: return bem_posSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1048795675: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case 1196738734: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1448425960: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_TextByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_TextByteIterator.bevs_inst = (BEC_2_4_12_TextByteIterator)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_TextByteIterator.bevs_inst;
}
}
