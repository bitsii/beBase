package be;
/* IO:File: source/extended/Json.be */
public class BEC_2_4_12_JsonUnmarshaller extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_JsonUnmarshaller() { }
private static byte[] becc_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x55,0x6E,0x6D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x75,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72};
private static byte[] bels_1 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x6D,0x61,0x70};
private static byte[] bels_2 = {0x6B,0x65,0x79,0x20,0x75,0x6E,0x64,0x65,0x66,0x20,0x69,0x6E,0x20,0x6B,0x76,0x6D,0x69,0x64};
private static byte[] bels_3 = {0x73,0x74,0x61,0x63,0x6B,0x20,0x65,0x6D,0x70,0x74,0x79,0x20,0x69,0x6E,0x20,0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
public static BEC_2_4_12_JsonUnmarshaller bevs_inst;
public BEC_2_4_6_JsonParser bevp_parser;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_9_4_ContainerPair bevp_pair;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_9_5_ContainerStack bevp_stack;
public BEC_2_4_12_JsonUnmarshaller bem_new_0() throws Throwable {
bevp_parser = (new BEC_2_4_6_JsonParser()).bem_new_0();
bevp_list = (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_pair = (new BEC_2_9_4_ContainerPair()).bem_new_0();
bevp_map = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_first = null;
bevp_stack = (new BEC_2_9_5_ContainerStack()).bem_new_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_unmarshall_1(BEC_2_4_6_TextString beva_str) throws Throwable {
this.bem_new_0();
bevp_parser.bem_parse_2(beva_str, this);
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_addIn_1(BEC_2_6_6_SystemObject beva_o) throws Throwable {
BEC_2_6_6_SystemObject bevl_top = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_first == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 487 */ {
bevp_first = beva_o;
} /* Line: 488 */
bevl_top = bevp_stack.bem_peek_0();
if (bevl_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 491 */ {
bevt_2_tmpany_phold = bevl_top.bemd_1(631500772, BEL_4_Base.bevn_sameClass_1, bevp_pair);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_2_tmpany_phold).bevi_bool) /* Line: 492 */ {
bevt_4_tmpany_phold = bevl_top.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 493 */ {
bevt_5_tmpany_phold = bevl_top.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_6_tmpany_phold = bevl_top.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
bevt_5_tmpany_phold.bemd_2(107034370, BEL_4_Base.bevn_put_2, bevt_6_tmpany_phold, beva_o);
bevl_top.bemd_1(253930368, BEL_4_Base.bevn_secondSet_1, null);
} /* Line: 495 */
 else  /* Line: 496 */ {
bevl_top.bemd_1(253930368, BEL_4_Base.bevn_secondSet_1, beva_o);
} /* Line: 497 */
} /* Line: 493 */
 else  /* Line: 492 */ {
bevt_7_tmpany_phold = bevl_top.bemd_1(631500772, BEL_4_Base.bevn_sameClass_1, bevp_list);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_7_tmpany_phold).bevi_bool) /* Line: 499 */ {
bevl_top.bemd_1(-228068295, BEL_4_Base.bevn_addValueWhole_1, beva_o);
} /* Line: 500 */
 else  /* Line: 501 */ {
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(17, bels_0));
bevt_8_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_8_tmpany_phold);
} /* Line: 502 */
} /* Line: 492 */
} /* Line: 492 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginMap_0() throws Throwable {
BEC_2_9_3_ContainerMap bevl_m = null;
BEC_2_9_4_ContainerPair bevt_0_tmpany_phold = null;
bevl_m = (new BEC_2_9_3_ContainerMap()).bem_new_0();
this.bem_addIn_1(bevl_m);
bevt_0_tmpany_phold = (new BEC_2_9_4_ContainerPair()).bem_new_2(bevl_m, null);
bevp_stack.bem_push_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endMap_0() throws Throwable {
BEC_2_9_4_ContainerPair bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 516 */ {
bevl_p = (BEC_2_9_4_ContainerPair) bevp_stack.bem_pop_0();
} /* Line: 517 */
 else  /* Line: 518 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(21, bels_1));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 519 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_kvMid_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_stack.bem_peek_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(631500772, BEL_4_Base.bevn_sameClass_1, bevp_pair);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(105008580, BEL_4_Base.bevn_not_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 525 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 525 */ {
bevt_6_tmpany_phold = bevp_stack.bem_peek_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(242848115, BEL_4_Base.bevn_secondGet_0);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 525 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 525 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 525 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 525 */ {
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(18, bels_2));
bevt_7_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_7_tmpany_phold);
} /* Line: 526 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_beginList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
bevl_l = (new BEC_2_9_4_ContainerList()).bem_new_0();
this.bem_addIn_1(bevl_l);
bevp_stack.bem_push_1(bevl_l);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_endList_0() throws Throwable {
BEC_2_9_4_ContainerList bevl_l = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_stack.bem_isEmptyGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 539 */ {
bevl_l = (BEC_2_9_4_ContainerList) bevp_stack.bem_pop_0();
} /* Line: 540 */
 else  /* Line: 541 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(22, bels_3));
bevt_1_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 542 */
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleString_1(BEC_2_4_6_TextString beva_str) throws Throwable {
this.bem_addIn_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleTrue_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
this.bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleFalse_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
this.bem_addIn_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleNull_0() throws Throwable {
this.bem_addIn_1(null);
return this;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) throws Throwable {
this.bem_addIn_1(beva_int);
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_parserGet_0() throws Throwable {
return bevp_parser;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_parserSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parser = (BEC_2_4_6_JsonParser) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() throws Throwable {
return bevp_list;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerPair bem_pairGet_0() throws Throwable {
return bevp_pair;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_pairSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pair = (BEC_2_9_4_ContainerPair) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGet_0() throws Throwable {
return bevp_map;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() throws Throwable {
return bevp_first;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_stackGet_0() throws Throwable {
return bevp_stack;
} /*method end*/
public BEC_2_4_12_JsonUnmarshaller bem_stackSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_stack = (BEC_2_9_5_ContainerStack) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {470, 471, 472, 473, 475, 476, 481, 482, 483, 487, 487, 488, 490, 491, 491, 492, 493, 493, 493, 494, 494, 494, 495, 497, 499, 500, 502, 502, 502, 509, 510, 511, 511, 516, 517, 519, 519, 519, 525, 525, 525, 0, 525, 525, 525, 525, 0, 0, 526, 526, 526, 532, 533, 534, 539, 540, 542, 542, 542, 549, 554, 554, 559, 559, 564, 569, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 21, 22, 23, 24, 28, 29, 30, 44, 49, 50, 52, 53, 58, 59, 61, 62, 67, 68, 69, 70, 71, 74, 78, 80, 83, 84, 85, 94, 95, 96, 97, 105, 107, 110, 111, 112, 126, 127, 128, 130, 133, 134, 135, 140, 141, 144, 148, 149, 150, 156, 157, 158, 166, 168, 171, 172, 173, 178, 183, 184, 189, 190, 194, 198, 202, 205, 209, 212, 216, 219, 223, 226, 230, 233, 237, 240};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 470 19
new 0 470 19
assign 1 471 20
new 0 471 20
assign 1 472 21
new 0 472 21
assign 1 473 22
new 0 473 22
assign 1 475 23
assign 1 476 24
new 0 476 24
new 0 481 28
parse 2 482 29
return 1 483 30
assign 1 487 44
undef 1 487 49
assign 1 488 50
assign 1 490 52
peek 0 490 52
assign 1 491 53
def 1 491 58
assign 1 492 59
sameClass 1 492 59
assign 1 493 61
secondGet 0 493 61
assign 1 493 62
def 1 493 67
assign 1 494 68
firstGet 0 494 68
assign 1 494 69
secondGet 0 494 69
put 2 494 70
secondSet 1 495 71
secondSet 1 497 74
assign 1 499 78
sameClass 1 499 78
addValueWhole 1 500 80
assign 1 502 83
new 0 502 83
assign 1 502 84
new 1 502 84
throw 1 502 85
assign 1 509 94
new 0 509 94
addIn 1 510 95
assign 1 511 96
new 2 511 96
push 1 511 97
assign 1 516 105
isEmptyGet 0 516 105
assign 1 517 107
pop 0 517 107
assign 1 519 110
new 0 519 110
assign 1 519 111
new 1 519 111
throw 1 519 112
assign 1 525 126
peek 0 525 126
assign 1 525 127
sameClass 1 525 127
assign 1 525 128
not 0 525 128
assign 1 0 130
assign 1 525 133
peek 0 525 133
assign 1 525 134
secondGet 0 525 134
assign 1 525 135
undef 1 525 140
assign 1 0 141
assign 1 0 144
assign 1 526 148
new 0 526 148
assign 1 526 149
new 1 526 149
throw 1 526 150
assign 1 532 156
new 0 532 156
addIn 1 533 157
push 1 534 158
assign 1 539 166
isEmptyGet 0 539 166
assign 1 540 168
pop 0 540 168
assign 1 542 171
new 0 542 171
assign 1 542 172
new 1 542 172
throw 1 542 173
addIn 1 549 178
assign 1 554 183
new 0 554 183
addIn 1 554 184
assign 1 559 189
new 0 559 189
addIn 1 559 190
addIn 1 564 194
addIn 1 569 198
return 1 0 202
assign 1 0 205
return 1 0 209
assign 1 0 212
return 1 0 216
assign 1 0 219
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
return 1 0 237
assign 1 0 240
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1431394368: return bem_handleNull_0();
case -314718434: return bem_print_0();
case 1102720804: return bem_classNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -435843368: return bem_beginList_0();
case -1308786538: return bem_echo_0();
case 1398681994: return bem_endList_0();
case 104713553: return bem_new_0();
case -368775858: return bem_kvMid_0();
case -1246679159: return bem_listGet_0();
case -1262128633: return bem_handleTrue_0();
case 287040793: return bem_hashGet_0();
case 1774940957: return bem_toString_0();
case -729571811: return bem_serializeToString_0();
case 1095000804: return bem_beginMap_0();
case 478622533: return bem_sourceFileNameGet_0();
case -416660294: return bem_objectIteratorGet_0();
case 443668840: return bem_methodNotDefined_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -183400265: return bem_firstGet_0();
case 2055025483: return bem_serializeContents_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1286503731: return bem_pairGet_0();
case -506014516: return bem_handleFalse_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 2013904863: return bem_stackGet_0();
case 167292072: return bem_parserGet_0();
case 156467595: return bem_mapGet_0();
case 1820417453: return bem_create_0();
case 1708368370: return bem_endMap_0();
case -786424307: return bem_tagGet_0();
case -1354714650: return bem_copy_0();
case -1182494494: return bem_toAny_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 581408689: return bem_equals_1(bevd_0);
case 167549848: return bem_mapSet_1(bevd_0);
case -1275421478: return bem_pairSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1818023961: return bem_unmarshall_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1774332469: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case -172318012: return bem_firstSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1235596906: return bem_listSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 178374325: return bem_parserSet_1(bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 1512002600: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -1148905512: return bem_addIn_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 2024987116: return bem_stackSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_JsonUnmarshaller();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_JsonUnmarshaller.bevs_inst = (BEC_2_4_12_JsonUnmarshaller)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_JsonUnmarshaller.bevs_inst;
}
}
