package be;
/* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject extends be.BECS_Object {
public BEC_2_6_6_SystemObject() { }
private static byte[] becc_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_0, 8));
private static byte[] bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_1, 23));
private static byte[] bels_2 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_3 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_3, 16));
private static byte[] bels_4 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_5 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_6 = {0x5F};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_6, 1));
private static BEC_2_4_3_MathInt bevo_4 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_5 = (new BEC_2_4_3_MathInt(7));
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(7));
private static byte[] bels_7 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_8 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bels_9 = {0x5F};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_9, 1));
public static BEC_2_6_6_SystemObject bevs_inst;
public BEC_2_6_6_SystemObject bem_new_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undefined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_defined_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_toAny_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_forwardCall_1(BEC_2_6_11_SystemForwardCall beva_forwardCall) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_5_tmpany_phold = bevo_0;
bevt_6_tmpany_phold = beva_forwardCall.bem_nameGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = this.bem_classNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 74 */
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_phold = this.bem_createInstance_2(beva_cname, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_4_3_MathInt bevl_mhash = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_11_SystemInitializer bevt_9_tmpany_phold = null;
if (beva_cname == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(18, bels_2));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 99 */
bevl_result = null;

        String key = new String(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int, "UTF-8");
        Class ti = be.BECS_Runtime.typeInstances.get(key);
        if (ti != null) {
            //System.out.println("Getting new instance for |" + key + "|");
            bevl_result = (BEC_2_6_6_SystemObject) ti.newInstance();
        } 
        //else {
        //    System.out.println("No typeInstance for |" + key + "|");
        //}
        if (bevl_result == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 177 */ {
if (beva_throwOnFail.bevi_bool) /* Line: 178 */ {
bevt_7_tmpany_phold = bevo_2;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_cname);
bevt_5_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 179 */
 else  /* Line: 180 */ {
return null;
} /* Line: 181 */
} /* Line: 178 */
bevt_9_tmpany_phold = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_initializeIfShould_1(bevl_result);
return bevt_8_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(23, bels_4));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 220 */
if (beva_args == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(32, bels_5));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 223 */
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_tmpany_phold = bevo_3;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevl_chash = bevl_cname.bem_hashGet_0();
 /* Line: 232 */ {
bevt_10_tmpany_phold = bevo_4;
if (bevl_numargs.bevi_int > bevt_10_tmpany_phold.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_12_tmpany_phold = bevo_5;
bevt_11_tmpany_phold = bevl_numargs.bem_subtract_1(bevt_12_tmpany_phold);
bevl_args2 = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(7));
while (true)
 /* Line: 235 */ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_15_tmpany_phold = bevo_6;
bevt_14_tmpany_phold = bevl_i.bem_subtract_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_tmpany_phold, bevt_16_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 235 */
 else  /* Line: 235 */ {
break;
} /* Line: 235 */
} /* Line: 235 */
} /* Line: 235 */
} /* Line: 233 */

        int ci = be.BECS_Ids.callIds.get(new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8"));
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(bevl_chash.bevi_int, ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(bevl_chash.bevi_int, ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(bevl_chash.bevi_int, ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 361 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 363 */
return bevl_rval;
} /*method end*/
public BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) throws Throwable {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_19_SystemInvocationException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
if (beva_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 390 */ {
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(18, bels_7));
bevt_1_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 391 */
if (beva_numargs == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(21, bels_8));
bevt_4_tmpany_phold = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 394 */
bevt_7_tmpany_phold = bevo_7;
bevt_6_tmpany_phold = beva_name.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevl_chash = bevl_cname.bem_hashGet_0();

      String name = "bem_" + new String(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int, "UTF-8");
      java.lang.reflect.Method[] methods = this.getClass().getMethods();
      for (int i = 0;i < methods.length;i++) {
        if (methods[i].getName().equals(name)) {
            return be.BECS_Runtime.boolTrue;
        }
      }
      bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 450 */ {
bevl_rval.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
} /* Line: 451 */
if (bevl_rval == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /* Line: 454 */
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /*method end*/
public final BEC_2_4_6_TextString bem_classNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clname();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      return bevl_xi;
} /*method end*/
public final BEC_2_4_6_TextString bem_sourceFileNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      byte[] bevls_clname = bemc_clfile();
      bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      return bevl_xi;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tagGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = hashCode();
      return bevl_toRet;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_print_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_echo_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_toString_0();
bevt_0_tmpany_phold.bem_echo_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copy_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_create_0();
bevt_0_tmpany_phold = this.bem_copyTo_1(bevt_1_tmpany_phold);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
if (beva_copy == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 674 */ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 675 */
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_tmpany_phold);
while (true)
 /* Line: 679 */ {
bevt_3_tmpany_phold = bevl_siter.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 679 */ {
bevt_4_tmpany_phold = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_tmpany_phold);
} /* Line: 680 */
 else  /* Line: 679 */ {
break;
} /* Line: 679 */
} /* Line: 679 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deserializeClassNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_classNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() throws Throwable {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_serializeContents_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && this.getClass().equals(beva_other.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_sameClass_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      if (beva_other != null && beva_other.getClass().isAssignableFrom(this.getClass())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = this.bem_sameType_1(beva_other);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_once_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_many_0() throws Throwable {
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {32, 32, 43, 43, 54, 54, 65, 65, 69, 73, 74, 74, 74, 74, 74, 74, 74, 74, 74, 79, 79, 79, 98, 98, 99, 99, 99, 101, 177, 177, 179, 179, 179, 179, 181, 184, 184, 184, 219, 219, 220, 220, 220, 222, 222, 223, 223, 223, 225, 226, 226, 226, 226, 227, 233, 233, 233, 234, 234, 234, 235, 235, 235, 236, 236, 236, 236, 235, 361, 363, 365, 390, 390, 391, 391, 391, 393, 393, 394, 394, 394, 396, 396, 396, 396, 397, 450, 451, 453, 453, 454, 454, 456, 456, 490, 512, 544, 544, 576, 576, 587, 613, 624, 650, 654, 654, 654, 658, 658, 662, 662, 666, 666, 670, 670, 670, 674, 674, 675, 677, 677, 678, 678, 679, 680, 680, 686, 686, 692, 698, 698, 702, 702, 706, 706, 710, 710, 733, 780, 780, 784, 784, 784, 839, 839, 843, 843, 843};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {31, 32, 36, 37, 41, 42, 46, 47, 50, 62, 64, 65, 66, 67, 68, 69, 70, 71, 72, 79, 80, 81, 98, 103, 104, 105, 106, 108, 119, 124, 126, 127, 128, 129, 132, 135, 136, 137, 164, 169, 170, 171, 172, 174, 179, 180, 181, 182, 184, 185, 186, 187, 188, 189, 191, 192, 197, 198, 199, 200, 201, 204, 209, 210, 211, 212, 213, 214, 244, 246, 248, 267, 272, 273, 274, 275, 277, 282, 283, 284, 285, 287, 288, 289, 290, 291, 300, 302, 304, 309, 310, 311, 313, 314, 321, 328, 336, 337, 345, 346, 350, 353, 357, 360, 365, 366, 371, 375, 376, 380, 381, 386, 387, 393, 394, 395, 405, 410, 411, 413, 414, 415, 416, 419, 421, 422, 432, 433, 439, 446, 447, 451, 452, 456, 457, 461, 462, 468, 476, 477, 482, 483, 488, 496, 497, 502, 503, 508};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 32 31
new 0 32 31
return 1 32 32
assign 1 43 36
new 0 43 36
return 1 43 37
assign 1 54 41
new 0 54 41
return 1 54 42
assign 1 65 46
new 0 65 46
return 1 65 47
return 1 69 50
assign 1 73 62
new 0 73 62
assign 1 74 64
new 0 74 64
assign 1 74 65
nameGet 0 74 65
assign 1 74 66
add 1 74 66
assign 1 74 67
new 0 74 67
assign 1 74 68
add 1 74 68
assign 1 74 69
classNameGet 0 74 69
assign 1 74 70
add 1 74 70
assign 1 74 71
new 1 74 71
throw 1 74 72
assign 1 79 79
new 0 79 79
assign 1 79 80
createInstance 2 79 80
return 1 79 81
assign 1 98 98
undef 1 98 103
assign 1 99 104
new 0 99 104
assign 1 99 105
new 1 99 105
throw 1 99 106
assign 1 101 108
assign 1 177 119
undef 1 177 124
assign 1 179 126
new 0 179 126
assign 1 179 127
add 1 179 127
assign 1 179 128
new 1 179 128
throw 1 179 129
return 1 181 132
assign 1 184 135
new 0 184 135
assign 1 184 136
initializeIfShould 1 184 136
return 1 184 137
assign 1 219 164
undef 1 219 169
assign 1 220 170
new 0 220 170
assign 1 220 171
new 1 220 171
throw 1 220 172
assign 1 222 174
undef 1 222 179
assign 1 223 180
new 0 223 180
assign 1 223 181
new 1 223 181
throw 1 223 182
assign 1 225 184
lengthGet 0 225 184
assign 1 226 185
new 0 226 185
assign 1 226 186
add 1 226 186
assign 1 226 187
toString 0 226 187
assign 1 226 188
add 1 226 188
assign 1 227 189
hashGet 0 227 189
assign 1 233 191
new 0 233 191
assign 1 233 192
greater 1 233 197
assign 1 234 198
new 0 234 198
assign 1 234 199
subtract 1 234 199
assign 1 234 200
new 1 234 200
assign 1 235 201
new 0 235 201
assign 1 235 204
lesser 1 235 209
assign 1 236 210
new 0 236 210
assign 1 236 211
subtract 1 236 211
assign 1 236 212
get 1 236 212
put 2 236 213
incrementValue 0 235 214
assign 1 361 244
new 0 361 244
toString 0 363 246
return 1 365 248
assign 1 390 267
undef 1 390 272
assign 1 391 273
new 0 391 273
assign 1 391 274
new 1 391 274
throw 1 391 275
assign 1 393 277
undef 1 393 282
assign 1 394 283
new 0 394 283
assign 1 394 284
new 1 394 284
throw 1 394 285
assign 1 396 287
new 0 396 287
assign 1 396 288
add 1 396 288
assign 1 396 289
toString 0 396 289
assign 1 396 290
add 1 396 290
assign 1 397 291
hashGet 0 397 291
assign 1 450 300
new 0 450 300
toString 0 451 302
assign 1 453 304
def 1 453 309
assign 1 454 310
new 0 454 310
return 1 454 311
assign 1 456 313
new 0 456 313
return 1 456 314
return 1 490 321
return 1 512 328
assign 1 544 336
new 0 544 336
return 1 544 337
assign 1 576 345
new 0 576 345
return 1 576 346
assign 1 587 350
new 0 587 350
return 1 613 353
assign 1 624 357
new 0 624 357
return 1 650 360
assign 1 654 365
equals 1 654 365
assign 1 654 366
not 0 654 371
return 1 654 371
assign 1 658 375
classNameGet 0 658 375
return 1 658 376
assign 1 662 380
toString 0 662 380
print 0 662 381
assign 1 666 386
toString 0 666 386
echo 0 666 387
assign 1 670 393
create 0 670 393
assign 1 670 394
copyTo 1 670 394
return 1 670 395
assign 1 674 405
undef 1 674 410
return 1 675 411
assign 1 677 413
new 0 677 413
assign 1 677 414
new 2 677 414
assign 1 678 415
new 0 678 415
assign 1 678 416
new 2 678 416
assign 1 679 419
hasNextGet 0 679 419
assign 1 680 421
nextGet 0 680 421
nextSet 1 680 422
assign 1 686 432
classNameGet 0 686 432
return 1 686 433
return 1 692 439
assign 1 698 446
new 1 698 446
return 1 698 447
assign 1 702 451
new 1 702 451
return 1 702 452
assign 1 706 456
new 1 706 456
return 1 706 457
assign 1 710 461
new 0 710 461
return 1 710 462
return 1 733 468
assign 1 780 476
new 0 780 476
return 1 780 477
assign 1 784 482
sameClass 1 784 482
assign 1 784 483
not 0 784 488
return 1 784 488
assign 1 839 496
new 0 839 496
return 1 839 497
assign 1 843 502
sameType 1 843 502
assign 1 843 503
not 0 843 508
return 1 843 508
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -786424307: return bem_tagGet_0();
case -1308786538: return bem_echo_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1774940957: return bem_toString_0();
case 1820417453: return bem_create_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1081412016: return bem_many_0();
case -1182494494: return bem_toAny_0();
case -845792839: return bem_iteratorGet_0();
case 2055025483: return bem_serializeContents_0();
case -729571811: return bem_serializeToString_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1102720804: return bem_classNameGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -1012494862: return bem_once_0();
case -314718434: return bem_print_0();
case 287040793: return bem_hashGet_0();
case 104713553: return bem_new_0();
case -1354714650: return bem_copy_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 95462007: return bem_def_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -868745803: return bem_forwardCall_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemObject();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemObject.bevs_inst = becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemObject.bevs_inst;
}
}
