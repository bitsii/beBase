package be;
/* IO:File: source/build/JSEmitter.be */
public final class BEC_2_5_9_BuildJSEmitter extends BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bels_0 = {0x6A,0x73};
private static byte[] bels_1 = {0x2E,0x6A,0x73};
private static byte[] bels_2 = {};
private static byte[] bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bels_7 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bels_8 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bels_9 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bevo_0 = (new BEC_2_4_6_TextString(bels_9, 5));
private static byte[] bels_10 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bels_11 = {0x29,0x20,0x7B};
private static byte[] bels_12 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bevo_1 = (new BEC_2_4_6_TextString(bels_12, 31));
private static byte[] bels_13 = {0x29,0x29};
private static BEC_2_4_6_TextString bevo_2 = (new BEC_2_4_6_TextString(bels_13, 2));
private static byte[] bels_14 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bels_15 = {0x20,0x3D,0x20,0x5B};
private static byte[] bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_17 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_18 = {0x28,0x29,0x3B};
private static byte[] bels_19 = {0x7D};
private static byte[] bels_20 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bels_21 = {0x2C,0x20};
private static byte[] bels_22 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bels_23 = {0x5D,0x3B};
private static byte[] bels_24 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bels_25 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bels_26 = {0x7D};
private static byte[] bels_27 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_28 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bels_29 = {0x3B};
private static byte[] bels_30 = {0x7D};
private static byte[] bels_31 = {0x5D,0x3B};
private static byte[] bels_32 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_3 = (new BEC_2_4_6_TextString(bels_32, 10));
private static byte[] bels_33 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bels_34 = {0x5D,0x20,0x3D,0x20};
private static byte[] bels_35 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bels_36 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_4 = (new BEC_2_4_6_TextString(bels_36, 4));
private static byte[] bels_37 = {0x28,0x29};
private static BEC_2_4_6_TextString bevo_5 = (new BEC_2_4_6_TextString(bels_37, 2));
private static byte[] bels_38 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bels_39 = {0x29,0x3B};
private static byte[] bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bels_41 = {0x29,0x3B};
private static byte[] bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_43 = {0x2C,0x20};
private static byte[] bels_44 = {0x29,0x3B};
private static byte[] bels_45 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bels_46 = {0x2C,0x20};
private static byte[] bels_47 = {0x29,0x3B};
private static BEC_2_4_3_MathInt bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bels_48 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bels_49 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bels_51 = {};
private static byte[] bels_52 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bels_53 = {0x28,0x29,0x3B};
private static byte[] bels_54 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bels_55 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bels_56 = {0x22,0x3B};
private static byte[] bels_57 = {};
private static byte[] bels_58 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_59 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bels_60 = {0x76,0x61,0x72,0x20};
private static byte[] bels_61 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bels_62 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bevo_7 = (new BEC_2_4_6_TextString(bels_62, 25));
private static byte[] bels_63 = {0x20,0x7B};
private static BEC_2_4_6_TextString bevo_8 = (new BEC_2_4_6_TextString(bels_63, 2));
private static byte[] bels_64 = {0x74,0x68,0x69,0x73};
private static byte[] bels_65 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_9 = (new BEC_2_4_6_TextString(bels_65, 17));
private static byte[] bels_66 = {0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bevo_10 = (new BEC_2_4_6_TextString(bels_66, 3));
private static byte[] bels_67 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bevo_11 = (new BEC_2_4_6_TextString(bels_67, 38));
private static byte[] bels_68 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_12 = (new BEC_2_4_6_TextString(bels_68, 4));
private static byte[] bels_69 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bevo_13 = (new BEC_2_4_6_TextString(bels_69, 21));
private static byte[] bels_70 = {0x29};
private static BEC_2_4_6_TextString bevo_14 = (new BEC_2_4_6_TextString(bels_70, 1));
private static byte[] bels_71 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_15 = (new BEC_2_4_6_TextString(bels_71, 4));
private static byte[] bels_72 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bevo_16 = (new BEC_2_4_6_TextString(bels_72, 23));
private static byte[] bels_73 = {0x29};
private static BEC_2_4_6_TextString bevo_17 = (new BEC_2_4_6_TextString(bels_73, 1));
private static byte[] bels_74 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_18 = (new BEC_2_4_6_TextString(bels_74, 4));
private static byte[] bels_75 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bevo_19 = (new BEC_2_4_6_TextString(bels_75, 27));
private static byte[] bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_20 = (new BEC_2_4_6_TextString(bels_76, 22));
private static byte[] bels_77 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_21 = (new BEC_2_4_6_TextString(bels_77, 2));
private static byte[] bels_78 = {0x29};
private static BEC_2_4_6_TextString bevo_22 = (new BEC_2_4_6_TextString(bels_78, 1));
private static byte[] bels_79 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bevo_23 = (new BEC_2_4_6_TextString(bels_79, 4));
private static byte[] bels_80 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bevo_24 = (new BEC_2_4_6_TextString(bels_80, 32));
private static byte[] bels_81 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_25 = (new BEC_2_4_6_TextString(bels_81, 22));
private static byte[] bels_82 = {0x2C,0x20};
private static BEC_2_4_6_TextString bevo_26 = (new BEC_2_4_6_TextString(bels_82, 2));
private static byte[] bels_83 = {0x29};
private static BEC_2_4_6_TextString bevo_27 = (new BEC_2_4_6_TextString(bels_83, 1));
private static byte[] bels_84 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bels_85 = {0x76,0x61,0x72,0x20};
private static byte[] bels_86 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bels_87 = {0x7D};
private static byte[] bels_88 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_28 = (new BEC_2_4_6_TextString(bels_88, 5));
private static byte[] bels_89 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_29 = (new BEC_2_4_6_TextString(bels_89, 4));
private static byte[] bels_90 = {};
private static byte[] bels_91 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_30 = (new BEC_2_4_6_TextString(bels_91, 11));
private static byte[] bels_92 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bevo_31 = (new BEC_2_4_6_TextString(bels_92, 5));
private static byte[] bels_93 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bevo_32 = (new BEC_2_4_6_TextString(bels_93, 3));
private static byte[] bels_94 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bevo_33 = (new BEC_2_4_6_TextString(bels_94, 11));
private static byte[] bels_95 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bevo_34 = (new BEC_2_4_6_TextString(bels_95, 4));
private static byte[] bels_96 = {0x3B};
private static BEC_2_4_6_TextString bevo_35 = (new BEC_2_4_6_TextString(bels_96, 1));
private static byte[] bels_97 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_98 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bels_99 = {};
private static byte[] bels_100 = {};
private static byte[] bels_101 = {};
private static byte[] bels_102 = {};
private static byte[] bels_103 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bels_104 = {};
private static byte[] bels_105 = {};
private static byte[] bels_106 = {};
private static byte[] bels_107 = {};
private static byte[] bels_108 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bevo_36 = (new BEC_2_4_6_TextString(bels_108, 7));
private static byte[] bels_109 = {0x3A,0x20};
private static BEC_2_4_6_TextString bevo_37 = (new BEC_2_4_6_TextString(bels_109, 2));
private static byte[] bels_110 = {};
private static byte[] bels_111 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bevo_38 = (new BEC_2_4_6_TextString(bels_111, 31));
private static byte[] bels_112 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bevo_39 = (new BEC_2_4_6_TextString(bels_112, 22));
private static byte[] bels_113 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bevo_40 = (new BEC_2_4_6_TextString(bels_113, 5));
private static byte[] bels_114 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bels_115 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bels_116 = {0x29,0x20,0x7B};
private static byte[] bels_117 = {};
private static byte[] bels_118 = {0x5F};
private static BEC_2_4_6_TextString bevo_41 = (new BEC_2_4_6_TextString(bels_118, 1));
private static byte[] bels_119 = {0x62,0x65};
public static BEC_2_5_9_BuildJSEmitter bevs_inst;
public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public BEC_2_6_6_SystemObject bem_new_1(BEC_2_5_5_BuildBuild beva__build) throws Throwable {
bevp_emitLang = (new BEC_2_4_6_TextString(2, bels_0));
bevp_fileExt = (new BEC_2_4_6_TextString(3, bels_1));
bevp_exceptDec = (new BEC_2_4_6_TextString(0, bels_2));
super.bem_new_1(beva__build);
bevp_trueValue = (new BEC_2_4_6_TextString(34, bels_3));
bevp_falseValue = (new BEC_2_4_6_TextString(35, bels_4));
bevp_instanceEqual = (new BEC_2_4_6_TextString(5, bels_5));
bevp_instanceNotEqual = (new BEC_2_4_6_TextString(5, bels_6));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(28, bels_7));
bevt_2_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = this.bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(15, bels_8));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch = bevp_methodCatch.bem_increment_0();
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(8, bels_10));
bevt_4_tmpany_phold = bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_11));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(432255188, BEL_4_Base.bevn_containedGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-183400265, BEL_4_Base.bevn_firstGet_0);
bevt_14_tmpany_phold = bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = this.bem_finalAssign_3((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold, bevt_12_tmpany_phold, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildClassInfoMethod_1(BEC_2_4_6_TextString beva_belsBase) throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(22, bels_14));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_15));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildCreate_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(37, bels_16));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_17));
bevt_6_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_9_tmpany_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold);
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_18));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_19));
bevt_14_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildPropList_0() throws Throwable {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(26, bels_20));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 73 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_5_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
if (bevl_first.bevi_bool) /* Line: 74 */ {
bevl_first = be.BECS_Runtime.boolFalse;
} /* Line: 75 */
 else  /* Line: 76 */ {
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_21));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 77 */
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(5, bels_22));
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 79 */
 else  /* Line: 73 */ {
break;
} /* Line: 73 */
} /* Line: 73 */
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_23));
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_buildInitial_0() throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevl_newcc = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold);
bevl_stinst = this.bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(50, bels_24));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (new BEC_2_4_6_TextString(14, bels_25));
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_26));
bevt_9_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(41, bels_27));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bels_28));
bevt_17_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_29));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_30));
bevt_20_tmpany_phold = bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
this.bem_buildPropList_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) throws Throwable {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_31));
bevt_0_tmpany_phold = beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_2_tmpany_phold = bevo_3;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 124 */
bevt_4_tmpany_phold = super.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLib_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_typeInstances = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
bevl_libe = this.bem_getLibOutput_0();
bevl_typeInstances = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_libInit = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 138 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 138 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(40, bels_33));
bevt_8_tmpany_phold = bevl_typeInstances.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1774940957, BEL_4_Base.bevn_toString_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_34));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_15_tmpany_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_35));
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_20_tmpany_phold != null && bevt_20_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_20_tmpany_phold).bevi_bool) /* Line: 144 */ {
bevt_24_tmpany_phold = bevo_4;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(354142775, BEL_4_Base.bevn_namepathGet_0);
bevt_26_tmpany_phold = this.bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold);
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bevo_5;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(65, bels_38));
bevt_33_tmpany_phold = bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_39));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(931239762, BEL_4_Base.bevn_heldGet_0);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(1791388575, BEL_4_Base.bevn_synGet_0);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(481879936, BEL_4_Base.bevn_hasDefaultGet_0);
if (bevt_36_tmpany_phold != null && bevt_36_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_36_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevt_42_tmpany_phold = (new BEC_2_4_6_TextString(63, bels_40));
bevt_41_tmpany_phold = bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_41));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 154 */
} /* Line: 153 */
} /* Line: 144 */
 else  /* Line: 138 */ {
break;
} /* Line: 138 */
} /* Line: 138 */
bevl_smap = (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 162 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_45_tmpany_phold).bevi_bool) /* Line: 162 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(42, bels_42));
bevt_52_tmpany_phold = bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_43));
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_44));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (new BEC_2_4_6_TextString(43, bels_45));
bevt_67_tmpany_phold = bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_46));
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_47));
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 165 */
 else  /* Line: 162 */ {
break;
} /* Line: 162 */
} /* Line: 162 */
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_typeInstances);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bevo_6;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(91, bels_48));
bevt_80_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(93, bels_49));
bevt_82_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(78, bels_50));
bevt_84_tmpany_phold = bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 177 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = this.bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (new BEC_2_4_6_TextString(0, bels_51));
bevt_90_tmpany_phold = (new BEC_2_4_6_TextString(13, bels_52));
bevt_89_tmpany_phold = bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_53));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(46, bels_54));
bevt_94_tmpany_phold = bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 191 */
bevt_99_tmpany_phold = (new BEC_2_4_6_TextString(42, bels_55));
bevt_98_tmpany_phold = bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_56));
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (new BEC_2_4_6_TextString(0, bels_57));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_105_tmpany_phold = (new BEC_2_4_6_TextString(15, bels_58));
bevt_104_tmpany_phold = bevl_main.bem_addValue_1(bevt_105_tmpany_phold);
bevt_104_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpany_phold = (new BEC_2_4_6_TextString(16, bels_59));
bevt_106_tmpany_phold = bevl_main.bem_addValue_1(bevt_107_tmpany_phold);
bevt_106_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 200 */
bevl_libe.bem_write_1(bevl_main);
this.bem_finishLibOutput_1(bevl_libe);
bevt_108_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 206 */ {
this.bem_saveSyns_0();
} /* Line: 207 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_decForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 213 */ {
} /* Line: 213 */
 else  /* Line: 215 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_60));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 217 */
bevt_4_tmpany_phold = this.bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 219 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_boolTypeGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(7, bels_61));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_mainStartGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_superNameGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_64));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) throws Throwable {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevo_11;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bevo_12;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevo_13;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bevo_14;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bevo_15;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevo_16;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1087506597, BEL_4_Base.bevn_literalValueGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bevo_17;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 251 */ {
bevt_8_tmpany_phold = bevo_18;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bevo_19;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bevo_20;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bevo_21;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bevo_22;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 252 */
bevt_24_tmpany_phold = bevo_23;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bevo_24;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bevo_25;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bevo_26;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bevo_27;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) throws Throwable {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = this.bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 259 */
 else  /* Line: 260 */ {
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(14, bels_84));
bevl_extends = this.bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 261 */
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(4, bels_85));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(15, bels_86));
bevl_begin = bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (new BEC_2_4_6_TextString(1, bels_87));
bevt_8_tmpany_phold = bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameForCall_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1796577138, BEL_4_Base.bevn_superCallGet_0);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_0_tmpany_phold).bevi_bool) /* Line: 277 */ {
bevt_3_tmpany_phold = bevo_28;
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 278 */
bevt_7_tmpany_phold = bevo_29;
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_classEndGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevl_end = (new BEC_2_4_6_TextString(0, bels_90));
bevt_0_tmpany_loop = bevp_superCalls.bem_iteratorGet_0();
while (true)
 /* Line: 285 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_1_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = bevo_30;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevo_31;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bevo_32;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = bevo_33;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevo_34;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1211273660, BEL_4_Base.bevn_nameGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevo_35;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
return bevl_end;
} /*method end*/
public BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevp_allOnceDecs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 296 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() throws Throwable {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = this.bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) throws Throwable {
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() throws Throwable {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevp_lineCount = (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 314 */ {
bevt_7_tmpany_phold = bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 315 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (new BEC_2_4_6_TextString(9, bels_97));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (new BEC_2_4_6_TextString(9, bels_98));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 320 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEL_4_Base.bevn_hasNextGet_0);
if (bevt_16_tmpany_phold != null && bevt_16_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool)bevt_16_tmpany_phold).bevi_bool) /* Line: 320 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEL_4_Base.bevn_nextGet_0);
bevt_17_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1010579589, BEL_4_Base.bevn_open_0);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(347960120, BEL_4_Base.bevn_readString_0);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(866536361, BEL_4_Base.bevn_close_0);
bevt_21_tmpany_phold = this.bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 325 */
 else  /* Line: 320 */ {
break;
} /* Line: 320 */
} /* Line: 320 */
} /* Line: 320 */
} /* Line: 319 */
return bevp_shlibe;
} /*method end*/
public BEC_2_6_6_SystemObject bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) throws Throwable {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_99));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_100));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_101));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_endNs_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_102));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(13, bels_103));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_spropDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_104));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_propDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_105));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_initialDecGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_106));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_107));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bevo_36;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bevo_37;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_110));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevo_38;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevo_39;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevo_40;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (new BEC_2_4_6_TextString(11, bels_114));
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (new BEC_2_4_6_TextString(12, bels_115));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (new BEC_2_4_6_TextString(3, bels_116));
bevt_6_tmpany_phold = bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_formCast_1(BEC_2_5_11_BuildClassConfig beva_cc) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(0, bels_117));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevo_41;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(2, bels_119));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = super.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) throws Throwable {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = super.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() throws Throwable {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() throws Throwable {
return bevp_shlibe;
} /*method end*/
public BEC_2_6_6_SystemObject bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 21, 22, 26, 28, 29, 31, 32, 36, 36, 36, 36, 36, 36, 36, 36, 40, 40, 40, 41, 42, 42, 42, 42, 42, 42, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 55, 55, 55, 55, 55, 55, 55, 59, 59, 59, 59, 59, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 62, 62, 62, 67, 67, 68, 70, 70, 70, 70, 72, 73, 0, 73, 73, 75, 77, 77, 79, 79, 79, 79, 79, 79, 83, 83, 83, 88, 88, 88, 89, 91, 91, 91, 91, 91, 94, 94, 94, 94, 96, 96, 96, 98, 98, 98, 98, 98, 101, 101, 101, 101, 101, 101, 103, 103, 103, 105, 110, 111, 112, 118, 118, 118, 123, 124, 124, 124, 124, 126, 126, 132, 134, 135, 136, 137, 138, 138, 140, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 144, 144, 144, 146, 146, 146, 146, 146, 146, 146, 146, 146, 152, 152, 152, 152, 152, 152, 153, 153, 153, 154, 154, 154, 154, 154, 154, 160, 162, 162, 0, 162, 162, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 164, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 165, 169, 171, 174, 174, 174, 174, 174, 175, 175, 175, 176, 176, 176, 177, 177, 177, 180, 181, 184, 185, 185, 186, 188, 189, 189, 189, 189, 189, 189, 189, 190, 191, 191, 191, 193, 193, 193, 193, 193, 193, 193, 193, 194, 195, 196, 197, 198, 199, 199, 199, 200, 200, 200, 202, 204, 206, 207, 213, 216, 216, 216, 217, 217, 219, 219, 224, 224, 228, 228, 228, 228, 228, 228, 232, 232, 237, 237, 237, 237, 237, 237, 237, 238, 238, 238, 238, 238, 239, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 243, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 247, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 258, 258, 259, 259, 259, 261, 261, 263, 263, 263, 263, 263, 271, 271, 271, 272, 273, 277, 277, 278, 278, 278, 278, 278, 280, 280, 280, 280, 280, 284, 285, 0, 285, 285, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 286, 288, 295, 295, 296, 298, 299, 299, 304, 304, 312, 312, 313, 314, 314, 314, 314, 314, 315, 315, 315, 317, 317, 317, 319, 319, 319, 320, 320, 320, 320, 0, 320, 320, 321, 321, 322, 322, 322, 323, 323, 324, 324, 325, 331, 335, 336, 341, 341, 345, 345, 349, 349, 353, 353, 357, 357, 361, 361, 365, 365, 370, 370, 375, 375, 379, 379, 379, 379, 379, 379, 383, 383, 387, 387, 387, 387, 387, 392, 392, 392, 392, 392, 392, 392, 397, 397, 397, 397, 397, 397, 397, 399, 401, 401, 401, 406, 406, 410, 410, 414, 414, 414, 414, 419, 419, 423, 424, 424, 425, 429, 430, 430, 431, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {173, 174, 175, 176, 177, 178, 179, 180, 191, 192, 193, 194, 195, 196, 197, 198, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 251, 252, 253, 254, 255, 256, 257, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 317, 318, 319, 320, 321, 322, 323, 324, 325, 325, 328, 330, 332, 335, 336, 338, 339, 340, 341, 342, 343, 349, 350, 351, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 414, 415, 416, 422, 423, 424, 433, 435, 436, 437, 438, 440, 441, 566, 567, 568, 569, 570, 571, 574, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 619, 620, 621, 622, 623, 624, 632, 633, 634, 634, 637, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 677, 678, 679, 680, 681, 682, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 714, 715, 716, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 732, 733, 734, 735, 736, 737, 739, 740, 741, 743, 753, 757, 758, 763, 764, 765, 767, 768, 774, 775, 783, 784, 785, 786, 787, 788, 792, 793, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 954, 959, 960, 961, 962, 965, 966, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 990, 991, 993, 994, 995, 996, 997, 999, 1000, 1001, 1002, 1003, 1032, 1033, 1033, 1036, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1067, 1072, 1077, 1078, 1080, 1081, 1082, 1086, 1087, 1118, 1123, 1124, 1125, 1126, 1127, 1128, 1133, 1134, 1135, 1136, 1138, 1139, 1140, 1141, 1142, 1143, 1145, 1146, 1147, 1148, 1148, 1151, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1161, 1162, 1163, 1171, 1174, 1175, 1180, 1181, 1185, 1186, 1190, 1191, 1195, 1196, 1200, 1201, 1205, 1206, 1210, 1211, 1215, 1216, 1220, 1221, 1229, 1230, 1231, 1232, 1233, 1234, 1238, 1239, 1246, 1247, 1248, 1249, 1250, 1259, 1260, 1261, 1262, 1263, 1264, 1265, 1276, 1277, 1278, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1291, 1292, 1296, 1297, 1303, 1304, 1305, 1306, 1310, 1311, 1316, 1317, 1318, 1319, 1324, 1325, 1326, 1327, 1330, 1333, 1337, 1340};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 173
new 0 20 173
assign 1 21 174
new 0 21 174
assign 1 22 175
new 0 22 175
new 1 26 176
assign 1 28 177
new 0 28 177
assign 1 29 178
new 0 29 178
assign 1 31 179
new 0 31 179
assign 1 32 180
new 0 32 180
assign 1 36 191
new 0 36 191
assign 1 36 192
addValue 1 36 192
assign 1 36 193
secondGet 0 36 193
assign 1 36 194
formTarg 1 36 194
assign 1 36 195
addValue 1 36 195
assign 1 36 196
new 0 36 196
assign 1 36 197
addValue 1 36 197
addValue 1 36 198
assign 1 40 219
new 0 40 219
assign 1 40 220
toString 0 40 220
assign 1 40 221
add 1 40 221
assign 1 41 222
increment 0 41 222
assign 1 42 223
new 0 42 223
assign 1 42 224
addValue 1 42 224
assign 1 42 225
addValue 1 42 225
assign 1 42 226
new 0 42 226
assign 1 42 227
addValue 1 42 227
addValue 1 42 228
assign 1 47 229
containedGet 0 47 229
assign 1 47 230
firstGet 0 47 230
assign 1 47 231
containedGet 0 47 231
assign 1 47 232
firstGet 0 47 232
assign 1 47 233
new 0 47 233
assign 1 47 234
add 1 47 234
assign 1 47 235
new 0 47 235
assign 1 47 236
add 1 47 236
assign 1 47 237
finalAssign 3 47 237
addValue 1 47 238
assign 1 55 251
emitNameGet 0 55 251
assign 1 55 252
addValue 1 55 252
assign 1 55 253
new 0 55 253
assign 1 55 254
addValue 1 55 254
assign 1 55 255
addValue 1 55 255
assign 1 55 256
new 0 55 256
addValue 1 55 257
assign 1 59 277
emitNameGet 0 59 277
assign 1 59 278
addValue 1 59 278
assign 1 59 279
new 0 59 279
assign 1 59 280
addValue 1 59 280
addValue 1 59 281
assign 1 60 282
new 0 60 282
assign 1 60 283
addValue 1 60 283
assign 1 60 284
heldGet 0 60 284
assign 1 60 285
namepathGet 0 60 285
assign 1 60 286
getClassConfig 1 60 286
assign 1 60 287
libNameGet 0 60 287
assign 1 60 288
relEmitName 1 60 288
assign 1 60 289
addValue 1 60 289
assign 1 60 290
new 0 60 290
assign 1 60 291
addValue 1 60 291
addValue 1 60 292
assign 1 62 293
new 0 62 293
assign 1 62 294
addValue 1 62 294
addValue 1 62 295
assign 1 67 317
heldGet 0 67 317
assign 1 67 318
synGet 0 67 318
assign 1 68 319
ptyListGet 0 68 319
assign 1 70 320
emitNameGet 0 70 320
assign 1 70 321
addValue 1 70 321
assign 1 70 322
new 0 70 322
addValue 1 70 323
assign 1 72 324
new 0 72 324
assign 1 73 325
iteratorGet 0 0 325
assign 1 73 328
hasNextGet 0 73 328
assign 1 73 330
nextGet 0 73 330
assign 1 75 332
new 0 75 332
assign 1 77 335
new 0 77 335
addValue 1 77 336
assign 1 79 338
addValue 1 79 338
assign 1 79 339
new 0 79 339
assign 1 79 340
addValue 1 79 340
assign 1 79 341
nameGet 0 79 341
assign 1 79 342
addValue 1 79 342
addValue 1 79 343
assign 1 83 349
new 0 83 349
assign 1 83 350
addValue 1 83 350
addValue 1 83 351
assign 1 88 379
heldGet 0 88 379
assign 1 88 380
namepathGet 0 88 380
assign 1 88 381
getClassConfig 1 88 381
assign 1 89 382
getInitialInst 1 89 382
assign 1 91 383
emitNameGet 0 91 383
assign 1 91 384
addValue 1 91 384
assign 1 91 385
new 0 91 385
assign 1 91 386
addValue 1 91 386
addValue 1 91 387
assign 1 94 388
addValue 1 94 388
assign 1 94 389
new 0 94 389
assign 1 94 390
addValue 1 94 390
addValue 1 94 391
assign 1 96 392
new 0 96 392
assign 1 96 393
addValue 1 96 393
addValue 1 96 394
assign 1 98 395
emitNameGet 0 98 395
assign 1 98 396
addValue 1 98 396
assign 1 98 397
new 0 98 397
assign 1 98 398
addValue 1 98 398
addValue 1 98 399
assign 1 101 400
new 0 101 400
assign 1 101 401
addValue 1 101 401
assign 1 101 402
addValue 1 101 402
assign 1 101 403
new 0 101 403
assign 1 101 404
addValue 1 101 404
addValue 1 101 405
assign 1 103 406
new 0 103 406
assign 1 103 407
addValue 1 103 407
addValue 1 103 408
buildPropList 0 105 409
getCode 2 110 414
assign 1 111 415
toString 0 111 415
addValue 1 112 416
assign 1 118 422
new 0 118 422
assign 1 118 423
addValue 1 118 423
addValue 1 118 424
assign 1 123 433
isPropertyGet 0 123 433
assign 1 124 435
new 0 124 435
assign 1 124 436
nameGet 0 124 436
assign 1 124 437
add 1 124 437
return 1 124 438
assign 1 126 440
nameForVar 1 126 440
return 1 126 441
assign 1 132 566
getLibOutput 0 132 566
assign 1 134 567
new 0 134 567
assign 1 135 568
new 0 135 568
assign 1 136 569
new 0 136 569
assign 1 137 570
new 0 137 570
assign 1 138 571
iteratorGet 0 138 571
assign 1 138 574
hasNextGet 0 138 574
assign 1 140 576
nextGet 0 140 576
assign 1 142 577
new 0 142 577
assign 1 142 578
addValue 1 142 578
assign 1 142 579
addValue 1 142 579
assign 1 142 580
heldGet 0 142 580
assign 1 142 581
namepathGet 0 142 581
assign 1 142 582
toString 0 142 582
assign 1 142 583
addValue 1 142 583
assign 1 142 584
addValue 1 142 584
assign 1 142 585
new 0 142 585
assign 1 142 586
addValue 1 142 586
assign 1 142 587
heldGet 0 142 587
assign 1 142 588
namepathGet 0 142 588
assign 1 142 589
getClassConfig 1 142 589
assign 1 142 590
libNameGet 0 142 590
assign 1 142 591
relEmitName 1 142 591
assign 1 142 592
addValue 1 142 592
assign 1 142 593
new 0 142 593
assign 1 142 594
addValue 1 142 594
addValue 1 142 595
assign 1 144 596
heldGet 0 144 596
assign 1 144 597
synGet 0 144 597
assign 1 144 598
hasDefaultGet 0 144 598
assign 1 146 600
new 0 146 600
assign 1 146 601
heldGet 0 146 601
assign 1 146 602
namepathGet 0 146 602
assign 1 146 603
getClassConfig 1 146 603
assign 1 146 604
libNameGet 0 146 604
assign 1 146 605
relEmitName 1 146 605
assign 1 146 606
add 1 146 606
assign 1 146 607
new 0 146 607
assign 1 146 608
add 1 146 608
assign 1 152 609
new 0 152 609
assign 1 152 610
addValue 1 152 610
assign 1 152 611
addValue 1 152 611
assign 1 152 612
new 0 152 612
assign 1 152 613
addValue 1 152 613
addValue 1 152 614
assign 1 153 615
heldGet 0 153 615
assign 1 153 616
synGet 0 153 616
assign 1 153 617
hasDefaultGet 0 153 617
assign 1 154 619
new 0 154 619
assign 1 154 620
addValue 1 154 620
assign 1 154 621
addValue 1 154 621
assign 1 154 622
new 0 154 622
assign 1 154 623
addValue 1 154 623
addValue 1 154 624
assign 1 160 632
new 0 160 632
assign 1 162 633
keysGet 0 162 633
assign 1 162 634
iteratorGet 0 0 634
assign 1 162 637
hasNextGet 0 162 637
assign 1 162 639
nextGet 0 162 639
assign 1 164 640
new 0 164 640
assign 1 164 641
addValue 1 164 641
assign 1 164 642
new 0 164 642
assign 1 164 643
quoteGet 0 164 643
assign 1 164 644
addValue 1 164 644
assign 1 164 645
addValue 1 164 645
assign 1 164 646
new 0 164 646
assign 1 164 647
quoteGet 0 164 647
assign 1 164 648
addValue 1 164 648
assign 1 164 649
new 0 164 649
assign 1 164 650
addValue 1 164 650
assign 1 164 651
get 1 164 651
assign 1 164 652
addValue 1 164 652
assign 1 164 653
new 0 164 653
assign 1 164 654
addValue 1 164 654
addValue 1 164 655
assign 1 165 656
new 0 165 656
assign 1 165 657
addValue 1 165 657
assign 1 165 658
new 0 165 658
assign 1 165 659
quoteGet 0 165 659
assign 1 165 660
addValue 1 165 660
assign 1 165 661
addValue 1 165 661
assign 1 165 662
new 0 165 662
assign 1 165 663
quoteGet 0 165 663
assign 1 165 664
addValue 1 165 664
assign 1 165 665
new 0 165 665
assign 1 165 666
addValue 1 165 666
assign 1 165 667
get 1 165 667
assign 1 165 668
addValue 1 165 668
assign 1 165 669
new 0 165 669
assign 1 165 670
addValue 1 165 670
addValue 1 165 671
write 1 169 677
write 1 171 678
assign 1 174 679
usedLibrarysGet 0 174 679
assign 1 174 680
sizeGet 0 174 680
assign 1 174 681
new 0 174 681
assign 1 174 682
equals 1 174 687
assign 1 175 688
new 0 175 688
assign 1 175 689
addValue 1 175 689
addValue 1 175 690
assign 1 176 691
new 0 176 691
assign 1 176 692
addValue 1 176 692
addValue 1 176 693
assign 1 177 694
new 0 177 694
assign 1 177 695
addValue 1 177 695
addValue 1 177 696
write 1 180 698
write 1 181 699
assign 1 184 700
new 0 184 700
assign 1 185 701
mainNameGet 0 185 701
fromString 1 185 702
assign 1 186 703
getClassConfig 1 186 703
assign 1 188 704
new 0 188 704
assign 1 189 705
new 0 189 705
assign 1 189 706
addValue 1 189 706
assign 1 189 707
fullEmitNameGet 0 189 707
assign 1 189 708
addValue 1 189 708
assign 1 189 709
new 0 189 709
assign 1 189 710
addValue 1 189 710
addValue 1 189 711
assign 1 190 712
ownProcessGet 0 190 712
assign 1 191 714
new 0 191 714
assign 1 191 715
addValue 1 191 715
addValue 1 191 716
assign 1 193 718
new 0 193 718
assign 1 193 719
addValue 1 193 719
assign 1 193 720
outputPlatformGet 0 193 720
assign 1 193 721
nameGet 0 193 721
assign 1 193 722
addValue 1 193 722
assign 1 193 723
new 0 193 723
assign 1 193 724
addValue 1 193 724
addValue 1 193 725
write 1 194 726
assign 1 195 727
new 0 195 727
write 1 196 728
write 1 197 729
assign 1 198 730
ownProcessGet 0 198 730
assign 1 199 732
new 0 199 732
assign 1 199 733
addValue 1 199 733
addValue 1 199 734
assign 1 200 735
new 0 200 735
assign 1 200 736
addValue 1 200 736
addValue 1 200 737
write 1 202 739
finishLibOutput 1 204 740
assign 1 206 741
saveSynsGet 0 206 741
saveSyns 0 207 743
assign 1 213 753
isPropertyGet 0 213 753
assign 1 216 757
isArgGet 0 216 757
assign 1 216 758
not 0 216 763
assign 1 217 764
new 0 217 764
addValue 1 217 765
assign 1 219 767
nameForVar 1 219 767
addValue 1 219 768
assign 1 224 774
new 0 224 774
return 1 224 775
assign 1 228 783
new 0 228 783
assign 1 228 784
add 1 228 784
assign 1 228 785
new 0 228 785
assign 1 228 786
add 1 228 786
assign 1 228 787
add 1 228 787
return 1 228 788
assign 1 232 792
new 0 232 792
return 1 232 793
assign 1 237 807
emitNameGet 0 237 807
assign 1 237 808
new 0 237 808
assign 1 237 809
add 1 237 809
assign 1 237 810
add 1 237 810
assign 1 237 811
new 0 237 811
assign 1 237 812
add 1 237 812
assign 1 237 813
addValue 1 237 813
assign 1 238 814
emitNameGet 0 238 814
assign 1 238 815
add 1 238 815
assign 1 238 816
new 0 238 816
assign 1 238 817
add 1 238 817
assign 1 238 818
addValue 1 238 818
return 1 239 819
assign 1 243 833
new 0 243 833
assign 1 243 834
libNameGet 0 243 834
assign 1 243 835
relEmitName 1 243 835
assign 1 243 836
add 1 243 836
assign 1 243 837
new 0 243 837
assign 1 243 838
add 1 243 838
assign 1 243 839
heldGet 0 243 839
assign 1 243 840
literalValueGet 0 243 840
assign 1 243 841
add 1 243 841
assign 1 243 842
new 0 243 842
assign 1 243 843
add 1 243 843
return 1 243 844
assign 1 247 858
new 0 247 858
assign 1 247 859
libNameGet 0 247 859
assign 1 247 860
relEmitName 1 247 860
assign 1 247 861
add 1 247 861
assign 1 247 862
new 0 247 862
assign 1 247 863
add 1 247 863
assign 1 247 864
heldGet 0 247 864
assign 1 247 865
literalValueGet 0 247 865
assign 1 247 866
add 1 247 866
assign 1 247 867
new 0 247 867
assign 1 247 868
add 1 247 868
return 1 247 869
assign 1 252 905
new 0 252 905
assign 1 252 906
libNameGet 0 252 906
assign 1 252 907
relEmitName 1 252 907
assign 1 252 908
add 1 252 908
assign 1 252 909
new 0 252 909
assign 1 252 910
add 1 252 910
assign 1 252 911
emitNameGet 0 252 911
assign 1 252 912
add 1 252 912
assign 1 252 913
new 0 252 913
assign 1 252 914
add 1 252 914
assign 1 252 915
add 1 252 915
assign 1 252 916
new 0 252 916
assign 1 252 917
add 1 252 917
assign 1 252 918
add 1 252 918
assign 1 252 919
new 0 252 919
assign 1 252 920
add 1 252 920
return 1 252 921
assign 1 254 923
new 0 254 923
assign 1 254 924
libNameGet 0 254 924
assign 1 254 925
relEmitName 1 254 925
assign 1 254 926
add 1 254 926
assign 1 254 927
new 0 254 927
assign 1 254 928
add 1 254 928
assign 1 254 929
emitNameGet 0 254 929
assign 1 254 930
add 1 254 930
assign 1 254 931
new 0 254 931
assign 1 254 932
add 1 254 932
assign 1 254 933
add 1 254 933
assign 1 254 934
new 0 254 934
assign 1 254 935
add 1 254 935
assign 1 254 936
add 1 254 936
assign 1 254 937
new 0 254 937
assign 1 254 938
add 1 254 938
return 1 254 939
assign 1 258 954
def 1 258 959
assign 1 259 960
libNameGet 0 259 960
assign 1 259 961
relEmitName 1 259 961
assign 1 259 962
extend 1 259 962
assign 1 261 965
new 0 261 965
assign 1 261 966
extend 1 261 966
assign 1 263 968
new 0 263 968
assign 1 263 969
emitNameGet 0 263 969
assign 1 263 970
addValue 1 263 970
assign 1 263 971
new 0 263 971
assign 1 263 972
addValue 1 263 972
assign 1 271 973
new 0 271 973
assign 1 271 974
addValue 1 271 974
addValue 1 271 975
addValue 1 272 976
return 1 273 977
assign 1 277 990
heldGet 0 277 990
assign 1 277 991
superCallGet 0 277 991
assign 1 278 993
new 0 278 993
assign 1 278 994
heldGet 0 278 994
assign 1 278 995
nameGet 0 278 995
assign 1 278 996
add 1 278 996
return 1 278 997
assign 1 280 999
new 0 280 999
assign 1 280 1000
heldGet 0 280 1000
assign 1 280 1001
nameGet 0 280 1001
assign 1 280 1002
add 1 280 1002
return 1 280 1003
assign 1 284 1032
new 0 284 1032
assign 1 285 1033
iteratorGet 0 0 1033
assign 1 285 1036
hasNextGet 0 285 1036
assign 1 285 1038
nextGet 0 285 1038
assign 1 286 1039
emitNameGet 0 286 1039
assign 1 286 1040
new 0 286 1040
assign 1 286 1041
add 1 286 1041
assign 1 286 1042
new 0 286 1042
assign 1 286 1043
add 1 286 1043
assign 1 286 1044
heldGet 0 286 1044
assign 1 286 1045
nameGet 0 286 1045
assign 1 286 1046
add 1 286 1046
assign 1 286 1047
new 0 286 1047
assign 1 286 1048
add 1 286 1048
assign 1 286 1049
emitNameGet 0 286 1049
assign 1 286 1050
add 1 286 1050
assign 1 286 1051
new 0 286 1051
assign 1 286 1052
add 1 286 1052
assign 1 286 1053
new 0 286 1053
assign 1 286 1054
add 1 286 1054
assign 1 286 1055
heldGet 0 286 1055
assign 1 286 1056
nameGet 0 286 1056
assign 1 286 1057
add 1 286 1057
assign 1 286 1058
new 0 286 1058
assign 1 286 1059
add 1 286 1059
assign 1 286 1060
add 1 286 1060
addValue 1 286 1061
return 1 288 1067
assign 1 295 1072
undef 1 295 1077
assign 1 296 1078
new 0 296 1078
addValue 1 298 1080
assign 1 299 1081
new 0 299 1081
return 1 299 1082
assign 1 304 1086
getLibOutput 0 304 1086
return 1 304 1087
assign 1 312 1118
undef 1 312 1123
assign 1 313 1124
new 0 313 1124
assign 1 314 1125
parentGet 0 314 1125
assign 1 314 1126
fileGet 0 314 1126
assign 1 314 1127
existsGet 0 314 1127
assign 1 314 1128
not 0 314 1133
assign 1 315 1134
parentGet 0 315 1134
assign 1 315 1135
fileGet 0 315 1135
makeDirs 0 315 1136
assign 1 317 1138
fileGet 0 317 1138
assign 1 317 1139
writerGet 0 317 1139
assign 1 317 1140
open 0 317 1140
assign 1 319 1141
paramsGet 0 319 1141
assign 1 319 1142
new 0 319 1142
assign 1 319 1143
has 1 319 1143
assign 1 320 1145
paramsGet 0 320 1145
assign 1 320 1146
new 0 320 1146
assign 1 320 1147
get 1 320 1147
assign 1 320 1148
iteratorGet 0 0 1148
assign 1 320 1151
hasNextGet 0 320 1151
assign 1 320 1153
nextGet 0 320 1153
assign 1 321 1154
apNew 1 321 1154
assign 1 321 1155
fileGet 0 321 1155
assign 1 322 1156
readerGet 0 322 1156
assign 1 322 1157
open 0 322 1157
assign 1 322 1158
readString 0 322 1158
assign 1 323 1159
readerGet 0 323 1159
close 0 323 1160
assign 1 324 1161
countLines 1 324 1161
addValue 1 324 1162
write 1 325 1163
return 1 331 1171
close 0 335 1174
assign 1 336 1175
assign 1 341 1180
new 0 341 1180
return 1 341 1181
assign 1 345 1185
new 0 345 1185
return 1 345 1186
assign 1 349 1190
new 0 349 1190
return 1 349 1191
assign 1 353 1195
new 0 353 1195
return 1 353 1196
assign 1 357 1200
new 0 357 1200
return 1 357 1201
assign 1 361 1205
new 0 361 1205
return 1 361 1206
assign 1 365 1210
new 0 365 1210
return 1 365 1211
assign 1 370 1215
new 0 370 1215
return 1 370 1216
assign 1 375 1220
new 0 375 1220
return 1 375 1221
assign 1 379 1229
new 0 379 1229
assign 1 379 1230
add 1 379 1230
assign 1 379 1231
new 0 379 1231
assign 1 379 1232
add 1 379 1232
assign 1 379 1233
add 1 379 1233
return 1 379 1234
assign 1 383 1238
new 0 383 1238
return 1 383 1239
assign 1 387 1246
libNameGet 0 387 1246
assign 1 387 1247
relEmitName 1 387 1247
assign 1 387 1248
new 0 387 1248
assign 1 387 1249
add 1 387 1249
return 1 387 1250
assign 1 392 1259
emitNameGet 0 392 1259
assign 1 392 1260
new 0 392 1260
assign 1 392 1261
add 1 392 1261
assign 1 392 1262
new 0 392 1262
assign 1 392 1263
add 1 392 1263
assign 1 392 1264
add 1 392 1264
return 1 392 1265
assign 1 397 1276
emitNameGet 0 397 1276
assign 1 397 1277
addValue 1 397 1277
assign 1 397 1278
new 0 397 1278
assign 1 397 1279
addValue 1 397 1279
assign 1 397 1280
addValue 1 397 1280
assign 1 397 1281
new 0 397 1281
addValue 1 397 1282
addValue 1 399 1283
assign 1 401 1284
new 0 401 1284
assign 1 401 1285
addValue 1 401 1285
addValue 1 401 1286
assign 1 406 1291
new 0 406 1291
return 1 406 1292
assign 1 410 1296
new 0 410 1296
return 1 410 1297
assign 1 414 1303
new 0 414 1303
assign 1 414 1304
add 1 414 1304
assign 1 414 1305
add 1 414 1305
return 1 414 1306
assign 1 419 1310
new 0 419 1310
return 1 419 1311
assign 1 423 1316
getClassConfig 1 423 1316
assign 1 424 1317
fullEmitNameGet 0 424 1317
emitNameSet 1 424 1318
return 1 425 1319
assign 1 429 1324
getLocalClassConfig 1 429 1324
assign 1 430 1325
fullEmitNameGet 0 430 1325
emitNameSet 1 430 1326
return 1 431 1327
return 1 0 1330
assign 1 0 1333
return 1 0 1337
assign 1 0 1340
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1109279973: return bem_spropDecGet_0();
case -397629001: return bem_maxSpillArgsLenGet_0();
case -229958684: return bem_constGet_0();
case -944442837: return bem_classConfGet_0();
case 362974009: return bem_parentConfGet_0();
case -1413054881: return bem_smnlcsGet_0();
case -103017121: return bem_runtimeInitGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 1859739893: return bem_methodsGet_0();
case 1529527065: return bem_onceCountGet_0();
case -1947619572: return bem_msynGet_0();
case 89706405: return bem_ccCacheGet_0();
case -1967844855: return bem_initialDecGet_0();
case 1774940957: return bem_toString_0();
case 1074463609: return bem_saveSyns_0();
case 879002404: return bem_lastMethodsLinesGet_0();
case -4647121: return bem_doEmit_0();
case -2039613615: return bem_instanceNotEqualGet_0();
case -955058175: return bem_lastMethodBodyLinesGet_0();
case 236269941: return bem_ccMethodsGet_0();
case 2001798761: return bem_nlGet_0();
case -1711936384: return bem_baseSmtdDecGet_0();
case -1308786538: return bem_echo_0();
case 1372235405: return bem_superCallsGet_0();
case -1786051763: return bem_methodCatchGet_0();
case -1081275759: return bem_classesInDepthOrderGet_0();
case 1380285640: return bem_objectCcGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 604504089: return bem_falseValueGet_0();
case 5583797: return bem_maxDynArgsGet_0();
case -378762597: return bem_boolNpGet_0();
case -1727672536: return bem_propDecGet_0();
case -628036310: return bem_lastMethodsSizeGet_0();
case -1487140092: return bem_classEndGet_0();
case 104713553: return bem_new_0();
case -402158238: return bem_inFilePathedGet_0();
case 1431933907: return bem_lastCallGet_0();
case 1177623581: return bem_callNamesGet_0();
case -991179882: return bem_qGet_0();
case -644675716: return bem_ntypesGet_0();
case -1081412016: return bem_many_0();
case 1638160588: return bem_lineCountGet_0();
case 2001828726: return bem_mainOutsideNsGet_0();
case 443668840: return bem_methodNotDefined_0();
case 772789066: return bem_libEmitPathGet_0();
case 2055025483: return bem_serializeContents_0();
case 1312373307: return bem_buildCreate_0();
case -1703922349: return bem_fullLibEmitNameGet_0();
case -845792839: return bem_iteratorGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case 36542021: return bem_mainEndGet_0();
case 916491491: return bem_emitLib_0();
case 603479476: return bem_allOnceDecsGet_0();
case -1747980150: return bem_smnlecsGet_0();
case -1841706211: return bem_returnTypeGet_0();
case -1073009537: return bem_beginNs_0();
case -2085643372: return bem_stringNpGet_0();
case -1500143225: return bem_useDynMethodsGet_0();
case -1052944126: return bem_csynGet_0();
case -1607412815: return bem_endNs_0();
case -86482693: return bem_overrideSmtdDecGet_0();
case -1923547459: return bem_boolCcGet_0();
case 1163853939: return bem_methodCallsGet_0();
case 498080472: return bem_mnodeGet_0();
case 1820417453: return bem_create_0();
case 962646066: return bem_shlibeGet_0();
case -946095539: return bem_mainInClassGet_0();
case -681402717: return bem_boolTypeGet_0();
case -101343106: return bem_nativeCSlotsGet_0();
case -493012039: return bem_buildGet_0();
case -206157822: return bem_coanyiantReturnsGet_0();
case -1354714650: return bem_copy_0();
case 1921215990: return bem_overrideMtdDecGet_0();
case -254265568: return bem_buildPropList_0();
case 361542143: return bem_classEmitsGet_0();
case -902412214: return bem_classCallsGet_0();
case -294732055: return bem_floatNpGet_0();
case -729571811: return bem_serializeToString_0();
case -1831751774: return bem_cnodeGet_0();
case -416660294: return bem_objectIteratorGet_0();
case -622039562: return bem_intNpGet_0();
case 1240611285: return bem_onceDecsGet_0();
case -786424307: return bem_tagGet_0();
case -991255330: return bem_mainStartGet_0();
case -722876119: return bem_buildClassInfo_0();
case -1910715228: return bem_libEmitNameGet_0();
case -797225458: return bem_dynMethodsGet_0();
case 1181505319: return bem_buildInitial_0();
case 2117559209: return bem_serializationIteratorGet_0();
case -1755995201: return bem_transGet_0();
case -1449942744: return bem_instanceEqualGet_0();
case -1012494862: return bem_once_0();
case -1369896794: return bem_objectNpGet_0();
case -1498619679: return bem_getLibOutput_0();
case 287040793: return bem_hashGet_0();
case -1317806639: return bem_baseMtdDecGet_0();
case 483359873: return bem_superNameGet_0();
case -1241388883: return bem_lastMethodBodySizeGet_0();
case -1795655423: return bem_propertyDecsGet_0();
case -1152064310: return bem_instOfGet_0();
case 1178070402: return bem_fileExtGet_0();
case 1102720804: return bem_classNameGet_0();
case -727049506: return bem_exceptDecGet_0();
case 57260628: return bem_getClassOutput_0();
case -388723214: return bem_preClassGet_0();
case 1327064356: return bem_methodBodyGet_0();
case -1926693913: return bem_synEmitPathGet_0();
case -1064889660: return bem_trueValueGet_0();
case -314718434: return bem_print_0();
case -220901978: return bem_emitLangGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case -571409003: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -367680344: return bem_boolNpSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case 890084657: return bem_lastMethodsLinesSet_1(bevd_0);
case 1649242841: return bem_lineCountSet_1(bevd_0);
case -229048805: return bem_begin_1(bevd_0);
case -1053807407: return bem_trueValueSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1490821560: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 443668841: return bem_methodNotDefined_1((BEC_2_6_11_SystemForwardCall) bevd_0);
case 2142670547: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 2144776371: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 165152860: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -1227314505: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -541207893: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -283649802: return bem_floatNpSet_1(bevd_0);
case 372624396: return bem_classEmitsSet_1(bevd_0);
case -1915611660: return bem_synEmitPathSet_1(bevd_0);
case 247352194: return bem_ccMethodsSet_1(bevd_0);
case 509162725: return bem_mnodeSet_1(bevd_0);
case -1702694534: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1140982057: return bem_instOfSet_1(bevd_0);
case 136278220: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 96651725: return bem_end_1(bevd_0);
case -1744912948: return bem_transSet_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case -610957309: return bem_intNpSet_1(bevd_0);
case -386546748: return bem_maxSpillArgsLenSet_1(bevd_0);
case 286757664: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1189152655: return bem_fileExtSet_1(bevd_0);
case -481929786: return bem_buildSet_1(bevd_0);
case 116598338: return bem_formRTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -593061802: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1401972628: return bem_smnlcsSet_1(bevd_0);
case 1093148766: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 973728319: return bem_shlibeSet_1(bevd_0);
case 1188705834: return bem_callNamesSet_1(bevd_0);
case 1815237879: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case -2028531362: return bem_instanceNotEqualSet_1(bevd_0);
case -891329961: return bem_classCallsSet_1(bevd_0);
case -1887784556: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1423829048: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1577659269: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 2064313158: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 166782299: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -980097629: return bem_qSet_1(bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case -1820669521: return bem_cnodeSet_1(bevd_0);
case -945327254: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 374056262: return bem_parentConfSet_1(bevd_0);
case -1073009536: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -90260853: return bem_nativeCSlotsSet_1(bevd_0);
case -1022041723: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 615586342: return bem_falseValueSet_1(bevd_0);
case -1230306630: return bem_lastMethodBodySizeSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1901078234: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -1070193506: return bem_classesInDepthOrderSet_1(bevd_0);
case 1870822146: return bem_methodsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case 1671519970: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1384315704: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1692840096: return bem_fullLibEmitNameSet_1(bevd_0);
case -596365949: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1912465206: return bem_boolCcSet_1(bevd_0);
case -377640961: return bem_preClassSet_1(bevd_0);
case 1540609318: return bem_onceCountSet_1(bevd_0);
case -943975922: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -933360584: return bem_classConfSet_1(bevd_0);
case 100788658: return bem_ccCacheSet_1(bevd_0);
case -1736897897: return bem_smnlecsSet_1(bevd_0);
case 1559080429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case -70425956: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case -16141842: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case 1174936192: return bem_methodCallsSet_1(bevd_0);
case -1980754914: return bem_oldacceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -1936537319: return bem_msynSet_1(bevd_0);
case -551679723: return bem_formCast_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -218876431: return bem_constSet_1(bevd_0);
case -2146525510: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -616954057: return bem_lastMethodsSizeSet_1(bevd_0);
case -209819725: return bem_emitLangSet_1(bevd_0);
case 104713554: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case -1438860491: return bem_instanceEqualSet_1(bevd_0);
case -1899632975: return bem_libEmitNameSet_1(bevd_0);
case -478502832: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1784573170: return bem_propertyDecsSet_1(bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 400692465: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1511645563: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -2110408325: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -193407613: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1900236779: return bem_buildClassInfoMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1379547888: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -391075985: return bem_inFilePathedSet_1(bevd_0);
case -36312873: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 660268682: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1041861873: return bem_csynSet_1(bevd_0);
case -1931824221: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -715967253: return bem_exceptDecSet_1(bevd_0);
case -1830623958: return bem_returnTypeSet_1(bevd_0);
case -1562282714: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case 1338146609: return bem_methodBodySet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case -786143205: return bem_dynMethodsSet_1(bevd_0);
case 16666050: return bem_maxDynArgsSet_1(bevd_0);
case -1774969510: return bem_methodCatchSet_1(bevd_0);
case 614561729: return bem_allOnceDecsSet_1(bevd_0);
case 2118534024: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1383317658: return bem_superCallsSet_1(bevd_0);
case -1358814541: return bem_objectNpSet_1(bevd_0);
case -1820890036: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1443016160: return bem_lastCallSet_1(bevd_0);
case 783871319: return bem_libEmitPathSet_1(bevd_0);
case -2074561119: return bem_stringNpSet_1(bevd_0);
case 1251693538: return bem_onceDecsSet_1(bevd_0);
case -65026440: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -627952553: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -508002125: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -707569329: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -724180734: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1391367893: return bem_objectCcSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 83636036: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1550716691: return bem_finalAssignTo_2((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_5_8_BuildNamePath) bevd_1);
case -1978614329: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1604046278: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -569933480: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1697242261: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 276483120: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1671519971: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 297627956: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1051833433: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -6388749: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -722876117: return bem_buildClassInfo_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 361121302: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callHash) {
case 886529145: return bem_finalAssign_3((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2);
}
return super.bemd_3(callHash, callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_5(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) throws Throwable {
switch (callHash) {
case -316092711: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2023930725: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1591575024: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return super.bemd_5(callHash, callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public byte[] bemc_clname() throws Throwable {
return becc_clname;
}
public byte[] bemc_clfile() throws Throwable {
return becc_clfile;
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildJSEmitter();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildJSEmitter.bevs_inst = (BEC_2_5_9_BuildJSEmitter)becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildJSEmitter.bevs_inst;
}
}
