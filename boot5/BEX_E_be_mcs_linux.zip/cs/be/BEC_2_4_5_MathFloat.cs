namespace be {
/* IO:File: source/base/Float.be */
public sealed class BEC_2_4_5_MathFloat : BEC_2_6_6_SystemObject {
public BEC_2_4_5_MathFloat() { }
static BEC_2_4_5_MathFloat() { }

   
    public float bevi_float;
    public BEC_2_4_5_MathFloat(float bevi_float) { this.bevi_float = bevi_float; }
    
   private static byte[] becc_BEC_2_4_5_MathFloat_clname = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] becc_BEC_2_4_5_MathFloat_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x6C,0x6F,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_0 = {0x2D};
private static byte[] bece_BEC_2_4_5_MathFloat_bels_1 = {0x2E};
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_5_MathFloat_bevo_3 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_6_TextString bece_BEC_2_4_5_MathFloat_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_4_5_MathFloat_bels_1, 1));
public static new BEC_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_inst;

public static new BET_2_4_5_MathFloat bece_BEC_2_4_5_MathFloat_bevs_type;

public BEC_2_4_5_MathFloat bem_vfloatGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_vfloatSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_new_1(BEC_2_6_6_SystemObject beva_si) {
BEC_2_5_4_LogicBool bevl_neg = null;
BEC_2_4_3_MathInt bevl_dec = null;
BEC_2_4_3_MathInt bevl_lhs = null;
BEC_2_4_3_MathInt bevl_rhs = null;
BEC_2_4_3_MathInt bevl_divby = null;
BEC_2_4_5_MathFloat bevl_rhsf = null;
BEC_2_4_5_MathFloat bevl_lhsf = null;
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_21_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_22_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_0));
bevt_0_tmpany_phold = beva_si.bemd_1(220581911, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 64 */ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_si = beva_si.bemd_1(1876986254, bevt_2_tmpany_phold);
} /* Line: 66 */
 else  /* Line: 67 */ {
bevl_neg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 68 */
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_5_MathFloat_bels_1));
bevl_dec = (BEC_2_4_3_MathInt) beva_si.bemd_1(336070467, bevt_3_tmpany_phold);
if (bevl_dec == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 71 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_0;
if (bevl_dec.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_7_tmpany_phold = beva_si.bemd_2(-641608382, bevt_8_tmpany_phold, bevl_dec);
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_7_tmpany_phold);
} /* Line: 73 */
 else  /* Line: 74 */ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 75 */
bevt_11_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_1;
bevt_10_tmpany_phold = bevl_dec.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = beva_si.bemd_0(87976308);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_lesser_1((BEC_2_4_3_MathInt) bevt_12_tmpany_phold );
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_2;
bevt_14_tmpany_phold = bevl_dec.bem_add_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = beva_si.bemd_1(1876986254, bevt_14_tmpany_phold);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_13_tmpany_phold);
} /* Line: 78 */
 else  /* Line: 79 */ {
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 80 */
} /* Line: 77 */
 else  /* Line: 82 */ {
bevl_lhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_si);
bevl_rhs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 84 */
bevt_16_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_3;
bevt_18_tmpany_phold = bevl_rhs.bem_toString_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_sizeGet_0();
bevl_divby = bevt_16_tmpany_phold.bem_power_1(bevt_17_tmpany_phold);
if (bevl_neg.bevi_bool) /* Line: 87 */ {
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_rhs.bem_multiplyValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevl_lhs.bem_multiplyValue_1(bevt_20_tmpany_phold);
} /* Line: 89 */
bevt_21_tmpany_phold = bevl_rhs.bem_toFloat_0();
bevt_22_tmpany_phold = bevl_divby.bem_toFloat_0();
bevl_rhsf = bevt_21_tmpany_phold.bem_divide_1(bevt_22_tmpany_phold);
bevl_lhsf = bevl_lhs.bem_toFloat_0();
bevl_res = bevl_lhsf.bem_add_1(bevl_rhsf);
return (BEC_2_4_5_MathFloat) bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_toInt_0() {
BEC_2_4_3_MathInt bevl_ii = null;
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return bevl_ii;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toInt_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_3_MathInt bevl_lhi = null;
BEC_2_4_5_MathFloat bevl_rh = null;
BEC_2_4_3_MathInt bevl_rhi = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
BEC_2_4_5_MathFloat bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_lhi = bem_toInt_0();
bevt_0_tmpany_phold = bevl_lhi.bem_toFloat_0();
bevl_rh = bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(1000000.0f));
bevl_rh = bevl_rh.bem_multiply_1(bevt_1_tmpany_phold);
bevl_rhi = bevl_rh.bem_toInt_0();
bevt_4_tmpany_phold = bevl_lhi.bem_toString_0();
bevt_5_tmpany_phold = bece_BEC_2_4_5_MathFloat_bevo_4;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevl_rhi.bem_toString_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_5_MathFloat bem_increment_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 144 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + 1;
            return bevl_res;
} /* Line: 156 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_decrement_0() {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 164 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - 1;
            return bevl_res;
} /* Line: 176 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_add_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 184 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float + beva_xi.bevi_float;
            return bevl_res;
} /* Line: 196 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_subtract_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 204 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float - beva_xi.bevi_float;
            return bevl_res;
} /* Line: 216 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_multiply_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 224 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float * beva_xi.bevi_float;
            return bevl_res;
} /* Line: 236 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_divide_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevl_res = null;
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
 /* Line: 244 */ {
bevl_res = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

                bevl_res.bevi_float = this.bevi_float / beva_xi.bevi_float;
            return bevl_res;
} /* Line: 256 */
} /*method end*/
public BEC_2_4_5_MathFloat bem_modulus_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_4_5_MathFloat bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat(0.0f));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float == bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_5_MathFloat;
      if (this.bevi_float != bevls_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float > beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float < beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float >= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_5_MathFloat beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_float <= beva_xi.bevi_float) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {64, 64, 65, 66, 66, 68, 70, 70, 71, 71, 72, 72, 72, 73, 73, 73, 75, 77, 77, 77, 77, 78, 78, 78, 78, 80, 83, 84, 86, 86, 86, 86, 88, 88, 89, 89, 91, 91, 91, 92, 93, 94, 97, 97, 100, 100, 104, 108, 108, 119, 127, 132, 132, 136, 137, 137, 138, 138, 139, 140, 140, 140, 140, 140, 140, 145, 156, 165, 176, 185, 196, 205, 216, 225, 236, 245, 256, 264, 264, 301, 301, 338, 338, 366, 366, 394, 394, 422, 422, 450, 450};
public static new int[] bevs_smnlec
 = new int[] {65, 66, 68, 69, 70, 73, 75, 76, 77, 82, 83, 84, 89, 90, 91, 92, 95, 97, 98, 99, 100, 102, 103, 104, 105, 108, 112, 113, 115, 116, 117, 118, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 134, 135, 139, 140, 143, 148, 149, 153, 154, 158, 159, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 189, 192, 199, 202, 209, 212, 219, 222, 229, 232, 239, 242, 247, 248, 258, 259, 269, 270, 279, 280, 289, 290, 299, 300, 309, 310};
/* BEGIN LINEINFO 
assign 1 64 65
new 0 64 65
assign 1 64 66
begins 1 64 66
assign 1 65 68
new 0 65 68
assign 1 66 69
new 0 66 69
assign 1 66 70
substring 1 66 70
assign 1 68 73
new 0 68 73
assign 1 70 75
new 0 70 75
assign 1 70 76
find 1 70 76
assign 1 71 77
def 1 71 82
assign 1 72 83
new 0 72 83
assign 1 72 84
greater 1 72 89
assign 1 73 90
new 0 73 90
assign 1 73 91
substring 2 73 91
assign 1 73 92
new 1 73 92
assign 1 75 95
new 0 75 95
assign 1 77 97
new 0 77 97
assign 1 77 98
add 1 77 98
assign 1 77 99
sizeGet 0 77 99
assign 1 77 100
lesser 1 77 100
assign 1 78 102
new 0 78 102
assign 1 78 103
add 1 78 103
assign 1 78 104
substring 1 78 104
assign 1 78 105
new 1 78 105
assign 1 80 108
new 0 80 108
assign 1 83 112
new 1 83 112
assign 1 84 113
new 0 84 113
assign 1 86 115
new 0 86 115
assign 1 86 116
toString 0 86 116
assign 1 86 117
sizeGet 0 86 117
assign 1 86 118
power 1 86 118
assign 1 88 120
new 0 88 120
multiplyValue 1 88 121
assign 1 89 122
new 0 89 122
multiplyValue 1 89 123
assign 1 91 125
toFloat 0 91 125
assign 1 91 126
toFloat 0 91 126
assign 1 91 127
divide 1 91 127
assign 1 92 128
toFloat 0 92 128
assign 1 93 129
add 1 93 129
return 1 94 130
assign 1 97 134
new 0 97 134
return 1 97 135
assign 1 100 139
toString 0 100 139
return 1 100 140
new 1 104 143
assign 1 108 148
new 0 108 148
return 1 108 149
assign 1 119 153
new 0 119 153
return 1 127 154
assign 1 132 158
toInt 0 132 158
return 1 132 159
assign 1 136 172
toInt 0 136 172
assign 1 137 173
toFloat 0 137 173
assign 1 137 174
subtract 1 137 174
assign 1 138 175
new 0 138 175
assign 1 138 176
multiply 1 138 176
assign 1 139 177
toInt 0 139 177
assign 1 140 178
toString 0 140 178
assign 1 140 179
new 0 140 179
assign 1 140 180
add 1 140 180
assign 1 140 181
toString 0 140 181
assign 1 140 182
add 1 140 182
return 1 140 183
assign 1 145 189
new 0 145 189
return 1 156 192
assign 1 165 199
new 0 165 199
return 1 176 202
assign 1 185 209
new 0 185 209
return 1 196 212
assign 1 205 219
new 0 205 219
return 1 216 222
assign 1 225 229
new 0 225 229
return 1 236 232
assign 1 245 239
new 0 245 239
return 1 256 242
assign 1 264 247
new 0 264 247
return 1 264 248
assign 1 301 258
new 0 301 258
return 1 301 259
assign 1 338 269
new 0 338 269
return 1 338 270
assign 1 366 279
new 0 366 279
return 1 366 280
assign 1 394 289
new 0 394 289
return 1 394 290
assign 1 422 299
new 0 422 299
return 1 422 300
assign 1 450 309
new 0 450 309
return 1 450 310
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1384295738: return bem_vfloatGet_0();
case -1123278056: return bem_tagGet_0();
case 1071461198: return bem_echo_0();
case 1942283510: return bem_sourceFileNameGet_0();
case -257901952: return bem_decrement_0();
case -10010145: return bem_copy_0();
case 96033137: return bem_serializeToString_0();
case -449079106: return bem_iteratorGet_0();
case -1086782351: return bem_print_0();
case -2051518290: return bem_once_0();
case -868730656: return bem_increment_0();
case 1036419091: return bem_toInt_0();
case 1194804327: return bem_fieldNamesGet_0();
case 1513233059: return bem_toString_0();
case 304245841: return bem_vfloatSet_0();
case -713163994: return bem_toAny_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case 1851908877: return bem_hashGet_0();
case 1577195459: return bem_serializationIteratorGet_0();
case -1266447496: return bem_classNameGet_0();
case -1362850090: return bem_serializeContents_0();
case 611670694: return bem_fieldIteratorGet_0();
case 144584723: return bem_create_0();
case 990360647: return bem_new_0();
case 341575045: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1986564952: return bem_greater_1((BEC_2_4_5_MathFloat) bevd_0);
case -1071001840: return bem_new_1(bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case -124318134: return bem_lesser_1((BEC_2_4_5_MathFloat) bevd_0);
case 375073126: return bem_add_1((BEC_2_4_5_MathFloat) bevd_0);
case -655019399: return bem_def_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 171178280: return bem_modulus_1((BEC_2_4_5_MathFloat) bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case 593948905: return bem_lesserEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case 1955330620: return bem_divide_1((BEC_2_4_5_MathFloat) bevd_0);
case 888018773: return bem_subtract_1((BEC_2_4_5_MathFloat) bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case 1449340032: return bem_otherClass_1(bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 546598962: return bem_multiply_1((BEC_2_4_5_MathFloat) bevd_0);
case 1320706881: return bem_greaterEquals_1((BEC_2_4_5_MathFloat) bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_MathFloat_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_4_5_MathFloat_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_MathFloat();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst = (BEC_2_4_5_MathFloat) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_5_MathFloat.bece_BEC_2_4_5_MathFloat_bevs_type;
}
}
}
