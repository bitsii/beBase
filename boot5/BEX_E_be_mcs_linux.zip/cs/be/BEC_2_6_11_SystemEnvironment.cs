namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public sealed class BEC_2_6_11_SystemEnvironment : BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemEnvironment() { }
static BEC_2_6_11_SystemEnvironment() { }
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x6E,0x76,0x69,0x72,0x6F,0x6E,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_inst;

public static new BET_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_type;

public BEC_2_4_6_TextString bem_getVariable_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevl_value = null;

            string value = Environment.GetEnvironmentVariable(beva_name.bems_toCsString());
            if (value != null) {
                bevl_value = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(value));
            }
        return bevl_value;
} /*method end*/
public BEC_2_4_6_TextString bem_getVar_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getVariable_1(beva_name);
return bevt_0_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {581, 585, 585};
public static new int[] bevs_smnlec
 = new int[] {27, 31, 32};
/* BEGIN LINEINFO 
return 1 581 27
assign 1 585 31
getVariable 1 585 31
return 1 585 32
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 501088997: return bem_sourceFileNameGet_0();
case -639297756: return bem_toAny_0();
case 281444821: return bem_fieldIteratorGet_0();
case -1486279572: return bem_serializeContents_0();
case -1275325619: return bem_toString_0();
case -2017009146: return bem_new_0();
case -744679096: return bem_fieldNamesGet_0();
case -1005119995: return bem_many_0();
case -1583672278: return bem_echo_0();
case 611702865: return bem_copy_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case -1754478112: return bem_print_0();
case -678541085: return bem_classNameGet_0();
case -1475550710: return bem_create_0();
case 119461913: return bem_tagGet_0();
case -545556484: return bem_once_0();
case -225870373: return bem_serializeToString_0();
case 2045941275: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 509474695: return bem_sameObject_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2013317963: return bem_getVar_1((BEC_2_4_6_TextString) bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case -40495613: return bem_getVariable_1((BEC_2_4_6_TextString) bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemEnvironment_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_11_SystemEnvironment_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_11_SystemEnvironment();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst = (BEC_2_6_11_SystemEnvironment) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_type;
}
}
}
