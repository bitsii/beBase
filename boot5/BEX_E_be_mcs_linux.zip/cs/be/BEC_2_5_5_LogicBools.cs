namespace be {
/* IO:File: source/base/Logic.be */
public sealed class BEC_2_5_5_LogicBools : BEC_2_6_6_SystemObject {
public BEC_2_5_5_LogicBools() { }
static BEC_2_5_5_LogicBools() { }
private static byte[] becc_BEC_2_5_5_LogicBools_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] becc_BEC_2_5_5_LogicBools_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_LogicBools_bels_2 = {0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_LogicBools_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_LogicBools_bels_2, 1));
public static new BEC_2_5_5_LogicBools bece_BEC_2_5_5_LogicBools_bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_5_5_LogicBools bem_default_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_forString_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(-170563302, bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 115 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 116 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_fromString_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 122 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_LogicBools_bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(-170563302, bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 122 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 122 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 122 */
 else  /* Line: 122 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 122 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 123 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_5_LogicBools_bevo_0;
bevt_0_tmpany_phold = beva_str.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 130 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {115, 115, 116, 116, 118, 118, 122, 122, 122, 122, 0, 0, 0, 123, 123, 125, 125, 129, 129, 130, 130, 132, 132};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 27, 28, 30, 31, 40, 45, 46, 47, 49, 52, 56, 59, 60, 62, 63, 70, 71, 73, 74, 76, 77};
/* BEGIN LINEINFO 
assign 1 115 24
new 0 115 24
assign 1 115 25
equals 1 115 25
assign 1 116 27
new 0 116 27
return 1 116 28
assign 1 118 30
new 0 118 30
return 1 118 31
assign 1 122 40
def 1 122 45
assign 1 122 46
new 0 122 46
assign 1 122 47
equals 1 122 47
assign 1 0 49
assign 1 0 52
assign 1 0 56
assign 1 123 59
new 0 123 59
return 1 123 60
assign 1 125 62
new 0 125 62
return 1 125 63
assign 1 129 70
new 0 129 70
assign 1 129 71
equals 1 129 71
assign 1 130 73
new 0 130 73
return 1 130 74
assign 1 132 76
new 0 132 76
return 1 132 77
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 460304834: return bem_fieldIteratorGet_0();
case 607966049: return bem_serializationIteratorGet_0();
case -1533121038: return bem_new_0();
case -853598946: return bem_serializeContents_0();
case -1233972717: return bem_create_0();
case -1569136637: return bem_default_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 1307328857: return bem_toAny_0();
case -827921680: return bem_copy_0();
case 1165489654: return bem_sourceFileNameGet_0();
case 466290922: return bem_iteratorGet_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -590451146: return bem_serializeToString_0();
case -1802544452: return bem_many_0();
case 247385301: return bem_toString_0();
case 210264567: return bem_print_0();
case 2043795865: return bem_echo_0();
case 212191548: return bem_tagGet_0();
case -315420442: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 172009000: return bem_otherType_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1674145558: return bem_forString_1(bevd_0);
case 2043990153: return bem_fromString_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_LogicBools_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_5_LogicBools_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_LogicBools();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst = (BEC_2_5_5_LogicBools) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_LogicBools.bece_BEC_2_5_5_LogicBools_bevs_inst;
}
}
}
