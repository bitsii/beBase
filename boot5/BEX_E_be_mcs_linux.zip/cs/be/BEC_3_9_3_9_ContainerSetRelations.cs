namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_9_ContainerSetRelations : BEC_2_6_6_SystemObject {
public BEC_3_9_3_9_ContainerSetRelations() { }
static BEC_3_9_3_9_ContainerSetRelations() { }
private static byte[] becc_BEC_3_9_3_9_ContainerSetRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_9_ContainerSetRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_9_ContainerSetRelations bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;

public static new BET_3_9_3_9_ContainerSetRelations bece_BEC_3_9_3_9_ContainerSetRelations_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_3_9_3_9_ContainerSetRelations bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_0(-1963952686);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_1(506068861, beva_l);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {68, 68, 72, 72};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 25, 26};
/* BEGIN LINEINFO 
assign 1 68 20
hashGet 0 68 20
return 1 68 21
assign 1 72 25
equals 1 72 25
return 1 72 26
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1189966673: return bem_toAny_0();
case 1045959947: return bem_deserializeClassNameGet_0();
case -212029696: return bem_many_0();
case -1554789119: return bem_iteratorGet_0();
case 1039721337: return bem_fieldIteratorGet_0();
case -177474376: return bem_serializeToString_0();
case 1556716904: return bem_default_0();
case 266181284: return bem_tagGet_0();
case -1948098255: return bem_classNameGet_0();
case 1657059163: return bem_fieldNamesGet_0();
case 2110316685: return bem_serializeContents_0();
case 1329517290: return bem_once_0();
case -174321978: return bem_serializationIteratorGet_0();
case 254210050: return bem_copy_0();
case -1519514970: return bem_print_0();
case -1641539908: return bem_toString_0();
case -1963952686: return bem_hashGet_0();
case -1886421584: return bem_new_0();
case -1841512138: return bem_sourceFileNameGet_0();
case -1063147421: return bem_create_0();
case 900120920: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1837267423: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 670434524: return bem_copyTo_1(bevd_0);
case 1733222638: return bem_defined_1(bevd_0);
case 1581368506: return bem_otherClass_1(bevd_0);
case -120618989: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -985468058: return bem_undefined_1(bevd_0);
case 1547979194: return bem_getHash_1(bevd_0);
case 506068861: return bem_equals_1(bevd_0);
case -2101355929: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1688875848: return bem_sameType_1(bevd_0);
case 17112028: return bem_sameClass_1(bevd_0);
case 789094035: return bem_def_1(bevd_0);
case 911117738: return bem_notEquals_1(bevd_0);
case 1337665439: return bem_otherType_1(bevd_0);
case -1038314311: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1751970442: return bem_undef_1(bevd_0);
case 1794882951: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 35608937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 925887327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1673554568: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 35788340: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -719350484: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1172756878: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1332721694: return bem_isEqual_2(bevd_0, bevd_1);
case 1834730412: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_3_9_ContainerSetRelations_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_9_ContainerSetRelations_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_9_ContainerSetRelations();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst = (BEC_3_9_3_9_ContainerSetRelations) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_type;
}
}
}
