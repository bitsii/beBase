namespace be {
/* IO:File: source/build/JVEmitter.be */
public sealed class BEC_2_5_9_BuildJVEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJVEmitter() { }
static BEC_2_5_9_BuildJVEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJVEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x56,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_0 = {0x6A,0x76};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_1 = {0x2E,0x6A,0x61,0x76,0x61};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_3 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20,0x62,0x65,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_4 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_5 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_6 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_7 = {0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_8 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_9 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_10 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_11 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_12 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_13 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_14 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_15 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_16 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_17 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_18 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x54,0x68,0x72,0x6F,0x77,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_19 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_20 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_21 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_22 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_23 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_24 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_25 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_26 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_27 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_28 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_29 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_30 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_31 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_32 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_33 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_34 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_35 = {0x70,0x61,0x63,0x6B,0x61,0x67,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_36 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_37 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildJVEmitter_bels_38 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x20};
public static new BEC_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;

public static new BET_2_5_9_BuildJVEmitter bece_BEC_2_5_9_BuildJVEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildJVEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_2_4_IOFile bevt_9_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_9_4_ContainerList bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_9_4_ContainerList bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
bevt_5_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 26*/ {
bevt_7_ta_ph = bevp_classConf.bem_classDirGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevt_6_ta_ph.bem_makeDirs_0();
} /* Line: 27*/
bevt_10_ta_ph = bevp_classConf.bem_typePathGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_fileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_writerGet_0();
bevl_tout = bevt_8_ta_ph.bemd_0(1947374815);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJVEmitter_bels_3));
bevl_bet.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_4));
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildJVEmitter_bels_5));
bevt_12_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
bevt_18_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevt_18_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_7));
bevt_17_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_5_9_BuildJVEmitter_bels_8));
bevl_bet.bem_addValue_1(bevt_22_ta_ph);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_23_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_23_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 37*/ {
bevt_24_ta_ph = bevt_0_ta_loop.bemd_0(-211510432);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 37*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(581391667);
if (bevl_firstmnsyn.bevi_bool)/* Line: 38*/ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 39*/
 else /* Line: 40*/ {
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_25_ta_ph);
} /* Line: 41*/
bevt_27_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_28_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_26_ta_ph = (BEC_2_4_6_TextString) bevt_27_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_26_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 43*/
 else /* Line: 37*/ {
break;
} /* Line: 37*/
} /* Line: 37*/
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJVEmitter_bels_11));
bevl_bet.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildJVEmitter_bels_12));
bevl_bet.bem_addValue_1(bevt_31_ta_ph);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_32_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_32_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 50*/ {
bevt_33_ta_ph = bevt_1_ta_loop.bemd_0(-211510432);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(581391667);
if (bevl_firstptsyn.bevi_bool)/* Line: 51*/ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 52*/
 else /* Line: 53*/ {
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_9));
bevl_bet.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 54*/
bevt_36_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_37_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_35_ta_ph = (BEC_2_4_6_TextString) bevt_36_ta_ph.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 56*/
 else /* Line: 50*/ {
break;
} /* Line: 50*/
} /* Line: 50*/
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_10));
bevl_bet.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(54, bece_BEC_2_5_9_BuildJVEmitter_bels_14));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJVEmitter_bels_15));
bevt_42_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_43_ta_ph);
bevt_44_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_41_ta_ph = (BEC_2_4_6_TextString) bevt_42_ta_ph.bem_addValue_1(bevt_44_ta_ph);
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJVEmitter_bels_16));
bevt_41_ta_ph.bem_addValue_1(bevt_45_ta_ph);
bevt_46_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_46_ta_ph);
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_13));
bevl_bet.bem_addValue_1(bevt_47_ta_ph);
bevl_tout.bemd_1(-487853278, bevl_bet);
bevl_tout.bemd_0(925559139);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_17));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildJVEmitter_bels_18));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJVEmitter_bels_19));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1337693140);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1604065800);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildJVEmitter_bels_20));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_21));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
bevt_0_ta_ph = bevl_bc.bem_begins_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 83*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_22));
beva_sdec.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 85*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_23));
beva_sdec.bem_addValue_1(bevt_4_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_24));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(beva_typeName);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_25));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 98*/
 else /* Line: 98*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 98*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 99*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
if (beva_msyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 105*/ {
bevt_2_ta_ph = beva_msyn.bem_isFinalGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 105*/
 else /* Line: 105*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 105*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJVEmitter_bels_26));
return bevt_3_ta_ph;
} /* Line: 106*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_6));
return bevt_4_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJVEmitter_bels_27));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bece_BEC_2_5_9_BuildJVEmitter_bels_28));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_exceptDec);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_29));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevl_ms = bevt_0_ta_ph.bem_add_1(bevp_nl);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJVEmitter_bels_30));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevp_libEmitName);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_31));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_4_ta_ph.bem_addValue_1(bevp_nl);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJVEmitter_bels_32));
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_ta_ph);
bevt_9_ta_ph.bem_addValue_1(bevp_nl);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildJVEmitter_bels_33));
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_outputPlatformGet_0();
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1437514936);
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJVEmitter_bels_34));
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_libNameGet_0();
bevt_0_ta_ph = bem_beginNs_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJVEmitter_bels_35));
bevt_4_ta_ph = bem_libNs_1(beva_libName);
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJVEmitter_bels_36));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getNameSpace_1(beva_libName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJVEmitter_bels_37));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJVEmitter_bels_38));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 18, 22, 26, 26, 26, 26, 26, 27, 27, 27, 29, 29, 29, 29, 30, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33, 33, 33, 35, 35, 36, 37, 37, 0, 37, 37, 39, 41, 41, 43, 43, 43, 43, 45, 45, 46, 46, 48, 48, 49, 50, 50, 0, 50, 50, 52, 54, 54, 56, 56, 56, 56, 58, 58, 60, 60, 62, 62, 63, 63, 63, 63, 63, 63, 64, 64, 65, 65, 66, 67, 71, 71, 71, 72, 73, 73, 73, 73, 73, 73, 75, 75, 75, 75, 75, 75, 75, 75, 75, 75, 81, 82, 83, 83, 84, 84, 85, 85, 87, 87, 88, 94, 94, 94, 94, 94, 94, 98, 98, 98, 0, 0, 0, 99, 99, 101, 101, 105, 105, 105, 0, 0, 0, 106, 106, 108, 108, 112, 112, 116, 116, 116, 116, 116, 117, 117, 117, 117, 117, 117, 118, 118, 118, 119, 119, 119, 119, 119, 119, 119, 119, 120, 124, 124, 124, 128, 128, 128, 128, 128, 128, 128, 132, 132, 136, 136, 140, 140, 140};
public static new int[] bevs_smnlec
 = new int[] {52, 53, 54, 55, 113, 114, 115, 116, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 149, 152, 154, 156, 159, 160, 162, 163, 164, 165, 171, 172, 173, 174, 175, 176, 177, 178, 179, 179, 182, 184, 186, 189, 190, 192, 193, 194, 195, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 268, 269, 270, 271, 273, 274, 275, 276, 278, 279, 280, 289, 290, 291, 292, 293, 294, 302, 307, 308, 310, 313, 317, 320, 321, 323, 324, 332, 337, 338, 340, 343, 347, 350, 351, 353, 354, 358, 359, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 408, 409, 410, 419, 420, 421, 422, 423, 424, 425, 429, 430, 434, 435, 440, 441, 442};
/* BEGIN LINEINFO 
assign 1 16 52
new 0 16 52
assign 1 17 53
new 0 17 53
assign 1 18 54
new 0 18 54
new 1 22 55
assign 1 26 113
classDirGet 0 26 113
assign 1 26 114
fileGet 0 26 114
assign 1 26 115
existsGet 0 26 115
assign 1 26 116
not 0 26 121
assign 1 27 122
classDirGet 0 27 122
assign 1 27 123
fileGet 0 27 123
makeDirs 0 27 124
assign 1 29 126
typePathGet 0 29 126
assign 1 29 127
fileGet 0 29 127
assign 1 29 128
writerGet 0 29 128
assign 1 29 129
open 0 29 129
assign 1 30 130
new 0 30 130
assign 1 31 131
new 0 31 131
addValue 1 31 132
assign 1 32 133
new 0 32 133
assign 1 32 134
addValue 1 32 134
assign 1 32 135
typeEmitNameGet 0 32 135
assign 1 32 136
addValue 1 32 136
assign 1 32 137
new 0 32 137
addValue 1 32 138
assign 1 33 139
new 0 33 139
assign 1 33 140
addValue 1 33 140
assign 1 33 141
typeEmitNameGet 0 33 141
assign 1 33 142
addValue 1 33 142
assign 1 33 143
new 0 33 143
addValue 1 33 144
assign 1 35 145
new 0 35 145
addValue 1 35 146
assign 1 36 147
new 0 36 147
assign 1 37 148
mtdListGet 0 37 148
assign 1 37 149
iteratorGet 0 0 149
assign 1 37 152
hasNextGet 0 37 152
assign 1 37 154
nextGet 0 37 154
assign 1 39 156
new 0 39 156
assign 1 41 159
new 0 41 159
addValue 1 41 160
assign 1 43 162
addValue 1 43 162
assign 1 43 163
nameGet 0 43 163
assign 1 43 164
addValue 1 43 164
addValue 1 43 165
assign 1 45 171
new 0 45 171
addValue 1 45 172
assign 1 46 173
new 0 46 173
addValue 1 46 174
assign 1 48 175
new 0 48 175
addValue 1 48 176
assign 1 49 177
new 0 49 177
assign 1 50 178
ptyListGet 0 50 178
assign 1 50 179
iteratorGet 0 0 179
assign 1 50 182
hasNextGet 0 50 182
assign 1 50 184
nextGet 0 50 184
assign 1 52 186
new 0 52 186
assign 1 54 189
new 0 54 189
addValue 1 54 190
assign 1 56 192
addValue 1 56 192
assign 1 56 193
nameGet 0 56 193
assign 1 56 194
addValue 1 56 194
addValue 1 56 195
assign 1 58 201
new 0 58 201
addValue 1 58 202
assign 1 60 203
new 0 60 203
addValue 1 60 204
assign 1 62 205
new 0 62 205
addValue 1 62 206
assign 1 63 207
new 0 63 207
assign 1 63 208
addValue 1 63 208
assign 1 63 209
emitNameGet 0 63 209
assign 1 63 210
addValue 1 63 210
assign 1 63 211
new 0 63 211
addValue 1 63 212
assign 1 64 213
new 0 64 213
addValue 1 64 214
assign 1 65 215
new 0 65 215
addValue 1 65 216
write 1 66 217
close 0 67 218
assign 1 71 239
new 0 71 239
assign 1 71 240
toString 0 71 240
assign 1 71 241
add 1 71 241
incrementValue 0 72 242
assign 1 73 243
new 0 73 243
assign 1 73 244
addValue 1 73 244
assign 1 73 245
addValue 1 73 245
assign 1 73 246
new 0 73 246
assign 1 73 247
addValue 1 73 247
addValue 1 73 248
assign 1 75 249
containedGet 0 75 249
assign 1 75 250
firstGet 0 75 250
assign 1 75 251
containedGet 0 75 251
assign 1 75 252
firstGet 0 75 252
assign 1 75 253
new 0 75 253
assign 1 75 254
add 1 75 254
assign 1 75 255
new 0 75 255
assign 1 75 256
add 1 75 256
assign 1 75 257
finalAssign 4 75 257
addValue 1 75 258
getInt 2 81 268
assign 1 82 269
toHexString 1 82 269
assign 1 83 270
new 0 83 270
assign 1 83 271
begins 1 83 271
assign 1 84 273
new 0 84 273
assign 1 84 274
substring 1 84 274
assign 1 85 275
new 0 85 275
addValue 1 85 276
assign 1 87 278
new 0 87 278
addValue 1 87 279
addValue 1 88 280
assign 1 94 289
new 0 94 289
assign 1 94 290
add 1 94 290
assign 1 94 291
new 0 94 291
assign 1 94 292
add 1 94 292
assign 1 94 293
add 1 94 293
return 1 94 294
assign 1 98 302
def 1 98 307
assign 1 98 308
isFinalGet 0 98 308
assign 1 0 310
assign 1 0 313
assign 1 0 317
assign 1 99 320
new 0 99 320
return 1 99 321
assign 1 101 323
new 0 101 323
return 1 101 324
assign 1 105 332
def 1 105 337
assign 1 105 338
isFinalGet 0 105 338
assign 1 0 340
assign 1 0 343
assign 1 0 347
assign 1 106 350
new 0 106 350
return 1 106 351
assign 1 108 353
new 0 108 353
return 1 108 354
assign 1 112 358
new 0 112 358
return 1 112 359
assign 1 116 381
new 0 116 381
assign 1 116 382
add 1 116 382
assign 1 116 383
new 0 116 383
assign 1 116 384
add 1 116 384
assign 1 116 385
add 1 116 385
assign 1 117 386
new 0 117 386
assign 1 117 387
addValue 1 117 387
assign 1 117 388
addValue 1 117 388
assign 1 117 389
new 0 117 389
assign 1 117 390
addValue 1 117 390
addValue 1 117 391
assign 1 118 392
new 0 118 392
assign 1 118 393
addValue 1 118 393
addValue 1 118 394
assign 1 119 395
new 0 119 395
assign 1 119 396
addValue 1 119 396
assign 1 119 397
outputPlatformGet 0 119 397
assign 1 119 398
nameGet 0 119 398
assign 1 119 399
addValue 1 119 399
assign 1 119 400
new 0 119 400
assign 1 119 401
addValue 1 119 401
addValue 1 119 402
return 1 120 403
assign 1 124 408
libNameGet 0 124 408
assign 1 124 409
beginNs 1 124 409
return 1 124 410
assign 1 128 419
new 0 128 419
assign 1 128 420
libNs 1 128 420
assign 1 128 421
add 1 128 421
assign 1 128 422
new 0 128 422
assign 1 128 423
add 1 128 423
assign 1 128 424
add 1 128 424
return 1 128 425
assign 1 132 429
getNameSpace 1 132 429
return 1 132 430
assign 1 136 434
new 0 136 434
return 1 136 435
assign 1 140 440
new 0 140 440
assign 1 140 441
add 1 140 441
return 1 140 442
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1118345455: return bem_saveSyns_0();
case 954314799: return bem_nullValueGetDirect_0();
case -1076915155: return bem_serializeToString_0();
case -2001553127: return bem_idToNameGet_0();
case 1735438754: return bem_fullLibEmitNameGetDirect_0();
case -975498393: return bem_fieldNamesGet_0();
case -1464033941: return bem_buildInitial_0();
case 407841732: return bem_classConfGet_0();
case -474205928: return bem_doEmit_0();
case -738904241: return bem_typeDecGet_0();
case 353817315: return bem_getClassOutput_0();
case -1964388126: return bem_mnodeGet_0();
case 420057427: return bem_maxSpillArgsLenGet_0();
case 1910033340: return bem_buildGet_0();
case 1041429925: return bem_lastMethodBodyLinesGetDirect_0();
case 745544124: return bem_nullValueGet_0();
case -1524361715: return bem_nlGet_0();
case -523845738: return bem_parentConfGet_0();
case -1779747842: return bem_gcMarksGet_0();
case -598146418: return bem_mainStartGet_0();
case -1548070336: return bem_saveIds_0();
case -63350780: return bem_idToNameGetDirect_0();
case 405026: return bem_mainEndGet_0();
case 905339083: return bem_objectNpGetDirect_0();
case 1251618469: return bem_qGetDirect_0();
case 1766258890: return bem_lineCountGet_0();
case 246213752: return bem_spropDecGet_0();
case -1621956962: return bem_writeBET_0();
case 559261394: return bem_objectCcGetDirect_0();
case 549314837: return bem_csynGetDirect_0();
case -458218411: return bem_constGet_0();
case -663803487: return bem_boolNpGetDirect_0();
case 650896089: return bem_idToNamePathGetDirect_0();
case 1932405186: return bem_lineCountGetDirect_0();
case -413684602: return bem_endNs_0();
case 1722798404: return bem_boolCcGetDirect_0();
case -105291527: return bem_inFilePathedGet_0();
case 628791263: return bem_classCallsGetDirect_0();
case 830242903: return bem_synEmitPathGet_0();
case 676335640: return bem_msynGet_0();
case -70491779: return bem_invpGet_0();
case 1167340379: return bem_qGet_0();
case 1153344161: return bem_serializeContents_0();
case 862702287: return bem_smnlecsGetDirect_0();
case 515194553: return bem_falseValueGet_0();
case -1679319319: return bem_methodsGetDirect_0();
case -879730765: return bem_methodBodyGetDirect_0();
case 433613536: return bem_onceDecsGet_0();
case -33953410: return bem_methodCallsGet_0();
case -1996770286: return bem_objectNpGet_0();
case -574574637: return bem_transGet_0();
case -319269182: return bem_methodCatchGetDirect_0();
case 876676878: return bem_ntypesGetDirect_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -606522170: return bem_transGetDirect_0();
case -1445403786: return bem_preClassGet_0();
case -892100048: return bem_libEmitNameGet_0();
case 191341193: return bem_instanceNotEqualGetDirect_0();
case 3896650: return bem_baseMtdDecGet_0();
case -342200774: return bem_dynMethodsGetDirect_0();
case 729434303: return bem_boolTypeGet_0();
case -1873895492: return bem_smnlcsGet_0();
case -1792801458: return bem_preClassGetDirect_0();
case -2142700859: return bem_classesInDepthOrderGet_0();
case -1100810412: return bem_exceptDecGetDirect_0();
case 52083157: return bem_ccCacheGet_0();
case -2021770962: return bem_gcMarksGetDirect_0();
case -553645547: return bem_cnodeGetDirect_0();
case -2096768021: return bem_inFilePathedGetDirect_0();
case -791503811: return bem_useDynMethodsGet_0();
case 421177749: return bem_print_0();
case 2005590948: return bem_returnTypeGetDirect_0();
case 1398396164: return bem_ccMethodsGet_0();
case -2077315399: return bem_floatNpGetDirect_0();
case -1688873660: return bem_classEmitsGetDirect_0();
case -2028680714: return bem_classesInDepthOrderGetDirect_0();
case 333220584: return bem_buildClassInfo_0();
case 1232394224: return bem_buildGetDirect_0();
case -104032419: return bem_classEndGet_0();
case -645154618: return bem_superCallsGetDirect_0();
case -40905183: return bem_echo_0();
case -672373119: return bem_ccMethodsGetDirect_0();
case 40398009: return bem_onceDecsGetDirect_0();
case -46001784: return bem_belslitsGetDirect_0();
case 88195190: return bem_constGetDirect_0();
case 658635932: return bem_propertyDecsGet_0();
case 954703233: return bem_create_0();
case 1652226712: return bem_classCallsGet_0();
case 919140360: return bem_buildCreate_0();
case 545775887: return bem_invpGetDirect_0();
case -804333793: return bem_libEmitPathGet_0();
case -416299989: return bem_maxDynArgsGet_0();
case -905099191: return bem_objectCcGet_0();
case 1974505938: return bem_hashGet_0();
case -1655029407: return bem_scvpGetDirect_0();
case -193582610: return bem_tagGet_0();
case -1713075607: return bem_lastMethodBodyLinesGet_0();
case -688377997: return bem_lastMethodsLinesGetDirect_0();
case 366809185: return bem_emitLib_0();
case 92749048: return bem_mainInClassGet_0();
case -157011648: return bem_propDecGet_0();
case 2141331584: return bem_baseSmtdDecGet_0();
case 764322765: return bem_nameToIdPathGet_0();
case -1804759939: return bem_stringNpGet_0();
case 1505739548: return bem_overrideMtdDecGet_0();
case 1562357256: return bem_ccCacheGetDirect_0();
case 12683368: return bem_callNamesGetDirect_0();
case -1653939165: return bem_iteratorGet_0();
case 1623528709: return bem_nameToIdPathGetDirect_0();
case 276430934: return bem_parentConfGetDirect_0();
case -172065706: return bem_lastMethodsSizeGet_0();
case -181421339: return bem_methodBodyGet_0();
case 1159364071: return bem_getLibOutput_0();
case -1562275097: return bem_maxDynArgsGetDirect_0();
case 1146003758: return bem_nameToIdGetDirect_0();
case 1725398431: return bem_lastCallGet_0();
case -146424608: return bem_nlGetDirect_0();
case 2081363871: return bem_copy_0();
case -1894735143: return bem_methodCatchGet_0();
case -363760108: return bem_callNamesGet_0();
case 2144581091: return bem_covariantReturnsGet_0();
case 1013430591: return bem_initialDecGet_0();
case -1823894784: return bem_idToNamePathGet_0();
case -2058100448: return bem_superNameGet_0();
case 1077027817: return bem_inClassGet_0();
case -1549701273: return bem_randGetDirect_0();
case -1652977713: return bem_libEmitNameGetDirect_0();
case 1646886937: return bem_newDecGet_0();
case 820532752: return bem_lastMethodBodySizeGetDirect_0();
case -1421380846: return bem_smnlecsGet_0();
case -37950896: return bem_msynGetDirect_0();
case -893093197: return bem_toString_0();
case 1312947361: return bem_instanceEqualGet_0();
case 1834246217: return bem_classNameGet_0();
case -722250565: return bem_superCallsGet_0();
case -2118708930: return bem_new_0();
case 41316592: return bem_emitLangGetDirect_0();
case 1178551689: return bem_scvpGet_0();
case 1775829382: return bem_csynGet_0();
case 1191254416: return bem_boolNpGet_0();
case -771530553: return bem_lastCallGetDirect_0();
case -1567768992: return bem_lastMethodBodySizeGet_0();
case 58217918: return bem_ntypesGet_0();
case -21958676: return bem_mainOutsideNsGet_0();
case 1555300551: return bem_lastMethodsSizeGetDirect_0();
case -711947409: return bem_inClassGetDirect_0();
case 840447762: return bem_nativeCSlotsGetDirect_0();
case 1784218862: return bem_nameToIdGet_0();
case -621234092: return bem_preClassOutput_0();
case -2119717232: return bem_boolCcGet_0();
case 428897684: return bem_belslitsGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -144031735: return bem_instanceNotEqualGet_0();
case -1694631580: return bem_afterCast_0();
case -807565050: return bem_intNpGet_0();
case 940166253: return bem_exceptDecGet_0();
case -1375209352: return bem_floatNpGet_0();
case -803900055: return bem_nativeCSlotsGet_0();
case -892057345: return bem_falseValueGetDirect_0();
case -1653115994: return bem_smnlcsGetDirect_0();
case -1342456909: return bem_methodsGet_0();
case -129874257: return bem_libEmitPathGetDirect_0();
case -5538352: return bem_instOfGet_0();
case -123284073: return bem_maxSpillArgsLenGetDirect_0();
case 1421395075: return bem_propertyDecsGetDirect_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 2126077980: return bem_classEmitsGet_0();
case -1088750573: return bem_randGet_0();
case 1315468009: return bem_runtimeInitGet_0();
case -101712799: return bem_stringNpGetDirect_0();
case -1570225969: return bem_loadIds_0();
case -1991230999: return bem_fileExtGetDirect_0();
case -1209303662: return bem_lastMethodsLinesGet_0();
case 1078624159: return bem_dynMethodsGet_0();
case -1478769760: return bem_mnodeGetDirect_0();
case 1907822907: return bem_intNpGetDirect_0();
case -1893707267: return bem_returnTypeGet_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 1234308938: return bem_instanceEqualGetDirect_0();
case -757888283: return bem_cnodeGet_0();
case 674373139: return bem_beginNs_0();
case 2089082126: return bem_synEmitPathGetDirect_0();
case -1410975628: return bem_classConfGetDirect_0();
case 698844861: return bem_instOfGetDirect_0();
case -306508569: return bem_trueValueGetDirect_0();
case 1422094797: return bem_emitLangGet_0();
case 1456027580: return bem_fullLibEmitNameGet_0();
case -2059454988: return bem_fileExtGet_0();
case -235947406: return bem_methodCallsGetDirect_0();
case 1155346090: return bem_trueValueGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1819679892: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 1068068139: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1218998069: return bem_gcMarksSetDirect_1(bevd_0);
case 726536459: return bem_nameToIdSet_1(bevd_0);
case 1253100045: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 1322219409: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 2117195598: return bem_nameToIdPathSet_1(bevd_0);
case 1980486728: return bem_superCallsSet_1(bevd_0);
case -716091806: return bem_ccCacheSet_1(bevd_0);
case -1010476522: return bem_synEmitPathSetDirect_1(bevd_0);
case -728013547: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -459818197: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 2062523911: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 602385542: return bem_classCallsSetDirect_1(bevd_0);
case -127998909: return bem_methodCallsSet_1(bevd_0);
case -217027086: return bem_falseValueSetDirect_1(bevd_0);
case -1748711333: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1788659387: return bem_invpSetDirect_1(bevd_0);
case -182217682: return bem_ccMethodsSet_1(bevd_0);
case 952345047: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1312352005: return bem_preClassSetDirect_1(bevd_0);
case 1137321087: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 519724799: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 670046554: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1871574706: return bem_methodCatchSet_1(bevd_0);
case -187868289: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 33677120: return bem_floatNpSet_1(bevd_0);
case 273560766: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -374172463: return bem_boolNpSetDirect_1(bevd_0);
case -543137024: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1173548718: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 510192491: return bem_lastMethodsLinesSet_1(bevd_0);
case -179493390: return bem_instanceNotEqualSet_1(bevd_0);
case 1528488519: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 215907131: return bem_transSet_1(bevd_0);
case 452762255: return bem_propertyDecsSet_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 799271212: return bem_methodCatchSetDirect_1(bevd_0);
case 1642585945: return bem_classConfSetDirect_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 28808816: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -1349439414: return bem_maxDynArgsSetDirect_1(bevd_0);
case -996640729: return bem_buildSet_1(bevd_0);
case -1321490696: return bem_randSetDirect_1(bevd_0);
case -444306731: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 636236596: return bem_methodBodySet_1(bevd_0);
case -685493641: return bem_inFilePathedSetDirect_1(bevd_0);
case -718705053: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 158805950: return bem_dynMethodsSetDirect_1(bevd_0);
case -809055130: return bem_methodsSetDirect_1(bevd_0);
case -238702035: return bem_trueValueSet_1(bevd_0);
case -1226141798: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -856140099: return bem_mnodeSet_1(bevd_0);
case 71537269: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1422543141: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 646309079: return bem_exceptDecSet_1(bevd_0);
case 1206527808: return bem_msynSetDirect_1(bevd_0);
case 1273177145: return bem_inFilePathedSet_1(bevd_0);
case -1635216579: return bem_nullValueSetDirect_1(bevd_0);
case -1162626625: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 2081592502: return bem_lastCallSetDirect_1(bevd_0);
case -574369222: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 631777839: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1298066413: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -229836953: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -1794363404: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1167427082: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -117238473: return bem_lineCountSet_1(bevd_0);
case -1992412421: return bem_emitLangSetDirect_1(bevd_0);
case 307222774: return bem_emitLangSet_1(bevd_0);
case 1013431444: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -745596008: return bem_idToNameSet_1(bevd_0);
case -1132676648: return bem_lstringEndCi_1((BEC_2_4_6_TextString) bevd_0);
case 1002871962: return bem_inClassSetDirect_1(bevd_0);
case 736740069: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1257125596: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -2042501127: return bem_ntypesSetDirect_1(bevd_0);
case 969890227: return bem_idToNameSetDirect_1(bevd_0);
case 59504167: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -860180577: return bem_idToNamePathSetDirect_1(bevd_0);
case -454010292: return bem_scvpSet_1(bevd_0);
case -578117914: return bem_intNpSet_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -2056626135: return bem_lineCountSetDirect_1(bevd_0);
case -2125922332: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1479492989: return bem_cnodeSet_1(bevd_0);
case -690940028: return bem_invpSet_1(bevd_0);
case 1639728825: return bem_fullLibEmitNameSet_1(bevd_0);
case 1761502964: return bem_libEmitPathSetDirect_1(bevd_0);
case 1736101817: return bem_transSetDirect_1(bevd_0);
case -1261538307: return bem_instOfSet_1(bevd_0);
case 1756395446: return bem_ccMethodsSetDirect_1(bevd_0);
case -2042883029: return bem_lastMethodBodySizeSet_1(bevd_0);
case -96852122: return bem_callNamesSet_1(bevd_0);
case 964469559: return bem_floatNpSetDirect_1(bevd_0);
case -2008446011: return bem_returnTypeSetDirect_1(bevd_0);
case -1834752485: return bem_libEmitPathSet_1(bevd_0);
case -682596181: return bem_nullValueSet_1(bevd_0);
case 973840681: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1669834284: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1116138076: return bem_objectCcSetDirect_1(bevd_0);
case -113459514: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 436854185: return bem_gcMarksSet_1(bevd_0);
case -866123245: return bem_smnlcsSet_1(bevd_0);
case 1778383552: return bem_propertyDecsSetDirect_1(bevd_0);
case -238302596: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1837216461: return bem_superCallsSetDirect_1(bevd_0);
case -1832996390: return bem_instOfSetDirect_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -191261161: return bem_preClassSet_1(bevd_0);
case -685696286: return bem_maxDynArgsSet_1(bevd_0);
case 1843382149: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1733700445: return bem_scvpSetDirect_1(bevd_0);
case 1832648923: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1677402774: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 257733747: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1865062933: return bem_buildSetDirect_1(bevd_0);
case 716937430: return bem_randSet_1(bevd_0);
case 1391467578: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 922684956: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1819306118: return bem_constSetDirect_1(bevd_0);
case 2011490434: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1409368810: return bem_onceDecsSetDirect_1(bevd_0);
case 720335249: return bem_mnodeSetDirect_1(bevd_0);
case 1610508395: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 537872706: return bem_stringNpSet_1(bevd_0);
case -669415086: return bem_constSet_1(bevd_0);
case -419030920: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -1703995683: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1445556124: return bem_classCallsSet_1(bevd_0);
case -2020479967: return bem_methodsSet_1(bevd_0);
case -1524400271: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1107102660: return bem_trueValueSetDirect_1(bevd_0);
case -1347585187: return bem_objectNpSet_1(bevd_0);
case -209212406: return bem_cnodeSetDirect_1(bevd_0);
case 367372318: return bem_fileExtSetDirect_1(bevd_0);
case -1133791598: return bem_smnlecsSetDirect_1(bevd_0);
case -2025115952: return bem_smnlecsSet_1(bevd_0);
case -1586326941: return bem_returnTypeSet_1(bevd_0);
case 1683360859: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 2022500193: return bem_classConfSet_1(bevd_0);
case -440603221: return bem_fileExtSet_1(bevd_0);
case -2053477462: return bem_objectCcSet_1(bevd_0);
case -2045639292: return bem_objectNpSetDirect_1(bevd_0);
case 386424866: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -398951732: return bem_nativeCSlotsSet_1(bevd_0);
case -1564379620: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1125537884: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1120222459: return bem_instanceEqualSet_1(bevd_0);
case 152905666: return bem_idToNamePathSet_1(bevd_0);
case -813345128: return bem_lastCallSet_1(bevd_0);
case 863734754: return bem_libEmitNameSetDirect_1(bevd_0);
case -631003549: return bem_begin_1(bevd_0);
case -1571802125: return bem_classesInDepthOrderSet_1(bevd_0);
case 445807228: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1000390917: return bem_inClassSet_1(bevd_0);
case -1100782292: return bem_methodCallsSetDirect_1(bevd_0);
case -104502086: return bem_boolCcSetDirect_1(bevd_0);
case 906394861: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -2017628816: return bem_nameToIdSetDirect_1(bevd_0);
case 1090483485: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1149784928: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1708889682: return bem_methodBodySetDirect_1(bevd_0);
case -37536344: return bem_smnlcsSetDirect_1(bevd_0);
case 999106407: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 312819044: return bem_parentConfSet_1(bevd_0);
case 1327698647: return bem_synEmitPathSet_1(bevd_0);
case -306392746: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 243494982: return bem_csynSet_1(bevd_0);
case -1756790859: return bem_intNpSetDirect_1(bevd_0);
case 1211900971: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1627032752: return bem_classEmitsSetDirect_1(bevd_0);
case -1725891234: return bem_qSet_1(bevd_0);
case -1739950932: return bem_nlSet_1(bevd_0);
case -1587286451: return bem_belslitsSet_1(bevd_0);
case -775811621: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1537135787: return bem_ntypesSet_1(bevd_0);
case 42284156: return bem_instanceEqualSetDirect_1(bevd_0);
case -1671387085: return bem_onceDecsSet_1(bevd_0);
case -1879294297: return bem_libEmitNameSet_1(bevd_0);
case 537433000: return bem_end_1(bevd_0);
case 1579048056: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -329801993: return bem_dynMethodsSet_1(bevd_0);
case -1847864067: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 505906565: return bem_falseValueSet_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -379549317: return bem_msynSet_1(bevd_0);
case -913525996: return bem_parentConfSetDirect_1(bevd_0);
case -144121633: return bem_exceptDecSetDirect_1(bevd_0);
case -505568387: return bem_lastMethodsSizeSet_1(bevd_0);
case 78334940: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -721158637: return bem_nameToIdPathSetDirect_1(bevd_0);
case 25031630: return bem_nlSetDirect_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1287263776: return bem_qSetDirect_1(bevd_0);
case -801203699: return bem_boolCcSet_1(bevd_0);
case 1567346822: return bem_classEmitsSet_1(bevd_0);
case -502133510: return bem_csynSetDirect_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -715123460: return bem_belslitsSetDirect_1(bevd_0);
case 2014200617: return bem_boolNpSet_1(bevd_0);
case -71188929: return bem_ccCacheSetDirect_1(bevd_0);
case 1024933216: return bem_callNamesSetDirect_1(bevd_0);
case 1906312444: return bem_stringNpSetDirect_1(bevd_0);
case 204683157: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -497711860: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1944532162: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 305989740: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 2084834466: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -536099638: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1534350547: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1918038998: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1977544901: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1938618938: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -770607322: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1852067127: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 247464101: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 923323362: return bem_lstringStartCi_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -515130299: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1061487176: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1906669825: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 560995311: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 502107989: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1787865276: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1309157622: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -1986912141: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -642281942: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1610372895: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJVEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJVEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJVEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst = (BEC_2_5_9_BuildJVEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJVEmitter.bece_BEC_2_5_9_BuildJVEmitter_bevs_type;
}
}
}
