namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemPlatform : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemPlatform() { }
static BEC_2_6_8_SystemPlatform() { }
private static byte[] becc_BEC_2_6_8_SystemPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_8_SystemPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_0 = {0x6D,0x61,0x63,0x6F,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_0, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_1 = {0x6C,0x69,0x6E,0x75,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_1, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_2 = {0x66,0x72,0x65,0x65,0x62,0x73,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_2, 7));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_3 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_4 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_5 = {0x2F,0x64,0x65,0x76,0x2F,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_6 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_6, 5));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_7 = {0x5C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_8 = {0x2F};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_9 = {0x6E,0x75,0x6C};
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_10 = {0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_10, 9));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_11 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x2C,0x20,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x20,0x6D,0x75,0x73,0x74,0x20,0x62,0x65,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x69,0x6E,0x20,0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_11, 60));
private static byte[] bece_BEC_2_6_8_SystemPlatform_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_8_SystemPlatform_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_6_8_SystemPlatform_bels_12, 5));
public static new BEC_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_inst;

public static new BET_2_6_8_SystemPlatform bece_BEC_2_6_8_SystemPlatform_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_4_LogicBool bevp_isNix;
public BEC_2_5_4_LogicBool bevp_isWin;
public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_otherSeparator;
public BEC_2_4_6_TextString bevp_nullFile;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_new_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_0;
bevt_2_tmpany_phold = bevp_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 621 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 621 */ {
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_1;
bevt_4_tmpany_phold = bevp_name.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 621 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 621 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 621 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 621 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 621 */ {
bevt_7_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_2;
bevt_6_tmpany_phold = bevp_name.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 621 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 621 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 621 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 621 */ {
bevp_isNix = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_isWin = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_3));
bevp_otherSeparator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_4));
bevp_nullFile = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_6_8_SystemPlatform_bels_5));
} /* Line: 626 */
 else  /* Line: 621 */ {
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_3;
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 627 */ {
bevp_isNix = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isWin = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_separator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_7));
bevp_otherSeparator = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemPlatform_bels_8));
bevp_nullFile = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_8_SystemPlatform_bels_9));
} /* Line: 632 */
 else  /* Line: 633 */ {
bevt_13_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_name);
bevt_14_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_5;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 634 */
} /* Line: 621 */
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_16_tmpany_phold = bece_BEC_2_6_8_SystemPlatform_bevo_6;
bevt_15_tmpany_phold = bevp_name.bem_equals_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 637 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(654813963);
} /* Line: 639 */
 else  /* Line: 640 */ {
bevp_newline = (BEC_2_4_6_TextString) bevl_strings.bemd_0(654813963);
} /* Line: 641 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isNixGet_0() {
return bevp_isNix;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNixGetDirect_0() {
return bevp_isNix;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_isNixSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isNixSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isNix = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isWinGet_0() {
return bevp_isWin;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isWinGetDirect_0() {
return bevp_isWin;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_isWinSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_isWinSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_isWin = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_separatorGet_0() {
return bevp_separator;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGetDirect_0() {
return bevp_separator;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_otherSeparatorGet_0() {
return bevp_otherSeparator;
} /*method end*/
public BEC_2_4_6_TextString bem_otherSeparatorGetDirect_0() {
return bevp_otherSeparator;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_otherSeparatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_otherSeparatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_otherSeparator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nullFileGet_0() {
return bevp_nullFile;
} /*method end*/
public BEC_2_4_6_TextString bem_nullFileGetDirect_0() {
return bevp_nullFile;
} /*method end*/
public virtual BEC_2_6_8_SystemPlatform bem_nullFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_8_SystemPlatform bem_nullFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nullFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {615, 616, 621, 621, 0, 621, 621, 0, 0, 0, 621, 621, 0, 0, 622, 623, 624, 625, 626, 627, 627, 628, 629, 630, 631, 632, 634, 634, 634, 634, 634, 634, 636, 637, 637, 639, 641, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {48, 49, 71, 72, 74, 77, 78, 80, 83, 87, 90, 91, 93, 96, 100, 101, 102, 103, 104, 107, 108, 110, 111, 112, 113, 114, 117, 118, 119, 120, 121, 122, 125, 126, 127, 129, 132, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203, 207, 210, 213, 217, 221, 224, 227, 231};
/* BEGIN LINEINFO 
assign 1 615 48
buildProfile 0 616 49
assign 1 621 71
new 0 621 71
assign 1 621 72
equals 1 621 72
assign 1 0 74
assign 1 621 77
new 0 621 77
assign 1 621 78
equals 1 621 78
assign 1 0 80
assign 1 0 83
assign 1 0 87
assign 1 621 90
new 0 621 90
assign 1 621 91
equals 1 621 91
assign 1 0 93
assign 1 0 96
assign 1 622 100
new 0 622 100
assign 1 623 101
new 0 623 101
assign 1 624 102
new 0 624 102
assign 1 625 103
new 0 625 103
assign 1 626 104
new 0 626 104
assign 1 627 107
new 0 627 107
assign 1 627 108
equals 1 627 108
assign 1 628 110
new 0 628 110
assign 1 629 111
new 0 629 111
assign 1 630 112
new 0 630 112
assign 1 631 113
new 0 631 113
assign 1 632 114
new 0 632 114
assign 1 634 117
new 0 634 117
assign 1 634 118
add 1 634 118
assign 1 634 119
new 0 634 119
assign 1 634 120
add 1 634 120
assign 1 634 121
new 1 634 121
throw 1 634 122
assign 1 636 125
new 0 636 125
assign 1 637 126
new 0 637 126
assign 1 637 127
equals 1 637 127
assign 1 639 129
unixNewlineGet 0 639 129
assign 1 641 132
unixNewlineGet 0 641 132
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1043543071: return bem_create_0();
case -1200514874: return bem_once_0();
case -1048585343: return bem_copy_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -2011984947: return bem_classNameGet_0();
case -1021558772: return bem_fieldIteratorGet_0();
case 795649196: return bem_serializationIteratorGet_0();
case -1800587860: return bem_serializeToString_0();
case -1671167021: return bem_newlineGet_0();
case 856014071: return bem_isWinGet_0();
case 190764838: return bem_toString_0();
case 976768273: return bem_fieldNamesGet_0();
case 451316734: return bem_new_0();
case 2022567405: return bem_tagGet_0();
case 1450812749: return bem_nameGetDirect_0();
case -1916695436: return bem_otherSeparatorGetDirect_0();
case 1391650653: return bem_isWinGetDirect_0();
case -74565376: return bem_isNixGet_0();
case -1017732045: return bem_toAny_0();
case -204986197: return bem_print_0();
case 1161636512: return bem_nullFileGetDirect_0();
case -193453355: return bem_iteratorGet_0();
case 1809869265: return bem_many_0();
case 1022223687: return bem_isNixGetDirect_0();
case -179379300: return bem_nullFileGet_0();
case -1852647932: return bem_serializeContents_0();
case 178622326: return bem_separatorGet_0();
case -1139382788: return bem_otherSeparatorGet_0();
case -1816569440: return bem_newlineGetDirect_0();
case -246521336: return bem_buildProfile_0();
case 1096094931: return bem_nameGet_0();
case -477940854: return bem_hashGet_0();
case 1463816718: return bem_sourceFileNameGet_0();
case -1615839398: return bem_echo_0();
case 785994077: return bem_separatorGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 467257123: return bem_nullFileSet_1(bevd_0);
case -974417776: return bem_undef_1(bevd_0);
case -624545505: return bem_separatorSet_1(bevd_0);
case -227533897: return bem_isWinSet_1(bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case 1255352870: return bem_notEquals_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 786665509: return bem_newlineSetDirect_1(bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 228258099: return bem_nameSet_1(bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1314421310: return bem_isWinSetDirect_1(bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case 1295553255: return bem_nullFileSetDirect_1(bevd_0);
case 380641409: return bem_otherSeparatorSetDirect_1(bevd_0);
case 1001059519: return bem_otherSeparatorSet_1(bevd_0);
case 1487535860: return bem_isNixSetDirect_1(bevd_0);
case 1317898590: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -252330168: return bem_def_1(bevd_0);
case 615692338: return bem_isNixSet_1(bevd_0);
case -297237715: return bem_separatorSetDirect_1(bevd_0);
case -2086680116: return bem_newlineSet_1(bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case 2004115403: return bem_nameSetDirect_1(bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst = (BEC_2_6_8_SystemPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_8_SystemPlatform.bece_BEC_2_6_8_SystemPlatform_bevs_type;
}
}
}
