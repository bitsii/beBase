namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_17_TextMultiByteIterator : BEC_2_4_12_TextByteIterator {
public BEC_2_4_17_TextMultiByteIterator() { }
static BEC_2_4_17_TextMultiByteIterator() { }
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x4D,0x75,0x6C,0x74,0x69,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_17_TextMultiByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(127));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(-64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(-32));
private static BEC_2_4_3_MathInt bece_BEC_2_4_17_TextMultiByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(-16));
private static byte[] bece_BEC_2_4_17_TextMultiByteIterator_bels_0 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x2C,0x20,0x75,0x74,0x66,0x2D,0x38,0x20,0x6D,0x75,0x6C,0x74,0x69,0x62,0x79,0x74,0x65,0x20,0x73,0x65,0x71,0x75,0x65,0x6E,0x63,0x65,0x20,0x69,0x73,0x20,0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x20,0x74,0x68,0x61,0x6E,0x20,0x34,0x20,0x62,0x79,0x74,0x65,0x73};
public static new BEC_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;

public static new BET_2_4_17_TextMultiByteIterator bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_bcount;
public BEC_2_4_3_MathInt bevp_ival;
public override BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) {
bevp_bcount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_ival = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
base.bem_new_1(beva__str);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_2_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1345 */ {
bevp_str.bem_getInt_2(bevp_pos, bevp_ival);
bevt_4_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_0;
if (bevp_ival.bevi_int >= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1347 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_1;
if (bevp_ival.bevi_int <= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 1347 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1347 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1347 */
 else  /* Line: 1347 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1347 */ {
bevp_bcount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 1348 */
 else  /* Line: 1347 */ {
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-32));
bevt_8_tmpany_phold = bevp_ival.bem_and_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_2;
if (bevt_8_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 1349 */ {
bevp_bcount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 1350 */
 else  /* Line: 1347 */ {
bevt_13_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-16));
bevt_12_tmpany_phold = bevp_ival.bem_and_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_3;
if (bevt_12_tmpany_phold.bevi_int == bevt_14_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 1351 */ {
bevp_bcount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
} /* Line: 1352 */
 else  /* Line: 1347 */ {
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-8));
bevt_16_tmpany_phold = bevp_ival.bem_and_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_4_17_TextMultiByteIterator_bevo_4;
if (bevt_16_tmpany_phold.bevi_int == bevt_18_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 1353 */ {
bevp_bcount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 1354 */
 else  /* Line: 1355 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(66, bece_BEC_2_4_17_TextMultiByteIterator_bels_0));
bevt_19_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_20_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 1356 */
} /* Line: 1347 */
} /* Line: 1347 */
} /* Line: 1347 */
bevt_22_tmpany_phold = beva_buf.bem_sizeGet_0();
if (bevt_22_tmpany_phold.bevi_int != bevp_bcount.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 1358 */ {
bevt_23_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_23_tmpany_phold.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1359 */
bevp_bcount.bevi_int += bevp_pos.bevi_int;
bevt_24_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_buf.bem_copyValue_4(bevp_str, bevp_pos, bevp_bcount, bevt_24_tmpany_phold);
bevp_pos.bevi_int = bevp_bcount.bevi_int;
} /* Line: 1363 */
return beva_buf;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorIteratorGet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_bcountGet_0() {
return bevp_bcount;
} /*method end*/
public BEC_2_4_3_MathInt bem_bcountGetDirect_0() {
return bevp_bcount;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_bcountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_bcountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bcount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ivalGet_0() {
return bevp_ival;
} /*method end*/
public BEC_2_4_3_MathInt bem_ivalGetDirect_0() {
return bevp_ival;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_ivalSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_ivalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ival = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1334, 1335, 1337, 1341, 1341, 1341, 1341, 1345, 1345, 1345, 1346, 1347, 1347, 1347, 1347, 1347, 1347, 0, 0, 0, 1348, 1349, 1349, 1349, 1349, 1349, 1350, 1351, 1351, 1351, 1351, 1351, 1352, 1353, 1353, 1353, 1353, 1353, 1354, 1356, 1356, 1356, 1358, 1358, 1358, 1359, 1359, 1361, 1362, 1362, 1363, 1365, 1369, 1373, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 33, 34, 35, 36, 64, 65, 70, 71, 72, 73, 78, 79, 80, 85, 86, 89, 93, 96, 99, 100, 101, 102, 107, 108, 111, 112, 113, 114, 119, 120, 123, 124, 125, 126, 131, 132, 135, 136, 137, 142, 143, 148, 149, 150, 152, 153, 154, 155, 157, 160, 163, 166, 169, 172, 176, 180, 183, 186, 190};
/* BEGIN LINEINFO 
assign 1 1334 24
new 0 1334 24
assign 1 1335 25
new 0 1335 25
new 1 1337 26
assign 1 1341 33
new 0 1341 33
assign 1 1341 34
new 1 1341 34
assign 1 1341 35
next 1 1341 35
return 1 1341 36
assign 1 1345 64
sizeGet 0 1345 64
assign 1 1345 65
greater 1 1345 70
getInt 2 1346 71
assign 1 1347 72
new 0 1347 72
assign 1 1347 73
greaterEquals 1 1347 78
assign 1 1347 79
new 0 1347 79
assign 1 1347 80
lesserEquals 1 1347 85
assign 1 0 86
assign 1 0 89
assign 1 0 93
assign 1 1348 96
new 0 1348 96
assign 1 1349 99
new 0 1349 99
assign 1 1349 100
and 1 1349 100
assign 1 1349 101
new 0 1349 101
assign 1 1349 102
equals 1 1349 107
assign 1 1350 108
new 0 1350 108
assign 1 1351 111
new 0 1351 111
assign 1 1351 112
and 1 1351 112
assign 1 1351 113
new 0 1351 113
assign 1 1351 114
equals 1 1351 119
assign 1 1352 120
new 0 1352 120
assign 1 1353 123
new 0 1353 123
assign 1 1353 124
and 1 1353 124
assign 1 1353 125
new 0 1353 125
assign 1 1353 126
equals 1 1353 131
assign 1 1354 132
new 0 1354 132
assign 1 1356 135
new 0 1356 135
assign 1 1356 136
new 1 1356 136
throw 1 1356 137
assign 1 1358 142
sizeGet 0 1358 142
assign 1 1358 143
notEquals 1 1358 148
assign 1 1359 149
sizeGet 0 1359 149
setValue 1 1359 150
addValue 1 1361 152
assign 1 1362 153
new 0 1362 153
copyValue 4 1362 154
setValue 1 1363 155
return 1 1365 157
return 1 1369 160
return 1 1373 163
return 1 0 166
return 1 0 169
assign 1 0 172
assign 1 0 176
return 1 0 180
return 1 0 183
assign 1 0 186
assign 1 0 190
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1291754014: return bem_fieldIteratorGet_0();
case 376318330: return bem_toAny_0();
case -188774864: return bem_fieldNamesGet_0();
case 1892440434: return bem_serializeToString_0();
case 2022591848: return bem_new_0();
case -1107234286: return bem_ivalGet_0();
case -999106707: return bem_vcopyGet_0();
case 123890466: return bem_tagGet_0();
case -1336547559: return bem_copy_0();
case -1778311841: return bem_hasNextGet_0();
case -1914264312: return bem_serializationIteratorGet_0();
case 1924878947: return bem_serializeContents_0();
case -2097142996: return bem_many_0();
case -92876860: return bem_echo_0();
case -1673560399: return bem_toString_0();
case 1684359161: return bem_classNameGet_0();
case -1704712124: return bem_bcountGetDirect_0();
case 1538356292: return bem_nextGet_0();
case -2090696396: return bem_strGet_0();
case 782585161: return bem_deserializeClassNameGet_0();
case 1155228453: return bem_multiByteIteratorIteratorGet_0();
case 632535565: return bem_containerGet_0();
case 604393816: return bem_strGetDirect_0();
case 1714059697: return bem_iteratorGet_0();
case 704433134: return bem_ivalGetDirect_0();
case -1576271171: return bem_posGet_0();
case -398562709: return bem_vcopyGetDirect_0();
case 1726245742: return bem_hashGet_0();
case -175273612: return bem_posGetDirect_0();
case -172634187: return bem_once_0();
case -870016446: return bem_print_0();
case -670105916: return bem_byteIteratorIteratorGet_0();
case -997138031: return bem_create_0();
case 2055857335: return bem_bcountGet_0();
case -939140314: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -502649276: return bem_notEquals_1(bevd_0);
case -1245620052: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1860558101: return bem_sameType_1(bevd_0);
case 1857861907: return bem_bcountSetDirect_1(bevd_0);
case -1103040453: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 1560831110: return bem_equals_1(bevd_0);
case -1783619507: return bem_sameClass_1(bevd_0);
case 2024151813: return bem_otherClass_1(bevd_0);
case 1823110159: return bem_ivalSetDirect_1(bevd_0);
case -1139805373: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2108385190: return bem_undefined_1(bevd_0);
case -628251942: return bem_defined_1(bevd_0);
case 1122714975: return bem_vcopySet_1(bevd_0);
case -1259222473: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -9743810: return bem_sameObject_1(bevd_0);
case -1299087238: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -636994717: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1802133619: return bem_undef_1(bevd_0);
case -379656630: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 520589705: return bem_strSetDirect_1(bevd_0);
case 405342261: return bem_strSet_1(bevd_0);
case -148425027: return bem_otherType_1(bevd_0);
case 476552274: return bem_ivalSet_1(bevd_0);
case -1554389120: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1708234308: return bem_posSetDirect_1(bevd_0);
case 1805626980: return bem_bcountSet_1(bevd_0);
case -1994787564: return bem_def_1(bevd_0);
case -1032180306: return bem_posSet_1(bevd_0);
case 921396152: return bem_copyTo_1(bevd_0);
case 742915379: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1921951359: return bem_vcopySetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -402932836: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1915330817: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -518118155: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -355453886: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1141599202: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1078652527: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1443758120: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_4_17_TextMultiByteIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_17_TextMultiByteIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_17_TextMultiByteIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst = (BEC_2_4_17_TextMultiByteIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_17_TextMultiByteIterator.bece_BEC_2_4_17_TextMultiByteIterator_bevs_type;
}
}
}
