namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_6_SystemRandom : BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }
static BEC_2_6_6_SystemRandom() { }

   
   public RandomNumberGenerator srand = RNGCryptoServiceProvider.Create();
   
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_0 = (new BEC_2_4_3_MathInt(26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_1 = (new BEC_2_4_3_MathInt(65));
public static new BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static new BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() {

      srand = RNGCryptoServiceProvider.Create();
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getInt_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) {

      byte[] rb = new byte[4];
      srand.GetBytes(rb);
      beva_value.bevi_int = BitConverter.ToInt32(rb, 0);
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_2_tmpany_phold = bem_getInt_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_getInt_1(beva_value);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_tmpany_phold = bem_getString_2(bevt_1_tmpany_phold, beva_size);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_str.bem_capacityGet_0();
if (bevt_1_tmpany_phold.bevi_int < beva_size.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 263 */ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 264 */
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_tmpany_phold);
bevl_value = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 272 */ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_9_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_0;
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) bevt_9_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bem_getIntMax_2(bevl_value, bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_1;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevt_7_tmpany_phold;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 272 */
 else  /* Line: 272 */ {
break;
} /* Line: 272 */
} /* Line: 272 */
return beva_str;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {203, 226, 226, 226, 247, 251, 251, 251, 251, 251, 255, 255, 255, 255, 259, 259, 259, 263, 263, 263, 264, 266, 266, 271, 272, 272, 272, 274, 274, 274, 274, 274, 274, 274, 272, 276};
public static new int[] bevs_smnlec
 = new int[] {27, 38, 39, 40, 47, 54, 55, 56, 57, 58, 64, 65, 66, 67, 72, 73, 74, 91, 92, 97, 98, 100, 101, 102, 103, 106, 111, 112, 113, 114, 115, 116, 117, 119, 120, 126};
/* BEGIN LINEINFO 
seedNow 0 203 27
assign 1 226 38
new 0 226 38
assign 1 226 39
getInt 1 226 39
return 1 226 40
return 1 247 47
assign 1 251 54
new 0 251 54
assign 1 251 55
getInt 1 251 55
assign 1 251 56
absValue 0 251 56
assign 1 251 57
modulusValue 1 251 57
return 1 251 58
assign 1 255 64
getInt 1 255 64
assign 1 255 65
absValue 0 255 65
assign 1 255 66
modulusValue 1 255 66
return 1 255 67
assign 1 259 72
new 1 259 72
assign 1 259 73
getString 2 259 73
return 1 259 74
assign 1 263 91
capacityGet 0 263 91
assign 1 263 92
lesser 1 263 97
capacitySet 1 264 98
assign 1 266 100
copy 0 266 100
sizeSet 1 266 101
assign 1 271 102
new 0 271 102
assign 1 272 103
new 0 272 103
assign 1 272 106
lesser 1 272 111
assign 1 274 112
new 0 274 112
assign 1 274 113
once 0 274 113
assign 1 274 114
getIntMax 2 274 114
assign 1 274 115
new 0 274 115
assign 1 274 116
once 0 274 116
assign 1 274 117
addValue 1 274 117
setIntUnchecked 2 274 119
incrementValue 0 272 120
return 1 276 126
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 330207183: return bem_once_0();
case 1610207827: return bem_serializeToString_0();
case -512259678: return bem_many_0();
case 722156191: return bem_create_0();
case -1012810233: return bem_getInt_0();
case 441719677: return bem_hashGet_0();
case -751296258: return bem_toString_0();
case 701763907: return bem_new_0();
case -796966532: return bem_print_0();
case -196471174: return bem_toAny_0();
case 561389448: return bem_copy_0();
case 1280430641: return bem_deserializeClassNameGet_0();
case -2127113784: return bem_sourceFileNameGet_0();
case 1213196089: return bem_seedNow_0();
case 70409796: return bem_fieldIteratorGet_0();
case -1612673222: return bem_echo_0();
case -447720903: return bem_default_0();
case -808549585: return bem_classNameGet_0();
case -627661593: return bem_serializationIteratorGet_0();
case 73901351: return bem_fieldNamesGet_0();
case -1391094119: return bem_tagGet_0();
case -374298812: return bem_iteratorGet_0();
case 2049921022: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 803653343: return bem_otherClass_1(bevd_0);
case 680756917: return bem_defined_1(bevd_0);
case -191286971: return bem_def_1(bevd_0);
case 1649757588: return bem_sameObject_1(bevd_0);
case -1934236484: return bem_sameType_1(bevd_0);
case 1645946581: return bem_notEquals_1(bevd_0);
case -1380437617: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1110748051: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1587984688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1197345309: return bem_otherType_1(bevd_0);
case -903844594: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case -1668696125: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -362077461: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case 788956945: return bem_undefined_1(bevd_0);
case -1272706644: return bem_copyTo_1(bevd_0);
case 1320952802: return bem_sameClass_1(bevd_0);
case 463890253: return bem_undef_1(bevd_0);
case -599496021: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case 725850689: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 235947300: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 814323516: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2053867671: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1365336246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1806210068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2137630710: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1094925459: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1242672538: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1245666680: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemRandom();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
}
