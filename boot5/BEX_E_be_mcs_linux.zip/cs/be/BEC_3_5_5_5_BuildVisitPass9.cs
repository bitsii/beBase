namespace be {
/* IO:File: source/build/Pass9.be */
public sealed class BEC_3_5_5_5_BuildVisitPass9 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass9() { }
static BEC_3_5_5_5_BuildVisitPass9() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x39};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass9_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x39,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_0 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x73,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x66,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x74,0x6F,0x6F,0x20,0x67,0x72,0x65,0x61,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass9_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass9_bels_0, 44));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_1 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_2 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_3 = {0x47,0x45,0x54};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_4 = {0x70,0x75,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_5 = {0x67,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_6 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_7 = {0x69,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_8 = {0x68,0x61,0x73,0x4E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_9 = {0x6E,0x65,0x78,0x74,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_10 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_11 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass9_bels_12 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x66,0x6F,0x72,0x20,0x6C,0x6F,0x6F,0x70,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x74,0x77,0x6F,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64};
public static new BEC_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass9 bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;

public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_lbrnode = null;
BEC_2_6_6_SystemObject bevl_loopif = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_bnode = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_6_6_SystemObject bevl_cond = null;
BEC_2_6_6_SystemObject bevl_atStep = null;
BEC_2_6_6_SystemObject bevl_estr = null;
BEC_2_6_6_SystemObject bevl_ac = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevl_ntarg = null;
BEC_2_6_6_SystemObject bevl_isPut = null;
BEC_2_5_4_BuildNode bevl_narg2 = null;
BEC_2_5_4_BuildNode bevl_narg3 = null;
BEC_2_5_4_BuildNode bevl_linn = null;
BEC_2_6_6_SystemObject bevl_lin = null;
BEC_2_6_6_SystemObject bevl_lany = null;
BEC_2_6_6_SystemObject bevl_toit = null;
BEC_2_6_6_SystemObject bevl_tmpn = null;
BEC_2_6_6_SystemObject bevl_tmpv = null;
BEC_2_6_6_SystemObject bevl_gin = null;
BEC_2_6_6_SystemObject bevl_gic = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_asc = null;
BEC_2_6_6_SystemObject bevl_tmpnt = null;
BEC_2_6_6_SystemObject bevl_tcn = null;
BEC_2_6_6_SystemObject bevl_tcc = null;
BEC_2_6_6_SystemObject bevl_tmpng = null;
BEC_2_6_6_SystemObject bevl_iagn = null;
BEC_2_6_6_SystemObject bevl_iagc = null;
BEC_2_6_6_SystemObject bevl_iasn = null;
BEC_2_6_6_SystemObject bevl_iasc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_23_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_45_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_50_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_68_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_73_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_74_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_75_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_119_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_130_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_139_tmpany_phold = null;
BEC_2_4_6_TextString bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_145_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_153_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_154_tmpany_phold = null;
bevt_7_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_8_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_7_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 30 */ {
beva_node.bem_initContained_0();
bevt_9_tmpany_phold = beva_node.bem_containedGet_0();
bevl_it = bevt_9_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 35 */ {
bevt_10_tmpany_phold = bevl_it.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 35 */ {
bevl_i = bevl_it.bemd_0(-1738265524);
bevt_12_tmpany_phold = bevl_i.bemd_0(770126239);
bevt_13_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(-390319261, bevt_13_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 38 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(-12868923);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1284229570);
if (bevt_15_tmpany_phold == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(-12868923);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_0(1206759967);
bevl_i.bemd_1(-1864479135, bevt_17_tmpany_phold);
bevl_i.bemd_0(2080975900);
} /* Line: 41 */
 else  /* Line: 42 */ {
bevt_19_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass9_bevo_0;
bevt_22_tmpany_phold = bevl_i.bemd_0(-12868923);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-1986207258);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(1513233059);
bevl_estr = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevl_estr, beva_node);
throw new be.BECS_ThrowBack(bevt_23_tmpany_phold);
} /* Line: 44 */
} /* Line: 39 */
} /* Line: 38 */
 else  /* Line: 35 */ {
break;
} /* Line: 35 */
} /* Line: 35 */
bevt_24_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_24_tmpany_phold;
} /* Line: 48 */
 else  /* Line: 30 */ {
bevt_26_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
if (bevt_26_tmpany_phold.bevi_int == bevt_27_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_c.bemd_1(-1960489208, bevt_28_tmpany_phold);
bevt_31_tmpany_phold = beva_node.bem_containerGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_typenameGet_0();
bevt_32_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_30_tmpany_phold.bevi_int == bevt_32_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_36_tmpany_phold = beva_node.bem_containerGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_heldGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(1041439923);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_1(-390319261, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_33_tmpany_phold).bevi_bool) /* Line: 56 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
 else  /* Line: 56 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 56 */ {
bevt_38_tmpany_phold = beva_node.bem_isFirstGet_0();
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 56 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 56 */
 else  /* Line: 56 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 56 */ {
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_2));
bevl_c.bemd_1(751452664, bevt_39_tmpany_phold);
} /* Line: 57 */
 else  /* Line: 58 */ {
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_3));
bevl_c.bemd_1(751452664, bevt_40_tmpany_phold);
} /* Line: 59 */
bevt_41_tmpany_phold = bevl_ac.bemd_0(1041439923);
bevl_c.bemd_1(-1639447904, bevt_41_tmpany_phold);
bevl_c.bemd_0(1584807758);
bevt_43_tmpany_phold = bevl_c.bemd_0(714434414);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_2));
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bemd_1(-390319261, bevt_44_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 63 */ {
bevt_45_tmpany_phold = beva_node.bem_containerGet_0();
bevt_45_tmpany_phold.bem_heldSet_1(bevl_c);
bevt_46_tmpany_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_46_tmpany_phold.bem_firstGet_0();
bevt_47_tmpany_phold = bevl_ntarg.bemd_0(770126239);
beva_node.bem_typenameSet_1(bevt_47_tmpany_phold);
bevt_48_tmpany_phold = bevl_ntarg.bemd_0(1721602940);
beva_node.bem_heldSet_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevl_ntarg.bemd_0(-12868923);
beva_node.bem_containedSet_1(bevt_49_tmpany_phold);
bevt_51_tmpany_phold = beva_node.bem_containerGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_nextDescendGet_0();
return bevt_50_tmpany_phold;
} /* Line: 70 */
 else  /* Line: 71 */ {
bevt_52_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_52_tmpany_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 73 */
bevt_53_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_53_tmpany_phold;
} /* Line: 75 */
 else  /* Line: 30 */ {
bevt_55_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_56_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
if (bevt_55_tmpany_phold.bevi_int == bevt_56_tmpany_phold.bevi_int) {
bevt_54_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_54_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevl_ac = beva_node.bem_heldGet_0();
bevl_c = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_59_tmpany_phold = beva_node.bem_containerGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bem_typenameGet_0();
bevt_60_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_60_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_64_tmpany_phold = beva_node.bem_containerGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bem_heldGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(1041439923);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_1(-390319261, bevt_65_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 80 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
 else  /* Line: 80 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 80 */ {
bevt_66_tmpany_phold = beva_node.bem_isFirstGet_0();
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 80 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 80 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 80 */
 else  /* Line: 80 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 80 */ {
bevl_isPut = be.BECS_Runtime.boolTrue;
} /* Line: 82 */
 else  /* Line: 83 */ {
bevl_isPut = be.BECS_Runtime.boolFalse;
} /* Line: 85 */
if (((BEC_2_5_4_LogicBool) bevl_isPut).bevi_bool) /* Line: 87 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_4));
bevl_c.bemd_1(-1639447904, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = beva_node.bem_containerGet_0();
bevt_68_tmpany_phold.bem_heldSet_1(bevl_c);
bevt_69_tmpany_phold = beva_node.bem_containedGet_0();
bevl_ntarg = bevt_69_tmpany_phold.bem_firstGet_0();
bevl_narg2 = (BEC_2_5_4_BuildNode) bevl_ntarg.bemd_0(896327087);
bevl_narg3 = beva_node.bem_nextPeerGet_0();
bevl_narg2.bem_delete_0();
bevl_narg3.bem_delete_0();
bevt_70_tmpany_phold = bevl_ntarg.bemd_0(770126239);
beva_node.bem_typenameSet_1(bevt_70_tmpany_phold);
bevt_71_tmpany_phold = bevl_ntarg.bemd_0(1721602940);
beva_node.bem_heldSet_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevl_ntarg.bemd_0(-12868923);
beva_node.bem_containedSet_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = beva_node.bem_containerGet_0();
bevt_73_tmpany_phold.bem_addValue_1(bevl_narg2);
bevt_74_tmpany_phold = beva_node.bem_containerGet_0();
bevt_74_tmpany_phold.bem_addValue_1(bevl_narg3);
bevt_76_tmpany_phold = beva_node.bem_containerGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_nextDescendGet_0();
return bevt_75_tmpany_phold;
} /* Line: 105 */
 else  /* Line: 106 */ {
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass9_bels_5));
bevl_c.bemd_1(-1639447904, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bem_typenameSet_1(bevt_78_tmpany_phold);
beva_node.bem_heldSet_1(bevl_c);
} /* Line: 113 */
bevt_79_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_79_tmpany_phold;
} /* Line: 115 */
} /* Line: 30 */
} /* Line: 30 */
bevt_81_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_82_tmpany_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_81_tmpany_phold.bevi_int == bevt_82_tmpany_phold.bevi_int) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevt_85_tmpany_phold = beva_node.bem_containedGet_0();
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bem_firstGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(-12868923);
bevl_linn = (BEC_2_5_4_BuildNode) bevt_83_tmpany_phold.bemd_0(1206759967);
bevt_87_tmpany_phold = bevl_linn.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_90_tmpany_phold = bevl_linn.bem_heldGet_0();
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_0(-1886613910);
if (((BEC_2_5_4_LogicBool) bevt_89_tmpany_phold).bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_91_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
beva_node.bem_typenameSet_1(bevt_91_tmpany_phold);
} /* Line: 122 */
} /* Line: 120 */
bevt_93_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_94_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
if (bevt_93_tmpany_phold.bevi_int == bevt_94_tmpany_phold.bevi_int) {
bevt_92_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_92_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_92_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_95_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
beva_node.bem_typenameSet_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_96_tmpany_phold.bem_firstGet_0();
bevl_brnode = beva_node.bem_secondGet_0();
bevt_97_tmpany_phold = bevl_pnode.bemd_0(-12868923);
bevl_lin = bevt_97_tmpany_phold.bemd_0(1206759967);
bevt_98_tmpany_phold = bevl_lin.bemd_0(-12868923);
bevl_lany = bevt_98_tmpany_phold.bemd_0(1206759967);
bevl_toit = bevl_lin.bemd_0(1593453371);
bevl_pnode.bemd_1(1923865818, null);
bevl_tmpn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpn.bemd_1(-2026879179, beva_node);
bevt_99_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpn.bemd_1(410619082, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass9_bels_6));
bevl_tmpv = beva_node.bem_tmpVar_2(bevt_100_tmpany_phold, bevp_build);
bevl_tmpn.bemd_1(1931610315, bevl_tmpv);
bevl_gin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_101_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_gin.bemd_1(410619082, bevt_101_tmpany_phold);
bevl_gic = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_gin.bemd_1(1931610315, bevl_gic);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass9_bels_7));
bevl_gic.bemd_1(-1639447904, bevt_102_tmpany_phold);
bevt_103_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gic.bemd_1(-81490097, bevt_103_tmpany_phold);
bevl_gin.bemd_1(-989818108, bevl_toit);
bevl_asn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(-2026879179, beva_node);
bevt_104_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asn.bemd_1(410619082, bevt_104_tmpany_phold);
bevl_asc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_asn.bemd_1(1931610315, bevl_asc);
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevl_asc.bemd_1(-1639447904, bevt_105_tmpany_phold);
bevl_asn.bemd_1(-989818108, bevl_tmpn);
bevl_asn.bemd_1(-989818108, bevl_gin);
beva_node.bem_beforeInsert_1((BEC_2_5_4_BuildNode) bevl_asn );
bevl_tmpn.bemd_0(1768501912);
bevl_tmpnt = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_asn.bemd_1(-2026879179, beva_node);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpnt.bemd_1(410619082, bevt_106_tmpany_phold);
bevl_tmpnt.bemd_1(1931610315, bevl_tmpv);
bevl_tcn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tcn.bemd_1(-2026879179, beva_node);
bevt_107_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_tcn.bemd_1(410619082, bevt_107_tmpany_phold);
bevl_tcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_tcn.bemd_1(1931610315, bevl_tcc);
bevt_108_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass9_bels_8));
bevl_tcc.bemd_1(-1639447904, bevt_108_tmpany_phold);
bevl_tcn.bemd_1(-989818108, bevl_tmpnt);
bevl_pnode.bemd_1(-989818108, bevl_tcn);
bevl_tmpng = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_tmpng.bemd_1(-2026879179, beva_node);
bevt_109_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_tmpng.bemd_1(410619082, bevt_109_tmpany_phold);
bevl_tmpng.bemd_1(1931610315, bevl_tmpv);
bevl_iagn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iagn.bemd_1(-2026879179, beva_node);
bevt_110_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iagn.bemd_1(410619082, bevt_110_tmpany_phold);
bevl_iagc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iagn.bemd_1(1931610315, bevl_iagc);
bevt_111_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass9_bels_9));
bevl_iagc.bemd_1(-1639447904, bevt_111_tmpany_phold);
bevl_iagn.bemd_1(-989818108, bevl_tmpng);
bevl_iasn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_iasn.bemd_1(-2026879179, beva_node);
bevt_112_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_iasn.bemd_1(410619082, bevt_112_tmpany_phold);
bevl_iasc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevl_iasn.bemd_1(1931610315, bevl_iasc);
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_1));
bevl_iasc.bemd_1(-1639447904, bevt_113_tmpany_phold);
bevl_iasn.bemd_1(-989818108, bevl_lany);
bevl_iasn.bemd_1(-989818108, bevl_iagn);
bevl_brnode.bemd_1(88962889, bevl_iasn);
return (BEC_2_5_4_BuildNode) bevl_toit;
} /* Line: 215 */
bevt_115_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_116_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
if (bevt_115_tmpany_phold.bevi_int == bevt_116_tmpany_phold.bevi_int) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(-2026879179, beva_node);
bevt_117_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(410619082, bevt_117_tmpany_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(-2026879179, beva_node);
bevt_118_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(410619082, bevt_118_tmpany_phold);
bevl_lnode.bemd_1(-989818108, bevl_lbrnode);
bevl_loopif = beva_node;
bevt_119_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(410619082, bevt_119_tmpany_phold);
bevl_lbrnode.bemd_1(-989818108, bevl_loopif);
bevt_121_tmpany_phold = beva_node.bem_heldGet_0();
if (bevt_121_tmpany_phold == null) {
bevt_120_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_120_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_120_tmpany_phold.bevi_bool) /* Line: 229 */ {
bevt_123_tmpany_phold = beva_node.bem_heldGet_0();
bevt_124_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass9_bels_10));
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(-390319261, bevt_124_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_122_tmpany_phold).bevi_bool) /* Line: 229 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 229 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 229 */
 else  /* Line: 229 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 229 */ {
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass9_bels_11));
bevl_loopif.bemd_1(1931610315, bevt_125_tmpany_phold);
} /* Line: 230 */
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(-2026879179, beva_node);
bevt_126_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(410619082, bevt_126_tmpany_phold);
bevl_loopif.bemd_1(-989818108, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(-2026879179, beva_node);
bevt_127_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(410619082, bevt_127_tmpany_phold);
bevl_enode.bemd_1(-989818108, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-2026879179, beva_node);
bevt_128_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(410619082, bevt_128_tmpany_phold);
bevl_brnode.bemd_1(-989818108, bevl_bnode);
bevt_129_tmpany_phold = bevl_lnode.bemd_0(-193444335);
return (BEC_2_5_4_BuildNode) bevt_129_tmpany_phold;
} /* Line: 244 */
 else  /* Line: 217 */ {
bevt_131_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_132_tmpany_phold = bevp_ntypes.bem_FORGet_0();
if (bevt_131_tmpany_phold.bevi_int == bevt_132_tmpany_phold.bevi_int) {
bevt_130_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_130_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_130_tmpany_phold.bevi_bool) /* Line: 245 */ {
bevl_lnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lnode.bemd_1(-2026879179, beva_node);
bevt_133_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevl_lnode.bemd_1(410619082, bevt_133_tmpany_phold);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevt_134_tmpany_phold = beva_node.bem_containedGet_0();
bevl_pnode = bevt_134_tmpany_phold.bem_firstGet_0();
bevl_pnode.bemd_0(2080975900);
bevt_137_tmpany_phold = bevl_pnode.bemd_0(-12868923);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(-1986207258);
bevt_138_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(-124318134, bevt_138_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_135_tmpany_phold).bevi_bool) /* Line: 252 */ {
bevt_140_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bece_BEC_3_5_5_5_BuildVisitPass9_bels_12));
bevt_139_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_140_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_139_tmpany_phold);
} /* Line: 253 */
bevt_141_tmpany_phold = bevl_pnode.bemd_0(-12868923);
bevl_init = bevt_141_tmpany_phold.bemd_0(1206759967);
bevl_cond = bevl_pnode.bemd_0(1593453371);
bevl_atStep = null;
bevt_144_tmpany_phold = bevl_pnode.bemd_0(-12868923);
bevt_143_tmpany_phold = bevt_144_tmpany_phold.bemd_0(-1986207258);
bevt_145_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bemd_1(-1986564952, bevt_145_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_142_tmpany_phold).bevi_bool) /* Line: 258 */ {
bevl_atStep = bevl_pnode.bemd_0(-1524334826);
bevl_atStep.bemd_0(2080975900);
} /* Line: 260 */
bevl_init.bemd_0(2080975900);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_lnode );
bevl_lnode.bemd_1(-1864479135, bevl_init);
bevl_lbrnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_lbrnode.bemd_1(-2026879179, beva_node);
bevt_146_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_lbrnode.bemd_1(410619082, bevt_146_tmpany_phold);
bevl_lnode.bemd_1(-989818108, bevl_lbrnode);
bevl_loopif = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_loopif.bemd_1(-2026879179, beva_node);
bevt_147_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_loopif.bemd_1(410619082, bevt_147_tmpany_phold);
bevl_loopif.bemd_1(-614531390, beva_node);
if (bevl_atStep == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 275 */ {
bevt_150_tmpany_phold = bevl_loopif.bemd_0(-12868923);
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_0(1206759967);
bevt_149_tmpany_phold.bemd_1(-989818108, bevl_atStep);
} /* Line: 276 */
bevl_loopif.bemd_1(88962889, bevl_pnode);
bevl_lbrnode.bemd_1(-989818108, bevl_loopif);
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_enode.bemd_1(-2026879179, beva_node);
bevt_151_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(410619082, bevt_151_tmpany_phold);
bevl_loopif.bemd_1(-989818108, bevl_enode);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(-2026879179, beva_node);
bevt_152_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(410619082, bevt_152_tmpany_phold);
bevl_enode.bemd_1(-989818108, bevl_brnode);
bevl_bnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_bnode.bemd_1(-2026879179, beva_node);
bevt_153_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevl_bnode.bemd_1(410619082, bevt_153_tmpany_phold);
bevl_brnode.bemd_1(-989818108, bevl_bnode);
return (BEC_2_5_4_BuildNode) bevl_init;
} /* Line: 293 */
} /* Line: 217 */
bevt_154_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_154_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {30, 30, 30, 30, 34, 35, 35, 35, 37, 38, 38, 38, 39, 39, 39, 39, 40, 40, 40, 41, 43, 43, 43, 43, 43, 44, 44, 48, 48, 49, 49, 49, 49, 53, 54, 55, 55, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 0, 0, 0, 56, 0, 0, 0, 57, 57, 59, 59, 61, 61, 62, 63, 63, 63, 64, 64, 65, 65, 67, 67, 68, 68, 69, 69, 70, 70, 70, 72, 72, 73, 75, 75, 76, 76, 76, 76, 78, 79, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 0, 0, 0, 80, 0, 0, 0, 82, 85, 88, 88, 89, 89, 90, 90, 93, 94, 96, 97, 99, 99, 100, 100, 101, 101, 103, 103, 104, 104, 105, 105, 105, 111, 111, 112, 112, 113, 115, 115, 117, 117, 117, 117, 119, 119, 119, 119, 120, 120, 120, 120, 120, 120, 0, 0, 0, 122, 122, 125, 125, 125, 125, 126, 126, 127, 127, 128, 129, 129, 130, 130, 131, 132, 151, 152, 153, 153, 154, 154, 155, 157, 158, 158, 159, 160, 161, 161, 162, 162, 163, 165, 166, 167, 167, 168, 169, 170, 170, 171, 172, 174, 175, 177, 178, 179, 179, 180, 182, 183, 184, 184, 185, 186, 187, 187, 188, 190, 192, 193, 194, 194, 195, 197, 198, 199, 199, 200, 201, 202, 202, 203, 205, 206, 207, 207, 208, 209, 210, 210, 211, 212, 214, 215, 217, 217, 217, 217, 218, 219, 220, 220, 221, 222, 223, 224, 224, 225, 226, 227, 227, 228, 229, 229, 229, 229, 229, 229, 0, 0, 0, 230, 230, 232, 233, 234, 234, 235, 236, 237, 238, 238, 239, 240, 241, 242, 242, 243, 244, 244, 245, 245, 245, 245, 246, 247, 248, 248, 249, 250, 250, 251, 252, 252, 252, 252, 253, 253, 253, 255, 255, 256, 257, 258, 258, 258, 258, 259, 260, 262, 264, 265, 267, 268, 269, 269, 270, 271, 272, 273, 273, 274, 275, 275, 276, 276, 276, 278, 279, 280, 281, 282, 282, 283, 284, 285, 286, 286, 287, 288, 289, 290, 290, 291, 293, 295, 295};
public static new int[] bevs_smnlec
 = new int[] {220, 221, 222, 227, 228, 229, 230, 233, 235, 236, 237, 238, 240, 241, 242, 247, 248, 249, 250, 251, 254, 255, 256, 257, 258, 259, 260, 268, 269, 272, 273, 274, 279, 280, 281, 282, 283, 284, 285, 286, 287, 292, 293, 294, 295, 296, 297, 299, 302, 306, 309, 311, 314, 318, 321, 322, 325, 326, 328, 329, 330, 331, 332, 333, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 350, 351, 352, 354, 355, 358, 359, 360, 365, 366, 367, 368, 369, 370, 371, 376, 377, 378, 379, 380, 381, 383, 386, 390, 393, 395, 398, 402, 405, 408, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 436, 437, 438, 439, 440, 442, 443, 447, 448, 449, 454, 455, 456, 457, 458, 459, 460, 461, 466, 467, 468, 470, 473, 477, 480, 481, 484, 485, 486, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 574, 575, 576, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 602, 603, 604, 605, 607, 610, 614, 617, 618, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 639, 640, 641, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 660, 661, 662, 664, 665, 666, 667, 668, 669, 670, 671, 673, 674, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 694, 695, 696, 697, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 719, 720};
/* BEGIN LINEINFO 
assign 1 30 220
typenameGet 0 30 220
assign 1 30 221
CALLGet 0 30 221
assign 1 30 222
equals 1 30 227
initContained 0 34 228
assign 1 35 229
containedGet 0 35 229
assign 1 35 230
iteratorGet 0 35 230
assign 1 35 233
hasNextGet 0 35 233
assign 1 37 235
nextGet 0 37 235
assign 1 38 236
typenameGet 0 38 236
assign 1 38 237
PARENSGet 0 38 237
assign 1 38 238
equals 1 38 238
assign 1 39 240
containedGet 0 39 240
assign 1 39 241
firstNodeGet 0 39 241
assign 1 39 242
def 1 39 247
assign 1 40 248
containedGet 0 40 248
assign 1 40 249
firstGet 0 40 249
beforeInsert 1 40 250
delete 0 41 251
assign 1 43 254
new 0 43 254
assign 1 43 255
containedGet 0 43 255
assign 1 43 256
lengthGet 0 43 256
assign 1 43 257
toString 0 43 257
assign 1 43 258
add 1 43 258
assign 1 44 259
new 2 44 259
throw 1 44 260
assign 1 48 268
nextDescendGet 0 48 268
return 1 48 269
assign 1 49 272
typenameGet 0 49 272
assign 1 49 273
ACCESSORGet 0 49 273
assign 1 49 274
equals 1 49 279
assign 1 53 280
heldGet 0 53 280
assign 1 54 281
new 0 54 281
assign 1 55 282
new 0 55 282
wasAccessorSet 1 55 283
assign 1 56 284
containerGet 0 56 284
assign 1 56 285
typenameGet 0 56 285
assign 1 56 286
CALLGet 0 56 286
assign 1 56 287
equals 1 56 292
assign 1 56 293
containerGet 0 56 293
assign 1 56 294
heldGet 0 56 294
assign 1 56 295
nameGet 0 56 295
assign 1 56 296
new 0 56 296
assign 1 56 297
equals 1 56 297
assign 1 0 299
assign 1 0 302
assign 1 0 306
assign 1 56 309
isFirstGet 0 56 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 57 321
new 0 57 321
accessorTypeSet 1 57 322
assign 1 59 325
new 0 59 325
accessorTypeSet 1 59 326
assign 1 61 328
nameGet 0 61 328
nameSet 1 61 329
toAccessorName 0 62 330
assign 1 63 331
accessorTypeGet 0 63 331
assign 1 63 332
new 0 63 332
assign 1 63 333
equals 1 63 333
assign 1 64 335
containerGet 0 64 335
heldSet 1 64 336
assign 1 65 337
containedGet 0 65 337
assign 1 65 338
firstGet 0 65 338
assign 1 67 339
typenameGet 0 67 339
typenameSet 1 67 340
assign 1 68 341
heldGet 0 68 341
heldSet 1 68 342
assign 1 69 343
containedGet 0 69 343
containedSet 1 69 344
assign 1 70 345
containerGet 0 70 345
assign 1 70 346
nextDescendGet 0 70 346
return 1 70 347
assign 1 72 350
CALLGet 0 72 350
typenameSet 1 72 351
heldSet 1 73 352
assign 1 75 354
nextDescendGet 0 75 354
return 1 75 355
assign 1 76 358
typenameGet 0 76 358
assign 1 76 359
IDXACCGet 0 76 359
assign 1 76 360
equals 1 76 365
assign 1 78 366
heldGet 0 78 366
assign 1 79 367
new 0 79 367
assign 1 80 368
containerGet 0 80 368
assign 1 80 369
typenameGet 0 80 369
assign 1 80 370
CALLGet 0 80 370
assign 1 80 371
equals 1 80 376
assign 1 80 377
containerGet 0 80 377
assign 1 80 378
heldGet 0 80 378
assign 1 80 379
nameGet 0 80 379
assign 1 80 380
new 0 80 380
assign 1 80 381
equals 1 80 381
assign 1 0 383
assign 1 0 386
assign 1 0 390
assign 1 80 393
isFirstGet 0 80 393
assign 1 0 395
assign 1 0 398
assign 1 0 402
assign 1 82 405
new 0 82 405
assign 1 85 408
new 0 85 408
assign 1 88 411
new 0 88 411
nameSet 1 88 412
assign 1 89 413
containerGet 0 89 413
heldSet 1 89 414
assign 1 90 415
containedGet 0 90 415
assign 1 90 416
firstGet 0 90 416
assign 1 93 417
nextPeerGet 0 93 417
assign 1 94 418
nextPeerGet 0 94 418
delete 0 96 419
delete 0 97 420
assign 1 99 421
typenameGet 0 99 421
typenameSet 1 99 422
assign 1 100 423
heldGet 0 100 423
heldSet 1 100 424
assign 1 101 425
containedGet 0 101 425
containedSet 1 101 426
assign 1 103 427
containerGet 0 103 427
addValue 1 103 428
assign 1 104 429
containerGet 0 104 429
addValue 1 104 430
assign 1 105 431
containerGet 0 105 431
assign 1 105 432
nextDescendGet 0 105 432
return 1 105 433
assign 1 111 436
new 0 111 436
nameSet 1 111 437
assign 1 112 438
CALLGet 0 112 438
typenameSet 1 112 439
heldSet 1 113 440
assign 1 115 442
nextDescendGet 0 115 442
return 1 115 443
assign 1 117 447
typenameGet 0 117 447
assign 1 117 448
FORGet 0 117 448
assign 1 117 449
equals 1 117 454
assign 1 119 455
containedGet 0 119 455
assign 1 119 456
firstGet 0 119 456
assign 1 119 457
containedGet 0 119 457
assign 1 119 458
firstGet 0 119 458
assign 1 120 459
typenameGet 0 120 459
assign 1 120 460
CALLGet 0 120 460
assign 1 120 461
equals 1 120 466
assign 1 120 467
heldGet 0 120 467
assign 1 120 468
wasOperGet 0 120 468
assign 1 0 470
assign 1 0 473
assign 1 0 477
assign 1 122 480
FOREACHGet 0 122 480
typenameSet 1 122 481
assign 1 125 484
typenameGet 0 125 484
assign 1 125 485
FOREACHGet 0 125 485
assign 1 125 486
equals 1 125 491
assign 1 126 492
WHILEGet 0 126 492
typenameSet 1 126 493
assign 1 127 494
containedGet 0 127 494
assign 1 127 495
firstGet 0 127 495
assign 1 128 496
secondGet 0 128 496
assign 1 129 497
containedGet 0 129 497
assign 1 129 498
firstGet 0 129 498
assign 1 130 499
containedGet 0 130 499
assign 1 130 500
firstGet 0 130 500
assign 1 131 501
secondGet 0 131 501
containedSet 1 132 502
assign 1 151 503
new 1 151 503
copyLoc 1 152 504
assign 1 153 505
VARGet 0 153 505
typenameSet 1 153 506
assign 1 154 507
new 0 154 507
assign 1 154 508
tmpVar 2 154 508
heldSet 1 155 509
assign 1 157 510
new 1 157 510
assign 1 158 511
CALLGet 0 158 511
typenameSet 1 158 512
assign 1 159 513
new 0 159 513
heldSet 1 160 514
assign 1 161 515
new 0 161 515
nameSet 1 161 516
assign 1 162 517
new 0 162 517
wasForeachGennedSet 1 162 518
addValue 1 163 519
assign 1 165 520
new 1 165 520
copyLoc 1 166 521
assign 1 167 522
CALLGet 0 167 522
typenameSet 1 167 523
assign 1 168 524
new 0 168 524
heldSet 1 169 525
assign 1 170 526
new 0 170 526
nameSet 1 170 527
addValue 1 171 528
addValue 1 172 529
beforeInsert 1 174 530
addVariable 0 175 531
assign 1 177 532
new 1 177 532
copyLoc 1 178 533
assign 1 179 534
VARGet 0 179 534
typenameSet 1 179 535
heldSet 1 180 536
assign 1 182 537
new 1 182 537
copyLoc 1 183 538
assign 1 184 539
CALLGet 0 184 539
typenameSet 1 184 540
assign 1 185 541
new 0 185 541
heldSet 1 186 542
assign 1 187 543
new 0 187 543
nameSet 1 187 544
addValue 1 188 545
addValue 1 190 546
assign 1 192 547
new 1 192 547
copyLoc 1 193 548
assign 1 194 549
VARGet 0 194 549
typenameSet 1 194 550
heldSet 1 195 551
assign 1 197 552
new 1 197 552
copyLoc 1 198 553
assign 1 199 554
CALLGet 0 199 554
typenameSet 1 199 555
assign 1 200 556
new 0 200 556
heldSet 1 201 557
assign 1 202 558
new 0 202 558
nameSet 1 202 559
addValue 1 203 560
assign 1 205 561
new 1 205 561
copyLoc 1 206 562
assign 1 207 563
CALLGet 0 207 563
typenameSet 1 207 564
assign 1 208 565
new 0 208 565
heldSet 1 209 566
assign 1 210 567
new 0 210 567
nameSet 1 210 568
addValue 1 211 569
addValue 1 212 570
prepend 1 214 571
return 1 215 572
assign 1 217 574
typenameGet 0 217 574
assign 1 217 575
WHILEGet 0 217 575
assign 1 217 576
equals 1 217 581
assign 1 218 582
new 1 218 582
copyLoc 1 219 583
assign 1 220 584
LOOPGet 0 220 584
typenameSet 1 220 585
replaceWith 1 221 586
assign 1 222 587
new 1 222 587
copyLoc 1 223 588
assign 1 224 589
BRACESGet 0 224 589
typenameSet 1 224 590
addValue 1 225 591
assign 1 226 592
assign 1 227 593
IFGet 0 227 593
typenameSet 1 227 594
addValue 1 228 595
assign 1 229 596
heldGet 0 229 596
assign 1 229 597
def 1 229 602
assign 1 229 603
heldGet 0 229 603
assign 1 229 604
new 0 229 604
assign 1 229 605
equals 1 229 605
assign 1 0 607
assign 1 0 610
assign 1 0 614
assign 1 230 617
new 0 230 617
heldSet 1 230 618
assign 1 232 620
new 1 232 620
copyLoc 1 233 621
assign 1 234 622
ELSEGet 0 234 622
typenameSet 1 234 623
addValue 1 235 624
assign 1 236 625
new 1 236 625
copyLoc 1 237 626
assign 1 238 627
BRACESGet 0 238 627
typenameSet 1 238 628
addValue 1 239 629
assign 1 240 630
new 1 240 630
copyLoc 1 241 631
assign 1 242 632
BREAKGet 0 242 632
typenameSet 1 242 633
addValue 1 243 634
assign 1 244 635
nextDescendGet 0 244 635
return 1 244 636
assign 1 245 639
typenameGet 0 245 639
assign 1 245 640
FORGet 0 245 640
assign 1 245 641
equals 1 245 646
assign 1 246 647
new 1 246 647
copyLoc 1 247 648
assign 1 248 649
LOOPGet 0 248 649
typenameSet 1 248 650
replaceWith 1 249 651
assign 1 250 652
containedGet 0 250 652
assign 1 250 653
firstGet 0 250 653
delete 0 251 654
assign 1 252 655
containedGet 0 252 655
assign 1 252 656
lengthGet 0 252 656
assign 1 252 657
new 0 252 657
assign 1 252 658
lesser 1 252 658
assign 1 253 660
new 0 253 660
assign 1 253 661
new 2 253 661
throw 1 253 662
assign 1 255 664
containedGet 0 255 664
assign 1 255 665
firstGet 0 255 665
assign 1 256 666
secondGet 0 256 666
assign 1 257 667
assign 1 258 668
containedGet 0 258 668
assign 1 258 669
lengthGet 0 258 669
assign 1 258 670
new 0 258 670
assign 1 258 671
greater 1 258 671
assign 1 259 673
thirdGet 0 259 673
delete 0 260 674
delete 0 262 676
replaceWith 1 264 677
beforeInsert 1 265 678
assign 1 267 679
new 1 267 679
copyLoc 1 268 680
assign 1 269 681
BRACESGet 0 269 681
typenameSet 1 269 682
addValue 1 270 683
assign 1 271 684
new 1 271 684
copyLoc 1 272 685
assign 1 273 686
IFGet 0 273 686
typenameSet 1 273 687
takeContents 1 274 688
assign 1 275 689
def 1 275 694
assign 1 276 695
containedGet 0 276 695
assign 1 276 696
firstGet 0 276 696
addValue 1 276 697
prepend 1 278 699
addValue 1 279 700
assign 1 280 701
new 1 280 701
copyLoc 1 281 702
assign 1 282 703
ELSEGet 0 282 703
typenameSet 1 282 704
addValue 1 283 705
assign 1 284 706
new 1 284 706
copyLoc 1 285 707
assign 1 286 708
BRACESGet 0 286 708
typenameSet 1 286 709
addValue 1 287 710
assign 1 288 711
new 1 288 711
copyLoc 1 289 712
assign 1 290 713
BREAKGet 0 290 713
typenameSet 1 290 714
addValue 1 291 715
return 1 293 716
assign 1 295 719
nextDescendGet 0 295 719
return 1 295 720
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1194804327: return bem_fieldNamesGet_0();
case 1513233059: return bem_toString_0();
case -1999164817: return bem_transGetDirect_0();
case 144584723: return bem_create_0();
case -1123278056: return bem_tagGet_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case -1298453047: return bem_buildGet_0();
case 1577195459: return bem_serializationIteratorGet_0();
case -713163994: return bem_toAny_0();
case -1362850090: return bem_serializeContents_0();
case -2051518290: return bem_once_0();
case -449079106: return bem_iteratorGet_0();
case -1114977715: return bem_constGet_0();
case -1993157878: return bem_ntypesGetDirect_0();
case 1193197051: return bem_ntypesGet_0();
case 611670694: return bem_fieldIteratorGet_0();
case 1942283510: return bem_sourceFileNameGet_0();
case 1139700098: return bem_transGet_0();
case 96033137: return bem_serializeToString_0();
case 341575045: return bem_many_0();
case 1860736480: return bem_constGetDirect_0();
case -1266447496: return bem_classNameGet_0();
case 936251957: return bem_buildGetDirect_0();
case 1851908877: return bem_hashGet_0();
case -10010145: return bem_copy_0();
case 1071461198: return bem_echo_0();
case 990360647: return bem_new_0();
case -1086782351: return bem_print_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 631726084: return bem_constSet_1(bevd_0);
case -608257616: return bem_constSetDirect_1(bevd_0);
case -187300612: return bem_ntypesSet_1(bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case 1735530030: return bem_begin_1(bevd_0);
case 930474266: return bem_transSet_1(bevd_0);
case -209888717: return bem_buildSet_1(bevd_0);
case -655019399: return bem_def_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case 142328325: return bem_buildSetDirect_1(bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case 422384913: return bem_end_1(bevd_0);
case 1839872882: return bem_transSetDirect_1(bevd_0);
case 1191176750: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1744479301: return bem_ntypesSetDirect_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case 1449340032: return bem_otherClass_1(bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass9_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass9_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass9();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst = (BEC_3_5_5_5_BuildVisitPass9) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass9.bece_BEC_3_5_5_5_BuildVisitPass9_bevs_type;
}
}
}
