namespace be {
/* IO:File: source/base/OpiFc.be */
public sealed class BEC_2_6_19_SystemObjectFieldIterator : BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
static BEC_2_6_19_SystemObjectFieldIterator() { }
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0 = {0x47,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0, 9));
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1 = {0x53,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1, 9));
public static new BEC_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;

public static new BET_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_9_4_ContainerList bevp_instFieldNames;
public BEC_2_4_3_MathInt bevp_lastidx;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_new_2(beva__instance, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevp_instance.bemd_0(767177150);
bevt_0_tmpany_phold = bevp_instFieldNames.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_0;
bevp_lastidx = bevt_0_tmpany_phold.bem_subtract_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 30 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_pos.bevi_int < bevp_lastidx.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 36 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_pos.bevi_int <= bevp_lastidx.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 43 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bem_advance_0();
bevt_0_tmpany_phold = bem_currentNameGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 54 */ {
bevt_1_tmpany_phold = bevp_instFieldNames.bem_get_1(bevp_pos);
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /* Line: 55 */
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bem_advance_0();
bevt_0_tmpany_phold = bem_currentGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 66 */ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_1;
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_res = bevp_instance.bemd_2(1047719554, bevl_invokeName, bevt_2_tmpany_phold);
return bevl_res;
} /* Line: 70 */
return null;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
bem_advance_0();
bem_currentSet_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_9_4_ContainerList bevl_args = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bem_hasCurrentGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_19_SystemObjectFieldIterator_bevo_2;
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_args = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_args.bem_put_2(bevt_3_tmpany_phold, beva_value);
bevp_instance.bemd_2(1047719554, bevl_invokeName, bevl_args);
} /* Line: 86 */
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 91 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 91 */ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 91 */
 else  /* Line: 91 */ {
break;
} /* Line: 91 */
} /* Line: 91 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGetDirect_0() {
return bevp_pos;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() {
return bevp_instance;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGetDirect_0() {
return bevp_instance;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instance = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_instFieldNamesGet_0() {
return bevp_instFieldNames;
} /*method end*/
public BEC_2_9_4_ContainerList bem_instFieldNamesGetDirect_0() {
return bevp_instFieldNames;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instFieldNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instFieldNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lastidxGet_0() {
return bevp_lastidx;
} /*method end*/
public BEC_2_4_3_MathInt bem_lastidxGetDirect_0() {
return bevp_lastidx;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_lastidxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastidx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_lastidxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastidx = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 16, 16, 21, 22, 23, 24, 24, 24, 29, 30, 35, 35, 36, 36, 38, 38, 42, 42, 43, 43, 45, 45, 49, 50, 50, 54, 55, 55, 57, 61, 62, 62, 66, 67, 68, 68, 69, 69, 70, 72, 76, 77, 81, 82, 83, 83, 84, 84, 85, 85, 86, 91, 91, 91, 92, 91, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 34, 35, 36, 37, 38, 39, 44, 46, 54, 59, 60, 61, 63, 64, 70, 75, 76, 77, 79, 80, 84, 85, 86, 91, 93, 94, 96, 100, 101, 102, 111, 113, 114, 115, 116, 117, 118, 120, 123, 124, 135, 137, 138, 139, 140, 141, 142, 143, 144, 151, 154, 159, 160, 161, 170, 173, 176, 180, 184, 187, 190, 194, 198, 201, 204, 208, 212, 215, 218, 222};
/* BEGIN LINEINFO 
assign 1 16 27
new 0 16 27
assign 1 16 28
new 2 16 28
return 1 16 29
assign 1 21 34
new 0 21 34
assign 1 22 35
assign 1 23 36
fieldNamesGet 0 23 36
assign 1 24 37
sizeGet 0 24 37
assign 1 24 38
new 0 24 38
assign 1 24 39
subtract 1 24 39
assign 1 29 44
hasNextGet 0 29 44
assign 1 30 46
increment 0 30 46
assign 1 35 54
lesser 1 35 59
assign 1 36 60
new 0 36 60
return 1 36 61
assign 1 38 63
new 0 38 63
return 1 38 64
assign 1 42 70
lesserEquals 1 42 75
assign 1 43 76
new 0 43 76
return 1 43 77
assign 1 45 79
new 0 45 79
return 1 45 80
advance 0 49 84
assign 1 50 85
currentNameGet 0 50 85
return 1 50 86
assign 1 54 91
hasCurrentGet 0 54 91
assign 1 55 93
get 1 55 93
return 1 55 94
return 1 57 96
advance 0 61 100
assign 1 62 101
currentGet 0 62 101
return 1 62 102
assign 1 66 111
hasCurrentGet 0 66 111
assign 1 67 113
currentNameGet 0 67 113
assign 1 68 114
new 0 68 114
assign 1 68 115
add 1 68 115
assign 1 69 116
new 0 69 116
assign 1 69 117
invoke 2 69 117
return 1 70 118
return 1 72 120
advance 0 76 123
currentSet 1 77 124
assign 1 81 135
hasCurrentGet 0 81 135
assign 1 82 137
currentNameGet 0 82 137
assign 1 83 138
new 0 83 138
assign 1 83 139
add 1 83 139
assign 1 84 140
new 0 84 140
assign 1 84 141
new 1 84 141
assign 1 85 142
new 0 85 142
put 2 85 143
invoke 2 86 144
assign 1 91 151
new 0 91 151
assign 1 91 154
lesser 1 91 159
nextSet 1 92 160
incrementValue 0 91 161
return 1 0 170
return 1 0 173
assign 1 0 176
assign 1 0 180
return 1 0 184
return 1 0 187
assign 1 0 190
assign 1 0 194
return 1 0 198
return 1 0 201
assign 1 0 204
assign 1 0 208
return 1 0 212
return 1 0 215
assign 1 0 218
assign 1 0 222
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1747771860: return bem_classNameGet_0();
case 1441355720: return bem_posGet_0();
case -2039257540: return bem_tagGet_0();
case -1975328143: return bem_once_0();
case 721422711: return bem_currentGet_0();
case 1210909683: return bem_hasNextGet_0();
case -1442113467: return bem_create_0();
case 767177150: return bem_fieldNamesGet_0();
case -169902781: return bem_hasCurrentGet_0();
case 1505927918: return bem_serializeContents_0();
case 1779997640: return bem_advance_0();
case -1261413541: return bem_instFieldNamesGet_0();
case -304660926: return bem_sourceFileNameGet_0();
case -384445283: return bem_currentNameGet_0();
case 837494813: return bem_nextGet_0();
case -1755490473: return bem_instFieldNamesGetDirect_0();
case -558474950: return bem_lastidxGetDirect_0();
case -448869219: return bem_print_0();
case 583026473: return bem_toAny_0();
case 1091579640: return bem_new_0();
case -848592504: return bem_posGetDirect_0();
case -1616792218: return bem_deserializeClassNameGet_0();
case 858617719: return bem_instanceGet_0();
case 1062973207: return bem_serializationIteratorGet_0();
case 1287866350: return bem_copy_0();
case 546322415: return bem_echo_0();
case -470506305: return bem_serializeToString_0();
case 1017833055: return bem_many_0();
case -275053926: return bem_fieldIteratorGet_0();
case 1138449181: return bem_lastidxGet_0();
case 1530383857: return bem_nextNameGet_0();
case -497450892: return bem_hashGet_0();
case 1884049010: return bem_toString_0();
case -1100398933: return bem_instanceGetDirect_0();
case -926676223: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -13945303: return bem_defined_1(bevd_0);
case -778156991: return bem_new_1(bevd_0);
case -2044127077: return bem_posSetDirect_1(bevd_0);
case -1369944393: return bem_posSet_1(bevd_0);
case -1916951160: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -396792969: return bem_otherType_1(bevd_0);
case -942274895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1587063872: return bem_nextSet_1(bevd_0);
case -2135311656: return bem_currentSet_1(bevd_0);
case -1634396383: return bem_instFieldNamesSetDirect_1(bevd_0);
case 2047213073: return bem_equals_1(bevd_0);
case 13577034: return bem_def_1(bevd_0);
case 1011958071: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1829756344: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 205081622: return bem_sameObject_1(bevd_0);
case -1732969657: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -413404846: return bem_instFieldNamesSet_1(bevd_0);
case -1680819360: return bem_undefined_1(bevd_0);
case 38080717: return bem_undef_1(bevd_0);
case -60820913: return bem_lastidxSetDirect_1(bevd_0);
case 293257169: return bem_instanceSetDirect_1(bevd_0);
case 745295406: return bem_sameClass_1(bevd_0);
case -1507083548: return bem_otherClass_1(bevd_0);
case -1132198926: return bem_sameType_1(bevd_0);
case -456915093: return bem_lastidxSet_1(bevd_0);
case -149148452: return bem_copyTo_1(bevd_0);
case -8971619: return bem_instanceSet_1(bevd_0);
case -1396938224: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 276198978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -931383679: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 62716626: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513618976: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1047719554: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -927828157: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1041543114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1611590654: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemObjectFieldIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_19_SystemObjectFieldIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;
}
}
}
