namespace be {
/* IO:File: source/base/OpiFc.be */
public sealed class BEC_2_6_19_SystemObjectFieldIterator : BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemObjectFieldIterator() { }
static BEC_2_6_19_SystemObjectFieldIterator() { }
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x46,0x69,0x65,0x6C,0x64,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemObjectFieldIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x70,0x69,0x46,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0 = {0x47,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
private static byte[] bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1 = {0x53,0x65,0x74,0x44,0x69,0x72,0x65,0x63,0x74};
public static new BEC_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;

public static new BET_2_6_19_SystemObjectFieldIterator bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_6_6_SystemObject bevp_instance;
public BEC_2_9_4_ContainerList bevp_instFieldNames;
public BEC_2_4_3_MathInt bevp_lastidx;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_1(BEC_2_6_6_SystemObject beva__instance) {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_ta_ph = bem_new_2(beva__instance, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_new_2(BEC_2_6_6_SystemObject beva__instance, BEC_2_5_4_LogicBool beva_forceFirstSlot) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_instance = beva__instance;
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevp_instance.bemd_0(-921473949);
bevt_0_ta_ph = bevp_instFieldNames.bem_sizeGet_0();
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_lastidx = bevt_0_ta_ph.bem_subtract_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_advance_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 29*/ {
bevp_pos = bevp_pos.bem_increment_0();
} /* Line: 30*/
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_pos.bevi_int < bevp_lastidx.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 35*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 36*/
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_pos.bevi_int <= bevp_lastidx.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 43*/
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nextNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bem_advance_0();
bevt_0_ta_ph = bem_currentNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_currentNameGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_1_ta_ph = bevp_instFieldNames.bem_get_1(bevp_pos);
return (BEC_2_4_6_TextString) bevt_1_ta_ph;
} /* Line: 55*/
return null;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bem_advance_0();
bevt_0_ta_ph = bem_currentGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentGet_0() {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_9_4_ContainerList bevt_2_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 66*/ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_6_19_SystemObjectFieldIterator_bels_0));
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_ta_ph);
bevt_2_ta_ph = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_res = bevp_instance.bemd_2(878556511, bevl_invokeName, bevt_2_ta_ph);
return bevl_res;
} /* Line: 70*/
return null;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
bem_advance_0();
bem_currentSet_1(beva_value);
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_currentSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_6_TextString bevl_currentName = null;
BEC_2_4_6_TextString bevl_invokeName = null;
BEC_2_9_4_ContainerList bevl_args = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = bem_hasCurrentGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 81*/ {
bevl_currentName = bem_currentNameGet_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_6_19_SystemObjectFieldIterator_bels_1));
bevl_invokeName = bevl_currentName.bem_add_1(bevt_1_ta_ph);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_args = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_args.bem_put_2(bevt_3_ta_ph, beva_value);
bevp_instance.bemd_2(878556511, bevl_invokeName, bevl_args);
} /* Line: 86*/
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 91*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 91*/ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 91*/
 else /* Line: 91*/ {
break;
} /* Line: 91*/
} /* Line: 91*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGetDirect_0() {
return bevp_pos;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGet_0() {
return bevp_instance;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instanceGetDirect_0() {
return bevp_instance;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_instance = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instanceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_instance = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_instFieldNamesGet_0() {
return bevp_instFieldNames;
} /*method end*/
public BEC_2_9_4_ContainerList bem_instFieldNamesGetDirect_0() {
return bevp_instFieldNames;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instFieldNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_instFieldNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_instFieldNames = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_lastidxGet_0() {
return bevp_lastidx;
} /*method end*/
public BEC_2_4_3_MathInt bem_lastidxGetDirect_0() {
return bevp_lastidx;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_lastidxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lastidx = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_lastidxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lastidx = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 16, 16, 21, 22, 23, 24, 24, 24, 29, 30, 35, 35, 36, 36, 38, 38, 42, 42, 43, 43, 45, 45, 49, 50, 50, 54, 55, 55, 57, 61, 62, 62, 66, 67, 68, 68, 69, 69, 70, 72, 76, 77, 81, 82, 83, 83, 84, 84, 85, 85, 86, 91, 91, 91, 92, 91, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 31, 32, 33, 34, 35, 36, 41, 43, 51, 56, 57, 58, 60, 61, 67, 72, 73, 74, 76, 77, 81, 82, 83, 88, 90, 91, 93, 97, 98, 99, 108, 110, 111, 112, 113, 114, 115, 117, 120, 121, 132, 134, 135, 136, 137, 138, 139, 140, 141, 148, 151, 156, 157, 158, 167, 170, 173, 177, 181, 184, 187, 191, 195, 198, 201, 205, 209, 212, 215, 219};
/* BEGIN LINEINFO 
assign 1 16 24
new 0 16 24
assign 1 16 25
new 2 16 25
return 1 16 26
assign 1 21 31
new 0 21 31
assign 1 22 32
assign 1 23 33
fieldNamesGet 0 23 33
assign 1 24 34
sizeGet 0 24 34
assign 1 24 35
new 0 24 35
assign 1 24 36
subtract 1 24 36
assign 1 29 41
hasNextGet 0 29 41
assign 1 30 43
increment 0 30 43
assign 1 35 51
lesser 1 35 56
assign 1 36 57
new 0 36 57
return 1 36 58
assign 1 38 60
new 0 38 60
return 1 38 61
assign 1 42 67
lesserEquals 1 42 72
assign 1 43 73
new 0 43 73
return 1 43 74
assign 1 45 76
new 0 45 76
return 1 45 77
advance 0 49 81
assign 1 50 82
currentNameGet 0 50 82
return 1 50 83
assign 1 54 88
hasCurrentGet 0 54 88
assign 1 55 90
get 1 55 90
return 1 55 91
return 1 57 93
advance 0 61 97
assign 1 62 98
currentGet 0 62 98
return 1 62 99
assign 1 66 108
hasCurrentGet 0 66 108
assign 1 67 110
currentNameGet 0 67 110
assign 1 68 111
new 0 68 111
assign 1 68 112
add 1 68 112
assign 1 69 113
new 0 69 113
assign 1 69 114
invoke 2 69 114
return 1 70 115
return 1 72 117
advance 0 76 120
currentSet 1 77 121
assign 1 81 132
hasCurrentGet 0 81 132
assign 1 82 134
currentNameGet 0 82 134
assign 1 83 135
new 0 83 135
assign 1 83 136
add 1 83 136
assign 1 84 137
new 0 84 137
assign 1 84 138
new 1 84 138
assign 1 85 139
new 0 85 139
put 2 85 140
invoke 2 86 141
assign 1 91 148
new 0 91 148
assign 1 91 151
lesser 1 91 156
nextSet 1 92 157
incrementValue 0 91 158
return 1 0 167
return 1 0 170
assign 1 0 173
assign 1 0 177
return 1 0 181
return 1 0 184
assign 1 0 187
assign 1 0 191
return 1 0 195
return 1 0 198
assign 1 0 201
assign 1 0 205
return 1 0 209
return 1 0 212
assign 1 0 215
assign 1 0 219
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1975680234: return bem_hasNextGet_0();
case 1431238446: return bem_instanceGet_0();
case -356617806: return bem_currentGet_0();
case -1363819567: return bem_new_0();
case -467511392: return bem_toString_0();
case -1420109489: return bem_instanceGetDirect_0();
case -1180998553: return bem_nextNameGet_0();
case -793241295: return bem_iteratorGet_0();
case 111922109: return bem_hasCurrentGet_0();
case -526693302: return bem_advance_0();
case 1890854002: return bem_tagGet_0();
case -447432319: return bem_many_0();
case -105946774: return bem_serializeToString_0();
case 1862898487: return bem_posGet_0();
case -1747485282: return bem_lastidxGetDirect_0();
case -1760538533: return bem_classNameGet_0();
case -1323898541: return bem_toAny_0();
case -1188922735: return bem_echo_0();
case 1092105192: return bem_hashGet_0();
case 1652521523: return bem_serializeContents_0();
case 1319388306: return bem_copy_0();
case -1533288301: return bem_currentNameGet_0();
case 906941538: return bem_posGetDirect_0();
case -921473949: return bem_fieldNamesGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case 584602695: return bem_instFieldNamesGet_0();
case -1738799246: return bem_instFieldNamesGetDirect_0();
case -481234421: return bem_lastidxGet_0();
case 1597327951: return bem_create_0();
case 7254011: return bem_fieldIteratorGet_0();
case 895193825: return bem_once_0();
case -1387831588: return bem_print_0();
case 371157924: return bem_sourceFileNameGet_0();
case -39165288: return bem_deserializeClassNameGet_0();
case 409355098: return bem_nextGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -153377347: return bem_instanceSetDirect_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 1051453829: return bem_instanceSet_1(bevd_0);
case 1929898803: return bem_new_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1730109169: return bem_nextSet_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1398656393: return bem_lastidxSetDirect_1(bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case 1943264841: return bem_instFieldNamesSetDirect_1(bevd_0);
case 581665393: return bem_lastidxSet_1(bevd_0);
case -104906255: return bem_currentSet_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case -1089132387: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -898917744: return bem_posSetDirect_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case 104385023: return bem_posSet_1(bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 491826752: return bem_instFieldNamesSet_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1973904590: return bem_new_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemObjectFieldIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_19_SystemObjectFieldIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_19_SystemObjectFieldIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst = (BEC_2_6_19_SystemObjectFieldIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_19_SystemObjectFieldIterator.bece_BEC_2_6_19_SystemObjectFieldIterator_bevs_type;
}
}
}
