namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_3_6_6_4_SystemThreadLock : BEC_2_6_6_SystemObject {
public BEC_3_6_6_4_SystemThreadLock() { }
static BEC_3_6_6_4_SystemThreadLock() { }
private static byte[] becc_BEC_3_6_6_4_SystemThreadLock_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4C,0x6F,0x63,0x6B};
private static byte[] becc_BEC_3_6_6_4_SystemThreadLock_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_4_SystemThreadLock bece_BEC_3_6_6_4_SystemThreadLock_bevs_inst;

public static new BET_3_6_6_4_SystemThreadLock bece_BEC_3_6_6_4_SystemThreadLock_bevs_type;

public BEC_2_5_4_LogicBool bem_lock_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

    Monitor.Enter(this); //yes, monitor is reentrant
    bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_unlock_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

    Monitor.Exit(this);
    bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {838, 838, 857, 857};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 28, 29};
/* BEGIN LINEINFO 
assign 1 838 21
new 0 838 21
return 1 838 22
assign 1 857 28
new 0 857 28
return 1 857 29
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1253246070: return bem_create_0();
case 1014225644: return bem_echo_0();
case -1882364243: return bem_many_0();
case -628560707: return bem_toAny_0();
case -2123848647: return bem_fieldNamesGet_0();
case 770834928: return bem_serializeContents_0();
case -795258431: return bem_lock_0();
case 1297175099: return bem_fieldIteratorGet_0();
case -753894116: return bem_new_0();
case -1074341902: return bem_print_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -1138072028: return bem_tagGet_0();
case 844225351: return bem_classNameGet_0();
case -2083934905: return bem_copy_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 80244442: return bem_toString_0();
case -2131387379: return bem_iteratorGet_0();
case -1625648722: return bem_once_0();
case -1194289304: return bem_serializeToString_0();
case -1989361192: return bem_unlock_0();
case 1165329653: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -636442813: return bem_def_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_6_6_4_SystemThreadLock_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_4_SystemThreadLock_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_4_SystemThreadLock();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_4_SystemThreadLock.bece_BEC_3_6_6_4_SystemThreadLock_bevs_inst = (BEC_3_6_6_4_SystemThreadLock) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_4_SystemThreadLock.bece_BEC_3_6_6_4_SystemThreadLock_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_4_SystemThreadLock.bece_BEC_3_6_6_4_SystemThreadLock_bevs_type;
}
}
}
