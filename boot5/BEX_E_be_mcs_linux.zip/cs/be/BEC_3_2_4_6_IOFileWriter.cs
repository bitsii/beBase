namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileWriter : BEC_2_2_6_IOWriter {
public BEC_3_2_4_6_IOFileWriter() { }
static BEC_3_2_4_6_IOFileWriter() { }
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_0 = {0x77,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_1 = {0x61,0x62};
public static new BEC_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;

public static new BET_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public virtual BEC_3_2_4_6_IOFileWriter bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_openTruncate_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_openAppend_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_open_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_open_1(BEC_2_4_6_TextString beva_mode) {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevl_append = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_fhpatha = bevp_path.bem_toString_0();
/* Line: 428*/ {
if (beva_mode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 429*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bevt_2_ta_ph = beva_mode.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 429*/
 else /* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 429*/ {
bevl_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 430*/
 else /* Line: 431*/ {
bevl_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 432*/
} /* Line: 429*/

      if (this.bevi_os == null) {
        string bevls_spath = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        if (bevl_append.bevi_bool) {
            this.bevi_os = new FileStream(bevls_spath, FileMode.Append, FileAccess.Write, FileShare.Write, 64);
        } else {
            this.bevi_os = new FileStream(bevls_spath, FileMode.Create, FileAccess.Write, FileShare.Write, 64);
        }
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {388, 389, 389, 393, 393, 397, 397, 401, 401, 412, 429, 429, 429, 429, 0, 0, 0, 430, 432, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 27, 28, 33, 34, 39, 40, 56, 58, 63, 64, 65, 67, 70, 74, 77, 80, 96, 99, 102, 106};
/* BEGIN LINEINFO 
assign 1 388 20
new 0 388 20
assign 1 389 21
new 1 389 21
pathSet 1 389 22
assign 1 393 27
new 0 393 27
open 1 393 28
assign 1 397 33
new 0 397 33
open 1 397 34
assign 1 401 39
new 0 401 39
open 1 401 40
assign 1 412 56
toString 0 412 56
assign 1 429 58
def 1 429 63
assign 1 429 64
new 0 429 64
assign 1 429 65
equals 1 429 65
assign 1 0 67
assign 1 0 70
assign 1 0 74
assign 1 430 77
new 0 430 77
assign 1 432 80
new 0 432 80
return 1 0 96
return 1 0 99
assign 1 0 102
assign 1 0 106
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1890854002: return bem_tagGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -1371430204: return bem_pathGet_0();
case 7254011: return bem_fieldIteratorGet_0();
case 286844024: return bem_isClosedGetDirect_0();
case 895193825: return bem_once_0();
case 212584225: return bem_open_0();
case 622682430: return bem_isClosedGet_0();
case -1469993846: return bem_close_0();
case 102443066: return bem_pathGetDirect_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -793241295: return bem_iteratorGet_0();
case 1319388306: return bem_copy_0();
case -447432319: return bem_many_0();
case 1652521523: return bem_serializeContents_0();
case 371157924: return bem_sourceFileNameGet_0();
case 2083021527: return bem_openAppend_0();
case -1760538533: return bem_classNameGet_0();
case -1188922735: return bem_echo_0();
case -1323898541: return bem_toAny_0();
case -1778971343: return bem_extOpen_0();
case -921473949: return bem_fieldNamesGet_0();
case 1597327951: return bem_create_0();
case 2003508561: return bem_vfileGet_0();
case 1616565966: return bem_openTruncate_0();
case -1363819567: return bem_new_0();
case -105946774: return bem_serializeToString_0();
case -88974785: return bem_vfileGetDirect_0();
case -1387831588: return bem_print_0();
case -467511392: return bem_toString_0();
case 1092105192: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1488511778: return bem_otherType_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2059057942: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1504974059: return bem_pathSetDirect_1(bevd_0);
case 1100654917: return bem_isClosedSet_1(bevd_0);
case 1929898803: return bem_new_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -785601011: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case 1925094858: return bem_vfileSet_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -1290530871: return bem_vfileSetDirect_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -231846695: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case -1525807035: return bem_pathSet_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1556578029: return bem_isClosedSetDirect_1(bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileWriter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileWriter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_6_IOFileWriter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst = (BEC_3_2_4_6_IOFileWriter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_type;
}
}
}
