namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileWriter : BEC_2_2_6_IOWriter {
public BEC_3_2_4_6_IOFileWriter() { }
static BEC_3_2_4_6_IOFileWriter() { }
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileWriter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_0 = {0x77,0x62};
private static byte[] bece_BEC_3_2_4_6_IOFileWriter_bels_1 = {0x61,0x62};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileWriter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileWriter_bels_1, 2));
public static new BEC_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;

public static new BET_3_2_4_6_IOFileWriter bece_BEC_3_2_4_6_IOFileWriter_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public virtual BEC_3_2_4_6_IOFileWriter bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_openTruncate_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_openAppend_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_1));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_open_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_2_4_6_IOFileWriter_bels_0));
bem_open_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_open_1(BEC_2_4_6_TextString beva_mode) {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevl_append = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_fhpatha = bevp_path.bem_toString_0();
/* Line: 428*/ {
if (beva_mode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 429*/ {
bevt_3_ta_ph = bece_BEC_3_2_4_6_IOFileWriter_bevo_0;
bevt_2_ta_ph = beva_mode.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 429*/
 else /* Line: 429*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 429*/ {
bevl_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 430*/
 else /* Line: 431*/ {
bevl_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 432*/
} /* Line: 429*/

      if (this.bevi_os == null) {
        string bevls_spath = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        if (bevl_append.bevi_bool) {
            this.bevi_os = new FileStream(bevls_spath, FileMode.Append, FileAccess.Write, FileShare.Write, 64);
        } else {
            this.bevi_os = new FileStream(bevls_spath, FileMode.Create, FileAccess.Write, FileShare.Write, 64);
        }
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileWriter bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {388, 389, 389, 393, 393, 397, 397, 401, 401, 412, 429, 429, 429, 429, 0, 0, 0, 430, 432, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 28, 29, 34, 35, 40, 41, 57, 59, 64, 65, 66, 68, 71, 75, 78, 81, 97, 100, 103, 107};
/* BEGIN LINEINFO 
assign 1 388 21
new 0 388 21
assign 1 389 22
new 1 389 22
pathSet 1 389 23
assign 1 393 28
new 0 393 28
open 1 393 29
assign 1 397 34
new 0 397 34
open 1 397 35
assign 1 401 40
new 0 401 40
open 1 401 41
assign 1 412 57
toString 0 412 57
assign 1 429 59
def 1 429 64
assign 1 429 65
new 0 429 65
assign 1 429 66
equals 1 429 66
assign 1 0 68
assign 1 0 71
assign 1 0 75
assign 1 430 78
new 0 430 78
assign 1 432 81
new 0 432 81
return 1 0 97
return 1 0 100
assign 1 0 103
assign 1 0 107
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 119461913: return bem_tagGet_0();
case 1986846950: return bem_close_0();
case 281444821: return bem_fieldIteratorGet_0();
case -678541085: return bem_classNameGet_0();
case 665089720: return bem_pathGetDirect_0();
case 621895644: return bem_openAppend_0();
case -806099499: return bem_isClosedGetDirect_0();
case -1754478112: return bem_print_0();
case -2017009146: return bem_new_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -1005119995: return bem_many_0();
case -1475550710: return bem_create_0();
case -225870373: return bem_serializeToString_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 2045941275: return bem_iteratorGet_0();
case -744679096: return bem_fieldNamesGet_0();
case -1486279572: return bem_serializeContents_0();
case -1275325619: return bem_toString_0();
case 501088997: return bem_sourceFileNameGet_0();
case 1173023945: return bem_openTruncate_0();
case -194123929: return bem_vfileGetDirect_0();
case 2022064601: return bem_extOpen_0();
case 1575784889: return bem_vfileGet_0();
case -639297756: return bem_toAny_0();
case -545556484: return bem_once_0();
case 1166484122: return bem_isClosedGet_0();
case -1160702942: return bem_pathGet_0();
case 611702865: return bem_copy_0();
case -1583672278: return bem_echo_0();
case 353438806: return bem_open_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 509474695: return bem_sameObject_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case -1751182431: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case -1698900309: return bem_new_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -554175306: return bem_pathSet_1(bevd_0);
case 1961622357: return bem_vfileSetDirect_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case 1598599718: return bem_vfileSet_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case -1002509445: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 15953581: return bem_pathSetDirect_1(bevd_0);
case -2036968612: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case -1670055117: return bem_isClosedSet_1(bevd_0);
case -1625335738: return bem_isClosedSetDirect_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileWriter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileWriter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_6_IOFileWriter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst = (BEC_3_2_4_6_IOFileWriter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_6_IOFileWriter.bece_BEC_3_2_4_6_IOFileWriter_bevs_type;
}
}
}
