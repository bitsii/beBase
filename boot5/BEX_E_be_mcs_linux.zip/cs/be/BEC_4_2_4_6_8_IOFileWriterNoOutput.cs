namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_8_IOFileWriterNoOutput : BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_8_IOFileWriterNoOutput() { }
static BEC_4_2_4_6_8_IOFileWriterNoOutput() { }
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x4E,0x6F,0x4F,0x75,0x74,0x70,0x75,0x74};
private static byte[] becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;

public static new BET_4_2_4_6_8_IOFileWriterNoOutput bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;

public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_default_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_4_2_4_6_8_IOFileWriterNoOutput bem_writeIfPossible_1(BEC_2_6_6_SystemObject beva_str) {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_write_1(BEC_2_4_6_TextString beva_str) {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isClosedGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_open_0() {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_close_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {768, 777, 777};
public static new int[] bevs_smnlec
 = new int[] {16, 30, 31};
/* BEGIN LINEINFO 
assign 1 768 16
new 0 768 16
assign 1 777 30
new 0 777 30
return 1 777 31
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case -1749612006: return bem_vfileGetDirect_0();
case 925559139: return bem_close_0();
case -1076915155: return bem_serializeToString_0();
case 1834246217: return bem_classNameGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -487191921: return bem_default_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case -151747519: return bem_pathGet_0();
case 1541114762: return bem_openAppend_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case 2081363871: return bem_copy_0();
case -975498393: return bem_fieldNamesGet_0();
case 954703233: return bem_create_0();
case -893093197: return bem_toString_0();
case 1908183650: return bem_extOpen_0();
case 155723965: return bem_pathGetDirect_0();
case 397219271: return bem_vfileGet_0();
case 1947374815: return bem_open_0();
case -40905183: return bem_echo_0();
case -1805795806: return bem_isClosedGet_0();
case -125356968: return bem_isClosedGetDirect_0();
case -1653939165: return bem_iteratorGet_0();
case -1336530209: return bem_openTruncate_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -74273945: return bem_pathSet_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -120886279: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case 278832140: return bem_writeIfPossible_1(bevd_0);
case 1224708572: return bem_isClosedSet_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -1421462792: return bem_pathSetDirect_1(bevd_0);
case -1339687555: return bem_vfileSetDirect_1(bevd_0);
case 87576062: return bem_vfileSet_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 714792787: return bem_isClosedSetDirect_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 59504167: return bem_new_1(bevd_0);
case -487853278: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 1959927211: return bem_writeStringClose_1((BEC_2_4_6_TextString) bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_8_IOFileWriterNoOutput_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_8_IOFileWriterNoOutput();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst = (BEC_4_2_4_6_8_IOFileWriterNoOutput) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_type;
}
}
}
