namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_8_ContainerLinkedListIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_10_8_ContainerLinkedListIterator() { }
static BEC_3_9_10_8_ContainerLinkedListIterator() { }
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_3_9_10_8_ContainerLinkedListIterator bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst;

public static new BET_3_9_10_8_ContainerLinkedListIterator bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_list;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_currNode;
public BEC_2_5_4_LogicBool bevp_starting;
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_new_1(BEC_2_9_10_ContainerLinkedList beva_l) {
bevp_list = beva_l;
bevp_starting = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_containerGet_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 448 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 449 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 455 */ {
bevt_2_tmpany_phold = bevp_list.bem_firstNodeGet_0();
if (bevt_2_tmpany_phold == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /* Line: 457 */
 else  /* Line: 458 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 459 */
} /* Line: 456 */
if (bevp_currNode == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_7_tmpany_phold = bevp_currNode.bem_nextGet_0();
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 463 */
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_9_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_nxnode = (BEC_3_9_10_4_ContainerLinkedListNode) bem_nextNodeGet_0();
if (bevl_nxnode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevp_list.bem_addValue_1(beva_value);
bem_nextNodeGet_0();
} /* Line: 472 */
 else  /* Line: 473 */ {
bevl_nxnode.bem_heldSet_1(beva_value);
} /* Line: 474 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextNodeGet_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 480 */ {
bevp_starting = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 482 */
 else  /* Line: 483 */ {
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 485 */
} /* Line: 484 */
bevp_currNode = bevl_nxnode;
return bevp_currNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentNodeGet_0() {
return bevp_currNode;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva__currNode) {
bevp_starting = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva__currNode;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 502 */ {
return null;
} /* Line: 503 */
bevt_1_tmpany_phold = bevp_currNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 509 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 510 */
bevp_currNode.bem_heldSet_1(beva_x);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (bevp_starting.bevi_bool) /* Line: 518 */ {
bevp_starting = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 520 */
 else  /* Line: 521 */ {
if (bevp_currNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 523 */
} /* Line: 522 */
bevp_currNode = bevl_nxnode;
if (bevp_currNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 527 */ {
bevt_2_tmpany_phold = bevp_currNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 528 */
return bevp_currNode;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 534 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 534 */ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 534 */
 else  /* Line: 534 */ {
break;
} /* Line: 534 */
} /* Line: 534 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_listGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_listGetDirect_0() {
return bevp_list;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGet_0() {
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGetDirect_0() {
return bevp_currNode;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_currNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_currNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_startingGet_0() {
return bevp_starting;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startingGetDirect_0() {
return bevp_starting;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_startingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_startingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {436, 438, 444, 448, 448, 449, 449, 451, 451, 456, 456, 456, 457, 457, 459, 459, 462, 462, 0, 462, 462, 462, 0, 0, 463, 463, 465, 465, 469, 470, 470, 471, 472, 474, 481, 482, 484, 484, 485, 488, 489, 493, 497, 498, 502, 502, 503, 505, 505, 509, 509, 510, 510, 512, 513, 513, 519, 520, 522, 522, 523, 526, 527, 527, 528, 528, 530, 534, 534, 534, 535, 534, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 21, 27, 32, 33, 34, 36, 37, 51, 52, 57, 58, 59, 62, 63, 66, 71, 72, 75, 76, 81, 82, 85, 89, 90, 92, 93, 98, 99, 104, 105, 106, 109, 117, 118, 121, 126, 127, 130, 131, 134, 137, 138, 144, 149, 150, 152, 153, 159, 164, 165, 166, 168, 169, 170, 178, 179, 182, 187, 188, 191, 192, 197, 198, 199, 201, 206, 209, 214, 215, 216, 225, 228, 231, 235, 239, 242, 245, 249, 253, 256, 259, 263};
/* BEGIN LINEINFO 
assign 1 436 16
assign 1 438 17
new 0 438 17
return 1 444 21
assign 1 448 27
undef 1 448 32
assign 1 449 33
new 0 449 33
return 1 449 34
assign 1 451 36
new 0 451 36
return 1 451 37
assign 1 456 51
firstNodeGet 0 456 51
assign 1 456 52
undef 1 456 57
assign 1 457 58
new 0 457 58
return 1 457 59
assign 1 459 62
new 0 459 62
return 1 459 63
assign 1 462 66
undef 1 462 71
assign 1 0 72
assign 1 462 75
nextGet 0 462 75
assign 1 462 76
undef 1 462 81
assign 1 0 82
assign 1 0 85
assign 1 463 89
new 0 463 89
return 1 463 90
assign 1 465 92
new 0 465 92
return 1 465 93
assign 1 469 98
nextNodeGet 0 469 98
assign 1 470 99
undef 1 470 104
addValue 1 471 105
nextNodeGet 0 472 106
heldSet 1 474 109
assign 1 481 117
new 0 481 117
assign 1 482 118
firstNodeGet 0 482 118
assign 1 484 121
def 1 484 126
assign 1 485 127
nextGet 0 485 127
assign 1 488 130
return 1 489 131
return 1 493 134
assign 1 497 137
new 0 497 137
assign 1 498 138
assign 1 502 144
undef 1 502 149
return 1 503 150
assign 1 505 152
heldGet 0 505 152
return 1 505 153
assign 1 509 159
undef 1 509 164
assign 1 510 165
new 0 510 165
return 1 510 166
heldSet 1 512 168
assign 1 513 169
new 0 513 169
return 1 513 170
assign 1 519 178
new 0 519 178
assign 1 520 179
firstNodeGet 0 520 179
assign 1 522 182
def 1 522 187
assign 1 523 188
nextGet 0 523 188
assign 1 526 191
assign 1 527 192
def 1 527 197
assign 1 528 198
heldGet 0 528 198
return 1 528 199
return 1 530 201
assign 1 534 206
new 0 534 206
assign 1 534 209
lesser 1 534 214
nextSet 1 535 215
incrementValue 0 534 216
return 1 0 225
return 1 0 228
assign 1 0 231
assign 1 0 235
return 1 0 239
return 1 0 242
assign 1 0 245
assign 1 0 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1453867968: return bem_hasNextGet_0();
case -2129039241: return bem_currentNodeGet_0();
case 330207183: return bem_once_0();
case 1610207827: return bem_serializeToString_0();
case -512259678: return bem_many_0();
case 722156191: return bem_create_0();
case -365418091: return bem_nextNodeGet_0();
case -2133796658: return bem_startingGet_0();
case 441719677: return bem_hashGet_0();
case -751296258: return bem_toString_0();
case 701763907: return bem_new_0();
case -796966532: return bem_print_0();
case -196471174: return bem_toAny_0();
case 561389448: return bem_copy_0();
case 476157961: return bem_containerGet_0();
case -1276763041: return bem_currNodeGetDirect_0();
case -1567151917: return bem_currNodeGet_0();
case 1280430641: return bem_deserializeClassNameGet_0();
case 1875242997: return bem_currentGet_0();
case 1003136183: return bem_startingGetDirect_0();
case -2127113784: return bem_sourceFileNameGet_0();
case 1682310649: return bem_listGetDirect_0();
case 70409796: return bem_fieldIteratorGet_0();
case -1612673222: return bem_echo_0();
case -808549585: return bem_classNameGet_0();
case -627661593: return bem_serializationIteratorGet_0();
case 1569839774: return bem_listGet_0();
case -1608052766: return bem_hasCurrentGet_0();
case -746055719: return bem_nextGet_0();
case 73901351: return bem_fieldNamesGet_0();
case -1391094119: return bem_tagGet_0();
case -374298812: return bem_iteratorGet_0();
case 2049921022: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 803653343: return bem_otherClass_1(bevd_0);
case 680756917: return bem_defined_1(bevd_0);
case -191286971: return bem_def_1(bevd_0);
case 1649757588: return bem_sameObject_1(bevd_0);
case 354506797: return bem_startingSetDirect_1(bevd_0);
case -1307569551: return bem_startingSet_1(bevd_0);
case 282098674: return bem_listSetDirect_1(bevd_0);
case -1934236484: return bem_sameType_1(bevd_0);
case 198920865: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1645946581: return bem_notEquals_1(bevd_0);
case -772740554: return bem_currNodeSetDirect_1(bevd_0);
case -1380437617: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1110748051: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -610985228: return bem_currentNodeSet_1(bevd_0);
case 1587984688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1197345309: return bem_otherType_1(bevd_0);
case 538498706: return bem_currNodeSet_1(bevd_0);
case -1668696125: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1802140760: return bem_currentSet_1(bevd_0);
case 1426349559: return bem_listSet_1(bevd_0);
case 1381682421: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 788956945: return bem_undefined_1(bevd_0);
case -1272706644: return bem_copyTo_1(bevd_0);
case 1320952802: return bem_sameClass_1(bevd_0);
case 463890253: return bem_undef_1(bevd_0);
case 725850689: return bem_equals_1(bevd_0);
case -1729040748: return bem_nextSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1094925459: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1806210068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2137630710: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 235947300: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1242672538: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2053867671: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1365336246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_10_8_ContainerLinkedListIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst = (BEC_3_9_10_8_ContainerLinkedListIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_type;
}
}
}
