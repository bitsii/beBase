namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_3_9_10_8_ContainerLinkedListIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_10_8_ContainerLinkedListIterator() { }
static BEC_3_9_10_8_ContainerLinkedListIterator() { }
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_3_9_10_8_ContainerLinkedListIterator bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst;

public static new BET_3_9_10_8_ContainerLinkedListIterator bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_list;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_currNode;
public BEC_2_5_4_LogicBool bevp_starting;
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_new_1(BEC_2_9_10_ContainerLinkedList beva_l) {
bevp_list = beva_l;
bevp_starting = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_containerGet_0() {
return bevp_list;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 449*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 450*/
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
if (bevp_starting.bevi_bool)/* Line: 456*/ {
bevt_2_ta_ph = bevp_list.bem_firstNodeGet_0();
if (bevt_2_ta_ph == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 458*/
 else /* Line: 459*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 460*/
} /* Line: 457*/
if (bevp_currNode == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 463*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 463*/ {
bevt_7_ta_ph = bevp_currNode.bem_nextGet_0();
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 463*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 463*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 463*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 463*/ {
bevt_8_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 464*/
bevt_9_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_9_ta_ph;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_nxnode = (BEC_3_9_10_4_ContainerLinkedListNode) bem_nextNodeGet_0();
if (bevl_nxnode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 471*/ {
bevp_list.bem_addValue_1(beva_value);
bem_nextNodeGet_0();
} /* Line: 473*/
 else /* Line: 474*/ {
bevl_nxnode.bem_heldSet_1(beva_value);
} /* Line: 475*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextNodeGet_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_starting.bevi_bool)/* Line: 481*/ {
bevp_starting = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 483*/
 else /* Line: 484*/ {
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 485*/ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 486*/
} /* Line: 485*/
bevp_currNode = bevl_nxnode;
return bevp_currNode;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentNodeGet_0() {
return bevp_currNode;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_currentNodeSet_1(BEC_2_6_6_SystemObject beva__currNode) {
bevp_starting = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva__currNode;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 503*/ {
return null;
} /* Line: 504*/
bevt_1_ta_ph = bevp_currNode.bem_heldGet_0();
return bevt_1_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 510*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 511*/
bevp_currNode.bem_heldSet_1(beva_x);
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nxnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_starting.bevi_bool)/* Line: 519*/ {
bevp_starting = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nxnode = bevp_list.bem_firstNodeGet_0();
} /* Line: 521*/
 else /* Line: 522*/ {
if (bevp_currNode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 523*/ {
bevl_nxnode = bevp_currNode.bem_nextGet_0();
} /* Line: 524*/
} /* Line: 523*/
bevp_currNode = bevl_nxnode;
if (bevp_currNode == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 528*/ {
bevt_2_ta_ph = bevp_currNode.bem_heldGet_0();
return bevt_2_ta_ph;
} /* Line: 529*/
return bevp_currNode;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 535*/ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 535*/ {
bem_nextSet_1(null);
bevl_mi.bevi_int++;
} /* Line: 535*/
 else /* Line: 535*/ {
break;
} /* Line: 535*/
} /* Line: 535*/
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_listGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_listGetDirect_0() {
return bevp_list;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_list = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGet_0() {
return bevp_currNode;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_currNodeGetDirect_0() {
return bevp_currNode;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_currNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_currNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_currNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_startingGet_0() {
return bevp_starting;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startingGetDirect_0() {
return bevp_starting;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_startingSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_10_8_ContainerLinkedListIterator bem_startingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_starting = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {437, 439, 445, 449, 449, 450, 450, 452, 452, 457, 457, 457, 458, 458, 460, 460, 463, 463, 0, 463, 463, 463, 0, 0, 464, 464, 466, 466, 470, 471, 471, 472, 473, 475, 482, 483, 485, 485, 486, 489, 490, 494, 498, 499, 503, 503, 504, 506, 506, 510, 510, 511, 511, 513, 514, 514, 520, 521, 523, 523, 524, 527, 528, 528, 529, 529, 531, 535, 535, 535, 536, 535, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 21, 27, 32, 33, 34, 36, 37, 51, 52, 57, 58, 59, 62, 63, 66, 71, 72, 75, 76, 81, 82, 85, 89, 90, 92, 93, 98, 99, 104, 105, 106, 109, 117, 118, 121, 126, 127, 130, 131, 134, 137, 138, 144, 149, 150, 152, 153, 159, 164, 165, 166, 168, 169, 170, 178, 179, 182, 187, 188, 191, 192, 197, 198, 199, 201, 206, 209, 214, 215, 216, 225, 228, 231, 235, 239, 242, 245, 249, 253, 256, 259, 263};
/* BEGIN LINEINFO 
assign 1 437 16
assign 1 439 17
new 0 439 17
return 1 445 21
assign 1 449 27
undef 1 449 32
assign 1 450 33
new 0 450 33
return 1 450 34
assign 1 452 36
new 0 452 36
return 1 452 37
assign 1 457 51
firstNodeGet 0 457 51
assign 1 457 52
undef 1 457 57
assign 1 458 58
new 0 458 58
return 1 458 59
assign 1 460 62
new 0 460 62
return 1 460 63
assign 1 463 66
undef 1 463 71
assign 1 0 72
assign 1 463 75
nextGet 0 463 75
assign 1 463 76
undef 1 463 81
assign 1 0 82
assign 1 0 85
assign 1 464 89
new 0 464 89
return 1 464 90
assign 1 466 92
new 0 466 92
return 1 466 93
assign 1 470 98
nextNodeGet 0 470 98
assign 1 471 99
undef 1 471 104
addValue 1 472 105
nextNodeGet 0 473 106
heldSet 1 475 109
assign 1 482 117
new 0 482 117
assign 1 483 118
firstNodeGet 0 483 118
assign 1 485 121
def 1 485 126
assign 1 486 127
nextGet 0 486 127
assign 1 489 130
return 1 490 131
return 1 494 134
assign 1 498 137
new 0 498 137
assign 1 499 138
assign 1 503 144
undef 1 503 149
return 1 504 150
assign 1 506 152
heldGet 0 506 152
return 1 506 153
assign 1 510 159
undef 1 510 164
assign 1 511 165
new 0 511 165
return 1 511 166
heldSet 1 513 168
assign 1 514 169
new 0 514 169
return 1 514 170
assign 1 520 178
new 0 520 178
assign 1 521 179
firstNodeGet 0 521 179
assign 1 523 182
def 1 523 187
assign 1 524 188
nextGet 0 524 188
assign 1 527 191
assign 1 528 192
def 1 528 197
assign 1 529 198
heldGet 0 529 198
return 1 529 199
return 1 531 201
assign 1 535 206
new 0 535 206
assign 1 535 209
lesser 1 535 214
nextSet 1 536 215
incrementValue 0 535 216
return 1 0 225
return 1 0 228
assign 1 0 231
assign 1 0 235
return 1 0 239
return 1 0 242
assign 1 0 245
assign 1 0 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 581391667: return bem_nextGet_0();
case -1204412075: return bem_hasCurrentGet_0();
case 769250352: return bem_listGet_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case -2066684560: return bem_startingGetDirect_0();
case 1741189688: return bem_listGetDirect_0();
case -1535878607: return bem_currentNodeGet_0();
case -1076915155: return bem_serializeToString_0();
case 1834246217: return bem_classNameGet_0();
case -489005731: return bem_startingGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1931705863: return bem_sourceFileNameGet_0();
case 1974442435: return bem_currNodeGet_0();
case -1605246562: return bem_currentGet_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case 2131881616: return bem_nextNodeGet_0();
case 2081363871: return bem_copy_0();
case -975498393: return bem_fieldNamesGet_0();
case -2102703130: return bem_containerGet_0();
case 954703233: return bem_create_0();
case -893093197: return bem_toString_0();
case -40905183: return bem_echo_0();
case -826596413: return bem_currNodeGetDirect_0();
case -211510432: return bem_hasNextGet_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2035828126: return bem_listSet_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1624894897: return bem_startingSetDirect_1(bevd_0);
case 59504167: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -289306022: return bem_currentNodeSet_1(bevd_0);
case -217126743: return bem_currNodeSetDirect_1(bevd_0);
case -1449154677: return bem_nextSet_1(bevd_0);
case 386533818: return bem_currentSet_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -1173854178: return bem_currNodeSet_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 631501284: return bem_startingSet_1(bevd_0);
case -1543465561: return bem_listSetDirect_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 1590900809: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_10_8_ContainerLinkedListIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_10_8_ContainerLinkedListIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst = (BEC_3_9_10_8_ContainerLinkedListIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_10_8_ContainerLinkedListIterator.bece_BEC_3_9_10_8_ContainerLinkedListIterator_bevs_type;
}
}
}
