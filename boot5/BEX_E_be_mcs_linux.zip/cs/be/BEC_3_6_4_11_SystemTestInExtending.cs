namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_11_SystemTestInExtending : BEC_3_6_4_10_SystemTestExtendable {
public BEC_3_6_4_11_SystemTestInExtending() { }
static BEC_3_6_4_11_SystemTestInExtending() { }
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x49,0x6E,0x45,0x78,0x74,0x65,0x6E,0x64,0x69,0x6E,0x67};
private static byte[] becc_BEC_3_6_4_11_SystemTestInExtending_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;

public static new BET_3_6_4_11_SystemTestInExtending bece_BEC_3_6_4_11_SystemTestInExtending_bevs_type;

public BEC_2_6_6_SystemObject bevp_prop2a;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_3_6_4_10_SystemTestExtendable bem_bcall_0() {
bevp_propa.bemd_0(-796966532);
return this;
} /*method end*/
public virtual BEC_3_6_4_11_SystemTestInExtending bem_ccall_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_prop2aGet_0() {
return bevp_prop2a;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prop2aGetDirect_0() {
return bevp_prop2a;
} /*method end*/
public virtual BEC_3_6_4_11_SystemTestInExtending bem_prop2aSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_4_11_SystemTestInExtending bem_prop2aSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prop2a = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {222, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 24, 27, 30, 34};
/* BEGIN LINEINFO 
print 0 222 17
return 1 0 24
return 1 0 27
assign 1 0 30
assign 1 0 34
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 424359144: return bem_bcall_0();
case 330207183: return bem_once_0();
case -374298812: return bem_iteratorGet_0();
case -808549585: return bem_classNameGet_0();
case -512259678: return bem_many_0();
case 392178751: return bem_acall_0();
case 1025944045: return bem_prop2aGetDirect_0();
case -796966532: return bem_print_0();
case -196471174: return bem_toAny_0();
case 701763907: return bem_new_0();
case 2049921022: return bem_serializeContents_0();
case 830917786: return bem_propbGetDirect_0();
case 977947116: return bem_propaGet_0();
case -1391094119: return bem_tagGet_0();
case 73901351: return bem_fieldNamesGet_0();
case 70409796: return bem_fieldIteratorGet_0();
case -627661593: return bem_serializationIteratorGet_0();
case 561389448: return bem_copy_0();
case 1280430641: return bem_deserializeClassNameGet_0();
case -927784910: return bem_propbGet_0();
case 1403215128: return bem_ccall_0();
case -1093731912: return bem_propaGetDirect_0();
case -751296258: return bem_toString_0();
case 1610207827: return bem_serializeToString_0();
case -1612673222: return bem_echo_0();
case -1721733866: return bem_prop2aGet_0();
case 722156191: return bem_create_0();
case -2127113784: return bem_sourceFileNameGet_0();
case 441719677: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 803653343: return bem_otherClass_1(bevd_0);
case 1404554541: return bem_propaSet_1(bevd_0);
case 680756917: return bem_defined_1(bevd_0);
case -191286971: return bem_def_1(bevd_0);
case -178830172: return bem_propaSetDirect_1(bevd_0);
case 1649757588: return bem_sameObject_1(bevd_0);
case -1647199848: return bem_prop2aSet_1(bevd_0);
case -1934236484: return bem_sameType_1(bevd_0);
case 1645946581: return bem_notEquals_1(bevd_0);
case -1380437617: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1110748051: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1587984688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1197345309: return bem_otherType_1(bevd_0);
case -1668696125: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 60214556: return bem_prop2aSetDirect_1(bevd_0);
case 416370635: return bem_propbSetDirect_1(bevd_0);
case 788956945: return bem_undefined_1(bevd_0);
case -593651580: return bem_propbSet_1(bevd_0);
case -1272706644: return bem_copyTo_1(bevd_0);
case 1320952802: return bem_sameClass_1(bevd_0);
case 463890253: return bem_undef_1(bevd_0);
case 725850689: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1094925459: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1806210068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2137630710: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 235947300: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1242672538: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2053867671: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1365336246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_6_4_11_SystemTestInExtending_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_11_SystemTestInExtending_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_4_11_SystemTestInExtending();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst = (BEC_3_6_4_11_SystemTestInExtending) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_4_11_SystemTestInExtending.bece_BEC_3_6_4_11_SystemTestInExtending_bevs_type;
}
}
}
