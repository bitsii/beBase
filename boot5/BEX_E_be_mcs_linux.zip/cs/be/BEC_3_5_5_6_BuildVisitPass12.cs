namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_6_BuildVisitPass12 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass12() { }
static BEC_3_5_5_6_BuildVisitPass12() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass12_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x32};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass12_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_1 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_2 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_5 = {0x47,0x45,0x54};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_6 = {0x5F,0x30};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_7 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_8 = {0x5F,0x31};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_9 = {0x53,0x45,0x54};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_10 = {0x43,0x61,0x6C,0x6C,0x20,0x68,0x65,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_11 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_12 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitPass12_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitPass12_bels_12, 64));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_13 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x74,0x72,0x79,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x70,0x72,0x6F,0x62,0x61,0x62,0x6C,0x79,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x65,0x78,0x69,0x73,0x74,0x2C,0x20,0x76,0x65,0x72,0x69,0x66,0x79,0x20,0x6E,0x61,0x6D,0x65,0x20,0x61,0x6E,0x64,0x20,0x75,0x73,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_14 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x66,0x6F,0x72,0x20,0x6E,0x65,0x77,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x69,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitPass12_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitPass12_bels_14, 52));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_15 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x6C,0x79,0x20,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x6E,0x65,0x77,0x2C,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20,0x6E,0x6F,0x74,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitPass12_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_16 = {0x5F};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_17 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_18 = {0x6F,0x6E,0x63,0x65,0x5F,0x30};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass12_bels_19 = {0x6D,0x61,0x6E,0x79,0x5F,0x30};
public static new BEC_3_5_5_6_BuildVisitPass12 bece_BEC_3_5_5_6_BuildVisitPass12_bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_classnp;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAccessor_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_myselfn = null;
BEC_2_6_6_SystemObject bevl_myself = null;
BEC_2_6_6_SystemObject bevl_mtdmyn = null;
BEC_2_6_6_SystemObject bevl_mtdmy = null;
BEC_2_6_6_SystemObject bevl_myparn = null;
BEC_2_6_6_SystemObject bevl_mybr = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_3_BuildVar bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevl_myselfn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_myselfn.bemd_1(1123008767, bevt_0_tmpany_phold);
bevl_myself = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass12_bels_0));
bevl_myself.bemd_1(1673152110, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1636902212, bevt_2_tmpany_phold);
bevl_myself.bemd_1(-1816477318, bevp_classnp);
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myself.bemd_1(1576812120, bevt_3_tmpany_phold);
bevl_myselfn.bemd_1(-641432356, bevl_myself);
bevl_mtdmyn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_4_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mtdmyn.bemd_1(1123008767, bevt_4_tmpany_phold);
bevl_mtdmy = (new BEC_2_5_6_BuildMethod()).bem_new_0();
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_mtdmy.bemd_1(302064000, bevt_5_tmpany_phold);
bevl_mtdmyn.bemd_1(-641432356, bevl_mtdmy);
bevl_myparn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_6_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevl_myparn.bemd_1(1123008767, bevt_6_tmpany_phold);
bevl_myparn.bemd_1(1990140510, bevl_myselfn);
bevl_mtdmyn.bemd_1(1990140510, bevl_myparn);
bevl_myselfn.bemd_0(904418505);
bevl_mybr = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_7_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_mybr.bemd_1(1123008767, bevt_7_tmpany_phold);
bevl_mtdmyn.bemd_1(1990140510, bevl_mybr);
bevt_8_tmpany_phold = (BEC_2_5_3_BuildVar) (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_mtdmy.bemd_1(1655634778, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevl_mtdmy.bemd_0(-259814340);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_9_tmpany_phold.bemd_1(1425696487, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_mtdmy.bemd_0(-259814340);
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_11_tmpany_phold.bemd_1(2037029693, bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bevl_mtdmy.bemd_0(-259814340);
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_13_tmpany_phold.bemd_1(1636902212, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevl_mtdmy.bemd_0(-259814340);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass12_bels_1));
bevt_16_tmpany_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_17_tmpany_phold);
bevt_15_tmpany_phold.bemd_1(-1816477318, bevt_16_tmpany_phold);
return bevl_mtdmyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getRetNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_6_6_SystemObject bevl_retnoden = null;
BEC_2_6_6_SystemObject bevl_retnode = null;
BEC_2_6_6_SystemObject bevl_sn = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevl_retnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_retnoden.bemd_1(1123008767, bevt_0_tmpany_phold);
bevl_retnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass12_bels_2));
bevl_retnode.bemd_1(1673152110, bevt_1_tmpany_phold);
bevl_retnoden.bemd_1(-641432356, bevl_retnode);
bevl_sn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_2_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_sn.bemd_1(1123008767, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass12_bels_3));
bevl_sn.bemd_1(-641432356, bevt_3_tmpany_phold);
bevl_retnoden.bemd_1(1990140510, bevl_sn);
return bevl_retnoden;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getAsNode_1(BEC_2_6_6_SystemObject beva_selfnode) {
BEC_2_6_6_SystemObject bevl_asnoden = null;
BEC_2_6_6_SystemObject bevl_asnode = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_asnoden = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_0_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_asnoden.bemd_1(1123008767, bevt_0_tmpany_phold);
bevl_asnode = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass12_bels_4));
bevl_asnode.bemd_1(1673152110, bevt_1_tmpany_phold);
bevl_asnoden.bemd_1(-641432356, bevl_asnode);
return bevl_asnoden;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_ia = null;
BEC_2_6_6_SystemObject bevl_tst = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ename = null;
BEC_2_6_6_SystemObject bevl_anode = null;
BEC_2_6_6_SystemObject bevl_rettnode = null;
BEC_2_6_6_SystemObject bevl_rin = null;
BEC_2_6_6_SystemObject bevl_sv = null;
BEC_2_6_6_SystemObject bevl_svn = null;
BEC_2_6_6_SystemObject bevl_svn2 = null;
BEC_2_6_6_SystemObject bevl_asn = null;
BEC_2_6_6_SystemObject bevl_newNp = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_c1 = null;
BEC_2_6_6_SystemObject bevl_bn = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_109_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_123_tmpany_phold = null;
BEC_2_4_6_TextString bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_127_tmpany_phold = null;
BEC_2_4_6_TextString bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_6_TextString bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_148_tmpany_phold = null;
BEC_2_4_6_TextString bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_155_tmpany_phold = null;
BEC_2_4_6_TextString bevt_156_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_157_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_4_6_TextString bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_174_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_175_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_176_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_177_tmpany_phold = null;
BEC_2_4_6_TextString bevt_178_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_179_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_180_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_182_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_183_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_184_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_185_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_186_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_187_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_188_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_189_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_190_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_191_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_192_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_195_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_196_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_197_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_198_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_199_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_200_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_201_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_202_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_203_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_204_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_205_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_13_tmpany_phold = beva_node.bem_containedGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_firstGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(2098347484);
bevl_ia = bevt_11_tmpany_phold.bemd_0(448589254);
bevt_14_tmpany_phold = bevl_ia.bemd_0(498738483);
bevt_15_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_14_tmpany_phold.bemd_1(1636902212, bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevl_ia.bemd_0(498738483);
bevt_16_tmpany_phold.bemd_1(-1816477318, bevp_classnp);
} /* Line: 80 */
 else  /* Line: 77 */ {
bevt_18_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_19_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_18_tmpany_phold.bevi_int == bevt_19_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_20_tmpany_phold = beva_node.bem_heldGet_0();
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_20_tmpany_phold.bemd_0(-525406659);
bevl_tst = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_22_tmpany_phold = beva_node.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-2100666041);
bevl_ii = bevt_21_tmpany_phold.bemd_0(466290922);
while (true)
 /* Line: 87 */ {
bevt_23_tmpany_phold = bevl_ii.bemd_0(-896397486);
if (bevt_23_tmpany_phold != null && bevt_23_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 87 */ {
bevt_24_tmpany_phold = bevl_ii.bemd_0(-1887743737);
bevl_i = bevt_24_tmpany_phold.bemd_0(498738483);
bevt_26_tmpany_phold = bevl_i.bemd_0(-585577712);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(-827921680);
bevl_tst.bemd_1(1673152110, bevt_25_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_6_BuildVisitPass12_bels_5));
bevl_tst.bemd_1(-1632327453, bevt_27_tmpany_phold);
bevl_tst.bemd_0(-1690034679);
bevl_ename = bevl_tst.bemd_0(-585577712);
bevt_29_tmpany_phold = bevl_tst.bemd_0(-585577712);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitPass12_bels_6));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(2070942174, bevt_30_tmpany_phold);
bevl_tst.bemd_1(1673152110, bevt_28_tmpany_phold);
bevt_31_tmpany_phold = bevl_i.bemd_0(10644838);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevt_35_tmpany_phold = beva_node.bem_heldGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(-23854572);
bevt_36_tmpany_phold = bevl_tst.bemd_0(-585577712);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bemd_1(-798387133, bevt_36_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(70212490);
if (bevt_32_tmpany_phold != null && bevt_32_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_32_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 94 */
 else  /* Line: 94 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 94 */ {
bevl_anode = bem_getAccessor_1(beva_node);
bevt_37_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_37_tmpany_phold.bemd_1(-76444608, bevl_i);
bevt_38_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_38_tmpany_phold.bemd_1(202667724, bevl_ename);
bevt_39_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_40_tmpany_phold = bevl_tst.bemd_0(-585577712);
bevt_39_tmpany_phold.bemd_1(1673152110, bevt_40_tmpany_phold);
bevt_41_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_42_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_41_tmpany_phold.bemd_1(-1236356142, bevt_42_tmpany_phold);
bevt_44_tmpany_phold = beva_node.bem_heldGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(-23854572);
bevt_46_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(-585577712);
bevt_43_tmpany_phold.bemd_2(-1422139163, bevt_45_tmpany_phold, bevl_anode);
bevt_48_tmpany_phold = beva_node.bem_heldGet_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_0(-1469928422);
bevt_47_tmpany_phold.bemd_1(1990140510, bevl_anode);
bevt_50_tmpany_phold = beva_node.bem_containedGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_lastGet_0();
bevt_49_tmpany_phold.bemd_1(1990140510, bevl_anode);
bevl_rettnode = bem_getRetNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(-66762763, beva_node);
bevt_51_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(1123008767, bevt_51_tmpany_phold);
bevt_53_tmpany_phold = bevl_i.bemd_0(-585577712);
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_0(-827921680);
bevl_rin.bemd_1(-641432356, bevt_52_tmpany_phold);
bevl_rettnode.bemd_1(1990140510, bevl_rin);
bevt_55_tmpany_phold = bevl_anode.bemd_0(2098347484);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(934916935);
bevt_54_tmpany_phold.bemd_1(1990140510, bevl_rettnode);
bevt_57_tmpany_phold = bevl_rettnode.bemd_0(2098347484);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(448589254);
bevt_56_tmpany_phold.bemd_1(1409999903, this);
bevl_rin.bemd_1(1409999903, this);
bevt_58_tmpany_phold = bevl_i.bemd_0(579701841);
if (bevt_58_tmpany_phold != null && bevt_58_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_58_tmpany_phold).bevi_bool) /* Line: 113 */ {
bevt_59_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_59_tmpany_phold.bemd_1(1655634778, bevl_i);
} /* Line: 114 */
 else  /* Line: 115 */ {
bevt_60_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_60_tmpany_phold.bemd_1(1655634778, null);
} /* Line: 116 */
} /* Line: 113 */
bevt_62_tmpany_phold = bevl_i.bemd_0(-585577712);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-827921680);
bevl_tst.bemd_1(1673152110, bevt_61_tmpany_phold);
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_6_BuildVisitPass12_bels_7));
bevl_tst.bemd_1(-1632327453, bevt_63_tmpany_phold);
bevl_tst.bemd_0(-1690034679);
bevl_ename = bevl_tst.bemd_0(-585577712);
bevt_65_tmpany_phold = bevl_tst.bemd_0(-585577712);
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitPass12_bels_8));
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_1(2070942174, bevt_66_tmpany_phold);
bevl_tst.bemd_1(1673152110, bevt_64_tmpany_phold);
bevt_67_tmpany_phold = bevl_i.bemd_0(10644838);
if (bevt_67_tmpany_phold != null && bevt_67_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_67_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevt_71_tmpany_phold = beva_node.bem_heldGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_0(-23854572);
bevt_72_tmpany_phold = bevl_tst.bemd_0(-585577712);
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bemd_1(-798387133, bevt_72_tmpany_phold);
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(70212490);
if (bevt_68_tmpany_phold != null && bevt_68_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_68_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
 else  /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 126 */ {
bevl_anode = bem_getAccessor_1(beva_node);
bevt_73_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_73_tmpany_phold.bemd_1(-76444608, bevl_i);
bevt_74_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_74_tmpany_phold.bemd_1(202667724, bevl_ename);
bevt_75_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_76_tmpany_phold = bevl_tst.bemd_0(-585577712);
bevt_75_tmpany_phold.bemd_1(1673152110, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_78_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_77_tmpany_phold.bemd_1(-1236356142, bevt_78_tmpany_phold);
bevt_80_tmpany_phold = beva_node.bem_heldGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bemd_0(-23854572);
bevt_82_tmpany_phold = bevl_anode.bemd_0(498738483);
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_0(-585577712);
bevt_79_tmpany_phold.bemd_2(-1422139163, bevt_81_tmpany_phold, bevl_anode);
bevt_84_tmpany_phold = beva_node.bem_heldGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_0(-1469928422);
bevt_83_tmpany_phold.bemd_1(1990140510, bevl_anode);
bevt_86_tmpany_phold = beva_node.bem_containedGet_0();
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_lastGet_0();
bevt_85_tmpany_phold.bemd_1(1990140510, bevl_anode);
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_6_BuildVisitPass12_bels_9));
bevl_sv = bevl_anode.bemd_2(-790353020, bevt_87_tmpany_phold, bevp_build);
bevt_88_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_sv.bemd_1(1576812120, bevt_88_tmpany_phold);
bevl_svn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_svn.bemd_1(-66762763, beva_node);
bevt_89_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn.bemd_1(1123008767, bevt_89_tmpany_phold);
bevl_svn.bemd_1(-641432356, bevl_sv);
bevt_91_tmpany_phold = bevl_anode.bemd_0(2098347484);
bevt_90_tmpany_phold = bevt_91_tmpany_phold.bemd_0(448589254);
bevt_90_tmpany_phold.bemd_1(1990140510, bevl_svn);
bevl_svn2 = (new BEC_2_5_4_BuildNode());
bevl_svn2.bemd_1(-66762763, beva_node);
bevt_92_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_svn2.bemd_1(1123008767, bevt_92_tmpany_phold);
bevl_svn2.bemd_1(-641432356, bevl_sv);
bevl_asn = bem_getAsNode_1(beva_node);
bevl_rin = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_rin.bemd_1(-66762763, beva_node);
bevt_93_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_rin.bemd_1(1123008767, bevt_93_tmpany_phold);
bevt_95_tmpany_phold = bevl_i.bemd_0(-585577712);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_0(-827921680);
bevl_rin.bemd_1(-641432356, bevt_94_tmpany_phold);
bevl_asn.bemd_1(1990140510, bevl_rin);
bevl_asn.bemd_1(1990140510, bevl_svn2);
bevt_97_tmpany_phold = bevl_anode.bemd_0(2098347484);
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bemd_0(934916935);
bevt_96_tmpany_phold.bemd_1(1990140510, bevl_asn);
bevl_svn.bemd_0(904418505);
bevl_rin.bemd_1(1409999903, this);
} /* Line: 160 */
} /* Line: 126 */
 else  /* Line: 87 */ {
break;
} /* Line: 87 */
} /* Line: 87 */
} /* Line: 87 */
 else  /* Line: 77 */ {
bevt_99_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_100_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_99_tmpany_phold.bevi_int == bevt_100_tmpany_phold.bevi_int) {
bevt_98_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_98_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_102_tmpany_phold = beva_node.bem_heldGet_0();
if (bevt_102_tmpany_phold == null) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 167 */ {
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_3_5_5_6_BuildVisitPass12_bels_10));
bevt_103_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_104_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_103_tmpany_phold);
} /* Line: 168 */
bevt_106_tmpany_phold = beva_node.bem_heldGet_0();
bevt_105_tmpany_phold = bevt_106_tmpany_phold.bemd_0(1586996261);
if (bevt_105_tmpany_phold != null && bevt_105_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_105_tmpany_phold).bevi_bool) /* Line: 170 */ {
bevt_109_tmpany_phold = beva_node.bem_heldGet_0();
bevt_108_tmpany_phold = bevt_109_tmpany_phold.bemd_0(-60895298);
if (bevt_108_tmpany_phold == null) {
bevt_107_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_107_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_107_tmpany_phold.bevi_bool) /* Line: 170 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 170 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 170 */
 else  /* Line: 170 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 170 */ {
bevt_110_tmpany_phold = beva_node.bem_containedGet_0();
bevl_newNp = bevt_110_tmpany_phold.bem_firstGet_0();
bevt_112_tmpany_phold = bevl_newNp.bemd_0(-1476823905);
bevt_113_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_111_tmpany_phold = bevt_112_tmpany_phold.bemd_1(1999045680, bevt_113_tmpany_phold);
if (bevt_111_tmpany_phold != null && bevt_111_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_111_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevt_115_tmpany_phold = bevl_newNp.bemd_0(-1476823905);
bevt_116_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(-170563302, bevt_116_tmpany_phold);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_114_tmpany_phold).bevi_bool) /* Line: 173 */ {
bevt_119_tmpany_phold = bevl_newNp.bemd_0(498738483);
bevt_118_tmpany_phold = bevt_119_tmpany_phold.bemd_0(-585577712);
bevt_120_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass12_bels_11));
bevt_117_tmpany_phold = bevt_118_tmpany_phold.bemd_1(-170563302, bevt_120_tmpany_phold);
if (bevt_117_tmpany_phold != null && bevt_117_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_117_tmpany_phold).bevi_bool) /* Line: 173 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 173 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 173 */
 else  /* Line: 173 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 173 */ {
bevl_newNp = beva_node.bem_secondGet_0();
bevt_122_tmpany_phold = bevl_newNp.bemd_0(-1476823905);
bevt_123_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevt_121_tmpany_phold = bevt_122_tmpany_phold.bemd_1(1999045680, bevt_123_tmpany_phold);
if (bevt_121_tmpany_phold != null && bevt_121_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_121_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevt_125_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass12_bevo_0;
bevt_126_tmpany_phold = bevl_newNp.bemd_0(247385301);
bevt_124_tmpany_phold = bevt_125_tmpany_phold.bem_add_1(bevt_126_tmpany_phold);
bevt_124_tmpany_phold.bem_print_0();
bevt_128_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(131, bece_BEC_3_5_5_6_BuildVisitPass12_bels_13));
bevt_127_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_128_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_127_tmpany_phold);
} /* Line: 177 */
} /* Line: 175 */
 else  /* Line: 179 */ {
bevt_130_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass12_bevo_1;
bevt_131_tmpany_phold = bevl_newNp.bemd_0(247385301);
bevt_129_tmpany_phold = bevt_130_tmpany_phold.bem_add_1(bevt_131_tmpany_phold);
bevt_129_tmpany_phold.bem_print_0();
bevt_133_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_3_5_5_6_BuildVisitPass12_bels_15));
bevt_132_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_133_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_132_tmpany_phold);
} /* Line: 181 */
} /* Line: 173 */
bevt_134_tmpany_phold = beva_node.bem_heldGet_0();
bevt_135_tmpany_phold = bevl_newNp.bemd_0(498738483);
bevt_134_tmpany_phold.bemd_1(-1481920972, bevt_135_tmpany_phold);
bevl_newNp.bemd_0(23661901);
} /* Line: 185 */
bevt_136_tmpany_phold = beva_node.bem_heldGet_0();
bevt_139_tmpany_phold = beva_node.bem_containedGet_0();
bevt_138_tmpany_phold = bevt_139_tmpany_phold.bem_lengthGet_0();
bevt_140_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass12_bevo_2;
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bem_subtract_1(bevt_140_tmpany_phold);
bevt_136_tmpany_phold.bemd_1(-1236356142, bevt_137_tmpany_phold);
bevt_141_tmpany_phold = beva_node.bem_heldGet_0();
bevt_143_tmpany_phold = beva_node.bem_heldGet_0();
bevt_142_tmpany_phold = bevt_143_tmpany_phold.bemd_0(-585577712);
bevt_141_tmpany_phold.bemd_1(202667724, bevt_142_tmpany_phold);
bevt_144_tmpany_phold = beva_node.bem_heldGet_0();
bevt_148_tmpany_phold = beva_node.bem_heldGet_0();
bevt_147_tmpany_phold = bevt_148_tmpany_phold.bemd_0(-585577712);
bevt_149_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_6_BuildVisitPass12_bels_16));
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_1(2070942174, bevt_149_tmpany_phold);
bevt_152_tmpany_phold = beva_node.bem_heldGet_0();
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_0(-1874026496);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(247385301);
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(2070942174, bevt_150_tmpany_phold);
bevt_144_tmpany_phold.bemd_1(1673152110, bevt_145_tmpany_phold);
bevt_155_tmpany_phold = beva_node.bem_heldGet_0();
bevt_154_tmpany_phold = bevt_155_tmpany_phold.bemd_0(394575160);
bevt_156_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass12_bels_17));
bevt_153_tmpany_phold = bevt_154_tmpany_phold.bemd_1(-170563302, bevt_156_tmpany_phold);
if (bevt_153_tmpany_phold != null && bevt_153_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_153_tmpany_phold).bevi_bool) /* Line: 190 */ {
bevt_157_tmpany_phold = beva_node.bem_containedGet_0();
bevl_c0 = bevt_157_tmpany_phold.bem_firstGet_0();
if (bevl_c0 == null) {
bevt_158_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_158_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_158_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_160_tmpany_phold = bevl_c0.bemd_0(-1476823905);
bevt_161_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_159_tmpany_phold = bevt_160_tmpany_phold.bemd_1(-170563302, bevt_161_tmpany_phold);
if (bevt_159_tmpany_phold != null && bevt_159_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_159_tmpany_phold).bevi_bool) /* Line: 192 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 192 */ {
bevt_163_tmpany_phold = bevl_c0.bemd_0(498738483);
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(1105615385);
bevt_162_tmpany_phold.bemd_0(-1178831757);
} /* Line: 193 */
bevt_164_tmpany_phold = beva_node.bem_containedGet_0();
bevl_c1 = bevt_164_tmpany_phold.bem_secondGet_0();
if (bevl_c1 == null) {
bevt_165_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_165_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 196 */ {
bevt_167_tmpany_phold = bevl_c1.bemd_0(-1476823905);
bevt_168_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bemd_1(-170563302, bevt_168_tmpany_phold);
if (bevt_166_tmpany_phold != null && bevt_166_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_166_tmpany_phold).bevi_bool) /* Line: 196 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 196 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 196 */
 else  /* Line: 196 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 196 */ {
bevt_171_tmpany_phold = bevl_c1.bemd_0(498738483);
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_0(-585577712);
bevt_172_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass12_bels_18));
bevt_169_tmpany_phold = bevt_170_tmpany_phold.bemd_1(-170563302, bevt_172_tmpany_phold);
if (bevt_169_tmpany_phold != null && bevt_169_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_169_tmpany_phold).bevi_bool) /* Line: 201 */ {
bevt_173_tmpany_phold = beva_node.bem_heldGet_0();
bevt_174_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_173_tmpany_phold.bemd_1(1187932885, bevt_174_tmpany_phold);
} /* Line: 202 */
bevt_177_tmpany_phold = bevl_c1.bemd_0(498738483);
bevt_176_tmpany_phold = bevt_177_tmpany_phold.bemd_0(-585577712);
bevt_178_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass12_bels_19));
bevt_175_tmpany_phold = bevt_176_tmpany_phold.bemd_1(-170563302, bevt_178_tmpany_phold);
if (bevt_175_tmpany_phold != null && bevt_175_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_175_tmpany_phold).bevi_bool) /* Line: 204 */ {
bevt_179_tmpany_phold = beva_node.bem_heldGet_0();
bevt_180_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_179_tmpany_phold.bemd_1(-1318753118, bevt_180_tmpany_phold);
} /* Line: 205 */
} /* Line: 204 */
} /* Line: 196 */
} /* Line: 190 */
 else  /* Line: 77 */ {
bevt_182_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_183_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_182_tmpany_phold.bevi_int == bevt_183_tmpany_phold.bevi_int) {
bevt_181_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_181_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_181_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevl_bn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_185_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_185_tmpany_phold == null) {
bevt_184_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_184_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_184_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevt_188_tmpany_phold = beva_node.bem_containedGet_0();
bevt_187_tmpany_phold = bevt_188_tmpany_phold.bem_lastGet_0();
if (bevt_187_tmpany_phold == null) {
bevt_186_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_186_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_186_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 211 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 211 */
 else  /* Line: 211 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 211 */ {
bevt_191_tmpany_phold = beva_node.bem_containedGet_0();
bevt_190_tmpany_phold = bevt_191_tmpany_phold.bem_lastGet_0();
bevt_189_tmpany_phold = bevt_190_tmpany_phold.bemd_0(-1479921011);
bevl_bn.bemd_1(630261677, bevt_189_tmpany_phold);
} /* Line: 212 */
 else  /* Line: 213 */ {
bevl_bn.bemd_1(-66762763, beva_node);
} /* Line: 214 */
bevt_192_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
bevl_bn.bemd_1(1123008767, bevt_192_tmpany_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_bn );
} /* Line: 217 */
 else  /* Line: 77 */ {
bevt_194_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_195_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_194_tmpany_phold.bevi_int == bevt_195_tmpany_phold.bevi_int) {
bevt_193_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_193_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_193_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevl_pn = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_197_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_197_tmpany_phold == null) {
bevt_196_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_196_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_196_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_200_tmpany_phold = beva_node.bem_containedGet_0();
bevt_199_tmpany_phold = bevt_200_tmpany_phold.bem_lastGet_0();
if (bevt_199_tmpany_phold == null) {
bevt_198_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_198_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_198_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_203_tmpany_phold = beva_node.bem_containedGet_0();
bevt_202_tmpany_phold = bevt_203_tmpany_phold.bem_lastGet_0();
bevt_201_tmpany_phold = bevt_202_tmpany_phold.bemd_0(-1479921011);
bevl_pn.bemd_1(630261677, bevt_201_tmpany_phold);
} /* Line: 221 */
 else  /* Line: 222 */ {
bevl_pn.bemd_1(-66762763, beva_node);
} /* Line: 223 */
bevt_204_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
bevl_pn.bemd_1(1123008767, bevt_204_tmpany_phold);
beva_node.bem_addValue_1((BEC_2_5_4_BuildNode) bevl_pn );
} /* Line: 226 */
} /* Line: 77 */
} /* Line: 77 */
} /* Line: 77 */
} /* Line: 77 */
bevt_205_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_205_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_classnpGet_0() {
return bevp_classnp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass12 bem_classnpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classnp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {21, 22, 22, 23, 24, 24, 25, 25, 26, 27, 27, 28, 29, 30, 30, 31, 32, 32, 33, 34, 35, 35, 36, 37, 38, 39, 40, 40, 41, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 46, 47, 51, 52, 52, 53, 54, 54, 55, 56, 57, 57, 58, 58, 59, 60, 64, 65, 65, 66, 67, 67, 68, 69, 77, 77, 77, 77, 78, 78, 78, 78, 79, 79, 79, 80, 80, 84, 84, 84, 84, 85, 85, 86, 87, 87, 87, 87, 88, 88, 89, 89, 89, 90, 90, 91, 92, 93, 93, 93, 93, 94, 94, 94, 94, 94, 94, 0, 0, 0, 96, 97, 97, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 101, 101, 102, 102, 102, 103, 103, 103, 104, 105, 106, 107, 107, 108, 108, 108, 109, 110, 110, 110, 111, 111, 111, 112, 113, 114, 114, 116, 116, 121, 121, 121, 122, 122, 123, 124, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 0, 0, 0, 128, 129, 129, 130, 130, 131, 131, 131, 132, 132, 132, 133, 133, 133, 133, 133, 134, 134, 134, 135, 135, 135, 137, 137, 138, 138, 139, 140, 141, 141, 142, 144, 144, 144, 145, 146, 147, 147, 148, 150, 151, 152, 153, 153, 154, 154, 154, 155, 156, 157, 157, 157, 159, 160, 166, 166, 166, 166, 167, 167, 167, 168, 168, 168, 170, 170, 170, 170, 170, 170, 0, 0, 0, 171, 171, 172, 172, 172, 173, 173, 173, 173, 173, 173, 173, 0, 0, 0, 174, 175, 175, 175, 176, 176, 176, 176, 177, 177, 177, 180, 180, 180, 180, 181, 181, 181, 184, 184, 184, 185, 187, 187, 187, 187, 187, 187, 188, 188, 188, 188, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 190, 190, 190, 190, 191, 191, 192, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 195, 195, 196, 196, 196, 196, 196, 0, 0, 0, 201, 201, 201, 201, 202, 202, 202, 204, 204, 204, 204, 205, 205, 205, 209, 209, 209, 209, 210, 211, 211, 211, 211, 211, 211, 211, 0, 0, 0, 212, 212, 212, 212, 214, 216, 216, 217, 218, 218, 218, 218, 219, 220, 220, 220, 220, 220, 220, 220, 0, 0, 0, 221, 221, 221, 221, 223, 225, 225, 226, 228, 228, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 135, 136, 137, 138, 139, 140, 141, 142, 368, 369, 370, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 387, 388, 389, 394, 395, 396, 397, 398, 399, 400, 403, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 420, 421, 422, 423, 424, 426, 429, 433, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 476, 477, 480, 481, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 497, 498, 499, 500, 501, 503, 506, 510, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 575, 576, 577, 582, 583, 584, 589, 590, 591, 592, 594, 595, 597, 598, 599, 604, 605, 608, 612, 615, 616, 617, 618, 619, 621, 622, 623, 625, 626, 627, 628, 630, 633, 637, 640, 641, 642, 643, 645, 646, 647, 648, 649, 650, 651, 655, 656, 657, 658, 659, 660, 661, 664, 665, 666, 667, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 694, 695, 696, 701, 702, 703, 704, 706, 709, 713, 716, 717, 718, 720, 721, 722, 727, 728, 729, 730, 732, 735, 739, 742, 743, 744, 745, 747, 748, 749, 751, 752, 753, 754, 756, 757, 758, 764, 765, 766, 771, 772, 773, 774, 779, 780, 781, 782, 787, 788, 791, 795, 798, 799, 800, 801, 804, 806, 807, 808, 811, 812, 813, 818, 819, 820, 821, 826, 827, 828, 829, 834, 835, 838, 842, 845, 846, 847, 848, 851, 853, 854, 855, 861, 862, 865, 868};
/* BEGIN LINEINFO 
assign 1 21 61
new 1 21 61
assign 1 22 62
VARGet 0 22 62
typenameSet 1 22 63
assign 1 23 64
new 0 23 64
assign 1 24 65
new 0 24 65
nameSet 1 24 66
assign 1 25 67
new 0 25 67
isTypedSet 1 25 68
namepathSet 1 26 69
assign 1 27 70
new 0 27 70
isArgSet 1 27 71
heldSet 1 28 72
assign 1 29 73
new 1 29 73
assign 1 30 74
METHODGet 0 30 74
typenameSet 1 30 75
assign 1 31 76
new 0 31 76
assign 1 32 77
new 0 32 77
isGenAccessorSet 1 32 78
heldSet 1 33 79
assign 1 34 80
new 1 34 80
assign 1 35 81
PARENSGet 0 35 81
typenameSet 1 35 82
addValue 1 36 83
addValue 1 37 84
addVariable 0 38 85
assign 1 39 86
new 1 39 86
assign 1 40 87
BRACESGet 0 40 87
typenameSet 1 40 88
addValue 1 41 89
assign 1 42 90
new 0 42 90
rtypeSet 1 42 91
assign 1 43 92
rtypeGet 0 43 92
assign 1 43 93
new 0 43 93
isSelfSet 1 43 94
assign 1 44 95
rtypeGet 0 44 95
assign 1 44 96
new 0 44 96
isThisSet 1 44 97
assign 1 45 98
rtypeGet 0 45 98
assign 1 45 99
new 0 45 99
isTypedSet 1 45 100
assign 1 46 101
rtypeGet 0 46 101
assign 1 46 102
new 0 46 102
assign 1 46 103
new 1 46 103
namepathSet 1 46 104
return 1 47 105
assign 1 51 115
new 1 51 115
assign 1 52 116
CALLGet 0 52 116
typenameSet 1 52 117
assign 1 53 118
new 0 53 118
assign 1 54 119
new 0 54 119
nameSet 1 54 120
heldSet 1 55 121
assign 1 56 122
new 1 56 122
assign 1 57 123
VARGet 0 57 123
typenameSet 1 57 124
assign 1 58 125
new 0 58 125
heldSet 1 58 126
addValue 1 59 127
return 1 60 128
assign 1 64 135
new 1 64 135
assign 1 65 136
CALLGet 0 65 136
typenameSet 1 65 137
assign 1 66 138
new 0 66 138
assign 1 67 139
new 0 67 139
nameSet 1 67 140
heldSet 1 68 141
return 1 69 142
assign 1 77 368
typenameGet 0 77 368
assign 1 77 369
METHODGet 0 77 369
assign 1 77 370
equals 1 77 375
assign 1 78 376
containedGet 0 78 376
assign 1 78 377
firstGet 0 78 377
assign 1 78 378
containedGet 0 78 378
assign 1 78 379
firstGet 0 78 379
assign 1 79 380
heldGet 0 79 380
assign 1 79 381
new 0 79 381
isTypedSet 1 79 382
assign 1 80 383
heldGet 0 80 383
namepathSet 1 80 384
assign 1 84 387
typenameGet 0 84 387
assign 1 84 388
CLASSGet 0 84 388
assign 1 84 389
equals 1 84 394
assign 1 85 395
heldGet 0 85 395
assign 1 85 396
namepathGet 0 85 396
assign 1 86 397
new 0 86 397
assign 1 87 398
heldGet 0 87 398
assign 1 87 399
orderedVarsGet 0 87 399
assign 1 87 400
iteratorGet 0 87 400
assign 1 87 403
hasNextGet 0 87 403
assign 1 88 405
nextGet 0 88 405
assign 1 88 406
heldGet 0 88 406
assign 1 89 407
nameGet 0 89 407
assign 1 89 408
copy 0 89 408
nameSet 1 89 409
assign 1 90 410
new 0 90 410
accessorTypeSet 1 90 411
toAccessorName 0 91 412
assign 1 92 413
nameGet 0 92 413
assign 1 93 414
nameGet 0 93 414
assign 1 93 415
new 0 93 415
assign 1 93 416
add 1 93 416
nameSet 1 93 417
assign 1 94 418
isDeclaredGet 0 94 418
assign 1 94 420
heldGet 0 94 420
assign 1 94 421
methodsGet 0 94 421
assign 1 94 422
nameGet 0 94 422
assign 1 94 423
has 1 94 423
assign 1 94 424
not 0 94 424
assign 1 0 426
assign 1 0 429
assign 1 0 433
assign 1 96 436
getAccessor 1 96 436
assign 1 97 437
heldGet 0 97 437
propertySet 1 97 438
assign 1 98 439
heldGet 0 98 439
orgNameSet 1 98 440
assign 1 99 441
heldGet 0 99 441
assign 1 99 442
nameGet 0 99 442
nameSet 1 99 443
assign 1 100 444
heldGet 0 100 444
assign 1 100 445
new 0 100 445
numargsSet 1 100 446
assign 1 101 447
heldGet 0 101 447
assign 1 101 448
methodsGet 0 101 448
assign 1 101 449
heldGet 0 101 449
assign 1 101 450
nameGet 0 101 450
put 2 101 451
assign 1 102 452
heldGet 0 102 452
assign 1 102 453
orderedMethodsGet 0 102 453
addValue 1 102 454
assign 1 103 455
containedGet 0 103 455
assign 1 103 456
lastGet 0 103 456
addValue 1 103 457
assign 1 104 458
getRetNode 1 104 458
assign 1 105 459
new 1 105 459
copyLoc 1 106 460
assign 1 107 461
VARGet 0 107 461
typenameSet 1 107 462
assign 1 108 463
nameGet 0 108 463
assign 1 108 464
copy 0 108 464
heldSet 1 108 465
addValue 1 109 466
assign 1 110 467
containedGet 0 110 467
assign 1 110 468
lastGet 0 110 468
addValue 1 110 469
assign 1 111 470
containedGet 0 111 470
assign 1 111 471
firstGet 0 111 471
syncVariable 1 111 472
syncVariable 1 112 473
assign 1 113 474
isTypedGet 0 113 474
assign 1 114 476
heldGet 0 114 476
rtypeSet 1 114 477
assign 1 116 480
heldGet 0 116 480
rtypeSet 1 116 481
assign 1 121 484
nameGet 0 121 484
assign 1 121 485
copy 0 121 485
nameSet 1 121 486
assign 1 122 487
new 0 122 487
accessorTypeSet 1 122 488
toAccessorName 0 123 489
assign 1 124 490
nameGet 0 124 490
assign 1 125 491
nameGet 0 125 491
assign 1 125 492
new 0 125 492
assign 1 125 493
add 1 125 493
nameSet 1 125 494
assign 1 126 495
isDeclaredGet 0 126 495
assign 1 126 497
heldGet 0 126 497
assign 1 126 498
methodsGet 0 126 498
assign 1 126 499
nameGet 0 126 499
assign 1 126 500
has 1 126 500
assign 1 126 501
not 0 126 501
assign 1 0 503
assign 1 0 506
assign 1 0 510
assign 1 128 513
getAccessor 1 128 513
assign 1 129 514
heldGet 0 129 514
propertySet 1 129 515
assign 1 130 516
heldGet 0 130 516
orgNameSet 1 130 517
assign 1 131 518
heldGet 0 131 518
assign 1 131 519
nameGet 0 131 519
nameSet 1 131 520
assign 1 132 521
heldGet 0 132 521
assign 1 132 522
new 0 132 522
numargsSet 1 132 523
assign 1 133 524
heldGet 0 133 524
assign 1 133 525
methodsGet 0 133 525
assign 1 133 526
heldGet 0 133 526
assign 1 133 527
nameGet 0 133 527
put 2 133 528
assign 1 134 529
heldGet 0 134 529
assign 1 134 530
orderedMethodsGet 0 134 530
addValue 1 134 531
assign 1 135 532
containedGet 0 135 532
assign 1 135 533
lastGet 0 135 533
addValue 1 135 534
assign 1 137 535
new 0 137 535
assign 1 137 536
tmpVar 2 137 536
assign 1 138 537
new 0 138 537
isArgSet 1 138 538
assign 1 139 539
new 1 139 539
copyLoc 1 140 540
assign 1 141 541
VARGet 0 141 541
typenameSet 1 141 542
heldSet 1 142 543
assign 1 144 544
containedGet 0 144 544
assign 1 144 545
firstGet 0 144 545
addValue 1 144 546
assign 1 145 547
new 0 145 547
copyLoc 1 146 548
assign 1 147 549
VARGet 0 147 549
typenameSet 1 147 550
heldSet 1 148 551
assign 1 150 552
getAsNode 1 150 552
assign 1 151 553
new 1 151 553
copyLoc 1 152 554
assign 1 153 555
VARGet 0 153 555
typenameSet 1 153 556
assign 1 154 557
nameGet 0 154 557
assign 1 154 558
copy 0 154 558
heldSet 1 154 559
addValue 1 155 560
addValue 1 156 561
assign 1 157 562
containedGet 0 157 562
assign 1 157 563
lastGet 0 157 563
addValue 1 157 564
addVariable 0 159 565
syncVariable 1 160 566
assign 1 166 575
typenameGet 0 166 575
assign 1 166 576
CALLGet 0 166 576
assign 1 166 577
equals 1 166 582
assign 1 167 583
heldGet 0 167 583
assign 1 167 584
undef 1 167 589
assign 1 168 590
new 0 168 590
assign 1 168 591
new 2 168 591
throw 1 168 592
assign 1 170 594
heldGet 0 170 594
assign 1 170 595
isConstructGet 0 170 595
assign 1 170 597
heldGet 0 170 597
assign 1 170 598
newNpGet 0 170 598
assign 1 170 599
undef 1 170 604
assign 1 0 605
assign 1 0 608
assign 1 0 612
assign 1 171 615
containedGet 0 171 615
assign 1 171 616
firstGet 0 171 616
assign 1 172 617
typenameGet 0 172 617
assign 1 172 618
NAMEPATHGet 0 172 618
assign 1 172 619
notEquals 1 172 619
assign 1 173 621
typenameGet 0 173 621
assign 1 173 622
VARGet 0 173 622
assign 1 173 623
equals 1 173 623
assign 1 173 625
heldGet 0 173 625
assign 1 173 626
nameGet 0 173 626
assign 1 173 627
new 0 173 627
assign 1 173 628
equals 1 173 628
assign 1 0 630
assign 1 0 633
assign 1 0 637
assign 1 174 640
secondGet 0 174 640
assign 1 175 641
typenameGet 0 175 641
assign 1 175 642
NAMEPATHGet 0 175 642
assign 1 175 643
notEquals 1 175 643
assign 1 176 645
new 0 176 645
assign 1 176 646
toString 0 176 646
assign 1 176 647
add 1 176 647
print 0 176 648
assign 1 177 649
new 0 177 649
assign 1 177 650
new 2 177 650
throw 1 177 651
assign 1 180 655
new 0 180 655
assign 1 180 656
toString 0 180 656
assign 1 180 657
add 1 180 657
print 0 180 658
assign 1 181 659
new 0 181 659
assign 1 181 660
new 2 181 660
throw 1 181 661
assign 1 184 664
heldGet 0 184 664
assign 1 184 665
heldGet 0 184 665
newNpSet 1 184 666
delete 0 185 667
assign 1 187 669
heldGet 0 187 669
assign 1 187 670
containedGet 0 187 670
assign 1 187 671
lengthGet 0 187 671
assign 1 187 672
new 0 187 672
assign 1 187 673
subtract 1 187 673
numargsSet 1 187 674
assign 1 188 675
heldGet 0 188 675
assign 1 188 676
heldGet 0 188 676
assign 1 188 677
nameGet 0 188 677
orgNameSet 1 188 678
assign 1 189 679
heldGet 0 189 679
assign 1 189 680
heldGet 0 189 680
assign 1 189 681
nameGet 0 189 681
assign 1 189 682
new 0 189 682
assign 1 189 683
add 1 189 683
assign 1 189 684
heldGet 0 189 684
assign 1 189 685
numargsGet 0 189 685
assign 1 189 686
toString 0 189 686
assign 1 189 687
add 1 189 687
nameSet 1 189 688
assign 1 190 689
heldGet 0 190 689
assign 1 190 690
orgNameGet 0 190 690
assign 1 190 691
new 0 190 691
assign 1 190 692
equals 1 190 692
assign 1 191 694
containedGet 0 191 694
assign 1 191 695
firstGet 0 191 695
assign 1 192 696
def 1 192 701
assign 1 192 702
typenameGet 0 192 702
assign 1 192 703
VARGet 0 192 703
assign 1 192 704
equals 1 192 704
assign 1 0 706
assign 1 0 709
assign 1 0 713
assign 1 193 716
heldGet 0 193 716
assign 1 193 717
numAssignsGet 0 193 717
incrementValue 0 193 718
assign 1 195 720
containedGet 0 195 720
assign 1 195 721
secondGet 0 195 721
assign 1 196 722
def 1 196 727
assign 1 196 728
typenameGet 0 196 728
assign 1 196 729
CALLGet 0 196 729
assign 1 196 730
equals 1 196 730
assign 1 0 732
assign 1 0 735
assign 1 0 739
assign 1 201 742
heldGet 0 201 742
assign 1 201 743
nameGet 0 201 743
assign 1 201 744
new 0 201 744
assign 1 201 745
equals 1 201 745
assign 1 202 747
heldGet 0 202 747
assign 1 202 748
new 0 202 748
isOnceSet 1 202 749
assign 1 204 751
heldGet 0 204 751
assign 1 204 752
nameGet 0 204 752
assign 1 204 753
new 0 204 753
assign 1 204 754
equals 1 204 754
assign 1 205 756
heldGet 0 205 756
assign 1 205 757
new 0 205 757
isManySet 1 205 758
assign 1 209 764
typenameGet 0 209 764
assign 1 209 765
BRACESGet 0 209 765
assign 1 209 766
equals 1 209 771
assign 1 210 772
new 1 210 772
assign 1 211 773
containedGet 0 211 773
assign 1 211 774
def 1 211 779
assign 1 211 780
containedGet 0 211 780
assign 1 211 781
lastGet 0 211 781
assign 1 211 782
def 1 211 787
assign 1 0 788
assign 1 0 791
assign 1 0 795
assign 1 212 798
containedGet 0 212 798
assign 1 212 799
lastGet 0 212 799
assign 1 212 800
nlcGet 0 212 800
nlcSet 1 212 801
copyLoc 1 214 804
assign 1 216 806
RBRACESGet 0 216 806
typenameSet 1 216 807
addValue 1 217 808
assign 1 218 811
typenameGet 0 218 811
assign 1 218 812
PARENSGet 0 218 812
assign 1 218 813
equals 1 218 818
assign 1 219 819
new 1 219 819
assign 1 220 820
containedGet 0 220 820
assign 1 220 821
def 1 220 826
assign 1 220 827
containedGet 0 220 827
assign 1 220 828
lastGet 0 220 828
assign 1 220 829
def 1 220 834
assign 1 0 835
assign 1 0 838
assign 1 0 842
assign 1 221 845
containedGet 0 221 845
assign 1 221 846
lastGet 0 221 846
assign 1 221 847
nlcGet 0 221 847
nlcSet 1 221 848
copyLoc 1 223 851
assign 1 225 853
RPARENSGet 0 225 853
typenameSet 1 225 854
addValue 1 226 855
assign 1 228 861
nextDescendGet 0 228 861
return 1 228 862
return 1 0 865
assign 1 0 868
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1862907585: return bem_transGet_0();
case -1026573604: return bem_buildGet_0();
case -1694731736: return bem_ntypesGet_0();
case 210264567: return bem_print_0();
case 2043795865: return bem_echo_0();
case 1165489654: return bem_sourceFileNameGet_0();
case -1233972717: return bem_create_0();
case 212191548: return bem_tagGet_0();
case -590451146: return bem_serializeToString_0();
case -315420442: return bem_once_0();
case -1533121038: return bem_new_0();
case 607966049: return bem_serializationIteratorGet_0();
case -827921680: return bem_copy_0();
case 1081968352: return bem_constGet_0();
case 466290922: return bem_iteratorGet_0();
case 247385301: return bem_toString_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -853598946: return bem_serializeContents_0();
case -1802544452: return bem_many_0();
case 460304834: return bem_fieldIteratorGet_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 37993623: return bem_classnpGet_0();
case 1307328857: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1644787064: return bem_end_1(bevd_0);
case 172009000: return bem_otherType_1(bevd_0);
case 1070497437: return bem_transSet_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -1867128398: return bem_classnpSet_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case -1492960264: return bem_getRetNode_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case -6357522: return bem_ntypesSet_1(bevd_0);
case -941597658: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case 1289711396: return bem_buildSet_1(bevd_0);
case -148506608: return bem_getAsNode_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -256010896: return bem_constSet_1(bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case 1779417047: return bem_getAccessor_1(bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1625639133: return bem_begin_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass12_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass12_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass12();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass12.bece_BEC_3_5_5_6_BuildVisitPass12_bevs_inst = (BEC_3_5_5_6_BuildVisitPass12) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass12.bece_BEC_3_5_5_6_BuildVisitPass12_bevs_inst;
}
}
}
