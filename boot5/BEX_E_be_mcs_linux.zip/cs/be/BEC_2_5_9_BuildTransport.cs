namespace be {
/* IO:File: source/build/Transport.be */
public sealed class BEC_2_5_9_BuildTransport : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
static BEC_2_5_9_BuildTransport() { }
private static byte[] becc_BEC_2_5_9_BuildTransport_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransport_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_3 = {0x4E,0x6F,0x64,0x65,0x3A};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_4 = {0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x62,0x79};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_5 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_6 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_7 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_8 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_9 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static new BEC_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_inst;

public static new BET_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_type;

public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
BEC_2_5_9_BuildConstants bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevp_build = beva__build;
bevt_0_ta_ph = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_ta_ph.bem_ntypesGet_0();
bevp_outermost = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildTransport_bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_ta_ph);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) {
BEC_2_5_9_BuildConstants bevt_0_ta_ph = null;
bevp_build = beva__build;
bevt_0_ta_ph = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_ta_ph.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
try /* Line: 34*/ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
/* Line: 39*/ {
if (bevl_node == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 39*/ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 40*/
 else /* Line: 39*/ {
break;
} /* Line: 39*/
} /* Line: 39*/
beva_visitor.bem_end_1(this);
} /* Line: 43*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 45*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildTransport_bels_1));
bevt_2_ta_ph.bem_print_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildTransport_bels_2));
bevt_3_ta_ph.bem_print_0();
bevl_e.bemd_0(-1387831588);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildTransport_bels_3));
bevt_4_ta_ph.bem_print_0();
bevl_node.bem_print_0();
bevl_nc = bevl_node.bem_containerGet_0();
while (true)
/* Line: 52*/ {
if (bevl_nc == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 52*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildTransport_bels_4));
bevt_6_ta_ph.bem_print_0();
bevl_nc.bemd_0(-1387831588);
bevl_nc = bevl_nc.bemd_0(2080713205);
} /* Line: 55*/
 else /* Line: 52*/ {
break;
} /* Line: 52*/
} /* Line: 52*/
} /* Line: 52*/
 else /* Line: 57*/ {
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(44, bece_BEC_2_5_9_BuildTransport_bels_5));
bevt_7_ta_ph.bem_print_0();
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildTransport_bels_2));
bevt_8_ta_ph.bem_print_0();
bevl_e.bemd_0(-1387831588);
} /* Line: 60*/
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 62*/
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_contain_0() {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_4_3_MathInt bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_5_4_BuildNode bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_4_3_MathInt bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_4_3_MathInt bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_5_4_LogicBool bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_5_4_LogicBool bevt_65_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_5_4_LogicBool bevt_71_ta_ph = null;
BEC_2_4_3_MathInt bevt_72_ta_ph = null;
bevt_7_ta_ph = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_ta_ph.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
/* Line: 71*/ {
bevt_8_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 71*/ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_ta_ph = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_ta_ph.bevi_bool) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 75*/ {
bevt_12_ta_ph = bevl_curr.bem_typenameGet_0();
bevt_13_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_ta_ph.bevi_int == bevt_13_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 76*/ {
bevt_15_ta_ph = bevl_node.bem_typenameGet_0();
bevt_16_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_15_ta_ph.bevi_int == bevt_16_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 76*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 76*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 76*/
 else /* Line: 76*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 76*/ {
bevl_wf = bevl_node;
while (true)
/* Line: 80*/ {
if (bevl_wf == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_19_ta_ph = bevl_wf.bem_typenameGet_0();
bevt_20_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_19_ta_ph.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 80*/ {
bevt_22_ta_ph = bevl_wf.bem_typenameGet_0();
bevt_23_ta_ph = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_ta_ph.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 80*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 80*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 81*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 81*/ {
bevt_25_ta_ph = bevl_wf.bem_typenameGet_0();
bevt_26_ta_ph = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_ta_ph.bevi_int == bevt_26_ta_ph.bevi_int) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 81*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 81*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 81*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 80*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 80*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 80*/
 else /* Line: 80*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 81*/ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 82*/
 else /* Line: 80*/ {
break;
} /* Line: 80*/
} /* Line: 80*/
if (bevl_wf == null) {
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 84*/ {
bevt_29_ta_ph = bevl_wf.bem_typenameGet_0();
bevt_30_ta_ph = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_ta_ph.bevi_int == bevt_30_ta_ph.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 84*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 84*/ {
bevt_32_ta_ph = bevl_wf.bem_typenameGet_0();
bevt_33_ta_ph = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_ta_ph.bevi_int == bevt_33_ta_ph.bevi_int) {
bevt_31_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_31_ta_ph.bevi_bool)/* Line: 84*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 84*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 84*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 84*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 84*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 84*/
 else /* Line: 84*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 84*/ {
bevl_cnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_ta_ph = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_ta_ph);
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildTransport_bels_6));
bevl_cnode.bem_heldSet_1(bevt_35_ta_ph);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 91*/
} /* Line: 84*/
bevt_37_ta_ph = bevl_curr.bem_typenameGet_0();
bevt_38_ta_ph = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_ta_ph.bevi_int == bevt_38_ta_ph.bevi_int) {
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_41_ta_ph = bevl_curr.bem_containerGet_0();
bevt_40_ta_ph = bevt_41_ta_ph.bem_typenameGet_0();
bevt_42_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_ta_ph.bevi_int == bevt_42_ta_ph.bevi_int) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 94*/
 else /* Line: 94*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 94*/ {
bevt_44_ta_ph = bevl_node.bem_typenameGet_0();
bevt_45_ta_ph = bevp_ntypes.bem_IDGet_0();
if (bevt_44_ta_ph.bevi_int == bevt_45_ta_ph.bevi_int) {
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 94*/
 else /* Line: 94*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 94*/ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_ta_ph = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_ta_ph);
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_7));
bevl_mnode.bem_heldSet_1(bevt_47_ta_ph);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 100*/
bevt_49_ta_ph = bevl_node.bem_typenameGet_0();
bevt_50_ta_ph = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_ta_ph.bevi_int == bevt_50_ta_ph.bevi_int) {
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 103*/ {
bevt_52_ta_ph = bevl_curr.bem_typenameGet_0();
bevt_53_ta_ph = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_ta_ph.bevi_int == bevt_53_ta_ph.bevi_int) {
bevt_51_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_51_ta_ph.bevi_bool)/* Line: 103*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 103*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 103*/
 else /* Line: 103*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 103*/ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_ta_ph = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_ta_ph);
bevt_55_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_8));
bevl_mnode.bem_heldSet_1(bevt_55_ta_ph);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 109*/
bevt_57_ta_ph = bevl_node.bem_typenameGet_0();
bevt_58_ta_ph = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_ta_ph.bevi_int == bevt_58_ta_ph.bevi_int) {
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 112*/ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 113*/
 else /* Line: 112*/ {
bevt_60_ta_ph = bevl_node.bem_typenameGet_0();
bevt_61_ta_ph = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_ta_ph.bevi_int == bevt_61_ta_ph.bevi_int) {
bevt_59_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_59_ta_ph.bevi_bool)/* Line: 114*/ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 115*/
 else /* Line: 112*/ {
bevt_63_ta_ph = bevl_node.bem_typenameGet_0();
bevt_64_ta_ph = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_ta_ph.bevi_int == bevt_64_ta_ph.bevi_int) {
bevt_62_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_62_ta_ph.bevi_bool)/* Line: 116*/ {
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_65_ta_ph.bevi_bool)/* Line: 118*/ {
bevt_67_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_9));
bevt_66_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_ta_ph, bevl_node);
throw new be.BECS_ThrowBack(bevt_66_ta_ph);
} /* Line: 119*/
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 122*/ {
bevt_70_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_9));
bevt_69_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_ta_ph, bevl_node);
throw new be.BECS_ThrowBack(bevt_69_ta_ph);
} /* Line: 123*/
} /* Line: 122*/
 else /* Line: 125*/ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 126*/
} /* Line: 112*/
} /* Line: 112*/
bevt_72_ta_ph = bevl_node.bem_typenameGet_0();
bevt_71_ta_ph = bevl_conTypes.bem_has_1(bevt_72_ta_ph);
if (bevt_71_ta_ph.bevi_bool)/* Line: 128*/ {
bevl_curr = bevl_node;
} /* Line: 129*/
} /* Line: 128*/
} /* Line: 75*/
 else /* Line: 71*/ {
break;
} /* Line: 71*/
} /* Line: 71*/
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 137*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_9));
bevt_1_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_ta_ph, beva_curr);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 138*/
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGetDirect_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() {
return bevp_outermost;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGetDirect_0() {
return bevp_outermost;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_outermostSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGetDirect_0() {
return bevp_current;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 17, 18, 19, 21, 21, 22, 22, 26, 27, 27, 28, 29, 35, 37, 39, 39, 40, 43, 45, 45, 46, 46, 47, 47, 48, 49, 49, 50, 51, 52, 52, 53, 53, 54, 55, 58, 58, 59, 59, 60, 62, 67, 67, 68, 69, 70, 71, 71, 74, 75, 75, 75, 76, 76, 76, 76, 76, 76, 76, 76, 0, 0, 0, 79, 80, 80, 80, 80, 80, 80, 0, 80, 80, 80, 80, 0, 0, 0, 81, 81, 81, 81, 0, 0, 0, 0, 0, 82, 84, 84, 84, 84, 84, 84, 0, 84, 84, 84, 84, 0, 0, 0, 0, 0, 87, 88, 88, 89, 89, 90, 91, 94, 94, 94, 94, 94, 94, 94, 94, 94, 0, 0, 0, 94, 94, 94, 94, 0, 0, 0, 96, 97, 97, 98, 98, 99, 100, 103, 103, 103, 103, 103, 103, 103, 103, 0, 0, 0, 105, 106, 106, 107, 107, 108, 109, 112, 112, 112, 112, 113, 114, 114, 114, 114, 115, 116, 116, 116, 116, 117, 118, 118, 119, 119, 119, 121, 122, 122, 123, 123, 123, 126, 128, 128, 129, 136, 137, 137, 138, 138, 138, 140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {30, 31, 32, 33, 34, 35, 36, 37, 38, 43, 44, 45, 46, 47, 64, 65, 68, 73, 74, 80, 84, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 101, 106, 107, 108, 109, 110, 118, 119, 120, 121, 122, 124, 210, 211, 212, 213, 214, 215, 218, 220, 221, 222, 227, 228, 229, 230, 235, 236, 237, 238, 243, 244, 247, 251, 254, 257, 262, 263, 264, 265, 270, 271, 274, 275, 276, 281, 282, 285, 289, 292, 293, 294, 299, 300, 303, 307, 310, 314, 317, 323, 328, 329, 330, 331, 336, 337, 340, 341, 342, 347, 348, 351, 355, 358, 362, 365, 366, 367, 368, 369, 370, 371, 374, 375, 376, 381, 382, 383, 384, 385, 390, 391, 394, 398, 401, 402, 403, 408, 409, 412, 416, 419, 420, 421, 422, 423, 424, 425, 427, 428, 429, 434, 435, 436, 437, 442, 443, 446, 450, 453, 454, 455, 456, 457, 458, 459, 461, 462, 463, 468, 469, 472, 473, 474, 479, 480, 483, 484, 485, 490, 491, 492, 497, 498, 499, 500, 502, 503, 508, 509, 510, 511, 515, 519, 520, 522, 537, 538, 543, 544, 545, 546, 548, 551, 554, 557, 561, 565, 568, 571, 575, 579, 582, 585, 589, 593, 596, 599, 603};
/* BEGIN LINEINFO 
assign 1 16 30
assign 1 17 31
constantsGet 0 17 31
assign 1 17 32
ntypesGet 0 17 32
assign 1 18 33
new 1 18 33
assign 1 19 34
assign 1 21 35
TRANSUNITGet 0 21 35
typenameSet 1 21 36
assign 1 22 37
new 0 22 37
heldSet 1 22 38
assign 1 26 43
assign 1 27 44
constantsGet 0 27 44
assign 1 27 45
ntypesGet 0 27 45
assign 1 28 46
assign 1 29 47
begin 1 35 64
assign 1 37 65
accept 1 37 65
assign 1 39 68
def 1 39 73
assign 1 40 74
accept 1 40 74
end 1 43 80
assign 1 45 84
def 1 45 89
assign 1 46 90
new 0 46 90
print 0 46 91
assign 1 47 92
new 0 47 92
print 0 47 93
print 0 48 94
assign 1 49 95
new 0 49 95
print 0 49 96
print 0 50 97
assign 1 51 98
containerGet 0 51 98
assign 1 52 101
def 1 52 106
assign 1 53 107
new 0 53 107
print 0 53 108
print 0 54 109
assign 1 55 110
containerGet 0 55 110
assign 1 58 118
new 0 58 118
print 0 58 119
assign 1 59 120
new 0 59 120
print 0 59 121
print 0 60 122
throw 1 62 124
assign 1 67 210
constantsGet 0 67 210
assign 1 67 211
conTypesGet 0 67 211
assign 1 68 212
assign 1 69 213
containedGet 0 69 213
containedSet 1 70 214
assign 1 71 215
linkedListIteratorGet 0 71 215
assign 1 71 218
hasNextGet 0 71 218
assign 1 74 220
nextGet 0 74 220
assign 1 75 221
delayDeleteGet 0 75 221
assign 1 75 222
not 0 75 227
assign 1 76 228
typenameGet 0 76 228
assign 1 76 229
TRANSUNITGet 0 76 229
assign 1 76 230
equals 1 76 235
assign 1 76 236
typenameGet 0 76 236
assign 1 76 237
IDGet 0 76 237
assign 1 76 238
equals 1 76 243
assign 1 0 244
assign 1 0 247
assign 1 0 251
assign 1 79 254
assign 1 80 257
def 1 80 262
assign 1 80 263
typenameGet 0 80 263
assign 1 80 264
IDGet 0 80 264
assign 1 80 265
equals 1 80 270
assign 1 0 271
assign 1 80 274
typenameGet 0 80 274
assign 1 80 275
COLONGet 0 80 275
assign 1 80 276
equals 1 80 281
assign 1 0 282
assign 1 0 285
assign 1 0 289
assign 1 81 292
typenameGet 0 81 292
assign 1 81 293
SPACEGet 0 81 293
assign 1 81 294
equals 1 81 299
assign 1 0 300
assign 1 0 303
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 82 317
nextPeerGet 0 82 317
assign 1 84 323
def 1 84 328
assign 1 84 329
typenameGet 0 84 329
assign 1 84 330
PARENSGet 0 84 330
assign 1 84 331
equals 1 84 336
assign 1 0 337
assign 1 84 340
typenameGet 0 84 340
assign 1 84 341
BRACESGet 0 84 341
assign 1 84 342
equals 1 84 347
assign 1 0 348
assign 1 0 351
assign 1 0 355
assign 1 0 358
assign 1 0 362
assign 1 87 365
new 1 87 365
assign 1 88 366
CLASSGet 0 88 366
typenameSet 1 88 367
assign 1 89 368
new 0 89 368
heldSet 1 89 369
addValue 1 90 370
assign 1 91 371
assign 1 94 374
typenameGet 0 94 374
assign 1 94 375
BRACESGet 0 94 375
assign 1 94 376
equals 1 94 381
assign 1 94 382
containerGet 0 94 382
assign 1 94 383
typenameGet 0 94 383
assign 1 94 384
CLASSGet 0 94 384
assign 1 94 385
equals 1 94 390
assign 1 0 391
assign 1 0 394
assign 1 0 398
assign 1 94 401
typenameGet 0 94 401
assign 1 94 402
IDGet 0 94 402
assign 1 94 403
equals 1 94 408
assign 1 0 409
assign 1 0 412
assign 1 0 416
assign 1 96 419
new 1 96 419
assign 1 97 420
METHODGet 0 97 420
typenameSet 1 97 421
assign 1 98 422
new 0 98 422
heldSet 1 98 423
addValue 1 99 424
assign 1 100 425
assign 1 103 427
typenameGet 0 103 427
assign 1 103 428
BRACESGet 0 103 428
assign 1 103 429
equals 1 103 434
assign 1 103 435
typenameGet 0 103 435
assign 1 103 436
BRACESGet 0 103 436
assign 1 103 437
equals 1 103 442
assign 1 0 443
assign 1 0 446
assign 1 0 450
assign 1 105 453
new 1 105 453
assign 1 106 454
PROPERTIESGet 0 106 454
typenameSet 1 106 455
assign 1 107 456
new 0 107 456
heldSet 1 107 457
addValue 1 108 458
assign 1 109 459
assign 1 112 461
typenameGet 0 112 461
assign 1 112 462
RPARENSGet 0 112 462
assign 1 112 463
equals 1 112 468
assign 1 113 469
stepBack 1 113 469
assign 1 114 472
typenameGet 0 114 472
assign 1 114 473
RIDXGet 0 114 473
assign 1 114 474
equals 1 114 479
assign 1 115 480
stepBack 1 115 480
assign 1 116 483
typenameGet 0 116 483
assign 1 116 484
RBRACESGet 0 116 484
assign 1 116 485
equals 1 116 490
assign 1 117 491
stepBack 1 117 491
assign 1 118 492
undef 1 118 497
assign 1 119 498
new 0 119 498
assign 1 119 499
new 2 119 499
throw 1 119 500
assign 1 121 502
stepBack 1 121 502
assign 1 122 503
undef 1 122 508
assign 1 123 509
new 0 123 509
assign 1 123 510
new 2 123 510
throw 1 123 511
addValue 1 126 515
assign 1 128 519
typenameGet 0 128 519
assign 1 128 520
has 1 128 520
assign 1 129 522
assign 1 136 537
containerGet 0 136 537
assign 1 137 538
undef 1 137 543
assign 1 138 544
new 0 138 544
assign 1 138 545
new 2 138 545
throw 1 138 546
return 1 140 548
return 1 0 551
return 1 0 554
assign 1 0 557
assign 1 0 561
return 1 0 565
return 1 0 568
assign 1 0 571
assign 1 0 575
return 1 0 579
return 1 0 582
assign 1 0 585
assign 1 0 589
return 1 0 593
return 1 0 596
assign 1 0 599
assign 1 0 603
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1387831588: return bem_print_0();
case -1188922735: return bem_echo_0();
case -793241295: return bem_iteratorGet_0();
case 371157924: return bem_sourceFileNameGet_0();
case 1793580871: return bem_outermostGetDirect_0();
case 1652521523: return bem_serializeContents_0();
case -356617806: return bem_currentGet_0();
case -1760538533: return bem_classNameGet_0();
case 7254011: return bem_fieldIteratorGet_0();
case -921473949: return bem_fieldNamesGet_0();
case -1226960256: return bem_outermostGet_0();
case 895193825: return bem_once_0();
case -1094288749: return bem_currentGetDirect_0();
case -467511392: return bem_toString_0();
case 2121610934: return bem_buildGetDirect_0();
case -1323898541: return bem_toAny_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -188263053: return bem_ntypesGetDirect_0();
case -1792853387: return bem_contain_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -447432319: return bem_many_0();
case 1597327951: return bem_create_0();
case -1363819567: return bem_new_0();
case 1092105192: return bem_hashGet_0();
case -105946774: return bem_serializeToString_0();
case 1890854002: return bem_tagGet_0();
case 1470667102: return bem_buildGet_0();
case 1097162015: return bem_ntypesGet_0();
case 1319388306: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1035469982: return bem_ntypesSetDirect_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -200758756: return bem_ntypesSet_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1880265102: return bem_outermostSetDirect_1(bevd_0);
case 1929898803: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1112333174: return bem_buildSetDirect_1(bevd_0);
case -983056039: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case -104906255: return bem_currentSet_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case 849374443: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 759979266: return bem_currentSetDirect_1(bevd_0);
case -360640497: return bem_outermostSet_1(bevd_0);
case -1099297133: return bem_buildSet_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1973904590: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransport_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildTransport_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildTransport();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst = (BEC_2_5_9_BuildTransport) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_type;
}
}
}
