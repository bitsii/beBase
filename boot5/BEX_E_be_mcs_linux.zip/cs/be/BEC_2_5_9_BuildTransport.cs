namespace be {
/* IO:File: source/build/Transport.be */
public sealed class BEC_2_5_9_BuildTransport : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildTransport() { }
static BEC_2_5_9_BuildTransport() { }
private static byte[] becc_BEC_2_5_9_BuildTransport_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74};
private static byte[] becc_BEC_2_5_9_BuildTransport_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x54,0x72,0x61,0x6E,0x73,0x70,0x6F,0x72,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_0 = {0x74,0x72,0x61,0x6E,0x73,0x75,0x6E,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_1 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x20,0x74,0x6F,0x20,0x6E,0x6F,0x64,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_1, 37));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_2 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_2, 10));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_3 = {0x4E,0x6F,0x64,0x65,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_4 = {0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x64,0x20,0x62,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_4, 12));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_5 = {0x43,0x61,0x75,0x67,0x68,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x69,0x73,0x69,0x74,0x2C,0x20,0x6E,0x6F,0x64,0x65,0x20,0x69,0x73,0x20,0x75,0x6E,0x64,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_5, 44));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_6 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildTransport_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildTransport_bels_6, 10));
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_7 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_8 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_9 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_10 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_11 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
private static byte[] bece_BEC_2_5_9_BuildTransport_bels_12 = {0x4D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x63,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x73,0x74,0x65,0x70,0x6F,0x75,0x74};
public static new BEC_2_5_9_BuildTransport bece_BEC_2_5_9_BuildTransport_bevs_inst;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_5_4_BuildNode bevp_outermost;
public BEC_2_5_4_BuildNode bevp_current;
public BEC_2_5_9_BuildTransport bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevp_current = bevp_outermost;
bevt_1_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevp_outermost.bem_typenameSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildTransport_bels_0));
bevp_outermost.bem_heldSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_new_2(BEC_2_5_5_BuildBuild beva__build, BEC_2_5_4_BuildNode beva__outermost) {
BEC_2_5_9_BuildConstants bevt_0_tmpany_phold = null;
bevp_build = beva__build;
bevt_0_tmpany_phold = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevt_0_tmpany_phold.bem_ntypesGet_0();
bevp_outermost = beva__outermost;
bevp_current = bevp_outermost;
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_traverse_1(BEC_3_5_5_7_BuildVisitVisitor beva_visitor) {
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
try  /* Line: 35 */ {
beva_visitor.bem_begin_1(this);
bevl_node = beva_visitor.bem_accept_1(bevp_outermost);
while (true)
 /* Line: 40 */ {
if (bevl_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevl_node = beva_visitor.bem_accept_1(bevl_node);
} /* Line: 41 */
 else  /* Line: 40 */ {
break;
} /* Line: 40 */
} /* Line: 40 */
beva_visitor.bem_end_1(this);
} /* Line: 44 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
if (bevl_node == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_0;
bevt_2_tmpany_phold.bem_print_0();
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_1;
bevt_3_tmpany_phold.bem_print_0();
bevl_e.bemd_0(210264567);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_2;
bevt_4_tmpany_phold.bem_print_0();
bevl_node.bem_print_0();
bevl_nc = bevl_node.bem_containerGet_0();
while (true)
 /* Line: 53 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_3;
bevt_6_tmpany_phold.bem_print_0();
bevl_nc.bemd_0(210264567);
bevl_nc = bevl_nc.bemd_0(-122775537);
} /* Line: 56 */
 else  /* Line: 53 */ {
break;
} /* Line: 53 */
} /* Line: 53 */
} /* Line: 53 */
 else  /* Line: 58 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_4;
bevt_7_tmpany_phold.bem_print_0();
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildTransport_bevo_5;
bevt_8_tmpany_phold.bem_print_0();
bevl_e.bemd_0(210264567);
} /* Line: 61 */
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 63 */
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_contain_0() {
BEC_2_9_3_ContainerMap bevl_conTypes = null;
BEC_2_5_4_BuildNode bevl_curr = null;
BEC_2_9_10_ContainerLinkedList bevl_bfrom = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_5_4_BuildNode bevl_wf = null;
BEC_2_5_4_BuildNode bevl_cnode = null;
BEC_2_5_4_BuildNode bevl_mnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_9_BuildConstants bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
bevt_7_tmpany_phold = bevp_build.bem_constantsGet_0();
bevl_conTypes = bevt_7_tmpany_phold.bem_conTypesGet_0();
bevl_curr = bevp_outermost;
bevl_bfrom = bevp_outermost.bem_containedGet_0();
bevp_outermost.bem_containedSet_1(null);
bevl_i = bevl_bfrom.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 72 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_8_tmpany_phold != null && bevt_8_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 72 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevl_i.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_node.bem_delayDeleteGet_0();
if (bevt_10_tmpany_phold.bevi_bool) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 76 */ {
bevt_12_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_13_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
if (bevt_12_tmpany_phold.bevi_int == bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_15_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_15_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 77 */
 else  /* Line: 77 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 77 */ {
bevl_wf = bevl_node;
while (true)
 /* Line: 81 */ {
if (bevl_wf == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_19_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_20_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_19_tmpany_phold.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_22_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_23_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_22_tmpany_phold.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_25_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_26_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
if (bevt_25_tmpany_phold.bevi_int == bevt_26_tmpany_phold.bevi_int) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 82 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 82 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 81 */
 else  /* Line: 81 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 82 */ {
bevl_wf = bevl_wf.bem_nextPeerGet_0();
} /* Line: 83 */
 else  /* Line: 81 */ {
break;
} /* Line: 81 */
} /* Line: 81 */
if (bevl_wf == null) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_29_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_30_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
if (bevt_29_tmpany_phold.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_32_tmpany_phold = bevl_wf.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 85 */
 else  /* Line: 85 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 85 */ {
bevl_cnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_34_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevl_cnode.bem_typenameSet_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildTransport_bels_7));
bevl_cnode.bem_heldSet_1(bevt_35_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_cnode);
bevl_curr = bevl_cnode;
} /* Line: 92 */
} /* Line: 85 */
bevt_37_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_38_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_37_tmpany_phold.bevi_int == bevt_38_tmpany_phold.bevi_int) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_41_tmpany_phold = bevl_curr.bem_containerGet_0();
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_typenameGet_0();
bevt_42_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_40_tmpany_phold.bevi_int == bevt_42_tmpany_phold.bevi_int) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 95 */ {
bevt_44_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_45_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_44_tmpany_phold.bevi_int == bevt_45_tmpany_phold.bevi_int) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 95 */
 else  /* Line: 95 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 95 */ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_46_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevl_mnode.bem_typenameSet_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_8));
bevl_mnode.bem_heldSet_1(bevt_47_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 101 */
bevt_49_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_50_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_49_tmpany_phold.bevi_int == bevt_50_tmpany_phold.bevi_int) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_52_tmpany_phold = bevl_curr.bem_typenameGet_0();
bevt_53_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
if (bevt_52_tmpany_phold.bevi_int == bevt_53_tmpany_phold.bevi_int) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 104 */
 else  /* Line: 104 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 104 */ {
bevl_mnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_54_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevl_mnode.bem_typenameSet_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildTransport_bels_9));
bevl_mnode.bem_heldSet_1(bevt_55_tmpany_phold);
bevl_curr.bem_addValue_1(bevl_mnode);
bevl_curr = bevl_mnode;
} /* Line: 110 */
bevt_57_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_58_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
if (bevt_57_tmpany_phold.bevi_int == bevt_58_tmpany_phold.bevi_int) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 114 */
 else  /* Line: 113 */ {
bevt_60_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_61_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
if (bevt_60_tmpany_phold.bevi_int == bevt_61_tmpany_phold.bevi_int) {
bevt_59_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_59_tmpany_phold.bevi_bool) /* Line: 115 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
} /* Line: 116 */
 else  /* Line: 113 */ {
bevt_63_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_64_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_63_tmpany_phold.bevi_int == bevt_64_tmpany_phold.bevi_int) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_10));
bevt_66_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_67_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_66_tmpany_phold);
} /* Line: 120 */
bevl_curr = bem_stepBack_1(bevl_curr);
if (bevl_curr == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_11));
bevt_69_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_70_tmpany_phold, bevl_node);
throw new be.BECS_ThrowBack(bevt_69_tmpany_phold);
} /* Line: 124 */
} /* Line: 123 */
 else  /* Line: 126 */ {
bevl_curr.bem_addValue_1(bevl_node);
} /* Line: 127 */
} /* Line: 113 */
} /* Line: 113 */
bevt_72_tmpany_phold = bevl_node.bem_typenameGet_0();
bevt_71_tmpany_phold = bevl_conTypes.bem_has_1(bevt_72_tmpany_phold);
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevl_curr = bevl_node;
} /* Line: 130 */
} /* Line: 129 */
} /* Line: 76 */
 else  /* Line: 72 */ {
break;
} /* Line: 72 */
} /* Line: 72 */
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_stepBack_1(BEC_2_5_4_BuildNode beva_curr) {
BEC_2_5_4_BuildNode bevl_hop = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevl_hop = beva_curr.bem_containerGet_0();
if (bevl_hop == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 138 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildTransport_bels_12));
bevt_1_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_2_tmpany_phold, beva_curr);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 139 */
return bevl_hop;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_outermostGet_0() {
return bevp_outermost;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_outermostSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outermost = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 18, 19, 20, 22, 22, 23, 23, 27, 28, 28, 29, 30, 36, 38, 40, 40, 41, 44, 46, 46, 47, 47, 48, 48, 49, 50, 50, 51, 52, 53, 53, 54, 54, 55, 56, 59, 59, 60, 60, 61, 63, 68, 68, 69, 70, 71, 72, 72, 75, 76, 76, 76, 77, 77, 77, 77, 77, 77, 77, 77, 0, 0, 0, 80, 81, 81, 81, 81, 81, 81, 0, 81, 81, 81, 81, 0, 0, 0, 82, 82, 82, 82, 0, 0, 0, 0, 0, 83, 85, 85, 85, 85, 85, 85, 0, 85, 85, 85, 85, 0, 0, 0, 0, 0, 88, 89, 89, 90, 90, 91, 92, 95, 95, 95, 95, 95, 95, 95, 95, 95, 0, 0, 0, 95, 95, 95, 95, 0, 0, 0, 97, 98, 98, 99, 99, 100, 101, 104, 104, 104, 104, 104, 104, 104, 104, 0, 0, 0, 106, 107, 107, 108, 108, 109, 110, 113, 113, 113, 113, 114, 115, 115, 115, 115, 116, 117, 117, 117, 117, 118, 119, 119, 120, 120, 120, 122, 123, 123, 124, 124, 124, 127, 129, 129, 130, 137, 138, 138, 139, 139, 139, 141, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {36, 37, 38, 39, 40, 41, 42, 43, 44, 49, 50, 51, 52, 53, 70, 71, 74, 79, 80, 86, 90, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 107, 112, 113, 114, 115, 116, 124, 125, 126, 127, 128, 130, 216, 217, 218, 219, 220, 221, 224, 226, 227, 228, 233, 234, 235, 236, 241, 242, 243, 244, 249, 250, 253, 257, 260, 263, 268, 269, 270, 271, 276, 277, 280, 281, 282, 287, 288, 291, 295, 298, 299, 300, 305, 306, 309, 313, 316, 320, 323, 329, 334, 335, 336, 337, 342, 343, 346, 347, 348, 353, 354, 357, 361, 364, 368, 371, 372, 373, 374, 375, 376, 377, 380, 381, 382, 387, 388, 389, 390, 391, 396, 397, 400, 404, 407, 408, 409, 414, 415, 418, 422, 425, 426, 427, 428, 429, 430, 431, 433, 434, 435, 440, 441, 442, 443, 448, 449, 452, 456, 459, 460, 461, 462, 463, 464, 465, 467, 468, 469, 474, 475, 478, 479, 480, 485, 486, 489, 490, 491, 496, 497, 498, 503, 504, 505, 506, 508, 509, 514, 515, 516, 517, 521, 525, 526, 528, 543, 544, 549, 550, 551, 552, 554, 557, 560, 564, 567, 571, 574, 578, 581};
/* BEGIN LINEINFO 
assign 1 17 36
assign 1 18 37
constantsGet 0 18 37
assign 1 18 38
ntypesGet 0 18 38
assign 1 19 39
new 1 19 39
assign 1 20 40
assign 1 22 41
TRANSUNITGet 0 22 41
typenameSet 1 22 42
assign 1 23 43
new 0 23 43
heldSet 1 23 44
assign 1 27 49
assign 1 28 50
constantsGet 0 28 50
assign 1 28 51
ntypesGet 0 28 51
assign 1 29 52
assign 1 30 53
begin 1 36 70
assign 1 38 71
accept 1 38 71
assign 1 40 74
def 1 40 79
assign 1 41 80
accept 1 41 80
end 1 44 86
assign 1 46 90
def 1 46 95
assign 1 47 96
new 0 47 96
print 0 47 97
assign 1 48 98
new 0 48 98
print 0 48 99
print 0 49 100
assign 1 50 101
new 0 50 101
print 0 50 102
print 0 51 103
assign 1 52 104
containerGet 0 52 104
assign 1 53 107
def 1 53 112
assign 1 54 113
new 0 54 113
print 0 54 114
print 0 55 115
assign 1 56 116
containerGet 0 56 116
assign 1 59 124
new 0 59 124
print 0 59 125
assign 1 60 126
new 0 60 126
print 0 60 127
print 0 61 128
throw 1 63 130
assign 1 68 216
constantsGet 0 68 216
assign 1 68 217
conTypesGet 0 68 217
assign 1 69 218
assign 1 70 219
containedGet 0 70 219
containedSet 1 71 220
assign 1 72 221
linkedListIteratorGet 0 72 221
assign 1 72 224
hasNextGet 0 72 224
assign 1 75 226
nextGet 0 75 226
assign 1 76 227
delayDeleteGet 0 76 227
assign 1 76 228
not 0 76 233
assign 1 77 234
typenameGet 0 77 234
assign 1 77 235
TRANSUNITGet 0 77 235
assign 1 77 236
equals 1 77 241
assign 1 77 242
typenameGet 0 77 242
assign 1 77 243
IDGet 0 77 243
assign 1 77 244
equals 1 77 249
assign 1 0 250
assign 1 0 253
assign 1 0 257
assign 1 80 260
assign 1 81 263
def 1 81 268
assign 1 81 269
typenameGet 0 81 269
assign 1 81 270
IDGet 0 81 270
assign 1 81 271
equals 1 81 276
assign 1 0 277
assign 1 81 280
typenameGet 0 81 280
assign 1 81 281
COLONGet 0 81 281
assign 1 81 282
equals 1 81 287
assign 1 0 288
assign 1 0 291
assign 1 0 295
assign 1 82 298
typenameGet 0 82 298
assign 1 82 299
SPACEGet 0 82 299
assign 1 82 300
equals 1 82 305
assign 1 0 306
assign 1 0 309
assign 1 0 313
assign 1 0 316
assign 1 0 320
assign 1 83 323
nextPeerGet 0 83 323
assign 1 85 329
def 1 85 334
assign 1 85 335
typenameGet 0 85 335
assign 1 85 336
PARENSGet 0 85 336
assign 1 85 337
equals 1 85 342
assign 1 0 343
assign 1 85 346
typenameGet 0 85 346
assign 1 85 347
BRACESGet 0 85 347
assign 1 85 348
equals 1 85 353
assign 1 0 354
assign 1 0 357
assign 1 0 361
assign 1 0 364
assign 1 0 368
assign 1 88 371
new 1 88 371
assign 1 89 372
CLASSGet 0 89 372
typenameSet 1 89 373
assign 1 90 374
new 0 90 374
heldSet 1 90 375
addValue 1 91 376
assign 1 92 377
assign 1 95 380
typenameGet 0 95 380
assign 1 95 381
BRACESGet 0 95 381
assign 1 95 382
equals 1 95 387
assign 1 95 388
containerGet 0 95 388
assign 1 95 389
typenameGet 0 95 389
assign 1 95 390
CLASSGet 0 95 390
assign 1 95 391
equals 1 95 396
assign 1 0 397
assign 1 0 400
assign 1 0 404
assign 1 95 407
typenameGet 0 95 407
assign 1 95 408
IDGet 0 95 408
assign 1 95 409
equals 1 95 414
assign 1 0 415
assign 1 0 418
assign 1 0 422
assign 1 97 425
new 1 97 425
assign 1 98 426
METHODGet 0 98 426
typenameSet 1 98 427
assign 1 99 428
new 0 99 428
heldSet 1 99 429
addValue 1 100 430
assign 1 101 431
assign 1 104 433
typenameGet 0 104 433
assign 1 104 434
BRACESGet 0 104 434
assign 1 104 435
equals 1 104 440
assign 1 104 441
typenameGet 0 104 441
assign 1 104 442
BRACESGet 0 104 442
assign 1 104 443
equals 1 104 448
assign 1 0 449
assign 1 0 452
assign 1 0 456
assign 1 106 459
new 1 106 459
assign 1 107 460
PROPERTIESGet 0 107 460
typenameSet 1 107 461
assign 1 108 462
new 0 108 462
heldSet 1 108 463
addValue 1 109 464
assign 1 110 465
assign 1 113 467
typenameGet 0 113 467
assign 1 113 468
RPARENSGet 0 113 468
assign 1 113 469
equals 1 113 474
assign 1 114 475
stepBack 1 114 475
assign 1 115 478
typenameGet 0 115 478
assign 1 115 479
RIDXGet 0 115 479
assign 1 115 480
equals 1 115 485
assign 1 116 486
stepBack 1 116 486
assign 1 117 489
typenameGet 0 117 489
assign 1 117 490
RBRACESGet 0 117 490
assign 1 117 491
equals 1 117 496
assign 1 118 497
stepBack 1 118 497
assign 1 119 498
undef 1 119 503
assign 1 120 504
new 0 120 504
assign 1 120 505
new 2 120 505
throw 1 120 506
assign 1 122 508
stepBack 1 122 508
assign 1 123 509
undef 1 123 514
assign 1 124 515
new 0 124 515
assign 1 124 516
new 2 124 516
throw 1 124 517
addValue 1 127 521
assign 1 129 525
typenameGet 0 129 525
assign 1 129 526
has 1 129 526
assign 1 130 528
assign 1 137 543
containerGet 0 137 543
assign 1 138 544
undef 1 138 549
assign 1 139 550
new 0 139 550
assign 1 139 551
new 2 139 551
throw 1 139 552
return 1 141 554
return 1 0 557
assign 1 0 560
return 1 0 564
assign 1 0 567
return 1 0 571
assign 1 0 574
return 1 0 578
assign 1 0 581
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1026573604: return bem_buildGet_0();
case -1694731736: return bem_ntypesGet_0();
case 210264567: return bem_print_0();
case 372343815: return bem_contain_0();
case 2043795865: return bem_echo_0();
case 1165489654: return bem_sourceFileNameGet_0();
case -1233972717: return bem_create_0();
case 212191548: return bem_tagGet_0();
case -590451146: return bem_serializeToString_0();
case 2003639325: return bem_outermostGet_0();
case -315420442: return bem_once_0();
case -1533121038: return bem_new_0();
case 607966049: return bem_serializationIteratorGet_0();
case -827921680: return bem_copy_0();
case 466290922: return bem_iteratorGet_0();
case -1371570684: return bem_currentGet_0();
case 247385301: return bem_toString_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -853598946: return bem_serializeContents_0();
case -1802544452: return bem_many_0();
case 460304834: return bem_fieldIteratorGet_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 1307328857: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1289711396: return bem_buildSet_1(bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case 204645394: return bem_stepBack_1((BEC_2_5_4_BuildNode) bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case -6357522: return bem_ntypesSet_1(bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case -1910853276: return bem_outermostSet_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1791290028: return bem_traverse_1((BEC_3_5_5_7_BuildVisitVisitor) bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -1287998003: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case -318870977: return bem_currentSet_1(bevd_0);
case 172009000: return bem_otherType_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1302165635: return bem_new_2((BEC_2_5_5_BuildBuild) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildTransport_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildTransport_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildTransport();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst = (BEC_2_5_9_BuildTransport) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildTransport.bece_BEC_2_5_9_BuildTransport_bevs_inst;
}
}
}
