namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_3_6_NetSocket : BEC_2_6_6_SystemObject {
public BEC_2_3_6_NetSocket() { }
static BEC_2_3_6_NetSocket() { }

  public Socket bevi_socket;
  private static byte[] becc_BEC_2_3_6_NetSocket_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74};
private static byte[] becc_BEC_2_3_6_NetSocket_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_2_3_6_NetSocket bece_BEC_2_3_6_NetSocket_bevs_inst;

public static new BET_2_3_6_NetSocket bece_BEC_2_3_6_NetSocket_bevs_type;

public virtual BEC_3_3_6_6_NetSocketReader bem_readerGet_0() {
BEC_3_3_6_6_NetSocketReader bevl_sr = null;
bevl_sr = (BEC_3_3_6_6_NetSocketReader) (new BEC_3_3_6_6_NetSocketReader()).bem_new_0();

    bevl_sr.bevi_is = new NetworkStream(bevi_socket);
    bevl_sr.bem_extOpen_0();
return bevl_sr;
} /*method end*/
public virtual BEC_3_3_6_6_NetSocketWriter bem_writerGet_0() {
BEC_3_3_6_6_NetSocketWriter bevl_sw = null;
bevl_sw = (BEC_3_3_6_6_NetSocketWriter) (new BEC_3_3_6_6_NetSocketWriter()).bem_new_0();

    bevl_sw.bevi_os = new NetworkStream(bevi_socket);
    bevl_sw.bem_extOpen_0();
return bevl_sw;
} /*method end*/
public virtual BEC_2_3_6_NetSocket bem_new_2(BEC_2_4_6_TextString beva_host, BEC_2_4_3_MathInt beva_port) {

    IPHostEntry ipHostInfo = Dns.Resolve(beva_host.bems_toCsString());
    IPAddress ipAddress = ipHostInfo.AddressList[0];
    IPEndPoint remoteEP = new IPEndPoint(ipAddress,beva_port.bevi_int);

    bevi_socket = new Socket(AddressFamily.InterNetwork, 
        SocketType.Stream, ProtocolType.Tcp );
    bevi_socket.Connect(remoteEP);
    return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {760, 771, 772, 776, 787, 788};
public static new int[] bevs_smnlec
 = new int[] {24, 27, 28, 32, 35, 36};
/* BEGIN LINEINFO 
assign 1 760 24
new 0 760 24
extOpen 0 771 27
return 1 772 28
assign 1 776 32
new 0 776 32
extOpen 0 787 35
return 1 788 36
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1253246070: return bem_create_0();
case 1014225644: return bem_echo_0();
case -1882364243: return bem_many_0();
case -628560707: return bem_toAny_0();
case -2123848647: return bem_fieldNamesGet_0();
case 770834928: return bem_serializeContents_0();
case 1297175099: return bem_fieldIteratorGet_0();
case 1470091628: return bem_writerGet_0();
case -753894116: return bem_new_0();
case -1074341902: return bem_print_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -1138072028: return bem_tagGet_0();
case 1089607414: return bem_readerGet_0();
case 844225351: return bem_classNameGet_0();
case -2083934905: return bem_copy_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 80244442: return bem_toString_0();
case -2131387379: return bem_iteratorGet_0();
case -1625648722: return bem_once_0();
case -1194289304: return bem_serializeToString_0();
case 1165329653: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -636442813: return bem_def_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1551438146: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_3_6_NetSocket_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_3_6_NetSocket_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_6_NetSocket();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_inst = (BEC_2_3_6_NetSocket) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_type;
}
}
}
