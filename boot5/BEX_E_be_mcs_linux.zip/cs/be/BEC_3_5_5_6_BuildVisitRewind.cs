namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_6_BuildVisitRewind : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
static BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_1, 11));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_2, 2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x5F,0x30};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_3, 2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_6, 27));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_8, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_9, 13));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_10 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_10, 17));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_11 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitRewind_bels_11, 10));
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_12 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;

public static new BET_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;

public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_79_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_83_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_86_tmpany_phold = null;
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 349 */ {
bevt_12_tmpany_phold = beva_node.bem_heldGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-996291770);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 349 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 349 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 349 */
 else  /* Line: 349 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 349 */ {
bevt_15_tmpany_phold = beva_node.bem_containerGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_typenameGet_0();
bevt_16_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_tmpany_phold.bevi_int == bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevt_20_tmpany_phold = beva_node.bem_containerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_heldGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-689596936);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bemd_1(1560831110, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 351 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 351 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 351 */
 else  /* Line: 351 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 351 */ {
bevt_22_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 351 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 351 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 351 */
 else  /* Line: 351 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 351 */ {
bevt_26_tmpany_phold = beva_node.bem_containedGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_firstGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(673824477);
bevt_27_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(1560831110, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 353 */ {
bevt_31_tmpany_phold = beva_node.bem_containedGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_firstGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-1714917982);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(846854502);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 353 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 353 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 353 */
 else  /* Line: 353 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 353 */ {
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-1714917982);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_tmpany_phold.bemd_0(83257762);
bevt_35_tmpany_phold = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_lastGet_0();
bevt_39_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_0;
bevt_40_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_1;
bevt_38_tmpany_phold = bevl_fgcn.bem_substring_2(bevt_39_tmpany_phold, bevt_40_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevt_38_tmpany_phold.bem_lowerValue_0();
bevt_42_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_41_tmpany_phold = bevl_fgcn.bem_substring_1(bevt_42_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_2;
bevl_fgin = bevt_36_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_tmpany_phold = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_3;
bevt_45_tmpany_phold = bevl_fgin.bem_add_1(bevt_46_tmpany_phold);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_tmpany_phold.bem_get_1(bevt_45_tmpany_phold);
if (bevl_fgms == null) {
bevt_47_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_47_tmpany_phold.bevi_bool) /* Line: 360 */ {
bevt_48_tmpany_phold = beva_node.bem_heldGet_0();
bevt_48_tmpany_phold.bemd_1(-1875649840, bevl_fgin);
bevt_49_tmpany_phold = beva_node.bem_heldGet_0();
bevt_51_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_4;
bevt_50_tmpany_phold = bevl_fgin.bem_add_1(bevt_51_tmpany_phold);
bevt_49_tmpany_phold.bemd_1(542517897, bevt_50_tmpany_phold);
} /* Line: 363 */
} /* Line: 360 */
} /* Line: 353 */
} /* Line: 351 */
bevt_53_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_54_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_tmpany_phold.bevi_int == bevt_54_tmpany_phold.bevi_int) {
bevt_52_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_52_tmpany_phold.bevi_bool) /* Line: 368 */ {
bevp_inClass = beva_node;
bevt_55_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_tmpany_phold.bemd_0(83257762);
bevt_56_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_tmpany_phold.bemd_0(301369084);
} /* Line: 371 */
bevt_58_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_59_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_tmpany_phold.bevi_int == bevt_59_tmpany_phold.bevi_int) {
bevt_57_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_57_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 375 */
 else  /* Line: 373 */ {
bevt_61_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_62_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_61_tmpany_phold.bevi_int == bevt_62_tmpany_phold.bevi_int) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 376 */ {
bevt_64_tmpany_phold = beva_node.bem_heldGet_0();
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-2088196826);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 376 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 376 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 376 */
 else  /* Line: 376 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 376 */ {
bevt_66_tmpany_phold = beva_node.bem_heldGet_0();
bevt_65_tmpany_phold = bevt_66_tmpany_phold.bemd_0(510108416);
bevt_67_tmpany_phold = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(-1734148013, bevt_65_tmpany_phold, bevt_67_tmpany_phold);
bevt_69_tmpany_phold = beva_node.bem_heldGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_0(510108416);
bevl_ll = bevp_rmap.bemd_1(2122005988, bevt_68_tmpany_phold);
if (bevl_ll == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 379 */ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = beva_node.bem_heldGet_0();
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(510108416);
bevp_rmap.bemd_2(-1734148013, bevt_71_tmpany_phold, bevl_ll);
} /* Line: 381 */
bevl_ll.bemd_1(-809802935, beva_node);
} /* Line: 383 */
 else  /* Line: 373 */ {
bevt_74_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_75_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_tmpany_phold.bevi_int == bevt_75_tmpany_phold.bevi_int) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_77_tmpany_phold = beva_node.bem_containerGet_0();
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 384 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 384 */
 else  /* Line: 384 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 384 */ {
bevt_80_tmpany_phold = beva_node.bem_containerGet_0();
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_containerGet_0();
if (bevt_79_tmpany_phold == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 384 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 384 */
 else  /* Line: 384 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 384 */ {
bevt_84_tmpany_phold = beva_node.bem_containerGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bem_containerGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_typenameGet_0();
bevt_85_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_tmpany_phold.bevi_int == bevt_85_tmpany_phold.bevi_int) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 384 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 384 */
 else  /* Line: 384 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 384 */ {
bem_processTmps_0();
} /* Line: 386 */
} /* Line: 373 */
} /* Line: 373 */
bevt_86_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_86_tmpany_phold;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_41_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_84_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
 /* Line: 400 */ {
if (((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool) /* Line: 400 */ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(2059934062);
while (true)
 /* Line: 402 */ {
bevt_9_tmpany_phold = bevl_i.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 402 */ {
bevl_nv = bevl_i.bemd_0(1538356292);
bevt_11_tmpany_phold = bevl_nv.bemd_0(846854502);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(695021271);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 405 */ {
bevl_nvname = bevl_nv.bemd_0(510108416);
bevl_ll = bevp_rmap.bemd_1(2122005988, bevl_nvname);
bevt_0_tmpany_loop = bevl_ll.bemd_0(1714059697);
while (true)
 /* Line: 410 */ {
bevt_12_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 410 */ {
bevl_k = bevt_0_tmpany_loop.bemd_0(1538356292);
bevt_13_tmpany_phold = bevl_k.bemd_0(947511164);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevt_16_tmpany_phold = bevl_k.bemd_0(632535565);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(673824477);
bevt_17_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bemd_1(1560831110, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 411 */
 else  /* Line: 411 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 411 */ {
bevt_21_tmpany_phold = bevl_k.bemd_0(632535565);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-1714917982);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-689596936);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_4));
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(1560831110, bevt_22_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 411 */
 else  /* Line: 411 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 411 */ {
bevt_26_tmpany_phold = bevl_k.bemd_0(632535565);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_0(1086579101);
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(673824477);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(1560831110, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 411 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 411 */
 else  /* Line: 411 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 411 */ {
bevt_28_tmpany_phold = bevl_k.bemd_0(632535565);
bevl_tcall = bevt_28_tmpany_phold.bemd_0(1086579101);
bevl_targNp = null;
bevt_31_tmpany_phold = bevl_tcall.bemd_0(-1714917982);
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bemd_0(33920432);
if (bevt_30_tmpany_phold == null) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevt_32_tmpany_phold = bevl_tcall.bemd_0(-1714917982);
bevl_targNp = bevt_32_tmpany_phold.bemd_0(33920432);
} /* Line: 416 */
 else  /* Line: 417 */ {
bevt_33_tmpany_phold = bevl_tcall.bemd_0(1663291856);
bevl_targ = bevt_33_tmpany_phold.bemd_0(-1865033616);
bevt_35_tmpany_phold = bevl_targ.bemd_0(-1714917982);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_0(-44110333);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 422 */ {
bevl_tany = bevl_targ.bemd_0(-1714917982);
} /* Line: 423 */
 else  /* Line: 424 */ {
bevt_37_tmpany_phold = bevp_inClassSyn.bemd_0(-807419237);
bevt_39_tmpany_phold = bevl_targ.bemd_0(-1714917982);
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_0(510108416);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_1(2122005988, bevt_38_tmpany_phold);
bevl_tany = bevt_36_tmpany_phold.bemd_0(-1580567476);
} /* Line: 425 */
bevt_40_tmpany_phold = bevl_tany.bemd_0(846854502);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 428 */ {
bevl_targNp = bevl_tany.bemd_0(83257762);
} /* Line: 429 */
} /* Line: 428 */
if (bevl_targNp == null) {
bevt_41_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_41_tmpany_phold.bevi_bool) /* Line: 432 */ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_44_tmpany_phold = bevl_tcall.bemd_0(-1714917982);
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_0(510108416);
bevl_mtdc = bevt_42_tmpany_phold.bem_get_1(bevt_43_tmpany_phold);
if (bevl_mtdc == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 436 */ {
bevl_oany = bevl_mtdc.bemd_0(-427007633);
if (bevl_oany == null) {
bevt_46_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevt_47_tmpany_phold = bevl_oany.bemd_0(846854502);
if (((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 439 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 439 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 439 */
 else  /* Line: 439 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 439 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_tmpany_phold = bevl_oany.bemd_0(-862585246);
if (((BEC_2_5_4_LogicBool) bevt_48_tmpany_phold).bevi_bool) /* Line: 442 */ {
bevl_nv.bemd_1(-823985373, bevl_targNp);
} /* Line: 443 */
 else  /* Line: 444 */ {
bevt_49_tmpany_phold = bevl_oany.bemd_0(83257762);
bevl_nv.bemd_1(-823985373, bevt_49_tmpany_phold);
} /* Line: 445 */
bevt_50_tmpany_phold = bevl_oany.bemd_0(846854502);
bevl_nv.bemd_1(666612066, bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bevp_inClass.bemd_0(-1714917982);
bevt_52_tmpany_phold = bevl_nv.bemd_0(83257762);
bevt_51_tmpany_phold.bemd_1(1441768704, bevt_52_tmpany_phold);
bevt_55_tmpany_phold = bevl_nv.bemd_0(83257762);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(-1673560399);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_1(1560831110, bevt_56_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_53_tmpany_phold).bevi_bool) /* Line: 449 */ {
bevt_58_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_5;
bevt_59_tmpany_phold = bevl_oany.bemd_0(-862585246);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevt_59_tmpany_phold);
bevt_57_tmpany_phold.bem_print_0();
} /* Line: 449 */
} /* Line: 449 */
} /* Line: 439 */
 else  /* Line: 436 */ {
bevt_62_tmpany_phold = bevl_tcall.bemd_0(-1714917982);
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(-689596936);
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_7));
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_1(-502649276, bevt_63_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 451 */ {
bevt_64_tmpany_phold = bevl_syn.bem_mtdMapGet_0();
bevt_65_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_6;
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_tmpany_phold.bem_get_1(bevt_65_tmpany_phold);
if (bevl_fcms == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_69_tmpany_phold = bevl_fcms.bem_originGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_toString_0();
bevt_70_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_7;
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_notEquals_1(bevt_70_tmpany_phold);
if (bevt_67_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 453 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 453 */
 else  /* Line: 453 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 453 */ {
bevt_71_tmpany_phold = bevl_tcall.bemd_0(-1714917982);
bevt_72_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_71_tmpany_phold.bemd_1(-1026391344, bevt_72_tmpany_phold);
} /* Line: 454 */
 else  /* Line: 455 */ {
bevt_77_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_8;
bevt_79_tmpany_phold = bevl_tcall.bemd_0(-1714917982);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(510108416);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bem_add_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitRewind_bevo_9;
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bem_add_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = bevl_targNp.bemd_0(-1673560399);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bem_add_1(bevt_81_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_tmpany_phold, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_tmpany_phold);
} /* Line: 456 */
} /* Line: 453 */
} /* Line: 436 */
} /* Line: 436 */
} /* Line: 432 */
 else  /* Line: 411 */ {
bevt_82_tmpany_phold = bevl_k.bemd_0(947511164);
if (((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevt_85_tmpany_phold = bevl_k.bemd_0(632535565);
bevt_84_tmpany_phold = bevt_85_tmpany_phold.bemd_0(673824477);
bevt_86_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_83_tmpany_phold = bevt_84_tmpany_phold.bemd_1(1560831110, bevt_86_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_83_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_90_tmpany_phold = bevl_k.bemd_0(632535565);
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_0(-1714917982);
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bemd_0(-689596936);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_12));
bevt_87_tmpany_phold = bevt_88_tmpany_phold.bemd_1(1560831110, bevt_91_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_87_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_95_tmpany_phold = bevl_k.bemd_0(632535565);
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_0(1086579101);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(673824477);
bevt_96_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_1(1560831110, bevt_96_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 462 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 462 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 462 */
 else  /* Line: 462 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 462 */ {
bevt_98_tmpany_phold = bevl_k.bemd_0(632535565);
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_0(1086579101);
bevl_targ = bevt_97_tmpany_phold.bemd_0(-1714917982);
bevt_99_tmpany_phold = bevl_targ.bemd_0(846854502);
if (((BEC_2_5_4_LogicBool) bevt_99_tmpany_phold).bevi_bool) /* Line: 465 */ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_tmpany_phold = bevl_targ.bemd_0(846854502);
bevl_nv.bemd_1(666612066, bevt_100_tmpany_phold);
bevt_101_tmpany_phold = bevl_targ.bemd_0(83257762);
bevl_nv.bemd_1(-823985373, bevt_101_tmpany_phold);
} /* Line: 470 */
} /* Line: 465 */
} /* Line: 411 */
} /* Line: 411 */
 else  /* Line: 410 */ {
break;
} /* Line: 410 */
} /* Line: 410 */
} /* Line: 410 */
} /* Line: 405 */
 else  /* Line: 402 */ {
break;
} /* Line: 402 */
} /* Line: 402 */
} /* Line: 402 */
 else  /* Line: 400 */ {
break;
} /* Line: 400 */
} /* Line: 400 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() {
return bevp_tvmap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGetDirect_0() {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tvmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tvmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() {
return bevp_rmap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGetDirect_0() {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rmap = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGetDirect_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClass = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClass = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGetDirect_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGetDirect_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassSyn = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {349, 349, 349, 349, 349, 349, 0, 0, 0, 351, 351, 351, 351, 351, 351, 351, 351, 351, 351, 0, 0, 0, 351, 0, 0, 0, 353, 353, 353, 353, 353, 353, 353, 353, 353, 0, 0, 0, 354, 354, 354, 354, 355, 355, 356, 356, 356, 356, 356, 356, 356, 356, 356, 358, 359, 359, 359, 359, 360, 360, 362, 362, 363, 363, 363, 363, 368, 368, 368, 368, 369, 370, 370, 371, 371, 373, 373, 373, 373, 374, 375, 376, 376, 376, 376, 376, 376, 0, 0, 0, 377, 377, 377, 377, 378, 378, 378, 379, 379, 380, 381, 381, 381, 383, 384, 384, 384, 384, 384, 384, 384, 0, 0, 0, 384, 384, 384, 384, 0, 0, 0, 384, 384, 384, 384, 384, 384, 0, 0, 0, 386, 388, 388, 392, 401, 402, 402, 403, 405, 405, 408, 409, 410, 0, 410, 410, 411, 411, 411, 411, 411, 0, 0, 0, 411, 411, 411, 411, 411, 0, 0, 0, 411, 411, 411, 411, 411, 0, 0, 0, 413, 413, 414, 415, 415, 415, 415, 416, 416, 418, 418, 422, 422, 423, 425, 425, 425, 425, 425, 428, 429, 432, 432, 434, 435, 435, 435, 435, 436, 436, 438, 439, 439, 439, 0, 0, 0, 440, 442, 443, 445, 445, 447, 447, 448, 448, 448, 449, 449, 449, 449, 449, 449, 449, 449, 451, 451, 451, 451, 452, 452, 452, 453, 453, 453, 453, 453, 453, 0, 0, 0, 454, 454, 454, 456, 456, 456, 456, 456, 456, 456, 456, 456, 456, 462, 462, 462, 462, 462, 0, 0, 0, 462, 462, 462, 462, 462, 0, 0, 0, 462, 462, 462, 462, 462, 0, 0, 0, 463, 463, 463, 465, 467, 469, 469, 470, 470, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {139, 140, 141, 146, 147, 148, 150, 153, 157, 160, 161, 162, 163, 168, 169, 170, 171, 172, 173, 175, 178, 182, 185, 187, 190, 194, 197, 198, 199, 200, 201, 203, 204, 205, 206, 208, 211, 215, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 243, 244, 245, 246, 247, 248, 249, 254, 255, 256, 261, 262, 263, 264, 265, 266, 268, 269, 270, 275, 276, 277, 280, 281, 282, 287, 288, 289, 291, 294, 298, 301, 302, 303, 304, 305, 306, 307, 308, 313, 314, 315, 316, 317, 319, 322, 323, 324, 329, 330, 331, 336, 337, 340, 344, 347, 348, 349, 354, 355, 358, 362, 365, 366, 367, 368, 369, 374, 375, 378, 382, 385, 389, 390, 509, 513, 514, 517, 519, 520, 521, 523, 524, 525, 525, 528, 530, 531, 533, 534, 535, 536, 538, 541, 545, 548, 549, 550, 551, 552, 554, 557, 561, 564, 565, 566, 567, 568, 570, 573, 577, 580, 581, 582, 583, 584, 585, 590, 591, 592, 595, 596, 597, 598, 600, 603, 604, 605, 606, 607, 609, 611, 614, 619, 620, 621, 622, 623, 624, 625, 630, 631, 632, 637, 638, 640, 643, 647, 650, 651, 653, 656, 657, 659, 660, 661, 662, 663, 664, 665, 666, 667, 669, 670, 671, 672, 677, 678, 679, 680, 682, 683, 684, 685, 690, 691, 692, 693, 694, 696, 699, 703, 706, 707, 708, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 727, 729, 730, 731, 732, 734, 737, 741, 744, 745, 746, 747, 748, 750, 753, 757, 760, 761, 762, 763, 764, 766, 769, 773, 776, 777, 778, 779, 781, 782, 783, 784, 785, 808, 811, 814, 818, 822, 825, 828, 832, 836, 839, 842, 846, 850, 853, 856, 860, 864, 867, 870, 874, 878, 881, 884, 888, 892, 895, 898, 902};
/* BEGIN LINEINFO 
assign 1 349 139
typenameGet 0 349 139
assign 1 349 140
CALLGet 0 349 140
assign 1 349 141
equals 1 349 146
assign 1 349 147
heldGet 0 349 147
assign 1 349 148
wasForeachGennedGet 0 349 148
assign 1 0 150
assign 1 0 153
assign 1 0 157
assign 1 351 160
containerGet 0 351 160
assign 1 351 161
typenameGet 0 351 161
assign 1 351 162
CALLGet 0 351 162
assign 1 351 163
equals 1 351 168
assign 1 351 169
containerGet 0 351 169
assign 1 351 170
heldGet 0 351 170
assign 1 351 171
orgNameGet 0 351 171
assign 1 351 172
new 0 351 172
assign 1 351 173
equals 1 351 173
assign 1 0 175
assign 1 0 178
assign 1 0 182
assign 1 351 185
isSecondGet 0 351 185
assign 1 0 187
assign 1 0 190
assign 1 0 194
assign 1 353 197
containedGet 0 353 197
assign 1 353 198
firstGet 0 353 198
assign 1 353 199
typenameGet 0 353 199
assign 1 353 200
VARGet 0 353 200
assign 1 353 201
equals 1 353 201
assign 1 353 203
containedGet 0 353 203
assign 1 353 204
firstGet 0 353 204
assign 1 353 205
heldGet 0 353 205
assign 1 353 206
isTypedGet 0 353 206
assign 1 0 208
assign 1 0 211
assign 1 0 215
assign 1 354 218
containedGet 0 354 218
assign 1 354 219
firstGet 0 354 219
assign 1 354 220
heldGet 0 354 220
assign 1 354 221
namepathGet 0 354 221
assign 1 355 222
stepsGet 0 355 222
assign 1 355 223
lastGet 0 355 223
assign 1 356 224
new 0 356 224
assign 1 356 225
new 0 356 225
assign 1 356 226
substring 2 356 226
assign 1 356 227
lowerValue 0 356 227
assign 1 356 228
new 0 356 228
assign 1 356 229
substring 1 356 229
assign 1 356 230
add 1 356 230
assign 1 356 231
new 0 356 231
assign 1 356 232
add 1 356 232
assign 1 358 233
getSynNp 1 358 233
assign 1 359 234
mtdMapGet 0 359 234
assign 1 359 235
new 0 359 235
assign 1 359 236
add 1 359 236
assign 1 359 237
get 1 359 237
assign 1 360 238
def 1 360 243
assign 1 362 244
heldGet 0 362 244
orgNameSet 1 362 245
assign 1 363 246
heldGet 0 363 246
assign 1 363 247
new 0 363 247
assign 1 363 248
add 1 363 248
nameSet 1 363 249
assign 1 368 254
typenameGet 0 368 254
assign 1 368 255
CLASSGet 0 368 255
assign 1 368 256
equals 1 368 261
assign 1 369 262
assign 1 370 263
heldGet 0 370 263
assign 1 370 264
namepathGet 0 370 264
assign 1 371 265
heldGet 0 371 265
assign 1 371 266
synGet 0 371 266
assign 1 373 268
typenameGet 0 373 268
assign 1 373 269
METHODGet 0 373 269
assign 1 373 270
equals 1 373 275
assign 1 374 276
new 0 374 276
assign 1 375 277
new 0 375 277
assign 1 376 280
typenameGet 0 376 280
assign 1 376 281
VARGet 0 376 281
assign 1 376 282
equals 1 376 287
assign 1 376 288
heldGet 0 376 288
assign 1 376 289
autoTypeGet 0 376 289
assign 1 0 291
assign 1 0 294
assign 1 0 298
assign 1 377 301
heldGet 0 377 301
assign 1 377 302
nameGet 0 377 302
assign 1 377 303
heldGet 0 377 303
put 2 377 304
assign 1 378 305
heldGet 0 378 305
assign 1 378 306
nameGet 0 378 306
assign 1 378 307
get 1 378 307
assign 1 379 308
undef 1 379 313
assign 1 380 314
new 0 380 314
assign 1 381 315
heldGet 0 381 315
assign 1 381 316
nameGet 0 381 316
put 2 381 317
addValue 1 383 319
assign 1 384 322
typenameGet 0 384 322
assign 1 384 323
RBRACESGet 0 384 323
assign 1 384 324
equals 1 384 329
assign 1 384 330
containerGet 0 384 330
assign 1 384 331
def 1 384 336
assign 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 384 347
containerGet 0 384 347
assign 1 384 348
containerGet 0 384 348
assign 1 384 349
def 1 384 354
assign 1 0 355
assign 1 0 358
assign 1 0 362
assign 1 384 365
containerGet 0 384 365
assign 1 384 366
containerGet 0 384 366
assign 1 384 367
typenameGet 0 384 367
assign 1 384 368
METHODGet 0 384 368
assign 1 384 369
equals 1 384 374
assign 1 0 375
assign 1 0 378
assign 1 0 382
processTmps 0 386 385
assign 1 388 389
nextDescendGet 0 388 389
return 1 388 390
assign 1 392 509
new 0 392 509
assign 1 401 513
new 0 401 513
assign 1 402 514
valueIteratorGet 0 402 514
assign 1 402 517
hasNextGet 0 402 517
assign 1 403 519
nextGet 0 403 519
assign 1 405 520
isTypedGet 0 405 520
assign 1 405 521
not 0 405 521
assign 1 408 523
nameGet 0 408 523
assign 1 409 524
get 1 409 524
assign 1 410 525
iteratorGet 0 0 525
assign 1 410 528
hasNextGet 0 410 528
assign 1 410 530
nextGet 0 410 530
assign 1 411 531
isFirstGet 0 411 531
assign 1 411 533
containerGet 0 411 533
assign 1 411 534
typenameGet 0 411 534
assign 1 411 535
CALLGet 0 411 535
assign 1 411 536
equals 1 411 536
assign 1 0 538
assign 1 0 541
assign 1 0 545
assign 1 411 548
containerGet 0 411 548
assign 1 411 549
heldGet 0 411 549
assign 1 411 550
orgNameGet 0 411 550
assign 1 411 551
new 0 411 551
assign 1 411 552
equals 1 411 552
assign 1 0 554
assign 1 0 557
assign 1 0 561
assign 1 411 564
containerGet 0 411 564
assign 1 411 565
secondGet 0 411 565
assign 1 411 566
typenameGet 0 411 566
assign 1 411 567
CALLGet 0 411 567
assign 1 411 568
equals 1 411 568
assign 1 0 570
assign 1 0 573
assign 1 0 577
assign 1 413 580
containerGet 0 413 580
assign 1 413 581
secondGet 0 413 581
assign 1 414 582
assign 1 415 583
heldGet 0 415 583
assign 1 415 584
newNpGet 0 415 584
assign 1 415 585
def 1 415 590
assign 1 416 591
heldGet 0 416 591
assign 1 416 592
newNpGet 0 416 592
assign 1 418 595
containedGet 0 418 595
assign 1 418 596
firstGet 0 418 596
assign 1 422 597
heldGet 0 422 597
assign 1 422 598
isDeclaredGet 0 422 598
assign 1 423 600
heldGet 0 423 600
assign 1 425 603
ptyMapGet 0 425 603
assign 1 425 604
heldGet 0 425 604
assign 1 425 605
nameGet 0 425 605
assign 1 425 606
get 1 425 606
assign 1 425 607
memSynGet 0 425 607
assign 1 428 609
isTypedGet 0 428 609
assign 1 429 611
namepathGet 0 429 611
assign 1 432 614
def 1 432 619
assign 1 434 620
getSynNp 1 434 620
assign 1 435 621
mtdMapGet 0 435 621
assign 1 435 622
heldGet 0 435 622
assign 1 435 623
nameGet 0 435 623
assign 1 435 624
get 1 435 624
assign 1 436 625
def 1 436 630
assign 1 438 631
rsynGet 0 438 631
assign 1 439 632
def 1 439 637
assign 1 439 638
isTypedGet 0 439 638
assign 1 0 640
assign 1 0 643
assign 1 0 647
assign 1 440 650
new 0 440 650
assign 1 442 651
isSelfGet 0 442 651
namepathSet 1 443 653
assign 1 445 656
namepathGet 0 445 656
namepathSet 1 445 657
assign 1 447 659
isTypedGet 0 447 659
isTypedSet 1 447 660
assign 1 448 661
heldGet 0 448 661
assign 1 448 662
namepathGet 0 448 662
addUsed 1 448 663
assign 1 449 664
namepathGet 0 449 664
assign 1 449 665
toString 0 449 665
assign 1 449 666
new 0 449 666
assign 1 449 667
equals 1 449 667
assign 1 449 669
new 0 449 669
assign 1 449 670
isSelfGet 0 449 670
assign 1 449 671
add 1 449 671
print 0 449 672
assign 1 451 677
heldGet 0 451 677
assign 1 451 678
orgNameGet 0 451 678
assign 1 451 679
new 0 451 679
assign 1 451 680
notEquals 1 451 680
assign 1 452 682
mtdMapGet 0 452 682
assign 1 452 683
new 0 452 683
assign 1 452 684
get 1 452 684
assign 1 453 685
def 1 453 690
assign 1 453 691
originGet 0 453 691
assign 1 453 692
toString 0 453 692
assign 1 453 693
new 0 453 693
assign 1 453 694
notEquals 1 453 694
assign 1 0 696
assign 1 0 699
assign 1 0 703
assign 1 454 706
heldGet 0 454 706
assign 1 454 707
new 0 454 707
isForwardSet 1 454 708
assign 1 456 711
new 0 456 711
assign 1 456 712
heldGet 0 456 712
assign 1 456 713
nameGet 0 456 713
assign 1 456 714
add 1 456 714
assign 1 456 715
new 0 456 715
assign 1 456 716
add 1 456 716
assign 1 456 717
toString 0 456 717
assign 1 456 718
add 1 456 718
assign 1 456 719
new 2 456 719
throw 1 456 720
assign 1 462 727
isFirstGet 0 462 727
assign 1 462 729
containerGet 0 462 729
assign 1 462 730
typenameGet 0 462 730
assign 1 462 731
CALLGet 0 462 731
assign 1 462 732
equals 1 462 732
assign 1 0 734
assign 1 0 737
assign 1 0 741
assign 1 462 744
containerGet 0 462 744
assign 1 462 745
heldGet 0 462 745
assign 1 462 746
orgNameGet 0 462 746
assign 1 462 747
new 0 462 747
assign 1 462 748
equals 1 462 748
assign 1 0 750
assign 1 0 753
assign 1 0 757
assign 1 462 760
containerGet 0 462 760
assign 1 462 761
secondGet 0 462 761
assign 1 462 762
typenameGet 0 462 762
assign 1 462 763
VARGet 0 462 763
assign 1 462 764
equals 1 462 764
assign 1 0 766
assign 1 0 769
assign 1 0 773
assign 1 463 776
containerGet 0 463 776
assign 1 463 777
secondGet 0 463 777
assign 1 463 778
heldGet 0 463 778
assign 1 465 779
isTypedGet 0 465 779
assign 1 467 781
new 0 467 781
assign 1 469 782
isTypedGet 0 469 782
isTypedSet 1 469 783
assign 1 470 784
namepathGet 0 470 784
namepathSet 1 470 785
return 1 0 808
return 1 0 811
assign 1 0 814
assign 1 0 818
return 1 0 822
return 1 0 825
assign 1 0 828
assign 1 0 832
return 1 0 836
return 1 0 839
assign 1 0 842
assign 1 0 846
return 1 0 850
return 1 0 853
assign 1 0 856
assign 1 0 860
return 1 0 864
return 1 0 867
assign 1 0 870
assign 1 0 874
return 1 0 878
return 1 0 881
assign 1 0 884
assign 1 0 888
return 1 0 892
return 1 0 895
assign 1 0 898
assign 1 0 902
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -172634187: return bem_once_0();
case 372040847: return bem_constGet_0();
case 1726245742: return bem_hashGet_0();
case 1142974282: return bem_inClassGet_0();
case -366187484: return bem_processTmps_0();
case 2038100065: return bem_inClassSynGetDirect_0();
case -40573534: return bem_ntypesGetDirect_0();
case -1070579648: return bem_rmapGetDirect_0();
case -1914264312: return bem_serializationIteratorGet_0();
case -419692225: return bem_buildGet_0();
case -2097142996: return bem_many_0();
case 782585161: return bem_deserializeClassNameGet_0();
case 1747938195: return bem_nlGet_0();
case -649577692: return bem_inClassGetDirect_0();
case -1336547559: return bem_copy_0();
case -717090637: return bem_inClassSynGet_0();
case -1983538737: return bem_rmapGet_0();
case -92876860: return bem_echo_0();
case 376318330: return bem_toAny_0();
case -1673560399: return bem_toString_0();
case -870016446: return bem_print_0();
case -939140314: return bem_sourceFileNameGet_0();
case -1677382389: return bem_inClassNpGetDirect_0();
case -1460274649: return bem_transGetDirect_0();
case -997138031: return bem_create_0();
case 1396075820: return bem_buildGetDirect_0();
case 1924878947: return bem_serializeContents_0();
case 1684359161: return bem_classNameGet_0();
case -351518414: return bem_emitterGetDirect_0();
case 1049031508: return bem_transGet_0();
case 2022591848: return bem_new_0();
case 1714059697: return bem_iteratorGet_0();
case 949430454: return bem_inClassNpGet_0();
case -440540280: return bem_ntypesGet_0();
case 1892440434: return bem_serializeToString_0();
case -188774864: return bem_fieldNamesGet_0();
case 123890466: return bem_tagGet_0();
case -1269496711: return bem_tvmapGet_0();
case -1845286658: return bem_nlGetDirect_0();
case -1025695402: return bem_tvmapGetDirect_0();
case 1291754014: return bem_fieldIteratorGet_0();
case -147628840: return bem_emitterGet_0();
case -1772944905: return bem_constGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -948460336: return bem_ntypesSet_1(bevd_0);
case -502649276: return bem_notEquals_1(bevd_0);
case 1687349246: return bem_transSetDirect_1(bevd_0);
case -1807927146: return bem_buildSetDirect_1(bevd_0);
case -1386441501: return bem_ntypesSetDirect_1(bevd_0);
case 2089083830: return bem_inClassNpSet_1(bevd_0);
case -1860558101: return bem_sameType_1(bevd_0);
case 1977164141: return bem_nlSet_1(bevd_0);
case 507417053: return bem_emitterSetDirect_1(bevd_0);
case 1560831110: return bem_equals_1(bevd_0);
case -1783619507: return bem_sameClass_1(bevd_0);
case 2024151813: return bem_otherClass_1(bevd_0);
case -161371104: return bem_inClassSynSet_1(bevd_0);
case -1694384494: return bem_end_1(bevd_0);
case 1404691116: return bem_constSet_1(bevd_0);
case -1139805373: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2108385190: return bem_undefined_1(bevd_0);
case -851389461: return bem_inClassSynSetDirect_1(bevd_0);
case -628251942: return bem_defined_1(bevd_0);
case -1259222473: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -9743810: return bem_sameObject_1(bevd_0);
case -665667897: return bem_constSetDirect_1(bevd_0);
case -1299087238: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 906586952: return bem_transSet_1(bevd_0);
case 1802133619: return bem_undef_1(bevd_0);
case 275918344: return bem_rmapSetDirect_1(bevd_0);
case 636524381: return bem_begin_1(bevd_0);
case -257411874: return bem_buildSet_1(bevd_0);
case -453683584: return bem_inClassSet_1(bevd_0);
case -148425027: return bem_otherType_1(bevd_0);
case -1241822778: return bem_tvmapSetDirect_1(bevd_0);
case 956396799: return bem_inClassSetDirect_1(bevd_0);
case -1554389120: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 115059227: return bem_tvmapSet_1(bevd_0);
case -886713353: return bem_nlSetDirect_1(bevd_0);
case -1994787564: return bem_def_1(bevd_0);
case 921396152: return bem_copyTo_1(bevd_0);
case 1791316855: return bem_inClassNpSetDirect_1(bevd_0);
case 1566667222: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1969068127: return bem_emitterSet_1(bevd_0);
case 1131000455: return bem_rmapSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -402932836: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1915330817: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -518118155: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -355453886: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1141599202: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1078652527: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1443758120: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;
}
}
}
