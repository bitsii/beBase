namespace be {
/* IO:File: source/build/Pass12.be */
public sealed class BEC_3_5_5_6_BuildVisitRewind : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitRewind() { }
static BEC_3_5_5_6_BuildVisitRewind() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x52,0x65,0x77,0x69,0x6E,0x64};
private static byte[] becc_BEC_3_5_5_6_BuildVisitRewind_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x32,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_0 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_1 = {0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x47,0x65,0x74};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_2 = {0x5F,0x30};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_3 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_4 = {0x46,0x4F,0x55,0x4E,0x44,0x20,0x41,0x20,0x53,0x45,0x4C,0x46,0x20,0x54,0x4D,0x50,0x56,0x41,0x52,0x20,0x72,0x65,0x77,0x69,0x6E,0x64,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_5 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_6 = {0x66,0x6F,0x72,0x77,0x61,0x72,0x64,0x43,0x61,0x6C,0x6C,0x5F,0x32};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_7 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_8 = {0x28,0x41,0x29,0x20,0x4E,0x6F,0x20,0x73,0x75,0x63,0x68,0x20,0x63,0x61,0x6C,0x6C,0x20};
private static byte[] bece_BEC_3_5_5_6_BuildVisitRewind_bels_9 = {0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
public static new BEC_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;

public static new BET_3_5_5_6_BuildVisitRewind bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;

public BEC_2_6_6_SystemObject bevp_tvmap;
public BEC_2_6_6_SystemObject bevp_rmap;
public BEC_2_6_6_SystemObject bevp_inClass;
public BEC_2_6_6_SystemObject bevp_inClassNp;
public BEC_2_6_6_SystemObject bevp_inClassSyn;
public BEC_2_6_6_SystemObject bevp_nl;
public BEC_2_6_6_SystemObject bevp_emitter;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_8_BuildNamePath bevl_fgnp = null;
BEC_2_4_6_TextString bevl_fgcn = null;
BEC_2_4_6_TextString bevl_fgin = null;
BEC_2_5_8_BuildClassSyn bevl_fgsy = null;
BEC_2_5_6_BuildMtdSyn bevl_fgms = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_BuildNode bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_5_4_BuildNode bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_34_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_3_MathInt bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_3_MathInt bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_5_4_LogicBool bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_5_4_LogicBool bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_5_4_BuildNode bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_5_4_BuildNode bevt_79_ta_ph = null;
BEC_2_5_4_BuildNode bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_5_4_BuildNode bevt_83_ta_ph = null;
BEC_2_5_4_BuildNode bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_5_4_BuildNode bevt_86_ta_ph = null;
bevt_9_ta_ph = beva_node.bem_typenameGet_0();
bevt_10_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_9_ta_ph.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 336*/ {
bevt_12_ta_ph = beva_node.bem_heldGet_0();
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(374698518);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 336*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 336*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 336*/
 else /* Line: 336*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 336*/ {
bevt_15_ta_ph = beva_node.bem_containerGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_typenameGet_0();
bevt_16_ta_ph = bevp_ntypes.bem_CALLGet_0();
if (bevt_14_ta_ph.bevi_int == bevt_16_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 338*/ {
bevt_20_ta_ph = beva_node.bem_containerGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_heldGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(354190023);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(-575162425, bevt_21_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 338*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 338*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 338*/
 else /* Line: 338*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 338*/ {
bevt_22_ta_ph = beva_node.bem_isSecondGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 338*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 338*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 338*/
 else /* Line: 338*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 338*/ {
bevt_26_ta_ph = beva_node.bem_containedGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bem_firstGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(1755711417);
bevt_27_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(-575162425, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 340*/ {
bevt_31_ta_ph = beva_node.bem_containedGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_firstGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(1295480597);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-1442766961);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 340*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 340*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 340*/
 else /* Line: 340*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 340*/ {
bevt_34_ta_ph = beva_node.bem_containedGet_0();
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(1295480597);
bevl_fgnp = (BEC_2_5_8_BuildNamePath) bevt_32_ta_ph.bemd_0(-477657043);
bevt_35_ta_ph = bevl_fgnp.bem_stepsGet_0();
bevl_fgcn = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_lastGet_0();
bevt_39_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_40_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_38_ta_ph = bevl_fgcn.bem_substring_2(bevt_39_ta_ph, bevt_40_ta_ph);
bevt_37_ta_ph = (BEC_2_4_6_TextString) bevt_38_ta_ph.bem_lowerValue_0();
bevt_42_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_41_ta_ph = bevl_fgcn.bem_substring_1(bevt_42_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevt_41_ta_ph);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_6_BuildVisitRewind_bels_1));
bevl_fgin = bevt_36_ta_ph.bem_add_1(bevt_43_ta_ph);
bevl_fgsy = bevp_build.bem_getSynNp_1(bevl_fgnp);
bevt_44_ta_ph = bevl_fgsy.bem_mtdMapGet_0();
bevt_46_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitRewind_bels_2));
bevt_45_ta_ph = bevl_fgin.bem_add_1(bevt_46_ta_ph);
bevl_fgms = (BEC_2_5_6_BuildMtdSyn) bevt_44_ta_ph.bem_get_1(bevt_45_ta_ph);
if (bevl_fgms == null) {
bevt_47_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_47_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_47_ta_ph.bevi_bool)/* Line: 347*/ {
bevt_48_ta_ph = beva_node.bem_heldGet_0();
bevt_48_ta_ph.bemd_1(137800965, bevl_fgin);
bevt_49_ta_ph = beva_node.bem_heldGet_0();
bevt_51_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_6_BuildVisitRewind_bels_2));
bevt_50_ta_ph = bevl_fgin.bem_add_1(bevt_51_ta_ph);
bevt_49_ta_ph.bemd_1(1122223586, bevt_50_ta_ph);
} /* Line: 350*/
} /* Line: 347*/
} /* Line: 340*/
} /* Line: 338*/
bevt_53_ta_ph = beva_node.bem_typenameGet_0();
bevt_54_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_53_ta_ph.bevi_int == bevt_54_ta_ph.bevi_int) {
bevt_52_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_52_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_52_ta_ph.bevi_bool)/* Line: 355*/ {
bevp_inClass = beva_node;
bevt_55_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassNp = bevt_55_ta_ph.bemd_0(-477657043);
bevt_56_ta_ph = beva_node.bem_heldGet_0();
bevp_inClassSyn = bevt_56_ta_ph.bemd_0(511436136);
} /* Line: 358*/
bevt_58_ta_ph = beva_node.bem_typenameGet_0();
bevt_59_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_58_ta_ph.bevi_int == bevt_59_ta_ph.bevi_int) {
bevt_57_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_57_ta_ph.bevi_bool)/* Line: 360*/ {
bevp_tvmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_rmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 362*/
 else /* Line: 360*/ {
bevt_61_ta_ph = beva_node.bem_typenameGet_0();
bevt_62_ta_ph = bevp_ntypes.bem_VARGet_0();
if (bevt_61_ta_ph.bevi_int == bevt_62_ta_ph.bevi_int) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 363*/ {
bevt_64_ta_ph = beva_node.bem_heldGet_0();
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(1707307489);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 363*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 363*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 363*/
 else /* Line: 363*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 363*/ {
bevt_66_ta_ph = beva_node.bem_heldGet_0();
bevt_65_ta_ph = bevt_66_ta_ph.bemd_0(1437514936);
bevt_67_ta_ph = beva_node.bem_heldGet_0();
bevp_tvmap.bemd_2(-1373042537, bevt_65_ta_ph, bevt_67_ta_ph);
bevt_69_ta_ph = beva_node.bem_heldGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bemd_0(1437514936);
bevl_ll = bevp_rmap.bemd_1(517117201, bevt_68_ta_ph);
if (bevl_ll == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 366*/ {
bevl_ll = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_ta_ph = beva_node.bem_heldGet_0();
bevt_71_ta_ph = bevt_72_ta_ph.bemd_0(1437514936);
bevp_rmap.bemd_2(-1373042537, bevt_71_ta_ph, bevl_ll);
} /* Line: 368*/
bevl_ll.bemd_1(-1648734891, beva_node);
} /* Line: 370*/
 else /* Line: 360*/ {
bevt_74_ta_ph = beva_node.bem_typenameGet_0();
bevt_75_ta_ph = bevp_ntypes.bem_RBRACESGet_0();
if (bevt_74_ta_ph.bevi_int == bevt_75_ta_ph.bevi_int) {
bevt_73_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_73_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_77_ta_ph = beva_node.bem_containerGet_0();
if (bevt_77_ta_ph == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 371*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 371*/
 else /* Line: 371*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 371*/ {
bevt_80_ta_ph = beva_node.bem_containerGet_0();
bevt_79_ta_ph = bevt_80_ta_ph.bem_containerGet_0();
if (bevt_79_ta_ph == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 371*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 371*/
 else /* Line: 371*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 371*/ {
bevt_84_ta_ph = beva_node.bem_containerGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bem_containerGet_0();
bevt_82_ta_ph = bevt_83_ta_ph.bem_typenameGet_0();
bevt_85_ta_ph = bevp_ntypes.bem_METHODGet_0();
if (bevt_82_ta_ph.bevi_int == bevt_85_ta_ph.bevi_int) {
bevt_81_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_81_ta_ph.bevi_bool)/* Line: 371*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 371*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 371*/
 else /* Line: 371*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 371*/ {
bem_processTmps_0();
} /* Line: 373*/
} /* Line: 360*/
} /* Line: 360*/
bevt_86_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_86_ta_ph;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_processTmps_0() {
BEC_2_6_6_SystemObject bevl_foundone = null;
BEC_2_6_6_SystemObject bevl_targ = null;
BEC_2_6_6_SystemObject bevl_tany = null;
BEC_2_6_6_SystemObject bevl_tcall = null;
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_6_6_SystemObject bevl_targNp = null;
BEC_2_6_6_SystemObject bevl_mtdc = null;
BEC_2_6_6_SystemObject bevl_oany = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_nv = null;
BEC_2_6_6_SystemObject bevl_nvname = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_k = null;
BEC_2_5_6_BuildMtdSyn bevl_fcms = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_5_4_LogicBool bevt_41_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_5_4_LogicBool bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_6_6_SystemObject bevt_82_ta_ph = null;
BEC_2_6_6_SystemObject bevt_83_ta_ph = null;
BEC_2_6_6_SystemObject bevt_84_ta_ph = null;
BEC_2_6_6_SystemObject bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_6_6_SystemObject bevt_87_ta_ph = null;
BEC_2_6_6_SystemObject bevt_88_ta_ph = null;
BEC_2_6_6_SystemObject bevt_89_ta_ph = null;
BEC_2_6_6_SystemObject bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_6_6_SystemObject bevt_92_ta_ph = null;
BEC_2_6_6_SystemObject bevt_93_ta_ph = null;
BEC_2_6_6_SystemObject bevt_94_ta_ph = null;
BEC_2_6_6_SystemObject bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_6_6_SystemObject bevt_98_ta_ph = null;
BEC_2_6_6_SystemObject bevt_99_ta_ph = null;
BEC_2_6_6_SystemObject bevt_100_ta_ph = null;
BEC_2_6_6_SystemObject bevt_101_ta_ph = null;
bevl_foundone = be.BECS_Runtime.boolTrue;
while (true)
/* Line: 387*/ {
if (((BEC_2_5_4_LogicBool) bevl_foundone).bevi_bool)/* Line: 387*/ {
bevl_foundone = be.BECS_Runtime.boolFalse;
bevl_i = bevp_tvmap.bemd_0(-1417238021);
while (true)
/* Line: 389*/ {
bevt_9_ta_ph = bevl_i.bemd_0(-211510432);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 389*/ {
bevl_nv = bevl_i.bemd_0(581391667);
bevt_11_ta_ph = bevl_nv.bemd_0(-1442766961);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1340623042);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 392*/ {
bevl_nvname = bevl_nv.bemd_0(1437514936);
bevl_ll = bevp_rmap.bemd_1(517117201, bevl_nvname);
bevt_0_ta_loop = bevl_ll.bemd_0(-1653939165);
while (true)
/* Line: 397*/ {
bevt_12_ta_ph = bevt_0_ta_loop.bemd_0(-211510432);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 397*/ {
bevl_k = bevt_0_ta_loop.bemd_0(581391667);
bevt_13_ta_ph = bevl_k.bemd_0(-1469550277);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 398*/ {
bevt_16_ta_ph = bevl_k.bemd_0(-2102703130);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(1755711417);
bevt_17_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bemd_1(-575162425, bevt_17_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 398*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 398*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 398*/
 else /* Line: 398*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 398*/ {
bevt_21_ta_ph = bevl_k.bemd_0(-2102703130);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(1295480597);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(354190023);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(-575162425, bevt_22_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 398*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 398*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 398*/
 else /* Line: 398*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 398*/ {
bevt_26_ta_ph = bevl_k.bemd_0(-2102703130);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(-367837424);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_0(1755711417);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_23_ta_ph = bevt_24_ta_ph.bemd_1(-575162425, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 398*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 398*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 398*/
 else /* Line: 398*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 398*/ {
bevt_28_ta_ph = bevl_k.bemd_0(-2102703130);
bevl_tcall = bevt_28_ta_ph.bemd_0(-367837424);
bevl_targNp = null;
bevt_31_ta_ph = bevl_tcall.bemd_0(1295480597);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(1542357663);
if (bevt_30_ta_ph == null) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 402*/ {
bevt_32_ta_ph = bevl_tcall.bemd_0(1295480597);
bevl_targNp = bevt_32_ta_ph.bemd_0(1542357663);
} /* Line: 403*/
 else /* Line: 404*/ {
bevt_33_ta_ph = bevl_tcall.bemd_0(1337693140);
bevl_targ = bevt_33_ta_ph.bemd_0(1604065800);
bevt_35_ta_ph = bevl_targ.bemd_0(1295480597);
bevt_34_ta_ph = bevt_35_ta_ph.bemd_0(-1647160366);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 409*/ {
bevl_tany = bevl_targ.bemd_0(1295480597);
} /* Line: 410*/
 else /* Line: 411*/ {
bevt_37_ta_ph = bevp_inClassSyn.bemd_0(839691837);
bevt_39_ta_ph = bevl_targ.bemd_0(1295480597);
bevt_38_ta_ph = bevt_39_ta_ph.bemd_0(1437514936);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_1(517117201, bevt_38_ta_ph);
bevl_tany = bevt_36_ta_ph.bemd_0(1004094878);
} /* Line: 412*/
bevt_40_ta_ph = bevl_tany.bemd_0(-1442766961);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 415*/ {
bevl_targNp = bevl_tany.bemd_0(-477657043);
} /* Line: 416*/
} /* Line: 415*/
if (bevl_targNp == null) {
bevt_41_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_41_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_41_ta_ph.bevi_bool)/* Line: 419*/ {
bevl_syn = bevp_build.bem_getSynNp_1(bevl_targNp);
bevt_42_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_44_ta_ph = bevl_tcall.bemd_0(1295480597);
bevt_43_ta_ph = bevt_44_ta_ph.bemd_0(1437514936);
bevl_mtdc = bevt_42_ta_ph.bem_get_1(bevt_43_ta_ph);
if (bevl_mtdc == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 423*/ {
bevl_oany = bevl_mtdc.bemd_0(1490984682);
if (bevl_oany == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 426*/ {
bevt_47_ta_ph = bevl_oany.bemd_0(-1442766961);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 426*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 426*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 426*/
 else /* Line: 426*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 426*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_48_ta_ph = bevl_oany.bemd_0(-240320019);
if (((BEC_2_5_4_LogicBool) bevt_48_ta_ph).bevi_bool)/* Line: 429*/ {
bevl_nv.bemd_1(-417397329, bevl_targNp);
} /* Line: 430*/
 else /* Line: 431*/ {
bevt_49_ta_ph = bevl_oany.bemd_0(-477657043);
bevl_nv.bemd_1(-417397329, bevt_49_ta_ph);
} /* Line: 432*/
bevt_50_ta_ph = bevl_oany.bemd_0(-1442766961);
bevl_nv.bemd_1(-114530290, bevt_50_ta_ph);
bevt_51_ta_ph = bevp_inClass.bemd_0(1295480597);
bevt_52_ta_ph = bevl_nv.bemd_0(-477657043);
bevt_51_ta_ph.bemd_1(1278311978, bevt_52_ta_ph);
bevt_55_ta_ph = bevl_nv.bemd_0(-477657043);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(-893093197);
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitRewind_bels_3));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(-575162425, bevt_56_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 436*/ {
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(27, bece_BEC_3_5_5_6_BuildVisitRewind_bels_4));
bevt_59_ta_ph = bevl_oany.bemd_0(-240320019);
bevt_57_ta_ph = bevt_58_ta_ph.bem_add_1(bevt_59_ta_ph);
bevt_57_ta_ph.bem_print_0();
} /* Line: 436*/
} /* Line: 436*/
} /* Line: 426*/
 else /* Line: 423*/ {
bevt_62_ta_ph = bevl_tcall.bemd_0(1295480597);
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(354190023);
bevt_63_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_5));
bevt_60_ta_ph = bevt_61_ta_ph.bemd_1(-846997646, bevt_63_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_60_ta_ph).bevi_bool)/* Line: 438*/ {
bevt_64_ta_ph = bevl_syn.bem_mtdMapGet_0();
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_6_BuildVisitRewind_bels_6));
bevl_fcms = (BEC_2_5_6_BuildMtdSyn) bevt_64_ta_ph.bem_get_1(bevt_65_ta_ph);
if (bevl_fcms == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_69_ta_ph = bevl_fcms.bem_originGet_0();
bevt_68_ta_ph = bevt_69_ta_ph.bem_toString_0();
bevt_70_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_6_BuildVisitRewind_bels_7));
bevt_67_ta_ph = bevt_68_ta_ph.bem_notEquals_1(bevt_70_ta_ph);
if (bevt_67_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 440*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 440*/
 else /* Line: 440*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 440*/ {
bevt_71_ta_ph = bevl_tcall.bemd_0(1295480597);
bevt_72_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_71_ta_ph.bemd_1(-736916645, bevt_72_ta_ph);
} /* Line: 441*/
 else /* Line: 442*/ {
bevt_77_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_3_5_5_6_BuildVisitRewind_bels_8));
bevt_79_ta_ph = bevl_tcall.bemd_0(1295480597);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(1437514936);
bevt_76_ta_ph = bevt_77_ta_ph.bem_add_1(bevt_78_ta_ph);
bevt_80_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_6_BuildVisitRewind_bels_9));
bevt_75_ta_ph = bevt_76_ta_ph.bem_add_1(bevt_80_ta_ph);
bevt_81_ta_ph = bevl_targNp.bemd_0(-893093197);
bevt_74_ta_ph = bevt_75_ta_ph.bem_add_1(bevt_81_ta_ph);
bevt_73_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_ta_ph, bevl_tcall);
throw new be.BECS_ThrowBack(bevt_73_ta_ph);
} /* Line: 443*/
} /* Line: 440*/
} /* Line: 423*/
} /* Line: 423*/
} /* Line: 419*/
 else /* Line: 398*/ {
bevt_82_ta_ph = bevl_k.bemd_0(-1469550277);
if (((BEC_2_5_4_LogicBool) bevt_82_ta_ph).bevi_bool)/* Line: 449*/ {
bevt_85_ta_ph = bevl_k.bemd_0(-2102703130);
bevt_84_ta_ph = bevt_85_ta_ph.bemd_0(1755711417);
bevt_86_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_83_ta_ph = bevt_84_ta_ph.bemd_1(-575162425, bevt_86_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_83_ta_ph).bevi_bool)/* Line: 449*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 449*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 449*/
 else /* Line: 449*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 449*/ {
bevt_90_ta_ph = bevl_k.bemd_0(-2102703130);
bevt_89_ta_ph = bevt_90_ta_ph.bemd_0(1295480597);
bevt_88_ta_ph = bevt_89_ta_ph.bemd_0(354190023);
bevt_91_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitRewind_bels_0));
bevt_87_ta_ph = bevt_88_ta_ph.bemd_1(-575162425, bevt_91_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_87_ta_ph).bevi_bool)/* Line: 449*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 449*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 449*/
 else /* Line: 449*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 449*/ {
bevt_95_ta_ph = bevl_k.bemd_0(-2102703130);
bevt_94_ta_ph = bevt_95_ta_ph.bemd_0(-367837424);
bevt_93_ta_ph = bevt_94_ta_ph.bemd_0(1755711417);
bevt_96_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_92_ta_ph = bevt_93_ta_ph.bemd_1(-575162425, bevt_96_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_92_ta_ph).bevi_bool)/* Line: 449*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 449*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 449*/
 else /* Line: 449*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 449*/ {
bevt_98_ta_ph = bevl_k.bemd_0(-2102703130);
bevt_97_ta_ph = bevt_98_ta_ph.bemd_0(-367837424);
bevl_targ = bevt_97_ta_ph.bemd_0(1295480597);
bevt_99_ta_ph = bevl_targ.bemd_0(-1442766961);
if (((BEC_2_5_4_LogicBool) bevt_99_ta_ph).bevi_bool)/* Line: 452*/ {
bevl_foundone = be.BECS_Runtime.boolTrue;
bevt_100_ta_ph = bevl_targ.bemd_0(-1442766961);
bevl_nv.bemd_1(-114530290, bevt_100_ta_ph);
bevt_101_ta_ph = bevl_targ.bemd_0(-477657043);
bevl_nv.bemd_1(-417397329, bevt_101_ta_ph);
} /* Line: 457*/
} /* Line: 452*/
} /* Line: 398*/
} /* Line: 398*/
 else /* Line: 397*/ {
break;
} /* Line: 397*/
} /* Line: 397*/
} /* Line: 397*/
} /* Line: 392*/
 else /* Line: 389*/ {
break;
} /* Line: 389*/
} /* Line: 389*/
} /* Line: 389*/
 else /* Line: 387*/ {
break;
} /* Line: 387*/
} /* Line: 387*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGet_0() {
return bevp_tvmap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tvmapGetDirect_0() {
return bevp_tvmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tvmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_tvmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tvmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGet_0() {
return bevp_rmap;
} /*method end*/
public BEC_2_6_6_SystemObject bem_rmapGetDirect_0() {
return bevp_rmap;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_rmapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rmap = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGet_0() {
return bevp_inClass;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassGetDirect_0() {
return bevp_inClass;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClass = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClass = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassNpGetDirect_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassNp = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGet_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_inClassSynGetDirect_0() {
return bevp_inClassSyn;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_inClassSynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inClassSyn = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nl = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nl = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitRewind bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {336, 336, 336, 336, 336, 336, 0, 0, 0, 338, 338, 338, 338, 338, 338, 338, 338, 338, 338, 0, 0, 0, 338, 0, 0, 0, 340, 340, 340, 340, 340, 340, 340, 340, 340, 0, 0, 0, 341, 341, 341, 341, 342, 342, 343, 343, 343, 343, 343, 343, 343, 343, 343, 345, 346, 346, 346, 346, 347, 347, 349, 349, 350, 350, 350, 350, 355, 355, 355, 355, 356, 357, 357, 358, 358, 360, 360, 360, 360, 361, 362, 363, 363, 363, 363, 363, 363, 0, 0, 0, 364, 364, 364, 364, 365, 365, 365, 366, 366, 367, 368, 368, 368, 370, 371, 371, 371, 371, 371, 371, 371, 0, 0, 0, 371, 371, 371, 371, 0, 0, 0, 371, 371, 371, 371, 371, 371, 0, 0, 0, 373, 375, 375, 379, 388, 389, 389, 390, 392, 392, 395, 396, 397, 0, 397, 397, 398, 398, 398, 398, 398, 0, 0, 0, 398, 398, 398, 398, 398, 0, 0, 0, 398, 398, 398, 398, 398, 0, 0, 0, 400, 400, 401, 402, 402, 402, 402, 403, 403, 405, 405, 409, 409, 410, 412, 412, 412, 412, 412, 415, 416, 419, 419, 421, 422, 422, 422, 422, 423, 423, 425, 426, 426, 426, 0, 0, 0, 427, 429, 430, 432, 432, 434, 434, 435, 435, 435, 436, 436, 436, 436, 436, 436, 436, 436, 438, 438, 438, 438, 439, 439, 439, 440, 440, 440, 440, 440, 440, 0, 0, 0, 441, 441, 441, 443, 443, 443, 443, 443, 443, 443, 443, 443, 443, 449, 449, 449, 449, 449, 0, 0, 0, 449, 449, 449, 449, 449, 0, 0, 0, 449, 449, 449, 449, 449, 0, 0, 0, 450, 450, 450, 452, 454, 456, 456, 457, 457, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {126, 127, 128, 133, 134, 135, 137, 140, 144, 147, 148, 149, 150, 155, 156, 157, 158, 159, 160, 162, 165, 169, 172, 174, 177, 181, 184, 185, 186, 187, 188, 190, 191, 192, 193, 195, 198, 202, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 230, 231, 232, 233, 234, 235, 236, 241, 242, 243, 248, 249, 250, 251, 252, 253, 255, 256, 257, 262, 263, 264, 267, 268, 269, 274, 275, 276, 278, 281, 285, 288, 289, 290, 291, 292, 293, 294, 295, 300, 301, 302, 303, 304, 306, 309, 310, 311, 316, 317, 318, 323, 324, 327, 331, 334, 335, 336, 341, 342, 345, 349, 352, 353, 354, 355, 356, 361, 362, 365, 369, 372, 376, 377, 496, 500, 501, 504, 506, 507, 508, 510, 511, 512, 512, 515, 517, 518, 520, 521, 522, 523, 525, 528, 532, 535, 536, 537, 538, 539, 541, 544, 548, 551, 552, 553, 554, 555, 557, 560, 564, 567, 568, 569, 570, 571, 572, 577, 578, 579, 582, 583, 584, 585, 587, 590, 591, 592, 593, 594, 596, 598, 601, 606, 607, 608, 609, 610, 611, 612, 617, 618, 619, 624, 625, 627, 630, 634, 637, 638, 640, 643, 644, 646, 647, 648, 649, 650, 651, 652, 653, 654, 656, 657, 658, 659, 664, 665, 666, 667, 669, 670, 671, 672, 677, 678, 679, 680, 681, 683, 686, 690, 693, 694, 695, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 714, 716, 717, 718, 719, 721, 724, 728, 731, 732, 733, 734, 735, 737, 740, 744, 747, 748, 749, 750, 751, 753, 756, 760, 763, 764, 765, 766, 768, 769, 770, 771, 772, 795, 798, 801, 805, 809, 812, 815, 819, 823, 826, 829, 833, 837, 840, 843, 847, 851, 854, 857, 861, 865, 868, 871, 875, 879, 882, 885, 889};
/* BEGIN LINEINFO 
assign 1 336 126
typenameGet 0 336 126
assign 1 336 127
CALLGet 0 336 127
assign 1 336 128
equals 1 336 133
assign 1 336 134
heldGet 0 336 134
assign 1 336 135
wasForeachGennedGet 0 336 135
assign 1 0 137
assign 1 0 140
assign 1 0 144
assign 1 338 147
containerGet 0 338 147
assign 1 338 148
typenameGet 0 338 148
assign 1 338 149
CALLGet 0 338 149
assign 1 338 150
equals 1 338 155
assign 1 338 156
containerGet 0 338 156
assign 1 338 157
heldGet 0 338 157
assign 1 338 158
orgNameGet 0 338 158
assign 1 338 159
new 0 338 159
assign 1 338 160
equals 1 338 160
assign 1 0 162
assign 1 0 165
assign 1 0 169
assign 1 338 172
isSecondGet 0 338 172
assign 1 0 174
assign 1 0 177
assign 1 0 181
assign 1 340 184
containedGet 0 340 184
assign 1 340 185
firstGet 0 340 185
assign 1 340 186
typenameGet 0 340 186
assign 1 340 187
VARGet 0 340 187
assign 1 340 188
equals 1 340 188
assign 1 340 190
containedGet 0 340 190
assign 1 340 191
firstGet 0 340 191
assign 1 340 192
heldGet 0 340 192
assign 1 340 193
isTypedGet 0 340 193
assign 1 0 195
assign 1 0 198
assign 1 0 202
assign 1 341 205
containedGet 0 341 205
assign 1 341 206
firstGet 0 341 206
assign 1 341 207
heldGet 0 341 207
assign 1 341 208
namepathGet 0 341 208
assign 1 342 209
stepsGet 0 342 209
assign 1 342 210
lastGet 0 342 210
assign 1 343 211
new 0 343 211
assign 1 343 212
new 0 343 212
assign 1 343 213
substring 2 343 213
assign 1 343 214
lowerValue 0 343 214
assign 1 343 215
new 0 343 215
assign 1 343 216
substring 1 343 216
assign 1 343 217
add 1 343 217
assign 1 343 218
new 0 343 218
assign 1 343 219
add 1 343 219
assign 1 345 220
getSynNp 1 345 220
assign 1 346 221
mtdMapGet 0 346 221
assign 1 346 222
new 0 346 222
assign 1 346 223
add 1 346 223
assign 1 346 224
get 1 346 224
assign 1 347 225
def 1 347 230
assign 1 349 231
heldGet 0 349 231
orgNameSet 1 349 232
assign 1 350 233
heldGet 0 350 233
assign 1 350 234
new 0 350 234
assign 1 350 235
add 1 350 235
nameSet 1 350 236
assign 1 355 241
typenameGet 0 355 241
assign 1 355 242
CLASSGet 0 355 242
assign 1 355 243
equals 1 355 248
assign 1 356 249
assign 1 357 250
heldGet 0 357 250
assign 1 357 251
namepathGet 0 357 251
assign 1 358 252
heldGet 0 358 252
assign 1 358 253
synGet 0 358 253
assign 1 360 255
typenameGet 0 360 255
assign 1 360 256
METHODGet 0 360 256
assign 1 360 257
equals 1 360 262
assign 1 361 263
new 0 361 263
assign 1 362 264
new 0 362 264
assign 1 363 267
typenameGet 0 363 267
assign 1 363 268
VARGet 0 363 268
assign 1 363 269
equals 1 363 274
assign 1 363 275
heldGet 0 363 275
assign 1 363 276
autoTypeGet 0 363 276
assign 1 0 278
assign 1 0 281
assign 1 0 285
assign 1 364 288
heldGet 0 364 288
assign 1 364 289
nameGet 0 364 289
assign 1 364 290
heldGet 0 364 290
put 2 364 291
assign 1 365 292
heldGet 0 365 292
assign 1 365 293
nameGet 0 365 293
assign 1 365 294
get 1 365 294
assign 1 366 295
undef 1 366 300
assign 1 367 301
new 0 367 301
assign 1 368 302
heldGet 0 368 302
assign 1 368 303
nameGet 0 368 303
put 2 368 304
addValue 1 370 306
assign 1 371 309
typenameGet 0 371 309
assign 1 371 310
RBRACESGet 0 371 310
assign 1 371 311
equals 1 371 316
assign 1 371 317
containerGet 0 371 317
assign 1 371 318
def 1 371 323
assign 1 0 324
assign 1 0 327
assign 1 0 331
assign 1 371 334
containerGet 0 371 334
assign 1 371 335
containerGet 0 371 335
assign 1 371 336
def 1 371 341
assign 1 0 342
assign 1 0 345
assign 1 0 349
assign 1 371 352
containerGet 0 371 352
assign 1 371 353
containerGet 0 371 353
assign 1 371 354
typenameGet 0 371 354
assign 1 371 355
METHODGet 0 371 355
assign 1 371 356
equals 1 371 361
assign 1 0 362
assign 1 0 365
assign 1 0 369
processTmps 0 373 372
assign 1 375 376
nextDescendGet 0 375 376
return 1 375 377
assign 1 379 496
new 0 379 496
assign 1 388 500
new 0 388 500
assign 1 389 501
valueIteratorGet 0 389 501
assign 1 389 504
hasNextGet 0 389 504
assign 1 390 506
nextGet 0 390 506
assign 1 392 507
isTypedGet 0 392 507
assign 1 392 508
not 0 392 508
assign 1 395 510
nameGet 0 395 510
assign 1 396 511
get 1 396 511
assign 1 397 512
iteratorGet 0 0 512
assign 1 397 515
hasNextGet 0 397 515
assign 1 397 517
nextGet 0 397 517
assign 1 398 518
isFirstGet 0 398 518
assign 1 398 520
containerGet 0 398 520
assign 1 398 521
typenameGet 0 398 521
assign 1 398 522
CALLGet 0 398 522
assign 1 398 523
equals 1 398 523
assign 1 0 525
assign 1 0 528
assign 1 0 532
assign 1 398 535
containerGet 0 398 535
assign 1 398 536
heldGet 0 398 536
assign 1 398 537
orgNameGet 0 398 537
assign 1 398 538
new 0 398 538
assign 1 398 539
equals 1 398 539
assign 1 0 541
assign 1 0 544
assign 1 0 548
assign 1 398 551
containerGet 0 398 551
assign 1 398 552
secondGet 0 398 552
assign 1 398 553
typenameGet 0 398 553
assign 1 398 554
CALLGet 0 398 554
assign 1 398 555
equals 1 398 555
assign 1 0 557
assign 1 0 560
assign 1 0 564
assign 1 400 567
containerGet 0 400 567
assign 1 400 568
secondGet 0 400 568
assign 1 401 569
assign 1 402 570
heldGet 0 402 570
assign 1 402 571
newNpGet 0 402 571
assign 1 402 572
def 1 402 577
assign 1 403 578
heldGet 0 403 578
assign 1 403 579
newNpGet 0 403 579
assign 1 405 582
containedGet 0 405 582
assign 1 405 583
firstGet 0 405 583
assign 1 409 584
heldGet 0 409 584
assign 1 409 585
isDeclaredGet 0 409 585
assign 1 410 587
heldGet 0 410 587
assign 1 412 590
ptyMapGet 0 412 590
assign 1 412 591
heldGet 0 412 591
assign 1 412 592
nameGet 0 412 592
assign 1 412 593
get 1 412 593
assign 1 412 594
memSynGet 0 412 594
assign 1 415 596
isTypedGet 0 415 596
assign 1 416 598
namepathGet 0 416 598
assign 1 419 601
def 1 419 606
assign 1 421 607
getSynNp 1 421 607
assign 1 422 608
mtdMapGet 0 422 608
assign 1 422 609
heldGet 0 422 609
assign 1 422 610
nameGet 0 422 610
assign 1 422 611
get 1 422 611
assign 1 423 612
def 1 423 617
assign 1 425 618
rsynGet 0 425 618
assign 1 426 619
def 1 426 624
assign 1 426 625
isTypedGet 0 426 625
assign 1 0 627
assign 1 0 630
assign 1 0 634
assign 1 427 637
new 0 427 637
assign 1 429 638
isSelfGet 0 429 638
namepathSet 1 430 640
assign 1 432 643
namepathGet 0 432 643
namepathSet 1 432 644
assign 1 434 646
isTypedGet 0 434 646
isTypedSet 1 434 647
assign 1 435 648
heldGet 0 435 648
assign 1 435 649
namepathGet 0 435 649
addUsed 1 435 650
assign 1 436 651
namepathGet 0 436 651
assign 1 436 652
toString 0 436 652
assign 1 436 653
new 0 436 653
assign 1 436 654
equals 1 436 654
assign 1 436 656
new 0 436 656
assign 1 436 657
isSelfGet 0 436 657
assign 1 436 658
add 1 436 658
print 0 436 659
assign 1 438 664
heldGet 0 438 664
assign 1 438 665
orgNameGet 0 438 665
assign 1 438 666
new 0 438 666
assign 1 438 667
notEquals 1 438 667
assign 1 439 669
mtdMapGet 0 439 669
assign 1 439 670
new 0 439 670
assign 1 439 671
get 1 439 671
assign 1 440 672
def 1 440 677
assign 1 440 678
originGet 0 440 678
assign 1 440 679
toString 0 440 679
assign 1 440 680
new 0 440 680
assign 1 440 681
notEquals 1 440 681
assign 1 0 683
assign 1 0 686
assign 1 0 690
assign 1 441 693
heldGet 0 441 693
assign 1 441 694
new 0 441 694
isForwardSet 1 441 695
assign 1 443 698
new 0 443 698
assign 1 443 699
heldGet 0 443 699
assign 1 443 700
nameGet 0 443 700
assign 1 443 701
add 1 443 701
assign 1 443 702
new 0 443 702
assign 1 443 703
add 1 443 703
assign 1 443 704
toString 0 443 704
assign 1 443 705
add 1 443 705
assign 1 443 706
new 2 443 706
throw 1 443 707
assign 1 449 714
isFirstGet 0 449 714
assign 1 449 716
containerGet 0 449 716
assign 1 449 717
typenameGet 0 449 717
assign 1 449 718
CALLGet 0 449 718
assign 1 449 719
equals 1 449 719
assign 1 0 721
assign 1 0 724
assign 1 0 728
assign 1 449 731
containerGet 0 449 731
assign 1 449 732
heldGet 0 449 732
assign 1 449 733
orgNameGet 0 449 733
assign 1 449 734
new 0 449 734
assign 1 449 735
equals 1 449 735
assign 1 0 737
assign 1 0 740
assign 1 0 744
assign 1 449 747
containerGet 0 449 747
assign 1 449 748
secondGet 0 449 748
assign 1 449 749
typenameGet 0 449 749
assign 1 449 750
VARGet 0 449 750
assign 1 449 751
equals 1 449 751
assign 1 0 753
assign 1 0 756
assign 1 0 760
assign 1 450 763
containerGet 0 450 763
assign 1 450 764
secondGet 0 450 764
assign 1 450 765
heldGet 0 450 765
assign 1 452 766
isTypedGet 0 452 766
assign 1 454 768
new 0 454 768
assign 1 456 769
isTypedGet 0 456 769
isTypedSet 1 456 770
assign 1 457 771
namepathGet 0 457 771
namepathSet 1 457 772
return 1 0 795
return 1 0 798
assign 1 0 801
assign 1 0 805
return 1 0 809
return 1 0 812
assign 1 0 815
assign 1 0 819
return 1 0 823
return 1 0 826
assign 1 0 829
assign 1 0 833
return 1 0 837
return 1 0 840
assign 1 0 843
assign 1 0 847
return 1 0 851
return 1 0 854
assign 1 0 857
assign 1 0 861
return 1 0 865
return 1 0 868
assign 1 0 871
assign 1 0 875
return 1 0 879
return 1 0 882
assign 1 0 885
assign 1 0 889
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1014025921: return bem_inClassNpGetDirect_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -44325320: return bem_emitterGetDirect_0();
case -893093197: return bem_toString_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case -606522170: return bem_transGetDirect_0();
case -1834811546: return bem_tvmapGet_0();
case -624477818: return bem_inClassNpGet_0();
case -146424608: return bem_nlGetDirect_0();
case 954703233: return bem_create_0();
case 1586815430: return bem_fieldIteratorGet_0();
case -396239848: return bem_emitterGet_0();
case 1834246217: return bem_classNameGet_0();
case -458218411: return bem_constGet_0();
case -574574637: return bem_transGet_0();
case -491105423: return bem_processTmps_0();
case -193582610: return bem_tagGet_0();
case -975498393: return bem_fieldNamesGet_0();
case 1910033340: return bem_buildGet_0();
case 58217918: return bem_ntypesGet_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case 660183910: return bem_inClassSynGetDirect_0();
case 1077027817: return bem_inClassGet_0();
case 876676878: return bem_ntypesGetDirect_0();
case 1232394224: return bem_buildGetDirect_0();
case -711947409: return bem_inClassGetDirect_0();
case 1652230546: return bem_tvmapGetDirect_0();
case -1524361715: return bem_nlGet_0();
case 88195190: return bem_constGetDirect_0();
case 744527223: return bem_rmapGetDirect_0();
case 1067944025: return bem_inClassSynGet_0();
case 2040995706: return bem_rmapGet_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -669415086: return bem_constSet_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -597278608: return bem_emitterSetDirect_1(bevd_0);
case -2042501127: return bem_ntypesSetDirect_1(bevd_0);
case -996640729: return bem_buildSet_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 1736101817: return bem_transSetDirect_1(bevd_0);
case 293328502: return bem_inClassSynSet_1(bevd_0);
case 537433000: return bem_end_1(bevd_0);
case -1537135787: return bem_ntypesSet_1(bevd_0);
case -1729531233: return bem_rmapSetDirect_1(bevd_0);
case 1777825783: return bem_emitterSet_1(bevd_0);
case 1865062933: return bem_buildSetDirect_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 1960820600: return bem_inClassNpSetDirect_1(bevd_0);
case -1142669433: return bem_rmapSet_1(bevd_0);
case -631003549: return bem_begin_1(bevd_0);
case 2011490434: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1002871962: return bem_inClassSetDirect_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 25031630: return bem_nlSetDirect_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 445058406: return bem_inClassSynSetDirect_1(bevd_0);
case -1739950932: return bem_nlSet_1(bevd_0);
case 1457046128: return bem_tvmapSet_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1000390917: return bem_inClassSet_1(bevd_0);
case -917640934: return bem_inClassNpSet_1(bevd_0);
case 215907131: return bem_transSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -1235267458: return bem_tvmapSetDirect_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1819306118: return bem_constSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitRewind_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitRewind_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitRewind();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst = (BEC_3_5_5_6_BuildVisitRewind) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_6_BuildVisitRewind.bece_BEC_3_5_5_6_BuildVisitRewind_bevs_type;
}
}
}
