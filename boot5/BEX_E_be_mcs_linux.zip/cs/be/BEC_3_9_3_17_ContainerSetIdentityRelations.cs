namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_17_ContainerSetIdentityRelations : BEC_3_9_3_9_ContainerSetRelations {
public BEC_3_9_3_17_ContainerSetIdentityRelations() { }
static BEC_3_9_3_17_ContainerSetIdentityRelations() { }
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x52,0x65,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;

public static new BET_3_9_3_17_ContainerSetIdentityRelations bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;

public override BEC_2_6_6_SystemObject bem_getHash_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_0(911313117);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_isEqual_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_l) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_k.bemd_1(1383324451, beva_l);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {79, 79, 83, 83};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20};
/* BEGIN LINEINFO 
assign 1 79 14
tagGet 0 79 14
return 1 79 15
assign 1 83 19
sameObject 1 83 19
return 1 83 20
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1131385505: return bem_toAny_0();
case 131226213: return bem_toString_0();
case 1279906777: return bem_serializeToString_0();
case 2063546474: return bem_classNameGet_0();
case -1485517163: return bem_copy_0();
case 431618869: return bem_once_0();
case 343375430: return bem_create_0();
case -1574932366: return bem_print_0();
case -928163909: return bem_fieldIteratorGet_0();
case -825084265: return bem_hashGet_0();
case 421749162: return bem_iteratorGet_0();
case 2061421621: return bem_many_0();
case -768719948: return bem_default_0();
case -1846550974: return bem_serializeContents_0();
case 916294969: return bem_sourceFileNameGet_0();
case -1031399474: return bem_echo_0();
case 1253953314: return bem_serializationIteratorGet_0();
case 911313117: return bem_tagGet_0();
case -957769093: return bem_deserializeClassNameGet_0();
case -2051799514: return bem_new_0();
case 1970758688: return bem_fieldNamesGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 747155616: return bem_notEquals_1(bevd_0);
case 1383324451: return bem_sameObject_1(bevd_0);
case -1551421646: return bem_copyTo_1(bevd_0);
case -1809169317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2018944701: return bem_def_1(bevd_0);
case -1181240679: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -436556280: return bem_undef_1(bevd_0);
case 1044863323: return bem_defined_1(bevd_0);
case -628476976: return bem_otherClass_1(bevd_0);
case 1928047187: return bem_undefined_1(bevd_0);
case -1065536512: return bem_equals_1(bevd_0);
case 2104162347: return bem_getHash_1(bevd_0);
case 1555616281: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 192530319: return bem_otherType_1(bevd_0);
case 1768644351: return bem_sameClass_1(bevd_0);
case -1655018142: return bem_sameType_1(bevd_0);
case 1147111468: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1990600260: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1260241587: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -598891548: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 670662017: return bem_isEqual_2(bevd_0, bevd_1);
case 1655882914: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1041029455: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -214435591: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -40143354: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(31, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_17_ContainerSetIdentityRelations_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_17_ContainerSetIdentityRelations();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst = (BEC_3_9_3_17_ContainerSetIdentityRelations) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_type;
}
}
}
