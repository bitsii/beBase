namespace be {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_6_SystemObject : be.BECS_Object {
public BEC_2_6_6_SystemObject() { }
static BEC_2_6_6_SystemObject() { }

   public virtual BEC_2_6_6_SystemObject bems_methodNotDefined(string name, BEC_2_6_6_SystemObject[] args) { 
     name = name.Substring(0, name.LastIndexOf("_"));
     return bem_methodNotDefined_2(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(name)), new BEC_2_9_4_ContainerList(args));
   }
   public virtual BEC_2_6_6_SystemObject bems_forwardCallCp(BEC_2_4_6_TextString name, BEC_2_9_4_ContainerList args) { 
     args = (BEC_2_9_4_ContainerList) args.bem_copy_0();
     return bem_forwardCall_2(name, args);
   }
   private static byte[] becc_BEC_2_6_6_SystemObject_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] becc_BEC_2_6_6_SystemObject_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_0 = {0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_1 = {0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_2 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_3 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_4 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_5 = {0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x4C,0x69,0x73,0x74,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_6 = {0x5F};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_7 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_6_SystemObject_bels_8 = {0x63,0x61,0x6E,0x28,0x29,0x20,0x6E,0x75,0x6D,0x61,0x72,0x67,0x73,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
public static BEC_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_inst;

public static BET_2_6_6_SystemObject bece_BEC_2_6_6_SystemObject_bevs_type;

public virtual BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_undef_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_def_1(BEC_2_6_6_SystemObject beva_ref) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNotDefined_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_6_6_SystemObject_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(beva_name);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bem_classNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 45*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_16_SystemMethodNotDefined bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 50*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_6_6_SystemObject_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(beva_name);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_1));
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bem_classNameGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_1_ta_ph = (BEC_2_6_16_SystemMethodNotDefined) (new BEC_2_6_16_SystemMethodNotDefined()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 51*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_ph = bem_createInstance_2(beva_cname, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_11_SystemInitializer bevt_8_ta_ph = null;
if (beva_cname == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_2));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 61*/
bevl_result = null;

        string key = System.Text.Encoding.UTF8.GetString(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int);
        BETS_Object ti = be.BECS_Runtime.typeRefs[key];
        if (ti != null) {
            bevl_result = ti.bems_createInstance();
        }
        if (bevl_result == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 117*/ {
if (beva_throwOnFail.bevi_bool)/* Line: 118*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_6_6_SystemObject_bels_3));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(beva_cname);
bevt_4_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 119*/
 else /* Line: 120*/ {
return null;
} /* Line: 121*/
} /* Line: 118*/
bevt_8_ta_ph = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_ta_ph = bevt_8_ta_ph.bem_initializeIfShould_1(bevl_result);
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_fieldNamesGet_0() {
BEC_2_9_4_ContainerList bevl_names = null;
bevl_names = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();

     BETS_Object bevs_cano = bemc_getType();
     string[] fnames = bevs_cano.bevs_fieldNames;
     
     for (int i = 0;i < fnames.Length;i++) {
     
       bevl_names.bem_addValue_1(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(fnames[i])));

     }
     return bevl_names;
} /*method end*/
public BEC_2_6_6_SystemObject bem_invoke_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_4_3_MathInt bevl_numargs = null;
BEC_2_9_4_ContainerList bevl_args2 = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 194*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_6_6_SystemObject_bels_4));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 195*/
if (beva_args == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_6_6_SystemObject_bels_5));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 198*/
bevl_numargs = beva_args.bem_lengthGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
/* Line: 206*/ {
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
if (bevl_numargs.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 207*/ {
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevt_11_ta_ph = bevl_numargs.bem_subtract_1(bevt_12_ta_ph);
bevl_args2 = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_11_ta_ph);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
while (true)
/* Line: 209*/ {
if (bevl_i.bevi_int < bevl_numargs.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 209*/ {
bevt_15_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevt_14_ta_ph = bevl_i.bem_subtract_1(bevt_15_ta_ph);
bevt_16_ta_ph = beva_args.bem_get_1(bevl_i);
bevl_args2.bem_put_2(bevt_14_ta_ph, bevt_16_ta_ph);
bevl_i.bevi_int++;
} /* Line: 209*/
 else /* Line: 209*/ {
break;
} /* Line: 209*/
} /* Line: 209*/
} /* Line: 209*/
} /* Line: 207*/

        int ci = be.BECS_Ids.callIds[bevl_cname.bems_toCsString()];
        
        if (bevl_numargs.bevi_int == 0) {
            bevl_rval = bemd_0(ci);
        } else if (bevl_numargs.bevi_int == 1) {
            bevl_rval = bemd_1(ci, beva_args.bevi_list[0]);
        } else if (bevl_numargs.bevi_int == 2) {
            bevl_rval = bemd_2(ci, beva_args.bevi_list[0], beva_args.bevi_list[1]);
        } else if (bevl_numargs.bevi_int == 3) {
            bevl_rval = bemd_3(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2]);
        } else if (bevl_numargs.bevi_int == 4) {
            bevl_rval = bemd_4(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3]);
        } else if (bevl_numargs.bevi_int == 5) {
            bevl_rval = bemd_5(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4]);
        } else if (bevl_numargs.bevi_int == 6) {
            bevl_rval = bemd_6(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5]);
        } else if (bevl_numargs.bevi_int == 7) {
            bevl_rval = bemd_7(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6]);
        } else {
            bevl_rval = bemd_x(ci, beva_args.bevi_list[0], beva_args.bevi_list[1], beva_args.bevi_list[2], beva_args.bevi_list[3], beva_args.bevi_list[4], beva_args.bevi_list[5], beva_args.bevi_list[6], bevl_args2.bevi_list);
        }
        bevt_17_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_17_ta_ph.bevi_bool)/* Line: 289*/ {
bevl_rval.bemd_0(-893093197);
} /* Line: 291*/
return bevl_rval;
} /*method end*/
public BEC_2_5_4_LogicBool bem_can_2(BEC_2_4_6_TextString beva_name, BEC_2_4_3_MathInt beva_numargs) {
BEC_2_4_6_TextString bevl_cname = null;
BEC_2_4_3_MathInt bevl_chash = null;
BEC_2_6_6_SystemObject bevl_rval = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 301*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_6_6_SystemObject_bels_7));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 302*/
if (beva_numargs == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 304*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_6_6_SystemObject_bels_8));
bevt_4_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 305*/
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_6_SystemObject_bels_6));
bevt_6_ta_ph = beva_name.bem_add_1(bevt_7_ta_ph);
bevt_8_ta_ph = beva_numargs.bem_toString_0();
bevl_cname = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);

      
      string name = System.Text.Encoding.UTF8.GetString(bevl_cname.bevi_bytes, 0, bevl_cname.bevp_size.bevi_int);
      
      BETS_Object bevs_cano = bemc_getType();
      
      if (bevs_cano.bevs_methodNames.ContainsKey(name)) {
        return be.BECS_Runtime.boolTrue;
      }
      
      bevt_9_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_9_ta_ph.bevi_bool)/* Line: 355*/ {
bevl_rval.bemd_0(-893093197);
} /* Line: 356*/
if (bevl_rval == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 358*/ {
bevt_11_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /* Line: 359*/
bevt_12_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_classNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clname();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clnames();
      /* Line: 392*/ {
} /* Line: 393*/
/* Line: 399*/ {
} /* Line: 400*/
return bevl_xi;
} /*method end*/
public BEC_2_4_6_TextString bem_sourceFileNameGet_0() {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.Length, bevls_clname);
      bevl_xi = bemc_clfiles();
      /* Line: 425*/ {
} /* Line: 426*/
return bevl_xi;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_sameObject_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (this != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_tagGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = GetHashCode();
      return bevl_toRet;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_x);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_classNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_print_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
bevt_0_ta_ph.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_echo_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
bevt_0_ta_ph.bem_echo_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_6_SystemObject) bem_create_0();
bevt_0_ta_ph = (BEC_2_6_6_SystemObject) bem_copyTo_1(bevt_1_ta_ph);
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyTo_1(BEC_2_6_6_SystemObject beva_copy) {
BEC_2_6_19_SystemObjectFieldIterator bevl_siter = null;
BEC_2_6_19_SystemObjectFieldIterator bevl_citer = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
if (beva_copy == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 624*/ {
return (BEC_2_6_6_SystemObject) beva_copy;
} /* Line: 625*/
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_siter = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(this, bevt_1_ta_ph);
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_citer = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_2(beva_copy, bevt_2_ta_ph);
while (true)
/* Line: 629*/ {
bevt_3_ta_ph = bevl_siter.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 629*/ {
bevt_4_ta_ph = bevl_siter.bem_nextGet_0();
bevl_citer.bem_nextSet_1(bevt_4_ta_ph);
} /* Line: 630*/
 else /* Line: 629*/ {
break;
} /* Line: 629*/
} /* Line: 629*/
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_classNameGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromString_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_serializeToString_0() {
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_19_SystemObjectFieldIterator bem_fieldIteratorGet_0() {
BEC_2_6_19_SystemObjectFieldIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_6_19_SystemObjectFieldIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_6_6_SystemObject bevl_copy = null;

      bevl_copy = this.bemc_create();
      return (BEC_2_6_6_SystemObject) bevl_copy;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (beva_other != null && this.GetType() == beva_other.GetType()) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherClass_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sameClass_1(beva_other);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_sameType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (beva_other != null && beva_other.GetType().IsAssignableFrom(this.GetType())) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_otherType_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sameType_1(beva_other);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public static int[] bevs_smnlc
 = new int[] {29, 29, 40, 40, 44, 45, 45, 45, 45, 45, 45, 45, 45, 50, 51, 51, 51, 51, 51, 51, 51, 51, 56, 56, 56, 60, 60, 61, 61, 61, 63, 117, 117, 119, 119, 119, 119, 121, 124, 124, 124, 129, 185, 194, 194, 195, 195, 195, 197, 197, 198, 198, 198, 200, 201, 201, 201, 201, 207, 207, 207, 208, 208, 208, 209, 209, 209, 210, 210, 210, 210, 209, 289, 291, 293, 301, 301, 302, 302, 302, 304, 304, 305, 305, 305, 307, 307, 307, 307, 355, 356, 358, 358, 359, 359, 361, 361, 406, 432, 471, 471, 510, 510, 521, 555, 566, 600, 604, 604, 604, 608, 608, 612, 612, 616, 616, 620, 620, 620, 624, 624, 625, 627, 627, 628, 628, 629, 630, 630, 636, 636, 642, 648, 648, 652, 652, 656, 656, 660, 660, 688, 744, 744, 748, 748, 748, 796, 796, 800, 800, 800};
public static int[] bevs_smnlec
 = new int[] {37, 38, 42, 43, 54, 56, 57, 58, 59, 60, 61, 62, 63, 76, 78, 79, 80, 81, 82, 83, 84, 85, 92, 93, 94, 107, 112, 113, 114, 115, 117, 124, 129, 131, 132, 133, 134, 137, 140, 141, 142, 146, 156, 182, 187, 188, 189, 190, 192, 197, 198, 199, 200, 202, 203, 204, 205, 206, 208, 209, 214, 215, 216, 217, 218, 221, 226, 227, 228, 229, 230, 231, 261, 263, 265, 284, 289, 290, 291, 292, 294, 299, 300, 301, 302, 304, 305, 306, 307, 318, 320, 322, 327, 328, 329, 331, 332, 344, 354, 362, 363, 371, 372, 376, 379, 383, 386, 391, 392, 397, 401, 402, 406, 407, 412, 413, 419, 420, 421, 431, 436, 437, 439, 440, 441, 442, 445, 447, 448, 458, 459, 465, 472, 473, 477, 478, 482, 483, 487, 488, 494, 502, 503, 508, 509, 514, 522, 523, 528, 529, 534};
/* BEGIN LINEINFO 
assign 1 29 37
new 0 29 37
return 1 29 38
assign 1 40 42
new 0 40 42
return 1 40 43
assign 1 44 54
new 0 44 54
assign 1 45 56
new 0 45 56
assign 1 45 57
add 1 45 57
assign 1 45 58
new 0 45 58
assign 1 45 59
add 1 45 59
assign 1 45 60
classNameGet 0 45 60
assign 1 45 61
add 1 45 61
assign 1 45 62
new 1 45 62
throw 1 45 63
assign 1 50 76
new 0 50 76
assign 1 51 78
new 0 51 78
assign 1 51 79
add 1 51 79
assign 1 51 80
new 0 51 80
assign 1 51 81
add 1 51 81
assign 1 51 82
classNameGet 0 51 82
assign 1 51 83
add 1 51 83
assign 1 51 84
new 1 51 84
throw 1 51 85
assign 1 56 92
new 0 56 92
assign 1 56 93
createInstance 2 56 93
return 1 56 94
assign 1 60 107
undef 1 60 112
assign 1 61 113
new 0 61 113
assign 1 61 114
new 1 61 114
throw 1 61 115
assign 1 63 117
assign 1 117 124
undef 1 117 129
assign 1 119 131
new 0 119 131
assign 1 119 132
add 1 119 132
assign 1 119 133
new 1 119 133
throw 1 119 134
return 1 121 137
assign 1 124 140
new 0 124 140
assign 1 124 141
initializeIfShould 1 124 141
return 1 124 142
assign 1 129 146
new 0 129 146
return 1 185 156
assign 1 194 182
undef 1 194 187
assign 1 195 188
new 0 195 188
assign 1 195 189
new 1 195 189
throw 1 195 190
assign 1 197 192
undef 1 197 197
assign 1 198 198
new 0 198 198
assign 1 198 199
new 1 198 199
throw 1 198 200
assign 1 200 202
lengthGet 0 200 202
assign 1 201 203
new 0 201 203
assign 1 201 204
add 1 201 204
assign 1 201 205
toString 0 201 205
assign 1 201 206
add 1 201 206
assign 1 207 208
new 0 207 208
assign 1 207 209
greater 1 207 214
assign 1 208 215
new 0 208 215
assign 1 208 216
subtract 1 208 216
assign 1 208 217
new 1 208 217
assign 1 209 218
new 0 209 218
assign 1 209 221
lesser 1 209 226
assign 1 210 227
new 0 210 227
assign 1 210 228
subtract 1 210 228
assign 1 210 229
get 1 210 229
put 2 210 230
incrementValue 0 209 231
assign 1 289 261
new 0 289 261
toString 0 291 263
return 1 293 265
assign 1 301 284
undef 1 301 289
assign 1 302 290
new 0 302 290
assign 1 302 291
new 1 302 291
throw 1 302 292
assign 1 304 294
undef 1 304 299
assign 1 305 300
new 0 305 300
assign 1 305 301
new 1 305 301
throw 1 305 302
assign 1 307 304
new 0 307 304
assign 1 307 305
add 1 307 305
assign 1 307 306
toString 0 307 306
assign 1 307 307
add 1 307 307
assign 1 355 318
new 0 355 318
toString 0 356 320
assign 1 358 322
def 1 358 327
assign 1 359 328
new 0 359 328
return 1 359 329
assign 1 361 331
new 0 361 331
return 1 361 332
return 1 406 344
return 1 432 354
assign 1 471 362
new 0 471 362
return 1 471 363
assign 1 510 371
new 0 510 371
return 1 510 372
assign 1 521 376
new 0 521 376
return 1 555 379
assign 1 566 383
new 0 566 383
return 1 600 386
assign 1 604 391
equals 1 604 391
assign 1 604 392
not 0 604 397
return 1 604 397
assign 1 608 401
classNameGet 0 608 401
return 1 608 402
assign 1 612 406
toString 0 612 406
print 0 612 407
assign 1 616 412
toString 0 616 412
echo 0 616 413
assign 1 620 419
create 0 620 419
assign 1 620 420
copyTo 1 620 420
return 1 620 421
assign 1 624 431
undef 1 624 436
return 1 625 437
assign 1 627 439
new 0 627 439
assign 1 627 440
new 2 627 440
assign 1 628 441
new 0 628 441
assign 1 628 442
new 2 628 442
assign 1 629 445
hasNextGet 0 629 445
assign 1 630 447
nextGet 0 630 447
nextSet 1 630 448
assign 1 636 458
classNameGet 0 636 458
return 1 636 459
return 1 642 465
assign 1 648 472
new 1 648 472
return 1 648 473
assign 1 652 477
new 1 652 477
return 1 652 478
assign 1 656 482
new 1 656 482
return 1 656 483
assign 1 660 487
new 0 660 487
return 1 660 488
return 1 688 494
assign 1 744 502
new 0 744 502
return 1 744 503
assign 1 748 508
sameClass 1 748 508
assign 1 748 509
not 0 748 514
return 1 748 514
assign 1 796 522
new 0 796 522
return 1 796 523
assign 1 800 528
sameType 1 800 528
assign 1 800 529
not 0 800 534
return 1 800 534
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1931705863: return bem_sourceFileNameGet_0();
case -893093197: return bem_toString_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case 954703233: return bem_create_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1834246217: return bem_classNameGet_0();
case -193582610: return bem_tagGet_0();
case -975498393: return bem_fieldNamesGet_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1220213109: return bem_otherClass_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemObject_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemObject_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemObject();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst = becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemObject.bece_BEC_2_6_6_SystemObject_bevs_type;
}
}
}
