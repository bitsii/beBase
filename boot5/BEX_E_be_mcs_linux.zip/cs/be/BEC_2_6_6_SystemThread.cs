namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_6_SystemThread : BEC_2_6_10_SystemThinThread {
public BEC_2_6_6_SystemThread() { }
static BEC_2_6_6_SystemThread() { }
private static byte[] becc_BEC_2_6_6_SystemThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_6_SystemThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_inst;

public static new BET_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_type;

public BEC_3_6_6_12_SystemThreadObjectLocker bevp_started;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_finished;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_threwException;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_returned;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_exception;
public override BEC_2_6_10_SystemThinThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_1_tmpany_phold);
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
base.bem_new_1(beva__toRun);
return this;
} /*method end*/
public override BEC_2_6_10_SystemThinThread bem_main_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
try  /* Line: 758 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_started.bem_oSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_toRun.bemd_0(154014197);
bevp_returned.bem_oSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_threwException.bem_oSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_3_tmpany_phold);
} /* Line: 762 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_threwException.bem_oSet_1(bevt_4_tmpany_phold);
bevp_exception.bem_oSet_1(bevl_e);
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_5_tmpany_phold);
} /* Line: 766 */
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGet_0() {
return bevp_started;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGet_0() {
return bevp_finished;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGet_0() {
return bevp_threwException;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGet_0() {
return bevp_returned;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGet_0() {
return bevp_exception;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {747, 747, 748, 748, 749, 750, 751, 753, 759, 759, 760, 760, 761, 761, 762, 762, 764, 764, 765, 766, 766, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 28, 29, 30, 31, 32, 44, 45, 46, 47, 48, 49, 50, 51, 55, 56, 57, 58, 59, 64, 67, 71, 74, 78, 81, 85, 88, 92, 95};
/* BEGIN LINEINFO 
assign 1 747 25
new 0 747 25
assign 1 747 26
new 1 747 26
assign 1 748 27
new 0 748 27
assign 1 748 28
new 1 748 28
assign 1 749 29
new 0 749 29
assign 1 750 30
new 0 750 30
assign 1 751 31
new 0 751 31
new 1 753 32
assign 1 759 44
new 0 759 44
oSet 1 759 45
assign 1 760 46
main 0 760 46
oSet 1 760 47
assign 1 761 48
new 0 761 48
oSet 1 761 49
assign 1 762 50
new 0 762 50
oSet 1 762 51
assign 1 764 55
new 0 764 55
oSet 1 764 56
oSet 1 765 57
assign 1 766 58
new 0 766 58
oSet 1 766 59
return 1 0 64
assign 1 0 67
return 1 0 71
assign 1 0 74
return 1 0 78
assign 1 0 81
return 1 0 85
assign 1 0 88
return 1 0 92
assign 1 0 95
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1991051685: return bem_print_0();
case -439307572: return bem_hashGet_0();
case -1889481920: return bem_once_0();
case 491585243: return bem_toString_0();
case 645227528: return bem_copy_0();
case 360839536: return bem_start_0();
case 154014197: return bem_main_0();
case -213541934: return bem_echo_0();
case -1791312022: return bem_serializationIteratorGet_0();
case -1436271556: return bem_wait_0();
case 1193477558: return bem_new_0();
case 879502245: return bem_toRunGet_0();
case 1501620573: return bem_deserializeClassNameGet_0();
case 153829440: return bem_iteratorGet_0();
case -1466347886: return bem_serializeContents_0();
case -2067310143: return bem_create_0();
case -637230318: return bem_serializeToString_0();
case 417391847: return bem_finishedGet_0();
case -414566530: return bem_fieldIteratorGet_0();
case 1805899516: return bem_many_0();
case 793830133: return bem_tagGet_0();
case 1163377727: return bem_toAny_0();
case 956121033: return bem_sourceFileNameGet_0();
case -1990261799: return bem_startedGet_0();
case -1216713378: return bem_returnedGet_0();
case -1479596377: return bem_exceptionGet_0();
case 1208753273: return bem_threwExceptionGet_0();
case 1754190679: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -505152552: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1464374223: return bem_threwExceptionSet_1(bevd_0);
case 1340919241: return bem_returnedSet_1(bevd_0);
case 100980215: return bem_otherClass_1(bevd_0);
case -1889413842: return bem_toRunSet_1(bevd_0);
case 759691226: return bem_exceptionSet_1(bevd_0);
case 279657909: return bem_equals_1(bevd_0);
case -1871751942: return bem_def_1(bevd_0);
case 263363004: return bem_finishedSet_1(bevd_0);
case -1658903143: return bem_startedSet_1(bevd_0);
case -1504728618: return bem_new_1(bevd_0);
case 1596320235: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1267197459: return bem_otherType_1(bevd_0);
case 1979194181: return bem_notEquals_1(bevd_0);
case 1114375968: return bem_sameClass_1(bevd_0);
case -1314037522: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1603994454: return bem_sameType_1(bevd_0);
case -704128729: return bem_copyTo_1(bevd_0);
case 385893729: return bem_undefined_1(bevd_0);
case -1192171297: return bem_defined_1(bevd_0);
case 1963771415: return bem_undef_1(bevd_0);
case 417172649: return bem_sameObject_1(bevd_0);
case -287855524: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1596177832: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1919067749: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1086524794: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1313996982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1153243887: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 966288160: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -962439482: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemThread_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemThread_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemThread();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst = (BEC_2_6_6_SystemThread) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_type;
}
}
}
