namespace be {

using System;
using System.Diagnostics;
/* IO:File: source/extended/Command.be */
public sealed class BEC_2_6_7_SystemCommand : BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemCommand() { }
static BEC_2_6_7_SystemCommand() { }

   public Process bevi_p;
   private static byte[] becc_BEC_2_6_7_SystemCommand_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_2_6_7_SystemCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_0 = {};
private static byte[] bece_BEC_2_6_7_SystemCommand_bels_1 = {0x20};
public static new BEC_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_inst;

public static new BET_2_6_7_SystemCommand bece_BEC_2_6_7_SystemCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public BEC_2_9_4_ContainerList bevp_commands;
public BEC_3_2_4_6_IOFileReader bevp_outputReader;
public BEC_2_6_7_SystemCommand bem_new_1(BEC_2_4_6_TextString beva__command) {
bevp_command = beva__command;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_listNew_1(BEC_2_9_4_ContainerList beva__commands) {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevp_commands = beva__commands;
bevp_command = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_0));
bevt_0_ta_loop = bevp_commands.bem_iteratorGet_0();
while (true)
/* Line: 46*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 46*/ {
bevl_c = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(409355098);
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_notEmpty_1(bevp_command);
if (bevt_2_ta_ph.bevi_bool)/* Line: 47*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_7_SystemCommand_bels_1));
bevp_command.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 48*/
bevp_command.bem_addValue_1(bevl_c);
} /* Line: 50*/
 else /* Line: 46*/ {
break;
} /* Line: 46*/
} /* Line: 46*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_1(BEC_2_4_6_TextString beva__command) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bem_new_1(beva__command);
bevt_0_ta_ph = bem_run_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_run_0() {
BEC_2_4_3_MathInt bevl_res = null;
BEC_2_4_3_MathInt bevl_sp = null;
BEC_2_4_6_TextString bevl_cmdRun = null;
BEC_2_4_6_TextString bevl_cmdArgs = null;
BEC_2_4_3_MathInt bevl_cl = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_cmdi = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
/* Line: 62*/ {
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_7_SystemCommand_bels_1));
bevl_sp = bevp_command.bem_find_1(bevt_0_ta_ph);
if (bevl_sp == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 64*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_cmdRun = bevp_command.bem_substring_2(bevt_2_ta_ph, bevl_sp);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_3_ta_ph = bevl_sp.bem_add_1(bevt_4_ta_ph);
bevl_cmdArgs = bevp_command.bem_substring_1(bevt_3_ta_ph);
} /* Line: 66*/
 else /* Line: 67*/ {
bevl_cmdRun = bevp_command;
bevl_cmdArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_6_7_SystemCommand_bels_0));
} /* Line: 69*/

          bevi_p = new Process();
          bevi_p.StartInfo.FileName = bevl_cmdRun.bems_toCsString();
          bevi_p.StartInfo.Arguments = bevl_cmdArgs.bems_toCsString();
          bevi_p.StartInfo.CreateNoWindow = true;
          bevi_p.StartInfo.UseShellExecute = false;
          bevi_p.StartInfo.RedirectStandardOutput = true;   
          //bevi_p.StartInfo.WorkingDirectory = strWorkingDirectory;
          bevi_p.Start();
          //bevi_p.StandardOutput.ReadToEnd();
          //bevi_p.WaitForExit();
          } /* Line: 73*/
if (bevp_commands == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 89*/ {
bevl_cl = bevp_commands.bem_sizeGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 96*/ {
if (bevl_i.bevi_int < bevl_cl.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 96*/ {
bevl_cmdi = (BEC_2_4_6_TextString) bevp_commands.bem_get_1(bevl_i);
bevl_i.bevi_int++;
} /* Line: 96*/
 else /* Line: 96*/ {
break;
} /* Line: 96*/
} /* Line: 96*/
} /* Line: 105*/
 else /* Line: 111*/ {
} /* Line: 113*/
return bevl_res;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_open_0() {
bem_run_0();
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_outputReader == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 132*/ {
return bevp_outputReader;
} /* Line: 133*/
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) (new BEC_3_2_4_6_IOFileReader()).bem_new_0();

     bevp_outputReader.bevi_is = bevi_p.StandardOutput.BaseStream;
     bevp_outputReader.bem_extOpen_0();
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_closeOutput_0() {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
try /* Line: 151*/ {
if (bevp_outputReader == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
bevp_outputReader.bem_close_0();
bevp_outputReader = null;
} /* Line: 154*/
} /* Line: 152*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 156*/
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_close_0() {
bem_closeOutput_0();

     bevi_p = null;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_outputContentGet_0() {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevl_ee = null;
BEC_3_2_4_6_IOFileReader bevt_0_ta_ph = null;
BEC_2_6_7_SystemCommand bevt_1_ta_ph = null;
try /* Line: 175*/ {
bevt_1_ta_ph = (BEC_2_6_7_SystemCommand) bem_open_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_outputGet_0();
bevl_res = bevt_0_ta_ph.bem_readString_0();
bem_close_0();
} /* Line: 177*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
try /* Line: 179*/ {
bem_close_0();
} /* Line: 180*/
 catch (System.Exception beve_1) {
bevl_ee = (be.BECS_ThrowBack.handleThrow(beve_1));
} /* Line: 181*/
} /* Line: 181*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGetDirect_0() {
return bevp_command;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGet_0() {
return bevp_commands;
} /*method end*/
public BEC_2_9_4_ContainerList bem_commandsGetDirect_0() {
return bevp_commands;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_commandsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_commands = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGet_0() {
return bevp_outputReader;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_outputReaderGetDirect_0() {
return bevp_outputReader;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemCommand bem_outputReaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputReader = (BEC_3_2_4_6_IOFileReader) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {37, 43, 45, 46, 0, 46, 46, 47, 47, 48, 48, 50, 55, 56, 56, 63, 63, 64, 64, 65, 65, 66, 66, 66, 68, 69, 89, 89, 90, 96, 96, 96, 97, 96, 121, 125, 132, 132, 133, 135, 146, 147, 152, 152, 153, 154, 160, 176, 176, 176, 177, 180, 183, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 33, 34, 35, 35, 38, 40, 41, 42, 44, 45, 47, 57, 58, 59, 77, 78, 79, 84, 85, 86, 87, 88, 89, 92, 93, 107, 112, 113, 114, 117, 122, 123, 124, 133, 136, 141, 146, 147, 149, 152, 153, 159, 164, 165, 166, 175, 187, 188, 189, 190, 195, 201, 204, 207, 210, 214, 218, 221, 224, 228, 232, 235, 238, 242};
/* BEGIN LINEINFO 
assign 1 37 23
assign 1 43 33
assign 1 45 34
new 0 45 34
assign 1 46 35
iteratorGet 0 0 35
assign 1 46 38
hasNextGet 0 46 38
assign 1 46 40
nextGet 0 46 40
assign 1 47 41
new 0 47 41
assign 1 47 42
notEmpty 1 47 42
assign 1 48 44
new 0 48 44
addValue 1 48 45
addValue 1 50 47
new 1 55 57
assign 1 56 58
run 0 56 58
return 1 56 59
assign 1 63 77
new 0 63 77
assign 1 63 78
find 1 63 78
assign 1 64 79
def 1 64 84
assign 1 65 85
new 0 65 85
assign 1 65 86
substring 2 65 86
assign 1 66 87
new 0 66 87
assign 1 66 88
add 1 66 88
assign 1 66 89
substring 1 66 89
assign 1 68 92
assign 1 69 93
new 0 69 93
assign 1 89 107
def 1 89 112
assign 1 90 113
sizeGet 0 90 113
assign 1 96 114
new 0 96 114
assign 1 96 117
lesser 1 96 122
assign 1 97 123
get 1 97 123
incrementValue 0 96 124
return 1 121 133
run 0 125 136
assign 1 132 141
def 1 132 146
return 1 133 147
assign 1 135 149
new 0 135 149
extOpen 0 146 152
return 1 147 153
assign 1 152 159
def 1 152 164
close 0 153 165
assign 1 154 166
closeOutput 0 160 175
assign 1 176 187
open 0 176 187
assign 1 176 188
outputGet 0 176 188
assign 1 176 189
readString 0 176 189
close 0 177 190
close 0 180 195
return 1 183 201
return 1 0 204
return 1 0 207
assign 1 0 210
assign 1 0 214
return 1 0 218
return 1 0 221
assign 1 0 224
assign 1 0 228
return 1 0 232
return 1 0 235
assign 1 0 238
assign 1 0 242
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1620460991: return bem_outputContentGet_0();
case 653215521: return bem_outputReaderGet_0();
case -1387831588: return bem_print_0();
case -1250294729: return bem_commandGetDirect_0();
case -1188922735: return bem_echo_0();
case -1385508075: return bem_closeOutput_0();
case -793241295: return bem_iteratorGet_0();
case 371157924: return bem_sourceFileNameGet_0();
case 1652521523: return bem_serializeContents_0();
case 1007580437: return bem_commandsGetDirect_0();
case -1760538533: return bem_classNameGet_0();
case 1146767811: return bem_outputGet_0();
case 7254011: return bem_fieldIteratorGet_0();
case -921473949: return bem_fieldNamesGet_0();
case 895193825: return bem_once_0();
case 212584225: return bem_open_0();
case -173683707: return bem_run_0();
case -467511392: return bem_toString_0();
case -1323898541: return bem_toAny_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -1999579961: return bem_commandGet_0();
case -1955965133: return bem_commandsGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -447432319: return bem_many_0();
case 1597327951: return bem_create_0();
case -1363819567: return bem_new_0();
case -1469993846: return bem_close_0();
case 1092105192: return bem_hashGet_0();
case -105946774: return bem_serializeToString_0();
case 1890854002: return bem_tagGet_0();
case -1505012312: return bem_outputReaderGetDirect_0();
case 1319388306: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1490569666: return bem_run_1((BEC_2_4_6_TextString) bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -775246282: return bem_commandSet_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case -956144428: return bem_commandsSet_1(bevd_0);
case 1929898803: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case 852471522: return bem_outputReaderSet_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -801490724: return bem_commandsSetDirect_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case 738045182: return bem_commandSetDirect_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 1397209817: return bem_outputReaderSetDirect_1(bevd_0);
case 1554754398: return bem_listNew_1((BEC_2_9_4_ContainerList) bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_7_SystemCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst = (BEC_2_6_7_SystemCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_7_SystemCommand.bece_BEC_2_6_7_SystemCommand_bevs_type;
}
}
}
