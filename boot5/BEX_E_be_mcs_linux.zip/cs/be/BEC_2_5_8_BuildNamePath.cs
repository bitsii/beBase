namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_8_BuildNamePath : BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
static BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_0, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_1, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_2, 1));
public static new BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;

public static new BET_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_type;

public BEC_2_4_6_TextString bevp_label;
public override BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_tmpany_phold.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_2_tmpany_phold = null;
if (bevp_label == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 20 */ {
bevt_2_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_lastGet_0();
return bevt_1_tmpany_phold;
} /* Line: 21 */
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_0;
bevt_1_tmpany_phold = bevl_oldpath.bem_equals_1(bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 29 */ {
return this;
} /* Line: 29 */
bevt_4_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_1;
bevt_3_tmpany_phold = bevl_oldpath.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 30 */ {
return this;
} /* Line: 30 */
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(1582146692);
bevt_6_tmpany_phold = bevl_tunode.bem_heldGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(484390330);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_tmpany_phold.bemd_1(178386925, bevl_fstep);
if (bevl_par == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 34 */ {
bevt_10_tmpany_phold = beva_node.bemd_0(205496670);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(688012872);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(484390330);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_tmpany_phold.bemd_1(178386925, bevl_fstep);
} /* Line: 35 */
if (bevl_par == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_14_tmpany_phold = bem_pathGet_0();
bevt_15_tmpany_phold = bece_BEC_2_5_8_BuildNamePath_bevo_2;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_has_1(bevt_15_tmpany_phold);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 37 */
 else  /* Line: 37 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 37 */ {
bevl_np2 = (BEC_2_6_8_SystemBasePath) bem_deleteFirstStep_0();
bevl_np = (BEC_2_6_8_SystemBasePath) bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 40 */
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(-1975163230);
if (bevl_clnode == null) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_17_tmpany_phold = bevl_clnode.bem_heldGet_0();
bevt_17_tmpany_phold.bemd_1(909898267, this);
} /* Line: 44 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_labelGetDirect_0() {
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 15, 16, 20, 20, 21, 21, 21, 24, 28, 29, 29, 29, 30, 30, 30, 31, 32, 33, 33, 33, 34, 34, 35, 35, 35, 35, 37, 37, 37, 37, 37, 37, 37, 0, 0, 0, 38, 39, 40, 42, 43, 43, 44, 44, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 30, 35, 36, 37, 38, 40, 68, 69, 70, 72, 74, 75, 77, 79, 80, 81, 82, 83, 84, 89, 90, 91, 92, 93, 95, 100, 101, 102, 103, 104, 109, 110, 113, 117, 120, 121, 122, 124, 125, 130, 131, 132, 137, 140, 144};
/* BEGIN LINEINFO 
assign 1 15 21
new 0 15 21
assign 1 15 22
colonGet 0 15 22
fromString 1 16 23
assign 1 20 30
undef 1 20 35
assign 1 21 36
split 1 21 36
assign 1 21 37
lastGet 0 21 37
return 1 21 38
return 1 24 40
assign 1 28 68
pathGet 0 28 68
assign 1 29 69
new 0 29 69
assign 1 29 70
equals 1 29 70
return 1 29 72
assign 1 30 74
new 0 30 74
assign 1 30 75
equals 1 30 75
return 1 30 77
assign 1 31 79
firstStepGet 0 31 79
assign 1 32 80
transUnitGet 0 32 80
assign 1 33 81
heldGet 0 33 81
assign 1 33 82
aliasedGet 0 33 82
assign 1 33 83
get 1 33 83
assign 1 34 84
undef 1 34 89
assign 1 35 90
buildGet 0 35 90
assign 1 35 91
emitDataGet 0 35 91
assign 1 35 92
aliasedGet 0 35 92
assign 1 35 93
get 1 35 93
assign 1 37 95
def 1 37 100
assign 1 37 101
pathGet 0 37 101
assign 1 37 102
new 0 37 102
assign 1 37 103
has 1 37 103
assign 1 37 104
not 0 37 109
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 38 120
deleteFirstStep 0 38 120
assign 1 39 121
add 1 39 121
assign 1 40 122
pathGet 0 40 122
assign 1 42 124
classGet 0 42 124
assign 1 43 125
def 1 43 130
assign 1 44 131
heldGet 0 44 131
addUsed 1 44 132
return 1 0 137
assign 1 0 140
assign 1 0 144
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1242864862: return bem_sourceFileNameGet_0();
case -1507957896: return bem_isAbsoluteGet_0();
case 347445468: return bem_deserializeClassNameGet_0();
case -910377260: return bem_pathGet_0();
case -1287291624: return bem_toString_0();
case -1718750264: return bem_tagGet_0();
case -841064746: return bem_labelGetDirect_0();
case 1739040137: return bem_fieldIteratorGet_0();
case 1278884210: return bem_stepsGet_0();
case 927247610: return bem_separatorGet_0();
case -1497387944: return bem_many_0();
case -908702369: return bem_stepListGet_0();
case -382967897: return bem_makeNonAbsolute_0();
case 855089063: return bem_toAny_0();
case -1820718044: return bem_echo_0();
case 1388220454: return bem_once_0();
case 1115941233: return bem_hashGet_0();
case 876979386: return bem_iteratorGet_0();
case 262448459: return bem_fieldNamesGet_0();
case -584837633: return bem_makeAbsolute_0();
case 1139687182: return bem_serializeToString_0();
case 1044385788: return bem_new_0();
case -380774728: return bem_serializationIteratorGet_0();
case 170011407: return bem_parentGet_0();
case 1516511629: return bem_serializeContents_0();
case -1288992480: return bem_separatorGetDirect_0();
case 2111384473: return bem_deleteFirstStep_0();
case -1936404363: return bem_create_0();
case 1846641427: return bem_classNameGet_0();
case 1897244050: return bem_pathGetDirect_0();
case -485032950: return bem_print_0();
case -771542888: return bem_labelGet_0();
case -194856632: return bem_firstStepGet_0();
case 1978340744: return bem_copy_0();
case -852452604: return bem_lastStepGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1158008951: return bem_pathSetDirect_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case -1684111948: return bem_labelSetDirect_1(bevd_0);
case -875855183: return bem_labelSet_1(bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case 1557443528: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -1465831844: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1218173325: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case 700307545: return bem_resolve_1(bevd_0);
case 1361754292: return bem_addSteps_1(bevd_0);
case -1979139572: return bem_pathSet_1(bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 212317316: return bem_addStep_1(bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case 830823701: return bem_separatorSet_1(bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case -1916883442: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -847200836: return bem_def_1(bevd_0);
case 483267729: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case 369876066: return bem_separatorSetDirect_1(bevd_0);
case 700838626: return bem_add_1(bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case -815577403: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1337377753: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 477404510: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1168427265: return bem_addSteps_2(bevd_0, bevd_1);
case 2022532152: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildNamePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_type;
}
}
}
