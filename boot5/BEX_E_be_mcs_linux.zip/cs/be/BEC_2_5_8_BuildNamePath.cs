namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_8_BuildNamePath : BEC_2_6_8_SystemBasePath {
public BEC_2_5_8_BuildNamePath() { }
static BEC_2_5_8_BuildNamePath() { }
private static byte[] becc_BEC_2_5_8_BuildNamePath_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x61,0x6D,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_5_8_BuildNamePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_0 = {0x73,0x65,0x6C,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_0, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_1 = {0x74,0x68,0x69,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_1, 4));
private static byte[] bece_BEC_2_5_8_BuildNamePath_bels_2 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_8_BuildNamePath_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_8_BuildNamePath_bels_2, 1));
public static new BEC_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_inst;

public static new BET_2_5_8_BuildNamePath bece_BEC_2_5_8_BuildNamePath_bevs_type;

public BEC_2_4_6_TextString bevp_label;
public override BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_separator = bevt_0_ta_ph.bem_colonGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_labelGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
if (bevp_label == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 19*/ {
bevt_2_ta_ph = bevp_path.bem_split_1(bevp_separator);
bevt_1_ta_ph = bevt_2_ta_ph.bem_lastGet_0();
return bevt_1_ta_ph;
} /* Line: 20*/
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_resolve_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_4_6_TextString bevl_oldpath = null;
BEC_2_4_6_TextString bevl_fstep = null;
BEC_2_5_4_BuildNode bevl_tunode = null;
BEC_2_6_8_SystemBasePath bevl_par = null;
BEC_2_6_8_SystemBasePath bevl_np2 = null;
BEC_2_6_8_SystemBasePath bevl_np = null;
BEC_2_5_4_BuildNode bevl_clnode = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
bevl_oldpath = bem_pathGet_0();
bevt_2_ta_ph = bece_BEC_2_5_8_BuildNamePath_bevo_0;
bevt_1_ta_ph = bevl_oldpath.bem_equals_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool)/* Line: 28*/ {
return this;
} /* Line: 28*/
bevt_4_ta_ph = bece_BEC_2_5_8_BuildNamePath_bevo_1;
bevt_3_ta_ph = bevl_oldpath.bem_equals_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool)/* Line: 29*/ {
return this;
} /* Line: 29*/
bevl_fstep = bem_firstStepGet_0();
bevl_tunode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(26993237);
bevt_6_ta_ph = bevl_tunode.bem_heldGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(2092054957);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_5_ta_ph.bemd_1(-783899545, bevl_fstep);
if (bevl_par == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 33*/ {
bevt_10_ta_ph = beva_node.bemd_0(346243671);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1068915473);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(2092054957);
bevl_par = (BEC_2_6_8_SystemBasePath) bevt_8_ta_ph.bemd_1(-783899545, bevl_fstep);
} /* Line: 34*/
if (bevl_par == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_14_ta_ph = bem_pathGet_0();
bevt_15_ta_ph = bece_BEC_2_5_8_BuildNamePath_bevo_2;
bevt_13_ta_ph = bevt_14_ta_ph.bem_has_1(bevt_15_ta_ph);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 36*/
 else /* Line: 36*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 36*/ {
bevl_np2 = (BEC_2_6_8_SystemBasePath) bem_deleteFirstStep_0();
bevl_np = (BEC_2_6_8_SystemBasePath) bevl_par.bem_add_1(bevl_np2);
bevp_path = bevl_np.bem_pathGet_0();
} /* Line: 39*/
bevl_clnode = (BEC_2_5_4_BuildNode) beva_node.bemd_0(-556255238);
if (bevl_clnode == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 42*/ {
bevt_17_ta_ph = bevl_clnode.bem_heldGet_0();
bevt_17_ta_ph.bemd_1(-1512104747, this);
} /* Line: 43*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_labelGetDirect_0() {
return bevp_label;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_labelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_label = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {14, 14, 15, 19, 19, 20, 20, 20, 23, 27, 28, 28, 28, 29, 29, 29, 30, 31, 32, 32, 32, 33, 33, 34, 34, 34, 34, 36, 36, 36, 36, 36, 36, 36, 0, 0, 0, 37, 38, 39, 41, 42, 42, 43, 43, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 30, 35, 36, 37, 38, 40, 68, 69, 70, 72, 74, 75, 77, 79, 80, 81, 82, 83, 84, 89, 90, 91, 92, 93, 95, 100, 101, 102, 103, 104, 109, 110, 113, 117, 120, 121, 122, 124, 125, 130, 131, 132, 137, 140, 144};
/* BEGIN LINEINFO 
assign 1 14 21
new 0 14 21
assign 1 14 22
colonGet 0 14 22
fromString 1 15 23
assign 1 19 30
undef 1 19 35
assign 1 20 36
split 1 20 36
assign 1 20 37
lastGet 0 20 37
return 1 20 38
return 1 23 40
assign 1 27 68
pathGet 0 27 68
assign 1 28 69
new 0 28 69
assign 1 28 70
equals 1 28 70
return 1 28 72
assign 1 29 74
new 0 29 74
assign 1 29 75
equals 1 29 75
return 1 29 77
assign 1 30 79
firstStepGet 0 30 79
assign 1 31 80
transUnitGet 0 31 80
assign 1 32 81
heldGet 0 32 81
assign 1 32 82
aliasedGet 0 32 82
assign 1 32 83
get 1 32 83
assign 1 33 84
undef 1 33 89
assign 1 34 90
buildGet 0 34 90
assign 1 34 91
emitDataGet 0 34 91
assign 1 34 92
aliasedGet 0 34 92
assign 1 34 93
get 1 34 93
assign 1 36 95
def 1 36 100
assign 1 36 101
pathGet 0 36 101
assign 1 36 102
new 0 36 102
assign 1 36 103
has 1 36 103
assign 1 36 104
not 0 36 109
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 37 120
deleteFirstStep 0 37 120
assign 1 38 121
add 1 38 121
assign 1 39 122
pathGet 0 39 122
assign 1 41 124
classGet 0 41 124
assign 1 42 125
def 1 42 130
assign 1 43 131
heldGet 0 43 131
addUsed 1 43 132
return 1 0 137
assign 1 0 140
assign 1 0 144
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 501088997: return bem_sourceFileNameGet_0();
case 232251157: return bem_makeNonAbsolute_0();
case 1529876014: return bem_makeAbsolute_0();
case 1981368170: return bem_isAbsoluteGet_0();
case -639297756: return bem_toAny_0();
case 281444821: return bem_fieldIteratorGet_0();
case 1125049001: return bem_labelGetDirect_0();
case -1486279572: return bem_serializeContents_0();
case 582600813: return bem_lastStepGet_0();
case 1231869100: return bem_labelGet_0();
case -1275325619: return bem_toString_0();
case -2017009146: return bem_new_0();
case -1803035233: return bem_deleteFirstStep_0();
case -744679096: return bem_fieldNamesGet_0();
case 1361918892: return bem_stepsGet_0();
case 665089720: return bem_pathGetDirect_0();
case -1005119995: return bem_many_0();
case -1583672278: return bem_echo_0();
case 611702865: return bem_copy_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 1413470669: return bem_firstStepGet_0();
case -1754478112: return bem_print_0();
case -1160702942: return bem_pathGet_0();
case -678541085: return bem_classNameGet_0();
case -1475550710: return bem_create_0();
case 1823450880: return bem_stepListGet_0();
case 119461913: return bem_tagGet_0();
case -545556484: return bem_once_0();
case 973726426: return bem_parentGet_0();
case 1002539641: return bem_separatorGet_0();
case -225870373: return bem_serializeToString_0();
case -1845366914: return bem_separatorGetDirect_0();
case 2045941275: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -850786392: return bem_labelSetDirect_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1278200359: return bem_resolve_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case 1941772529: return bem_addSteps_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case -1871616572: return bem_labelSet_1(bevd_0);
case -554175306: return bem_pathSet_1(bevd_0);
case -154408220: return bem_separatorSet_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 15953581: return bem_pathSetDirect_1(bevd_0);
case 1867275181: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case 2128667968: return bem_addStep_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case -2021462698: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 2121036928: return bem_separatorSetDirect_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 590890770: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1744665665: return bem_add_1(bevd_0);
case 902067997: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case -1698900309: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case -460451190: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case -496230308: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1836363946: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -425086271: return bem_addSteps_2(bevd_0, bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildNamePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_8_BuildNamePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildNamePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst = (BEC_2_5_8_BuildNamePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildNamePath.bece_BEC_2_5_8_BuildNamePath_bevs_type;
}
}
}
