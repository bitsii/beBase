namespace be {
/* IO:File: source/build/Pass3.be */
public sealed class BEC_3_5_5_5_BuildVisitPass3 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass3() { }
static BEC_3_5_5_5_BuildVisitPass3() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass3_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x33};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass3_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x33,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass3_bels_0 = {0x2D};
public static new BEC_3_5_5_5_BuildVisitPass3 bece_BEC_3_5_5_5_BuildVisitPass3_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass3 bece_BEC_3_5_5_5_BuildVisitPass3_bevs_type;

public BEC_2_5_4_BuildNode bevp_container;
public BEC_2_4_3_MathInt bevp_nestComment;
public BEC_2_4_3_MathInt bevp_strqCnt;
public BEC_2_5_4_BuildNode bevp_goingStr;
public BEC_2_4_3_MathInt bevp_quoteType;
public BEC_2_5_4_LogicBool bevp_inLc;
public BEC_2_5_4_LogicBool bevp_inSpace;
public BEC_2_5_4_LogicBool bevp_inNl;
public BEC_2_5_4_LogicBool bevp_inStr;
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bevp_nestComment = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_strqCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_inLc = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_inSpace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_inNl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_inStr = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_toRet = null;
BEC_2_5_4_BuildNode bevl_xn = null;
BEC_2_4_3_MathInt bevl_typename = null;
BEC_2_5_4_BuildNode bevl_nextPeer = null;
BEC_2_4_3_MathInt bevl_nextPeerTypename = null;
BEC_2_4_3_MathInt bevl_fsc = null;
BEC_2_4_3_MathInt bevl_csc = null;
BEC_2_4_3_MathInt bevl_ia = null;
BEC_2_5_4_BuildNode bevl_vback = null;
BEC_2_5_4_BuildNode bevl_pre = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_12_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_13_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_14_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_15_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_16_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_17_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_18_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_19_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_20_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_21_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_22_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_23_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_24_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_25_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_26_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_27_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_28_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_29_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_30_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_31_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_32_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_33_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_34_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_35_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_36_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_37_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_38_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_39_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_40_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_41_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_42_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_43_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_44_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_45_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_46_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_47_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_48_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_49_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_50_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_51_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_52_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_53_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_54_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_5_4_BuildNode bevt_62_ta_ph = null;
BEC_2_5_4_BuildNode bevt_63_ta_ph = null;
BEC_2_5_4_LogicBool bevt_64_ta_ph = null;
BEC_2_4_3_MathInt bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_5_4_LogicBool bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_5_4_LogicBool bevt_69_ta_ph = null;
BEC_2_5_4_BuildNode bevt_70_ta_ph = null;
BEC_2_5_4_BuildNode bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_4_3_MathInt bevt_82_ta_ph = null;
BEC_2_5_4_LogicBool bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_5_4_LogicBool bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_4_3_MathInt bevt_92_ta_ph = null;
BEC_2_5_4_LogicBool bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_4_3_MathInt bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_4_3_MathInt bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_5_4_LogicBool bevt_100_ta_ph = null;
BEC_2_4_3_MathInt bevt_101_ta_ph = null;
BEC_2_4_3_MathInt bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_6_6_SystemObject bevt_104_ta_ph = null;
BEC_2_6_6_SystemObject bevt_105_ta_ph = null;
BEC_2_6_6_SystemObject bevt_106_ta_ph = null;
BEC_2_5_4_LogicBool bevt_107_ta_ph = null;
BEC_2_5_4_LogicBool bevt_108_ta_ph = null;
BEC_2_4_3_MathInt bevt_109_ta_ph = null;
BEC_2_4_3_MathInt bevt_110_ta_ph = null;
BEC_2_4_3_MathInt bevt_111_ta_ph = null;
BEC_2_5_4_LogicBool bevt_112_ta_ph = null;
BEC_2_4_3_MathInt bevt_113_ta_ph = null;
BEC_2_6_6_SystemObject bevt_114_ta_ph = null;
BEC_2_6_6_SystemObject bevt_115_ta_ph = null;
BEC_2_6_6_SystemObject bevt_116_ta_ph = null;
BEC_2_5_4_LogicBool bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_5_4_LogicBool bevt_119_ta_ph = null;
BEC_2_4_3_MathInt bevt_120_ta_ph = null;
BEC_2_5_4_LogicBool bevt_121_ta_ph = null;
BEC_2_5_4_LogicBool bevt_122_ta_ph = null;
BEC_2_6_6_SystemObject bevt_123_ta_ph = null;
BEC_2_6_6_SystemObject bevt_124_ta_ph = null;
BEC_2_6_6_SystemObject bevt_125_ta_ph = null;
BEC_2_6_6_SystemObject bevt_126_ta_ph = null;
BEC_2_6_6_SystemObject bevt_127_ta_ph = null;
BEC_2_6_6_SystemObject bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_4_3_MathInt bevt_130_ta_ph = null;
BEC_2_5_4_LogicBool bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_5_4_LogicBool bevt_134_ta_ph = null;
BEC_2_5_4_BuildNode bevt_135_ta_ph = null;
BEC_2_5_4_BuildNode bevt_136_ta_ph = null;
BEC_2_5_4_LogicBool bevt_137_ta_ph = null;
BEC_2_4_3_MathInt bevt_138_ta_ph = null;
BEC_2_4_3_MathInt bevt_139_ta_ph = null;
BEC_2_5_4_LogicBool bevt_140_ta_ph = null;
BEC_2_4_3_MathInt bevt_141_ta_ph = null;
BEC_2_5_4_LogicBool bevt_142_ta_ph = null;
BEC_2_5_4_LogicBool bevt_143_ta_ph = null;
BEC_2_4_3_MathInt bevt_144_ta_ph = null;
BEC_2_5_4_LogicBool bevt_145_ta_ph = null;
BEC_2_5_4_BuildNode bevt_146_ta_ph = null;
BEC_2_5_4_LogicBool bevt_147_ta_ph = null;
BEC_2_5_4_LogicBool bevt_148_ta_ph = null;
BEC_2_4_3_MathInt bevt_149_ta_ph = null;
BEC_2_4_3_MathInt bevt_150_ta_ph = null;
BEC_2_5_4_LogicBool bevt_151_ta_ph = null;
BEC_2_5_4_LogicBool bevt_152_ta_ph = null;
BEC_2_4_3_MathInt bevt_153_ta_ph = null;
BEC_2_4_3_MathInt bevt_154_ta_ph = null;
BEC_2_5_4_LogicBool bevt_155_ta_ph = null;
BEC_2_4_3_MathInt bevt_156_ta_ph = null;
BEC_2_4_3_MathInt bevt_157_ta_ph = null;
BEC_2_5_4_LogicBool bevt_158_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_159_ta_ph = null;
BEC_2_4_3_MathInt bevt_160_ta_ph = null;
BEC_2_5_4_BuildNode bevt_161_ta_ph = null;
BEC_2_4_6_TextString bevt_162_ta_ph = null;
BEC_2_4_6_TextString bevt_163_ta_ph = null;
BEC_2_6_6_SystemObject bevt_164_ta_ph = null;
BEC_2_5_4_BuildNode bevt_165_ta_ph = null;
BEC_2_5_4_LogicBool bevt_166_ta_ph = null;
BEC_2_4_3_MathInt bevt_167_ta_ph = null;
BEC_2_5_4_LogicBool bevt_168_ta_ph = null;
BEC_2_5_4_LogicBool bevt_169_ta_ph = null;
BEC_2_4_3_MathInt bevt_170_ta_ph = null;
BEC_2_4_3_MathInt bevt_171_ta_ph = null;
BEC_2_6_6_SystemObject bevt_172_ta_ph = null;
BEC_2_6_6_SystemObject bevt_173_ta_ph = null;
BEC_2_6_6_SystemObject bevt_174_ta_ph = null;
BEC_2_5_4_BuildNode bevt_175_ta_ph = null;
BEC_2_5_4_BuildNode bevt_176_ta_ph = null;
BEC_2_5_4_BuildNode bevt_177_ta_ph = null;
BEC_2_5_4_LogicBool bevt_178_ta_ph = null;
BEC_2_4_3_MathInt bevt_179_ta_ph = null;
BEC_2_5_4_LogicBool bevt_180_ta_ph = null;
BEC_2_5_4_LogicBool bevt_181_ta_ph = null;
BEC_2_4_3_MathInt bevt_182_ta_ph = null;
BEC_2_4_3_MathInt bevt_183_ta_ph = null;
BEC_2_6_6_SystemObject bevt_184_ta_ph = null;
BEC_2_6_6_SystemObject bevt_185_ta_ph = null;
BEC_2_6_6_SystemObject bevt_186_ta_ph = null;
BEC_2_5_4_BuildNode bevt_187_ta_ph = null;
BEC_2_5_4_BuildNode bevt_188_ta_ph = null;
BEC_2_5_4_BuildNode bevt_189_ta_ph = null;
BEC_2_5_4_LogicBool bevt_190_ta_ph = null;
BEC_2_4_3_MathInt bevt_191_ta_ph = null;
BEC_2_5_4_LogicBool bevt_192_ta_ph = null;
BEC_2_5_4_BuildNode bevt_193_ta_ph = null;
BEC_2_5_4_LogicBool bevt_194_ta_ph = null;
BEC_2_4_3_MathInt bevt_195_ta_ph = null;
BEC_2_5_4_BuildNode bevt_196_ta_ph = null;
BEC_2_4_3_MathInt bevt_197_ta_ph = null;
BEC_2_6_6_SystemObject bevt_198_ta_ph = null;
BEC_2_6_6_SystemObject bevt_199_ta_ph = null;
BEC_2_6_6_SystemObject bevt_200_ta_ph = null;
BEC_2_5_4_BuildNode bevt_201_ta_ph = null;
BEC_2_4_3_MathInt bevt_202_ta_ph = null;
BEC_2_5_4_BuildNode bevt_203_ta_ph = null;
BEC_2_5_4_BuildNode bevt_204_ta_ph = null;
BEC_2_5_4_LogicBool bevt_205_ta_ph = null;
BEC_2_4_3_MathInt bevt_206_ta_ph = null;
BEC_2_5_4_LogicBool bevt_207_ta_ph = null;
BEC_2_5_4_BuildNode bevt_208_ta_ph = null;
BEC_2_5_4_LogicBool bevt_209_ta_ph = null;
BEC_2_4_3_MathInt bevt_210_ta_ph = null;
BEC_2_5_4_BuildNode bevt_211_ta_ph = null;
BEC_2_4_3_MathInt bevt_212_ta_ph = null;
BEC_2_6_6_SystemObject bevt_213_ta_ph = null;
BEC_2_6_6_SystemObject bevt_214_ta_ph = null;
BEC_2_6_6_SystemObject bevt_215_ta_ph = null;
BEC_2_5_4_BuildNode bevt_216_ta_ph = null;
BEC_2_4_3_MathInt bevt_217_ta_ph = null;
BEC_2_5_4_BuildNode bevt_218_ta_ph = null;
BEC_2_5_4_BuildNode bevt_219_ta_ph = null;
BEC_2_5_4_LogicBool bevt_220_ta_ph = null;
BEC_2_4_3_MathInt bevt_221_ta_ph = null;
BEC_2_5_4_LogicBool bevt_222_ta_ph = null;
BEC_2_5_4_LogicBool bevt_223_ta_ph = null;
BEC_2_4_3_MathInt bevt_224_ta_ph = null;
BEC_2_4_3_MathInt bevt_225_ta_ph = null;
BEC_2_6_6_SystemObject bevt_226_ta_ph = null;
BEC_2_6_6_SystemObject bevt_227_ta_ph = null;
BEC_2_6_6_SystemObject bevt_228_ta_ph = null;
BEC_2_5_4_BuildNode bevt_229_ta_ph = null;
BEC_2_5_4_BuildNode bevt_230_ta_ph = null;
BEC_2_5_4_BuildNode bevt_231_ta_ph = null;
BEC_2_5_4_LogicBool bevt_232_ta_ph = null;
BEC_2_4_3_MathInt bevt_233_ta_ph = null;
BEC_2_5_4_LogicBool bevt_234_ta_ph = null;
BEC_2_5_4_LogicBool bevt_235_ta_ph = null;
BEC_2_4_3_MathInt bevt_236_ta_ph = null;
BEC_2_4_3_MathInt bevt_237_ta_ph = null;
BEC_2_6_6_SystemObject bevt_238_ta_ph = null;
BEC_2_6_6_SystemObject bevt_239_ta_ph = null;
BEC_2_6_6_SystemObject bevt_240_ta_ph = null;
BEC_2_5_4_BuildNode bevt_241_ta_ph = null;
BEC_2_5_4_BuildNode bevt_242_ta_ph = null;
BEC_2_5_4_BuildNode bevt_243_ta_ph = null;
BEC_2_5_4_LogicBool bevt_244_ta_ph = null;
BEC_2_4_3_MathInt bevt_245_ta_ph = null;
BEC_2_5_4_LogicBool bevt_246_ta_ph = null;
BEC_2_5_4_LogicBool bevt_247_ta_ph = null;
BEC_2_4_3_MathInt bevt_248_ta_ph = null;
BEC_2_5_4_LogicBool bevt_249_ta_ph = null;
BEC_2_5_4_BuildNode bevt_250_ta_ph = null;
BEC_2_5_4_BuildNode bevt_251_ta_ph = null;
BEC_2_5_4_LogicBool bevt_252_ta_ph = null;
BEC_2_4_3_MathInt bevt_253_ta_ph = null;
BEC_2_5_4_BuildNode bevt_254_ta_ph = null;
BEC_2_5_4_BuildNode bevt_255_ta_ph = null;
BEC_2_4_3_MathInt bevt_256_ta_ph = null;
BEC_2_4_3_MathInt bevt_257_ta_ph = null;
BEC_2_6_6_SystemObject bevt_258_ta_ph = null;
BEC_2_6_6_SystemObject bevt_259_ta_ph = null;
BEC_2_6_6_SystemObject bevt_260_ta_ph = null;
BEC_2_6_6_SystemObject bevt_261_ta_ph = null;
BEC_2_5_4_BuildNode bevt_262_ta_ph = null;
BEC_2_6_6_SystemObject bevt_263_ta_ph = null;
BEC_2_5_4_BuildNode bevt_264_ta_ph = null;
BEC_2_5_4_BuildNode bevt_265_ta_ph = null;
BEC_2_5_4_BuildNode bevt_266_ta_ph = null;
BEC_2_5_4_BuildNode bevt_267_ta_ph = null;
BEC_2_5_4_BuildNode bevt_268_ta_ph = null;
BEC_2_5_4_BuildNode bevt_269_ta_ph = null;
BEC_2_5_4_BuildNode bevt_270_ta_ph = null;
BEC_2_4_3_MathInt bevt_271_ta_ph = null;
BEC_2_6_6_SystemObject bevt_272_ta_ph = null;
BEC_2_6_6_SystemObject bevt_273_ta_ph = null;
BEC_2_6_6_SystemObject bevt_274_ta_ph = null;
BEC_2_5_4_BuildNode bevt_275_ta_ph = null;
BEC_2_5_4_BuildNode bevt_276_ta_ph = null;
BEC_2_5_4_BuildNode bevt_277_ta_ph = null;
BEC_2_5_4_LogicBool bevt_278_ta_ph = null;
BEC_2_4_3_MathInt bevt_279_ta_ph = null;
BEC_2_5_4_LogicBool bevt_280_ta_ph = null;
BEC_2_5_4_LogicBool bevt_281_ta_ph = null;
BEC_2_4_3_MathInt bevt_282_ta_ph = null;
BEC_2_5_4_LogicBool bevt_283_ta_ph = null;
BEC_2_5_4_BuildNode bevt_284_ta_ph = null;
BEC_2_5_4_BuildNode bevt_285_ta_ph = null;
BEC_2_5_4_LogicBool bevt_286_ta_ph = null;
BEC_2_4_3_MathInt bevt_287_ta_ph = null;
BEC_2_5_4_BuildNode bevt_288_ta_ph = null;
BEC_2_5_4_BuildNode bevt_289_ta_ph = null;
BEC_2_4_3_MathInt bevt_290_ta_ph = null;
BEC_2_4_3_MathInt bevt_291_ta_ph = null;
BEC_2_6_6_SystemObject bevt_292_ta_ph = null;
BEC_2_6_6_SystemObject bevt_293_ta_ph = null;
BEC_2_6_6_SystemObject bevt_294_ta_ph = null;
BEC_2_6_6_SystemObject bevt_295_ta_ph = null;
BEC_2_5_4_BuildNode bevt_296_ta_ph = null;
BEC_2_6_6_SystemObject bevt_297_ta_ph = null;
BEC_2_5_4_BuildNode bevt_298_ta_ph = null;
BEC_2_5_4_BuildNode bevt_299_ta_ph = null;
BEC_2_5_4_BuildNode bevt_300_ta_ph = null;
BEC_2_5_4_BuildNode bevt_301_ta_ph = null;
BEC_2_5_4_BuildNode bevt_302_ta_ph = null;
BEC_2_5_4_BuildNode bevt_303_ta_ph = null;
BEC_2_5_4_BuildNode bevt_304_ta_ph = null;
BEC_2_4_3_MathInt bevt_305_ta_ph = null;
BEC_2_6_6_SystemObject bevt_306_ta_ph = null;
BEC_2_6_6_SystemObject bevt_307_ta_ph = null;
BEC_2_6_6_SystemObject bevt_308_ta_ph = null;
BEC_2_5_4_BuildNode bevt_309_ta_ph = null;
BEC_2_5_4_BuildNode bevt_310_ta_ph = null;
BEC_2_5_4_BuildNode bevt_311_ta_ph = null;
BEC_2_5_4_LogicBool bevt_312_ta_ph = null;
BEC_2_4_3_MathInt bevt_313_ta_ph = null;
BEC_2_5_4_LogicBool bevt_314_ta_ph = null;
BEC_2_5_4_LogicBool bevt_315_ta_ph = null;
BEC_2_4_3_MathInt bevt_316_ta_ph = null;
BEC_2_4_3_MathInt bevt_317_ta_ph = null;
BEC_2_6_6_SystemObject bevt_318_ta_ph = null;
BEC_2_6_6_SystemObject bevt_319_ta_ph = null;
BEC_2_6_6_SystemObject bevt_320_ta_ph = null;
BEC_2_5_4_BuildNode bevt_321_ta_ph = null;
BEC_2_5_4_BuildNode bevt_322_ta_ph = null;
BEC_2_5_4_BuildNode bevt_323_ta_ph = null;
BEC_2_5_4_LogicBool bevt_324_ta_ph = null;
BEC_2_4_3_MathInt bevt_325_ta_ph = null;
BEC_2_5_4_LogicBool bevt_326_ta_ph = null;
BEC_2_5_4_LogicBool bevt_327_ta_ph = null;
BEC_2_4_3_MathInt bevt_328_ta_ph = null;
BEC_2_4_3_MathInt bevt_329_ta_ph = null;
BEC_2_6_6_SystemObject bevt_330_ta_ph = null;
BEC_2_6_6_SystemObject bevt_331_ta_ph = null;
BEC_2_6_6_SystemObject bevt_332_ta_ph = null;
BEC_2_5_4_BuildNode bevt_333_ta_ph = null;
BEC_2_5_4_BuildNode bevt_334_ta_ph = null;
BEC_2_5_4_BuildNode bevt_335_ta_ph = null;
BEC_2_5_4_LogicBool bevt_336_ta_ph = null;
BEC_2_4_3_MathInt bevt_337_ta_ph = null;
BEC_2_5_4_LogicBool bevt_338_ta_ph = null;
BEC_2_5_4_LogicBool bevt_339_ta_ph = null;
BEC_2_4_3_MathInt bevt_340_ta_ph = null;
BEC_2_4_3_MathInt bevt_341_ta_ph = null;
BEC_2_6_6_SystemObject bevt_342_ta_ph = null;
BEC_2_6_6_SystemObject bevt_343_ta_ph = null;
BEC_2_6_6_SystemObject bevt_344_ta_ph = null;
BEC_2_5_4_BuildNode bevt_345_ta_ph = null;
BEC_2_5_4_BuildNode bevt_346_ta_ph = null;
BEC_2_5_4_BuildNode bevt_347_ta_ph = null;
BEC_2_5_4_LogicBool bevt_348_ta_ph = null;
BEC_2_4_3_MathInt bevt_349_ta_ph = null;
BEC_2_5_4_LogicBool bevt_350_ta_ph = null;
BEC_2_5_4_LogicBool bevt_351_ta_ph = null;
BEC_2_4_3_MathInt bevt_352_ta_ph = null;
BEC_2_4_3_MathInt bevt_353_ta_ph = null;
BEC_2_6_6_SystemObject bevt_354_ta_ph = null;
BEC_2_6_6_SystemObject bevt_355_ta_ph = null;
BEC_2_6_6_SystemObject bevt_356_ta_ph = null;
BEC_2_5_4_BuildNode bevt_357_ta_ph = null;
BEC_2_5_4_BuildNode bevt_358_ta_ph = null;
BEC_2_5_4_BuildNode bevt_359_ta_ph = null;
BEC_2_5_4_LogicBool bevt_360_ta_ph = null;
BEC_2_4_3_MathInt bevt_361_ta_ph = null;
BEC_2_5_4_LogicBool bevt_362_ta_ph = null;
BEC_2_5_4_LogicBool bevt_363_ta_ph = null;
BEC_2_4_3_MathInt bevt_364_ta_ph = null;
BEC_2_4_3_MathInt bevt_365_ta_ph = null;
BEC_2_6_6_SystemObject bevt_366_ta_ph = null;
BEC_2_6_6_SystemObject bevt_367_ta_ph = null;
BEC_2_6_6_SystemObject bevt_368_ta_ph = null;
BEC_2_5_4_BuildNode bevt_369_ta_ph = null;
BEC_2_5_4_BuildNode bevt_370_ta_ph = null;
BEC_2_5_4_BuildNode bevt_371_ta_ph = null;
BEC_2_5_4_LogicBool bevt_372_ta_ph = null;
BEC_2_4_3_MathInt bevt_373_ta_ph = null;
BEC_2_5_4_LogicBool bevt_374_ta_ph = null;
BEC_2_5_4_LogicBool bevt_375_ta_ph = null;
BEC_2_4_3_MathInt bevt_376_ta_ph = null;
BEC_2_4_3_MathInt bevt_377_ta_ph = null;
BEC_2_6_6_SystemObject bevt_378_ta_ph = null;
BEC_2_6_6_SystemObject bevt_379_ta_ph = null;
BEC_2_6_6_SystemObject bevt_380_ta_ph = null;
BEC_2_5_4_BuildNode bevt_381_ta_ph = null;
BEC_2_5_4_BuildNode bevt_382_ta_ph = null;
BEC_2_5_4_BuildNode bevt_383_ta_ph = null;
BEC_2_5_4_LogicBool bevt_384_ta_ph = null;
BEC_2_4_3_MathInt bevt_385_ta_ph = null;
BEC_2_5_4_LogicBool bevt_386_ta_ph = null;
BEC_2_5_4_LogicBool bevt_387_ta_ph = null;
BEC_2_4_3_MathInt bevt_388_ta_ph = null;
BEC_2_4_3_MathInt bevt_389_ta_ph = null;
BEC_2_6_6_SystemObject bevt_390_ta_ph = null;
BEC_2_6_6_SystemObject bevt_391_ta_ph = null;
BEC_2_6_6_SystemObject bevt_392_ta_ph = null;
BEC_2_5_4_BuildNode bevt_393_ta_ph = null;
BEC_2_5_4_BuildNode bevt_394_ta_ph = null;
BEC_2_5_4_BuildNode bevt_395_ta_ph = null;
BEC_2_5_4_LogicBool bevt_396_ta_ph = null;
BEC_2_4_3_MathInt bevt_397_ta_ph = null;
BEC_2_5_4_LogicBool bevt_398_ta_ph = null;
BEC_2_4_3_MathInt bevt_399_ta_ph = null;
BEC_2_5_4_BuildNode bevt_400_ta_ph = null;
bevl_typename = beva_node.bem_typenameGet_0();
bevl_nextPeer = beva_node.bem_nextPeerGet_0();
if (bevl_nextPeer == null) {
bevt_55_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_55_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_55_ta_ph.bevi_bool)/* Line: 48*/ {
bevl_nextPeerTypename = bevl_nextPeer.bem_typenameGet_0();
} /* Line: 49*/
bevt_57_ta_ph = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_typename.bevi_int == bevt_57_ta_ph.bevi_int) {
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 53*/ {
if (bevl_nextPeer == null) {
bevt_58_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_58_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_58_ta_ph.bevi_bool)/* Line: 53*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 53*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 53*/
 else /* Line: 53*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 53*/ {
bevt_60_ta_ph = bevp_ntypes.bem_MULTIPLYGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_60_ta_ph.bevi_int) {
bevt_59_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_59_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_59_ta_ph.bevi_bool)/* Line: 53*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 53*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 53*/
 else /* Line: 53*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 53*/ {
if (bevp_inStr.bevi_bool) {
bevt_61_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_61_ta_ph.bevi_bool)/* Line: 53*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 53*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 53*/
 else /* Line: 53*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 53*/ {
bevp_nestComment.bevi_int++;
bevt_62_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_62_ta_ph.bem_nextDescendGet_0();
bevt_63_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_63_ta_ph.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 59*/
bevt_65_ta_ph = bevp_ntypes.bem_MULTIPLYGet_0();
if (bevl_typename.bevi_int == bevt_65_ta_ph.bevi_int) {
bevt_64_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_64_ta_ph.bevi_bool)/* Line: 61*/ {
if (bevl_nextPeer == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 61*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 61*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 61*/
 else /* Line: 61*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 61*/ {
bevt_68_ta_ph = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_68_ta_ph.bevi_int) {
bevt_67_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_67_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_67_ta_ph.bevi_bool)/* Line: 61*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 61*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 61*/
 else /* Line: 61*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 61*/ {
if (bevp_inStr.bevi_bool) {
bevt_69_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_69_ta_ph.bevi_bool)/* Line: 61*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 61*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 61*/
 else /* Line: 61*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 61*/ {
bevp_nestComment.bem_decrementValue_0();
bevt_70_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_70_ta_ph.bem_nextDescendGet_0();
bevt_71_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_71_ta_ph.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 67*/
bevt_73_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_nestComment.bevi_int > bevt_73_ta_ph.bevi_int) {
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_72_ta_ph.bevi_bool)/* Line: 69*/ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 72*/
if (bevp_inStr.bevi_bool) {
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 74*/ {
if (bevp_inLc.bevi_bool) {
bevt_75_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_75_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_75_ta_ph.bevi_bool)/* Line: 74*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 74*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 74*/
 else /* Line: 74*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 74*/ {
bevt_77_ta_ph = bevp_ntypes.bem_STRQGet_0();
if (bevl_typename.bevi_int == bevt_77_ta_ph.bevi_int) {
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 74*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 74*/ {
bevt_79_ta_ph = bevp_ntypes.bem_WSTRQGet_0();
if (bevl_typename.bevi_int == bevt_79_ta_ph.bevi_int) {
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 74*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 74*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 74*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 74*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 74*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 74*/
 else /* Line: 74*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 74*/ {
bevl_xn = beva_node.bem_nextPeerGet_0();
bevp_strqCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_quoteType = beva_node.bem_typenameGet_0();
while (true)
/* Line: 78*/ {
if (bevl_xn == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 78*/ {
bevt_82_ta_ph = bevl_xn.bem_typenameGet_0();
if (bevt_82_ta_ph.bevi_int == bevp_quoteType.bevi_int) {
bevt_81_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_81_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_81_ta_ph.bevi_bool)/* Line: 78*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 78*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 78*/
 else /* Line: 78*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 78*/ {
bevp_strqCnt.bevi_int++;
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 81*/
 else /* Line: 78*/ {
break;
} /* Line: 78*/
} /* Line: 78*/
bevt_84_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (bevp_strqCnt.bevi_int == bevt_84_ta_ph.bevi_int) {
bevt_83_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_83_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_83_ta_ph.bevi_bool)/* Line: 83*/ {
bevp_strqCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_85_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
beva_node.bem_heldSet_1(bevt_85_ta_ph);
bevt_86_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
beva_node.bem_typenameSet_1(bevt_86_ta_ph);
bevt_87_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_node.bem_typeDetailSet_1(bevt_87_ta_ph);
} /* Line: 87*/
 else /* Line: 88*/ {
bevp_inStr = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_goingStr = beva_node;
bevt_88_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
beva_node.bem_heldSet_1(bevt_88_ta_ph);
bevt_90_ta_ph = bevp_ntypes.bem_WSTRQGet_0();
if (bevl_typename.bevi_int == bevt_90_ta_ph.bevi_int) {
bevt_89_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_89_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_89_ta_ph.bevi_bool)/* Line: 92*/ {
bevt_91_ta_ph = bevp_ntypes.bem_WSTRINGLGet_0();
bevp_goingStr.bem_typenameSet_1(bevt_91_ta_ph);
} /* Line: 94*/
 else /* Line: 95*/ {
bevt_92_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
bevp_goingStr.bem_typenameSet_1(bevt_92_ta_ph);
} /* Line: 96*/
} /* Line: 92*/
return bevl_xn;
} /* Line: 99*/
if (bevp_inStr.bevi_bool)/* Line: 101*/ {
if (bevp_inLc.bevi_bool) {
bevt_93_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_93_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_93_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
 else /* Line: 101*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_95_ta_ph = bevp_goingStr.bem_typenameGet_0();
bevt_96_ta_ph = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_95_ta_ph.bevi_int == bevt_96_ta_ph.bevi_int) {
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_94_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_94_ta_ph.bevi_bool)/* Line: 102*/ {
bevt_98_ta_ph = bevp_ntypes.bem_FSLASHGet_0();
if (bevl_typename.bevi_int == bevt_98_ta_ph.bevi_int) {
bevt_97_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_97_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_97_ta_ph.bevi_bool)/* Line: 102*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 102*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 102*/
 else /* Line: 102*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 102*/ {
beva_node.bem_delayDelete_0();
bevl_xn = beva_node.bem_nextPeerGet_0();
bevl_fsc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 106*/ {
if (bevl_xn == null) {
bevt_99_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_99_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_99_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_101_ta_ph = bevl_xn.bem_typenameGet_0();
bevt_102_ta_ph = bevp_ntypes.bem_FSLASHGet_0();
if (bevt_101_ta_ph.bevi_int == bevt_102_ta_ph.bevi_int) {
bevt_100_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_100_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_100_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 106*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 106*/
 else /* Line: 106*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_11_ta_anchor.bevi_bool)/* Line: 106*/ {
bevl_fsc.bevi_int++;
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 109*/
 else /* Line: 106*/ {
break;
} /* Line: 106*/
} /* Line: 106*/
bevl_ia = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 111*/ {
if (bevl_ia.bevi_int < bevl_fsc.bevi_int) {
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_103_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_103_ta_ph.bevi_bool)/* Line: 111*/ {
bevt_105_ta_ph = bevp_goingStr.bem_heldGet_0();
bevt_106_ta_ph = beva_node.bem_heldGet_0();
bevt_104_ta_ph = bevt_105_ta_ph.bemd_1(1007780901, bevt_106_ta_ph);
bevp_goingStr.bem_heldSet_1(bevt_104_ta_ph);
bevl_ia.bevi_int++;
} /* Line: 111*/
 else /* Line: 111*/ {
break;
} /* Line: 111*/
} /* Line: 111*/
if (bevl_xn == null) {
bevt_107_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_107_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_107_ta_ph.bevi_bool)/* Line: 114*/ {
bevt_110_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_109_ta_ph = bevl_fsc.bem_modulus_1(bevt_110_ta_ph);
bevt_111_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_109_ta_ph.bevi_int == bevt_111_ta_ph.bevi_int) {
bevt_108_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_108_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_108_ta_ph.bevi_bool)/* Line: 114*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 114*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 114*/
 else /* Line: 114*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_13_ta_anchor.bevi_bool)/* Line: 114*/ {
bevt_113_ta_ph = bevl_xn.bem_typenameGet_0();
if (bevt_113_ta_ph.bevi_int == bevp_quoteType.bevi_int) {
bevt_112_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_112_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_112_ta_ph.bevi_bool)/* Line: 114*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 114*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 114*/
 else /* Line: 114*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_12_ta_anchor.bevi_bool)/* Line: 114*/ {
bevl_xn.bem_delayDelete_0();
bevt_115_ta_ph = bevp_goingStr.bem_heldGet_0();
bevt_116_ta_ph = bevl_xn.bem_heldGet_0();
bevt_114_ta_ph = bevt_115_ta_ph.bemd_1(1007780901, bevt_116_ta_ph);
bevp_goingStr.bem_heldSet_1(bevt_114_ta_ph);
bevl_xn = bevl_xn.bem_nextDescendGet_0();
} /* Line: 117*/
return bevl_xn;
} /* Line: 119*/
 else /* Line: 102*/ {
if (bevl_typename.bevi_int == bevp_quoteType.bevi_int) {
bevt_117_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_117_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_117_ta_ph.bevi_bool)/* Line: 120*/ {
beva_node.bem_delayDelete_0();
bevl_xn = beva_node.bem_nextPeerGet_0();
bevl_csc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 124*/ {
if (bevl_xn == null) {
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 124*/ {
bevt_120_ta_ph = bevl_xn.bem_typenameGet_0();
if (bevt_120_ta_ph.bevi_int == bevp_quoteType.bevi_int) {
bevt_119_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_119_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_119_ta_ph.bevi_bool)/* Line: 124*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 124*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 124*/
 else /* Line: 124*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_14_ta_anchor.bevi_bool)/* Line: 124*/ {
bevl_csc.bevi_int++;
bevl_xn.bem_delayDelete_0();
bevl_xn = bevl_xn.bem_nextPeerGet_0();
} /* Line: 127*/
 else /* Line: 124*/ {
break;
} /* Line: 124*/
} /* Line: 124*/
if (bevl_csc.bevi_int == bevp_strqCnt.bevi_int) {
bevt_121_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_121_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_121_ta_ph.bevi_bool)/* Line: 129*/ {
bevp_goingStr.bem_typeDetailSet_1(bevp_strqCnt);
bevp_strqCnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_goingStr = null;
bevp_inStr = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 133*/
 else /* Line: 134*/ {
bevl_ia = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 135*/ {
if (bevl_ia.bevi_int < bevl_csc.bevi_int) {
bevt_122_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_122_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_122_ta_ph.bevi_bool)/* Line: 135*/ {
bevt_124_ta_ph = bevp_goingStr.bem_heldGet_0();
bevt_125_ta_ph = beva_node.bem_heldGet_0();
bevt_123_ta_ph = bevt_124_ta_ph.bemd_1(1007780901, bevt_125_ta_ph);
bevp_goingStr.bem_heldSet_1(bevt_123_ta_ph);
bevl_ia.bevi_int++;
} /* Line: 135*/
 else /* Line: 135*/ {
break;
} /* Line: 135*/
} /* Line: 135*/
} /* Line: 135*/
return bevl_xn;
} /* Line: 139*/
 else /* Line: 140*/ {
bevt_127_ta_ph = bevp_goingStr.bem_heldGet_0();
bevt_128_ta_ph = beva_node.bem_heldGet_0();
bevt_126_ta_ph = bevt_127_ta_ph.bemd_1(1007780901, bevt_128_ta_ph);
bevp_goingStr.bem_heldSet_1(bevt_126_ta_ph);
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 144*/
} /* Line: 102*/
} /* Line: 102*/
bevt_130_ta_ph = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_typename.bevi_int == bevt_130_ta_ph.bevi_int) {
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 147*/ {
if (bevl_nextPeer == null) {
bevt_131_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_131_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_131_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 147*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 147*/
 else /* Line: 147*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 147*/ {
bevt_133_ta_ph = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_133_ta_ph.bevi_int) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 147*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 147*/
 else /* Line: 147*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_16_ta_anchor.bevi_bool)/* Line: 147*/ {
if (bevp_inStr.bevi_bool) {
bevt_134_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_134_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_134_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 147*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 147*/
 else /* Line: 147*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_15_ta_anchor.bevi_bool)/* Line: 147*/ {
bevt_135_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_135_ta_ph.bem_nextDescendGet_0();
bevp_inLc = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_136_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_136_ta_ph.bem_delayDelete_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 152*/
if (bevp_inLc.bevi_bool)/* Line: 154*/ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
bevt_138_ta_ph = bevl_toRet.bem_typenameGet_0();
bevt_139_ta_ph = bevp_ntypes.bem_NEWLINEGet_0();
if (bevt_138_ta_ph.bevi_int == bevt_139_ta_ph.bevi_int) {
bevt_137_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_137_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_137_ta_ph.bevi_bool)/* Line: 157*/ {
bevp_inLc = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_toRet.bem_delayDelete_0();
bevl_toRet = bevl_toRet.bem_nextDescendGet_0();
} /* Line: 160*/
return bevl_toRet;
} /* Line: 162*/
bevt_141_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
if (bevl_typename.bevi_int == bevt_141_ta_ph.bevi_int) {
bevt_140_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_140_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_140_ta_ph.bevi_bool)/* Line: 164*/ {
if (bevl_nextPeer == null) {
bevt_142_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_142_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_142_ta_ph.bevi_bool)/* Line: 164*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 164*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 164*/
 else /* Line: 164*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_19_ta_anchor.bevi_bool)/* Line: 164*/ {
bevt_144_ta_ph = bevp_ntypes.bem_INTLGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_144_ta_ph.bevi_int) {
bevt_143_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_143_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_143_ta_ph.bevi_bool)/* Line: 164*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 164*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 164*/
 else /* Line: 164*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 164*/ {
bevt_146_ta_ph = beva_node.bem_priorPeerGet_0();
if (bevt_146_ta_ph == null) {
bevt_145_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_145_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_145_ta_ph.bevi_bool)/* Line: 165*/ {
bevl_vback = beva_node.bem_priorPeerGet_0();
while (true)
/* Line: 167*/ {
if (bevl_vback == null) {
bevt_147_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_147_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_147_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_149_ta_ph = bevl_vback.bem_typenameGet_0();
bevt_150_ta_ph = bevp_ntypes.bem_SPACEGet_0();
if (bevt_149_ta_ph.bevi_int == bevt_150_ta_ph.bevi_int) {
bevt_148_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_148_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_20_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 167*/ {
bevt_20_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 167*/
 else /* Line: 167*/ {
bevt_20_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_20_ta_anchor.bevi_bool)/* Line: 167*/ {
bevl_vback = bevl_vback.bem_priorPeerGet_0();
} /* Line: 168*/
 else /* Line: 167*/ {
break;
} /* Line: 167*/
} /* Line: 167*/
bevl_pre = bevl_vback;
} /* Line: 170*/
if (bevl_pre == null) {
bevt_151_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_151_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_151_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_23_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 173*/ {
bevt_153_ta_ph = bevl_pre.bem_typenameGet_0();
bevt_154_ta_ph = bevp_ntypes.bem_COMMAGet_0();
if (bevt_153_ta_ph.bevi_int == bevt_154_ta_ph.bevi_int) {
bevt_152_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_152_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_152_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_23_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 173*/ {
bevt_23_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 173*/
if (bevt_23_ta_anchor.bevi_bool)/* Line: 173*/ {
bevt_22_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 173*/ {
bevt_156_ta_ph = bevl_pre.bem_typenameGet_0();
bevt_157_ta_ph = bevp_ntypes.bem_PARENSGet_0();
if (bevt_156_ta_ph.bevi_int == bevt_157_ta_ph.bevi_int) {
bevt_155_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_155_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_155_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_22_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 173*/ {
bevt_22_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 173*/
if (bevt_22_ta_anchor.bevi_bool)/* Line: 173*/ {
bevt_21_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 173*/ {
bevt_159_ta_ph = bevp_const.bem_operGet_0();
bevt_160_ta_ph = bevl_pre.bem_typenameGet_0();
bevt_158_ta_ph = bevt_159_ta_ph.bem_has_1(bevt_160_ta_ph);
if (bevt_158_ta_ph.bevi_bool)/* Line: 173*/ {
bevt_21_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 173*/ {
bevt_21_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 173*/
if (bevt_21_ta_anchor.bevi_bool)/* Line: 173*/ {
bevt_161_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_163_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass3_bels_0));
bevt_165_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_164_ta_ph = bevt_165_ta_ph.bem_heldGet_0();
bevt_162_ta_ph = bevt_163_ta_ph.bem_add_1(bevt_164_ta_ph);
bevt_161_ta_ph.bem_heldSet_1(bevt_162_ta_ph);
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 179*/
} /* Line: 173*/
bevt_167_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_typename.bevi_int == bevt_167_ta_ph.bevi_int) {
bevt_166_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_166_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_166_ta_ph.bevi_bool)/* Line: 182*/ {
if (bevl_nextPeer == null) {
bevt_168_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_168_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_168_ta_ph.bevi_bool)/* Line: 182*/ {
bevt_25_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 182*/ {
bevt_25_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 182*/
 else /* Line: 182*/ {
bevt_25_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_25_ta_anchor.bevi_bool)/* Line: 182*/ {
bevt_170_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_170_ta_ph.bevi_int) {
bevt_169_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_169_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_169_ta_ph.bevi_bool)/* Line: 182*/ {
bevt_24_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 182*/ {
bevt_24_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 182*/
 else /* Line: 182*/ {
bevt_24_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_24_ta_anchor.bevi_bool)/* Line: 182*/ {
bevt_171_ta_ph = bevp_ntypes.bem_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_171_ta_ph);
bevt_173_ta_ph = beva_node.bem_heldGet_0();
bevt_175_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_174_ta_ph = bevt_175_ta_ph.bem_heldGet_0();
bevt_172_ta_ph = bevt_173_ta_ph.bemd_1(1007780901, bevt_174_ta_ph);
beva_node.bem_heldSet_1(bevt_172_ta_ph);
bevt_176_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_176_ta_ph.bem_nextDescendGet_0();
bevt_177_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_177_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 187*/
bevt_179_ta_ph = bevp_ntypes.bem_NOTGet_0();
if (bevl_typename.bevi_int == bevt_179_ta_ph.bevi_int) {
bevt_178_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_178_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_178_ta_ph.bevi_bool)/* Line: 189*/ {
if (bevl_nextPeer == null) {
bevt_180_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_180_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_180_ta_ph.bevi_bool)/* Line: 189*/ {
bevt_27_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 189*/ {
bevt_27_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 189*/
 else /* Line: 189*/ {
bevt_27_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_27_ta_anchor.bevi_bool)/* Line: 189*/ {
bevt_182_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_182_ta_ph.bevi_int) {
bevt_181_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_181_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_181_ta_ph.bevi_bool)/* Line: 189*/ {
bevt_26_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 189*/ {
bevt_26_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 189*/
 else /* Line: 189*/ {
bevt_26_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_26_ta_anchor.bevi_bool)/* Line: 189*/ {
bevt_183_ta_ph = bevp_ntypes.bem_NOT_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_183_ta_ph);
bevt_185_ta_ph = beva_node.bem_heldGet_0();
bevt_187_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_186_ta_ph = bevt_187_ta_ph.bem_heldGet_0();
bevt_184_ta_ph = bevt_185_ta_ph.bemd_1(1007780901, bevt_186_ta_ph);
beva_node.bem_heldSet_1(bevt_184_ta_ph);
bevt_188_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_188_ta_ph.bem_nextDescendGet_0();
bevt_189_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_189_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 194*/
bevt_191_ta_ph = bevp_ntypes.bem_ORGet_0();
if (bevl_typename.bevi_int == bevt_191_ta_ph.bevi_int) {
bevt_190_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_190_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_190_ta_ph.bevi_bool)/* Line: 196*/ {
bevt_193_ta_ph = beva_node.bem_nextPeerGet_0();
if (bevt_193_ta_ph == null) {
bevt_192_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_192_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_192_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_196_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_195_ta_ph = bevt_196_ta_ph.bem_typenameGet_0();
bevt_197_ta_ph = bevp_ntypes.bem_ORGet_0();
if (bevt_195_ta_ph.bevi_int == bevt_197_ta_ph.bevi_int) {
bevt_194_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_194_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_194_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_28_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 197*/ {
bevt_28_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 197*/
 else /* Line: 197*/ {
bevt_28_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_28_ta_anchor.bevi_bool)/* Line: 197*/ {
bevt_199_ta_ph = beva_node.bem_heldGet_0();
bevt_201_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_200_ta_ph = bevt_201_ta_ph.bem_heldGet_0();
bevt_198_ta_ph = bevt_199_ta_ph.bemd_1(1007780901, bevt_200_ta_ph);
beva_node.bem_heldSet_1(bevt_198_ta_ph);
bevt_202_ta_ph = bevp_ntypes.bem_LOGICAL_ORGet_0();
beva_node.bem_typenameSet_1(bevt_202_ta_ph);
bevt_203_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_203_ta_ph.bem_nextDescendGet_0();
bevt_204_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_204_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 202*/
} /* Line: 197*/
bevt_206_ta_ph = bevp_ntypes.bem_ANDGet_0();
if (bevl_typename.bevi_int == bevt_206_ta_ph.bevi_int) {
bevt_205_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_205_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_205_ta_ph.bevi_bool)/* Line: 205*/ {
bevt_208_ta_ph = beva_node.bem_nextPeerGet_0();
if (bevt_208_ta_ph == null) {
bevt_207_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_207_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_207_ta_ph.bevi_bool)/* Line: 206*/ {
bevt_211_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_210_ta_ph = bevt_211_ta_ph.bem_typenameGet_0();
bevt_212_ta_ph = bevp_ntypes.bem_ANDGet_0();
if (bevt_210_ta_ph.bevi_int == bevt_212_ta_ph.bevi_int) {
bevt_209_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_209_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_209_ta_ph.bevi_bool)/* Line: 206*/ {
bevt_29_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 206*/ {
bevt_29_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 206*/
 else /* Line: 206*/ {
bevt_29_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_29_ta_anchor.bevi_bool)/* Line: 206*/ {
bevt_214_ta_ph = beva_node.bem_heldGet_0();
bevt_216_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_215_ta_ph = bevt_216_ta_ph.bem_heldGet_0();
bevt_213_ta_ph = bevt_214_ta_ph.bemd_1(1007780901, bevt_215_ta_ph);
beva_node.bem_heldSet_1(bevt_213_ta_ph);
bevt_217_ta_ph = bevp_ntypes.bem_LOGICAL_ANDGet_0();
beva_node.bem_typenameSet_1(bevt_217_ta_ph);
bevt_218_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_218_ta_ph.bem_nextDescendGet_0();
bevt_219_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_219_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 211*/
} /* Line: 206*/
bevt_221_ta_ph = bevp_ntypes.bem_GREATERGet_0();
if (bevl_typename.bevi_int == bevt_221_ta_ph.bevi_int) {
bevt_220_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_220_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_220_ta_ph.bevi_bool)/* Line: 214*/ {
if (bevl_nextPeer == null) {
bevt_222_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_222_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_222_ta_ph.bevi_bool)/* Line: 214*/ {
bevt_31_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 214*/ {
bevt_31_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 214*/
 else /* Line: 214*/ {
bevt_31_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_31_ta_anchor.bevi_bool)/* Line: 214*/ {
bevt_224_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_224_ta_ph.bevi_int) {
bevt_223_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_223_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_223_ta_ph.bevi_bool)/* Line: 214*/ {
bevt_30_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 214*/ {
bevt_30_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 214*/
 else /* Line: 214*/ {
bevt_30_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_30_ta_anchor.bevi_bool)/* Line: 214*/ {
bevt_225_ta_ph = bevp_ntypes.bem_GREATER_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_225_ta_ph);
bevt_227_ta_ph = beva_node.bem_heldGet_0();
bevt_229_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_228_ta_ph = bevt_229_ta_ph.bem_heldGet_0();
bevt_226_ta_ph = bevt_227_ta_ph.bemd_1(1007780901, bevt_228_ta_ph);
beva_node.bem_heldSet_1(bevt_226_ta_ph);
bevt_230_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_230_ta_ph.bem_nextDescendGet_0();
bevt_231_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_231_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 219*/
bevt_233_ta_ph = bevp_ntypes.bem_LESSERGet_0();
if (bevl_typename.bevi_int == bevt_233_ta_ph.bevi_int) {
bevt_232_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_232_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_232_ta_ph.bevi_bool)/* Line: 221*/ {
if (bevl_nextPeer == null) {
bevt_234_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_234_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_234_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_33_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_33_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 221*/
 else /* Line: 221*/ {
bevt_33_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_33_ta_anchor.bevi_bool)/* Line: 221*/ {
bevt_236_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_236_ta_ph.bevi_int) {
bevt_235_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_235_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_235_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_32_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 221*/ {
bevt_32_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 221*/
 else /* Line: 221*/ {
bevt_32_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_32_ta_anchor.bevi_bool)/* Line: 221*/ {
bevt_237_ta_ph = bevp_ntypes.bem_LESSER_EQUALSGet_0();
beva_node.bem_typenameSet_1(bevt_237_ta_ph);
bevt_239_ta_ph = beva_node.bem_heldGet_0();
bevt_241_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_240_ta_ph = bevt_241_ta_ph.bem_heldGet_0();
bevt_238_ta_ph = bevt_239_ta_ph.bemd_1(1007780901, bevt_240_ta_ph);
beva_node.bem_heldSet_1(bevt_238_ta_ph);
bevt_242_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_242_ta_ph.bem_nextDescendGet_0();
bevt_243_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_243_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 226*/
bevt_245_ta_ph = bevp_ntypes.bem_ADDGet_0();
if (bevl_typename.bevi_int == bevt_245_ta_ph.bevi_int) {
bevt_244_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_244_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_244_ta_ph.bevi_bool)/* Line: 228*/ {
if (bevl_nextPeer == null) {
bevt_246_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_246_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_246_ta_ph.bevi_bool)/* Line: 228*/ {
bevt_35_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 228*/ {
bevt_35_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 228*/
 else /* Line: 228*/ {
bevt_35_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_35_ta_anchor.bevi_bool)/* Line: 228*/ {
bevt_248_ta_ph = bevp_ntypes.bem_ADDGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_248_ta_ph.bevi_int) {
bevt_247_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_247_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_247_ta_ph.bevi_bool)/* Line: 228*/ {
bevt_34_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 228*/ {
bevt_34_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 228*/
 else /* Line: 228*/ {
bevt_34_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_34_ta_anchor.bevi_bool)/* Line: 228*/ {
bevt_251_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_250_ta_ph = bevt_251_ta_ph.bem_nextPeerGet_0();
if (bevt_250_ta_ph == null) {
bevt_249_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_249_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_249_ta_ph.bevi_bool)/* Line: 229*/ {
bevt_255_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_254_ta_ph = bevt_255_ta_ph.bem_nextPeerGet_0();
bevt_253_ta_ph = bevt_254_ta_ph.bem_typenameGet_0();
bevt_256_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevt_253_ta_ph.bevi_int == bevt_256_ta_ph.bevi_int) {
bevt_252_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_252_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_252_ta_ph.bevi_bool)/* Line: 229*/ {
bevt_36_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 229*/ {
bevt_36_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 229*/
 else /* Line: 229*/ {
bevt_36_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_36_ta_anchor.bevi_bool)/* Line: 229*/ {
bevt_257_ta_ph = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_257_ta_ph);
bevt_260_ta_ph = beva_node.bem_heldGet_0();
bevt_262_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_261_ta_ph = bevt_262_ta_ph.bem_heldGet_0();
bevt_259_ta_ph = bevt_260_ta_ph.bemd_1(1007780901, bevt_261_ta_ph);
bevt_265_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_264_ta_ph = bevt_265_ta_ph.bem_nextPeerGet_0();
bevt_263_ta_ph = bevt_264_ta_ph.bem_heldGet_0();
bevt_258_ta_ph = bevt_259_ta_ph.bemd_1(1007780901, bevt_263_ta_ph);
beva_node.bem_heldSet_1(bevt_258_ta_ph);
bevt_267_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_266_ta_ph = bevt_267_ta_ph.bem_nextPeerGet_0();
bevl_toRet = bevt_266_ta_ph.bem_nextDescendGet_0();
bevt_268_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_268_ta_ph.bem_delayDelete_0();
bevt_270_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_269_ta_ph = bevt_270_ta_ph.bem_nextPeerGet_0();
bevt_269_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 235*/
bevt_271_ta_ph = bevp_ntypes.bem_INCREMENTGet_0();
beva_node.bem_typenameSet_1(bevt_271_ta_ph);
bevt_273_ta_ph = beva_node.bem_heldGet_0();
bevt_275_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_274_ta_ph = bevt_275_ta_ph.bem_heldGet_0();
bevt_272_ta_ph = bevt_273_ta_ph.bemd_1(1007780901, bevt_274_ta_ph);
beva_node.bem_heldSet_1(bevt_272_ta_ph);
bevt_276_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_276_ta_ph.bem_nextDescendGet_0();
bevt_277_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_277_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 241*/
bevt_279_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
if (bevl_typename.bevi_int == bevt_279_ta_ph.bevi_int) {
bevt_278_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_278_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_278_ta_ph.bevi_bool)/* Line: 243*/ {
if (bevl_nextPeer == null) {
bevt_280_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_280_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_280_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_38_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_38_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 243*/
 else /* Line: 243*/ {
bevt_38_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_38_ta_anchor.bevi_bool)/* Line: 243*/ {
bevt_282_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_282_ta_ph.bevi_int) {
bevt_281_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_281_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_281_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_37_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_37_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 243*/
 else /* Line: 243*/ {
bevt_37_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_37_ta_anchor.bevi_bool)/* Line: 243*/ {
bevt_285_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_284_ta_ph = bevt_285_ta_ph.bem_nextPeerGet_0();
if (bevt_284_ta_ph == null) {
bevt_283_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_283_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_283_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_289_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_288_ta_ph = bevt_289_ta_ph.bem_nextPeerGet_0();
bevt_287_ta_ph = bevt_288_ta_ph.bem_typenameGet_0();
bevt_290_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevt_287_ta_ph.bevi_int == bevt_290_ta_ph.bevi_int) {
bevt_286_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_286_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_286_ta_ph.bevi_bool)/* Line: 244*/ {
bevt_39_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 244*/ {
bevt_39_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 244*/
 else /* Line: 244*/ {
bevt_39_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_39_ta_anchor.bevi_bool)/* Line: 244*/ {
bevt_291_ta_ph = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_291_ta_ph);
bevt_294_ta_ph = beva_node.bem_heldGet_0();
bevt_296_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_295_ta_ph = bevt_296_ta_ph.bem_heldGet_0();
bevt_293_ta_ph = bevt_294_ta_ph.bemd_1(1007780901, bevt_295_ta_ph);
bevt_299_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_298_ta_ph = bevt_299_ta_ph.bem_nextPeerGet_0();
bevt_297_ta_ph = bevt_298_ta_ph.bem_heldGet_0();
bevt_292_ta_ph = bevt_293_ta_ph.bemd_1(1007780901, bevt_297_ta_ph);
beva_node.bem_heldSet_1(bevt_292_ta_ph);
bevt_301_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_300_ta_ph = bevt_301_ta_ph.bem_nextPeerGet_0();
bevl_toRet = bevt_300_ta_ph.bem_nextDescendGet_0();
bevt_302_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_302_ta_ph.bem_delayDelete_0();
bevt_304_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_303_ta_ph = bevt_304_ta_ph.bem_nextPeerGet_0();
bevt_303_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 250*/
bevt_305_ta_ph = bevp_ntypes.bem_DECREMENTGet_0();
beva_node.bem_typenameSet_1(bevt_305_ta_ph);
bevt_307_ta_ph = beva_node.bem_heldGet_0();
bevt_309_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_308_ta_ph = bevt_309_ta_ph.bem_heldGet_0();
bevt_306_ta_ph = bevt_307_ta_ph.bemd_1(1007780901, bevt_308_ta_ph);
beva_node.bem_heldSet_1(bevt_306_ta_ph);
bevt_310_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_310_ta_ph.bem_nextDescendGet_0();
bevt_311_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_311_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 256*/
bevt_313_ta_ph = bevp_ntypes.bem_ADDGet_0();
if (bevl_typename.bevi_int == bevt_313_ta_ph.bevi_int) {
bevt_312_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_312_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_312_ta_ph.bevi_bool)/* Line: 258*/ {
if (bevl_nextPeer == null) {
bevt_314_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_314_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_314_ta_ph.bevi_bool)/* Line: 258*/ {
bevt_41_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 258*/ {
bevt_41_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 258*/
 else /* Line: 258*/ {
bevt_41_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_41_ta_anchor.bevi_bool)/* Line: 258*/ {
bevt_316_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_316_ta_ph.bevi_int) {
bevt_315_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_315_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_315_ta_ph.bevi_bool)/* Line: 258*/ {
bevt_40_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 258*/ {
bevt_40_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 258*/
 else /* Line: 258*/ {
bevt_40_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_40_ta_anchor.bevi_bool)/* Line: 258*/ {
bevt_317_ta_ph = bevp_ntypes.bem_ADD_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_317_ta_ph);
bevt_319_ta_ph = beva_node.bem_heldGet_0();
bevt_321_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_320_ta_ph = bevt_321_ta_ph.bem_heldGet_0();
bevt_318_ta_ph = bevt_319_ta_ph.bemd_1(1007780901, bevt_320_ta_ph);
beva_node.bem_heldSet_1(bevt_318_ta_ph);
bevt_322_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_322_ta_ph.bem_nextDescendGet_0();
bevt_323_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_323_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 263*/
bevt_325_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
if (bevl_typename.bevi_int == bevt_325_ta_ph.bevi_int) {
bevt_324_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_324_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_324_ta_ph.bevi_bool)/* Line: 265*/ {
if (bevl_nextPeer == null) {
bevt_326_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_326_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_326_ta_ph.bevi_bool)/* Line: 265*/ {
bevt_43_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 265*/ {
bevt_43_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 265*/
 else /* Line: 265*/ {
bevt_43_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_43_ta_anchor.bevi_bool)/* Line: 265*/ {
bevt_328_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_328_ta_ph.bevi_int) {
bevt_327_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_327_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_327_ta_ph.bevi_bool)/* Line: 265*/ {
bevt_42_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 265*/ {
bevt_42_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 265*/
 else /* Line: 265*/ {
bevt_42_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_42_ta_anchor.bevi_bool)/* Line: 265*/ {
bevt_329_ta_ph = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_329_ta_ph);
bevt_331_ta_ph = beva_node.bem_heldGet_0();
bevt_333_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_332_ta_ph = bevt_333_ta_ph.bem_heldGet_0();
bevt_330_ta_ph = bevt_331_ta_ph.bemd_1(1007780901, bevt_332_ta_ph);
beva_node.bem_heldSet_1(bevt_330_ta_ph);
bevt_334_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_334_ta_ph.bem_nextDescendGet_0();
bevt_335_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_335_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 270*/
bevt_337_ta_ph = bevp_ntypes.bem_MULTIPLYGet_0();
if (bevl_typename.bevi_int == bevt_337_ta_ph.bevi_int) {
bevt_336_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_336_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_336_ta_ph.bevi_bool)/* Line: 272*/ {
if (bevl_nextPeer == null) {
bevt_338_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_338_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_338_ta_ph.bevi_bool)/* Line: 272*/ {
bevt_45_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 272*/ {
bevt_45_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 272*/
 else /* Line: 272*/ {
bevt_45_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_45_ta_anchor.bevi_bool)/* Line: 272*/ {
bevt_340_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_340_ta_ph.bevi_int) {
bevt_339_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_339_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_339_ta_ph.bevi_bool)/* Line: 272*/ {
bevt_44_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 272*/ {
bevt_44_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 272*/
 else /* Line: 272*/ {
bevt_44_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_44_ta_anchor.bevi_bool)/* Line: 272*/ {
bevt_341_ta_ph = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_341_ta_ph);
bevt_343_ta_ph = beva_node.bem_heldGet_0();
bevt_345_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_344_ta_ph = bevt_345_ta_ph.bem_heldGet_0();
bevt_342_ta_ph = bevt_343_ta_ph.bemd_1(1007780901, bevt_344_ta_ph);
beva_node.bem_heldSet_1(bevt_342_ta_ph);
bevt_346_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_346_ta_ph.bem_nextDescendGet_0();
bevt_347_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_347_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 277*/
bevt_349_ta_ph = bevp_ntypes.bem_DIVIDEGet_0();
if (bevl_typename.bevi_int == bevt_349_ta_ph.bevi_int) {
bevt_348_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_348_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_348_ta_ph.bevi_bool)/* Line: 279*/ {
if (bevl_nextPeer == null) {
bevt_350_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_350_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_350_ta_ph.bevi_bool)/* Line: 279*/ {
bevt_47_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 279*/ {
bevt_47_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 279*/
 else /* Line: 279*/ {
bevt_47_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_47_ta_anchor.bevi_bool)/* Line: 279*/ {
bevt_352_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_352_ta_ph.bevi_int) {
bevt_351_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_351_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_351_ta_ph.bevi_bool)/* Line: 279*/ {
bevt_46_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 279*/ {
bevt_46_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 279*/
 else /* Line: 279*/ {
bevt_46_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_46_ta_anchor.bevi_bool)/* Line: 279*/ {
bevt_353_ta_ph = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_353_ta_ph);
bevt_355_ta_ph = beva_node.bem_heldGet_0();
bevt_357_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_356_ta_ph = bevt_357_ta_ph.bem_heldGet_0();
bevt_354_ta_ph = bevt_355_ta_ph.bemd_1(1007780901, bevt_356_ta_ph);
beva_node.bem_heldSet_1(bevt_354_ta_ph);
bevt_358_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_358_ta_ph.bem_nextDescendGet_0();
bevt_359_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_359_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 284*/
bevt_361_ta_ph = bevp_ntypes.bem_MODULUSGet_0();
if (bevl_typename.bevi_int == bevt_361_ta_ph.bevi_int) {
bevt_360_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_360_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_360_ta_ph.bevi_bool)/* Line: 286*/ {
if (bevl_nextPeer == null) {
bevt_362_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_362_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_362_ta_ph.bevi_bool)/* Line: 286*/ {
bevt_49_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 286*/ {
bevt_49_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 286*/
 else /* Line: 286*/ {
bevt_49_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_49_ta_anchor.bevi_bool)/* Line: 286*/ {
bevt_364_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_364_ta_ph.bevi_int) {
bevt_363_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_363_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_363_ta_ph.bevi_bool)/* Line: 286*/ {
bevt_48_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 286*/ {
bevt_48_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 286*/
 else /* Line: 286*/ {
bevt_48_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_48_ta_anchor.bevi_bool)/* Line: 286*/ {
bevt_365_ta_ph = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_365_ta_ph);
bevt_367_ta_ph = beva_node.bem_heldGet_0();
bevt_369_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_368_ta_ph = bevt_369_ta_ph.bem_heldGet_0();
bevt_366_ta_ph = bevt_367_ta_ph.bemd_1(1007780901, bevt_368_ta_ph);
beva_node.bem_heldSet_1(bevt_366_ta_ph);
bevt_370_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_370_ta_ph.bem_nextDescendGet_0();
bevt_371_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_371_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 291*/
bevt_373_ta_ph = bevp_ntypes.bem_ANDGet_0();
if (bevl_typename.bevi_int == bevt_373_ta_ph.bevi_int) {
bevt_372_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_372_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_372_ta_ph.bevi_bool)/* Line: 293*/ {
if (bevl_nextPeer == null) {
bevt_374_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_374_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_374_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_51_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 293*/ {
bevt_51_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 293*/
 else /* Line: 293*/ {
bevt_51_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_51_ta_anchor.bevi_bool)/* Line: 293*/ {
bevt_376_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_376_ta_ph.bevi_int) {
bevt_375_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_375_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_375_ta_ph.bevi_bool)/* Line: 293*/ {
bevt_50_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 293*/ {
bevt_50_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 293*/
 else /* Line: 293*/ {
bevt_50_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_50_ta_anchor.bevi_bool)/* Line: 293*/ {
bevt_377_ta_ph = bevp_ntypes.bem_AND_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_377_ta_ph);
bevt_379_ta_ph = beva_node.bem_heldGet_0();
bevt_381_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_380_ta_ph = bevt_381_ta_ph.bem_heldGet_0();
bevt_378_ta_ph = bevt_379_ta_ph.bemd_1(1007780901, bevt_380_ta_ph);
beva_node.bem_heldSet_1(bevt_378_ta_ph);
bevt_382_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_382_ta_ph.bem_nextDescendGet_0();
bevt_383_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_383_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 298*/
bevt_385_ta_ph = bevp_ntypes.bem_ORGet_0();
if (bevl_typename.bevi_int == bevt_385_ta_ph.bevi_int) {
bevt_384_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_384_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_384_ta_ph.bevi_bool)/* Line: 300*/ {
if (bevl_nextPeer == null) {
bevt_386_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_386_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_386_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_53_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_53_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_53_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_53_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_388_ta_ph = bevp_ntypes.bem_ASSIGNGet_0();
if (bevl_nextPeerTypename.bevi_int == bevt_388_ta_ph.bevi_int) {
bevt_387_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_387_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_387_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_52_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_52_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_52_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_52_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_389_ta_ph = bevp_ntypes.bem_OR_ASSIGNGet_0();
beva_node.bem_typenameSet_1(bevt_389_ta_ph);
bevt_391_ta_ph = beva_node.bem_heldGet_0();
bevt_393_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_392_ta_ph = bevt_393_ta_ph.bem_heldGet_0();
bevt_390_ta_ph = bevt_391_ta_ph.bemd_1(1007780901, bevt_392_ta_ph);
beva_node.bem_heldSet_1(bevt_390_ta_ph);
bevt_394_ta_ph = beva_node.bem_nextPeerGet_0();
bevl_toRet = bevt_394_ta_ph.bem_nextDescendGet_0();
bevt_395_ta_ph = beva_node.bem_nextPeerGet_0();
bevt_395_ta_ph.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 305*/
bevt_397_ta_ph = bevp_ntypes.bem_SPACEGet_0();
if (bevl_typename.bevi_int == bevt_397_ta_ph.bevi_int) {
bevt_396_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_396_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_396_ta_ph.bevi_bool)/* Line: 307*/ {
bevt_54_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 307*/ {
bevt_399_ta_ph = bevp_ntypes.bem_NEWLINEGet_0();
if (bevl_typename.bevi_int == bevt_399_ta_ph.bevi_int) {
bevt_398_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_398_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_398_ta_ph.bevi_bool)/* Line: 307*/ {
bevt_54_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 307*/ {
bevt_54_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 307*/
if (bevt_54_ta_anchor.bevi_bool)/* Line: 307*/ {
bevl_toRet = beva_node.bem_nextDescendGet_0();
beva_node.bem_delayDelete_0();
return bevl_toRet;
} /* Line: 310*/
bevt_400_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_400_ta_ph;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_5_4_BuildNode bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_container = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nestCommentGet_0() {
return bevp_nestComment;
} /*method end*/
public BEC_2_4_3_MathInt bem_nestCommentGetDirect_0() {
return bevp_nestComment;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_nestCommentSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nestComment = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_nestCommentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nestComment = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_strqCntGet_0() {
return bevp_strqCnt;
} /*method end*/
public BEC_2_4_3_MathInt bem_strqCntGetDirect_0() {
return bevp_strqCnt;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_strqCntSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_strqCnt = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_strqCntSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_strqCnt = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_goingStrGet_0() {
return bevp_goingStr;
} /*method end*/
public BEC_2_5_4_BuildNode bem_goingStrGetDirect_0() {
return bevp_goingStr;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_goingStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_goingStr = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_goingStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_goingStr = (BEC_2_5_4_BuildNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_quoteTypeGet_0() {
return bevp_quoteType;
} /*method end*/
public BEC_2_4_3_MathInt bem_quoteTypeGetDirect_0() {
return bevp_quoteType;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_quoteTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quoteType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_quoteTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quoteType = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inLcGet_0() {
return bevp_inLc;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inLcGetDirect_0() {
return bevp_inLc;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_inLcSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inLc = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_inLcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inLc = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inSpaceGet_0() {
return bevp_inSpace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inSpaceGetDirect_0() {
return bevp_inSpace;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_inSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inSpace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_inSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inSpace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inNlGet_0() {
return bevp_inNl;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inNlGetDirect_0() {
return bevp_inNl;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_inNlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inNl = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_inNlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inNl = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inStrGet_0() {
return bevp_inStr;
} /*method end*/
public BEC_2_5_4_LogicBool bem_inStrGetDirect_0() {
return bevp_inStr;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_inStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inStr = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass3 bem_inStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_inStr = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 23, 25, 34, 35, 36, 37, 46, 47, 48, 48, 49, 53, 53, 53, 53, 53, 0, 0, 0, 53, 53, 53, 0, 0, 0, 53, 53, 0, 0, 0, 55, 56, 56, 57, 57, 58, 59, 61, 61, 61, 61, 61, 0, 0, 0, 61, 61, 61, 0, 0, 0, 61, 61, 0, 0, 0, 63, 64, 64, 65, 65, 66, 67, 69, 69, 69, 70, 71, 72, 74, 74, 74, 74, 0, 0, 0, 74, 74, 74, 0, 74, 74, 74, 0, 0, 0, 0, 0, 75, 76, 77, 78, 78, 78, 78, 78, 0, 0, 0, 79, 80, 81, 83, 83, 83, 84, 85, 85, 86, 86, 87, 87, 89, 90, 91, 91, 92, 92, 92, 94, 94, 96, 96, 99, 101, 101, 0, 0, 0, 102, 102, 102, 102, 102, 102, 102, 0, 0, 0, 103, 104, 105, 106, 106, 106, 106, 106, 106, 0, 0, 0, 107, 108, 109, 111, 111, 111, 112, 112, 112, 112, 111, 114, 114, 114, 114, 114, 114, 114, 0, 0, 0, 114, 114, 114, 0, 0, 0, 115, 116, 116, 116, 116, 117, 119, 120, 120, 121, 122, 123, 124, 124, 124, 124, 124, 0, 0, 0, 125, 126, 127, 129, 129, 130, 131, 132, 133, 135, 135, 135, 136, 136, 136, 136, 135, 139, 141, 141, 141, 141, 142, 143, 144, 147, 147, 147, 147, 147, 0, 0, 0, 147, 147, 147, 0, 0, 0, 147, 147, 0, 0, 0, 148, 148, 149, 150, 150, 151, 152, 155, 156, 157, 157, 157, 157, 158, 159, 160, 162, 164, 164, 164, 164, 164, 0, 0, 0, 164, 164, 164, 0, 0, 0, 165, 165, 165, 166, 167, 167, 167, 167, 167, 167, 0, 0, 0, 168, 170, 173, 173, 0, 173, 173, 173, 173, 0, 0, 0, 173, 173, 173, 173, 0, 0, 0, 173, 173, 173, 0, 0, 176, 176, 176, 176, 176, 176, 177, 178, 179, 182, 182, 182, 182, 182, 0, 0, 0, 182, 182, 182, 0, 0, 0, 183, 183, 184, 184, 184, 184, 184, 185, 185, 186, 186, 187, 189, 189, 189, 189, 189, 0, 0, 0, 189, 189, 189, 0, 0, 0, 190, 190, 191, 191, 191, 191, 191, 192, 192, 193, 193, 194, 196, 196, 196, 197, 197, 197, 197, 197, 197, 197, 197, 0, 0, 0, 198, 198, 198, 198, 198, 199, 199, 200, 200, 201, 201, 202, 205, 205, 205, 206, 206, 206, 206, 206, 206, 206, 206, 0, 0, 0, 207, 207, 207, 207, 207, 208, 208, 209, 209, 210, 210, 211, 214, 214, 214, 214, 214, 0, 0, 0, 214, 214, 214, 0, 0, 0, 215, 215, 216, 216, 216, 216, 216, 217, 217, 218, 218, 219, 221, 221, 221, 221, 221, 0, 0, 0, 221, 221, 221, 0, 0, 0, 222, 222, 223, 223, 223, 223, 223, 224, 224, 225, 225, 226, 228, 228, 228, 228, 228, 0, 0, 0, 228, 228, 228, 0, 0, 0, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 0, 0, 0, 230, 230, 231, 231, 231, 231, 231, 231, 231, 231, 231, 232, 232, 232, 233, 233, 234, 234, 234, 235, 237, 237, 238, 238, 238, 238, 238, 239, 239, 240, 240, 241, 243, 243, 243, 243, 243, 0, 0, 0, 243, 243, 243, 0, 0, 0, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 0, 0, 0, 245, 245, 246, 246, 246, 246, 246, 246, 246, 246, 246, 247, 247, 247, 248, 248, 249, 249, 249, 250, 252, 252, 253, 253, 253, 253, 253, 254, 254, 255, 255, 256, 258, 258, 258, 258, 258, 0, 0, 0, 258, 258, 258, 0, 0, 0, 259, 259, 260, 260, 260, 260, 260, 261, 261, 262, 262, 263, 265, 265, 265, 265, 265, 0, 0, 0, 265, 265, 265, 0, 0, 0, 266, 266, 267, 267, 267, 267, 267, 268, 268, 269, 269, 270, 272, 272, 272, 272, 272, 0, 0, 0, 272, 272, 272, 0, 0, 0, 273, 273, 274, 274, 274, 274, 274, 275, 275, 276, 276, 277, 279, 279, 279, 279, 279, 0, 0, 0, 279, 279, 279, 0, 0, 0, 280, 280, 281, 281, 281, 281, 281, 282, 282, 283, 283, 284, 286, 286, 286, 286, 286, 0, 0, 0, 286, 286, 286, 0, 0, 0, 287, 287, 288, 288, 288, 288, 288, 289, 289, 290, 290, 291, 293, 293, 293, 293, 293, 0, 0, 0, 293, 293, 293, 0, 0, 0, 294, 294, 295, 295, 295, 295, 295, 296, 296, 297, 297, 298, 300, 300, 300, 300, 300, 0, 0, 0, 300, 300, 300, 0, 0, 0, 301, 301, 302, 302, 302, 302, 302, 303, 303, 304, 304, 305, 307, 307, 307, 0, 307, 307, 307, 0, 0, 308, 309, 310, 312, 312, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 25, 26, 27, 28, 29, 444, 445, 446, 451, 452, 454, 455, 460, 461, 466, 467, 470, 474, 477, 478, 483, 484, 487, 491, 494, 499, 500, 503, 507, 510, 511, 512, 513, 514, 515, 516, 518, 519, 524, 525, 530, 531, 534, 538, 541, 542, 547, 548, 551, 555, 558, 563, 564, 567, 571, 574, 575, 576, 577, 578, 579, 580, 582, 583, 588, 589, 590, 591, 593, 598, 599, 604, 605, 608, 612, 615, 616, 621, 622, 625, 626, 631, 632, 635, 639, 642, 646, 649, 650, 651, 654, 659, 660, 661, 666, 667, 670, 674, 677, 678, 679, 685, 686, 691, 692, 693, 694, 695, 696, 697, 698, 701, 702, 703, 704, 705, 706, 711, 712, 713, 716, 717, 720, 723, 728, 729, 732, 736, 739, 740, 741, 746, 747, 748, 753, 754, 757, 761, 764, 765, 766, 769, 774, 775, 776, 777, 782, 783, 786, 790, 793, 794, 795, 801, 804, 809, 810, 811, 812, 813, 814, 820, 825, 826, 827, 828, 829, 834, 835, 838, 842, 845, 846, 851, 852, 855, 859, 862, 863, 864, 865, 866, 867, 869, 872, 877, 878, 879, 880, 883, 888, 889, 890, 895, 896, 899, 903, 906, 907, 908, 914, 919, 920, 921, 922, 923, 926, 929, 934, 935, 936, 937, 938, 939, 946, 949, 950, 951, 952, 953, 954, 955, 959, 960, 965, 966, 971, 972, 975, 979, 982, 983, 988, 989, 992, 996, 999, 1004, 1005, 1008, 1012, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1024, 1025, 1026, 1027, 1028, 1033, 1034, 1035, 1036, 1038, 1040, 1041, 1046, 1047, 1052, 1053, 1056, 1060, 1063, 1064, 1069, 1070, 1073, 1077, 1080, 1081, 1086, 1087, 1090, 1095, 1096, 1097, 1098, 1103, 1104, 1107, 1111, 1114, 1120, 1122, 1127, 1128, 1131, 1132, 1133, 1138, 1139, 1142, 1146, 1149, 1150, 1151, 1156, 1157, 1160, 1164, 1167, 1168, 1169, 1171, 1174, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1189, 1190, 1195, 1196, 1201, 1202, 1205, 1209, 1212, 1213, 1218, 1219, 1222, 1226, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1242, 1243, 1248, 1249, 1254, 1255, 1258, 1262, 1265, 1266, 1271, 1272, 1275, 1279, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293, 1295, 1296, 1301, 1302, 1303, 1308, 1309, 1310, 1311, 1312, 1317, 1318, 1321, 1325, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1336, 1337, 1338, 1339, 1342, 1343, 1348, 1349, 1350, 1355, 1356, 1357, 1358, 1359, 1364, 1365, 1368, 1372, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1389, 1390, 1395, 1396, 1401, 1402, 1405, 1409, 1412, 1413, 1418, 1419, 1422, 1426, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1442, 1443, 1448, 1449, 1454, 1455, 1458, 1462, 1465, 1466, 1471, 1472, 1475, 1479, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1495, 1496, 1501, 1502, 1507, 1508, 1511, 1515, 1518, 1519, 1524, 1525, 1528, 1532, 1535, 1536, 1537, 1542, 1543, 1544, 1545, 1546, 1547, 1552, 1553, 1556, 1560, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1597, 1598, 1603, 1604, 1609, 1610, 1613, 1617, 1620, 1621, 1626, 1627, 1630, 1634, 1637, 1638, 1639, 1644, 1645, 1646, 1647, 1648, 1649, 1654, 1655, 1658, 1662, 1665, 1666, 1667, 1668, 1669, 1670, 1671, 1672, 1673, 1674, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1684, 1686, 1687, 1688, 1689, 1690, 1691, 1692, 1693, 1694, 1695, 1696, 1697, 1699, 1700, 1705, 1706, 1711, 1712, 1715, 1719, 1722, 1723, 1728, 1729, 1732, 1736, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1752, 1753, 1758, 1759, 1764, 1765, 1768, 1772, 1775, 1776, 1781, 1782, 1785, 1789, 1792, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1800, 1801, 1802, 1803, 1805, 1806, 1811, 1812, 1817, 1818, 1821, 1825, 1828, 1829, 1834, 1835, 1838, 1842, 1845, 1846, 1847, 1848, 1849, 1850, 1851, 1852, 1853, 1854, 1855, 1856, 1858, 1859, 1864, 1865, 1870, 1871, 1874, 1878, 1881, 1882, 1887, 1888, 1891, 1895, 1898, 1899, 1900, 1901, 1902, 1903, 1904, 1905, 1906, 1907, 1908, 1909, 1911, 1912, 1917, 1918, 1923, 1924, 1927, 1931, 1934, 1935, 1940, 1941, 1944, 1948, 1951, 1952, 1953, 1954, 1955, 1956, 1957, 1958, 1959, 1960, 1961, 1962, 1964, 1965, 1970, 1971, 1976, 1977, 1980, 1984, 1987, 1988, 1993, 1994, 1997, 2001, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2017, 2018, 2023, 2024, 2029, 2030, 2033, 2037, 2040, 2041, 2046, 2047, 2050, 2054, 2057, 2058, 2059, 2060, 2061, 2062, 2063, 2064, 2065, 2066, 2067, 2068, 2070, 2071, 2076, 2077, 2080, 2081, 2086, 2087, 2090, 2094, 2095, 2096, 2098, 2099, 2102, 2105, 2108, 2112, 2116, 2119, 2122, 2126, 2130, 2133, 2136, 2140, 2144, 2147, 2150, 2154, 2158, 2161, 2164, 2168, 2172, 2175, 2178, 2182, 2186, 2189, 2192, 2196, 2200, 2203, 2206, 2210, 2214, 2217, 2220, 2224};
/* BEGIN LINEINFO 
begin 1 17 23
assign 1 23 24
new 0 23 24
assign 1 25 25
new 0 25 25
assign 1 34 26
new 0 34 26
assign 1 35 27
new 0 35 27
assign 1 36 28
new 0 36 28
assign 1 37 29
new 0 37 29
assign 1 46 444
typenameGet 0 46 444
assign 1 47 445
nextPeerGet 0 47 445
assign 1 48 446
def 1 48 451
assign 1 49 452
typenameGet 0 49 452
assign 1 53 454
DIVIDEGet 0 53 454
assign 1 53 455
equals 1 53 460
assign 1 53 461
def 1 53 466
assign 1 0 467
assign 1 0 470
assign 1 0 474
assign 1 53 477
MULTIPLYGet 0 53 477
assign 1 53 478
equals 1 53 483
assign 1 0 484
assign 1 0 487
assign 1 0 491
assign 1 53 494
not 0 53 499
assign 1 0 500
assign 1 0 503
assign 1 0 507
incrementValue 0 55 510
assign 1 56 511
nextPeerGet 0 56 511
assign 1 56 512
nextDescendGet 0 56 512
assign 1 57 513
nextPeerGet 0 57 513
delayDelete 0 57 514
delayDelete 0 58 515
return 1 59 516
assign 1 61 518
MULTIPLYGet 0 61 518
assign 1 61 519
equals 1 61 524
assign 1 61 525
def 1 61 530
assign 1 0 531
assign 1 0 534
assign 1 0 538
assign 1 61 541
DIVIDEGet 0 61 541
assign 1 61 542
equals 1 61 547
assign 1 0 548
assign 1 0 551
assign 1 0 555
assign 1 61 558
not 0 61 563
assign 1 0 564
assign 1 0 567
assign 1 0 571
decrementValue 0 63 574
assign 1 64 575
nextPeerGet 0 64 575
assign 1 64 576
nextDescendGet 0 64 576
assign 1 65 577
nextPeerGet 0 65 577
delayDelete 0 65 578
delayDelete 0 66 579
return 1 67 580
assign 1 69 582
new 0 69 582
assign 1 69 583
greater 1 69 588
assign 1 70 589
nextDescendGet 0 70 589
delayDelete 0 71 590
return 1 72 591
assign 1 74 593
not 0 74 598
assign 1 74 599
not 0 74 604
assign 1 0 605
assign 1 0 608
assign 1 0 612
assign 1 74 615
STRQGet 0 74 615
assign 1 74 616
equals 1 74 621
assign 1 0 622
assign 1 74 625
WSTRQGet 0 74 625
assign 1 74 626
equals 1 74 631
assign 1 0 632
assign 1 0 635
assign 1 0 639
assign 1 0 642
assign 1 0 646
assign 1 75 649
nextPeerGet 0 75 649
assign 1 76 650
new 0 76 650
assign 1 77 651
typenameGet 0 77 651
assign 1 78 654
def 1 78 659
assign 1 78 660
typenameGet 0 78 660
assign 1 78 661
equals 1 78 666
assign 1 0 667
assign 1 0 670
assign 1 0 674
incrementValue 0 79 677
delayDelete 0 80 678
assign 1 81 679
nextPeerGet 0 81 679
assign 1 83 685
new 0 83 685
assign 1 83 686
equals 1 83 691
assign 1 84 692
new 0 84 692
assign 1 85 693
new 0 85 693
heldSet 1 85 694
assign 1 86 695
STRINGLGet 0 86 695
typenameSet 1 86 696
assign 1 87 697
new 0 87 697
typeDetailSet 1 87 698
assign 1 89 701
new 0 89 701
assign 1 90 702
assign 1 91 703
new 0 91 703
heldSet 1 91 704
assign 1 92 705
WSTRQGet 0 92 705
assign 1 92 706
equals 1 92 711
assign 1 94 712
WSTRINGLGet 0 94 712
typenameSet 1 94 713
assign 1 96 716
STRINGLGet 0 96 716
typenameSet 1 96 717
return 1 99 720
assign 1 101 723
not 0 101 728
assign 1 0 729
assign 1 0 732
assign 1 0 736
assign 1 102 739
typenameGet 0 102 739
assign 1 102 740
STRINGLGet 0 102 740
assign 1 102 741
equals 1 102 746
assign 1 102 747
FSLASHGet 0 102 747
assign 1 102 748
equals 1 102 753
assign 1 0 754
assign 1 0 757
assign 1 0 761
delayDelete 0 103 764
assign 1 104 765
nextPeerGet 0 104 765
assign 1 105 766
new 0 105 766
assign 1 106 769
def 1 106 774
assign 1 106 775
typenameGet 0 106 775
assign 1 106 776
FSLASHGet 0 106 776
assign 1 106 777
equals 1 106 782
assign 1 0 783
assign 1 0 786
assign 1 0 790
incrementValue 0 107 793
delayDelete 0 108 794
assign 1 109 795
nextPeerGet 0 109 795
assign 1 111 801
new 0 111 801
assign 1 111 804
lesser 1 111 809
assign 1 112 810
heldGet 0 112 810
assign 1 112 811
heldGet 0 112 811
assign 1 112 812
add 1 112 812
heldSet 1 112 813
incrementValue 0 111 814
assign 1 114 820
def 1 114 825
assign 1 114 826
new 0 114 826
assign 1 114 827
modulus 1 114 827
assign 1 114 828
new 0 114 828
assign 1 114 829
equals 1 114 834
assign 1 0 835
assign 1 0 838
assign 1 0 842
assign 1 114 845
typenameGet 0 114 845
assign 1 114 846
equals 1 114 851
assign 1 0 852
assign 1 0 855
assign 1 0 859
delayDelete 0 115 862
assign 1 116 863
heldGet 0 116 863
assign 1 116 864
heldGet 0 116 864
assign 1 116 865
add 1 116 865
heldSet 1 116 866
assign 1 117 867
nextDescendGet 0 117 867
return 1 119 869
assign 1 120 872
equals 1 120 877
delayDelete 0 121 878
assign 1 122 879
nextPeerGet 0 122 879
assign 1 123 880
new 0 123 880
assign 1 124 883
def 1 124 888
assign 1 124 889
typenameGet 0 124 889
assign 1 124 890
equals 1 124 895
assign 1 0 896
assign 1 0 899
assign 1 0 903
incrementValue 0 125 906
delayDelete 0 126 907
assign 1 127 908
nextPeerGet 0 127 908
assign 1 129 914
equals 1 129 919
typeDetailSet 1 130 920
assign 1 131 921
new 0 131 921
assign 1 132 922
assign 1 133 923
new 0 133 923
assign 1 135 926
new 0 135 926
assign 1 135 929
lesser 1 135 934
assign 1 136 935
heldGet 0 136 935
assign 1 136 936
heldGet 0 136 936
assign 1 136 937
add 1 136 937
heldSet 1 136 938
incrementValue 0 135 939
return 1 139 946
assign 1 141 949
heldGet 0 141 949
assign 1 141 950
heldGet 0 141 950
assign 1 141 951
add 1 141 951
heldSet 1 141 952
assign 1 142 953
nextDescendGet 0 142 953
delayDelete 0 143 954
return 1 144 955
assign 1 147 959
DIVIDEGet 0 147 959
assign 1 147 960
equals 1 147 965
assign 1 147 966
def 1 147 971
assign 1 0 972
assign 1 0 975
assign 1 0 979
assign 1 147 982
DIVIDEGet 0 147 982
assign 1 147 983
equals 1 147 988
assign 1 0 989
assign 1 0 992
assign 1 0 996
assign 1 147 999
not 0 147 1004
assign 1 0 1005
assign 1 0 1008
assign 1 0 1012
assign 1 148 1015
nextPeerGet 0 148 1015
assign 1 148 1016
nextDescendGet 0 148 1016
assign 1 149 1017
new 0 149 1017
assign 1 150 1018
nextPeerGet 0 150 1018
delayDelete 0 150 1019
delayDelete 0 151 1020
return 1 152 1021
assign 1 155 1024
nextDescendGet 0 155 1024
delayDelete 0 156 1025
assign 1 157 1026
typenameGet 0 157 1026
assign 1 157 1027
NEWLINEGet 0 157 1027
assign 1 157 1028
equals 1 157 1033
assign 1 158 1034
new 0 158 1034
delayDelete 0 159 1035
assign 1 160 1036
nextDescendGet 0 160 1036
return 1 162 1038
assign 1 164 1040
SUBTRACTGet 0 164 1040
assign 1 164 1041
equals 1 164 1046
assign 1 164 1047
def 1 164 1052
assign 1 0 1053
assign 1 0 1056
assign 1 0 1060
assign 1 164 1063
INTLGet 0 164 1063
assign 1 164 1064
equals 1 164 1069
assign 1 0 1070
assign 1 0 1073
assign 1 0 1077
assign 1 165 1080
priorPeerGet 0 165 1080
assign 1 165 1081
def 1 165 1086
assign 1 166 1087
priorPeerGet 0 166 1087
assign 1 167 1090
def 1 167 1095
assign 1 167 1096
typenameGet 0 167 1096
assign 1 167 1097
SPACEGet 0 167 1097
assign 1 167 1098
equals 1 167 1103
assign 1 0 1104
assign 1 0 1107
assign 1 0 1111
assign 1 168 1114
priorPeerGet 0 168 1114
assign 1 170 1120
assign 1 173 1122
undef 1 173 1127
assign 1 0 1128
assign 1 173 1131
typenameGet 0 173 1131
assign 1 173 1132
COMMAGet 0 173 1132
assign 1 173 1133
equals 1 173 1138
assign 1 0 1139
assign 1 0 1142
assign 1 0 1146
assign 1 173 1149
typenameGet 0 173 1149
assign 1 173 1150
PARENSGet 0 173 1150
assign 1 173 1151
equals 1 173 1156
assign 1 0 1157
assign 1 0 1160
assign 1 0 1164
assign 1 173 1167
operGet 0 173 1167
assign 1 173 1168
typenameGet 0 173 1168
assign 1 173 1169
has 1 173 1169
assign 1 0 1171
assign 1 0 1174
assign 1 176 1178
nextPeerGet 0 176 1178
assign 1 176 1179
new 0 176 1179
assign 1 176 1180
nextPeerGet 0 176 1180
assign 1 176 1181
heldGet 0 176 1181
assign 1 176 1182
add 1 176 1182
heldSet 1 176 1183
assign 1 177 1184
nextDescendGet 0 177 1184
delayDelete 0 178 1185
return 1 179 1186
assign 1 182 1189
ASSIGNGet 0 182 1189
assign 1 182 1190
equals 1 182 1195
assign 1 182 1196
def 1 182 1201
assign 1 0 1202
assign 1 0 1205
assign 1 0 1209
assign 1 182 1212
ASSIGNGet 0 182 1212
assign 1 182 1213
equals 1 182 1218
assign 1 0 1219
assign 1 0 1222
assign 1 0 1226
assign 1 183 1229
EQUALSGet 0 183 1229
typenameSet 1 183 1230
assign 1 184 1231
heldGet 0 184 1231
assign 1 184 1232
nextPeerGet 0 184 1232
assign 1 184 1233
heldGet 0 184 1233
assign 1 184 1234
add 1 184 1234
heldSet 1 184 1235
assign 1 185 1236
nextPeerGet 0 185 1236
assign 1 185 1237
nextDescendGet 0 185 1237
assign 1 186 1238
nextPeerGet 0 186 1238
delayDelete 0 186 1239
return 1 187 1240
assign 1 189 1242
NOTGet 0 189 1242
assign 1 189 1243
equals 1 189 1248
assign 1 189 1249
def 1 189 1254
assign 1 0 1255
assign 1 0 1258
assign 1 0 1262
assign 1 189 1265
ASSIGNGet 0 189 1265
assign 1 189 1266
equals 1 189 1271
assign 1 0 1272
assign 1 0 1275
assign 1 0 1279
assign 1 190 1282
NOT_EQUALSGet 0 190 1282
typenameSet 1 190 1283
assign 1 191 1284
heldGet 0 191 1284
assign 1 191 1285
nextPeerGet 0 191 1285
assign 1 191 1286
heldGet 0 191 1286
assign 1 191 1287
add 1 191 1287
heldSet 1 191 1288
assign 1 192 1289
nextPeerGet 0 192 1289
assign 1 192 1290
nextDescendGet 0 192 1290
assign 1 193 1291
nextPeerGet 0 193 1291
delayDelete 0 193 1292
return 1 194 1293
assign 1 196 1295
ORGet 0 196 1295
assign 1 196 1296
equals 1 196 1301
assign 1 197 1302
nextPeerGet 0 197 1302
assign 1 197 1303
def 1 197 1308
assign 1 197 1309
nextPeerGet 0 197 1309
assign 1 197 1310
typenameGet 0 197 1310
assign 1 197 1311
ORGet 0 197 1311
assign 1 197 1312
equals 1 197 1317
assign 1 0 1318
assign 1 0 1321
assign 1 0 1325
assign 1 198 1328
heldGet 0 198 1328
assign 1 198 1329
nextPeerGet 0 198 1329
assign 1 198 1330
heldGet 0 198 1330
assign 1 198 1331
add 1 198 1331
heldSet 1 198 1332
assign 1 199 1333
LOGICAL_ORGet 0 199 1333
typenameSet 1 199 1334
assign 1 200 1335
nextPeerGet 0 200 1335
assign 1 200 1336
nextDescendGet 0 200 1336
assign 1 201 1337
nextPeerGet 0 201 1337
delayDelete 0 201 1338
return 1 202 1339
assign 1 205 1342
ANDGet 0 205 1342
assign 1 205 1343
equals 1 205 1348
assign 1 206 1349
nextPeerGet 0 206 1349
assign 1 206 1350
def 1 206 1355
assign 1 206 1356
nextPeerGet 0 206 1356
assign 1 206 1357
typenameGet 0 206 1357
assign 1 206 1358
ANDGet 0 206 1358
assign 1 206 1359
equals 1 206 1364
assign 1 0 1365
assign 1 0 1368
assign 1 0 1372
assign 1 207 1375
heldGet 0 207 1375
assign 1 207 1376
nextPeerGet 0 207 1376
assign 1 207 1377
heldGet 0 207 1377
assign 1 207 1378
add 1 207 1378
heldSet 1 207 1379
assign 1 208 1380
LOGICAL_ANDGet 0 208 1380
typenameSet 1 208 1381
assign 1 209 1382
nextPeerGet 0 209 1382
assign 1 209 1383
nextDescendGet 0 209 1383
assign 1 210 1384
nextPeerGet 0 210 1384
delayDelete 0 210 1385
return 1 211 1386
assign 1 214 1389
GREATERGet 0 214 1389
assign 1 214 1390
equals 1 214 1395
assign 1 214 1396
def 1 214 1401
assign 1 0 1402
assign 1 0 1405
assign 1 0 1409
assign 1 214 1412
ASSIGNGet 0 214 1412
assign 1 214 1413
equals 1 214 1418
assign 1 0 1419
assign 1 0 1422
assign 1 0 1426
assign 1 215 1429
GREATER_EQUALSGet 0 215 1429
typenameSet 1 215 1430
assign 1 216 1431
heldGet 0 216 1431
assign 1 216 1432
nextPeerGet 0 216 1432
assign 1 216 1433
heldGet 0 216 1433
assign 1 216 1434
add 1 216 1434
heldSet 1 216 1435
assign 1 217 1436
nextPeerGet 0 217 1436
assign 1 217 1437
nextDescendGet 0 217 1437
assign 1 218 1438
nextPeerGet 0 218 1438
delayDelete 0 218 1439
return 1 219 1440
assign 1 221 1442
LESSERGet 0 221 1442
assign 1 221 1443
equals 1 221 1448
assign 1 221 1449
def 1 221 1454
assign 1 0 1455
assign 1 0 1458
assign 1 0 1462
assign 1 221 1465
ASSIGNGet 0 221 1465
assign 1 221 1466
equals 1 221 1471
assign 1 0 1472
assign 1 0 1475
assign 1 0 1479
assign 1 222 1482
LESSER_EQUALSGet 0 222 1482
typenameSet 1 222 1483
assign 1 223 1484
heldGet 0 223 1484
assign 1 223 1485
nextPeerGet 0 223 1485
assign 1 223 1486
heldGet 0 223 1486
assign 1 223 1487
add 1 223 1487
heldSet 1 223 1488
assign 1 224 1489
nextPeerGet 0 224 1489
assign 1 224 1490
nextDescendGet 0 224 1490
assign 1 225 1491
nextPeerGet 0 225 1491
delayDelete 0 225 1492
return 1 226 1493
assign 1 228 1495
ADDGet 0 228 1495
assign 1 228 1496
equals 1 228 1501
assign 1 228 1502
def 1 228 1507
assign 1 0 1508
assign 1 0 1511
assign 1 0 1515
assign 1 228 1518
ADDGet 0 228 1518
assign 1 228 1519
equals 1 228 1524
assign 1 0 1525
assign 1 0 1528
assign 1 0 1532
assign 1 229 1535
nextPeerGet 0 229 1535
assign 1 229 1536
nextPeerGet 0 229 1536
assign 1 229 1537
def 1 229 1542
assign 1 229 1543
nextPeerGet 0 229 1543
assign 1 229 1544
nextPeerGet 0 229 1544
assign 1 229 1545
typenameGet 0 229 1545
assign 1 229 1546
ASSIGNGet 0 229 1546
assign 1 229 1547
equals 1 229 1552
assign 1 0 1553
assign 1 0 1556
assign 1 0 1560
assign 1 230 1563
INCREMENT_ASSIGNGet 0 230 1563
typenameSet 1 230 1564
assign 1 231 1565
heldGet 0 231 1565
assign 1 231 1566
nextPeerGet 0 231 1566
assign 1 231 1567
heldGet 0 231 1567
assign 1 231 1568
add 1 231 1568
assign 1 231 1569
nextPeerGet 0 231 1569
assign 1 231 1570
nextPeerGet 0 231 1570
assign 1 231 1571
heldGet 0 231 1571
assign 1 231 1572
add 1 231 1572
heldSet 1 231 1573
assign 1 232 1574
nextPeerGet 0 232 1574
assign 1 232 1575
nextPeerGet 0 232 1575
assign 1 232 1576
nextDescendGet 0 232 1576
assign 1 233 1577
nextPeerGet 0 233 1577
delayDelete 0 233 1578
assign 1 234 1579
nextPeerGet 0 234 1579
assign 1 234 1580
nextPeerGet 0 234 1580
delayDelete 0 234 1581
return 1 235 1582
assign 1 237 1584
INCREMENTGet 0 237 1584
typenameSet 1 237 1585
assign 1 238 1586
heldGet 0 238 1586
assign 1 238 1587
nextPeerGet 0 238 1587
assign 1 238 1588
heldGet 0 238 1588
assign 1 238 1589
add 1 238 1589
heldSet 1 238 1590
assign 1 239 1591
nextPeerGet 0 239 1591
assign 1 239 1592
nextDescendGet 0 239 1592
assign 1 240 1593
nextPeerGet 0 240 1593
delayDelete 0 240 1594
return 1 241 1595
assign 1 243 1597
SUBTRACTGet 0 243 1597
assign 1 243 1598
equals 1 243 1603
assign 1 243 1604
def 1 243 1609
assign 1 0 1610
assign 1 0 1613
assign 1 0 1617
assign 1 243 1620
SUBTRACTGet 0 243 1620
assign 1 243 1621
equals 1 243 1626
assign 1 0 1627
assign 1 0 1630
assign 1 0 1634
assign 1 244 1637
nextPeerGet 0 244 1637
assign 1 244 1638
nextPeerGet 0 244 1638
assign 1 244 1639
def 1 244 1644
assign 1 244 1645
nextPeerGet 0 244 1645
assign 1 244 1646
nextPeerGet 0 244 1646
assign 1 244 1647
typenameGet 0 244 1647
assign 1 244 1648
ASSIGNGet 0 244 1648
assign 1 244 1649
equals 1 244 1654
assign 1 0 1655
assign 1 0 1658
assign 1 0 1662
assign 1 245 1665
DECREMENT_ASSIGNGet 0 245 1665
typenameSet 1 245 1666
assign 1 246 1667
heldGet 0 246 1667
assign 1 246 1668
nextPeerGet 0 246 1668
assign 1 246 1669
heldGet 0 246 1669
assign 1 246 1670
add 1 246 1670
assign 1 246 1671
nextPeerGet 0 246 1671
assign 1 246 1672
nextPeerGet 0 246 1672
assign 1 246 1673
heldGet 0 246 1673
assign 1 246 1674
add 1 246 1674
heldSet 1 246 1675
assign 1 247 1676
nextPeerGet 0 247 1676
assign 1 247 1677
nextPeerGet 0 247 1677
assign 1 247 1678
nextDescendGet 0 247 1678
assign 1 248 1679
nextPeerGet 0 248 1679
delayDelete 0 248 1680
assign 1 249 1681
nextPeerGet 0 249 1681
assign 1 249 1682
nextPeerGet 0 249 1682
delayDelete 0 249 1683
return 1 250 1684
assign 1 252 1686
DECREMENTGet 0 252 1686
typenameSet 1 252 1687
assign 1 253 1688
heldGet 0 253 1688
assign 1 253 1689
nextPeerGet 0 253 1689
assign 1 253 1690
heldGet 0 253 1690
assign 1 253 1691
add 1 253 1691
heldSet 1 253 1692
assign 1 254 1693
nextPeerGet 0 254 1693
assign 1 254 1694
nextDescendGet 0 254 1694
assign 1 255 1695
nextPeerGet 0 255 1695
delayDelete 0 255 1696
return 1 256 1697
assign 1 258 1699
ADDGet 0 258 1699
assign 1 258 1700
equals 1 258 1705
assign 1 258 1706
def 1 258 1711
assign 1 0 1712
assign 1 0 1715
assign 1 0 1719
assign 1 258 1722
ASSIGNGet 0 258 1722
assign 1 258 1723
equals 1 258 1728
assign 1 0 1729
assign 1 0 1732
assign 1 0 1736
assign 1 259 1739
ADD_ASSIGNGet 0 259 1739
typenameSet 1 259 1740
assign 1 260 1741
heldGet 0 260 1741
assign 1 260 1742
nextPeerGet 0 260 1742
assign 1 260 1743
heldGet 0 260 1743
assign 1 260 1744
add 1 260 1744
heldSet 1 260 1745
assign 1 261 1746
nextPeerGet 0 261 1746
assign 1 261 1747
nextDescendGet 0 261 1747
assign 1 262 1748
nextPeerGet 0 262 1748
delayDelete 0 262 1749
return 1 263 1750
assign 1 265 1752
SUBTRACTGet 0 265 1752
assign 1 265 1753
equals 1 265 1758
assign 1 265 1759
def 1 265 1764
assign 1 0 1765
assign 1 0 1768
assign 1 0 1772
assign 1 265 1775
ASSIGNGet 0 265 1775
assign 1 265 1776
equals 1 265 1781
assign 1 0 1782
assign 1 0 1785
assign 1 0 1789
assign 1 266 1792
SUBTRACT_ASSIGNGet 0 266 1792
typenameSet 1 266 1793
assign 1 267 1794
heldGet 0 267 1794
assign 1 267 1795
nextPeerGet 0 267 1795
assign 1 267 1796
heldGet 0 267 1796
assign 1 267 1797
add 1 267 1797
heldSet 1 267 1798
assign 1 268 1799
nextPeerGet 0 268 1799
assign 1 268 1800
nextDescendGet 0 268 1800
assign 1 269 1801
nextPeerGet 0 269 1801
delayDelete 0 269 1802
return 1 270 1803
assign 1 272 1805
MULTIPLYGet 0 272 1805
assign 1 272 1806
equals 1 272 1811
assign 1 272 1812
def 1 272 1817
assign 1 0 1818
assign 1 0 1821
assign 1 0 1825
assign 1 272 1828
ASSIGNGet 0 272 1828
assign 1 272 1829
equals 1 272 1834
assign 1 0 1835
assign 1 0 1838
assign 1 0 1842
assign 1 273 1845
MULTIPLY_ASSIGNGet 0 273 1845
typenameSet 1 273 1846
assign 1 274 1847
heldGet 0 274 1847
assign 1 274 1848
nextPeerGet 0 274 1848
assign 1 274 1849
heldGet 0 274 1849
assign 1 274 1850
add 1 274 1850
heldSet 1 274 1851
assign 1 275 1852
nextPeerGet 0 275 1852
assign 1 275 1853
nextDescendGet 0 275 1853
assign 1 276 1854
nextPeerGet 0 276 1854
delayDelete 0 276 1855
return 1 277 1856
assign 1 279 1858
DIVIDEGet 0 279 1858
assign 1 279 1859
equals 1 279 1864
assign 1 279 1865
def 1 279 1870
assign 1 0 1871
assign 1 0 1874
assign 1 0 1878
assign 1 279 1881
ASSIGNGet 0 279 1881
assign 1 279 1882
equals 1 279 1887
assign 1 0 1888
assign 1 0 1891
assign 1 0 1895
assign 1 280 1898
DIVIDE_ASSIGNGet 0 280 1898
typenameSet 1 280 1899
assign 1 281 1900
heldGet 0 281 1900
assign 1 281 1901
nextPeerGet 0 281 1901
assign 1 281 1902
heldGet 0 281 1902
assign 1 281 1903
add 1 281 1903
heldSet 1 281 1904
assign 1 282 1905
nextPeerGet 0 282 1905
assign 1 282 1906
nextDescendGet 0 282 1906
assign 1 283 1907
nextPeerGet 0 283 1907
delayDelete 0 283 1908
return 1 284 1909
assign 1 286 1911
MODULUSGet 0 286 1911
assign 1 286 1912
equals 1 286 1917
assign 1 286 1918
def 1 286 1923
assign 1 0 1924
assign 1 0 1927
assign 1 0 1931
assign 1 286 1934
ASSIGNGet 0 286 1934
assign 1 286 1935
equals 1 286 1940
assign 1 0 1941
assign 1 0 1944
assign 1 0 1948
assign 1 287 1951
MODULUS_ASSIGNGet 0 287 1951
typenameSet 1 287 1952
assign 1 288 1953
heldGet 0 288 1953
assign 1 288 1954
nextPeerGet 0 288 1954
assign 1 288 1955
heldGet 0 288 1955
assign 1 288 1956
add 1 288 1956
heldSet 1 288 1957
assign 1 289 1958
nextPeerGet 0 289 1958
assign 1 289 1959
nextDescendGet 0 289 1959
assign 1 290 1960
nextPeerGet 0 290 1960
delayDelete 0 290 1961
return 1 291 1962
assign 1 293 1964
ANDGet 0 293 1964
assign 1 293 1965
equals 1 293 1970
assign 1 293 1971
def 1 293 1976
assign 1 0 1977
assign 1 0 1980
assign 1 0 1984
assign 1 293 1987
ASSIGNGet 0 293 1987
assign 1 293 1988
equals 1 293 1993
assign 1 0 1994
assign 1 0 1997
assign 1 0 2001
assign 1 294 2004
AND_ASSIGNGet 0 294 2004
typenameSet 1 294 2005
assign 1 295 2006
heldGet 0 295 2006
assign 1 295 2007
nextPeerGet 0 295 2007
assign 1 295 2008
heldGet 0 295 2008
assign 1 295 2009
add 1 295 2009
heldSet 1 295 2010
assign 1 296 2011
nextPeerGet 0 296 2011
assign 1 296 2012
nextDescendGet 0 296 2012
assign 1 297 2013
nextPeerGet 0 297 2013
delayDelete 0 297 2014
return 1 298 2015
assign 1 300 2017
ORGet 0 300 2017
assign 1 300 2018
equals 1 300 2023
assign 1 300 2024
def 1 300 2029
assign 1 0 2030
assign 1 0 2033
assign 1 0 2037
assign 1 300 2040
ASSIGNGet 0 300 2040
assign 1 300 2041
equals 1 300 2046
assign 1 0 2047
assign 1 0 2050
assign 1 0 2054
assign 1 301 2057
OR_ASSIGNGet 0 301 2057
typenameSet 1 301 2058
assign 1 302 2059
heldGet 0 302 2059
assign 1 302 2060
nextPeerGet 0 302 2060
assign 1 302 2061
heldGet 0 302 2061
assign 1 302 2062
add 1 302 2062
heldSet 1 302 2063
assign 1 303 2064
nextPeerGet 0 303 2064
assign 1 303 2065
nextDescendGet 0 303 2065
assign 1 304 2066
nextPeerGet 0 304 2066
delayDelete 0 304 2067
return 1 305 2068
assign 1 307 2070
SPACEGet 0 307 2070
assign 1 307 2071
equals 1 307 2076
assign 1 0 2077
assign 1 307 2080
NEWLINEGet 0 307 2080
assign 1 307 2081
equals 1 307 2086
assign 1 0 2087
assign 1 0 2090
assign 1 308 2094
nextDescendGet 0 308 2094
delayDelete 0 309 2095
return 1 310 2096
assign 1 312 2098
nextDescendGet 0 312 2098
return 1 312 2099
return 1 0 2102
return 1 0 2105
assign 1 0 2108
assign 1 0 2112
return 1 0 2116
return 1 0 2119
assign 1 0 2122
assign 1 0 2126
return 1 0 2130
return 1 0 2133
assign 1 0 2136
assign 1 0 2140
return 1 0 2144
return 1 0 2147
assign 1 0 2150
assign 1 0 2154
return 1 0 2158
return 1 0 2161
assign 1 0 2164
assign 1 0 2168
return 1 0 2172
return 1 0 2175
assign 1 0 2178
assign 1 0 2182
return 1 0 2186
return 1 0 2189
assign 1 0 2192
assign 1 0 2196
return 1 0 2200
return 1 0 2203
assign 1 0 2206
assign 1 0 2210
return 1 0 2214
return 1 0 2217
assign 1 0 2220
assign 1 0 2224
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1076915155: return bem_serializeToString_0();
case -2118708930: return bem_new_0();
case -1838156413: return bem_goingStrGetDirect_0();
case 946360922: return bem_serializationIteratorGet_0();
case -1857496098: return bem_inStrGetDirect_0();
case 77584512: return bem_quoteTypeGetDirect_0();
case -893093197: return bem_toString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case -975498393: return bem_fieldNamesGet_0();
case 246120668: return bem_inStrGet_0();
case 798914165: return bem_inSpaceGet_0();
case 1209398575: return bem_inNlGet_0();
case 421177749: return bem_print_0();
case 58217918: return bem_ntypesGet_0();
case 88195190: return bem_constGetDirect_0();
case 1834246217: return bem_classNameGet_0();
case 1746415434: return bem_inNlGetDirect_0();
case 1343914325: return bem_goingStrGet_0();
case -40905183: return bem_echo_0();
case 1542633581: return bem_containerGetDirect_0();
case -193582610: return bem_tagGet_0();
case -1703378497: return bem_nestCommentGetDirect_0();
case 1232394224: return bem_buildGetDirect_0();
case -458218411: return bem_constGet_0();
case -1653939165: return bem_iteratorGet_0();
case 842687434: return bem_inLcGet_0();
case 1974505938: return bem_hashGet_0();
case -410731305: return bem_nestCommentGet_0();
case 1910033340: return bem_buildGet_0();
case 954703233: return bem_create_0();
case 1748336476: return bem_inLcGetDirect_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -2116468169: return bem_strqCntGet_0();
case 2081363871: return bem_copy_0();
case 1529201275: return bem_quoteTypeGet_0();
case 633669157: return bem_inSpaceGetDirect_0();
case -2102703130: return bem_containerGet_0();
case -574574637: return bem_transGet_0();
case -606522170: return bem_transGetDirect_0();
case 2147093830: return bem_strqCntGetDirect_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 876676878: return bem_ntypesGetDirect_0();
case 1153344161: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -669415086: return bem_constSet_1(bevd_0);
case 1416027976: return bem_strqCntSetDirect_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 1801724214: return bem_goingStrSetDirect_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 1949947674: return bem_nestCommentSet_1(bevd_0);
case -2042501127: return bem_ntypesSetDirect_1(bevd_0);
case -1415090399: return bem_goingStrSet_1(bevd_0);
case 300135539: return bem_inLcSet_1(bevd_0);
case -1378164182: return bem_quoteTypeSet_1(bevd_0);
case -996640729: return bem_buildSet_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 1736101817: return bem_transSetDirect_1(bevd_0);
case 537433000: return bem_end_1(bevd_0);
case -1537135787: return bem_ntypesSet_1(bevd_0);
case -1215877607: return bem_inLcSetDirect_1(bevd_0);
case 1865062933: return bem_buildSetDirect_1(bevd_0);
case -1262209827: return bem_strqCntSet_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -1623360650: return bem_inNlSetDirect_1(bevd_0);
case -631003549: return bem_begin_1(bevd_0);
case 760472902: return bem_quoteTypeSetDirect_1(bevd_0);
case 2011490434: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1552867540: return bem_inStrSet_1(bevd_0);
case -1199705490: return bem_inStrSetDirect_1(bevd_0);
case 1774117556: return bem_inSpaceSetDirect_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -496971044: return bem_inSpaceSet_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -1567150732: return bem_nestCommentSetDirect_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -225069199: return bem_containerSetDirect_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 215907131: return bem_transSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -2021309617: return bem_inNlSet_1(bevd_0);
case 1213881950: return bem_containerSet_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1819306118: return bem_constSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass3_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass3_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass3();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass3.bece_BEC_3_5_5_5_BuildVisitPass3_bevs_inst = (BEC_3_5_5_5_BuildVisitPass3) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass3.bece_BEC_3_5_5_5_BuildVisitPass3_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass3.bece_BEC_3_5_5_5_BuildVisitPass3_bevs_type;
}
}
}
