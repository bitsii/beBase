namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static new BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try /* Line: 620*/ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 622*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 625*/
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 631*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(779059147, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 633*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 636*/
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 643*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(937370946, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 645*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 648*/
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 655*/ {
bevl_r = bevp_container.bemd_0(1587451931);
bevp_lock.bem_unlock_0();
} /* Line: 657*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 660*/
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 667*/ {
bevl_r = bevp_container.bemd_1(517117201, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 669*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 672*/
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 679*/ {
bevl_r = bevp_container.bemd_1(517117201, beva_key);
bevp_container.bemd_1(-1969854422, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 682*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 685*/
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 692*/ {
bevl_r = bevp_container.bemd_2(-1574261876, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 694*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 697*/
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 704*/ {
bevp_container.bemd_1(-1648734891, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 706*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 709*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 715*/ {
bevl_r = bevp_container.bemd_1(1627470026, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 717*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 720*/
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 727*/ {
bevp_container.bemd_1(1627470026, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 729*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 732*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 738*/ {
bevl_r = bevp_container.bemd_2(-1373042537, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 740*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 743*/
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 750*/ {
bevp_container.bemd_2(-1373042537, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 752*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 755*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 761*/ {
bevl_rc = bevp_container.bemd_3(1132014852, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 763*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 766*/
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getSet_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 773*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(1765841257);
bevp_lock.bem_unlock_0();
} /* Line: 775*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 778*/
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 785*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1561220618);
bevp_lock.bem_unlock_0();
} /* Line: 787*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 790*/
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 797*/ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-1604673737, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 799*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 802*/
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 809*/ {
bevt_0_ta_ph = bevp_container.bemd_1(779059147, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 810*/ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 811*/
 else /* Line: 812*/ {
bevp_container.bemd_2(-1373042537, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 814*/
bevp_lock.bem_unlock_0();
} /* Line: 816*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 819*/
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
try /* Line: 826*/ {
bevt_0_ta_ph = bevp_container.bemd_1(779059147, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 827*/ {
bevl_result = bevp_container.bemd_1(517117201, beva_key);
} /* Line: 828*/
 else /* Line: 829*/ {
bevp_container.bemd_2(-1373042537, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 831*/
bevp_lock.bem_unlock_0();
} /* Line: 833*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 836*/
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 843*/ {
bevp_container.bemd_3(-1208221563, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 845*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 848*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 854*/ {
bevl_r = bevp_container.bemd_1(-1969854422, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 856*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 859*/
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 866*/ {
bevl_r = bevp_container.bemd_2(2119982935, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 868*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 871*/
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 878*/ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(123269264);
bevp_lock.bem_unlock_0();
} /* Line: 880*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 883*/
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 890*/ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-836370094);
bevp_lock.bem_unlock_0();
} /* Line: 892*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 895*/
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 902*/ {
bevl_r = bevp_container.bemd_0(2081363871);
bevp_lock.bem_unlock_0();
} /* Line: 904*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 907*/
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 914*/ {
bevp_container.bemd_0(-1166381907);
bevp_lock.bem_unlock_0();
} /* Line: 916*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 919*/
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 925*/ {
bevp_container.bemd_0(925559139);
bevp_lock.bem_unlock_0();
} /* Line: 927*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 930*/
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_container = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {616, 619, 621, 622, 624, 625, 630, 632, 633, 635, 636, 638, 642, 644, 645, 647, 648, 650, 654, 656, 657, 659, 660, 662, 666, 668, 669, 671, 672, 674, 678, 680, 681, 682, 684, 685, 687, 691, 693, 694, 696, 697, 699, 703, 705, 706, 708, 709, 714, 716, 717, 719, 720, 722, 726, 728, 729, 731, 732, 737, 739, 740, 742, 743, 745, 749, 751, 752, 754, 755, 760, 762, 763, 765, 766, 768, 772, 774, 775, 777, 778, 780, 784, 786, 787, 789, 790, 792, 796, 798, 799, 801, 802, 804, 808, 810, 811, 813, 814, 816, 818, 819, 821, 825, 827, 828, 830, 831, 833, 835, 836, 838, 842, 844, 845, 847, 848, 853, 855, 856, 858, 859, 861, 865, 867, 868, 870, 871, 873, 877, 879, 880, 882, 883, 885, 889, 891, 892, 894, 895, 897, 901, 903, 904, 906, 907, 909, 913, 915, 916, 918, 919, 924, 926, 927, 929, 930, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 23, 24, 28, 29, 36, 38, 39, 43, 44, 46, 51, 53, 54, 58, 59, 61, 66, 68, 69, 73, 74, 76, 81, 83, 84, 88, 89, 91, 96, 98, 99, 100, 104, 105, 107, 112, 114, 115, 119, 120, 122, 126, 128, 129, 133, 134, 141, 143, 144, 148, 149, 151, 155, 157, 158, 162, 163, 170, 172, 173, 177, 178, 180, 184, 186, 187, 191, 192, 199, 201, 202, 206, 207, 209, 214, 216, 217, 221, 222, 224, 229, 231, 232, 236, 237, 239, 244, 246, 247, 251, 252, 254, 260, 262, 264, 267, 268, 270, 274, 275, 277, 283, 285, 287, 290, 291, 293, 297, 298, 300, 304, 306, 307, 311, 312, 319, 321, 322, 326, 327, 329, 334, 336, 337, 341, 342, 344, 349, 351, 352, 356, 357, 359, 364, 366, 367, 371, 372, 374, 379, 381, 382, 386, 387, 389, 393, 395, 396, 400, 401, 407, 409, 410, 414, 415, 420, 423, 426, 430, 434, 437, 440, 444};
/* BEGIN LINEINFO 
assign 1 616 20
new 0 616 20
lock 0 619 21
assign 1 621 23
unlock 0 622 24
unlock 0 624 28
throw 1 625 29
lock 0 630 36
assign 1 632 38
has 1 632 38
unlock 0 633 39
unlock 0 635 43
throw 1 636 44
return 1 638 46
lock 0 642 51
assign 1 644 53
has 2 644 53
unlock 0 645 54
unlock 0 647 58
throw 1 648 59
return 1 650 61
lock 0 654 66
assign 1 656 68
get 0 656 68
unlock 0 657 69
unlock 0 659 73
throw 1 660 74
return 1 662 76
lock 0 666 81
assign 1 668 83
get 1 668 83
unlock 0 669 84
unlock 0 671 88
throw 1 672 89
return 1 674 91
lock 0 678 96
assign 1 680 98
get 1 680 98
delete 1 681 99
unlock 0 682 100
unlock 0 684 104
throw 1 685 105
return 1 687 107
lock 0 691 112
assign 1 693 114
get 2 693 114
unlock 0 694 115
unlock 0 696 119
throw 1 697 120
return 1 699 122
lock 0 703 126
addValue 1 705 128
unlock 0 706 129
unlock 0 708 133
throw 1 709 134
lock 0 714 141
assign 1 716 143
put 1 716 143
unlock 0 717 144
unlock 0 719 148
throw 1 720 149
return 1 722 151
lock 0 726 155
put 1 728 157
unlock 0 729 158
unlock 0 731 162
throw 1 732 163
lock 0 737 170
assign 1 739 172
put 2 739 172
unlock 0 740 173
unlock 0 742 177
throw 1 743 178
return 1 745 180
lock 0 749 184
put 2 751 186
unlock 0 752 187
unlock 0 754 191
throw 1 755 192
lock 0 760 199
assign 1 762 201
testAndPut 3 762 201
unlock 0 763 202
unlock 0 765 206
throw 1 766 207
return 1 768 209
lock 0 772 214
assign 1 774 216
getSet 0 774 216
unlock 0 775 217
unlock 0 777 221
throw 1 778 222
return 1 780 224
lock 0 784 229
assign 1 786 231
getMap 0 786 231
unlock 0 787 232
unlock 0 789 236
throw 1 790 237
return 1 792 239
lock 0 796 244
assign 1 798 246
getMap 1 798 246
unlock 0 799 247
unlock 0 801 251
throw 1 802 252
return 1 804 254
lock 0 808 260
assign 1 810 262
has 1 810 262
assign 1 811 264
new 0 811 264
put 2 813 267
assign 1 814 268
new 0 814 268
unlock 0 816 270
unlock 0 818 274
throw 1 819 275
return 1 821 277
lock 0 825 283
assign 1 827 285
has 1 827 285
assign 1 828 287
get 1 828 287
put 2 830 290
assign 1 831 291
unlock 0 833 293
unlock 0 835 297
throw 1 836 298
return 1 838 300
lock 0 842 304
put 3 844 306
unlock 0 845 307
unlock 0 847 311
throw 1 848 312
lock 0 853 319
assign 1 855 321
delete 1 855 321
unlock 0 856 322
unlock 0 858 326
throw 1 859 327
return 1 861 329
lock 0 865 334
assign 1 867 336
delete 2 867 336
unlock 0 868 337
unlock 0 870 341
throw 1 871 342
return 1 873 344
lock 0 877 349
assign 1 879 351
sizeGet 0 879 351
unlock 0 880 352
unlock 0 882 356
throw 1 883 357
return 1 885 359
lock 0 889 364
assign 1 891 366
isEmptyGet 0 891 366
unlock 0 892 367
unlock 0 894 371
throw 1 895 372
return 1 897 374
lock 0 901 379
assign 1 903 381
copy 0 903 381
unlock 0 904 382
unlock 0 906 386
throw 1 907 387
return 1 909 389
lock 0 913 393
clear 0 915 395
unlock 0 916 396
unlock 0 918 400
throw 1 919 401
lock 0 924 407
close 0 926 409
unlock 0 927 410
unlock 0 929 414
throw 1 930 415
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
return 1 0 434
return 1 0 437
assign 1 0 440
assign 1 0 444
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 925559139: return bem_close_0();
case -1077543268: return bem_copyContainer_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -893093197: return bem_toString_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case 954703233: return bem_create_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1834246217: return bem_classNameGet_0();
case -836370094: return bem_isEmptyGet_0();
case -193582610: return bem_tagGet_0();
case -1166381907: return bem_clear_0();
case -975498393: return bem_fieldNamesGet_0();
case -2102703130: return bem_containerGet_0();
case 1587451931: return bem_get_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case 1765841257: return bem_getSet_0();
case -1561220618: return bem_getMap_0();
case 1542633581: return bem_containerGetDirect_0();
case 123269264: return bem_sizeGet_0();
case -755679640: return bem_lockGetDirect_0();
case -1481115162: return bem_lockGet_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -260432710: return bem_sameObject_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 313683143: return bem_getAndClear_1(bevd_0);
case 59504167: return bem_new_1(bevd_0);
case -1604673737: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1592339935: return bem_putReturn_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 1627470026: return bem_put_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 1688022980: return bem_lockSet_1(bevd_0);
case 779059147: return bem_has_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -225069199: return bem_containerSetDirect_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -516263413: return bem_lockSetDirect_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1648734891: return bem_addValue_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case 1213881950: return bem_containerSet_1(bevd_0);
case 517117201: return bem_get_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1969854422: return bem_delete_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1373042537: return bem_put_2(bevd_0, bevd_1);
case 937370946: return bem_has_2(bevd_0, bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -99767008: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -1574261876: return bem_get_2(bevd_0, bevd_1);
case -774703989: return bem_putReturn_2(bevd_0, bevd_1);
case -918964500: return bem_getOrPut_2(bevd_0, bevd_1);
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2119982935: return bem_delete_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1132014852: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
case -1208221563: return bem_put_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
}
