namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static new BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 871 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 873 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 876 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 882 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(-1422015583, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 884 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 887 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 894 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(-1378408800, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 896 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 899 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 906 */ {
bevl_r = bevp_container.bemd_0(1337461108);
bevp_lock.bem_unlock_0();
} /* Line: 908 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 911 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 918 */ {
bevl_r = bevp_container.bemd_1(1279255185, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 920 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 923 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 930 */ {
bevl_r = bevp_container.bemd_1(1279255185, beva_key);
bevp_container.bemd_1(-200725456, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 933 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 936 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 943 */ {
bevl_r = bevp_container.bemd_2(-84641831, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 945 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 948 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 955 */ {
bevp_container.bemd_1(-1110681556, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 957 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 960 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 966 */ {
bevl_r = bevp_container.bemd_1(652756, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 968 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 971 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 978 */ {
bevp_container.bemd_1(652756, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 980 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 983 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 989 */ {
bevl_r = bevp_container.bemd_2(1613887137, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 991 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 994 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1001 */ {
bevp_container.bemd_2(1613887137, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1003 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1006 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1012 */ {
bevl_rc = bevp_container.bemd_3(686400533, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 1014 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1017 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getSet_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1024 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(1742103199);
bevp_lock.bem_unlock_0();
} /* Line: 1026 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1029 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1036 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(1253746801);
bevp_lock.bem_unlock_0();
} /* Line: 1038 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1041 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1048 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(-233371686, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 1050 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1053 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1060 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-1422015583, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1061 */ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 1062 */
 else  /* Line: 1063 */ {
bevp_container.bemd_2(1613887137, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1065 */
bevp_lock.bem_unlock_0();
} /* Line: 1067 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1070 */
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1077 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(-1422015583, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1078 */ {
bevl_result = bevp_container.bemd_1(1279255185, beva_key);
} /* Line: 1079 */
 else  /* Line: 1080 */ {
bevp_container.bemd_2(1613887137, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1082 */
bevp_lock.bem_unlock_0();
} /* Line: 1084 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1087 */
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1094 */ {
bevp_container.bemd_3(-1401622544, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1096 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1099 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1105 */ {
bevl_r = bevp_container.bemd_1(-200725456, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1107 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1110 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1117 */ {
bevl_r = bevp_container.bemd_2(903312197, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1119 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1122 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1129 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(-692661161);
bevp_lock.bem_unlock_0();
} /* Line: 1131 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1134 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1141 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(338214363);
bevp_lock.bem_unlock_0();
} /* Line: 1143 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1146 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1153 */ {
bevl_r = bevp_container.bemd_0(653349672);
bevp_lock.bem_unlock_0();
} /* Line: 1155 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1158 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1165 */ {
bevp_container.bemd_0(-1957168733);
bevp_lock.bem_unlock_0();
} /* Line: 1167 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1170 */
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1176 */ {
bevp_container.bemd_0(-1081610686);
bevp_lock.bem_unlock_0();
} /* Line: 1178 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1181 */
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {867, 870, 872, 873, 875, 876, 881, 883, 884, 886, 887, 889, 893, 895, 896, 898, 899, 901, 905, 907, 908, 910, 911, 913, 917, 919, 920, 922, 923, 925, 929, 931, 932, 933, 935, 936, 938, 942, 944, 945, 947, 948, 950, 954, 956, 957, 959, 960, 965, 967, 968, 970, 971, 973, 977, 979, 980, 982, 983, 988, 990, 991, 993, 994, 996, 1000, 1002, 1003, 1005, 1006, 1011, 1013, 1014, 1016, 1017, 1019, 1023, 1025, 1026, 1028, 1029, 1031, 1035, 1037, 1038, 1040, 1041, 1043, 1047, 1049, 1050, 1052, 1053, 1055, 1059, 1061, 1062, 1064, 1065, 1067, 1069, 1070, 1072, 1076, 1078, 1079, 1081, 1082, 1084, 1086, 1087, 1089, 1093, 1095, 1096, 1098, 1099, 1104, 1106, 1107, 1109, 1110, 1112, 1116, 1118, 1119, 1121, 1122, 1124, 1128, 1130, 1131, 1133, 1134, 1136, 1140, 1142, 1143, 1145, 1146, 1148, 1152, 1154, 1155, 1157, 1158, 1160, 1164, 1166, 1167, 1169, 1170, 1175, 1177, 1178, 1180, 1181, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 59, 60, 62, 67, 69, 70, 74, 75, 77, 82, 84, 85, 89, 90, 92, 97, 99, 100, 101, 105, 106, 108, 113, 115, 116, 120, 121, 123, 127, 129, 130, 134, 135, 142, 144, 145, 149, 150, 152, 156, 158, 159, 163, 164, 171, 173, 174, 178, 179, 181, 185, 187, 188, 192, 193, 200, 202, 203, 207, 208, 210, 215, 217, 218, 222, 223, 225, 230, 232, 233, 237, 238, 240, 245, 247, 248, 252, 253, 255, 261, 263, 265, 268, 269, 271, 275, 276, 278, 284, 286, 288, 291, 292, 294, 298, 299, 301, 305, 307, 308, 312, 313, 320, 322, 323, 327, 328, 330, 335, 337, 338, 342, 343, 345, 350, 352, 353, 357, 358, 360, 365, 367, 368, 372, 373, 375, 380, 382, 383, 387, 388, 390, 394, 396, 397, 401, 402, 408, 410, 411, 415, 416, 421, 424, 427, 431, 435, 438, 441, 445};
/* BEGIN LINEINFO 
assign 1 867 21
new 0 867 21
lock 0 870 22
assign 1 872 24
unlock 0 873 25
unlock 0 875 29
throw 1 876 30
lock 0 881 37
assign 1 883 39
has 1 883 39
unlock 0 884 40
unlock 0 886 44
throw 1 887 45
return 1 889 47
lock 0 893 52
assign 1 895 54
has 2 895 54
unlock 0 896 55
unlock 0 898 59
throw 1 899 60
return 1 901 62
lock 0 905 67
assign 1 907 69
get 0 907 69
unlock 0 908 70
unlock 0 910 74
throw 1 911 75
return 1 913 77
lock 0 917 82
assign 1 919 84
get 1 919 84
unlock 0 920 85
unlock 0 922 89
throw 1 923 90
return 1 925 92
lock 0 929 97
assign 1 931 99
get 1 931 99
delete 1 932 100
unlock 0 933 101
unlock 0 935 105
throw 1 936 106
return 1 938 108
lock 0 942 113
assign 1 944 115
get 2 944 115
unlock 0 945 116
unlock 0 947 120
throw 1 948 121
return 1 950 123
lock 0 954 127
addValue 1 956 129
unlock 0 957 130
unlock 0 959 134
throw 1 960 135
lock 0 965 142
assign 1 967 144
put 1 967 144
unlock 0 968 145
unlock 0 970 149
throw 1 971 150
return 1 973 152
lock 0 977 156
put 1 979 158
unlock 0 980 159
unlock 0 982 163
throw 1 983 164
lock 0 988 171
assign 1 990 173
put 2 990 173
unlock 0 991 174
unlock 0 993 178
throw 1 994 179
return 1 996 181
lock 0 1000 185
put 2 1002 187
unlock 0 1003 188
unlock 0 1005 192
throw 1 1006 193
lock 0 1011 200
assign 1 1013 202
testAndPut 3 1013 202
unlock 0 1014 203
unlock 0 1016 207
throw 1 1017 208
return 1 1019 210
lock 0 1023 215
assign 1 1025 217
getSet 0 1025 217
unlock 0 1026 218
unlock 0 1028 222
throw 1 1029 223
return 1 1031 225
lock 0 1035 230
assign 1 1037 232
getMap 0 1037 232
unlock 0 1038 233
unlock 0 1040 237
throw 1 1041 238
return 1 1043 240
lock 0 1047 245
assign 1 1049 247
getMap 1 1049 247
unlock 0 1050 248
unlock 0 1052 252
throw 1 1053 253
return 1 1055 255
lock 0 1059 261
assign 1 1061 263
has 1 1061 263
assign 1 1062 265
new 0 1062 265
put 2 1064 268
assign 1 1065 269
new 0 1065 269
unlock 0 1067 271
unlock 0 1069 275
throw 1 1070 276
return 1 1072 278
lock 0 1076 284
assign 1 1078 286
has 1 1078 286
assign 1 1079 288
get 1 1079 288
put 2 1081 291
assign 1 1082 292
unlock 0 1084 294
unlock 0 1086 298
throw 1 1087 299
return 1 1089 301
lock 0 1093 305
put 3 1095 307
unlock 0 1096 308
unlock 0 1098 312
throw 1 1099 313
lock 0 1104 320
assign 1 1106 322
delete 1 1106 322
unlock 0 1107 323
unlock 0 1109 327
throw 1 1110 328
return 1 1112 330
lock 0 1116 335
assign 1 1118 337
delete 2 1118 337
unlock 0 1119 338
unlock 0 1121 342
throw 1 1122 343
return 1 1124 345
lock 0 1128 350
assign 1 1130 352
sizeGet 0 1130 352
unlock 0 1131 353
unlock 0 1133 357
throw 1 1134 358
return 1 1136 360
lock 0 1140 365
assign 1 1142 367
isEmptyGet 0 1142 367
unlock 0 1143 368
unlock 0 1145 372
throw 1 1146 373
return 1 1148 375
lock 0 1152 380
assign 1 1154 382
copy 0 1154 382
unlock 0 1155 383
unlock 0 1157 387
throw 1 1158 388
return 1 1160 390
lock 0 1164 394
clear 0 1166 396
unlock 0 1167 397
unlock 0 1169 401
throw 1 1170 402
lock 0 1175 408
close 0 1177 410
unlock 0 1178 411
unlock 0 1180 415
throw 1 1181 416
return 1 0 421
return 1 0 424
assign 1 0 427
assign 1 0 431
return 1 0 435
return 1 0 438
assign 1 0 441
assign 1 0 445
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1799416909: return bem_serializationIteratorGet_0();
case 1804773996: return bem_create_0();
case 1337461108: return bem_get_0();
case -73436994: return bem_new_0();
case -1702402638: return bem_copyContainer_0();
case 1254813232: return bem_toAny_0();
case -1072030744: return bem_sourceFileNameGet_0();
case 1253746801: return bem_getMap_0();
case 653349672: return bem_copy_0();
case -1778497682: return bem_serializeToString_0();
case 1618756204: return bem_lockGet_0();
case -692661161: return bem_sizeGet_0();
case 1742103199: return bem_getSet_0();
case 959038598: return bem_echo_0();
case 258127587: return bem_containerGetDirect_0();
case -2120499139: return bem_iteratorGet_0();
case -1081610686: return bem_close_0();
case 1562662552: return bem_many_0();
case 338214363: return bem_isEmptyGet_0();
case 167710369: return bem_print_0();
case -297374401: return bem_hashGet_0();
case -1067704397: return bem_once_0();
case -1957168733: return bem_clear_0();
case 39810102: return bem_tagGet_0();
case 1769468354: return bem_fieldNamesGet_0();
case -1628372783: return bem_classNameGet_0();
case -1071008216: return bem_serializeContents_0();
case 621276181: return bem_toString_0();
case 401689842: return bem_lockGetDirect_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case -1911751599: return bem_containerGet_0();
case -1960297657: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -984771648: return bem_lockSetDirect_1(bevd_0);
case -1049172860: return bem_defined_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case 699484092: return bem_getAndClear_1(bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case -986861340: return bem_containerSetDirect_1(bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1110681556: return bem_addValue_1(bevd_0);
case -438924354: return bem_undefined_1(bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case -2096860194: return bem_lockSet_1(bevd_0);
case 652756: return bem_put_1(bevd_0);
case -1422015583: return bem_has_1(bevd_0);
case -414228749: return bem_new_1(bevd_0);
case -200725456: return bem_delete_1(bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -233371686: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case 1279255185: return bem_get_1(bevd_0);
case -1239399152: return bem_containerSet_1(bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case 600379066: return bem_putReturn_1(bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1613887137: return bem_put_2(bevd_0, bevd_1);
case -1441085506: return bem_putIfAbsent_2(bevd_0, bevd_1);
case -84641831: return bem_get_2(bevd_0, bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -590401222: return bem_putReturn_2(bevd_0, bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 903312197: return bem_delete_2(bevd_0, bevd_1);
case -1378408800: return bem_has_2(bevd_0, bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1766042564: return bem_getOrPut_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1401622544: return bem_put_3(bevd_0, bevd_1, bevd_2);
case 686400533: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
}
