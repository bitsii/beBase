namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_3_6_6_15_SystemThreadContainerLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_15_SystemThreadContainerLocker() { }
static BEC_3_6_6_15_SystemThreadContainerLocker() { }
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;

public static new BET_3_6_6_15_SystemThreadContainerLocker bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_container;
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_new_1(BEC_2_6_6_SystemObject beva__container) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
bevp_lock.bem_lock_0();
try  /* Line: 814 */ {
bevp_container = beva__container;
bevp_lock.bem_unlock_0();
} /* Line: 816 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 819 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 825 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_1(450107248, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 827 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 830 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_key2) {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 837 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_2(967294627, beva_key, beva_key2);
bevp_lock.bem_unlock_0();
} /* Line: 839 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 842 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 849 */ {
bevl_r = bevp_container.bemd_0(-1137918754);
bevp_lock.bem_unlock_0();
} /* Line: 851 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 854 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 861 */ {
bevl_r = bevp_container.bemd_1(-686021029, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 863 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 866 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 873 */ {
bevl_r = bevp_container.bemd_1(-686021029, beva_key);
bevp_container.bemd_1(921876651, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 876 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 879 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 886 */ {
bevl_r = bevp_container.bemd_2(-1555078150, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 888 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 891 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_addValue_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 898 */ {
bevp_container.bemd_1(1380835473, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 900 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 903 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 909 */ {
bevl_r = bevp_container.bemd_1(1815502422, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 911 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 914 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 921 */ {
bevp_container.bemd_1(1815502422, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 923 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 926 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_putReturn_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 932 */ {
bevl_r = bevp_container.bemd_2(-1566202298, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 934 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 937 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 944 */ {
bevp_container.bemd_2(-1566202298, beva_key, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 946 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 949 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_testAndPut_3(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_oldValue, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 955 */ {
bevl_rc = bevp_container.bemd_3(-1211626632, beva_key, beva_oldValue, beva_value);
bevp_lock.bem_unlock_0();
} /* Line: 957 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 960 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_0() {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 967 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_0(-1774925727);
bevp_lock.bem_unlock_0();
} /* Line: 969 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 972 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_rc = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 979 */ {
bevl_rc = (BEC_2_9_3_ContainerMap) bevp_container.bemd_1(239759479, beva_prefix);
bevp_lock.bem_unlock_0();
} /* Line: 981 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 984 */
return bevl_rc;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_putIfAbsent_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevl_didPut = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 991 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(450107248, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 992 */ {
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 993 */
 else  /* Line: 994 */ {
bevp_container.bemd_2(-1566202298, beva_key, beva_value);
bevl_didPut = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 996 */
bevp_lock.bem_unlock_0();
} /* Line: 998 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1001 */
return bevl_didPut;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getOrPut_2(BEC_2_6_6_SystemObject beva_key, BEC_2_6_6_SystemObject beva_value) {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_lock.bem_lock_0();
try  /* Line: 1008 */ {
bevt_0_tmpany_phold = bevp_container.bemd_1(450107248, beva_key);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 1009 */ {
bevl_result = bevp_container.bemd_1(-686021029, beva_key);
} /* Line: 1010 */
 else  /* Line: 1011 */ {
bevp_container.bemd_2(-1566202298, beva_key, beva_value);
bevl_result = beva_value;
} /* Line: 1013 */
bevp_lock.bem_unlock_0();
} /* Line: 1015 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1018 */
return bevl_result;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_put_3(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1025 */ {
bevp_container.bemd_3(921121855, beva_p, beva_k, beva_v);
bevp_lock.bem_unlock_0();
} /* Line: 1027 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1030 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_key) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1036 */ {
bevl_r = bevp_container.bemd_1(921876651, beva_key);
bevp_lock.bem_unlock_0();
} /* Line: 1038 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1041 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_2(BEC_2_6_6_SystemObject beva_p, BEC_2_6_6_SystemObject beva_k) {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1048 */ {
bevl_r = bevp_container.bemd_2(-1324787350, beva_p, beva_k);
bevp_lock.bem_unlock_0();
} /* Line: 1050 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1053 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1060 */ {
bevl_r = (BEC_2_4_3_MathInt) bevp_container.bemd_0(1095191709);
bevp_lock.bem_unlock_0();
} /* Line: 1062 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1065 */
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1072 */ {
bevl_r = (BEC_2_5_4_LogicBool) bevp_container.bemd_0(-753040386);
bevp_lock.bem_unlock_0();
} /* Line: 1074 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1077 */
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_copyContainer_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1084 */ {
bevl_r = bevp_container.bemd_0(254210050);
bevp_lock.bem_unlock_0();
} /* Line: 1086 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1089 */
return bevl_r;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_clear_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1096 */ {
bevp_container.bemd_0(1278413277);
bevp_lock.bem_unlock_0();
} /* Line: 1098 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1101 */
return this;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_close_0() {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try  /* Line: 1107 */ {
bevp_container.bemd_0(1888800014);
bevp_lock.bem_unlock_0();
} /* Line: 1109 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1112 */
return this;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_containerGet_0() {
return bevp_container;
} /*method end*/
public BEC_2_6_6_SystemObject bem_containerGetDirect_0() {
return bevp_container;
} /*method end*/
public virtual BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_15_SystemThreadContainerLocker bem_containerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_container = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {810, 813, 815, 816, 818, 819, 824, 826, 827, 829, 830, 832, 836, 838, 839, 841, 842, 844, 848, 850, 851, 853, 854, 856, 860, 862, 863, 865, 866, 868, 872, 874, 875, 876, 878, 879, 881, 885, 887, 888, 890, 891, 893, 897, 899, 900, 902, 903, 908, 910, 911, 913, 914, 916, 920, 922, 923, 925, 926, 931, 933, 934, 936, 937, 939, 943, 945, 946, 948, 949, 954, 956, 957, 959, 960, 962, 966, 968, 969, 971, 972, 974, 978, 980, 981, 983, 984, 986, 990, 992, 993, 995, 996, 998, 1000, 1001, 1003, 1007, 1009, 1010, 1012, 1013, 1015, 1017, 1018, 1020, 1024, 1026, 1027, 1029, 1030, 1035, 1037, 1038, 1040, 1041, 1043, 1047, 1049, 1050, 1052, 1053, 1055, 1059, 1061, 1062, 1064, 1065, 1067, 1071, 1073, 1074, 1076, 1077, 1079, 1083, 1085, 1086, 1088, 1089, 1091, 1095, 1097, 1098, 1100, 1101, 1106, 1108, 1109, 1111, 1112, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 29, 30, 37, 39, 40, 44, 45, 47, 52, 54, 55, 59, 60, 62, 67, 69, 70, 74, 75, 77, 82, 84, 85, 89, 90, 92, 97, 99, 100, 101, 105, 106, 108, 113, 115, 116, 120, 121, 123, 127, 129, 130, 134, 135, 142, 144, 145, 149, 150, 152, 156, 158, 159, 163, 164, 171, 173, 174, 178, 179, 181, 185, 187, 188, 192, 193, 200, 202, 203, 207, 208, 210, 215, 217, 218, 222, 223, 225, 230, 232, 233, 237, 238, 240, 246, 248, 250, 253, 254, 256, 260, 261, 263, 269, 271, 273, 276, 277, 279, 283, 284, 286, 290, 292, 293, 297, 298, 305, 307, 308, 312, 313, 315, 320, 322, 323, 327, 328, 330, 335, 337, 338, 342, 343, 345, 350, 352, 353, 357, 358, 360, 365, 367, 368, 372, 373, 375, 379, 381, 382, 386, 387, 393, 395, 396, 400, 401, 406, 409, 412, 416, 420, 423, 426, 430};
/* BEGIN LINEINFO 
assign 1 810 21
new 0 810 21
lock 0 813 22
assign 1 815 24
unlock 0 816 25
unlock 0 818 29
throw 1 819 30
lock 0 824 37
assign 1 826 39
has 1 826 39
unlock 0 827 40
unlock 0 829 44
throw 1 830 45
return 1 832 47
lock 0 836 52
assign 1 838 54
has 2 838 54
unlock 0 839 55
unlock 0 841 59
throw 1 842 60
return 1 844 62
lock 0 848 67
assign 1 850 69
get 0 850 69
unlock 0 851 70
unlock 0 853 74
throw 1 854 75
return 1 856 77
lock 0 860 82
assign 1 862 84
get 1 862 84
unlock 0 863 85
unlock 0 865 89
throw 1 866 90
return 1 868 92
lock 0 872 97
assign 1 874 99
get 1 874 99
delete 1 875 100
unlock 0 876 101
unlock 0 878 105
throw 1 879 106
return 1 881 108
lock 0 885 113
assign 1 887 115
get 2 887 115
unlock 0 888 116
unlock 0 890 120
throw 1 891 121
return 1 893 123
lock 0 897 127
addValue 1 899 129
unlock 0 900 130
unlock 0 902 134
throw 1 903 135
lock 0 908 142
assign 1 910 144
put 1 910 144
unlock 0 911 145
unlock 0 913 149
throw 1 914 150
return 1 916 152
lock 0 920 156
put 1 922 158
unlock 0 923 159
unlock 0 925 163
throw 1 926 164
lock 0 931 171
assign 1 933 173
put 2 933 173
unlock 0 934 174
unlock 0 936 178
throw 1 937 179
return 1 939 181
lock 0 943 185
put 2 945 187
unlock 0 946 188
unlock 0 948 192
throw 1 949 193
lock 0 954 200
assign 1 956 202
testAndPut 3 956 202
unlock 0 957 203
unlock 0 959 207
throw 1 960 208
return 1 962 210
lock 0 966 215
assign 1 968 217
getMap 0 968 217
unlock 0 969 218
unlock 0 971 222
throw 1 972 223
return 1 974 225
lock 0 978 230
assign 1 980 232
getMap 1 980 232
unlock 0 981 233
unlock 0 983 237
throw 1 984 238
return 1 986 240
lock 0 990 246
assign 1 992 248
has 1 992 248
assign 1 993 250
new 0 993 250
put 2 995 253
assign 1 996 254
new 0 996 254
unlock 0 998 256
unlock 0 1000 260
throw 1 1001 261
return 1 1003 263
lock 0 1007 269
assign 1 1009 271
has 1 1009 271
assign 1 1010 273
get 1 1010 273
put 2 1012 276
assign 1 1013 277
unlock 0 1015 279
unlock 0 1017 283
throw 1 1018 284
return 1 1020 286
lock 0 1024 290
put 3 1026 292
unlock 0 1027 293
unlock 0 1029 297
throw 1 1030 298
lock 0 1035 305
assign 1 1037 307
delete 1 1037 307
unlock 0 1038 308
unlock 0 1040 312
throw 1 1041 313
return 1 1043 315
lock 0 1047 320
assign 1 1049 322
delete 2 1049 322
unlock 0 1050 323
unlock 0 1052 327
throw 1 1053 328
return 1 1055 330
lock 0 1059 335
assign 1 1061 337
sizeGet 0 1061 337
unlock 0 1062 338
unlock 0 1064 342
throw 1 1065 343
return 1 1067 345
lock 0 1071 350
assign 1 1073 352
isEmptyGet 0 1073 352
unlock 0 1074 353
unlock 0 1076 357
throw 1 1077 358
return 1 1079 360
lock 0 1083 365
assign 1 1085 367
copy 0 1085 367
unlock 0 1086 368
unlock 0 1088 372
throw 1 1089 373
return 1 1091 375
lock 0 1095 379
clear 0 1097 381
unlock 0 1098 382
unlock 0 1100 386
throw 1 1101 387
lock 0 1106 393
close 0 1108 395
unlock 0 1109 396
unlock 0 1111 400
throw 1 1112 401
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1189966673: return bem_toAny_0();
case 1095191709: return bem_sizeGet_0();
case 1045959947: return bem_deserializeClassNameGet_0();
case -212029696: return bem_many_0();
case -1554789119: return bem_iteratorGet_0();
case 1039721337: return bem_fieldIteratorGet_0();
case -177474376: return bem_serializeToString_0();
case 1278413277: return bem_clear_0();
case 266181284: return bem_tagGet_0();
case -1948098255: return bem_classNameGet_0();
case 1888800014: return bem_close_0();
case -1146592162: return bem_copyContainer_0();
case 1657059163: return bem_fieldNamesGet_0();
case 2110316685: return bem_serializeContents_0();
case 1329517290: return bem_once_0();
case -174321978: return bem_serializationIteratorGet_0();
case -1342427184: return bem_lockGetDirect_0();
case -258580511: return bem_containerGet_0();
case 254210050: return bem_copy_0();
case 291596773: return bem_lockGet_0();
case -1519514970: return bem_print_0();
case -1602808735: return bem_containerGetDirect_0();
case -1641539908: return bem_toString_0();
case -1963952686: return bem_hashGet_0();
case -1886421584: return bem_new_0();
case -1841512138: return bem_sourceFileNameGet_0();
case -1137918754: return bem_get_0();
case -753040386: return bem_isEmptyGet_0();
case -1774925727: return bem_getMap_0();
case -1063147421: return bem_create_0();
case 900120920: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 921876651: return bem_delete_1(bevd_0);
case 789094035: return bem_def_1(bevd_0);
case -1745179387: return bem_new_1(bevd_0);
case 1581368506: return bem_otherClass_1(bevd_0);
case 670434524: return bem_copyTo_1(bevd_0);
case -1278204223: return bem_putReturn_1(bevd_0);
case -2101355929: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 239759479: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1688875848: return bem_sameType_1(bevd_0);
case 1380835473: return bem_addValue_1(bevd_0);
case -1038314311: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1837267423: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -222128188: return bem_lockSetDirect_1(bevd_0);
case 1337665439: return bem_otherType_1(bevd_0);
case 911117738: return bem_notEquals_1(bevd_0);
case -1929852577: return bem_containerSetDirect_1(bevd_0);
case 774083329: return bem_lockSet_1(bevd_0);
case 1780619641: return bem_getAndClear_1(bevd_0);
case -985468058: return bem_undefined_1(bevd_0);
case 1733222638: return bem_defined_1(bevd_0);
case 17112028: return bem_sameClass_1(bevd_0);
case -120618989: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -686021029: return bem_get_1(bevd_0);
case 506068861: return bem_equals_1(bevd_0);
case 1815502422: return bem_put_1(bevd_0);
case 963371488: return bem_containerSet_1(bevd_0);
case 450107248: return bem_has_1(bevd_0);
case -1751970442: return bem_undef_1(bevd_0);
case 1794882951: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -566430956: return bem_getOrPut_2(bevd_0, bevd_1);
case 925887327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1555078150: return bem_get_2(bevd_0, bevd_1);
case 1709627300: return bem_putReturn_2(bevd_0, bevd_1);
case -719350484: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1834730412: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1673554568: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 35608937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 967294627: return bem_has_2(bevd_0, bevd_1);
case 35788340: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1324787350: return bem_delete_2(bevd_0, bevd_1);
case 1172756878: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1566202298: return bem_put_2(bevd_0, bevd_1);
case 738987598: return bem_putIfAbsent_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 921121855: return bem_put_3(bevd_0, bevd_1, bevd_2);
case -1211626632: return bem_testAndPut_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(29, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_6_6_15_SystemThreadContainerLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_15_SystemThreadContainerLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst = (BEC_3_6_6_15_SystemThreadContainerLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_15_SystemThreadContainerLocker.bece_BEC_3_6_6_15_SystemThreadContainerLocker_bevs_type;
}
}
}
