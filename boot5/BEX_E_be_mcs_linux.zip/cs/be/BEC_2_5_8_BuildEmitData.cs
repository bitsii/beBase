namespace be {
/* IO:File: source/build/EmitData.be */
public sealed class BEC_2_5_8_BuildEmitData : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildEmitData() { }
static BEC_2_5_8_BuildEmitData() { }
private static byte[] becc_BEC_2_5_8_BuildEmitData_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61};
private static byte[] becc_BEC_2_5_8_BuildEmitData_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static new BEC_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_inst;

public static new BET_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_type;

public BEC_2_9_3_ContainerMap bevp_ptsp;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_9_3_ContainerMap bevp_nameEntries;
public BEC_2_9_3_ContainerMap bevp_classes;
public BEC_2_9_10_ContainerLinkedList bevp_parseOrderClassNames;
public BEC_2_9_3_ContainerMap bevp_justParsed;
public BEC_2_9_3_ContainerMap bevp_synClasses;
public BEC_2_9_3_ContainerMap bevp_midNames;
public BEC_2_9_3_ContainerMap bevp_usedBy;
public BEC_2_9_3_ContainerMap bevp_subClasses;
public BEC_2_9_3_ContainerSet bevp_propertyIndexes;
public BEC_2_9_3_ContainerSet bevp_methodIndexes;
public BEC_2_9_3_ContainerSet bevp_shouldEmit;
public BEC_2_9_3_ContainerMap bevp_aliased;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_ptsp = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_nameEntries = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_justParsed = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_synClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_midNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_usedBy = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_subClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_aliased = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addSynClass_2(BEC_2_4_6_TextString beva_npstr, BEC_2_5_8_BuildClassSyn beva_syn) {
BEC_2_4_6_TextString bevl_myname = null;
BEC_2_4_6_TextString bevl_s = null;
BEC_2_9_3_ContainerSet bevl_ub = null;
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_8_BuildNamePath bevt_1_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevp_synClasses.bem_put_2(beva_npstr, beva_syn);
bevt_1_ta_ph = beva_syn.bem_namepathGet_0();
bevl_myname = bevt_1_ta_ph.bem_toString_0();
bevt_2_ta_ph = beva_syn.bem_usesGet_0();
bevt_0_ta_loop = bevt_2_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 40*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 40*/ {
bevl_s = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(450495808);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_usedBy.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 42*/ {
bevl_ub = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_usedBy.bem_put_2(bevl_s, bevl_ub);
} /* Line: 44*/
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 46*/
 else /* Line: 40*/ {
break;
} /* Line: 40*/
} /* Line: 40*/
bevt_5_ta_ph = beva_syn.bem_superListGet_0();
bevl_iu = bevt_5_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 48*/ {
bevt_6_ta_ph = bevl_iu.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 48*/ {
bevt_7_ta_ph = bevl_iu.bemd_0(450495808);
bevl_s = (BEC_2_4_6_TextString) bevt_7_ta_ph.bemd_0(-1275325619);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_subClasses.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 51*/ {
bevl_ub = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_subClasses.bem_put_2(bevl_s, bevl_ub);
} /* Line: 53*/
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 55*/
 else /* Line: 48*/ {
break;
} /* Line: 48*/
} /* Line: 48*/
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addParsedClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
bevt_3_ta_ph = beva_node.bemd_0(1875047920);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1986294773);
bevt_1_ta_ph = bevp_classes.bem_has_1(bevt_2_ta_ph);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_5_ta_ph = beva_node.bemd_0(1875047920);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-1986294773);
bevp_parseOrderClassNames.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 61*/
bevt_7_ta_ph = beva_node.bemd_0(1875047920);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-1986294773);
bevp_classes.bem_put_2(bevt_6_ta_ph, beva_node);
bevt_9_ta_ph = beva_node.bemd_0(1875047920);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1986294773);
bevp_justParsed.bem_put_2(bevt_8_ta_ph, beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGet_0() {
return bevp_ptsp;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGetDirect_0() {
return bevp_ptsp;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGetDirect_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGetDirect_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGet_0() {
return bevp_nameEntries;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGetDirect_0() {
return bevp_nameEntries;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGet_0() {
return bevp_classes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGetDirect_0() {
return bevp_classes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGet_0() {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGetDirect_0() {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGet_0() {
return bevp_justParsed;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGetDirect_0() {
return bevp_justParsed;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGet_0() {
return bevp_synClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGetDirect_0() {
return bevp_synClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGet_0() {
return bevp_midNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGetDirect_0() {
return bevp_midNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGet_0() {
return bevp_usedBy;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGetDirect_0() {
return bevp_usedBy;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGet_0() {
return bevp_subClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGetDirect_0() {
return bevp_subClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGet_0() {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGetDirect_0() {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGet_0() {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGetDirect_0() {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGet_0() {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGetDirect_0() {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGetDirect_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 29, 30, 31, 32, 33, 38, 39, 39, 40, 40, 0, 40, 40, 41, 42, 42, 43, 44, 46, 48, 48, 48, 49, 49, 50, 51, 51, 52, 53, 55, 60, 60, 60, 60, 60, 61, 61, 61, 63, 63, 63, 64, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 59, 60, 61, 62, 63, 63, 66, 68, 69, 70, 75, 76, 77, 79, 85, 86, 89, 91, 92, 93, 94, 99, 100, 101, 103, 122, 123, 124, 125, 130, 131, 132, 133, 135, 136, 137, 138, 139, 140, 144, 147, 150, 154, 158, 161, 164, 168, 172, 175, 178, 182, 186, 189, 192, 196, 200, 203, 206, 210, 214, 217, 220, 224, 228, 231, 234, 238, 242, 245, 248, 252, 256, 259, 262, 266, 270, 273, 276, 280, 284, 287, 290, 294, 298, 301, 304, 308, 312, 315, 318, 322, 326, 329, 332, 336, 340, 343, 346, 350};
/* BEGIN LINEINFO 
assign 1 17 28
new 0 17 28
assign 1 18 29
new 0 18 29
assign 1 19 30
new 0 19 30
assign 1 20 31
new 0 20 31
assign 1 21 32
new 0 21 32
assign 1 22 33
new 0 22 33
assign 1 23 34
new 0 23 34
assign 1 24 35
new 0 24 35
assign 1 25 36
new 0 25 36
assign 1 27 37
new 0 27 37
assign 1 29 38
new 0 29 38
assign 1 30 39
new 0 30 39
assign 1 31 40
new 0 31 40
assign 1 32 41
new 0 32 41
assign 1 33 42
new 0 33 42
put 2 38 59
assign 1 39 60
namepathGet 0 39 60
assign 1 39 61
toString 0 39 61
assign 1 40 62
usesGet 0 40 62
assign 1 40 63
iteratorGet 0 0 63
assign 1 40 66
hasNextGet 0 40 66
assign 1 40 68
nextGet 0 40 68
assign 1 41 69
get 1 41 69
assign 1 42 70
undef 1 42 75
assign 1 43 76
new 0 43 76
put 2 44 77
put 1 46 79
assign 1 48 85
superListGet 0 48 85
assign 1 48 86
iteratorGet 0 48 86
assign 1 48 89
hasNextGet 0 48 89
assign 1 49 91
nextGet 0 49 91
assign 1 49 92
toString 0 49 92
assign 1 50 93
get 1 50 93
assign 1 51 94
undef 1 51 99
assign 1 52 100
new 0 52 100
put 2 53 101
put 1 55 103
assign 1 60 122
heldGet 0 60 122
assign 1 60 123
nameGet 0 60 123
assign 1 60 124
has 1 60 124
assign 1 60 125
not 0 60 130
assign 1 61 131
heldGet 0 61 131
assign 1 61 132
nameGet 0 61 132
addValue 1 61 133
assign 1 63 135
heldGet 0 63 135
assign 1 63 136
nameGet 0 63 136
put 2 63 137
assign 1 64 138
heldGet 0 64 138
assign 1 64 139
nameGet 0 64 139
put 2 64 140
return 1 0 144
return 1 0 147
assign 1 0 150
assign 1 0 154
return 1 0 158
return 1 0 161
assign 1 0 164
assign 1 0 168
return 1 0 172
return 1 0 175
assign 1 0 178
assign 1 0 182
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
return 1 0 214
return 1 0 217
assign 1 0 220
assign 1 0 224
return 1 0 228
return 1 0 231
assign 1 0 234
assign 1 0 238
return 1 0 242
return 1 0 245
assign 1 0 248
assign 1 0 252
return 1 0 256
return 1 0 259
assign 1 0 262
assign 1 0 266
return 1 0 270
return 1 0 273
assign 1 0 276
assign 1 0 280
return 1 0 284
return 1 0 287
assign 1 0 290
assign 1 0 294
return 1 0 298
return 1 0 301
assign 1 0 304
assign 1 0 308
return 1 0 312
return 1 0 315
assign 1 0 318
assign 1 0 322
return 1 0 326
return 1 0 329
assign 1 0 332
assign 1 0 336
return 1 0 340
return 1 0 343
assign 1 0 346
assign 1 0 350
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1304712984: return bem_classesGetDirect_0();
case 119461913: return bem_tagGet_0();
case 1203485475: return bem_aliasedGetDirect_0();
case 281444821: return bem_fieldIteratorGet_0();
case -678541085: return bem_classNameGet_0();
case 445837382: return bem_ptspGetDirect_0();
case 1796868815: return bem_methodIndexesGet_0();
case 195362666: return bem_midNamesGet_0();
case 1474651636: return bem_parseOrderClassNamesGetDirect_0();
case 1747409952: return bem_shouldEmitGetDirect_0();
case -1928566775: return bem_classesGet_0();
case 1886456053: return bem_justParsedGetDirect_0();
case -1754478112: return bem_print_0();
case -2017009146: return bem_new_0();
case 2092054957: return bem_aliasedGet_0();
case -567808682: return bem_subClassesGetDirect_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -1428575777: return bem_usedByGet_0();
case -1005119995: return bem_many_0();
case 676757762: return bem_subClassesGet_0();
case 106799633: return bem_nameEntriesGet_0();
case -1475550710: return bem_create_0();
case 275203189: return bem_foreignClassesGetDirect_0();
case -225870373: return bem_serializeToString_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 2045941275: return bem_iteratorGet_0();
case -842234446: return bem_midNamesGetDirect_0();
case -744679096: return bem_fieldNamesGet_0();
case -1486279572: return bem_serializeContents_0();
case -1129662905: return bem_nameEntriesGetDirect_0();
case -1275325619: return bem_toString_0();
case 1178462071: return bem_ptspGet_0();
case -1888780014: return bem_shouldEmitGet_0();
case 501088997: return bem_sourceFileNameGet_0();
case -639297756: return bem_toAny_0();
case -545556484: return bem_once_0();
case 2115111020: return bem_foreignClassesGet_0();
case 581036077: return bem_methodIndexesGetDirect_0();
case -1930556514: return bem_usedByGetDirect_0();
case 1077502001: return bem_parseOrderClassNamesGet_0();
case 1017642803: return bem_propertyIndexesGet_0();
case -1308718782: return bem_synClassesGet_0();
case 611702865: return bem_copy_0();
case 88903975: return bem_allNamesGet_0();
case 8302359: return bem_justParsedGet_0();
case -1954874467: return bem_allNamesGetDirect_0();
case 748789118: return bem_propertyIndexesGetDirect_0();
case -1583672278: return bem_echo_0();
case 1640442072: return bem_synClassesGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1672844285: return bem_nameEntriesSet_1(bevd_0);
case 1665893606: return bem_addParsedClass_1(bevd_0);
case 1764825877: return bem_foreignClassesSetDirect_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 895507336: return bem_synClassesSetDirect_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2128418651: return bem_justParsedSet_1(bevd_0);
case 823997153: return bem_aliasedSet_1(bevd_0);
case 1336915059: return bem_methodIndexesSetDirect_1(bevd_0);
case 1179988509: return bem_subClassesSetDirect_1(bevd_0);
case 1280077478: return bem_classesSet_1(bevd_0);
case -1974514324: return bem_synClassesSet_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 1858692123: return bem_propertyIndexesSet_1(bevd_0);
case -1179779186: return bem_parseOrderClassNamesSetDirect_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case 1442871183: return bem_nameEntriesSetDirect_1(bevd_0);
case 2125687597: return bem_propertyIndexesSetDirect_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case 1558903315: return bem_justParsedSetDirect_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 1702321602: return bem_allNamesSet_1(bevd_0);
case -641225693: return bem_shouldEmitSetDirect_1(bevd_0);
case -549729054: return bem_ptspSet_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case 1180633976: return bem_usedBySet_1(bevd_0);
case -1153367581: return bem_aliasedSetDirect_1(bevd_0);
case 1466434539: return bem_methodIndexesSet_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case -879779954: return bem_midNamesSet_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 1598118543: return bem_parseOrderClassNamesSet_1(bevd_0);
case -175366802: return bem_foreignClassesSet_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case 1813838148: return bem_ptspSetDirect_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case -1745571126: return bem_usedBySetDirect_1(bevd_0);
case 268479694: return bem_shouldEmitSet_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case 513383527: return bem_midNamesSetDirect_1(bevd_0);
case 1757880130: return bem_subClassesSet_1(bevd_0);
case -889000695: return bem_classesSetDirect_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1535284732: return bem_allNamesSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 28931413: return bem_addSynClass_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_8_BuildClassSyn) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildEmitData_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_8_BuildEmitData_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildEmitData();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst = (BEC_2_5_8_BuildEmitData) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_type;
}
}
}
