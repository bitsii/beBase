namespace be {
/* IO:File: source/build/EmitData.be */
public sealed class BEC_2_5_8_BuildEmitData : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildEmitData() { }
static BEC_2_5_8_BuildEmitData() { }
private static byte[] becc_BEC_2_5_8_BuildEmitData_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61};
private static byte[] becc_BEC_2_5_8_BuildEmitData_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static new BEC_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_inst;

public static new BET_2_5_8_BuildEmitData bece_BEC_2_5_8_BuildEmitData_bevs_type;

public BEC_2_9_3_ContainerMap bevp_ptsp;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_9_3_ContainerMap bevp_nameEntries;
public BEC_2_9_3_ContainerMap bevp_classes;
public BEC_2_9_10_ContainerLinkedList bevp_parseOrderClassNames;
public BEC_2_9_3_ContainerMap bevp_justParsed;
public BEC_2_9_3_ContainerMap bevp_synClasses;
public BEC_2_9_3_ContainerMap bevp_midNames;
public BEC_2_9_3_ContainerMap bevp_usedBy;
public BEC_2_9_3_ContainerMap bevp_subClasses;
public BEC_2_9_3_ContainerSet bevp_propertyIndexes;
public BEC_2_9_3_ContainerSet bevp_methodIndexes;
public BEC_2_9_3_ContainerSet bevp_shouldEmit;
public BEC_2_9_3_ContainerMap bevp_aliased;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_ptsp = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_nameEntries = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_justParsed = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_synClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_midNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_usedBy = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_subClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_aliased = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addSynClass_2(BEC_2_4_6_TextString beva_npstr, BEC_2_5_8_BuildClassSyn beva_syn) {
BEC_2_4_6_TextString bevl_myname = null;
BEC_2_4_6_TextString bevl_s = null;
BEC_2_9_3_ContainerSet bevl_ub = null;
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_8_BuildNamePath bevt_1_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevp_synClasses.bem_put_2(beva_npstr, beva_syn);
bevt_1_tmpany_phold = beva_syn.bem_namepathGet_0();
bevl_myname = bevt_1_tmpany_phold.bem_toString_0();
bevt_2_tmpany_phold = beva_syn.bem_usesGet_0();
bevt_0_tmpany_loop = bevt_2_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 40 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(856020715);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 40 */ {
bevl_s = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-115978313);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_usedBy.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevl_ub = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_usedBy.bem_put_2(bevl_s, bevl_ub);
} /* Line: 44 */
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 46 */
 else  /* Line: 40 */ {
break;
} /* Line: 40 */
} /* Line: 40 */
bevt_5_tmpany_phold = beva_syn.bem_superListGet_0();
bevl_iu = bevt_5_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 48 */ {
bevt_6_tmpany_phold = bevl_iu.bemd_0(856020715);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_7_tmpany_phold = bevl_iu.bemd_0(-115978313);
bevl_s = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bemd_0(-1032171260);
bevl_ub = (BEC_2_9_3_ContainerSet) bevp_subClasses.bem_get_1(bevl_s);
if (bevl_ub == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 51 */ {
bevl_ub = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_subClasses.bem_put_2(bevl_s, bevl_ub);
} /* Line: 53 */
bevl_ub.bem_put_1(bevl_myname);
} /* Line: 55 */
 else  /* Line: 48 */ {
break;
} /* Line: 48 */
} /* Line: 48 */
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_addParsedClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bemd_0(-1696422828);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-64622528);
bevt_1_tmpany_phold = bevp_classes.bem_has_1(bevt_2_tmpany_phold);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_5_tmpany_phold = beva_node.bemd_0(-1696422828);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-64622528);
bevp_parseOrderClassNames.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 61 */
bevt_7_tmpany_phold = beva_node.bemd_0(-1696422828);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-64622528);
bevp_classes.bem_put_2(bevt_6_tmpany_phold, beva_node);
bevt_9_tmpany_phold = beva_node.bemd_0(-1696422828);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-64622528);
bevp_justParsed.bem_put_2(bevt_8_tmpany_phold, beva_node);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGet_0() {
return bevp_ptsp;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptspGetDirect_0() {
return bevp_ptsp;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_ptspSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ptsp = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGetDirect_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_allNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGetDirect_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_foreignClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGet_0() {
return bevp_nameEntries;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_nameEntriesGetDirect_0() {
return bevp_nameEntries;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_nameEntriesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameEntries = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGet_0() {
return bevp_classes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classesGetDirect_0() {
return bevp_classes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_classesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGet_0() {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_parseOrderClassNamesGetDirect_0() {
return bevp_parseOrderClassNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_parseOrderClassNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseOrderClassNames = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGet_0() {
return bevp_justParsed;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_justParsedGetDirect_0() {
return bevp_justParsed;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_justParsedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_justParsed = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGet_0() {
return bevp_synClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_synClassesGetDirect_0() {
return bevp_synClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_synClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGet_0() {
return bevp_midNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_midNamesGetDirect_0() {
return bevp_midNames;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_midNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_midNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGet_0() {
return bevp_usedBy;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_usedByGetDirect_0() {
return bevp_usedBy;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_usedBySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedBy = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGet_0() {
return bevp_subClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_subClassesGetDirect_0() {
return bevp_subClasses;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_subClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_subClasses = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGet_0() {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_propertyIndexesGetDirect_0() {
return bevp_propertyIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_propertyIndexesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propertyIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGet_0() {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_methodIndexesGetDirect_0() {
return bevp_methodIndexes;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_methodIndexesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodIndexes = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGet_0() {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_shouldEmitGetDirect_0() {
return bevp_shouldEmit;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_shouldEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shouldEmit = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGet_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_aliasedGetDirect_0() {
return bevp_aliased;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_aliasedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_aliased = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 29, 30, 31, 32, 33, 38, 39, 39, 40, 40, 0, 40, 40, 41, 42, 42, 43, 44, 46, 48, 48, 48, 49, 49, 50, 51, 51, 52, 53, 55, 60, 60, 60, 60, 60, 61, 61, 61, 63, 63, 63, 64, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 59, 60, 61, 62, 63, 63, 66, 68, 69, 70, 75, 76, 77, 79, 85, 86, 89, 91, 92, 93, 94, 99, 100, 101, 103, 122, 123, 124, 125, 130, 131, 132, 133, 135, 136, 137, 138, 139, 140, 144, 147, 150, 154, 158, 161, 164, 168, 172, 175, 178, 182, 186, 189, 192, 196, 200, 203, 206, 210, 214, 217, 220, 224, 228, 231, 234, 238, 242, 245, 248, 252, 256, 259, 262, 266, 270, 273, 276, 280, 284, 287, 290, 294, 298, 301, 304, 308, 312, 315, 318, 322, 326, 329, 332, 336, 340, 343, 346, 350};
/* BEGIN LINEINFO 
assign 1 17 28
new 0 17 28
assign 1 18 29
new 0 18 29
assign 1 19 30
new 0 19 30
assign 1 20 31
new 0 20 31
assign 1 21 32
new 0 21 32
assign 1 22 33
new 0 22 33
assign 1 23 34
new 0 23 34
assign 1 24 35
new 0 24 35
assign 1 25 36
new 0 25 36
assign 1 27 37
new 0 27 37
assign 1 29 38
new 0 29 38
assign 1 30 39
new 0 30 39
assign 1 31 40
new 0 31 40
assign 1 32 41
new 0 32 41
assign 1 33 42
new 0 33 42
put 2 38 59
assign 1 39 60
namepathGet 0 39 60
assign 1 39 61
toString 0 39 61
assign 1 40 62
usesGet 0 40 62
assign 1 40 63
iteratorGet 0 0 63
assign 1 40 66
hasNextGet 0 40 66
assign 1 40 68
nextGet 0 40 68
assign 1 41 69
get 1 41 69
assign 1 42 70
undef 1 42 75
assign 1 43 76
new 0 43 76
put 2 44 77
put 1 46 79
assign 1 48 85
superListGet 0 48 85
assign 1 48 86
iteratorGet 0 48 86
assign 1 48 89
hasNextGet 0 48 89
assign 1 49 91
nextGet 0 49 91
assign 1 49 92
toString 0 49 92
assign 1 50 93
get 1 50 93
assign 1 51 94
undef 1 51 99
assign 1 52 100
new 0 52 100
put 2 53 101
put 1 55 103
assign 1 60 122
heldGet 0 60 122
assign 1 60 123
nameGet 0 60 123
assign 1 60 124
has 1 60 124
assign 1 60 125
not 0 60 130
assign 1 61 131
heldGet 0 61 131
assign 1 61 132
nameGet 0 61 132
addValue 1 61 133
assign 1 63 135
heldGet 0 63 135
assign 1 63 136
nameGet 0 63 136
put 2 63 137
assign 1 64 138
heldGet 0 64 138
assign 1 64 139
nameGet 0 64 139
put 2 64 140
return 1 0 144
return 1 0 147
assign 1 0 150
assign 1 0 154
return 1 0 158
return 1 0 161
assign 1 0 164
assign 1 0 168
return 1 0 172
return 1 0 175
assign 1 0 178
assign 1 0 182
return 1 0 186
return 1 0 189
assign 1 0 192
assign 1 0 196
return 1 0 200
return 1 0 203
assign 1 0 206
assign 1 0 210
return 1 0 214
return 1 0 217
assign 1 0 220
assign 1 0 224
return 1 0 228
return 1 0 231
assign 1 0 234
assign 1 0 238
return 1 0 242
return 1 0 245
assign 1 0 248
assign 1 0 252
return 1 0 256
return 1 0 259
assign 1 0 262
assign 1 0 266
return 1 0 270
return 1 0 273
assign 1 0 276
assign 1 0 280
return 1 0 284
return 1 0 287
assign 1 0 290
assign 1 0 294
return 1 0 298
return 1 0 301
assign 1 0 304
assign 1 0 308
return 1 0 312
return 1 0 315
assign 1 0 318
assign 1 0 322
return 1 0 326
return 1 0 329
assign 1 0 332
assign 1 0 336
return 1 0 340
return 1 0 343
assign 1 0 346
assign 1 0 350
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1032171260: return bem_toString_0();
case 810445103: return bem_midNamesGetDirect_0();
case 1863191171: return bem_propertyIndexesGetDirect_0();
case 1836397184: return bem_methodIndexesGetDirect_0();
case 2051864076: return bem_allNamesGetDirect_0();
case 1071367189: return bem_methodIndexesGet_0();
case -1630003136: return bem_classesGet_0();
case 1764716287: return bem_once_0();
case 1945143392: return bem_fieldIteratorGet_0();
case -889606886: return bem_aliasedGet_0();
case -1610742202: return bem_create_0();
case 2098483713: return bem_copy_0();
case -1126084796: return bem_justParsedGetDirect_0();
case -1509690672: return bem_iteratorGet_0();
case 587446952: return bem_propertyIndexesGet_0();
case 281585293: return bem_toAny_0();
case 1623928634: return bem_midNamesGet_0();
case 237331770: return bem_nameEntriesGetDirect_0();
case -8567524: return bem_usedByGet_0();
case 1929688279: return bem_classNameGet_0();
case 2098994482: return bem_hashGet_0();
case -1058456741: return bem_print_0();
case 1050722055: return bem_synClassesGetDirect_0();
case 334648449: return bem_serializationIteratorGet_0();
case -249585493: return bem_shouldEmitGet_0();
case 447601340: return bem_usedByGetDirect_0();
case 812544411: return bem_echo_0();
case -1920628056: return bem_parseOrderClassNamesGet_0();
case -206017228: return bem_subClassesGet_0();
case -721323449: return bem_nameEntriesGet_0();
case 1663734561: return bem_subClassesGetDirect_0();
case 705622040: return bem_sourceFileNameGet_0();
case 538389441: return bem_serializeToString_0();
case 467596666: return bem_synClassesGet_0();
case 1669654091: return bem_many_0();
case -376699294: return bem_aliasedGetDirect_0();
case -663929751: return bem_foreignClassesGet_0();
case -98046751: return bem_tagGet_0();
case 1365986327: return bem_ptspGet_0();
case -1006908471: return bem_serializeContents_0();
case 1644674125: return bem_ptspGetDirect_0();
case 329044611: return bem_fieldNamesGet_0();
case 1220468660: return bem_allNamesGet_0();
case 1322537572: return bem_classesGetDirect_0();
case -253615410: return bem_foreignClassesGetDirect_0();
case 1163805126: return bem_new_0();
case -532904641: return bem_justParsedGet_0();
case 462191240: return bem_parseOrderClassNamesGetDirect_0();
case 1755062215: return bem_shouldEmitGetDirect_0();
case -1101624703: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1863898392: return bem_equals_1(bevd_0);
case 220285540: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -566926086: return bem_justParsedSet_1(bevd_0);
case -1238397258: return bem_nameEntriesSetDirect_1(bevd_0);
case 99127990: return bem_otherType_1(bevd_0);
case -1446306055: return bem_otherClass_1(bevd_0);
case -2126379200: return bem_synClassesSet_1(bevd_0);
case -1215624498: return bem_classesSetDirect_1(bevd_0);
case 1433641252: return bem_justParsedSetDirect_1(bevd_0);
case -1856433018: return bem_usedBySet_1(bevd_0);
case -158866773: return bem_nameEntriesSet_1(bevd_0);
case 1960470343: return bem_shouldEmitSetDirect_1(bevd_0);
case 951340271: return bem_addParsedClass_1(bevd_0);
case 613414930: return bem_def_1(bevd_0);
case 1300185187: return bem_undefined_1(bevd_0);
case 714503183: return bem_sameObject_1(bevd_0);
case -527029618: return bem_parseOrderClassNamesSetDirect_1(bevd_0);
case -1685877365: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -266774427: return bem_aliasedSetDirect_1(bevd_0);
case -833799554: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1524968669: return bem_sameClass_1(bevd_0);
case 1442217814: return bem_methodIndexesSet_1(bevd_0);
case -1776959106: return bem_notEquals_1(bevd_0);
case 1837978646: return bem_sameType_1(bevd_0);
case 1545114264: return bem_propertyIndexesSetDirect_1(bevd_0);
case -1776457256: return bem_ptspSet_1(bevd_0);
case 259633292: return bem_subClassesSet_1(bevd_0);
case 385170871: return bem_foreignClassesSetDirect_1(bevd_0);
case -1207491940: return bem_undef_1(bevd_0);
case -336228236: return bem_shouldEmitSet_1(bevd_0);
case -1774258469: return bem_parseOrderClassNamesSet_1(bevd_0);
case 1057431586: return bem_midNamesSet_1(bevd_0);
case 2108235391: return bem_defined_1(bevd_0);
case -919854875: return bem_ptspSetDirect_1(bevd_0);
case -1154517928: return bem_propertyIndexesSet_1(bevd_0);
case -10509890: return bem_aliasedSet_1(bevd_0);
case 1799570867: return bem_synClassesSetDirect_1(bevd_0);
case 1178647798: return bem_subClassesSetDirect_1(bevd_0);
case 1538927011: return bem_copyTo_1(bevd_0);
case 1513660267: return bem_allNamesSetDirect_1(bevd_0);
case -481554631: return bem_foreignClassesSet_1(bevd_0);
case 1239840684: return bem_allNamesSet_1(bevd_0);
case -1652764606: return bem_midNamesSetDirect_1(bevd_0);
case 1457761560: return bem_methodIndexesSetDirect_1(bevd_0);
case -1109286107: return bem_classesSet_1(bevd_0);
case -851186895: return bem_usedBySetDirect_1(bevd_0);
case 1867834674: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -903966108: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1997741826: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 937271141: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -906378356: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -319646499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 395811446: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1587977520: return bem_addSynClass_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_8_BuildClassSyn) bevd_1);
case -1670352859: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildEmitData_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_8_BuildEmitData_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildEmitData();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst = (BEC_2_5_8_BuildEmitData) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildEmitData.bece_BEC_2_5_8_BuildEmitData_bevs_type;
}
}
}
