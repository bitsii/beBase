namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_8_DbDirStore : BEC_2_6_6_SystemObject {
public BEC_2_2_8_DbDirStore() { }
static BEC_2_2_8_DbDirStore() { }
private static byte[] becc_BEC_2_2_8_DbDirStore_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65};
private static byte[] becc_BEC_2_2_8_DbDirStore_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_0 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_0, 0));
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_1 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_1, 0));
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_2 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_2, 0));
private static byte[] bece_BEC_2_2_8_DbDirStore_bels_3 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_8_DbDirStore_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_2_8_DbDirStore_bels_3, 0));
public static new BEC_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_inst;

public static new BET_2_2_8_DbDirStore bece_BEC_2_2_8_DbDirStore_bevs_type;

public BEC_2_6_10_SystemSerializer bevp_ser;
public BEC_3_2_4_4_IOFilePath bevp_storageDir;
public BEC_2_6_6_SystemObject bevp_keyEncoder;
public virtual BEC_2_2_8_DbDirStore bem_new_2(BEC_2_4_6_TextString beva_storageDir, BEC_2_6_6_SystemObject beva__keyEncoder) {
bem_new_1(beva_storageDir);
bevp_keyEncoder = beva__keyEncoder;
return this;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_new_1(BEC_2_4_6_TextString beva_storageDir) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_storageDir);
bem_pathNew_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_pathNew_1(BEC_3_2_4_4_IOFilePath beva__storageDir) {
bevp_ser = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevp_storageDir = beva__storageDir;
bevp_keyEncoder = null;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getStoreId_1(BEC_2_4_6_TextString beva_id) {
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_keyEncoder == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevl_storeId = (BEC_2_4_6_TextString) bevp_keyEncoder.bemd_1(-941124201, beva_id);
} /* Line: 374 */
 else  /* Line: 375 */ {
bevl_storeId = beva_id;
} /* Line: 376 */
return bevl_storeId;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_getPath_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_4_6_TextString bevl_storeId = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_0;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 383 */
 else  /* Line: 383 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 383 */ {
bevt_6_tmpany_phold = bevp_storageDir.bem_fileGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_7_tmpany_phold = bevp_storageDir.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 385 */
bevl_storeId = (BEC_2_4_6_TextString) bem_getStoreId_1(beva_id);
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_storageDir.bem_copy_0();
bevl_p = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevl_storeId);
} /* Line: 388 */
return bevl_p;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_1;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 394 */
 else  /* Line: 394 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 394 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_writerGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_0(-103166746);
bevp_ser.bem_serialize_2(beva_object, bevt_5_tmpany_phold);
bevt_9_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevt_8_tmpany_phold.bemd_0(-1592861100);
} /* Line: 398 */
} /* Line: 396 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_6_6_SystemObject bevl_object = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_12_tmpany_phold = null;
if (beva_id == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_4_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_2;
bevt_3_tmpany_phold = beva_id.bem_notEquals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 404 */
 else  /* Line: 404 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 404 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_existsGet_0();
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 406 */
 else  /* Line: 406 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 406 */ {
bevt_10_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_readerGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-103166746);
bevl_object = bevp_ser.bem_deserialize_1(bevt_8_tmpany_phold);
bevt_12_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_readerGet_0();
bevt_11_tmpany_phold.bemd_0(-1592861100);
return bevl_object;
} /* Line: 409 */
} /* Line: 406 */
return null;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 416 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_8_DbDirStore_bevo_3;
bevt_2_tmpany_phold = beva_id.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 416 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 416 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 416 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 416 */
bevl_p = bem_getPath_1(beva_id);
bevt_6_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_existsGet_0();
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 418 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 419 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_delete_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_2_4_IOFile bevt_0_tmpany_phold = null;
bevl_p = bem_getPath_1(beva_id);
bevt_0_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_0_tmpany_phold.bem_delete_0();
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemSerializer bem_serGet_0() {
return bevp_ser;
} /*method end*/
public BEC_2_6_10_SystemSerializer bem_serGetDirect_0() {
return bevp_ser;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_serSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_serSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ser = (BEC_2_6_10_SystemSerializer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_storageDirGet_0() {
return bevp_storageDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_storageDirGetDirect_0() {
return bevp_storageDir;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_storageDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_storageDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_storageDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_keyEncoderGet_0() {
return bevp_keyEncoder;
} /*method end*/
public BEC_2_6_6_SystemObject bem_keyEncoderGetDirect_0() {
return bevp_keyEncoder;
} /*method end*/
public virtual BEC_2_2_8_DbDirStore bem_keyEncoderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_keyEncoder = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_8_DbDirStore bem_keyEncoderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_keyEncoder = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {355, 356, 360, 360, 365, 366, 367, 373, 373, 374, 376, 378, 383, 383, 383, 383, 0, 0, 0, 384, 384, 384, 384, 385, 385, 387, 388, 388, 390, 394, 394, 394, 394, 0, 0, 0, 395, 396, 396, 397, 397, 397, 397, 398, 398, 398, 404, 404, 404, 404, 0, 0, 0, 405, 406, 406, 406, 406, 0, 0, 0, 407, 407, 407, 407, 408, 408, 408, 409, 412, 416, 416, 0, 416, 416, 0, 0, 416, 416, 417, 418, 418, 419, 419, 421, 421, 425, 426, 426, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 30, 31, 35, 36, 37, 43, 48, 49, 52, 54, 68, 73, 74, 75, 77, 80, 84, 87, 88, 89, 94, 95, 96, 98, 99, 100, 102, 116, 121, 122, 123, 125, 128, 132, 135, 136, 141, 142, 143, 144, 145, 146, 147, 148, 169, 174, 175, 176, 178, 181, 185, 188, 189, 194, 195, 196, 198, 201, 205, 208, 209, 210, 211, 212, 213, 214, 215, 218, 231, 236, 237, 240, 241, 243, 246, 250, 251, 253, 254, 255, 257, 258, 260, 261, 266, 267, 268, 272, 275, 278, 282, 286, 289, 292, 296, 300, 303, 306, 310};
/* BEGIN LINEINFO 
new 1 355 24
assign 1 356 25
assign 1 360 30
apNew 1 360 30
pathNew 1 360 31
assign 1 365 35
new 0 365 35
assign 1 366 36
assign 1 367 37
assign 1 373 43
def 1 373 48
assign 1 374 49
encode 1 374 49
assign 1 376 52
return 1 378 54
assign 1 383 68
def 1 383 73
assign 1 383 74
new 0 383 74
assign 1 383 75
notEquals 1 383 75
assign 1 0 77
assign 1 0 80
assign 1 0 84
assign 1 384 87
fileGet 0 384 87
assign 1 384 88
existsGet 0 384 88
assign 1 384 89
not 0 384 94
assign 1 385 95
fileGet 0 385 95
makeDirs 0 385 96
assign 1 387 98
getStoreId 1 387 98
assign 1 388 99
copy 0 388 99
assign 1 388 100
addStep 1 388 100
return 1 390 102
assign 1 394 116
def 1 394 121
assign 1 394 122
new 0 394 122
assign 1 394 123
notEquals 1 394 123
assign 1 0 125
assign 1 0 128
assign 1 0 132
assign 1 395 135
getPath 1 395 135
assign 1 396 136
def 1 396 141
assign 1 397 142
fileGet 0 397 142
assign 1 397 143
writerGet 0 397 143
assign 1 397 144
open 0 397 144
serialize 2 397 145
assign 1 398 146
fileGet 0 398 146
assign 1 398 147
writerGet 0 398 147
close 0 398 148
assign 1 404 169
def 1 404 174
assign 1 404 175
new 0 404 175
assign 1 404 176
notEquals 1 404 176
assign 1 0 178
assign 1 0 181
assign 1 0 185
assign 1 405 188
getPath 1 405 188
assign 1 406 189
def 1 406 194
assign 1 406 195
fileGet 0 406 195
assign 1 406 196
existsGet 0 406 196
assign 1 0 198
assign 1 0 201
assign 1 0 205
assign 1 407 208
fileGet 0 407 208
assign 1 407 209
readerGet 0 407 209
assign 1 407 210
open 0 407 210
assign 1 407 211
deserialize 1 407 211
assign 1 408 212
fileGet 0 408 212
assign 1 408 213
readerGet 0 408 213
close 0 408 214
return 1 409 215
return 1 412 218
assign 1 416 231
undef 1 416 236
assign 1 0 237
assign 1 416 240
new 0 416 240
assign 1 416 241
equals 1 416 241
assign 1 0 243
assign 1 0 246
assign 1 416 250
new 0 416 250
return 1 416 251
assign 1 417 253
getPath 1 417 253
assign 1 418 254
fileGet 0 418 254
assign 1 418 255
existsGet 0 418 255
assign 1 419 257
new 0 419 257
return 1 419 258
assign 1 421 260
new 0 421 260
return 1 421 261
assign 1 425 266
getPath 1 425 266
assign 1 426 267
fileGet 0 426 267
delete 0 426 268
return 1 0 272
return 1 0 275
assign 1 0 278
assign 1 0 282
return 1 0 286
return 1 0 289
assign 1 0 292
assign 1 0 296
return 1 0 300
return 1 0 303
assign 1 0 306
assign 1 0 310
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1074341902: return bem_print_0();
case 1222203422: return bem_serGetDirect_0();
case 80244442: return bem_toString_0();
case -1194289304: return bem_serializeToString_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 1554674943: return bem_storageDirGetDirect_0();
case 1014225644: return bem_echo_0();
case -1882364243: return bem_many_0();
case -628560707: return bem_toAny_0();
case -1744506517: return bem_keyEncoderGetDirect_0();
case -753894116: return bem_new_0();
case -2123848647: return bem_fieldNamesGet_0();
case -1138072028: return bem_tagGet_0();
case -1771232590: return bem_storageDirGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -2131387379: return bem_iteratorGet_0();
case 844225351: return bem_classNameGet_0();
case 1297175099: return bem_fieldIteratorGet_0();
case -1625648722: return bem_once_0();
case -798599052: return bem_keyEncoderGet_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 770834928: return bem_serializeContents_0();
case 82257638: return bem_serGet_0();
case -1253246070: return bem_create_0();
case -2083934905: return bem_copy_0();
case 1165329653: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case 322534726: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -1447808389: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case -1178555368: return bem_serSetDirect_1(bevd_0);
case -888522106: return bem_storageDirSetDirect_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case -1219892063: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case 1899981599: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case -636442813: return bem_def_1(bevd_0);
case -734328040: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case 1869433896: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1581901572: return bem_keyEncoderSet_1(bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case 1326486711: return bem_keyEncoderSetDirect_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case 1951870796: return bem_serSet_1(bevd_0);
case -475116748: return bem_storageDirSet_1(bevd_0);
case 1904730484: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1551438146: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 234485977: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_2_8_DbDirStore_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_8_DbDirStore_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_8_DbDirStore();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst = (BEC_2_2_8_DbDirStore) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_8_DbDirStore.bece_BEC_2_2_8_DbDirStore_bevs_type;
}
}
}
