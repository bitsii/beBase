namespace be {
/* IO:File: source/build/Pass11.be */
public sealed class BEC_3_5_5_6_BuildVisitPass11 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass11() { }
static BEC_3_5_5_6_BuildVisitPass11() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass11_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x31};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass11_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_2 = {0x74,0x68,0x72,0x6F,0x77};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitPass11_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_3 = {0x54,0x68,0x69,0x73,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x75,0x73,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x65,0x78,0x61,0x63,0x74,0x6C,0x79,0x20,0x6F,0x6E,0x65,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x2C,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitPass11_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitPass11_bels_3, 46));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_4 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_5 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_6 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_7 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_8 = {0x43,0x61,0x6C,0x6C,0x20,0x6E,0x6F,0x74,0x20,0x69,0x6E,0x20,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x70,0x6F,0x73,0x69,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_9 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_10 = {0x70,0x68,0x6F,0x6C,0x64};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_11 = {0x61,0x73,0x73,0x69,0x67,0x6E};
public static new BEC_3_5_5_6_BuildVisitPass11 bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst;

public static new BET_3_5_5_6_BuildVisitPass11 bece_BEC_3_5_5_6_BuildVisitPass11_bevs_type;

public BEC_2_5_4_BuildNode bevp_inMtd;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_fnode = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_5_4_BuildNode bevl_inode = null;
BEC_2_5_3_BuildVar bevl_ts = null;
BEC_2_5_4_BuildNode bevl_nsc = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_unwind = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_lastStep = null;
BEC_2_6_6_SystemObject bevl_pholdv = null;
BEC_2_6_6_SystemObject bevl_phold = null;
BEC_2_6_6_SystemObject bevl_prc = null;
BEC_2_6_6_SystemObject bevl_prcc = null;
BEC_2_6_6_SystemObject bevl_phold2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_108_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_109_tmpany_phold = null;
bevt_8_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_9_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
if (bevt_8_tmpany_phold.bevi_int == bevt_9_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 23 */ {
bevl_fnode = null;
bevt_14_tmpany_phold = beva_node.bem_containedGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_firstGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1663291856);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-2029152359);
if (bevt_11_tmpany_phold == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevl_fnode = beva_node.bem_nextDescendGet_0();
} /* Line: 26 */
bevt_17_tmpany_phold = beva_node.bem_containedGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_firstGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1663291856);
bevl_it = bevt_15_tmpany_phold.bemd_0(1714059697);
while (true)
 /* Line: 28 */ {
bevt_18_tmpany_phold = bevl_it.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 28 */ {
bevl_inode = (BEC_2_5_4_BuildNode) bevl_it.bemd_0(1538356292);
if (bevl_fnode == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevl_fnode = bevl_inode;
} /* Line: 31 */
beva_node.bem_beforeInsert_1(bevl_inode);
} /* Line: 33 */
 else  /* Line: 28 */ {
break;
} /* Line: 28 */
} /* Line: 28 */
beva_node.bem_delete_0();
return bevl_fnode;
} /* Line: 36 */
bevt_21_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_22_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_21_tmpany_phold.bevi_int == bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 38 */ {
bevp_inMtd = beva_node;
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(1253772551);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_0));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(2122005988, bevt_26_tmpany_phold);
bevl_ts = (BEC_2_5_3_BuildVar) bevt_23_tmpany_phold.bemd_0(-1714917982);
bevt_27_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_ts.bem_isTypedSet_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_node.bem_classGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-1714917982);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(83257762);
bevl_ts.bem_namepathSet_1(bevt_28_tmpany_phold);
} /* Line: 42 */
bevt_32_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_36_tmpany_phold = beva_node.bem_heldGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_0(510108416);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_1));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1560831110, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_40_tmpany_phold = beva_node.bem_heldGet_0();
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_0(510108416);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_6_BuildVisitPass11_bels_2));
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_1(1560831110, bevt_41_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_38_tmpany_phold).bevi_bool) /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 49 */ {
bevt_44_tmpany_phold = beva_node.bem_containedGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_lengthGet_0();
bevt_45_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass11_bevo_0;
if (bevt_43_tmpany_phold.bevi_int > bevt_45_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 49 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 49 */
 else  /* Line: 49 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 49 */ {
bevt_48_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass11_bevo_1;
bevt_51_tmpany_phold = beva_node.bem_containedGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_lengthGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_toString_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_47_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_46_tmpany_phold);
} /* Line: 50 */
bevt_54_tmpany_phold = beva_node.bem_heldGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_0(510108416);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_4));
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(1560831110, bevt_55_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_52_tmpany_phold).bevi_bool) /* Line: 52 */ {
bevt_58_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(-1322255896);
if (bevt_57_tmpany_phold == null) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_61_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(-1322255896);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-1785422617);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 53 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 53 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 53 */
 else  /* Line: 53 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 53 */ {
bevl_nsc = beva_node.bem_firstGet_0();
if (bevl_nsc == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_64_tmpany_phold = bevl_nsc.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
 else  /* Line: 61 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 61 */ {
bevt_68_tmpany_phold = bevl_nsc.bem_heldGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(510108416);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_5));
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_1(1560831110, bevt_69_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_66_tmpany_phold).bevi_bool) /* Line: 61 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 61 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 61 */
 else  /* Line: 61 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 61 */ {
} /* Line: 61 */
 else  /* Line: 63 */ {
bevt_70_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_70_tmpany_phold.bemd_1(1600876835, null);
} /* Line: 65 */
} /* Line: 61 */
} /* Line: 53 */
bevt_73_tmpany_phold = beva_node.bem_heldGet_0();
bevt_72_tmpany_phold = bevt_73_tmpany_phold.bemd_0(956044399);
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(695021271);
if (((BEC_2_5_4_LogicBool) bevt_71_tmpany_phold).bevi_bool) /* Line: 69 */ {
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(365775389, beva_node);
bevt_75_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(1253772551);
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_6));
bevl_v = bevt_74_tmpany_phold.bemd_1(2122005988, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_nd.bemd_1(-2043424394, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevl_v.bemd_0(-1714917982);
bevl_nd.bemd_1(114704418, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevt_80_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_79_tmpany_phold.bemd_1(1365695967, bevt_80_tmpany_phold);
beva_node.bem_prepend_1((BEC_2_5_4_BuildNode) bevl_nd );
} /* Line: 76 */
bevt_83_tmpany_phold = beva_node.bem_heldGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_0(510108416);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_7));
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(1560831110, bevt_84_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_81_tmpany_phold).bevi_bool) /* Line: 79 */ {
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 80 */
bevl_unwind = be.BECS_Runtime.boolTrue;
bevl_c0 = beva_node.bem_containerGet_0();
if (bevl_c0 == null) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_3_5_5_6_BuildVisitPass11_bels_8));
bevt_87_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_88_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_87_tmpany_phold);
} /* Line: 85 */
bevt_90_tmpany_phold = bevl_c0.bemd_0(673824477);
bevt_91_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_1(1560831110, bevt_91_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_89_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevt_94_tmpany_phold = bevl_c0.bemd_0(-1714917982);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(510108416);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_9));
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_1(1560831110, bevt_95_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 89 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 89 */
 else  /* Line: 89 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 89 */ {
bevt_96_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 89 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 89 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 89 */
 else  /* Line: 89 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 89 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 90 */
 else  /* Line: 89 */ {
bevt_98_tmpany_phold = bevl_c0.bemd_0(673824477);
bevt_99_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(1560831110, bevt_99_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_97_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 92 */
} /* Line: 89 */
if (((BEC_2_5_4_LogicBool) bevl_unwind).bevi_bool) /* Line: 94 */ {
bevl_cnode = bevl_c0;
bevl_lastStep = null;
while (true)
 /* Line: 99 */ {
bevt_101_tmpany_phold = bevl_cnode.bemd_0(673824477);
bevt_102_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_1(-502649276, bevt_102_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_100_tmpany_phold).bevi_bool) /* Line: 99 */ {
bevl_lastStep = bevl_cnode;
bevl_cnode = bevl_cnode.bemd_0(632535565);
} /* Line: 102 */
 else  /* Line: 99 */ {
break;
} /* Line: 99 */
} /* Line: 99 */
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_6_BuildVisitPass11_bels_10));
bevl_pholdv = bevl_lastStep.bemd_2(1506344634, bevt_103_tmpany_phold, bevp_build);
bevl_phold = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold.bemd_1(365775389, beva_node);
bevt_104_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold.bemd_1(-2043424394, bevt_104_tmpany_phold);
bevl_phold.bemd_1(114704418, bevl_pholdv);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_phold );
bevl_phold.bemd_0(1772682);
bevl_prc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_prc.bemd_1(365775389, beva_node);
bevt_105_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_prc.bemd_1(-2043424394, bevt_105_tmpany_phold);
bevl_prcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_106_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_11));
bevl_prcc.bemd_1(542517897, bevt_106_tmpany_phold);
bevl_prc.bemd_1(114704418, bevl_prcc);
bevl_phold2 = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold2.bemd_1(365775389, beva_node);
bevt_107_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold2.bemd_1(-2043424394, bevt_107_tmpany_phold);
bevl_phold2.bemd_1(114704418, bevl_pholdv);
bevl_prc.bemd_1(-809802935, bevl_phold2);
bevl_prc.bemd_1(-809802935, beva_node);
bevl_lastStep.bemd_1(1164881494, bevl_prc);
bevt_108_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_108_tmpany_phold;
} /* Line: 127 */
} /* Line: 94 */
bevt_109_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_109_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inMtdGet_0() {
return bevp_inMtd;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inMtdGetDirect_0() {
return bevp_inMtd;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {23, 23, 23, 23, 24, 25, 25, 25, 25, 25, 25, 26, 28, 28, 28, 28, 28, 29, 30, 30, 31, 33, 35, 36, 38, 38, 38, 38, 39, 40, 40, 40, 40, 40, 41, 41, 42, 42, 42, 42, 47, 47, 47, 47, 49, 49, 49, 49, 0, 49, 49, 49, 49, 0, 0, 49, 49, 49, 49, 49, 0, 0, 0, 50, 50, 50, 50, 50, 50, 50, 52, 52, 52, 52, 53, 53, 53, 53, 53, 53, 53, 0, 0, 0, 60, 61, 61, 61, 61, 61, 61, 0, 0, 0, 61, 61, 61, 61, 0, 0, 0, 65, 65, 69, 69, 69, 70, 71, 72, 72, 72, 72, 73, 73, 74, 74, 75, 75, 75, 76, 79, 79, 79, 79, 80, 80, 82, 83, 84, 84, 85, 85, 85, 89, 89, 89, 89, 89, 89, 89, 0, 0, 0, 89, 0, 0, 0, 90, 91, 91, 91, 92, 95, 96, 99, 99, 99, 101, 102, 107, 107, 108, 109, 110, 110, 111, 112, 113, 114, 115, 116, 116, 117, 118, 118, 119, 120, 121, 122, 122, 123, 124, 125, 126, 127, 127, 130, 130, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {157, 158, 159, 164, 165, 166, 167, 168, 169, 170, 175, 176, 178, 179, 180, 181, 184, 186, 187, 192, 193, 195, 201, 202, 204, 205, 206, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 225, 226, 227, 232, 233, 234, 235, 236, 238, 241, 242, 243, 244, 246, 249, 253, 254, 255, 256, 261, 262, 265, 269, 272, 273, 274, 275, 276, 277, 278, 280, 281, 282, 283, 285, 286, 287, 292, 293, 294, 295, 297, 300, 304, 307, 308, 313, 314, 315, 316, 321, 322, 325, 329, 332, 333, 334, 335, 337, 340, 344, 349, 350, 354, 355, 356, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 373, 374, 375, 376, 378, 379, 381, 382, 383, 388, 389, 390, 391, 393, 394, 395, 397, 398, 399, 400, 402, 405, 409, 412, 414, 417, 421, 424, 427, 428, 429, 431, 435, 436, 439, 440, 441, 443, 444, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 479, 480, 483, 486, 489, 493};
/* BEGIN LINEINFO 
assign 1 23 157
typenameGet 0 23 157
assign 1 23 158
EXPRGet 0 23 158
assign 1 23 159
equals 1 23 164
assign 1 24 165
assign 1 25 166
containedGet 0 25 166
assign 1 25 167
firstGet 0 25 167
assign 1 25 168
containedGet 0 25 168
assign 1 25 169
firstNodeGet 0 25 169
assign 1 25 170
undef 1 25 175
assign 1 26 176
nextDescendGet 0 26 176
assign 1 28 178
containedGet 0 28 178
assign 1 28 179
firstGet 0 28 179
assign 1 28 180
containedGet 0 28 180
assign 1 28 181
iteratorGet 0 28 181
assign 1 28 184
hasNextGet 0 28 184
assign 1 29 186
nextGet 0 29 186
assign 1 30 187
undef 1 30 192
assign 1 31 193
beforeInsert 1 33 195
delete 0 35 201
return 1 36 202
assign 1 38 204
typenameGet 0 38 204
assign 1 38 205
METHODGet 0 38 205
assign 1 38 206
equals 1 38 211
assign 1 39 212
assign 1 40 213
heldGet 0 40 213
assign 1 40 214
anyMapGet 0 40 214
assign 1 40 215
new 0 40 215
assign 1 40 216
get 1 40 216
assign 1 40 217
heldGet 0 40 217
assign 1 41 218
new 0 41 218
isTypedSet 1 41 219
assign 1 42 220
classGet 0 42 220
assign 1 42 221
heldGet 0 42 221
assign 1 42 222
namepathGet 0 42 222
namepathSet 1 42 223
assign 1 47 225
typenameGet 0 47 225
assign 1 47 226
CALLGet 0 47 226
assign 1 47 227
equals 1 47 232
assign 1 49 233
heldGet 0 49 233
assign 1 49 234
nameGet 0 49 234
assign 1 49 235
new 0 49 235
assign 1 49 236
equals 1 49 236
assign 1 0 238
assign 1 49 241
heldGet 0 49 241
assign 1 49 242
nameGet 0 49 242
assign 1 49 243
new 0 49 243
assign 1 49 244
equals 1 49 244
assign 1 0 246
assign 1 0 249
assign 1 49 253
containedGet 0 49 253
assign 1 49 254
lengthGet 0 49 254
assign 1 49 255
new 0 49 255
assign 1 49 256
greater 1 49 261
assign 1 0 262
assign 1 0 265
assign 1 0 269
assign 1 50 272
new 0 50 272
assign 1 50 273
containedGet 0 50 273
assign 1 50 274
lengthGet 0 50 274
assign 1 50 275
toString 0 50 275
assign 1 50 276
add 1 50 276
assign 1 50 277
new 2 50 277
throw 1 50 278
assign 1 52 280
heldGet 0 52 280
assign 1 52 281
nameGet 0 52 281
assign 1 52 282
new 0 52 282
assign 1 52 283
equals 1 52 283
assign 1 53 285
heldGet 0 53 285
assign 1 53 286
rtypeGet 0 53 286
assign 1 53 287
def 1 53 292
assign 1 53 293
heldGet 0 53 293
assign 1 53 294
rtypeGet 0 53 294
assign 1 53 295
impliedGet 0 53 295
assign 1 0 297
assign 1 0 300
assign 1 0 304
assign 1 60 307
firstGet 0 60 307
assign 1 61 308
def 1 61 313
assign 1 61 314
typenameGet 0 61 314
assign 1 61 315
VARGet 0 61 315
assign 1 61 316
equals 1 61 321
assign 1 0 322
assign 1 0 325
assign 1 0 329
assign 1 61 332
heldGet 0 61 332
assign 1 61 333
nameGet 0 61 333
assign 1 61 334
new 0 61 334
assign 1 61 335
equals 1 61 335
assign 1 0 337
assign 1 0 340
assign 1 0 344
assign 1 65 349
heldGet 0 65 349
rtypeSet 1 65 350
assign 1 69 354
heldGet 0 69 354
assign 1 69 355
boundGet 0 69 355
assign 1 69 356
not 0 69 356
assign 1 70 358
new 1 70 358
copyLoc 1 71 359
assign 1 72 360
heldGet 0 72 360
assign 1 72 361
anyMapGet 0 72 361
assign 1 72 362
new 0 72 362
assign 1 72 363
get 1 72 363
assign 1 73 364
VARGet 0 73 364
typenameSet 1 73 365
assign 1 74 366
heldGet 0 74 366
heldSet 1 74 367
assign 1 75 368
heldGet 0 75 368
assign 1 75 369
new 0 75 369
boundSet 1 75 370
prepend 1 76 371
assign 1 79 373
heldGet 0 79 373
assign 1 79 374
nameGet 0 79 374
assign 1 79 375
new 0 79 375
assign 1 79 376
equals 1 79 376
assign 1 80 378
nextDescendGet 0 80 378
return 1 80 379
assign 1 82 381
new 0 82 381
assign 1 83 382
containerGet 0 83 382
assign 1 84 383
undef 1 84 388
assign 1 85 389
new 0 85 389
assign 1 85 390
new 2 85 390
throw 1 85 391
assign 1 89 393
typenameGet 0 89 393
assign 1 89 394
CALLGet 0 89 394
assign 1 89 395
equals 1 89 395
assign 1 89 397
heldGet 0 89 397
assign 1 89 398
nameGet 0 89 398
assign 1 89 399
new 0 89 399
assign 1 89 400
equals 1 89 400
assign 1 0 402
assign 1 0 405
assign 1 0 409
assign 1 89 412
isSecondGet 0 89 412
assign 1 0 414
assign 1 0 417
assign 1 0 421
assign 1 90 424
new 0 90 424
assign 1 91 427
typenameGet 0 91 427
assign 1 91 428
BRACESGet 0 91 428
assign 1 91 429
equals 1 91 429
assign 1 92 431
new 0 92 431
assign 1 95 435
assign 1 96 436
assign 1 99 439
typenameGet 0 99 439
assign 1 99 440
BRACESGet 0 99 440
assign 1 99 441
notEquals 1 99 441
assign 1 101 443
assign 1 102 444
containerGet 0 102 444
assign 1 107 450
new 0 107 450
assign 1 107 451
tmpVar 2 107 451
assign 1 108 452
new 1 108 452
copyLoc 1 109 453
assign 1 110 454
VARGet 0 110 454
typenameSet 1 110 455
heldSet 1 111 456
replaceWith 1 112 457
addVariable 0 113 458
assign 1 114 459
new 1 114 459
copyLoc 1 115 460
assign 1 116 461
CALLGet 0 116 461
typenameSet 1 116 462
assign 1 117 463
new 0 117 463
assign 1 118 464
new 0 118 464
nameSet 1 118 465
heldSet 1 119 466
assign 1 120 467
new 1 120 467
copyLoc 1 121 468
assign 1 122 469
VARGet 0 122 469
typenameSet 1 122 470
heldSet 1 123 471
addValue 1 124 472
addValue 1 125 473
beforeInsert 1 126 474
assign 1 127 475
nextDescendGet 0 127 475
return 1 127 476
assign 1 130 479
nextDescendGet 0 130 479
return 1 130 480
return 1 0 483
return 1 0 486
assign 1 0 489
assign 1 0 493
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1460274649: return bem_transGetDirect_0();
case 1291754014: return bem_fieldIteratorGet_0();
case 376318330: return bem_toAny_0();
case -1772944905: return bem_constGetDirect_0();
case -188774864: return bem_fieldNamesGet_0();
case 1892440434: return bem_serializeToString_0();
case 2022591848: return bem_new_0();
case 123890466: return bem_tagGet_0();
case -1336547559: return bem_copy_0();
case -1914264312: return bem_serializationIteratorGet_0();
case 1924878947: return bem_serializeContents_0();
case -2097142996: return bem_many_0();
case -92876860: return bem_echo_0();
case -1673560399: return bem_toString_0();
case 1684359161: return bem_classNameGet_0();
case 1396075820: return bem_buildGetDirect_0();
case -419692225: return bem_buildGet_0();
case 782585161: return bem_deserializeClassNameGet_0();
case 824105696: return bem_inMtdGetDirect_0();
case 1714059697: return bem_iteratorGet_0();
case 1049031508: return bem_transGet_0();
case -440540280: return bem_ntypesGet_0();
case 1726245742: return bem_hashGet_0();
case 372040847: return bem_constGet_0();
case -40573534: return bem_ntypesGetDirect_0();
case -172634187: return bem_once_0();
case -744454572: return bem_inMtdGet_0();
case -870016446: return bem_print_0();
case -997138031: return bem_create_0();
case -939140314: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -948460336: return bem_ntypesSet_1(bevd_0);
case -502649276: return bem_notEquals_1(bevd_0);
case 1687349246: return bem_transSetDirect_1(bevd_0);
case -1807927146: return bem_buildSetDirect_1(bevd_0);
case -1386441501: return bem_ntypesSetDirect_1(bevd_0);
case -1860558101: return bem_sameType_1(bevd_0);
case 1560831110: return bem_equals_1(bevd_0);
case -1783619507: return bem_sameClass_1(bevd_0);
case 2024151813: return bem_otherClass_1(bevd_0);
case -1694384494: return bem_end_1(bevd_0);
case 1404691116: return bem_constSet_1(bevd_0);
case 1499692352: return bem_inMtdSet_1(bevd_0);
case -1139805373: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2108385190: return bem_undefined_1(bevd_0);
case -628251942: return bem_defined_1(bevd_0);
case -1259222473: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -9743810: return bem_sameObject_1(bevd_0);
case -665667897: return bem_constSetDirect_1(bevd_0);
case -1299087238: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 906586952: return bem_transSet_1(bevd_0);
case 1802133619: return bem_undef_1(bevd_0);
case 636524381: return bem_begin_1(bevd_0);
case -257411874: return bem_buildSet_1(bevd_0);
case -148425027: return bem_otherType_1(bevd_0);
case -1554389120: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1247316345: return bem_inMtdSetDirect_1(bevd_0);
case -1994787564: return bem_def_1(bevd_0);
case 921396152: return bem_copyTo_1(bevd_0);
case 1566667222: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -402932836: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1915330817: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -518118155: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -355453886: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1141599202: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1078652527: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1443758120: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass11_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass11_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_6_BuildVisitPass11();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst = (BEC_3_5_5_6_BuildVisitPass11) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_type;
}
}
}
