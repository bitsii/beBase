namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_10_SystemCallOnNull : BEC_2_6_9_SystemException {
public BEC_2_6_10_SystemCallOnNull() { }
static BEC_2_6_10_SystemCallOnNull() { }
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x61,0x6C,0x6C,0x4F,0x6E,0x4E,0x75,0x6C,0x6C};
private static byte[] becc_BEC_2_6_10_SystemCallOnNull_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;

public static new BET_2_6_10_SystemCallOnNull bece_BEC_2_6_10_SystemCallOnNull_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {391};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
assign 1 391 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 119461913: return bem_tagGet_0();
case 926333388: return bem_translateEmittedExceptionInner_0();
case -175333601: return bem_fileNameGetDirect_0();
case -1005119995: return bem_many_0();
case 2045941275: return bem_iteratorGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -791340178: return bem_fileNameGet_0();
case 1196171179: return bem_hashGet_0();
case 225427809: return bem_vvGetDirect_0();
case 501088997: return bem_sourceFileNameGet_0();
case 1487849820: return bem_emitLangGetDirect_0();
case -1504691864: return bem_getFrameText_0();
case 1326588441: return bem_lineNumberGetDirect_0();
case -2017009146: return bem_new_0();
case 611702865: return bem_copy_0();
case -1683446411: return bem_translateEmittedException_0();
case -545556484: return bem_once_0();
case 1379547046: return bem_langGetDirect_0();
case -1486279572: return bem_serializeContents_0();
case 1095614980: return bem_klassNameGet_0();
case -1583672278: return bem_echo_0();
case 927363103: return bem_translatedGet_0();
case -465296205: return bem_framesGetDirect_0();
case -2088980665: return bem_framesGet_0();
case 1660307925: return bem_translatedGetDirect_0();
case -87479749: return bem_emitLangGet_0();
case -606047962: return bem_descriptionGetDirect_0();
case 113419970: return bem_framesTextGet_0();
case 880688467: return bem_descriptionGet_0();
case 392815790: return bem_vvGet_0();
case 1891691282: return bem_klassNameGetDirect_0();
case -1115607661: return bem_langGet_0();
case -678541085: return bem_classNameGet_0();
case -639297756: return bem_toAny_0();
case -508201080: return bem_methodNameGetDirect_0();
case -1754478112: return bem_print_0();
case -167909039: return bem_lineNumberGet_0();
case -1475550710: return bem_create_0();
case -744679096: return bem_fieldNamesGet_0();
case -1920480675: return bem_methodNameGet_0();
case 281444821: return bem_fieldIteratorGet_0();
case -225870373: return bem_serializeToString_0();
case -1275325619: return bem_toString_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case -1547471654: return bem_framesTextGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 70562390: return bem_translatedSetDirect_1(bevd_0);
case -160668129: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case -1698900309: return bem_new_1(bevd_0);
case 1851870128: return bem_descriptionSet_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 2057601675: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1417240616: return bem_emitLangSetDirect_1(bevd_0);
case -1890529804: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case 2130896021: return bem_vvSetDirect_1(bevd_0);
case -1767533201: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -701778648: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 65088657: return bem_klassNameSet_1(bevd_0);
case 1454699217: return bem_lineNumberSetDirect_1(bevd_0);
case -109235931: return bem_framesTextSetDirect_1(bevd_0);
case -1612644231: return bem_klassNameSetDirect_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1731710924: return bem_methodNameSetDirect_1(bevd_0);
case 328346857: return bem_methodNameSet_1(bevd_0);
case 1917775411: return bem_fileNameSetDirect_1(bevd_0);
case -1223636941: return bem_framesSetDirect_1(bevd_0);
case 1163648039: return bem_descriptionSetDirect_1(bevd_0);
case -2060916709: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -425283037: return bem_framesSet_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case 1606810499: return bem_lineNumberSet_1(bevd_0);
case -1556501171: return bem_fileNameSet_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case 553868095: return bem_langSetDirect_1(bevd_0);
case 433383590: return bem_translatedSet_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case -646027894: return bem_emitLangSet_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 970281456: return bem_vvSet_1(bevd_0);
case -354097271: return bem_framesTextSet_1(bevd_0);
case -1127900515: return bem_langSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 982735219: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemCallOnNull_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemCallOnNull_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemCallOnNull();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst = (BEC_2_6_10_SystemCallOnNull) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemCallOnNull.bece_BEC_2_6_10_SystemCallOnNull_bevs_type;
}
}
}
