namespace be {
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig : BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
static BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x2E,0x73,0x79,0x6E};
public static new BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static new BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public virtual BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_1_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_3_ta_ph = bevp_emitter.bem_emitLangGet_0();
bevt_1_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_2_ta_ph.bem_addStep_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_1_ta_ph.bem_addStep_1(bevt_4_ta_ph);
bevt_6_ta_ph = bevp_emitter.bem_fileExtGet_0();
bevt_5_ta_ph = bevp_emitName.bem_add_1(bevt_6_ta_ph);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_ph.bem_addStep_1(bevt_5_ta_ph);
bevt_9_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_10_ta_ph = bevp_emitter.bem_emitLangGet_0();
bevt_8_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_9_ta_ph.bem_addStep_1(bevt_10_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_7_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_8_ta_ph.bem_addStep_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_emitter.bem_fileExtGet_0();
bevt_12_ta_ph = bevp_typeEmitName.bem_add_1(bevt_13_ta_ph);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_ta_ph.bem_addStep_1(bevt_12_ta_ph);
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevp_classPath.bem_parentGet_0();
bevt_14_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_classDir.bem_copy_0();
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_11_BuildClassConfig_bels_1));
bevt_15_ta_ph = bevp_emitName.bem_add_1(bevt_16_ta_ph);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_ta_ph.bem_addStep_1(bevt_15_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGetDirect_0() {
return bevp_np;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameSpaceGet_0() {
return bevp_nameSpace;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() {
return bevp_nameSpace;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitNameGet_0() {
return bevp_emitName;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGetDirect_0() {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_typeEmitNameGet_0() {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() {
return bevp_typeEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fullEmitNameGet_0() {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() {
return bevp_fullEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classPathGet_0() {
return bevp_classPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() {
return bevp_classPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_typePathGet_0() {
return bevp_typePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() {
return bevp_typePath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classDirGet_0() {
return bevp_classDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() {
return bevp_classDir;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_synPathGet_0() {
return bevp_synPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() {
return bevp_synPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {2470, 2471, 2472, 2473, 2475, 2476, 2477, 2478, 2479, 2479, 2479, 2479, 2479, 2479, 2479, 2479, 2480, 2480, 2480, 2480, 2480, 2480, 2480, 2480, 2481, 2482, 2482, 2482, 2482, 2489, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 76, 79, 82, 85, 89, 93, 96, 99, 103, 107, 110, 113, 117, 121, 124, 127, 131, 135, 138, 141, 145, 149, 152, 155, 159, 163, 166, 169, 173, 177, 180, 183, 187, 191, 194, 197, 201, 205, 208, 211, 215, 219, 222, 225, 229, 233, 236, 239, 243};
/* BEGIN LINEINFO 
assign 1 2470 44
assign 1 2471 45
assign 1 2472 46
assign 1 2473 47
assign 1 2475 48
getNameSpace 1 2475 48
assign 1 2476 49
getEmitName 1 2476 49
assign 1 2477 50
getTypeEmitName 1 2477 50
assign 1 2478 51
getFullEmitName 2 2478 51
assign 1 2479 52
copy 0 2479 52
assign 1 2479 53
emitLangGet 0 2479 53
assign 1 2479 54
addStep 1 2479 54
assign 1 2479 55
new 0 2479 55
assign 1 2479 56
addStep 1 2479 56
assign 1 2479 57
fileExtGet 0 2479 57
assign 1 2479 58
add 1 2479 58
assign 1 2479 59
addStep 1 2479 59
assign 1 2480 60
copy 0 2480 60
assign 1 2480 61
emitLangGet 0 2480 61
assign 1 2480 62
addStep 1 2480 62
assign 1 2480 63
new 0 2480 63
assign 1 2480 64
addStep 1 2480 64
assign 1 2480 65
fileExtGet 0 2480 65
assign 1 2480 66
add 1 2480 66
assign 1 2480 67
addStep 1 2480 67
assign 1 2481 68
parentGet 0 2481 68
assign 1 2482 69
copy 0 2482 69
assign 1 2482 70
new 0 2482 70
assign 1 2482 71
add 1 2482 71
assign 1 2482 72
addStep 1 2482 72
return 1 2489 76
return 1 0 79
return 1 0 82
assign 1 0 85
assign 1 0 89
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
return 1 0 107
return 1 0 110
assign 1 0 113
assign 1 0 117
return 1 0 121
return 1 0 124
assign 1 0 127
assign 1 0 131
return 1 0 135
return 1 0 138
assign 1 0 141
assign 1 0 145
return 1 0 149
return 1 0 152
assign 1 0 155
assign 1 0 159
return 1 0 163
return 1 0 166
assign 1 0 169
assign 1 0 173
return 1 0 177
return 1 0 180
assign 1 0 183
assign 1 0 187
return 1 0 191
return 1 0 194
assign 1 0 197
assign 1 0 201
return 1 0 205
return 1 0 208
assign 1 0 211
assign 1 0 215
return 1 0 219
return 1 0 222
assign 1 0 225
assign 1 0 229
return 1 0 233
return 1 0 236
assign 1 0 239
assign 1 0 243
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1760216553: return bem_emitNameGet_0();
case -1357085121: return bem_nameSpaceGetDirect_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 437073236: return bem_libNameGetDirect_0();
case 1474398444: return bem_synPathGet_0();
case -396239848: return bem_emitterGet_0();
case -1076915155: return bem_serializeToString_0();
case 1834246217: return bem_classNameGet_0();
case 26089241: return bem_npGet_0();
case 1908852111: return bem_fullEmitNameGetDirect_0();
case 647959760: return bem_emitPathGetDirect_0();
case 946360922: return bem_serializationIteratorGet_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case -1873299592: return bem_libNameGet_0();
case -1366419648: return bem_emitNameGetDirect_0();
case -1513114703: return bem_fullEmitNameGet_0();
case 1586815430: return bem_fieldIteratorGet_0();
case -159500529: return bem_typeEmitNameGet_0();
case 1470161223: return bem_typePathGet_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -1670461069: return bem_emitPathGet_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case -42888212: return bem_nameSpaceGet_0();
case 1179534115: return bem_classDirGetDirect_0();
case 2081363871: return bem_copy_0();
case 503205961: return bem_npGetDirect_0();
case -1505122043: return bem_typePathGetDirect_0();
case -975498393: return bem_fieldNamesGet_0();
case -44325320: return bem_emitterGetDirect_0();
case 954703233: return bem_create_0();
case -893093197: return bem_toString_0();
case -2116503406: return bem_synPathGetDirect_0();
case -40905183: return bem_echo_0();
case 535034979: return bem_classPathGet_0();
case -1803949379: return bem_typeEmitNameGetDirect_0();
case -1653939165: return bem_iteratorGet_0();
case 1372586853: return bem_classDirGet_0();
case 1892407844: return bem_classPathGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 454423193: return bem_typePathSet_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 951817770: return bem_libNameSet_1(bevd_0);
case -597278608: return bem_emitterSetDirect_1(bevd_0);
case -1190537: return bem_npSetDirect_1(bevd_0);
case -1260490211: return bem_nameSpaceSetDirect_1(bevd_0);
case 862982737: return bem_emitNameSetDirect_1(bevd_0);
case -1918431739: return bem_synPathSetDirect_1(bevd_0);
case 314165440: return bem_libNameSetDirect_1(bevd_0);
case 1808434079: return bem_classPathSetDirect_1(bevd_0);
case -1257267482: return bem_classPathSet_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 467814074: return bem_classDirSetDirect_1(bevd_0);
case -509290871: return bem_fullEmitNameSetDirect_1(bevd_0);
case 1777825783: return bem_emitterSet_1(bevd_0);
case -1915916303: return bem_typeEmitNameSet_1(bevd_0);
case 509237021: return bem_npSet_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 620986551: return bem_emitPathSetDirect_1(bevd_0);
case 1487692993: return bem_synPathSet_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -185757930: return bem_typePathSetDirect_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 725602057: return bem_classDirSet_1(bevd_0);
case 2005303398: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -1313323774: return bem_fullEmitNameSet_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -78554441: return bem_nameSpaceSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -1544772265: return bem_typeEmitNameSetDirect_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -458444492: return bem_emitNameSet_1(bevd_0);
case 812311338: return bem_emitPathSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 553335663: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_11_BuildClassConfig();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
}
