namespace be {
/* IO:File: source/build/EmitCommon.be */
public class BEC_2_5_11_BuildClassConfig : BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildClassConfig() { }
static BEC_2_5_11_BuildClassConfig() { }
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x43,0x6F,0x6E,0x66,0x69,0x67};
private static byte[] becc_BEC_2_5_11_BuildClassConfig_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x43,0x6F,0x6D,0x6D,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_0 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_1 = {0x62,0x65};
private static byte[] bece_BEC_2_5_11_BuildClassConfig_bels_2 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_11_BuildClassConfig_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_11_BuildClassConfig_bels_2, 4));
public static new BEC_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_inst;

public static new BET_2_5_11_BuildClassConfig bece_BEC_2_5_11_BuildClassConfig_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_5_10_BuildEmitCommon bevp_emitter;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_nameSpace;
public BEC_2_4_6_TextString bevp_emitName;
public BEC_2_4_6_TextString bevp_typeEmitName;
public BEC_2_4_6_TextString bevp_fullEmitName;
public BEC_3_2_4_4_IOFilePath bevp_classPath;
public BEC_3_2_4_4_IOFilePath bevp_typePath;
public BEC_3_2_4_4_IOFilePath bevp_classDir;
public BEC_3_2_4_4_IOFilePath bevp_synPath;
public virtual BEC_2_5_11_BuildClassConfig bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_5_10_BuildEmitCommon beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevp_emitPath = beva__emitPath;
bevp_libName = beva__libName;
bevp_nameSpace = bevp_emitter.bem_getNameSpace_1(bevp_libName);
bevp_emitName = bevp_emitter.bem_getEmitName_1(bevp_np);
bevp_typeEmitName = bevp_emitter.bem_getTypeEmitName_1(bevp_np);
bevp_fullEmitName = (BEC_2_4_6_TextString) bevp_emitter.bem_getFullEmitName_2(bevp_nameSpace, bevp_emitName);
bevt_2_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_3_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_1_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_2_tmpany_phold.bem_addStep_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_0));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_1_tmpany_phold.bem_addStep_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_5_tmpany_phold = bevp_emitName.bem_add_1(bevt_6_tmpany_phold);
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_phold.bem_addStep_1(bevt_5_tmpany_phold);
bevt_9_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_emitPath.bem_copy_0();
bevt_10_tmpany_phold = bevp_emitter.bem_emitLangGet_0();
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_9_tmpany_phold.bem_addStep_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_11_BuildClassConfig_bels_1));
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_8_tmpany_phold.bem_addStep_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_emitter.bem_fileExtGet_0();
bevt_12_tmpany_phold = bevp_typeEmitName.bem_add_1(bevt_13_tmpany_phold);
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_7_tmpany_phold.bem_addStep_1(bevt_12_tmpany_phold);
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevp_classPath.bem_parentGet_0();
bevt_14_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_classDir.bem_copy_0();
bevt_16_tmpany_phold = bece_BEC_2_5_11_BuildClassConfig_bevo_0;
bevt_15_tmpany_phold = bevp_emitName.bem_add_1(bevt_16_tmpany_phold);
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_14_tmpany_phold.bem_addStep_1(bevt_15_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_relEmitName_1(BEC_2_4_6_TextString beva_forLibName) {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGetDirect_0() {
return bevp_np;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildEmitCommon bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameSpaceGet_0() {
return bevp_nameSpace;
} /*method end*/
public BEC_2_4_6_TextString bem_nameSpaceGetDirect_0() {
return bevp_nameSpace;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_nameSpaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_nameSpaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nameSpace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitNameGet_0() {
return bevp_emitName;
} /*method end*/
public BEC_2_4_6_TextString bem_emitNameGetDirect_0() {
return bevp_emitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_emitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_emitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_typeEmitNameGet_0() {
return bevp_typeEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_typeEmitNameGetDirect_0() {
return bevp_typeEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typeEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typeEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typeEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fullEmitNameGet_0() {
return bevp_fullEmitName;
} /*method end*/
public BEC_2_4_6_TextString bem_fullEmitNameGetDirect_0() {
return bevp_fullEmitName;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_fullEmitNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_fullEmitNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fullEmitName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classPathGet_0() {
return bevp_classPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classPathGetDirect_0() {
return bevp_classPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_typePathGet_0() {
return bevp_typePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_typePathGetDirect_0() {
return bevp_typePath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_typePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_typePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_typePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_classDirGet_0() {
return bevp_classDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classDirGetDirect_0() {
return bevp_classDir;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_classDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_classDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_synPathGet_0() {
return bevp_synPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synPathGetDirect_0() {
return bevp_synPath;
} /*method end*/
public virtual BEC_2_5_11_BuildClassConfig bem_synPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_11_BuildClassConfig bem_synPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {2481, 2482, 2483, 2484, 2486, 2487, 2488, 2489, 2490, 2490, 2490, 2490, 2490, 2490, 2490, 2490, 2491, 2491, 2491, 2491, 2491, 2491, 2491, 2491, 2492, 2493, 2493, 2493, 2493, 2500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 78, 81, 84, 87, 91, 95, 98, 101, 105, 109, 112, 115, 119, 123, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203, 207, 210, 213, 217, 221, 224, 227, 231, 235, 238, 241, 245};
/* BEGIN LINEINFO 
assign 1 2481 46
assign 1 2482 47
assign 1 2483 48
assign 1 2484 49
assign 1 2486 50
getNameSpace 1 2486 50
assign 1 2487 51
getEmitName 1 2487 51
assign 1 2488 52
getTypeEmitName 1 2488 52
assign 1 2489 53
getFullEmitName 2 2489 53
assign 1 2490 54
copy 0 2490 54
assign 1 2490 55
emitLangGet 0 2490 55
assign 1 2490 56
addStep 1 2490 56
assign 1 2490 57
new 0 2490 57
assign 1 2490 58
addStep 1 2490 58
assign 1 2490 59
fileExtGet 0 2490 59
assign 1 2490 60
add 1 2490 60
assign 1 2490 61
addStep 1 2490 61
assign 1 2491 62
copy 0 2491 62
assign 1 2491 63
emitLangGet 0 2491 63
assign 1 2491 64
addStep 1 2491 64
assign 1 2491 65
new 0 2491 65
assign 1 2491 66
addStep 1 2491 66
assign 1 2491 67
fileExtGet 0 2491 67
assign 1 2491 68
add 1 2491 68
assign 1 2491 69
addStep 1 2491 69
assign 1 2492 70
parentGet 0 2492 70
assign 1 2493 71
copy 0 2493 71
assign 1 2493 72
new 0 2493 72
assign 1 2493 73
add 1 2493 73
assign 1 2493 74
addStep 1 2493 74
return 1 2500 78
return 1 0 81
return 1 0 84
assign 1 0 87
assign 1 0 91
return 1 0 95
return 1 0 98
assign 1 0 101
assign 1 0 105
return 1 0 109
return 1 0 112
assign 1 0 115
assign 1 0 119
return 1 0 123
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
return 1 0 207
return 1 0 210
assign 1 0 213
assign 1 0 217
return 1 0 221
return 1 0 224
assign 1 0 227
assign 1 0 231
return 1 0 235
return 1 0 238
assign 1 0 241
assign 1 0 245
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -894869369: return bem_typePathGet_0();
case -1799416909: return bem_serializationIteratorGet_0();
case 1804773996: return bem_create_0();
case -1258797208: return bem_nameSpaceGetDirect_0();
case -73436994: return bem_new_0();
case -9329741: return bem_typePathGetDirect_0();
case 1254813232: return bem_toAny_0();
case 404746528: return bem_fullEmitNameGetDirect_0();
case -1072030744: return bem_sourceFileNameGet_0();
case 653349672: return bem_copy_0();
case 267983587: return bem_classDirGet_0();
case 319071469: return bem_synPathGet_0();
case 2142858117: return bem_classPathGet_0();
case -317826930: return bem_fullEmitNameGet_0();
case -1778497682: return bem_serializeToString_0();
case 2094922617: return bem_libNameGet_0();
case -427802706: return bem_typeEmitNameGet_0();
case 367175766: return bem_npGet_0();
case 2977123: return bem_emitPathGetDirect_0();
case 959038598: return bem_echo_0();
case -2141267152: return bem_typeEmitNameGetDirect_0();
case 2108814440: return bem_emitNameGetDirect_0();
case -2133734017: return bem_classPathGetDirect_0();
case -2083451705: return bem_npGetDirect_0();
case 2132487494: return bem_emitNameGet_0();
case -2120499139: return bem_iteratorGet_0();
case 749082680: return bem_emitterGet_0();
case -1658202448: return bem_emitPathGet_0();
case 1562662552: return bem_many_0();
case 167710369: return bem_print_0();
case 575265560: return bem_libNameGetDirect_0();
case -297374401: return bem_hashGet_0();
case -1067704397: return bem_once_0();
case 39810102: return bem_tagGet_0();
case 1769468354: return bem_fieldNamesGet_0();
case -248386382: return bem_synPathGetDirect_0();
case 2073496976: return bem_emitterGetDirect_0();
case -1628372783: return bem_classNameGet_0();
case -1071008216: return bem_serializeContents_0();
case 621276181: return bem_toString_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case 1674244299: return bem_classDirGetDirect_0();
case 1548480487: return bem_nameSpaceGet_0();
case -1960297657: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -438924354: return bem_undefined_1(bevd_0);
case 207577733: return bem_classPathSet_1(bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -938525113: return bem_libNameSet_1(bevd_0);
case -1446307844: return bem_typePathSetDirect_1(bevd_0);
case -1341940529: return bem_synPathSetDirect_1(bevd_0);
case -1969670104: return bem_libNameSetDirect_1(bevd_0);
case 616753868: return bem_typeEmitNameSetDirect_1(bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -290365798: return bem_emitPathSetDirect_1(bevd_0);
case 2095605016: return bem_synPathSet_1(bevd_0);
case -509496273: return bem_classDirSet_1(bevd_0);
case -1001766950: return bem_emitterSetDirect_1(bevd_0);
case 879668484: return bem_emitNameSetDirect_1(bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case -345852288: return bem_classPathSetDirect_1(bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case 1325819735: return bem_emitterSet_1(bevd_0);
case -994456820: return bem_typePathSet_1(bevd_0);
case 1322688037: return bem_emitNameSet_1(bevd_0);
case 2054522452: return bem_fullEmitNameSetDirect_1(bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -697390710: return bem_npSetDirect_1(bevd_0);
case -1140900466: return bem_npSet_1(bevd_0);
case -1049172860: return bem_defined_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case -980644413: return bem_fullEmitNameSet_1(bevd_0);
case 1421631844: return bem_emitPathSet_1(bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case -467803608: return bem_nameSpaceSet_1(bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case 2027280634: return bem_nameSpaceSetDirect_1(bevd_0);
case 1539344419: return bem_typeEmitNameSet_1(bevd_0);
case -1251242063: return bem_relEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 119168590: return bem_classDirSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 720027862: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, (BEC_2_5_10_BuildEmitCommon) bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildClassConfig_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_11_BuildClassConfig_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_11_BuildClassConfig();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst = (BEC_2_5_11_BuildClassConfig) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_11_BuildClassConfig.bece_BEC_2_5_11_BuildClassConfig_bevs_type;
}
}
}
