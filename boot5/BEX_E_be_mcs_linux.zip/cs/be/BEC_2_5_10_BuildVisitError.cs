namespace be {
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError : BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
static BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static new BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static new BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_msgi) {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_1_tmpany_phold = bevl_toRet.bemd_1(182085968, bevp_msg);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_newlineGet_0();
bevl_toRet = bevt_1_tmpany_phold.bemd_1(182085968, bevt_2_tmpany_phold);
} /* Line: 25 */
if (bevp_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevl_nc = bevp_node;
while (true)
 /* Line: 29 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevl_toRet.bemd_1(-602412933, bevl_nc);
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_newlineGet_0();
bevl_toRet.bemd_1(-602412933, bevt_6_tmpany_phold);
bevl_nc = bevl_nc.bemd_0(1343898551);
} /* Line: 32 */
 else  /* Line: 29 */ {
break;
} /* Line: 29 */
} /* Line: 29 */
} /* Line: 29 */
bevt_8_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(182085968, bevt_8_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_msgGet_0() {
return bevp_msg;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGetDirect_0() {
return bevp_msg;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nodeGet_0() {
return bevp_node;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGetDirect_0() {
return bevp_node;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {10, 15, 16, 23, 24, 24, 25, 25, 25, 25, 27, 27, 28, 29, 29, 30, 31, 31, 31, 32, 35, 35, 36, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 20, 21, 36, 37, 42, 43, 44, 45, 46, 48, 53, 54, 57, 62, 63, 64, 65, 66, 67, 74, 75, 76, 79, 82, 85, 89, 93, 96, 99, 103};
/* BEGIN LINEINFO 
assign 1 10 16
assign 1 15 20
assign 1 16 21
assign 1 23 36
new 0 23 36
assign 1 24 37
def 1 24 42
assign 1 25 43
add 1 25 43
assign 1 25 44
new 0 25 44
assign 1 25 45
newlineGet 0 25 45
assign 1 25 46
add 1 25 46
assign 1 27 48
def 1 27 53
assign 1 28 54
assign 1 29 57
def 1 29 62
addValue 1 30 63
assign 1 31 64
new 0 31 64
assign 1 31 65
newlineGet 0 31 65
addValue 1 31 66
assign 1 32 67
containerGet 0 32 67
assign 1 35 74
getFrameText 0 35 74
assign 1 35 75
add 1 35 75
return 1 36 76
return 1 0 79
return 1 0 82
assign 1 0 85
assign 1 0 89
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1747771860: return bem_classNameGet_0();
case 1884049010: return bem_toString_0();
case -1218045724: return bem_emitLangGetDirect_0();
case -2028131331: return bem_msgGet_0();
case 836813297: return bem_langGet_0();
case -288796989: return bem_methodNameGetDirect_0();
case -926676223: return bem_iteratorGet_0();
case 270769958: return bem_framesTextGet_0();
case -1310698467: return bem_lineNumberGet_0();
case -468835743: return bem_translatedGetDirect_0();
case -2039257540: return bem_tagGet_0();
case 1035709840: return bem_fileNameGet_0();
case -931877776: return bem_lineNumberGetDirect_0();
case 546322415: return bem_echo_0();
case -448869219: return bem_print_0();
case -1442113467: return bem_create_0();
case -1096019733: return bem_emitLangGet_0();
case 1287866350: return bem_copy_0();
case 583026473: return bem_toAny_0();
case -304660926: return bem_sourceFileNameGet_0();
case 778193333: return bem_fileNameGetDirect_0();
case 1091579640: return bem_new_0();
case -497450892: return bem_hashGet_0();
case -1058671142: return bem_translateEmittedException_0();
case -275053926: return bem_fieldIteratorGet_0();
case 1146334116: return bem_klassNameGet_0();
case -1351393468: return bem_methodNameGet_0();
case -1229869102: return bem_msgGetDirect_0();
case 767177150: return bem_fieldNamesGet_0();
case 1787122251: return bem_nodeGet_0();
case 1017833055: return bem_many_0();
case -1616792218: return bem_deserializeClassNameGet_0();
case -2109366609: return bem_translateEmittedExceptionInner_0();
case 1505927918: return bem_serializeContents_0();
case -74396479: return bem_vvGet_0();
case -1776494837: return bem_nodeGetDirect_0();
case -1975328143: return bem_once_0();
case -409973446: return bem_framesGetDirect_0();
case 442193711: return bem_descriptionGet_0();
case -1513747673: return bem_getFrameText_0();
case -1179800415: return bem_translatedGet_0();
case 372926288: return bem_framesGet_0();
case 1332555025: return bem_framesTextGetDirect_0();
case 1062973207: return bem_serializationIteratorGet_0();
case 181581437: return bem_langGetDirect_0();
case -1180288412: return bem_vvGetDirect_0();
case -1210372679: return bem_descriptionGetDirect_0();
case 56074644: return bem_klassNameGetDirect_0();
case -470506305: return bem_serializeToString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -135472117: return bem_langSetDirect_1(bevd_0);
case -558141559: return bem_langSet_1(bevd_0);
case -1396938224: return bem_notEquals_1(bevd_0);
case 415626374: return bem_emitLangSet_1(bevd_0);
case 1076938750: return bem_fileNameSet_1(bevd_0);
case 1011958071: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2047213073: return bem_equals_1(bevd_0);
case 38080717: return bem_undef_1(bevd_0);
case -226945840: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -226350350: return bem_descriptionSet_1(bevd_0);
case 353229856: return bem_translatedSet_1(bevd_0);
case -139911993: return bem_vvSetDirect_1(bevd_0);
case -543181183: return bem_descriptionSetDirect_1(bevd_0);
case 924259954: return bem_framesSet_1(bevd_0);
case -629747025: return bem_methodNameSetDirect_1(bevd_0);
case -942274895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -243360848: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1185250915: return bem_lineNumberSet_1(bevd_0);
case -778156991: return bem_new_1(bevd_0);
case 745295406: return bem_sameClass_1(bevd_0);
case -1916951160: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 915056280: return bem_framesTextSet_1(bevd_0);
case -1132198926: return bem_sameType_1(bevd_0);
case 205081622: return bem_sameObject_1(bevd_0);
case -854859508: return bem_framesTextSetDirect_1(bevd_0);
case -1732969657: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 741776069: return bem_translatedSetDirect_1(bevd_0);
case -1609046533: return bem_msgSet_1(bevd_0);
case -546115402: return bem_klassNameSet_1(bevd_0);
case 686839432: return bem_vvSet_1(bevd_0);
case -960682151: return bem_framesSetDirect_1(bevd_0);
case -1507083548: return bem_otherClass_1(bevd_0);
case 1384684128: return bem_nodeSet_1(bevd_0);
case 849935344: return bem_methodNameSet_1(bevd_0);
case -13945303: return bem_defined_1(bevd_0);
case -1680819360: return bem_undefined_1(bevd_0);
case 1652682620: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -396792969: return bem_otherType_1(bevd_0);
case 76576094: return bem_msgSetDirect_1(bevd_0);
case -392551410: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -275059833: return bem_lineNumberSetDirect_1(bevd_0);
case -149148452: return bem_copyTo_1(bevd_0);
case -1627031099: return bem_nodeSetDirect_1(bevd_0);
case 468416774: return bem_klassNameSetDirect_1(bevd_0);
case 13577034: return bem_def_1(bevd_0);
case 1804735528: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 650559056: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -20866101: return bem_fileNameSetDirect_1(bevd_0);
case 1322048808: return bem_emitLangSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 276198978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -931383679: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 62716626: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513618976: return bem_new_2(bevd_0, bevd_1);
case 1047719554: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -927828157: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1041543114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1611590654: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1175245602: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_10_BuildVisitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
}
