namespace be {
/* IO:File: source/build/Errors.be */
public class BEC_2_5_10_BuildVisitError : BEC_2_6_9_SystemException {
public BEC_2_5_10_BuildVisitError() { }
static BEC_2_5_10_BuildVisitError() { }
private static byte[] becc_BEC_2_5_10_BuildVisitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_10_BuildVisitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x72,0x72,0x6F,0x72,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_10_BuildVisitError_bels_0 = {};
public static new BEC_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_inst;

public static new BET_2_5_10_BuildVisitError bece_BEC_2_5_10_BuildVisitError_bevs_type;

public BEC_2_6_6_SystemObject bevp_msg;
public BEC_2_6_6_SystemObject bevp_node;
public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_msgi) {
bevp_msg = beva_msgi;
return this;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_new_2(BEC_2_6_6_SystemObject beva_msgi, BEC_2_6_6_SystemObject beva_nodei) {
bevp_msg = beva_msgi;
bevp_node = beva_nodei;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_nc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevl_toRet = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_10_BuildVisitError_bels_0));
if (bevp_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 25 */ {
bevt_1_tmpany_phold = bevl_toRet.bemd_1(700838626, bevp_msg);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_newlineGet_0();
bevl_toRet = bevt_1_tmpany_phold.bemd_1(700838626, bevt_2_tmpany_phold);
} /* Line: 26 */
if (bevp_node == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 28 */ {
bevl_nc = bevp_node;
while (true)
 /* Line: 30 */ {
if (bevl_nc == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 30 */ {
bevl_toRet.bemd_1(-1977071910, bevl_nc);
bevt_7_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_newlineGet_0();
bevl_toRet.bemd_1(-1977071910, bevt_6_tmpany_phold);
bevl_nc = bevl_nc.bemd_0(-64139232);
} /* Line: 33 */
 else  /* Line: 30 */ {
break;
} /* Line: 30 */
} /* Line: 30 */
} /* Line: 30 */
bevt_8_tmpany_phold = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(700838626, bevt_8_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_msgGet_0() {
return bevp_msg;
} /*method end*/
public BEC_2_6_6_SystemObject bem_msgGetDirect_0() {
return bevp_msg;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_msgSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_msgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_msg = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_nodeGet_0() {
return bevp_node;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nodeGetDirect_0() {
return bevp_node;
} /*method end*/
public virtual BEC_2_5_10_BuildVisitError bem_nodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildVisitError bem_nodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_node = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {11, 16, 17, 24, 25, 25, 26, 26, 26, 26, 28, 28, 29, 30, 30, 31, 32, 32, 32, 33, 36, 36, 37, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 20, 21, 36, 37, 42, 43, 44, 45, 46, 48, 53, 54, 57, 62, 63, 64, 65, 66, 67, 74, 75, 76, 79, 82, 85, 89, 93, 96, 99, 103};
/* BEGIN LINEINFO 
assign 1 11 16
assign 1 16 20
assign 1 17 21
assign 1 24 36
new 0 24 36
assign 1 25 37
def 1 25 42
assign 1 26 43
add 1 26 43
assign 1 26 44
new 0 26 44
assign 1 26 45
newlineGet 0 26 45
assign 1 26 46
add 1 26 46
assign 1 28 48
def 1 28 53
assign 1 29 54
assign 1 30 57
def 1 30 62
addValue 1 31 63
assign 1 32 64
new 0 32 64
assign 1 32 65
newlineGet 0 32 65
addValue 1 32 66
assign 1 33 67
containerGet 0 33 67
assign 1 36 74
getFrameText 0 36 74
assign 1 36 75
add 1 36 75
return 1 37 76
return 1 0 79
return 1 0 82
assign 1 0 85
assign 1 0 89
return 1 0 93
return 1 0 96
assign 1 0 99
assign 1 0 103
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1242864862: return bem_sourceFileNameGet_0();
case -1363935153: return bem_langGetDirect_0();
case 1546600427: return bem_vvGetDirect_0();
case 1388220454: return bem_once_0();
case 1978340744: return bem_copy_0();
case -893140774: return bem_msgGet_0();
case 1267081794: return bem_methodNameGet_0();
case -588447981: return bem_emitLangGet_0();
case -485032950: return bem_print_0();
case 1076431645: return bem_lineNumberGetDirect_0();
case 1139687182: return bem_serializeToString_0();
case -1666892197: return bem_translateEmittedException_0();
case 2117688255: return bem_nodeGet_0();
case -1191467783: return bem_framesGetDirect_0();
case -1936404363: return bem_create_0();
case -533304425: return bem_framesTextGet_0();
case -1461089031: return bem_translatedGetDirect_0();
case 1115941233: return bem_hashGet_0();
case 1976427553: return bem_klassNameGetDirect_0();
case 347445468: return bem_deserializeClassNameGet_0();
case 1397900268: return bem_msgGetDirect_0();
case 1809234022: return bem_framesTextGetDirect_0();
case -380774728: return bem_serializationIteratorGet_0();
case 1044385788: return bem_new_0();
case 600528685: return bem_lineNumberGet_0();
case 1339527550: return bem_klassNameGet_0();
case 876979386: return bem_iteratorGet_0();
case 262448459: return bem_fieldNamesGet_0();
case 1846641427: return bem_classNameGet_0();
case 1222284310: return bem_translateEmittedExceptionInner_0();
case 1663093821: return bem_nodeGetDirect_0();
case -888974938: return bem_descriptionGet_0();
case -139211751: return bem_framesGet_0();
case 1109517661: return bem_emitLangGetDirect_0();
case -1718750264: return bem_tagGet_0();
case 1023220234: return bem_translatedGet_0();
case -1287291624: return bem_toString_0();
case -1030747721: return bem_methodNameGetDirect_0();
case -1820718044: return bem_echo_0();
case 1039576783: return bem_vvGet_0();
case 1348460493: return bem_fileNameGetDirect_0();
case -1889562117: return bem_descriptionGetDirect_0();
case -1283336034: return bem_langGet_0();
case 1516511629: return bem_serializeContents_0();
case -418256728: return bem_fileNameGet_0();
case -2113195206: return bem_getFrameText_0();
case -1497387944: return bem_many_0();
case 1739040137: return bem_fieldIteratorGet_0();
case 855089063: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2098981350: return bem_methodNameSetDirect_1(bevd_0);
case -784770856: return bem_framesTextSetDirect_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case -2135475151: return bem_emitLangSetDirect_1(bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case -1465831844: return bem_new_1(bevd_0);
case 1489007559: return bem_vvSet_1(bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1575911030: return bem_lineNumberSet_1(bevd_0);
case 205689082: return bem_lineNumberSetDirect_1(bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case 1239361667: return bem_methodNameSet_1(bevd_0);
case -627862337: return bem_translatedSetDirect_1(bevd_0);
case -1010984900: return bem_nodeSet_1(bevd_0);
case -630597728: return bem_klassNameSetDirect_1(bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 791565359: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case 1404127527: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1136666389: return bem_emitLangSet_1(bevd_0);
case 2022005382: return bem_descriptionSet_1(bevd_0);
case 301718756: return bem_vvSetDirect_1(bevd_0);
case 383466691: return bem_framesTextSet_1(bevd_0);
case 1388023994: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case -1885890319: return bem_fileNameSet_1(bevd_0);
case -847200836: return bem_def_1(bevd_0);
case -82611809: return bem_msgSetDirect_1(bevd_0);
case 1465976030: return bem_translatedSet_1(bevd_0);
case -2146658960: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 2109739292: return bem_nodeSetDirect_1(bevd_0);
case 1769191019: return bem_langSet_1(bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case -178401294: return bem_klassNameSet_1(bevd_0);
case -857760198: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1281786394: return bem_msgSet_1(bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case -621631535: return bem_descriptionSetDirect_1(bevd_0);
case 67916180: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1335269315: return bem_fileNameSetDirect_1(bevd_0);
case 2117320848: return bem_framesSet_1(bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case -1631337922: return bem_framesSetDirect_1(bevd_0);
case 477404510: return bem_undefined_1(bevd_0);
case 1812900623: return bem_langSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1887722661: return bem_new_2(bevd_0, bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1722657179: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_5_10_BuildVisitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_5_10_BuildVisitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_10_BuildVisitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst = (BEC_2_5_10_BuildVisitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_10_BuildVisitError.bece_BEC_2_5_10_BuildVisitError_bevs_type;
}
}
}
