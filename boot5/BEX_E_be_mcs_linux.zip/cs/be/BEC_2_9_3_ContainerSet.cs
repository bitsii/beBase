namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet : BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
static BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_5 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_3_ContainerSet_bevo_7 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static new BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_0;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 234 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_1;
if (bevp_size.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /* Line: 241 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_modu.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_21_ContainerSetSerializationIterator) (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
 /* Line: 259 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_4_tmpany_phold = bevl_ni.bem_keyGet_0();
bevt_3_tmpany_phold = bem_innerPut_4(bevt_4_tmpany_phold, null, bevl_ni, beva_ninner);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-393670001);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 262 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 263 */
} /* Line: 262 */
} /* Line: 261 */
 else  /* Line: 259 */ {
break;
} /* Line: 259 */
} /* Line: 259 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = beva_slt.bem_sizeGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(bevp_multi);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_2;
bevl_nslots = bevt_0_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
 /* Line: 274 */ {
bevt_4_tmpany_phold = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-393670001);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 274 */ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 276 */
 else  /* Line: 274 */ {
break;
} /* Line: 274 */
} /* Line: 274 */
return bevl_ninner;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_other == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_4_tmpany_phold = beva_other.bem_sizeGet_0();
bevt_5_tmpany_phold = bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 282 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 282 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 282 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 283 */
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 285 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_9_tmpany_phold = beva_other.bem_has_1(bevl_i);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 286 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /* Line: 286 */
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 293 */ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_3;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 295 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 296 */
} /* Line: 295 */
 else  /* Line: 298 */ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(-448727787);
} /* Line: 299 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 303 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 305 */ {
if (beva_inode == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 306 */ {
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpany_phold.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_tmpany_phold);
} /* Line: 307 */
 else  /* Line: 308 */ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 309 */
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 312 */
 else  /* Line: 305 */ {
bevt_10_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_9_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 313 */ {
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /* Line: 314 */
 else  /* Line: 305 */ {
bevt_13_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_12_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_13_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 315 */ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_tmpany_phold;
} /* Line: 319 */
 else  /* Line: 320 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_tmpany_phold;
} /* Line: 323 */
} /* Line: 322 */
} /* Line: 305 */
} /* Line: 305 */
} /* Line: 305 */
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-393670001);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
 /* Line: 333 */ {
bevt_3_tmpany_phold = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-393670001);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 333 */ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 334 */
 else  /* Line: 333 */ {
break;
} /* Line: 333 */
} /* Line: 333 */
bevp_slots = bevl_slt;
} /* Line: 336 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 338 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 339 */
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_4;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 347 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 348 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 352 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 354 */ {
return null;
} /* Line: 355 */
 else  /* Line: 354 */ {
bevt_5_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_4_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 356 */ {
return null;
} /* Line: 357 */
 else  /* Line: 354 */ {
bevt_7_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_6_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_7_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 358 */ {
bevt_8_tmpany_phold = bevl_n.bem_getFrom_0();
return bevt_8_tmpany_phold;
} /* Line: 359 */
 else  /* Line: 360 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 362 */ {
return null;
} /* Line: 363 */
} /* Line: 362 */
} /* Line: 354 */
} /* Line: 354 */
} /* Line: 354 */
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_5;
if (bevl_hval.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 374 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 378 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 380 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /* Line: 381 */
 else  /* Line: 380 */ {
bevt_6_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_5_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /* Line: 383 */
 else  /* Line: 380 */ {
bevt_9_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_8_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_9_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 384 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 385 */
 else  /* Line: 386 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_tmpany_phold;
} /* Line: 389 */
} /* Line: 388 */
} /* Line: 380 */
} /* Line: 380 */
} /* Line: 380 */
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_6;
if (bevl_hval.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 400 */ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 401 */
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
 /* Line: 405 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 407 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 408 */
 else  /* Line: 407 */ {
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_6_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 410 */
 else  /* Line: 407 */ {
bevt_10_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevp_rel.bem_isEqual_2(bevt_10_tmpany_phold, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_tmpany_phold).bevi_bool) /* Line: 411 */ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
 /* Line: 415 */ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 415 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_15_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_modulus_1(bevl_modu);
if (bevt_14_tmpany_phold.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 417 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 417 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 417 */ {
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_16_tmpany_phold;
} /* Line: 418 */
 else  /* Line: 419 */ {
bevt_18_tmpany_phold = bece_BEC_2_9_3_ContainerSet_bevo_7;
bevt_17_tmpany_phold = bevl_sl.bem_subtract_1(bevt_18_tmpany_phold);
bevl_slt.bem_put_2(bevt_17_tmpany_phold, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 421 */
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 423 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
bevt_19_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_19_tmpany_phold;
} /* Line: 425 */
 else  /* Line: 426 */ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 428 */ {
bevt_21_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_21_tmpany_phold;
} /* Line: 429 */
} /* Line: 428 */
} /* Line: 407 */
} /* Line: 407 */
} /* Line: 407 */
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_tmpany_phold = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bevp_slots.bem_copy_0();
bevl_other.bemd_1(-186400864, bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 439 */ {
bevt_2_tmpany_phold = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 441 */ {
bevt_4_tmpany_phold = bevl_other.bemd_0(-37143834);
bevt_6_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_tmpany_phold = bevl_n.bem_hvalGet_0();
bevt_8_tmpany_phold = bevl_n.bem_keyGet_0();
bevt_9_tmpany_phold = bevl_n.bem_getFrom_0();
bevt_5_tmpany_phold = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_tmpany_phold.bem_new_3(bevt_7_tmpany_phold, bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_4_tmpany_phold.bemd_2(360013839, bevl_i, bevt_5_tmpany_phold);
} /* Line: 442 */
 else  /* Line: 443 */ {
bevt_10_tmpany_phold = bevl_other.bemd_0(-37143834);
bevt_10_tmpany_phold.bemd_2(360013839, bevl_i, null);
} /* Line: 444 */
bevl_i = bevl_i.bem_increment_0();
} /* Line: 439 */
 else  /* Line: 439 */ {
break;
} /* Line: 439 */
} /* Line: 439 */
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_clear_0() {
bevp_slots.bem_clear_0();
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_keyIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_nodeIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 482 */ {
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 483 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 483 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = beva_other.bem_has_1(bevl_x);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 484 */ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 485 */
} /* Line: 484 */
 else  /* Line: 483 */ {
break;
} /* Line: 483 */
} /* Line: 483 */
} /* Line: 483 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_tmpany_loop = bem_setIteratorGet_0();
while (true)
 /* Line: 494 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 494 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 495 */
 else  /* Line: 494 */ {
break;
} /* Line: 494 */
} /* Line: 494 */
if (beva_other == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevt_1_tmpany_loop = beva_other.bem_setIteratorGet_0();
while (true)
 /* Line: 498 */ {
bevt_4_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevl_x = bevt_1_tmpany_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 499 */
 else  /* Line: 498 */ {
break;
} /* Line: 498 */
} /* Line: 498 */
} /* Line: 498 */
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_2_9_3_ContainerSet) bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 512 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(-1146451068, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 513 */ {
bevt_0_tmpany_loop = beva_other.bemd_0(876979386);
while (true)
 /* Line: 514 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bemd_0(463055371);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 514 */ {
bevl_x = bevt_0_tmpany_loop.bemd_0(-694819228);
bem_put_1(bevl_x);
} /* Line: 515 */
 else  /* Line: 514 */ {
break;
} /* Line: 514 */
} /* Line: 514 */
} /* Line: 514 */
 else  /* Line: 513 */ {
bevt_4_tmpany_phold = beva_other.bemd_1(-1146451068, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 517 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(2105223545);
bem_put_1(bevt_5_tmpany_phold);
} /* Line: 518 */
 else  /* Line: 519 */ {
bem_put_1(beva_other);
} /* Line: 520 */
} /* Line: 513 */
} /* Line: 513 */
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGetDirect_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGetDirect_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_multiGet_0() {
return bevp_multi;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGetDirect_0() {
return bevp_multi;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_multiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() {
return bevp_rel;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGetDirect_0() {
return bevp_rel;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_relSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() {
return bevp_baseNode;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGetDirect_0() {
return bevp_baseNode;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_baseNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGetDirect_0() {
return bevp_innerPutAdded;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_innerPutAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {215, 215, 221, 222, 223, 224, 225, 226, 227, 233, 233, 233, 234, 234, 236, 236, 240, 240, 240, 241, 241, 243, 243, 247, 247, 251, 251, 255, 255, 259, 259, 260, 261, 261, 262, 262, 262, 263, 263, 267, 267, 272, 272, 272, 272, 273, 274, 274, 275, 276, 278, 282, 282, 0, 282, 282, 282, 282, 0, 0, 283, 283, 285, 0, 285, 285, 286, 286, 286, 286, 286, 288, 288, 292, 293, 293, 294, 295, 295, 295, 296, 299, 301, 302, 304, 305, 305, 306, 306, 307, 307, 307, 309, 311, 312, 312, 313, 313, 313, 313, 314, 314, 315, 315, 316, 318, 319, 319, 321, 322, 322, 323, 323, 330, 330, 331, 332, 333, 333, 334, 336, 339, 344, 345, 346, 347, 347, 347, 348, 350, 351, 353, 354, 354, 355, 356, 356, 356, 356, 357, 358, 358, 359, 359, 361, 362, 362, 363, 370, 371, 372, 373, 373, 373, 374, 376, 377, 379, 380, 380, 381, 381, 382, 382, 382, 382, 383, 383, 384, 384, 385, 385, 387, 388, 388, 389, 389, 396, 397, 399, 400, 400, 400, 401, 403, 404, 406, 407, 407, 408, 408, 409, 409, 409, 409, 410, 410, 411, 411, 412, 413, 414, 415, 415, 416, 417, 417, 0, 417, 417, 417, 417, 0, 0, 418, 418, 420, 420, 420, 421, 423, 425, 425, 427, 428, 428, 429, 429, 436, 437, 438, 438, 439, 439, 439, 439, 440, 441, 441, 442, 442, 442, 442, 442, 442, 442, 444, 444, 439, 447, 452, 453, 457, 457, 461, 461, 465, 465, 469, 469, 473, 473, 477, 477, 481, 482, 482, 483, 0, 483, 483, 484, 485, 489, 493, 494, 0, 494, 494, 495, 497, 497, 498, 0, 498, 498, 499, 502, 506, 507, 508, 512, 512, 513, 514, 0, 514, 514, 515, 517, 518, 518, 520, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {29, 30, 34, 35, 36, 37, 38, 39, 40, 48, 49, 54, 55, 56, 58, 59, 66, 67, 72, 73, 74, 76, 77, 81, 82, 86, 87, 92, 93, 105, 108, 110, 111, 116, 117, 118, 119, 121, 122, 130, 131, 141, 142, 143, 144, 145, 148, 149, 151, 152, 158, 174, 179, 180, 183, 184, 185, 190, 191, 194, 198, 199, 201, 201, 204, 206, 207, 208, 213, 214, 215, 222, 223, 248, 249, 254, 255, 256, 257, 262, 263, 267, 269, 270, 273, 274, 279, 280, 285, 286, 287, 288, 291, 293, 294, 295, 298, 299, 300, 305, 306, 307, 310, 311, 313, 314, 315, 316, 319, 320, 325, 326, 327, 340, 341, 343, 344, 347, 348, 350, 356, 359, 380, 381, 382, 383, 384, 389, 390, 392, 393, 396, 397, 402, 403, 406, 407, 408, 413, 414, 417, 418, 420, 421, 424, 425, 430, 431, 458, 459, 460, 461, 462, 467, 468, 470, 471, 474, 475, 480, 481, 482, 485, 486, 487, 492, 493, 494, 497, 498, 500, 501, 504, 505, 510, 511, 512, 548, 549, 550, 551, 552, 557, 558, 560, 561, 564, 565, 570, 571, 572, 575, 576, 577, 582, 583, 584, 587, 588, 590, 591, 592, 595, 600, 601, 602, 607, 608, 611, 612, 613, 618, 619, 622, 626, 627, 630, 631, 632, 633, 635, 641, 642, 645, 646, 651, 652, 653, 675, 676, 677, 678, 679, 682, 683, 688, 689, 690, 695, 696, 697, 698, 699, 700, 701, 702, 705, 706, 708, 714, 717, 718, 723, 724, 728, 729, 733, 734, 738, 739, 743, 744, 748, 749, 758, 759, 764, 765, 765, 768, 770, 771, 773, 781, 791, 792, 792, 795, 797, 798, 804, 809, 810, 810, 813, 815, 816, 823, 827, 828, 829, 839, 844, 845, 847, 847, 850, 852, 853, 861, 863, 864, 867, 874, 877, 880, 884, 888, 891, 894, 898, 902, 905, 908, 912, 916, 919, 922, 926, 930, 933, 936, 940, 944, 947, 950, 954, 958, 961, 964, 968};
/* BEGIN LINEINFO 
assign 1 215 29
new 0 215 29
new 1 215 30
assign 1 221 34
new 1 221 34
assign 1 222 35
assign 1 223 36
new 0 223 36
assign 1 224 37
new 0 224 37
assign 1 225 38
new 0 225 38
assign 1 226 39
new 0 226 39
assign 1 227 40
new 0 227 40
assign 1 233 48
new 0 233 48
assign 1 233 49
equals 1 233 54
assign 1 234 55
new 0 234 55
return 1 234 56
assign 1 236 58
new 0 236 58
return 1 236 59
assign 1 240 66
new 0 240 66
assign 1 240 67
equals 1 240 72
assign 1 241 73
new 0 241 73
return 1 241 74
assign 1 243 76
new 0 243 76
return 1 243 77
assign 1 247 81
toString 0 247 81
return 1 247 82
assign 1 251 86
new 1 251 86
new 1 251 87
assign 1 255 92
new 1 255 92
return 1 255 93
assign 1 259 105
arrayIteratorGet 0 259 105
assign 1 259 108
hasNextGet 0 259 108
assign 1 260 110
nextGet 0 260 110
assign 1 261 111
def 1 261 116
assign 1 262 117
keyGet 0 262 117
assign 1 262 118
innerPut 4 262 118
assign 1 262 119
not 0 262 119
assign 1 263 121
new 0 263 121
return 1 263 122
assign 1 267 130
new 0 267 130
return 1 267 131
assign 1 272 141
sizeGet 0 272 141
assign 1 272 142
multiply 1 272 142
assign 1 272 143
new 0 272 143
assign 1 272 144
add 1 272 144
assign 1 273 145
new 1 273 145
assign 1 274 148
insertAll 2 274 148
assign 1 274 149
not 0 274 149
assign 1 275 151
increment 0 275 151
assign 1 276 152
new 1 276 152
return 1 278 158
assign 1 282 174
undef 1 282 179
assign 1 0 180
assign 1 282 183
sizeGet 0 282 183
assign 1 282 184
sizeGet 0 282 184
assign 1 282 185
notEquals 1 282 190
assign 1 0 191
assign 1 0 194
assign 1 283 198
new 0 283 198
return 1 283 199
assign 1 285 201
setIteratorGet 0 0 201
assign 1 285 204
hasNextGet 0 285 204
assign 1 285 206
nextGet 0 285 206
assign 1 286 207
has 1 286 207
assign 1 286 208
not 0 286 213
assign 1 286 214
new 0 286 214
return 1 286 215
assign 1 288 222
new 0 288 222
return 1 288 223
assign 1 292 248
sizeGet 0 292 248
assign 1 293 249
undef 1 293 254
assign 1 294 255
getHash 1 294 255
assign 1 295 256
new 0 295 256
assign 1 295 257
lesser 1 295 262
assign 1 296 263
abs 0 296 263
assign 1 299 267
hvalGet 0 299 267
assign 1 301 269
modulus 1 301 269
assign 1 302 270
assign 1 304 273
get 1 304 273
assign 1 305 274
undef 1 305 279
assign 1 306 280
undef 1 306 285
assign 1 307 286
create 0 307 286
assign 1 307 287
new 3 307 287
put 2 307 288
put 2 309 291
assign 1 311 293
new 0 311 293
assign 1 312 294
new 0 312 294
return 1 312 295
assign 1 313 298
hvalGet 0 313 298
assign 1 313 299
modulus 1 313 299
assign 1 313 300
notEquals 1 313 305
assign 1 314 306
new 0 314 306
return 1 314 307
assign 1 315 310
keyGet 0 315 310
assign 1 315 311
isEqual 2 315 311
putTo 2 316 313
assign 1 318 314
new 0 318 314
assign 1 319 315
new 0 319 315
return 1 319 316
assign 1 321 319
increment 0 321 319
assign 1 322 320
greaterEquals 1 322 325
assign 1 323 326
new 0 323 326
return 1 323 327
assign 1 330 340
innerPut 4 330 340
assign 1 330 341
not 0 330 341
assign 1 331 343
assign 1 332 344
rehash 1 332 344
assign 1 333 347
innerPut 4 333 347
assign 1 333 348
not 0 333 348
assign 1 334 350
rehash 1 334 350
assign 1 336 356
assign 1 339 359
increment 0 339 359
assign 1 344 380
assign 1 345 381
sizeGet 0 345 381
assign 1 346 382
getHash 1 346 382
assign 1 347 383
new 0 347 383
assign 1 347 384
lesser 1 347 389
assign 1 348 390
abs 0 348 390
assign 1 350 392
modulus 1 350 392
assign 1 351 393
assign 1 353 396
get 1 353 396
assign 1 354 397
undef 1 354 402
return 1 355 403
assign 1 356 406
hvalGet 0 356 406
assign 1 356 407
modulus 1 356 407
assign 1 356 408
notEquals 1 356 413
return 1 357 414
assign 1 358 417
keyGet 0 358 417
assign 1 358 418
isEqual 2 358 418
assign 1 359 420
getFrom 0 359 420
return 1 359 421
assign 1 361 424
increment 0 361 424
assign 1 362 425
greaterEquals 1 362 430
return 1 363 431
assign 1 370 458
assign 1 371 459
sizeGet 0 371 459
assign 1 372 460
getHash 1 372 460
assign 1 373 461
new 0 373 461
assign 1 373 462
lesser 1 373 467
assign 1 374 468
abs 0 374 468
assign 1 376 470
modulus 1 376 470
assign 1 377 471
assign 1 379 474
get 1 379 474
assign 1 380 475
undef 1 380 480
assign 1 381 481
new 0 381 481
return 1 381 482
assign 1 382 485
hvalGet 0 382 485
assign 1 382 486
modulus 1 382 486
assign 1 382 487
notEquals 1 382 492
assign 1 383 493
new 0 383 493
return 1 383 494
assign 1 384 497
keyGet 0 384 497
assign 1 384 498
isEqual 2 384 498
assign 1 385 500
new 0 385 500
return 1 385 501
assign 1 387 504
increment 0 387 504
assign 1 388 505
greaterEquals 1 388 510
assign 1 389 511
new 0 389 511
return 1 389 512
assign 1 396 548
assign 1 397 549
sizeGet 0 397 549
assign 1 399 550
getHash 1 399 550
assign 1 400 551
new 0 400 551
assign 1 400 552
lesser 1 400 557
assign 1 401 558
abs 0 401 558
assign 1 403 560
modulus 1 403 560
assign 1 404 561
assign 1 406 564
get 1 406 564
assign 1 407 565
undef 1 407 570
assign 1 408 571
new 0 408 571
return 1 408 572
assign 1 409 575
hvalGet 0 409 575
assign 1 409 576
modulus 1 409 576
assign 1 409 577
notEquals 1 409 582
assign 1 410 583
new 0 410 583
return 1 410 584
assign 1 411 587
keyGet 0 411 587
assign 1 411 588
isEqual 2 411 588
put 2 412 590
assign 1 413 591
decrement 0 413 591
assign 1 414 592
increment 0 414 592
assign 1 415 595
lesser 1 415 600
assign 1 416 601
get 1 416 601
assign 1 417 602
undef 1 417 607
assign 1 0 608
assign 1 417 611
hvalGet 0 417 611
assign 1 417 612
modulus 1 417 612
assign 1 417 613
notEquals 1 417 618
assign 1 0 619
assign 1 0 622
assign 1 418 626
new 0 418 626
return 1 418 627
assign 1 420 630
new 0 420 630
assign 1 420 631
subtract 1 420 631
put 2 420 632
put 2 421 633
assign 1 423 635
increment 0 423 635
assign 1 425 641
new 0 425 641
return 1 425 642
assign 1 427 645
increment 0 427 645
assign 1 428 646
greaterEquals 1 428 651
assign 1 429 652
new 0 429 652
return 1 429 653
assign 1 436 675
create 0 436 675
copyTo 1 437 676
assign 1 438 677
copy 0 438 677
slotsSet 1 438 678
assign 1 439 679
new 0 439 679
assign 1 439 682
lengthGet 0 439 682
assign 1 439 683
lesser 1 439 688
assign 1 440 689
get 1 440 689
assign 1 441 690
def 1 441 695
assign 1 442 696
slotsGet 0 442 696
assign 1 442 697
create 0 442 697
assign 1 442 698
hvalGet 0 442 698
assign 1 442 699
keyGet 0 442 699
assign 1 442 700
getFrom 0 442 700
assign 1 442 701
new 3 442 701
put 2 442 702
assign 1 444 705
slotsGet 0 444 705
put 2 444 706
assign 1 439 708
increment 0 439 708
return 1 447 714
clear 0 452 717
assign 1 453 718
new 0 453 718
assign 1 457 723
new 1 457 723
return 1 457 724
assign 1 461 728
new 1 461 728
return 1 461 729
assign 1 465 733
new 1 465 733
return 1 465 734
assign 1 469 738
keyIteratorGet 0 469 738
return 1 469 739
assign 1 473 743
new 1 473 743
return 1 473 744
assign 1 477 748
nodeIteratorGet 0 477 748
return 1 477 749
assign 1 481 758
new 0 481 758
assign 1 482 759
def 1 482 764
assign 1 483 765
setIteratorGet 0 0 765
assign 1 483 768
hasNextGet 0 483 768
assign 1 483 770
nextGet 0 483 770
assign 1 484 771
has 1 484 771
put 1 485 773
return 1 489 781
assign 1 493 791
new 0 493 791
assign 1 494 792
setIteratorGet 0 0 792
assign 1 494 795
hasNextGet 0 494 795
assign 1 494 797
nextGet 0 494 797
put 1 495 798
assign 1 497 804
def 1 497 809
assign 1 498 810
setIteratorGet 0 0 810
assign 1 498 813
hasNextGet 0 498 813
assign 1 498 815
nextGet 0 498 815
put 1 499 816
return 1 502 823
assign 1 506 827
copy 0 506 827
addValue 1 507 828
return 1 508 829
assign 1 512 839
def 1 512 844
assign 1 513 845
sameType 1 513 845
assign 1 514 847
iteratorGet 0 0 847
assign 1 514 850
hasNextGet 0 514 850
assign 1 514 852
nextGet 0 514 852
put 1 515 853
assign 1 517 861
sameType 1 517 861
assign 1 518 863
keyGet 0 518 863
put 1 518 864
put 1 520 867
return 1 0 874
return 1 0 877
assign 1 0 880
assign 1 0 884
return 1 0 888
return 1 0 891
assign 1 0 894
assign 1 0 898
return 1 0 902
return 1 0 905
assign 1 0 908
assign 1 0 912
return 1 0 916
return 1 0 919
assign 1 0 922
assign 1 0 926
return 1 0 930
return 1 0 933
assign 1 0 936
assign 1 0 940
return 1 0 944
return 1 0 947
assign 1 0 950
assign 1 0 954
return 1 0 958
return 1 0 961
assign 1 0 964
assign 1 0 968
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1242864862: return bem_sourceFileNameGet_0();
case -872928218: return bem_setIteratorGet_0();
case 236290177: return bem_clear_0();
case 347445468: return bem_deserializeClassNameGet_0();
case 123135140: return bem_baseNodeGet_0();
case -1287291624: return bem_toString_0();
case 901469825: return bem_keysGet_0();
case -1718750264: return bem_tagGet_0();
case 1415715320: return bem_multiGetDirect_0();
case 75862554: return bem_slotsGetDirect_0();
case 1739040137: return bem_fieldIteratorGet_0();
case 95635585: return bem_isEmptyGet_0();
case -638559494: return bem_innerPutAddedGetDirect_0();
case -1497387944: return bem_many_0();
case -194644176: return bem_relGetDirect_0();
case -1598532292: return bem_innerPutAddedGet_0();
case -421813365: return bem_relGet_0();
case 855089063: return bem_toAny_0();
case -1820718044: return bem_echo_0();
case 1388220454: return bem_once_0();
case 1115941233: return bem_hashGet_0();
case 860480151: return bem_sizeGet_0();
case 876979386: return bem_iteratorGet_0();
case -216232255: return bem_nodeIteratorGet_0();
case 262448459: return bem_fieldNamesGet_0();
case -37143834: return bem_slotsGet_0();
case 1139687182: return bem_serializeToString_0();
case 1044385788: return bem_new_0();
case -380774728: return bem_serializationIteratorGet_0();
case -1790132883: return bem_moduGet_0();
case 291901948: return bem_keyIteratorGet_0();
case 1516511629: return bem_serializeContents_0();
case -1936404363: return bem_create_0();
case 760802946: return bem_baseNodeGetDirect_0();
case 1846641427: return bem_classNameGet_0();
case -21452594: return bem_sizeGetDirect_0();
case -485032950: return bem_print_0();
case -170151734: return bem_notEmptyGet_0();
case 1502067215: return bem_moduGetDirect_0();
case -1628844979: return bem_nodesGet_0();
case 1978340744: return bem_copy_0();
case -391792840: return bem_multiGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2139223904: return bem_moduSetDirect_1(bevd_0);
case -751818663: return bem_baseNodeSetDirect_1(bevd_0);
case 2074542901: return bem_sizeSet_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case -1465831844: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 178386925: return bem_get_1(bevd_0);
case 574264917: return bem_innerPutAddedSetDirect_1(bevd_0);
case -1917117688: return bem_has_1(bevd_0);
case 757423185: return bem_put_1(bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case -1160084495: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case -186400864: return bem_slotsSet_1(bevd_0);
case 1910406041: return bem_moduSet_1(bevd_0);
case -1609788986: return bem_baseNodeSet_1(bevd_0);
case -1752672892: return bem_innerPutAddedSet_1(bevd_0);
case -78150587: return bem_relSet_1(bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case 497812126: return bem_sizeSetDirect_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case -847200836: return bem_def_1(bevd_0);
case 363343156: return bem_multiSet_1(bevd_0);
case -1977071910: return bem_addValue_1(bevd_0);
case 777649215: return bem_delete_1(bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case 2097962823: return bem_multiSetDirect_1(bevd_0);
case -663392281: return bem_relSetDirect_1(bevd_0);
case -440204786: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case 365676072: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1996492370: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case 458470087: return bem_slotsSetDirect_1(bevd_0);
case 700838626: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case 477404510: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 16788426: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1809883543: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerSet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
}
