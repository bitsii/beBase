namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerSet : BEC_2_6_6_SystemObject {
public BEC_2_9_3_ContainerSet() { }
static BEC_2_9_3_ContainerSet() { }
private static byte[] becc_BEC_2_9_3_ContainerSet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_3_ContainerSet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_inst;

public static new BET_2_9_3_ContainerSet bece_BEC_2_9_3_ContainerSet_bevs_type;

public BEC_2_9_4_ContainerList bevp_slots;
public BEC_2_4_3_MathInt bevp_modu;
public BEC_2_4_3_MathInt bevp_multi;
public BEC_3_9_3_9_ContainerSetRelations bevp_rel;
public BEC_3_9_3_7_ContainerSetSetNode bevp_baseNode;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_innerPutAdded;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 232*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 233*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_notEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /* Line: 240*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_modu.bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerSetSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_9_3_21_ContainerSetSerializationIterator) (new BEC_3_9_3_21_ContainerSetSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_insertAll_2(BEC_2_9_4_ContainerList beva_ninner, BEC_2_9_4_ContainerList beva_ir) {
BEC_3_9_4_8_ContainerListIterator bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_ni = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevl_i = beva_ir.bem_arrayIteratorGet_0();
while (true)
/* Line: 258*/ {
bevt_0_ta_ph = bevl_i.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 258*/ {
bevl_ni = (BEC_3_9_3_7_ContainerSetSetNode) bevl_i.bem_nextGet_0();
if (bevl_ni == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_4_ta_ph = bevl_ni.bem_keyGet_0();
bevt_3_ta_ph = bem_innerPut_4(bevt_4_ta_ph, null, bevl_ni, beva_ninner);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-534139924);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 261*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 262*/
} /* Line: 261*/
} /* Line: 260*/
 else /* Line: 258*/ {
break;
} /* Line: 258*/
} /* Line: 258*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_rehash_1(BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_nslots = null;
BEC_2_9_4_ContainerList bevl_ninner = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = beva_slt.bem_sizeGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_multiply_1(bevp_multi);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_nslots = bevt_0_ta_ph.bem_add_1(bevt_2_ta_ph);
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
while (true)
/* Line: 273*/ {
bevt_4_ta_ph = bem_insertAll_2(bevl_ninner, beva_slt);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-534139924);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 273*/ {
bevl_nslots = bevl_nslots.bem_increment_0();
bevl_ninner = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_nslots);
} /* Line: 275*/
 else /* Line: 273*/ {
break;
} /* Line: 273*/
} /* Line: 273*/
return bevl_ninner;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
if (beva_other == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 281*/ {
bevt_4_ta_ph = beva_other.bem_sizeGet_0();
bevt_5_ta_ph = bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int != bevt_5_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 281*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 281*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 281*/ {
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 282*/
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 284*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_7_ta_ph.bevi_bool)/* Line: 284*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_9_ta_ph = beva_other.bem_has_1(bevl_i);
if (bevt_9_ta_ph.bevi_bool) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 285*/ {
bevt_10_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 285*/
} /* Line: 285*/
 else /* Line: 284*/ {
break;
} /* Line: 284*/
} /* Line: 284*/
bevt_11_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_innerPut_4(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v, BEC_2_6_6_SystemObject beva_inode, BEC_2_9_4_ContainerList beva_slt) {
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
bevl_modu = beva_slt.bem_sizeGet_0();
if (beva_inode == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 292*/ {
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 294*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 295*/
} /* Line: 294*/
 else /* Line: 297*/ {
bevl_hval = (BEC_2_4_3_MathInt) beva_inode.bemd_0(-320681163);
} /* Line: 298*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 302*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) beva_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 304*/ {
if (beva_inode == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 305*/ {
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_5_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_ta_ph.bem_new_3(bevl_hval, beva_k, beva_v);
beva_slt.bem_put_2(bevl_sl, bevt_5_ta_ph);
} /* Line: 306*/
 else /* Line: 307*/ {
beva_slt.bem_put_2(bevl_sl, beva_inode);
} /* Line: 308*/
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_ta_ph;
} /* Line: 311*/
 else /* Line: 304*/ {
bevt_10_ta_ph = bevl_n.bem_hvalGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_9_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 312*/ {
bevt_11_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_ta_ph;
} /* Line: 313*/
 else /* Line: 304*/ {
bevt_13_ta_ph = bevl_n.bem_keyGet_0();
bevt_12_ta_ph = bevp_rel.bem_isEqual_2(bevt_13_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 314*/ {
bevl_n.bem_putTo_2(beva_k, beva_v);
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_14_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /* Line: 318*/
 else /* Line: 319*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 321*/ {
bevt_16_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 322*/
} /* Line: 321*/
} /* Line: 304*/
} /* Line: 304*/
} /* Line: 304*/
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_put_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevp_slots);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-534139924);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 329*/ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 332*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_k, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-534139924);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 332*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 333*/
 else /* Line: 332*/ {
break;
} /* Line: 332*/
} /* Line: 332*/
bevp_slots = bevl_slt;
} /* Line: 335*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 337*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 338*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 346*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 347*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 351*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 353*/ {
return null;
} /* Line: 354*/
 else /* Line: 353*/ {
bevt_5_ta_ph = bevl_n.bem_hvalGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_4_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 355*/ {
return null;
} /* Line: 356*/
 else /* Line: 353*/ {
bevt_7_ta_ph = bevl_n.bem_keyGet_0();
bevt_6_ta_ph = bevp_rel.bem_isEqual_2(bevt_7_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 357*/ {
bevt_8_ta_ph = bevl_n.bem_getFrom_0();
return bevt_8_ta_ph;
} /* Line: 358*/
 else /* Line: 359*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 361*/ {
return null;
} /* Line: 362*/
} /* Line: 361*/
} /* Line: 353*/
} /* Line: 353*/
} /* Line: 353*/
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 372*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 373*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 377*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 379*/ {
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /* Line: 380*/
 else /* Line: 379*/ {
bevt_6_ta_ph = bevl_n.bem_hvalGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_5_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 381*/ {
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /* Line: 382*/
 else /* Line: 379*/ {
bevt_9_ta_ph = bevl_n.bem_keyGet_0();
bevt_8_ta_ph = bevp_rel.bem_isEqual_2(bevt_9_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 383*/ {
bevt_10_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_ta_ph;
} /* Line: 384*/
 else /* Line: 385*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 387*/ {
bevt_12_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /* Line: 388*/
} /* Line: 387*/
} /* Line: 379*/
} /* Line: 379*/
} /* Line: 379*/
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_delete_1(BEC_2_6_6_SystemObject beva_k) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_4_3_MathInt bevl_modu = null;
BEC_2_4_3_MathInt bevl_hval = null;
BEC_2_4_3_MathInt bevl_orgsl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
bevl_slt = bevp_slots;
bevl_modu = bevl_slt.bem_sizeGet_0();
bevl_hval = (BEC_2_4_3_MathInt) bevp_rel.bem_getHash_1(beva_k);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_hval.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 399*/ {
bevl_hval = bevl_hval.bem_abs_0();
} /* Line: 400*/
bevl_orgsl = bevl_hval.bem_modulus_1(bevl_modu);
bevl_sl = bevl_orgsl;
while (true)
/* Line: 404*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 406*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 407*/
 else /* Line: 406*/ {
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_6_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 408*/ {
bevt_8_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 409*/
 else /* Line: 406*/ {
bevt_10_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevp_rel.bem_isEqual_2(bevt_10_ta_ph, beva_k);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 410*/ {
bevl_slt.bem_put_2(bevl_sl, null);
bevp_size = bevp_size.bem_decrement_0();
bevl_sl = bevl_sl.bem_increment_0();
while (true)
/* Line: 414*/ {
if (bevl_sl.bevi_int < bevl_modu.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 414*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevl_slt.bem_get_1(bevl_sl);
if (bevl_n == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 416*/ {
bevt_15_ta_ph = bevl_n.bem_hvalGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_modulus_1(bevl_modu);
if (bevt_14_ta_ph.bevi_int != bevl_orgsl.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 416*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 416*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 416*/ {
bevt_16_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_16_ta_ph;
} /* Line: 417*/
 else /* Line: 418*/ {
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_17_ta_ph = bevl_sl.bem_subtract_1(bevt_18_ta_ph);
bevl_slt.bem_put_2(bevt_17_ta_ph, bevl_n);
bevl_slt.bem_put_2(bevl_sl, null);
} /* Line: 420*/
bevl_sl = bevl_sl.bem_increment_0();
} /* Line: 422*/
 else /* Line: 414*/ {
break;
} /* Line: 414*/
} /* Line: 414*/
bevt_19_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_19_ta_ph;
} /* Line: 424*/
 else /* Line: 425*/ {
bevl_sl = bevl_sl.bem_increment_0();
if (bevl_sl.bevi_int >= bevl_modu.bevi_int) {
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 427*/ {
bevt_21_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_21_ta_ph;
} /* Line: 428*/
} /* Line: 427*/
} /* Line: 406*/
} /* Line: 406*/
} /* Line: 406*/
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_6_6_SystemObject bevl_other = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_3_7_ContainerSetSetNode bevl_n = null;
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_5_ta_ph = null;
BEC_3_9_3_7_ContainerSetSetNode bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevl_other = bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) bevp_slots.bem_copy_0();
bevl_other.bemd_1(476897882, bevt_0_ta_ph);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 438*/ {
bevt_2_ta_ph = bevp_slots.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 438*/ {
bevl_n = (BEC_3_9_3_7_ContainerSetSetNode) bevp_slots.bem_get_1(bevl_i);
if (bevl_n == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 440*/ {
bevt_4_ta_ph = bevl_other.bemd_0(264727971);
bevt_6_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevp_baseNode.bem_create_0();
bevt_7_ta_ph = bevl_n.bem_hvalGet_0();
bevt_8_ta_ph = bevl_n.bem_keyGet_0();
bevt_9_ta_ph = bevl_n.bem_getFrom_0();
bevt_5_ta_ph = (BEC_3_9_3_7_ContainerSetSetNode) bevt_6_ta_ph.bem_new_3(bevt_7_ta_ph, bevt_8_ta_ph, bevt_9_ta_ph);
bevt_4_ta_ph.bemd_2(512449538, bevl_i, bevt_5_ta_ph);
} /* Line: 441*/
 else /* Line: 442*/ {
bevt_10_ta_ph = bevl_other.bemd_0(264727971);
bevt_10_ta_ph.bemd_2(512449538, bevl_i, null);
} /* Line: 443*/
bevl_i = bevl_i.bem_increment_0();
} /* Line: 438*/
 else /* Line: 438*/ {
break;
} /* Line: 438*/
} /* Line: 438*/
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_clear_0() {
bevp_slots.bem_clear_0();
bevp_slots.bem_sizeSet_1(bevp_modu);
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_setIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keyIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_11_ContainerSetKeyIterator()).bem_new_1(this);
return (BEC_3_9_3_11_ContainerSetKeyIterator) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_9_3_11_ContainerSetKeyIterator bem_keysGet_0() {
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_keyIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodeIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_nodesGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_nodeIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_intersection_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 482*/ {
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 483*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 483*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = beva_other.bem_has_1(bevl_x);
if (bevt_3_ta_ph.bevi_bool)/* Line: 484*/ {
bevl_i.bem_put_1(bevl_x);
} /* Line: 485*/
} /* Line: 484*/
 else /* Line: 483*/ {
break;
} /* Line: 483*/
} /* Line: 483*/
} /* Line: 483*/
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_union_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevl_i = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_0_ta_loop = bem_setIteratorGet_0();
while (true)
/* Line: 494*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 494*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 495*/
 else /* Line: 494*/ {
break;
} /* Line: 494*/
} /* Line: 494*/
if (beva_other == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 497*/ {
bevt_1_ta_loop = beva_other.bem_setIteratorGet_0();
while (true)
/* Line: 498*/ {
bevt_4_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 498*/ {
bevl_x = bevt_1_ta_loop.bem_nextGet_0();
bevl_i.bem_put_1(bevl_x);
} /* Line: 499*/
 else /* Line: 498*/ {
break;
} /* Line: 498*/
} /* Line: 498*/
} /* Line: 498*/
return bevl_i;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_add_1(BEC_2_9_3_ContainerSet beva_other) {
BEC_2_9_3_ContainerSet bevl_x = null;
bevl_x = (BEC_2_9_3_ContainerSet) bem_copy_0();
bevl_x.bem_addValue_1(beva_other);
return (BEC_2_9_3_ContainerSet) bevl_x;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 512*/ {
bevt_2_ta_ph = beva_other.bemd_1(1814775779, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 513*/ {
bevt_0_ta_loop = beva_other.bemd_0(-793241295);
while (true)
/* Line: 514*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 514*/ {
bevl_x = bevt_0_ta_loop.bemd_0(409355098);
bem_put_1(bevl_x);
} /* Line: 515*/
 else /* Line: 514*/ {
break;
} /* Line: 514*/
} /* Line: 514*/
} /* Line: 514*/
 else /* Line: 513*/ {
bevt_4_ta_ph = beva_other.bemd_1(1814775779, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 517*/ {
bevt_5_ta_ph = beva_other.bemd_0(-317365949);
bem_put_1(bevt_5_ta_ph);
} /* Line: 518*/
 else /* Line: 519*/ {
bem_put_1(beva_other);
} /* Line: 520*/
} /* Line: 513*/
} /* Line: 513*/
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_slotsGet_0() {
return bevp_slots;
} /*method end*/
public BEC_2_9_4_ContainerList bem_slotsGetDirect_0() {
return bevp_slots;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_slotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_slotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_slots = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_moduGet_0() {
return bevp_modu;
} /*method end*/
public BEC_2_4_3_MathInt bem_moduGetDirect_0() {
return bevp_modu;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_moduSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_moduSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_modu = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_multiGet_0() {
return bevp_multi;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiGetDirect_0() {
return bevp_multi;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_multiSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_multiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_multi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_9_ContainerSetRelations bem_relGet_0() {
return bevp_rel;
} /*method end*/
public BEC_3_9_3_9_ContainerSetRelations bem_relGetDirect_0() {
return bevp_rel;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_relSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_relSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGet_0() {
return bevp_baseNode;
} /*method end*/
public BEC_3_9_3_7_ContainerSetSetNode bem_baseNodeGetDirect_0() {
return bevp_baseNode;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_baseNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_baseNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_innerPutAddedGet_0() {
return bevp_innerPutAdded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_innerPutAddedGetDirect_0() {
return bevp_innerPutAdded;
} /*method end*/
public virtual BEC_2_9_3_ContainerSet bem_innerPutAddedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_innerPutAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_innerPutAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {214, 214, 220, 221, 222, 223, 224, 225, 226, 232, 232, 232, 233, 233, 235, 235, 239, 239, 239, 240, 240, 242, 242, 246, 246, 250, 250, 254, 254, 258, 258, 259, 260, 260, 261, 261, 261, 262, 262, 266, 266, 271, 271, 271, 271, 272, 273, 273, 274, 275, 277, 281, 281, 0, 281, 281, 281, 281, 0, 0, 282, 282, 284, 0, 284, 284, 285, 285, 285, 285, 285, 287, 287, 291, 292, 292, 293, 294, 294, 294, 295, 298, 300, 301, 303, 304, 304, 305, 305, 306, 306, 306, 308, 310, 311, 311, 312, 312, 312, 312, 313, 313, 314, 314, 315, 317, 318, 318, 320, 321, 321, 322, 322, 329, 329, 330, 331, 332, 332, 333, 335, 338, 343, 344, 345, 346, 346, 346, 347, 349, 350, 352, 353, 353, 354, 355, 355, 355, 355, 356, 357, 357, 358, 358, 360, 361, 361, 362, 369, 370, 371, 372, 372, 372, 373, 375, 376, 378, 379, 379, 380, 380, 381, 381, 381, 381, 382, 382, 383, 383, 384, 384, 386, 387, 387, 388, 388, 395, 396, 398, 399, 399, 399, 400, 402, 403, 405, 406, 406, 407, 407, 408, 408, 408, 408, 409, 409, 410, 410, 411, 412, 413, 414, 414, 415, 416, 416, 0, 416, 416, 416, 416, 0, 0, 417, 417, 419, 419, 419, 420, 422, 424, 424, 426, 427, 427, 428, 428, 435, 436, 437, 437, 438, 438, 438, 438, 439, 440, 440, 441, 441, 441, 441, 441, 441, 441, 443, 443, 438, 446, 451, 452, 453, 457, 457, 461, 461, 465, 465, 469, 469, 473, 473, 477, 477, 481, 482, 482, 483, 0, 483, 483, 484, 485, 489, 493, 494, 0, 494, 494, 495, 497, 497, 498, 0, 498, 498, 499, 502, 506, 507, 508, 512, 512, 513, 514, 0, 514, 514, 515, 517, 518, 518, 520, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 26, 27, 28, 29, 30, 31, 32, 40, 41, 46, 47, 48, 50, 51, 58, 59, 64, 65, 66, 68, 69, 73, 74, 78, 79, 84, 85, 97, 100, 102, 103, 108, 109, 110, 111, 113, 114, 122, 123, 133, 134, 135, 136, 137, 140, 141, 143, 144, 150, 166, 171, 172, 175, 176, 177, 182, 183, 186, 190, 191, 193, 193, 196, 198, 199, 200, 205, 206, 207, 214, 215, 240, 241, 246, 247, 248, 249, 254, 255, 259, 261, 262, 265, 266, 271, 272, 277, 278, 279, 280, 283, 285, 286, 287, 290, 291, 292, 297, 298, 299, 302, 303, 305, 306, 307, 308, 311, 312, 317, 318, 319, 332, 333, 335, 336, 339, 340, 342, 348, 351, 372, 373, 374, 375, 376, 381, 382, 384, 385, 388, 389, 394, 395, 398, 399, 400, 405, 406, 409, 410, 412, 413, 416, 417, 422, 423, 450, 451, 452, 453, 454, 459, 460, 462, 463, 466, 467, 472, 473, 474, 477, 478, 479, 484, 485, 486, 489, 490, 492, 493, 496, 497, 502, 503, 504, 540, 541, 542, 543, 544, 549, 550, 552, 553, 556, 557, 562, 563, 564, 567, 568, 569, 574, 575, 576, 579, 580, 582, 583, 584, 587, 592, 593, 594, 599, 600, 603, 604, 605, 610, 611, 614, 618, 619, 622, 623, 624, 625, 627, 633, 634, 637, 638, 643, 644, 645, 667, 668, 669, 670, 671, 674, 675, 680, 681, 682, 687, 688, 689, 690, 691, 692, 693, 694, 697, 698, 700, 706, 709, 710, 711, 716, 717, 721, 722, 726, 727, 731, 732, 736, 737, 741, 742, 751, 752, 757, 758, 758, 761, 763, 764, 766, 774, 784, 785, 785, 788, 790, 791, 797, 802, 803, 803, 806, 808, 809, 816, 820, 821, 822, 832, 837, 838, 840, 840, 843, 845, 846, 854, 856, 857, 860, 867, 870, 873, 877, 881, 884, 887, 891, 895, 898, 901, 905, 909, 912, 915, 919, 923, 926, 929, 933, 937, 940, 943, 947, 951, 954, 957, 961};
/* BEGIN LINEINFO 
assign 1 214 21
new 0 214 21
new 1 214 22
assign 1 220 26
new 1 220 26
assign 1 221 27
assign 1 222 28
new 0 222 28
assign 1 223 29
new 0 223 29
assign 1 224 30
new 0 224 30
assign 1 225 31
new 0 225 31
assign 1 226 32
new 0 226 32
assign 1 232 40
new 0 232 40
assign 1 232 41
equals 1 232 46
assign 1 233 47
new 0 233 47
return 1 233 48
assign 1 235 50
new 0 235 50
return 1 235 51
assign 1 239 58
new 0 239 58
assign 1 239 59
equals 1 239 64
assign 1 240 65
new 0 240 65
return 1 240 66
assign 1 242 68
new 0 242 68
return 1 242 69
assign 1 246 73
toString 0 246 73
return 1 246 74
assign 1 250 78
new 1 250 78
new 1 250 79
assign 1 254 84
new 1 254 84
return 1 254 85
assign 1 258 97
arrayIteratorGet 0 258 97
assign 1 258 100
hasNextGet 0 258 100
assign 1 259 102
nextGet 0 259 102
assign 1 260 103
def 1 260 108
assign 1 261 109
keyGet 0 261 109
assign 1 261 110
innerPut 4 261 110
assign 1 261 111
not 0 261 111
assign 1 262 113
new 0 262 113
return 1 262 114
assign 1 266 122
new 0 266 122
return 1 266 123
assign 1 271 133
sizeGet 0 271 133
assign 1 271 134
multiply 1 271 134
assign 1 271 135
new 0 271 135
assign 1 271 136
add 1 271 136
assign 1 272 137
new 1 272 137
assign 1 273 140
insertAll 2 273 140
assign 1 273 141
not 0 273 141
assign 1 274 143
increment 0 274 143
assign 1 275 144
new 1 275 144
return 1 277 150
assign 1 281 166
undef 1 281 171
assign 1 0 172
assign 1 281 175
sizeGet 0 281 175
assign 1 281 176
sizeGet 0 281 176
assign 1 281 177
notEquals 1 281 182
assign 1 0 183
assign 1 0 186
assign 1 282 190
new 0 282 190
return 1 282 191
assign 1 284 193
setIteratorGet 0 0 193
assign 1 284 196
hasNextGet 0 284 196
assign 1 284 198
nextGet 0 284 198
assign 1 285 199
has 1 285 199
assign 1 285 200
not 0 285 205
assign 1 285 206
new 0 285 206
return 1 285 207
assign 1 287 214
new 0 287 214
return 1 287 215
assign 1 291 240
sizeGet 0 291 240
assign 1 292 241
undef 1 292 246
assign 1 293 247
getHash 1 293 247
assign 1 294 248
new 0 294 248
assign 1 294 249
lesser 1 294 254
assign 1 295 255
abs 0 295 255
assign 1 298 259
hvalGet 0 298 259
assign 1 300 261
modulus 1 300 261
assign 1 301 262
assign 1 303 265
get 1 303 265
assign 1 304 266
undef 1 304 271
assign 1 305 272
undef 1 305 277
assign 1 306 278
create 0 306 278
assign 1 306 279
new 3 306 279
put 2 306 280
put 2 308 283
assign 1 310 285
new 0 310 285
assign 1 311 286
new 0 311 286
return 1 311 287
assign 1 312 290
hvalGet 0 312 290
assign 1 312 291
modulus 1 312 291
assign 1 312 292
notEquals 1 312 297
assign 1 313 298
new 0 313 298
return 1 313 299
assign 1 314 302
keyGet 0 314 302
assign 1 314 303
isEqual 2 314 303
putTo 2 315 305
assign 1 317 306
new 0 317 306
assign 1 318 307
new 0 318 307
return 1 318 308
assign 1 320 311
increment 0 320 311
assign 1 321 312
greaterEquals 1 321 317
assign 1 322 318
new 0 322 318
return 1 322 319
assign 1 329 332
innerPut 4 329 332
assign 1 329 333
not 0 329 333
assign 1 330 335
assign 1 331 336
rehash 1 331 336
assign 1 332 339
innerPut 4 332 339
assign 1 332 340
not 0 332 340
assign 1 333 342
rehash 1 333 342
assign 1 335 348
assign 1 338 351
increment 0 338 351
assign 1 343 372
assign 1 344 373
sizeGet 0 344 373
assign 1 345 374
getHash 1 345 374
assign 1 346 375
new 0 346 375
assign 1 346 376
lesser 1 346 381
assign 1 347 382
abs 0 347 382
assign 1 349 384
modulus 1 349 384
assign 1 350 385
assign 1 352 388
get 1 352 388
assign 1 353 389
undef 1 353 394
return 1 354 395
assign 1 355 398
hvalGet 0 355 398
assign 1 355 399
modulus 1 355 399
assign 1 355 400
notEquals 1 355 405
return 1 356 406
assign 1 357 409
keyGet 0 357 409
assign 1 357 410
isEqual 2 357 410
assign 1 358 412
getFrom 0 358 412
return 1 358 413
assign 1 360 416
increment 0 360 416
assign 1 361 417
greaterEquals 1 361 422
return 1 362 423
assign 1 369 450
assign 1 370 451
sizeGet 0 370 451
assign 1 371 452
getHash 1 371 452
assign 1 372 453
new 0 372 453
assign 1 372 454
lesser 1 372 459
assign 1 373 460
abs 0 373 460
assign 1 375 462
modulus 1 375 462
assign 1 376 463
assign 1 378 466
get 1 378 466
assign 1 379 467
undef 1 379 472
assign 1 380 473
new 0 380 473
return 1 380 474
assign 1 381 477
hvalGet 0 381 477
assign 1 381 478
modulus 1 381 478
assign 1 381 479
notEquals 1 381 484
assign 1 382 485
new 0 382 485
return 1 382 486
assign 1 383 489
keyGet 0 383 489
assign 1 383 490
isEqual 2 383 490
assign 1 384 492
new 0 384 492
return 1 384 493
assign 1 386 496
increment 0 386 496
assign 1 387 497
greaterEquals 1 387 502
assign 1 388 503
new 0 388 503
return 1 388 504
assign 1 395 540
assign 1 396 541
sizeGet 0 396 541
assign 1 398 542
getHash 1 398 542
assign 1 399 543
new 0 399 543
assign 1 399 544
lesser 1 399 549
assign 1 400 550
abs 0 400 550
assign 1 402 552
modulus 1 402 552
assign 1 403 553
assign 1 405 556
get 1 405 556
assign 1 406 557
undef 1 406 562
assign 1 407 563
new 0 407 563
return 1 407 564
assign 1 408 567
hvalGet 0 408 567
assign 1 408 568
modulus 1 408 568
assign 1 408 569
notEquals 1 408 574
assign 1 409 575
new 0 409 575
return 1 409 576
assign 1 410 579
keyGet 0 410 579
assign 1 410 580
isEqual 2 410 580
put 2 411 582
assign 1 412 583
decrement 0 412 583
assign 1 413 584
increment 0 413 584
assign 1 414 587
lesser 1 414 592
assign 1 415 593
get 1 415 593
assign 1 416 594
undef 1 416 599
assign 1 0 600
assign 1 416 603
hvalGet 0 416 603
assign 1 416 604
modulus 1 416 604
assign 1 416 605
notEquals 1 416 610
assign 1 0 611
assign 1 0 614
assign 1 417 618
new 0 417 618
return 1 417 619
assign 1 419 622
new 0 419 622
assign 1 419 623
subtract 1 419 623
put 2 419 624
put 2 420 625
assign 1 422 627
increment 0 422 627
assign 1 424 633
new 0 424 633
return 1 424 634
assign 1 426 637
increment 0 426 637
assign 1 427 638
greaterEquals 1 427 643
assign 1 428 644
new 0 428 644
return 1 428 645
assign 1 435 667
create 0 435 667
copyTo 1 436 668
assign 1 437 669
copy 0 437 669
slotsSet 1 437 670
assign 1 438 671
new 0 438 671
assign 1 438 674
lengthGet 0 438 674
assign 1 438 675
lesser 1 438 680
assign 1 439 681
get 1 439 681
assign 1 440 682
def 1 440 687
assign 1 441 688
slotsGet 0 441 688
assign 1 441 689
create 0 441 689
assign 1 441 690
hvalGet 0 441 690
assign 1 441 691
keyGet 0 441 691
assign 1 441 692
getFrom 0 441 692
assign 1 441 693
new 3 441 693
put 2 441 694
assign 1 443 697
slotsGet 0 443 697
put 2 443 698
assign 1 438 700
increment 0 438 700
return 1 446 706
clear 0 451 709
sizeSet 1 452 710
assign 1 453 711
new 0 453 711
assign 1 457 716
new 1 457 716
return 1 457 717
assign 1 461 721
new 1 461 721
return 1 461 722
assign 1 465 726
new 1 465 726
return 1 465 727
assign 1 469 731
keyIteratorGet 0 469 731
return 1 469 732
assign 1 473 736
new 1 473 736
return 1 473 737
assign 1 477 741
nodeIteratorGet 0 477 741
return 1 477 742
assign 1 481 751
new 0 481 751
assign 1 482 752
def 1 482 757
assign 1 483 758
setIteratorGet 0 0 758
assign 1 483 761
hasNextGet 0 483 761
assign 1 483 763
nextGet 0 483 763
assign 1 484 764
has 1 484 764
put 1 485 766
return 1 489 774
assign 1 493 784
new 0 493 784
assign 1 494 785
setIteratorGet 0 0 785
assign 1 494 788
hasNextGet 0 494 788
assign 1 494 790
nextGet 0 494 790
put 1 495 791
assign 1 497 797
def 1 497 802
assign 1 498 803
setIteratorGet 0 0 803
assign 1 498 806
hasNextGet 0 498 806
assign 1 498 808
nextGet 0 498 808
put 1 499 809
return 1 502 816
assign 1 506 820
copy 0 506 820
addValue 1 507 821
return 1 508 822
assign 1 512 832
def 1 512 837
assign 1 513 838
sameType 1 513 838
assign 1 514 840
iteratorGet 0 0 840
assign 1 514 843
hasNextGet 0 514 843
assign 1 514 845
nextGet 0 514 845
put 1 515 846
assign 1 517 854
sameType 1 517 854
assign 1 518 856
keyGet 0 518 856
put 1 518 857
put 1 520 860
return 1 0 867
return 1 0 870
assign 1 0 873
assign 1 0 877
return 1 0 881
return 1 0 884
assign 1 0 887
assign 1 0 891
return 1 0 895
return 1 0 898
assign 1 0 901
assign 1 0 905
return 1 0 909
return 1 0 912
assign 1 0 915
assign 1 0 919
return 1 0 923
return 1 0 926
assign 1 0 929
assign 1 0 933
return 1 0 937
return 1 0 940
assign 1 0 943
assign 1 0 947
return 1 0 951
return 1 0 954
assign 1 0 957
assign 1 0 961
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 336567712: return bem_innerPutAddedGet_0();
case -1387831588: return bem_print_0();
case -1188922735: return bem_echo_0();
case -163477925: return bem_multiGetDirect_0();
case 1739898218: return bem_moduGetDirect_0();
case 432997763: return bem_relGet_0();
case -793241295: return bem_iteratorGet_0();
case -2015646956: return bem_innerPutAddedGetDirect_0();
case 371157924: return bem_sourceFileNameGet_0();
case 1652521523: return bem_serializeContents_0();
case -220982197: return bem_sizeGet_0();
case -1760538533: return bem_classNameGet_0();
case 264727971: return bem_slotsGet_0();
case 7254011: return bem_fieldIteratorGet_0();
case -921473949: return bem_fieldNamesGet_0();
case -780083863: return bem_setIteratorGet_0();
case 909687589: return bem_nodeIteratorGet_0();
case 895193825: return bem_once_0();
case -467511392: return bem_toString_0();
case -725384548: return bem_moduGet_0();
case -1323898541: return bem_toAny_0();
case -476395750: return bem_isEmptyGet_0();
case -39165288: return bem_deserializeClassNameGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -447432319: return bem_many_0();
case 1597327951: return bem_create_0();
case -1363819567: return bem_new_0();
case 1331681266: return bem_nodesGet_0();
case 1466460989: return bem_sizeGetDirect_0();
case 1720785179: return bem_clear_0();
case 1496752783: return bem_relGetDirect_0();
case 1092105192: return bem_hashGet_0();
case -2100155814: return bem_notEmptyGet_0();
case -990568829: return bem_baseNodeGetDirect_0();
case -359578239: return bem_keyIteratorGet_0();
case -105946774: return bem_serializeToString_0();
case 1050845344: return bem_slotsGetDirect_0();
case 1890854002: return bem_tagGet_0();
case -785115082: return bem_baseNodeGet_0();
case 177450878: return bem_keysGet_0();
case 133807000: return bem_multiGet_0();
case 1319388306: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -752419977: return bem_multiSetDirect_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1243270878: return bem_has_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1728508146: return bem_sizeSetDirect_1(bevd_0);
case 2069899029: return bem_sizeSet_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 476897882: return bem_slotsSet_1(bevd_0);
case -1993847136: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 1929898803: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 766063314: return bem_baseNodeSetDirect_1(bevd_0);
case 978995616: return bem_get_1(bevd_0);
case -317649604: return bem_moduSetDirect_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case 1476354894: return bem_delete_1(bevd_0);
case -1023953028: return bem_innerPutAddedSet_1(bevd_0);
case -1988368117: return bem_slotsSetDirect_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1670652779: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1634078582: return bem_addValue_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case 1172307361: return bem_multiSet_1(bevd_0);
case -475350780: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case -670810647: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -87656766: return bem_relSetDirect_1(bevd_0);
case -1965905628: return bem_put_1(bevd_0);
case -608426090: return bem_relSet_1(bevd_0);
case 298058979: return bem_moduSet_1(bevd_0);
case -1075789891: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1784773075: return bem_baseNodeSet_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case -1460307376: return bem_innerPutAddedSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1238879809: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1649780753: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerSet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerSet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerSet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst = (BEC_2_9_3_ContainerSet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_3_ContainerSet.bece_BEC_2_9_3_ContainerSet_bevs_type;
}
}
}
