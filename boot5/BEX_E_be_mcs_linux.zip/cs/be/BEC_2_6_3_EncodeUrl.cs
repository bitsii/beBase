namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeUrl : BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
static BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_BEC_2_6_3_EncodeUrl_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_BEC_2_6_3_EncodeUrl_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_1 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_2 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_3 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_4 = (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_5 = (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_6 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_7 = (new BEC_2_4_3_MathInt(44));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_8 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_9 = (new BEC_2_4_3_MathInt(42));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_10 = (new BEC_2_4_3_MathInt(32));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_0 = {0x2B};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_1 = {0x25};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_2 = {0x2B};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_2, 1));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_3 = {0x25};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_3, 1));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_4 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_16 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_17 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_5 = {0x2B};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_5, 1));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_6 = {0x25};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_6, 1));
public static new BEC_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_inst;

public static new BET_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_3_EncodeUrl bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
bevt_6_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_7_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_0;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_multiply_1(bevt_7_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_tmpany_phold);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_pt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_tmpany_phold);
while (true)
 /* Line: 217 */ {
bevt_9_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_tmpany_phold);
bevt_12_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_1;
if (bevl_ac.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_2;
if (bevl_ac.bevi_int < bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_16_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_3;
if (bevl_ac.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_18_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_4;
if (bevl_ac.bevi_int < bevt_18_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_20_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_5;
if (bevl_ac.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_22_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_6;
if (bevl_ac.bevi_int < bevt_22_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_7;
if (bevl_ac.bevi_int > bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_26_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_8;
if (bevl_ac.bevi_int < bevt_26_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_28_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_9;
if (bevl_ac.bevi_int == bevt_28_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 221 */
 else  /* Line: 220 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_10;
if (bevl_ac.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_r.bem_addValue_1(bevt_31_tmpany_phold);
} /* Line: 223 */
 else  /* Line: 224 */ {
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_r.bem_addValue_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_tmpany_phold);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 227 */
} /* Line: 220 */
} /* Line: 220 */
 else  /* Line: 217 */ {
break;
} /* Line: 217 */
} /* Line: 217 */
bevt_34_tmpany_phold = bevl_r.bem_toString_0();
return bevt_34_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
bevt_2_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_11;
bevl_npl = beva_str.bem_find_2(bevt_3_tmpany_phold, bevl_last);
bevt_4_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_12;
bevl_npe = beva_str.bem_find_2(bevt_4_tmpany_phold, bevl_last);
if (bevl_npe == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
if (bevl_npl == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 243 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 245 */
 else  /* Line: 246 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 248 */
bevl_len = beva_str.bem_sizeGet_0();
while (true)
 /* Line: 252 */ {
if (bevl_i == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 252 */ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevt_10_tmpany_phold = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_tmpany_phold);
bevl_last = bevl_i;
} /* Line: 255 */
if (bevl_ispl.bevi_bool) /* Line: 257 */ {
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_4));
bevl_r.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_13;
bevl_last = bevl_i.bem_add_1(bevt_12_tmpany_phold);
} /* Line: 259 */
 else  /* Line: 260 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_14;
bevt_14_tmpany_phold = bevl_i.bem_add_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_int < bevl_len.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_15;
bevt_18_tmpany_phold = bevl_i.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_16;
bevt_20_tmpany_phold = bevl_i.bem_add_1(bevt_21_tmpany_phold);
bevt_17_tmpany_phold = beva_str.bem_substring_2(bevt_18_tmpany_phold, bevt_20_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_tmpany_phold);
bevl_r.bem_addValue_1(bevt_16_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_17;
bevl_last = bevl_i.bem_add_1(bevt_22_tmpany_phold);
} /* Line: 263 */
} /* Line: 261 */
bevt_23_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_18;
bevl_npl = beva_str.bem_find_2(bevt_23_tmpany_phold, bevl_last);
bevt_24_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_19;
bevl_npe = beva_str.bem_find_2(bevt_24_tmpany_phold, bevl_last);
if (bevl_npe == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
if (bevl_npl == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 268 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 268 */
 else  /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 268 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 268 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 270 */
 else  /* Line: 271 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 273 */
} /* Line: 268 */
 else  /* Line: 252 */ {
break;
} /* Line: 252 */
} /* Line: 252 */
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_29_tmpany_phold = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_tmpany_phold);
} /* Line: 277 */
bevt_30_tmpany_phold = bevl_r.bem_toString_0();
return bevt_30_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {214, 214, 214, 214, 215, 216, 216, 217, 218, 219, 219, 220, 220, 220, 220, 220, 220, 0, 0, 0, 0, 220, 220, 220, 220, 220, 220, 0, 0, 0, 0, 0, 0, 220, 220, 220, 220, 220, 220, 0, 0, 0, 0, 0, 0, 220, 220, 220, 220, 220, 220, 0, 0, 0, 0, 0, 0, 220, 220, 220, 0, 0, 221, 222, 222, 222, 223, 223, 225, 225, 226, 226, 227, 230, 230, 234, 234, 235, 241, 241, 242, 242, 243, 243, 0, 243, 243, 243, 243, 0, 0, 0, 0, 0, 244, 245, 247, 248, 251, 252, 252, 253, 253, 254, 254, 255, 258, 258, 259, 259, 261, 261, 261, 261, 262, 262, 262, 262, 262, 262, 262, 263, 263, 266, 266, 267, 267, 268, 268, 0, 268, 268, 268, 268, 0, 0, 0, 0, 0, 269, 270, 272, 273, 276, 276, 277, 277, 279, 279};
public static new int[] bevs_smnlec
 = new int[] {88, 89, 90, 91, 92, 93, 94, 97, 99, 100, 101, 102, 103, 108, 109, 110, 115, 116, 119, 123, 126, 129, 130, 135, 136, 137, 142, 143, 146, 150, 153, 156, 160, 163, 164, 169, 170, 171, 176, 177, 180, 184, 187, 190, 194, 197, 198, 203, 204, 205, 210, 211, 214, 218, 221, 224, 228, 231, 232, 237, 238, 241, 245, 248, 249, 254, 255, 256, 259, 260, 261, 262, 263, 271, 272, 313, 314, 315, 316, 317, 318, 319, 320, 325, 326, 329, 334, 335, 340, 341, 344, 348, 351, 354, 358, 359, 362, 363, 365, 368, 373, 374, 379, 380, 381, 382, 385, 386, 387, 388, 391, 392, 393, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 410, 411, 412, 413, 414, 419, 420, 423, 428, 429, 434, 435, 438, 442, 445, 448, 452, 453, 456, 457, 464, 469, 470, 471, 473, 474};
/* BEGIN LINEINFO 
assign 1 214 88
sizeGet 0 214 88
assign 1 214 89
new 0 214 89
assign 1 214 90
multiply 1 214 90
assign 1 214 91
new 1 214 91
assign 1 215 92
new 1 215 92
assign 1 216 93
new 0 216 93
assign 1 216 94
new 1 216 94
assign 1 217 97
hasNextGet 0 217 97
next 1 218 99
assign 1 219 100
new 0 219 100
assign 1 219 101
getCode 1 219 101
assign 1 220 102
new 0 220 102
assign 1 220 103
greater 1 220 108
assign 1 220 109
new 0 220 109
assign 1 220 110
lesser 1 220 115
assign 1 0 116
assign 1 0 119
assign 1 0 123
assign 1 0 126
assign 1 220 129
new 0 220 129
assign 1 220 130
greater 1 220 135
assign 1 220 136
new 0 220 136
assign 1 220 137
lesser 1 220 142
assign 1 0 143
assign 1 0 146
assign 1 0 150
assign 1 0 153
assign 1 0 156
assign 1 0 160
assign 1 220 163
new 0 220 163
assign 1 220 164
greater 1 220 169
assign 1 220 170
new 0 220 170
assign 1 220 171
lesser 1 220 176
assign 1 0 177
assign 1 0 180
assign 1 0 184
assign 1 0 187
assign 1 0 190
assign 1 0 194
assign 1 220 197
new 0 220 197
assign 1 220 198
greater 1 220 203
assign 1 220 204
new 0 220 204
assign 1 220 205
lesser 1 220 210
assign 1 0 211
assign 1 0 214
assign 1 0 218
assign 1 0 221
assign 1 0 224
assign 1 0 228
assign 1 220 231
new 0 220 231
assign 1 220 232
equals 1 220 237
assign 1 0 238
assign 1 0 241
addValue 1 221 245
assign 1 222 248
new 0 222 248
assign 1 222 249
equals 1 222 254
assign 1 223 255
new 0 223 255
addValue 1 223 256
assign 1 225 259
new 0 225 259
addValue 1 225 260
assign 1 226 261
new 0 226 261
assign 1 226 262
getHex 1 226 262
addValue 1 227 263
assign 1 230 271
toString 0 230 271
return 1 230 272
assign 1 234 313
sizeGet 0 234 313
assign 1 234 314
new 1 234 314
assign 1 235 315
new 0 235 315
assign 1 241 316
new 0 241 316
assign 1 241 317
find 2 241 317
assign 1 242 318
new 0 242 318
assign 1 242 319
find 2 242 319
assign 1 243 320
undef 1 243 325
assign 1 0 326
assign 1 243 329
def 1 243 334
assign 1 243 335
lesser 1 243 340
assign 1 0 341
assign 1 0 344
assign 1 0 348
assign 1 0 351
assign 1 0 354
assign 1 244 358
new 0 244 358
assign 1 245 359
assign 1 247 362
new 0 247 362
assign 1 248 363
assign 1 251 365
sizeGet 0 251 365
assign 1 252 368
def 1 252 373
assign 1 253 374
greater 1 253 379
assign 1 254 380
substring 2 254 380
addValue 1 254 381
assign 1 255 382
assign 1 258 385
new 0 258 385
addValue 1 258 386
assign 1 259 387
new 0 259 387
assign 1 259 388
add 1 259 388
assign 1 261 391
new 0 261 391
assign 1 261 392
add 1 261 392
assign 1 261 393
lesser 1 261 398
assign 1 262 399
new 0 262 399
assign 1 262 400
add 1 262 400
assign 1 262 401
new 0 262 401
assign 1 262 402
add 1 262 402
assign 1 262 403
substring 2 262 403
assign 1 262 404
hexNew 1 262 404
addValue 1 262 405
assign 1 263 406
new 0 263 406
assign 1 263 407
add 1 263 407
assign 1 266 410
new 0 266 410
assign 1 266 411
find 2 266 411
assign 1 267 412
new 0 267 412
assign 1 267 413
find 2 267 413
assign 1 268 414
undef 1 268 419
assign 1 0 420
assign 1 268 423
def 1 268 428
assign 1 268 429
lesser 1 268 434
assign 1 0 435
assign 1 0 438
assign 1 0 442
assign 1 0 445
assign 1 0 448
assign 1 269 452
new 0 269 452
assign 1 270 453
assign 1 272 456
new 0 272 456
assign 1 273 457
assign 1 276 464
lesser 1 276 469
assign 1 277 470
substring 2 277 470
addValue 1 277 471
assign 1 279 473
toString 0 279 473
return 1 279 474
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1991051685: return bem_print_0();
case -439307572: return bem_hashGet_0();
case -1889481920: return bem_once_0();
case 491585243: return bem_toString_0();
case 645227528: return bem_copy_0();
case -213541934: return bem_echo_0();
case -1791312022: return bem_serializationIteratorGet_0();
case 1193477558: return bem_new_0();
case 1501620573: return bem_deserializeClassNameGet_0();
case 153829440: return bem_iteratorGet_0();
case -1466347886: return bem_serializeContents_0();
case -862758023: return bem_default_0();
case -2067310143: return bem_create_0();
case -637230318: return bem_serializeToString_0();
case -414566530: return bem_fieldIteratorGet_0();
case 1805899516: return bem_many_0();
case 793830133: return bem_tagGet_0();
case 1163377727: return bem_toAny_0();
case 956121033: return bem_sourceFileNameGet_0();
case 1754190679: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -505152552: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1603994454: return bem_sameType_1(bevd_0);
case 279657909: return bem_equals_1(bevd_0);
case 1267197459: return bem_otherType_1(bevd_0);
case 1963771415: return bem_undef_1(bevd_0);
case 100980215: return bem_otherClass_1(bevd_0);
case 1114375968: return bem_sameClass_1(bevd_0);
case -1314037522: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -287855524: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -704128729: return bem_copyTo_1(bevd_0);
case 385893729: return bem_undefined_1(bevd_0);
case 1979194181: return bem_notEquals_1(bevd_0);
case 320631834: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 1596320235: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1747438185: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case -1871751942: return bem_def_1(bevd_0);
case -1192171297: return bem_defined_1(bevd_0);
case 417172649: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1596177832: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1919067749: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1086524794: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1313996982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1153243887: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 966288160: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -962439482: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeUrl_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeUrl_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_3_EncodeUrl();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst = (BEC_2_6_3_EncodeUrl) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_type;
}
}
}
