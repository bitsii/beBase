namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeUrl : BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
static BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_BEC_2_6_3_EncodeUrl_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_BEC_2_6_3_EncodeUrl_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_1 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_2 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_3 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_4 = (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_5 = (new BEC_2_4_3_MathInt(94));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_6 = (new BEC_2_4_3_MathInt(123));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_7 = (new BEC_2_4_3_MathInt(44));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_8 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_9 = (new BEC_2_4_3_MathInt(42));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_10 = (new BEC_2_4_3_MathInt(32));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_0 = {0x2B};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_1 = {0x25};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_2 = {0x2B};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_2, 1));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_3 = {0x25};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_3, 1));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_4 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_16 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeUrl_bevo_17 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_5 = {0x2B};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_5, 1));
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_6 = {0x25};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeUrl_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeUrl_bels_6, 1));
public static new BEC_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_3_EncodeUrl bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
bevt_6_tmpany_phold = beva_str.bem_sizeGet_0();
bevt_7_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_0;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_multiply_1(bevt_7_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_tmpany_phold);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_pt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_tmpany_phold);
while (true)
 /* Line: 217 */ {
bevt_9_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_tmpany_phold);
bevt_12_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_1;
if (bevl_ac.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_2;
if (bevl_ac.bevi_int < bevt_14_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_16_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_3;
if (bevl_ac.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_18_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_4;
if (bevl_ac.bevi_int < bevt_18_tmpany_phold.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_20_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_5;
if (bevl_ac.bevi_int > bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_22_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_6;
if (bevl_ac.bevi_int < bevt_22_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_7;
if (bevl_ac.bevi_int > bevt_24_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_26_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_8;
if (bevl_ac.bevi_int < bevt_26_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
 else  /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_28_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_9;
if (bevl_ac.bevi_int == bevt_28_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 220 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 220 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 220 */ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 221 */
 else  /* Line: 220 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_10;
if (bevl_ac.bevi_int == bevt_30_tmpany_phold.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_r.bem_addValue_1(bevt_31_tmpany_phold);
} /* Line: 223 */
 else  /* Line: 224 */ {
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_r.bem_addValue_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_tmpany_phold);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 227 */
} /* Line: 220 */
} /* Line: 220 */
 else  /* Line: 217 */ {
break;
} /* Line: 217 */
} /* Line: 217 */
bevt_34_tmpany_phold = bevl_r.bem_toString_0();
return bevt_34_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
bevt_2_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_11;
bevl_npl = beva_str.bem_find_2(bevt_3_tmpany_phold, bevl_last);
bevt_4_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_12;
bevl_npe = beva_str.bem_find_2(bevt_4_tmpany_phold, bevl_last);
if (bevl_npe == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
if (bevl_npl == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 243 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
 else  /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 243 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 243 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 243 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 245 */
 else  /* Line: 246 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 248 */
bevl_len = beva_str.bem_sizeGet_0();
while (true)
 /* Line: 252 */ {
if (bevl_i == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 252 */ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevt_10_tmpany_phold = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_tmpany_phold);
bevl_last = bevl_i;
} /* Line: 255 */
if (bevl_ispl.bevi_bool) /* Line: 257 */ {
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_4));
bevl_r.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_13;
bevl_last = bevl_i.bem_add_1(bevt_12_tmpany_phold);
} /* Line: 259 */
 else  /* Line: 260 */ {
bevt_15_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_14;
bevt_14_tmpany_phold = bevl_i.bem_add_1(bevt_15_tmpany_phold);
if (bevt_14_tmpany_phold.bevi_int < bevl_len.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 261 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_15;
bevt_18_tmpany_phold = bevl_i.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_16;
bevt_20_tmpany_phold = bevl_i.bem_add_1(bevt_21_tmpany_phold);
bevt_17_tmpany_phold = beva_str.bem_substring_2(bevt_18_tmpany_phold, bevt_20_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_tmpany_phold);
bevl_r.bem_addValue_1(bevt_16_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_17;
bevl_last = bevl_i.bem_add_1(bevt_22_tmpany_phold);
} /* Line: 263 */
} /* Line: 261 */
bevt_23_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_18;
bevl_npl = beva_str.bem_find_2(bevt_23_tmpany_phold, bevl_last);
bevt_24_tmpany_phold = bece_BEC_2_6_3_EncodeUrl_bevo_19;
bevl_npe = beva_str.bem_find_2(bevt_24_tmpany_phold, bevl_last);
if (bevl_npe == null) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
if (bevl_npl == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 268 */ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 268 */
 else  /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 268 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 268 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 268 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 270 */
 else  /* Line: 271 */ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 273 */
} /* Line: 268 */
 else  /* Line: 252 */ {
break;
} /* Line: 252 */
} /* Line: 252 */
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_29_tmpany_phold = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_tmpany_phold);
} /* Line: 277 */
bevt_30_tmpany_phold = bevl_r.bem_toString_0();
return bevt_30_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {214, 214, 214, 214, 215, 216, 216, 217, 218, 219, 219, 220, 220, 220, 220, 220, 220, 0, 0, 0, 0, 220, 220, 220, 220, 220, 220, 0, 0, 0, 0, 0, 0, 220, 220, 220, 220, 220, 220, 0, 0, 0, 0, 0, 0, 220, 220, 220, 220, 220, 220, 0, 0, 0, 0, 0, 0, 220, 220, 220, 0, 0, 221, 222, 222, 222, 223, 223, 225, 225, 226, 226, 227, 230, 230, 234, 234, 235, 241, 241, 242, 242, 243, 243, 0, 243, 243, 243, 243, 0, 0, 0, 0, 0, 244, 245, 247, 248, 251, 252, 252, 253, 253, 254, 254, 255, 258, 258, 259, 259, 261, 261, 261, 261, 262, 262, 262, 262, 262, 262, 262, 263, 263, 266, 266, 267, 267, 268, 268, 0, 268, 268, 268, 268, 0, 0, 0, 0, 0, 269, 270, 272, 273, 276, 276, 277, 277, 279, 279};
public static new int[] bevs_smnlec
 = new int[] {85, 86, 87, 88, 89, 90, 91, 94, 96, 97, 98, 99, 100, 105, 106, 107, 112, 113, 116, 120, 123, 126, 127, 132, 133, 134, 139, 140, 143, 147, 150, 153, 157, 160, 161, 166, 167, 168, 173, 174, 177, 181, 184, 187, 191, 194, 195, 200, 201, 202, 207, 208, 211, 215, 218, 221, 225, 228, 229, 234, 235, 238, 242, 245, 246, 251, 252, 253, 256, 257, 258, 259, 260, 268, 269, 310, 311, 312, 313, 314, 315, 316, 317, 322, 323, 326, 331, 332, 337, 338, 341, 345, 348, 351, 355, 356, 359, 360, 362, 365, 370, 371, 376, 377, 378, 379, 382, 383, 384, 385, 388, 389, 390, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 407, 408, 409, 410, 411, 416, 417, 420, 425, 426, 431, 432, 435, 439, 442, 445, 449, 450, 453, 454, 461, 466, 467, 468, 470, 471};
/* BEGIN LINEINFO 
assign 1 214 85
sizeGet 0 214 85
assign 1 214 86
new 0 214 86
assign 1 214 87
multiply 1 214 87
assign 1 214 88
new 1 214 88
assign 1 215 89
new 1 215 89
assign 1 216 90
new 0 216 90
assign 1 216 91
new 1 216 91
assign 1 217 94
hasNextGet 0 217 94
next 1 218 96
assign 1 219 97
new 0 219 97
assign 1 219 98
getCode 1 219 98
assign 1 220 99
new 0 220 99
assign 1 220 100
greater 1 220 105
assign 1 220 106
new 0 220 106
assign 1 220 107
lesser 1 220 112
assign 1 0 113
assign 1 0 116
assign 1 0 120
assign 1 0 123
assign 1 220 126
new 0 220 126
assign 1 220 127
greater 1 220 132
assign 1 220 133
new 0 220 133
assign 1 220 134
lesser 1 220 139
assign 1 0 140
assign 1 0 143
assign 1 0 147
assign 1 0 150
assign 1 0 153
assign 1 0 157
assign 1 220 160
new 0 220 160
assign 1 220 161
greater 1 220 166
assign 1 220 167
new 0 220 167
assign 1 220 168
lesser 1 220 173
assign 1 0 174
assign 1 0 177
assign 1 0 181
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 220 194
new 0 220 194
assign 1 220 195
greater 1 220 200
assign 1 220 201
new 0 220 201
assign 1 220 202
lesser 1 220 207
assign 1 0 208
assign 1 0 211
assign 1 0 215
assign 1 0 218
assign 1 0 221
assign 1 0 225
assign 1 220 228
new 0 220 228
assign 1 220 229
equals 1 220 234
assign 1 0 235
assign 1 0 238
addValue 1 221 242
assign 1 222 245
new 0 222 245
assign 1 222 246
equals 1 222 251
assign 1 223 252
new 0 223 252
addValue 1 223 253
assign 1 225 256
new 0 225 256
addValue 1 225 257
assign 1 226 258
new 0 226 258
assign 1 226 259
getHex 1 226 259
addValue 1 227 260
assign 1 230 268
toString 0 230 268
return 1 230 269
assign 1 234 310
sizeGet 0 234 310
assign 1 234 311
new 1 234 311
assign 1 235 312
new 0 235 312
assign 1 241 313
new 0 241 313
assign 1 241 314
find 2 241 314
assign 1 242 315
new 0 242 315
assign 1 242 316
find 2 242 316
assign 1 243 317
undef 1 243 322
assign 1 0 323
assign 1 243 326
def 1 243 331
assign 1 243 332
lesser 1 243 337
assign 1 0 338
assign 1 0 341
assign 1 0 345
assign 1 0 348
assign 1 0 351
assign 1 244 355
new 0 244 355
assign 1 245 356
assign 1 247 359
new 0 247 359
assign 1 248 360
assign 1 251 362
sizeGet 0 251 362
assign 1 252 365
def 1 252 370
assign 1 253 371
greater 1 253 376
assign 1 254 377
substring 2 254 377
addValue 1 254 378
assign 1 255 379
assign 1 258 382
new 0 258 382
addValue 1 258 383
assign 1 259 384
new 0 259 384
assign 1 259 385
add 1 259 385
assign 1 261 388
new 0 261 388
assign 1 261 389
add 1 261 389
assign 1 261 390
lesser 1 261 395
assign 1 262 396
new 0 262 396
assign 1 262 397
add 1 262 397
assign 1 262 398
new 0 262 398
assign 1 262 399
add 1 262 399
assign 1 262 400
substring 2 262 400
assign 1 262 401
hexNew 1 262 401
addValue 1 262 402
assign 1 263 403
new 0 263 403
assign 1 263 404
add 1 263 404
assign 1 266 407
new 0 266 407
assign 1 266 408
find 2 266 408
assign 1 267 409
new 0 267 409
assign 1 267 410
find 2 267 410
assign 1 268 411
undef 1 268 416
assign 1 0 417
assign 1 268 420
def 1 268 425
assign 1 268 426
lesser 1 268 431
assign 1 0 432
assign 1 0 435
assign 1 0 439
assign 1 0 442
assign 1 0 445
assign 1 269 449
new 0 269 449
assign 1 270 450
assign 1 272 453
new 0 272 453
assign 1 273 454
assign 1 276 461
lesser 1 276 466
assign 1 277 467
substring 2 277 467
addValue 1 277 468
assign 1 279 470
toString 0 279 470
return 1 279 471
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1829615340: return bem_fieldIteratorGet_0();
case 386499474: return bem_deserializeClassNameGet_0();
case -1710921376: return bem_iteratorGet_0();
case -289190594: return bem_new_0();
case 1110687349: return bem_serializationIteratorGet_0();
case 1606100185: return bem_toAny_0();
case 1323527258: return bem_copy_0();
case 154399642: return bem_hashGet_0();
case 345797928: return bem_default_0();
case 468841666: return bem_sourceFileNameGet_0();
case -285521200: return bem_create_0();
case 628114265: return bem_many_0();
case -86198663: return bem_print_0();
case -457712006: return bem_classNameGet_0();
case -1679072038: return bem_toString_0();
case -2143843780: return bem_tagGet_0();
case 402795231: return bem_once_0();
case -1896702956: return bem_serializeContents_0();
case 820088259: return bem_echo_0();
case -693169976: return bem_serializeToString_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 2033308650: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 405603043: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759835639: return bem_defined_1(bevd_0);
case 1958076839: return bem_undefined_1(bevd_0);
case 2086659962: return bem_sameObject_1(bevd_0);
case 1526835907: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case 1253393632: return bem_def_1(bevd_0);
case -1211467604: return bem_copyTo_1(bevd_0);
case 365385951: return bem_equals_1(bevd_0);
case 1419518591: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 938569326: return bem_notEquals_1(bevd_0);
case -641584584: return bem_sameClass_1(bevd_0);
case -1706185549: return bem_otherType_1(bevd_0);
case 713999383: return bem_undef_1(bevd_0);
case -861317881: return bem_otherClass_1(bevd_0);
case 343567700: return bem_sameType_1(bevd_0);
case -1770369050: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 823180387: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1125341844: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389614349: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1812156494: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1790570920: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2109777534: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1447567526: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1299212473: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeUrl_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeUrl_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_3_EncodeUrl();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst = (BEC_2_6_3_EncodeUrl) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst;
}
}
}
