namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeUrl : BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeUrl() { }
static BEC_2_6_3_EncodeUrl() { }
private static byte[] becc_BEC_2_6_3_EncodeUrl_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x55,0x72,0x6C};
private static byte[] becc_BEC_2_6_3_EncodeUrl_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_0 = {0x2B};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_1 = {0x25};
private static byte[] bece_BEC_2_6_3_EncodeUrl_bels_2 = {0x20};
public static new BEC_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_inst;

public static new BET_2_6_3_EncodeUrl bece_BEC_2_6_3_EncodeUrl_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_3_EncodeUrl bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_hcs = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
bevt_6_ta_ph = beva_str.bem_sizeGet_0();
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = bevt_6_ta_ph.bem_multiply_1(bevt_7_ta_ph);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_5_ta_ph);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_pt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_8_ta_ph);
while (true)
/* Line: 216*/ {
bevt_9_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 216*/ {
bevl_tb.bem_next_1(bevl_pt);
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_10_ta_ph);
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
if (bevl_ac.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
if (bevl_ac.bevi_int < bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
 else /* Line: 219*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_ac.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(94));
if (bevl_ac.bevi_int < bevt_18_ta_ph.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
 else /* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(94));
if (bevl_ac.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_22_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
if (bevl_ac.bevi_int < bevt_22_ta_ph.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
 else /* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_24_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(44));
if (bevl_ac.bevi_int > bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_26_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
if (bevl_ac.bevi_int < bevt_26_ta_ph.bevi_int) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
 else /* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_28_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
if (bevl_ac.bevi_int == bevt_28_ta_ph.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 219*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 219*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 219*/ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 220*/
 else /* Line: 219*/ {
bevt_30_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
if (bevl_ac.bevi_int == bevt_30_ta_ph.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_r.bem_addValue_1(bevt_31_ta_ph);
} /* Line: 222*/
 else /* Line: 223*/ {
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_r.bem_addValue_1(bevt_32_ta_ph);
bevt_33_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_hcs = bevl_pt.bem_getHex_1(bevt_33_ta_ph);
bevl_r.bem_addValue_1(bevl_hcs);
} /* Line: 226*/
} /* Line: 219*/
} /* Line: 219*/
 else /* Line: 216*/ {
break;
} /* Line: 216*/
} /* Line: 216*/
bevt_34_ta_ph = bevl_r.bem_toString_0();
return bevt_34_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_npl = null;
BEC_2_4_3_MathInt bevl_npe = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevl_ispl = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
bevt_2_ta_ph = beva_str.bem_sizeGet_0();
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_npl = beva_str.bem_find_2(bevt_3_ta_ph, bevl_last);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_npe = beva_str.bem_find_2(bevt_4_ta_ph, bevl_last);
if (bevl_npe == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
if (bevl_npl == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 242*/ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 242*/
 else /* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 242*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 242*/ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 244*/
 else /* Line: 245*/ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 247*/
bevl_len = beva_str.bem_sizeGet_0();
while (true)
/* Line: 251*/ {
if (bevl_i == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 251*/ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 252*/ {
bevt_10_ta_ph = beva_str.bem_substring_2(bevl_last, bevl_i);
bevl_r.bem_addValue_1(bevt_10_ta_ph);
bevl_last = bevl_i;
} /* Line: 254*/
if (bevl_ispl.bevi_bool)/* Line: 256*/ {
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_2));
bevl_r.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_last = bevl_i.bem_add_1(bevt_12_ta_ph);
} /* Line: 258*/
 else /* Line: 259*/ {
bevt_15_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_14_ta_ph = bevl_i.bem_add_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_int < bevl_len.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 260*/ {
bevt_19_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_18_ta_ph = bevl_i.bem_add_1(bevt_19_ta_ph);
bevt_21_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevt_20_ta_ph = bevl_i.bem_add_1(bevt_21_ta_ph);
bevt_17_ta_ph = beva_str.bem_substring_2(bevt_18_ta_ph, bevt_20_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_hexNew_1(bevt_17_ta_ph);
bevl_r.bem_addValue_1(bevt_16_ta_ph);
bevt_22_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevl_last = bevl_i.bem_add_1(bevt_22_ta_ph);
} /* Line: 262*/
} /* Line: 260*/
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_0));
bevl_npl = beva_str.bem_find_2(bevt_23_ta_ph, bevl_last);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_3_EncodeUrl_bels_1));
bevl_npe = beva_str.bem_find_2(bevt_24_ta_ph, bevl_last);
if (bevl_npe == null) {
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 267*/ {
if (bevl_npl == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 267*/ {
if (bevl_npl.bevi_int < bevl_npe.bevi_int) {
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_27_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 267*/
 else /* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 267*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 267*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 267*/ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_i = bevl_npl;
} /* Line: 269*/
 else /* Line: 270*/ {
bevl_ispl = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_i = bevl_npe;
} /* Line: 272*/
} /* Line: 267*/
 else /* Line: 251*/ {
break;
} /* Line: 251*/
} /* Line: 251*/
if (bevl_last.bevi_int < bevl_len.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 275*/ {
bevt_29_ta_ph = beva_str.bem_substring_2(bevl_last, bevl_len);
bevl_r.bem_addValue_1(bevt_29_ta_ph);
} /* Line: 276*/
bevt_30_ta_ph = bevl_r.bem_toString_0();
return bevt_30_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {213, 213, 213, 213, 214, 215, 215, 216, 217, 218, 218, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 219, 219, 219, 0, 0, 0, 0, 0, 0, 219, 219, 219, 0, 0, 220, 221, 221, 221, 222, 222, 224, 224, 225, 225, 226, 229, 229, 233, 233, 234, 240, 240, 241, 241, 242, 242, 0, 242, 242, 242, 242, 0, 0, 0, 0, 0, 243, 244, 246, 247, 250, 251, 251, 252, 252, 253, 253, 254, 257, 257, 258, 258, 260, 260, 260, 260, 261, 261, 261, 261, 261, 261, 261, 262, 262, 265, 265, 266, 266, 267, 267, 0, 267, 267, 267, 267, 0, 0, 0, 0, 0, 268, 269, 271, 272, 275, 275, 276, 276, 278, 278};
public static new int[] bevs_smnlec
 = new int[] {64, 65, 66, 67, 68, 69, 70, 73, 75, 76, 77, 78, 79, 84, 85, 86, 91, 92, 95, 99, 102, 105, 106, 111, 112, 113, 118, 119, 122, 126, 129, 132, 136, 139, 140, 145, 146, 147, 152, 153, 156, 160, 163, 166, 170, 173, 174, 179, 180, 181, 186, 187, 190, 194, 197, 200, 204, 207, 208, 213, 214, 217, 221, 224, 225, 230, 231, 232, 235, 236, 237, 238, 239, 247, 248, 289, 290, 291, 292, 293, 294, 295, 296, 301, 302, 305, 310, 311, 316, 317, 320, 324, 327, 330, 334, 335, 338, 339, 341, 344, 349, 350, 355, 356, 357, 358, 361, 362, 363, 364, 367, 368, 369, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 386, 387, 388, 389, 390, 395, 396, 399, 404, 405, 410, 411, 414, 418, 421, 424, 428, 429, 432, 433, 440, 445, 446, 447, 449, 450};
/* BEGIN LINEINFO 
assign 1 213 64
sizeGet 0 213 64
assign 1 213 65
new 0 213 65
assign 1 213 66
multiply 1 213 66
assign 1 213 67
new 1 213 67
assign 1 214 68
new 1 214 68
assign 1 215 69
new 0 215 69
assign 1 215 70
new 1 215 70
assign 1 216 73
hasNextGet 0 216 73
next 1 217 75
assign 1 218 76
new 0 218 76
assign 1 218 77
getCode 1 218 77
assign 1 219 78
new 0 219 78
assign 1 219 79
greater 1 219 84
assign 1 219 85
new 0 219 85
assign 1 219 86
lesser 1 219 91
assign 1 0 92
assign 1 0 95
assign 1 0 99
assign 1 0 102
assign 1 219 105
new 0 219 105
assign 1 219 106
greater 1 219 111
assign 1 219 112
new 0 219 112
assign 1 219 113
lesser 1 219 118
assign 1 0 119
assign 1 0 122
assign 1 0 126
assign 1 0 129
assign 1 0 132
assign 1 0 136
assign 1 219 139
new 0 219 139
assign 1 219 140
greater 1 219 145
assign 1 219 146
new 0 219 146
assign 1 219 147
lesser 1 219 152
assign 1 0 153
assign 1 0 156
assign 1 0 160
assign 1 0 163
assign 1 0 166
assign 1 0 170
assign 1 219 173
new 0 219 173
assign 1 219 174
greater 1 219 179
assign 1 219 180
new 0 219 180
assign 1 219 181
lesser 1 219 186
assign 1 0 187
assign 1 0 190
assign 1 0 194
assign 1 0 197
assign 1 0 200
assign 1 0 204
assign 1 219 207
new 0 219 207
assign 1 219 208
equals 1 219 213
assign 1 0 214
assign 1 0 217
addValue 1 220 221
assign 1 221 224
new 0 221 224
assign 1 221 225
equals 1 221 230
assign 1 222 231
new 0 222 231
addValue 1 222 232
assign 1 224 235
new 0 224 235
addValue 1 224 236
assign 1 225 237
new 0 225 237
assign 1 225 238
getHex 1 225 238
addValue 1 226 239
assign 1 229 247
toString 0 229 247
return 1 229 248
assign 1 233 289
sizeGet 0 233 289
assign 1 233 290
new 1 233 290
assign 1 234 291
new 0 234 291
assign 1 240 292
new 0 240 292
assign 1 240 293
find 2 240 293
assign 1 241 294
new 0 241 294
assign 1 241 295
find 2 241 295
assign 1 242 296
undef 1 242 301
assign 1 0 302
assign 1 242 305
def 1 242 310
assign 1 242 311
lesser 1 242 316
assign 1 0 317
assign 1 0 320
assign 1 0 324
assign 1 0 327
assign 1 0 330
assign 1 243 334
new 0 243 334
assign 1 244 335
assign 1 246 338
new 0 246 338
assign 1 247 339
assign 1 250 341
sizeGet 0 250 341
assign 1 251 344
def 1 251 349
assign 1 252 350
greater 1 252 355
assign 1 253 356
substring 2 253 356
addValue 1 253 357
assign 1 254 358
assign 1 257 361
new 0 257 361
addValue 1 257 362
assign 1 258 363
new 0 258 363
assign 1 258 364
add 1 258 364
assign 1 260 367
new 0 260 367
assign 1 260 368
add 1 260 368
assign 1 260 369
lesser 1 260 374
assign 1 261 375
new 0 261 375
assign 1 261 376
add 1 261 376
assign 1 261 377
new 0 261 377
assign 1 261 378
add 1 261 378
assign 1 261 379
substring 2 261 379
assign 1 261 380
hexNew 1 261 380
addValue 1 261 381
assign 1 262 382
new 0 262 382
assign 1 262 383
add 1 262 383
assign 1 265 386
new 0 265 386
assign 1 265 387
find 2 265 387
assign 1 266 388
new 0 266 388
assign 1 266 389
find 2 266 389
assign 1 267 390
undef 1 267 395
assign 1 0 396
assign 1 267 399
def 1 267 404
assign 1 267 405
lesser 1 267 410
assign 1 0 411
assign 1 0 414
assign 1 0 418
assign 1 0 421
assign 1 0 424
assign 1 268 428
new 0 268 428
assign 1 269 429
assign 1 271 432
new 0 271 432
assign 1 272 433
assign 1 275 440
lesser 1 275 445
assign 1 276 446
substring 2 276 446
addValue 1 276 447
assign 1 278 449
toString 0 278 449
return 1 278 450
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1931705863: return bem_sourceFileNameGet_0();
case -893093197: return bem_toString_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case 954703233: return bem_create_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1834246217: return bem_classNameGet_0();
case -193582610: return bem_tagGet_0();
case -975498393: return bem_fieldNamesGet_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case -487191921: return bem_default_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1220213109: return bem_otherClass_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -1098927836: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -2092810203: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeUrl_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeUrl_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_3_EncodeUrl();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst = (BEC_2_6_3_EncodeUrl) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_3_EncodeUrl.bece_BEC_2_6_3_EncodeUrl_bevs_type;
}
}
}
