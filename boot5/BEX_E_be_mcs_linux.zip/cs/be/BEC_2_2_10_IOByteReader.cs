namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_10_IOByteReader : BEC_2_6_6_SystemObject {
public BEC_2_2_10_IOByteReader() { }
static BEC_2_2_10_IOByteReader() { }
private static byte[] becc_BEC_2_2_10_IOByteReader_clname = {0x49,0x4F,0x3A,0x42,0x79,0x74,0x65,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_10_IOByteReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_inst;

public static new BET_2_2_10_IOByteReader bece_BEC_2_2_10_IOByteReader_bevs_type;

public BEC_2_2_6_IOReader bevp_reader;
public BEC_2_4_6_TextString bevp_buf;
public BEC_2_4_12_TextByteIterator bevp_iter;
public virtual BEC_2_2_10_IOByteReader bem_readerBufferNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_6_TextString beva__buf) {
bevp_reader = beva__reader;
bevp_buf = beva__buf;
bevp_iter = bevp_buf.bem_biterGet_0();
return this;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerNew_1(BEC_2_2_6_IOReader beva__reader) {
BEC_2_2_10_IOByteReader bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(256));
bevt_0_ta_ph = (BEC_2_2_10_IOByteReader) bem_readerBlockNew_2(beva__reader, bevt_1_ta_ph);
return (BEC_2_2_10_IOByteReader) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerBlockNew_2(BEC_2_2_6_IOReader beva__reader, BEC_2_4_3_MathInt beva__blockSize) {
BEC_2_2_10_IOByteReader bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva__blockSize);
bevt_0_ta_ph = (BEC_2_2_10_IOByteReader) bem_readerBufferNew_2(beva__reader, bevt_1_ta_ph);
return (BEC_2_2_10_IOByteReader) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_iter.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 39*/ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_ta_ph);
} /* Line: 41*/
bevt_3_ta_ph = bevp_iter.bem_hasNextGet_0();
return bevt_3_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_dest) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_iter.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 51*/ {
bevp_reader.bem_readIntoBuffer_1(bevp_buf);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_iter.bem_posSet_1(bevt_2_ta_ph);
} /* Line: 53*/
bevt_3_ta_ph = bevp_iter.bem_next_1(beva_dest);
return bevt_3_ta_ph;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_readerGet_0() {
return bevp_reader;
} /*method end*/
public BEC_2_2_6_IOReader bem_readerGetDirect_0() {
return bevp_reader;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_readerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_readerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_reader = (BEC_2_2_6_IOReader) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_bufGet_0() {
return bevp_buf;
} /*method end*/
public BEC_2_4_6_TextString bem_bufGetDirect_0() {
return bevp_buf;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_bufSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_bufSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_iterGet_0() {
return bevp_iter;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_iterGetDirect_0() {
return bevp_iter;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_10_IOByteReader bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_iter = (BEC_2_4_12_TextByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {24, 25, 26, 31, 31, 31, 35, 35, 35, 39, 39, 39, 40, 41, 41, 43, 43, 47, 47, 47, 47, 51, 51, 51, 52, 53, 53, 55, 55, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 21, 27, 28, 29, 34, 35, 36, 43, 44, 49, 50, 51, 52, 54, 55, 61, 62, 63, 64, 71, 72, 77, 78, 79, 80, 82, 83, 86, 89, 92, 96, 100, 103, 106, 110, 114, 117, 120, 124};
/* BEGIN LINEINFO 
assign 1 24 19
assign 1 25 20
assign 1 26 21
biterGet 0 26 21
assign 1 31 27
new 0 31 27
assign 1 31 28
readerBlockNew 2 31 28
return 1 31 29
assign 1 35 34
new 1 35 34
assign 1 35 35
readerBufferNew 2 35 35
return 1 35 36
assign 1 39 43
hasNextGet 0 39 43
assign 1 39 44
not 0 39 49
readIntoBuffer 1 40 50
assign 1 41 51
new 0 41 51
posSet 1 41 52
assign 1 43 54
hasNextGet 0 43 54
return 1 43 55
assign 1 47 61
new 0 47 61
assign 1 47 62
new 1 47 62
assign 1 47 63
next 1 47 63
return 1 47 64
assign 1 51 71
hasNextGet 0 51 71
assign 1 51 72
not 0 51 77
readIntoBuffer 1 52 78
assign 1 53 79
new 0 53 79
posSet 1 53 80
assign 1 55 82
next 1 55 82
return 1 55 83
return 1 0 86
return 1 0 89
assign 1 0 92
assign 1 0 96
return 1 0 100
return 1 0 103
assign 1 0 106
assign 1 0 110
return 1 0 114
return 1 0 117
assign 1 0 120
assign 1 0 124
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 119461913: return bem_tagGet_0();
case 281444821: return bem_fieldIteratorGet_0();
case 663571840: return bem_readerGet_0();
case -678541085: return bem_classNameGet_0();
case 1352572835: return bem_bufGet_0();
case -1754478112: return bem_print_0();
case -943180211: return bem_bufGetDirect_0();
case -548377481: return bem_iterGet_0();
case -2017009146: return bem_new_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -1005119995: return bem_many_0();
case -508298247: return bem_hasNextGet_0();
case -1475550710: return bem_create_0();
case -225870373: return bem_serializeToString_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 2045941275: return bem_iteratorGet_0();
case -744679096: return bem_fieldNamesGet_0();
case -1486279572: return bem_serializeContents_0();
case -1275325619: return bem_toString_0();
case -868025575: return bem_iterGetDirect_0();
case 501088997: return bem_sourceFileNameGet_0();
case -639297756: return bem_toAny_0();
case -545556484: return bem_once_0();
case 450495808: return bem_nextGet_0();
case 611702865: return bem_copy_0();
case -95554016: return bem_readerGetDirect_0();
case -1583672278: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1539946307: return bem_readerNew_1((BEC_2_2_6_IOReader) bevd_0);
case -464526900: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case -1714112378: return bem_readerSet_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 495855889: return bem_iterSet_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case -75499273: return bem_bufSetDirect_1(bevd_0);
case 1798832723: return bem_readerSetDirect_1(bevd_0);
case 751389175: return bem_iterSetDirect_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 358287057: return bem_bufSet_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1677005514: return bem_readerBlockNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 458437697: return bem_readerBufferNew_2((BEC_2_2_6_IOReader) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_2_10_IOByteReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_10_IOByteReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_10_IOByteReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst = (BEC_2_2_10_IOByteReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_10_IOByteReader.bece_BEC_2_2_10_IOByteReader_bevs_type;
}
}
}
