namespace be {
/* IO:File: source/base/Exceptions.be */
public class BEC_2_9_5_ExceptionFrame : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ExceptionFrame() { }
static BEC_2_9_5_ExceptionFrame() { }
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clname = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x46,0x72,0x61,0x6D,0x65};
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x46,0x72,0x61,0x6D,0x65,0x3E,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_1 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_2 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_7 = {0x0A};
public static new BEC_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_inst;

public static new BET_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_type;

public BEC_2_4_6_TextString bevp_klassName;
public BEC_2_4_6_TextString bevp_methodName;
public BEC_2_4_6_TextString bevp_emitFileName;
public BEC_2_4_3_MathInt bevp_emitLine;
public BEC_2_4_6_TextString bevp_fileName;
public BEC_2_4_3_MathInt bevp_line;
public virtual BEC_2_9_5_ExceptionFrame bem_new_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__emitFileName, BEC_2_4_3_MathInt beva__emitLine) {
bevp_klassName = beva__klassName;
bevp_methodName = beva__methodName;
bevp_emitFileName = beva__emitFileName;
bevp_emitLine = beva__emitLine;
/* Line: 252*/ {
bem_extractLine_0();
} /* Line: 253*/
return this;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_extractLine_0() {
BEC_2_6_16_SystemExceptionBuilder bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_16_SystemExceptionBuilder) BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
bevp_line = bevt_0_ta_ph.bem_getLineForEmitLine_2(bevp_klassName, bevp_emitLine);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_9_5_ExceptionFrame_bels_0));
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_9_5_ExceptionFrame_bels_1));
bevl_res.bem_addValue_1(bevt_0_ta_ph);
if (bevp_klassName == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 267*/ {
bevl_res.bem_addValue_1(bevp_klassName);
} /* Line: 267*/
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_9_5_ExceptionFrame_bels_2));
bevl_res.bem_addValue_1(bevt_2_ta_ph);
if (bevp_methodName == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 269*/ {
bevl_res.bem_addValue_1(bevp_methodName);
} /* Line: 269*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_9_5_ExceptionFrame_bels_3));
bevl_res.bem_addValue_1(bevt_4_ta_ph);
if (bevp_fileName == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 271*/ {
bevl_res.bem_addValue_1(bevp_fileName);
} /* Line: 271*/
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_9_5_ExceptionFrame_bels_4));
bevl_res.bem_addValue_1(bevt_6_ta_ph);
if (bevp_line == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 273*/ {
bevt_8_ta_ph = bevp_line.bem_toString_0();
bevl_res.bem_addValue_1(bevt_8_ta_ph);
} /* Line: 273*/
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_5));
bevl_res.bem_addValue_1(bevt_9_ta_ph);
if (bevp_emitFileName == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 275*/ {
bevl_res.bem_addValue_1(bevp_emitFileName);
} /* Line: 275*/
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_6));
bevl_res.bem_addValue_1(bevt_11_ta_ph);
if (bevp_emitLine == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 277*/ {
bevt_13_ta_ph = bevp_emitLine.bem_toString_0();
bevl_res.bem_addValue_1(bevt_13_ta_ph);
} /* Line: 277*/
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_9_5_ExceptionFrame_bels_7));
bevl_res.bem_addValue_1(bevt_14_ta_ph);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassNameGet_0() {
return bevp_klassName;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGetDirect_0() {
return bevp_klassName;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public BEC_2_4_6_TextString bem_methodNameGetDirect_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitFileNameGet_0() {
return bevp_emitFileName;
} /*method end*/
public BEC_2_4_6_TextString bem_emitFileNameGetDirect_0() {
return bevp_emitFileName;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_emitFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_emitLineGet_0() {
return bevp_emitLine;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitLineGetDirect_0() {
return bevp_emitLine;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_emitLineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitLineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public BEC_2_4_6_TextString bem_fileNameGetDirect_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lineGet_0() {
return bevp_line;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGetDirect_0() {
return bevp_line;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_lineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {245, 246, 247, 248, 253, 261, 261, 265, 266, 266, 267, 267, 267, 268, 268, 269, 269, 269, 270, 270, 271, 271, 271, 272, 272, 273, 273, 273, 273, 274, 274, 275, 275, 275, 276, 276, 277, 277, 277, 277, 278, 278, 279, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 30, 32, 38, 39, 59, 60, 61, 62, 67, 68, 70, 71, 72, 77, 78, 80, 81, 82, 87, 88, 90, 91, 92, 97, 98, 99, 101, 102, 103, 108, 109, 111, 112, 113, 118, 119, 120, 122, 123, 124, 127, 130, 133, 137, 141, 144, 147, 151, 155, 158, 161, 165, 169, 172, 175, 179, 183, 186, 189, 193, 197, 200, 203, 207};
/* BEGIN LINEINFO 
assign 1 245 27
assign 1 246 28
assign 1 247 29
assign 1 248 30
extractLine 0 253 32
assign 1 261 38
new 0 261 38
assign 1 261 39
getLineForEmitLine 2 261 39
assign 1 265 59
new 0 265 59
assign 1 266 60
new 0 266 60
addValue 1 266 61
assign 1 267 62
def 1 267 67
addValue 1 267 68
assign 1 268 70
new 0 268 70
addValue 1 268 71
assign 1 269 72
def 1 269 77
addValue 1 269 78
assign 1 270 80
new 0 270 80
addValue 1 270 81
assign 1 271 82
def 1 271 87
addValue 1 271 88
assign 1 272 90
new 0 272 90
addValue 1 272 91
assign 1 273 92
def 1 273 97
assign 1 273 98
toString 0 273 98
addValue 1 273 99
assign 1 274 101
new 0 274 101
addValue 1 274 102
assign 1 275 103
def 1 275 108
addValue 1 275 109
assign 1 276 111
new 0 276 111
addValue 1 276 112
assign 1 277 113
def 1 277 118
assign 1 277 119
toString 0 277 119
addValue 1 277 120
assign 1 278 122
new 0 278 122
addValue 1 278 123
return 1 279 124
return 1 0 127
return 1 0 130
assign 1 0 133
assign 1 0 137
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
return 1 0 155
return 1 0 158
assign 1 0 161
assign 1 0 165
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -115789676: return bem_emitLineGetDirect_0();
case -1076915155: return bem_serializeToString_0();
case -2118708930: return bem_new_0();
case 946360922: return bem_serializationIteratorGet_0();
case 446504410: return bem_lineGetDirect_0();
case -1067547495: return bem_emitFileNameGetDirect_0();
case -893093197: return bem_toString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 178250922: return bem_extractLine_0();
case -675463808: return bem_emitFileNameGet_0();
case -975498393: return bem_fieldNamesGet_0();
case -1122166678: return bem_fileNameGet_0();
case 421177749: return bem_print_0();
case 1971771638: return bem_klassNameGetDirect_0();
case -128659508: return bem_emitLineGet_0();
case 1834246217: return bem_classNameGet_0();
case -40905183: return bem_echo_0();
case -193582610: return bem_tagGet_0();
case -1653939165: return bem_iteratorGet_0();
case 1955283253: return bem_klassNameGet_0();
case 1974505938: return bem_hashGet_0();
case 954703233: return bem_create_0();
case 1931705863: return bem_sourceFileNameGet_0();
case 2081363871: return bem_copy_0();
case -269512511: return bem_methodNameGetDirect_0();
case 1906790658: return bem_methodNameGet_0();
case -979668744: return bem_lineGet_0();
case 985380887: return bem_fileNameGetDirect_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1153344161: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 177409367: return bem_otherType_1(bevd_0);
case 795909813: return bem_emitFileNameSet_1(bevd_0);
case -1222964272: return bem_fileNameSetDirect_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -2101745537: return bem_lineSet_1(bevd_0);
case -772933514: return bem_emitLineSetDirect_1(bevd_0);
case -1518598205: return bem_emitLineSet_1(bevd_0);
case 541118601: return bem_lineSetDirect_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -798089535: return bem_methodNameSetDirect_1(bevd_0);
case 1646084805: return bem_klassNameSetDirect_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 991266054: return bem_fileNameSet_1(bevd_0);
case 296811218: return bem_klassNameSet_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -336394327: return bem_emitFileNameSetDirect_1(bevd_0);
case 1057844660: return bem_methodNameSet_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 553335663: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ExceptionFrame_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_5_ExceptionFrame_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ExceptionFrame();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst = (BEC_2_9_5_ExceptionFrame) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_type;
}
}
}
