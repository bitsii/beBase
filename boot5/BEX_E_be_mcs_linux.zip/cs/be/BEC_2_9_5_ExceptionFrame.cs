namespace be {
/* IO:File: source/base/Exceptions.be */
public class BEC_2_9_5_ExceptionFrame : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ExceptionFrame() { }
static BEC_2_9_5_ExceptionFrame() { }
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clname = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x46,0x72,0x61,0x6D,0x65};
private static byte[] becc_BEC_2_9_5_ExceptionFrame_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x46,0x72,0x61,0x6D,0x65,0x3E,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_1 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_2 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_5 = {0x20,0x45,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_9_5_ExceptionFrame_bels_7 = {0x0A};
public static new BEC_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_inst;

public static new BET_2_9_5_ExceptionFrame bece_BEC_2_9_5_ExceptionFrame_bevs_type;

public BEC_2_4_6_TextString bevp_klassName;
public BEC_2_4_6_TextString bevp_methodName;
public BEC_2_4_6_TextString bevp_emitFileName;
public BEC_2_4_3_MathInt bevp_emitLine;
public BEC_2_4_6_TextString bevp_fileName;
public BEC_2_4_3_MathInt bevp_line;
public virtual BEC_2_9_5_ExceptionFrame bem_new_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__emitFileName, BEC_2_4_3_MathInt beva__emitLine) {
bevp_klassName = beva__klassName;
bevp_methodName = beva__methodName;
bevp_emitFileName = beva__emitFileName;
bevp_emitLine = beva__emitLine;
 /* Line: 478 */ {
bem_extractLine_0();
} /* Line: 479 */
return this;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_extractLine_0() {
BEC_2_6_16_SystemExceptionBuilder bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_16_SystemExceptionBuilder) BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
bevp_line = bevt_0_tmpany_phold.bem_getLineForEmitLine_2(bevp_klassName, bevp_emitLine);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_9_5_ExceptionFrame_bels_0));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_9_5_ExceptionFrame_bels_1));
bevl_res.bem_addValue_1(bevt_0_tmpany_phold);
if (bevp_klassName == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 493 */ {
bevl_res.bem_addValue_1(bevp_klassName);
} /* Line: 493 */
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_9_5_ExceptionFrame_bels_2));
bevl_res.bem_addValue_1(bevt_2_tmpany_phold);
if (bevp_methodName == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 495 */ {
bevl_res.bem_addValue_1(bevp_methodName);
} /* Line: 495 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_9_5_ExceptionFrame_bels_3));
bevl_res.bem_addValue_1(bevt_4_tmpany_phold);
if (bevp_fileName == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 497 */ {
bevl_res.bem_addValue_1(bevp_fileName);
} /* Line: 497 */
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_9_5_ExceptionFrame_bels_4));
bevl_res.bem_addValue_1(bevt_6_tmpany_phold);
if (bevp_line == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 499 */ {
bevt_8_tmpany_phold = bevp_line.bem_toString_0();
bevl_res.bem_addValue_1(bevt_8_tmpany_phold);
} /* Line: 499 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_5));
bevl_res.bem_addValue_1(bevt_9_tmpany_phold);
if (bevp_emitFileName == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 501 */ {
bevl_res.bem_addValue_1(bevp_emitFileName);
} /* Line: 501 */
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_9_5_ExceptionFrame_bels_6));
bevl_res.bem_addValue_1(bevt_11_tmpany_phold);
if (bevp_emitLine == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_13_tmpany_phold = bevp_emitLine.bem_toString_0();
bevl_res.bem_addValue_1(bevt_13_tmpany_phold);
} /* Line: 503 */
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_9_5_ExceptionFrame_bels_7));
bevl_res.bem_addValue_1(bevt_14_tmpany_phold);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassNameGet_0() {
return bevp_klassName;
} /*method end*/
public BEC_2_4_6_TextString bem_klassNameGetDirect_0() {
return bevp_klassName;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_klassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public BEC_2_4_6_TextString bem_methodNameGetDirect_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_methodName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitFileNameGet_0() {
return bevp_emitFileName;
} /*method end*/
public BEC_2_4_6_TextString bem_emitFileNameGetDirect_0() {
return bevp_emitFileName;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_emitFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_emitLineGet_0() {
return bevp_emitLine;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitLineGetDirect_0() {
return bevp_emitLine;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_emitLineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_emitLineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLine = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public BEC_2_4_6_TextString bem_fileNameGetDirect_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lineGet_0() {
return bevp_line;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGetDirect_0() {
return bevp_line;
} /*method end*/
public virtual BEC_2_9_5_ExceptionFrame bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ExceptionFrame bem_lineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {471, 472, 473, 474, 479, 487, 487, 491, 492, 492, 493, 493, 493, 494, 494, 495, 495, 495, 496, 496, 497, 497, 497, 498, 498, 499, 499, 499, 499, 500, 500, 501, 501, 501, 502, 502, 503, 503, 503, 503, 504, 504, 505, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 30, 32, 38, 39, 59, 60, 61, 62, 67, 68, 70, 71, 72, 77, 78, 80, 81, 82, 87, 88, 90, 91, 92, 97, 98, 99, 101, 102, 103, 108, 109, 111, 112, 113, 118, 119, 120, 122, 123, 124, 127, 130, 133, 137, 141, 144, 147, 151, 155, 158, 161, 165, 169, 172, 175, 179, 183, 186, 189, 193, 197, 200, 203, 207};
/* BEGIN LINEINFO 
assign 1 471 27
assign 1 472 28
assign 1 473 29
assign 1 474 30
extractLine 0 479 32
assign 1 487 38
new 0 487 38
assign 1 487 39
getLineForEmitLine 2 487 39
assign 1 491 59
new 0 491 59
assign 1 492 60
new 0 492 60
addValue 1 492 61
assign 1 493 62
def 1 493 67
addValue 1 493 68
assign 1 494 70
new 0 494 70
addValue 1 494 71
assign 1 495 72
def 1 495 77
addValue 1 495 78
assign 1 496 80
new 0 496 80
addValue 1 496 81
assign 1 497 82
def 1 497 87
addValue 1 497 88
assign 1 498 90
new 0 498 90
addValue 1 498 91
assign 1 499 92
def 1 499 97
assign 1 499 98
toString 0 499 98
addValue 1 499 99
assign 1 500 101
new 0 500 101
addValue 1 500 102
assign 1 501 103
def 1 501 108
addValue 1 501 109
assign 1 502 111
new 0 502 111
addValue 1 502 112
assign 1 503 113
def 1 503 118
assign 1 503 119
toString 0 503 119
addValue 1 503 120
assign 1 504 122
new 0 504 122
addValue 1 504 123
return 1 505 124
return 1 0 127
return 1 0 130
assign 1 0 133
assign 1 0 137
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
return 1 0 155
return 1 0 158
assign 1 0 161
assign 1 0 165
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1929291383: return bem_lineGetDirect_0();
case 1567126550: return bem_methodNameGetDirect_0();
case 343375430: return bem_create_0();
case -1846550974: return bem_serializeContents_0();
case -2129090979: return bem_emitLineGetDirect_0();
case -1574932366: return bem_print_0();
case 1080054999: return bem_fileNameGet_0();
case 131226213: return bem_toString_0();
case 2063546474: return bem_classNameGet_0();
case -1031399474: return bem_echo_0();
case 1970758688: return bem_fieldNamesGet_0();
case 1131385505: return bem_toAny_0();
case 2061421621: return bem_many_0();
case 2056394698: return bem_emitFileNameGetDirect_0();
case 1623740550: return bem_emitLineGet_0();
case 1013387649: return bem_klassNameGet_0();
case 1253953314: return bem_serializationIteratorGet_0();
case 1279906777: return bem_serializeToString_0();
case 431618869: return bem_once_0();
case -1485517163: return bem_copy_0();
case 1857164583: return bem_emitFileNameGet_0();
case 421749162: return bem_iteratorGet_0();
case -2051799514: return bem_new_0();
case 916294969: return bem_sourceFileNameGet_0();
case 911313117: return bem_tagGet_0();
case -957769093: return bem_deserializeClassNameGet_0();
case -429288713: return bem_methodNameGet_0();
case -928163909: return bem_fieldIteratorGet_0();
case -825084265: return bem_hashGet_0();
case -30737044: return bem_fileNameGetDirect_0();
case -1445809059: return bem_lineGet_0();
case -994187651: return bem_klassNameGetDirect_0();
case 861616271: return bem_extractLine_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1181240679: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1551421646: return bem_copyTo_1(bevd_0);
case 1383324451: return bem_sameObject_1(bevd_0);
case 522323083: return bem_klassNameSet_1(bevd_0);
case -1043050793: return bem_emitLineSet_1(bevd_0);
case 1375200128: return bem_methodNameSetDirect_1(bevd_0);
case -215581826: return bem_lineSet_1(bevd_0);
case -1809169317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1768644351: return bem_sameClass_1(bevd_0);
case -2018944701: return bem_def_1(bevd_0);
case -628476976: return bem_otherClass_1(bevd_0);
case 192530319: return bem_otherType_1(bevd_0);
case -1655018142: return bem_sameType_1(bevd_0);
case -1065536512: return bem_equals_1(bevd_0);
case 1227499991: return bem_lineSetDirect_1(bevd_0);
case 1558226146: return bem_methodNameSet_1(bevd_0);
case 1044863323: return bem_defined_1(bevd_0);
case 747155616: return bem_notEquals_1(bevd_0);
case -436556280: return bem_undef_1(bevd_0);
case 1091520504: return bem_emitLineSetDirect_1(bevd_0);
case 754078543: return bem_emitFileNameSetDirect_1(bevd_0);
case 1147111468: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -533301219: return bem_klassNameSetDirect_1(bevd_0);
case 1713412654: return bem_fileNameSetDirect_1(bevd_0);
case -64538580: return bem_fileNameSet_1(bevd_0);
case 1928047187: return bem_undefined_1(bevd_0);
case 1555616281: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 703110193: return bem_emitFileNameSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1990600260: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1260241587: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -598891548: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1655882914: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1041029455: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -214435591: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -40143354: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1560513596: return bem_new_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ExceptionFrame_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_5_ExceptionFrame_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ExceptionFrame();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst = (BEC_2_9_5_ExceptionFrame) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_5_ExceptionFrame.bece_BEC_2_9_5_ExceptionFrame_bevs_type;
}
}
}
