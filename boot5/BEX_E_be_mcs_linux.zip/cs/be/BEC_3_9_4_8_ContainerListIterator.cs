namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_3_9_4_8_ContainerListIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_4_8_ContainerListIterator() { }
static BEC_3_9_4_8_ContainerListIterator() { }
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_9_4_8_ContainerListIterator_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_9_4_8_ContainerListIterator_bevo_1 = (new BEC_2_4_3_MathInt(-1));
public static new BEC_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_4_3_MathInt bevp_npos;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_list = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevp_npos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) {
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_4_ContainerList) beva_a;
bevp_npos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_containerGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_3_9_4_8_ContainerListIterator_bevo_0;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_4_tmpany_phold = bevp_list.bem_lengthGet_0();
if (bevp_pos.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 35 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 35 */
 else  /* Line: 35 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 35 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 36 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_currentGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevp_npos.bevi_int = bevp_pos.bevi_int;
bevp_npos.bevi_int++;
bevt_2_tmpany_phold = bece_BEC_3_9_4_8_ContainerListIterator_bevo_1;
if (bevp_pos.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_4_tmpany_phold = bevp_list.bem_lengthGet_0();
if (bevp_npos.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 52 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_tmpany_phold;
} /* Line: 53 */
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevp_pos.bevi_int++;
bevt_0_tmpany_phold = bevp_list.bem_get_1(bevp_pos);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevp_pos.bevi_int++;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
bevp_pos.bevi_int += beva_multiNullCount.bevi_int;
bevp_pos = bevp_pos;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() {
return bevp_list;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nposGet_0() {
return bevp_npos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_nposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_npos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 19, 20, 25, 26, 27, 31, 35, 35, 35, 35, 35, 35, 0, 0, 0, 36, 36, 38, 38, 42, 42, 46, 46, 50, 51, 52, 52, 52, 52, 52, 52, 0, 0, 0, 53, 53, 55, 55, 59, 60, 60, 64, 65, 65, 69, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 20, 21, 25, 26, 27, 31, 41, 42, 47, 48, 49, 54, 55, 58, 62, 65, 66, 68, 69, 73, 74, 78, 79, 89, 90, 91, 92, 97, 98, 99, 104, 105, 108, 112, 115, 116, 118, 119, 123, 124, 125, 129, 130, 131, 134, 139, 142, 146, 149, 153, 156};
/* BEGIN LINEINFO 
assign 1 18 18
new 0 18 18
assign 1 19 19
new 0 19 19
assign 1 19 20
new 1 19 20
assign 1 20 21
new 0 20 21
assign 1 25 25
new 0 25 25
assign 1 26 26
assign 1 27 27
new 0 27 27
return 1 31 31
assign 1 35 41
new 0 35 41
assign 1 35 42
greater 1 35 47
assign 1 35 48
lengthGet 0 35 48
assign 1 35 49
lesser 1 35 54
assign 1 0 55
assign 1 0 58
assign 1 0 62
assign 1 36 65
new 0 36 65
return 1 36 66
assign 1 38 68
new 0 38 68
return 1 38 69
assign 1 42 73
get 1 42 73
return 1 42 74
assign 1 46 78
put 2 46 78
return 1 46 79
setValue 1 50 89
incrementValue 0 51 90
assign 1 52 91
new 0 52 91
assign 1 52 92
greaterEquals 1 52 97
assign 1 52 98
lengthGet 0 52 98
assign 1 52 99
lesser 1 52 104
assign 1 0 105
assign 1 0 108
assign 1 0 112
assign 1 53 115
new 0 53 115
return 1 53 116
assign 1 55 118
new 0 55 118
return 1 55 119
incrementValue 0 59 123
assign 1 60 124
get 1 60 124
return 1 60 125
incrementValue 0 64 129
assign 1 65 130
put 2 65 130
return 1 65 131
assign 1 69 134
addValue 1 69 134
return 1 0 139
assign 1 0 142
return 1 0 146
assign 1 0 149
return 1 0 153
assign 1 0 156
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case -289190594: return bem_new_0();
case 1935523169: return bem_currentGet_0();
case 628114265: return bem_many_0();
case -86198663: return bem_print_0();
case -135573554: return bem_listGet_0();
case 1606100185: return bem_toAny_0();
case -693169976: return bem_serializeToString_0();
case 1260123968: return bem_hasCurrentGet_0();
case 2013906518: return bem_hasNextGet_0();
case 468841666: return bem_sourceFileNameGet_0();
case -2143843780: return bem_tagGet_0();
case -457712006: return bem_classNameGet_0();
case 1341475988: return bem_posGet_0();
case 386499474: return bem_deserializeClassNameGet_0();
case 1440809036: return bem_nextGet_0();
case 1110687349: return bem_serializationIteratorGet_0();
case 820088259: return bem_echo_0();
case 154399642: return bem_hashGet_0();
case -1896702956: return bem_serializeContents_0();
case 402795231: return bem_once_0();
case 1863363096: return bem_nposGet_0();
case 2141437344: return bem_containerGet_0();
case 1323527258: return bem_copy_0();
case -1710921376: return bem_iteratorGet_0();
case -285521200: return bem_create_0();
case -1679072038: return bem_toString_0();
case 1829615340: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 2033308650: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 405603043: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759835639: return bem_defined_1(bevd_0);
case 1958076839: return bem_undefined_1(bevd_0);
case -1281629522: return bem_posSet_1(bevd_0);
case -1403558192: return bem_nposSet_1(bevd_0);
case -993009622: return bem_nextSet_1(bevd_0);
case 2086659962: return bem_sameObject_1(bevd_0);
case 1519077869: return bem_new_1(bevd_0);
case 1253393632: return bem_def_1(bevd_0);
case -1211467604: return bem_copyTo_1(bevd_0);
case -459019861: return bem_currentSet_1(bevd_0);
case 914788459: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 365385951: return bem_equals_1(bevd_0);
case 938569326: return bem_notEquals_1(bevd_0);
case -641584584: return bem_sameClass_1(bevd_0);
case -1706185549: return bem_otherType_1(bevd_0);
case 713999383: return bem_undef_1(bevd_0);
case -861317881: return bem_otherClass_1(bevd_0);
case 343567700: return bem_sameType_1(bevd_0);
case -1497400251: return bem_listSet_1(bevd_0);
case -1770369050: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 823180387: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1125341844: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389614349: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1812156494: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1790570920: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2109777534: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1447567526: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1299212473: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_4_8_ContainerListIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_9_4_8_ContainerListIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_4_8_ContainerListIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst = (BEC_3_9_4_8_ContainerListIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
}
}
}
