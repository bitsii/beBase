namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_3_9_4_8_ContainerListIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_4_8_ContainerListIterator() { }
static BEC_3_9_4_8_ContainerListIterator() { }
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_9_4_8_ContainerListIterator_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_3_9_4_8_ContainerListIterator_bevo_1 = (new BEC_2_4_3_MathInt(-1));
public static new BEC_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;

public static new BET_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_4_3_MathInt bevp_npos;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_list = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_npos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) {
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_4_ContainerList) beva_a;
bevp_npos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_containerGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevt_2_ta_ph = bece_BEC_3_9_4_8_ContainerListIterator_bevo_0;
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 34*/ {
bevt_4_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_pos.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 34*/
 else /* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 34*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 35*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_currentGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevp_npos.bevi_int = bevp_pos.bevi_int;
bevp_npos.bevi_int++;
bevt_2_ta_ph = bece_BEC_3_9_4_8_ContainerListIterator_bevo_1;
if (bevp_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_4_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_npos.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 51*/
 else /* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 51*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 52*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
bevp_pos.bevi_int += beva_multiNullCount.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGetDirect_0() {
return bevp_pos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGetDirect_0() {
return bevp_list;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nposGet_0() {
return bevp_npos;
} /*method end*/
public BEC_2_4_3_MathInt bem_nposGetDirect_0() {
return bevp_npos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_nposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_npos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_nposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_npos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 18, 19, 24, 25, 26, 30, 34, 34, 34, 34, 34, 34, 0, 0, 0, 35, 35, 37, 37, 41, 41, 45, 45, 49, 50, 51, 51, 51, 51, 51, 51, 0, 0, 0, 52, 52, 54, 54, 58, 59, 59, 63, 64, 64, 68, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 24, 28, 29, 30, 34, 44, 45, 50, 51, 52, 57, 58, 61, 65, 68, 69, 71, 72, 76, 77, 81, 82, 92, 93, 94, 95, 100, 101, 102, 107, 108, 111, 115, 118, 119, 121, 122, 126, 127, 128, 132, 133, 134, 137, 141, 144, 147, 151, 155, 158, 161, 165, 169, 172, 175, 179};
/* BEGIN LINEINFO 
assign 1 17 21
new 0 17 21
assign 1 18 22
new 0 18 22
assign 1 18 23
new 1 18 23
assign 1 19 24
new 0 19 24
assign 1 24 28
new 0 24 28
assign 1 25 29
assign 1 26 30
new 0 26 30
return 1 30 34
assign 1 34 44
new 0 34 44
assign 1 34 45
greater 1 34 50
assign 1 34 51
lengthGet 0 34 51
assign 1 34 52
lesser 1 34 57
assign 1 0 58
assign 1 0 61
assign 1 0 65
assign 1 35 68
new 0 35 68
return 1 35 69
assign 1 37 71
new 0 37 71
return 1 37 72
assign 1 41 76
get 1 41 76
return 1 41 77
assign 1 45 81
put 2 45 81
return 1 45 82
setValue 1 49 92
incrementValue 0 50 93
assign 1 51 94
new 0 51 94
assign 1 51 95
greaterEquals 1 51 100
assign 1 51 101
lengthGet 0 51 101
assign 1 51 102
lesser 1 51 107
assign 1 0 108
assign 1 0 111
assign 1 0 115
assign 1 52 118
new 0 52 118
return 1 52 119
assign 1 54 121
new 0 54 121
return 1 54 122
incrementValue 0 58 126
assign 1 59 127
get 1 59 127
return 1 59 128
incrementValue 0 63 132
assign 1 64 133
put 2 64 133
return 1 64 134
addValue 1 68 137
return 1 0 141
return 1 0 144
assign 1 0 147
assign 1 0 151
return 1 0 155
return 1 0 158
assign 1 0 161
assign 1 0 165
return 1 0 169
return 1 0 172
assign 1 0 175
assign 1 0 179
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 119461913: return bem_tagGet_0();
case -1621443705: return bem_hasCurrentGet_0();
case -1481082583: return bem_nposGetDirect_0();
case 281444821: return bem_fieldIteratorGet_0();
case 390503721: return bem_posGet_0();
case 535013750: return bem_listGet_0();
case -678541085: return bem_classNameGet_0();
case -1644960612: return bem_nposGet_0();
case 1250656584: return bem_containerGet_0();
case -1754478112: return bem_print_0();
case -2017009146: return bem_new_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -1005119995: return bem_many_0();
case -508298247: return bem_hasNextGet_0();
case -1475550710: return bem_create_0();
case -225870373: return bem_serializeToString_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 2045941275: return bem_iteratorGet_0();
case -744679096: return bem_fieldNamesGet_0();
case -1486279572: return bem_serializeContents_0();
case -1275325619: return bem_toString_0();
case 501088997: return bem_sourceFileNameGet_0();
case -639297756: return bem_toAny_0();
case -545556484: return bem_once_0();
case 450495808: return bem_nextGet_0();
case 611702865: return bem_copy_0();
case 329323308: return bem_listGetDirect_0();
case 1242599373: return bem_posGetDirect_0();
case -737528143: return bem_currentGet_0();
case -1583672278: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1698900309: return bem_new_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -5223099: return bem_listSetDirect_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 222063505: return bem_listSet_1(bevd_0);
case 1937082313: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 126464026: return bem_nposSetDirect_1(bevd_0);
case -1255620502: return bem_nextSet_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case -1588408440: return bem_posSetDirect_1(bevd_0);
case 596627389: return bem_currentSet_1(bevd_0);
case 1340754233: return bem_posSet_1(bevd_0);
case -1336295344: return bem_nposSet_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_4_8_ContainerListIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_9_4_8_ContainerListIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_4_8_ContainerListIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst = (BEC_3_9_4_8_ContainerListIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;
}
}
}
