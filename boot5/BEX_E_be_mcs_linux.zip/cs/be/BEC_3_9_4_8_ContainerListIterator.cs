namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_3_9_4_8_ContainerListIterator : BEC_2_6_6_SystemObject {
public BEC_3_9_4_8_ContainerListIterator() { }
static BEC_3_9_4_8_ContainerListIterator() { }
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_4_8_ContainerListIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;

public static new BET_3_9_4_8_ContainerListIterator bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_9_4_ContainerList bevp_list;
public BEC_2_4_3_MathInt bevp_npos;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_list = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_npos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_new_1(BEC_2_6_6_SystemObject beva_a) {
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_list = (BEC_2_9_4_ContainerList) beva_a;
bevp_npos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_containerGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasCurrentGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 34*/ {
bevt_4_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_pos.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 34*/
 else /* Line: 34*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 34*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 35*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_currentGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return (BEC_2_5_4_LogicBool) bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_currentSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
bevp_npos.bevi_int = bevp_pos.bevi_int;
bevp_npos.bevi_int++;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
if (bevp_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_4_ta_ph = bevp_list.bem_lengthGet_0();
if (bevp_npos.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 51*/
 else /* Line: 51*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 51*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 52*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = bevp_list.bem_get_1(bevp_pos);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextSet_1(BEC_2_6_6_SystemObject beva_toSet) {
BEC_2_9_4_ContainerList bevt_0_ta_ph = null;
bevp_pos.bevi_int++;
bevt_0_ta_ph = (BEC_2_9_4_ContainerList) bevp_list.bem_put_2(bevp_pos, beva_toSet);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
bevp_pos.bevi_int += beva_multiNullCount.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGetDirect_0() {
return bevp_pos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGet_0() {
return bevp_list;
} /*method end*/
public BEC_2_9_4_ContainerList bem_listGetDirect_0() {
return bevp_list;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_listSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_listSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_list = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nposGet_0() {
return bevp_npos;
} /*method end*/
public BEC_2_4_3_MathInt bem_nposGetDirect_0() {
return bevp_npos;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_nposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_npos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_nposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_npos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 18, 19, 24, 25, 26, 30, 34, 34, 34, 34, 34, 34, 0, 0, 0, 35, 35, 37, 37, 41, 41, 45, 45, 49, 50, 51, 51, 51, 51, 51, 51, 0, 0, 0, 52, 52, 54, 54, 58, 59, 59, 63, 64, 64, 68, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 21, 22, 26, 27, 28, 32, 42, 43, 48, 49, 50, 55, 56, 59, 63, 66, 67, 69, 70, 74, 75, 79, 80, 90, 91, 92, 93, 98, 99, 100, 105, 106, 109, 113, 116, 117, 119, 120, 124, 125, 126, 130, 131, 132, 135, 139, 142, 145, 149, 153, 156, 159, 163, 167, 170, 173, 177};
/* BEGIN LINEINFO 
assign 1 17 19
new 0 17 19
assign 1 18 20
new 0 18 20
assign 1 18 21
new 1 18 21
assign 1 19 22
new 0 19 22
assign 1 24 26
new 0 24 26
assign 1 25 27
assign 1 26 28
new 0 26 28
return 1 30 32
assign 1 34 42
new 0 34 42
assign 1 34 43
greater 1 34 48
assign 1 34 49
lengthGet 0 34 49
assign 1 34 50
lesser 1 34 55
assign 1 0 56
assign 1 0 59
assign 1 0 63
assign 1 35 66
new 0 35 66
return 1 35 67
assign 1 37 69
new 0 37 69
return 1 37 70
assign 1 41 74
get 1 41 74
return 1 41 75
assign 1 45 79
put 2 45 79
return 1 45 80
setValue 1 49 90
incrementValue 0 50 91
assign 1 51 92
new 0 51 92
assign 1 51 93
greaterEquals 1 51 98
assign 1 51 99
lengthGet 0 51 99
assign 1 51 100
lesser 1 51 105
assign 1 0 106
assign 1 0 109
assign 1 0 113
assign 1 52 116
new 0 52 116
return 1 52 117
assign 1 54 119
new 0 54 119
return 1 54 120
incrementValue 0 58 124
assign 1 59 125
get 1 59 125
return 1 59 126
incrementValue 0 63 130
assign 1 64 131
put 2 64 131
return 1 64 132
addValue 1 68 135
return 1 0 139
return 1 0 142
assign 1 0 145
assign 1 0 149
return 1 0 153
return 1 0 156
assign 1 0 159
assign 1 0 163
return 1 0 167
return 1 0 170
assign 1 0 173
assign 1 0 177
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 581391667: return bem_nextGet_0();
case -1121035301: return bem_posGet_0();
case -1204412075: return bem_hasCurrentGet_0();
case -1333479481: return bem_posGetDirect_0();
case 769250352: return bem_listGet_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 1741189688: return bem_listGetDirect_0();
case -1076915155: return bem_serializeToString_0();
case 1511727176: return bem_nposGetDirect_0();
case 1834246217: return bem_classNameGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -1605246562: return bem_currentGet_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case 2081363871: return bem_copy_0();
case 1007740191: return bem_nposGet_0();
case -975498393: return bem_fieldNamesGet_0();
case -2102703130: return bem_containerGet_0();
case 954703233: return bem_create_0();
case -893093197: return bem_toString_0();
case -40905183: return bem_echo_0();
case -211510432: return bem_hasNextGet_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 177409367: return bem_otherType_1(bevd_0);
case 386533818: return bem_currentSet_1(bevd_0);
case -1166591549: return bem_posSet_1(bevd_0);
case -2062584242: return bem_nposSetDirect_1(bevd_0);
case 982499318: return bem_posSetDirect_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 1590900809: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 59504167: return bem_new_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -2035828126: return bem_listSet_1(bevd_0);
case -1449154677: return bem_nextSet_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -983967714: return bem_nposSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1543465561: return bem_listSetDirect_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_9_4_8_ContainerListIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_9_4_8_ContainerListIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_4_8_ContainerListIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst = (BEC_3_9_4_8_ContainerListIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_4_8_ContainerListIterator.bece_BEC_3_9_4_8_ContainerListIterator_bevs_type;
}
}
}
