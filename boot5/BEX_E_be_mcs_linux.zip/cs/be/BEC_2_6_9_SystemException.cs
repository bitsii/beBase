namespace be {
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_9_SystemException : BEC_2_6_6_SystemObject {
public BEC_2_6_9_SystemException() { }
static BEC_2_6_9_SystemException() { }
private static byte[] becc_BEC_2_6_9_SystemException_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_9_SystemException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_0 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x54,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x6F,0x72};
private static byte[] bece_BEC_2_6_9_SystemException_bels_1 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x3E,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_2 = {0x20,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_3 = {0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_4 = {0x20,0x4C,0x69,0x6E,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_5 = {0x20,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_6 = {0x20,0x45,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_7 = {0x20,0x4D,0x65,0x74,0x68,0x6F,0x64,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_8 = {0x20,0x43,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_9 = {0x20,0x46,0x72,0x61,0x6D,0x65,0x73,0x20,0x54,0x65,0x78,0x74,0x3A,0x20};
private static byte[] bece_BEC_2_6_9_SystemException_bels_10 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_6_9_SystemException_bels_11 = {0x0A};
public static new BEC_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_inst;

public static new BET_2_6_9_SystemException bece_BEC_2_6_9_SystemException_bevs_type;

public BEC_2_6_6_SystemObject bevp_methodName;
public BEC_2_6_6_SystemObject bevp_klassName;
public BEC_2_6_6_SystemObject bevp_description;
public BEC_2_6_6_SystemObject bevp_fileName;
public BEC_2_6_6_SystemObject bevp_lineNumber;
public BEC_2_4_6_TextString bevp_lang;
public BEC_2_4_6_TextString bevp_emitLang;
public BEC_2_9_10_ContainerLinkedList bevp_frames;
public BEC_2_4_6_TextString bevp_framesText;
public BEC_2_5_4_LogicBool bevp_translated;
public BEC_2_5_4_LogicBool bevp_vv;
public virtual BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_vv = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_description = beva_descr;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_5_4_LogicBool bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
/* Line: 54*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_1_ta_ph = bem_createInstance_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-2118708930);
bevt_0_ta_ph.bemd_1(-761076329, this);
} /* Line: 55*/
bevl_toRet = (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_1));
if (bevp_description == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 60*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_2));
bevt_4_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_5_ta_ph);
bevl_toRet = bevt_4_ta_ph.bemd_1(1007780901, bevp_description);
} /* Line: 61*/
if (bevp_fileName == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 63*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_6_9_SystemException_bels_3));
bevt_7_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_8_ta_ph);
bevl_toRet = bevt_7_ta_ph.bemd_1(1007780901, bevp_fileName);
} /* Line: 64*/
if (bevp_lineNumber == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 66*/ {
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_4));
bevt_10_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_11_ta_ph);
bevt_12_ta_ph = bevp_lineNumber.bemd_0(-893093197);
bevl_toRet = bevt_10_ta_ph.bemd_1(1007780901, bevt_12_ta_ph);
} /* Line: 67*/
if (bevp_lang == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 69*/ {
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_9_SystemException_bels_5));
bevt_14_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_15_ta_ph);
bevl_toRet = bevt_14_ta_ph.bemd_1(1007780901, bevp_lang);
} /* Line: 70*/
if (bevp_emitLang == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 72*/ {
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_6_9_SystemException_bels_6));
bevt_17_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_18_ta_ph);
bevl_toRet = bevt_17_ta_ph.bemd_1(1007780901, bevp_emitLang);
} /* Line: 73*/
if (bevp_methodName == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 75*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_6_9_SystemException_bels_7));
bevt_20_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_21_ta_ph);
bevl_toRet = bevt_20_ta_ph.bemd_1(1007780901, bevp_methodName);
} /* Line: 76*/
if (bevp_klassName == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 78*/ {
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_6_9_SystemException_bels_8));
bevt_23_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_24_ta_ph);
bevl_toRet = bevt_23_ta_ph.bemd_1(1007780901, bevp_klassName);
} /* Line: 79*/
if (bevp_framesText == null) {
bevt_25_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_25_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_25_ta_ph.bevi_bool)/* Line: 81*/ {
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_6_9_SystemException_bels_9));
bevt_26_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_27_ta_ph);
bevl_toRet = bevt_26_ta_ph.bemd_1(1007780901, bevp_framesText);
} /* Line: 82*/
if (bevp_frames == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 84*/ {
bevt_29_ta_ph = bem_getFrameText_0();
bevl_toRet = bevl_toRet.bemd_1(1007780901, bevt_29_ta_ph);
} /* Line: 85*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_framesGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
/* Line: 93*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_1_ta_ph = bem_createInstance_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-2118708930);
bevt_0_ta_ph.bemd_1(-761076329, this);
} /* Line: 94*/
if (bevp_vv.bevi_bool)/* Line: 96*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_6_9_SystemException_bels_10));
bevt_3_ta_ph.bem_print_0();
} /* Line: 97*/
return bevp_frames;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFrameText_0() {
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_9_10_ContainerLinkedList bevl_myFrames = null;
BEC_2_6_6_SystemObject bevl_ft = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
/* Line: 104*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_6_9_SystemException_bels_0));
bevt_2_ta_ph = bem_createInstance_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-2118708930);
bevt_1_ta_ph.bemd_1(-761076329, this);
} /* Line: 105*/
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_myFrames = bem_framesGet_0();
if (bevl_myFrames == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 109*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_9_SystemException_bels_11));
bevl_toRet = bevl_toRet.bem_add_1(bevt_5_ta_ph);
bevt_0_ta_loop = bevl_myFrames.bem_linkedListIteratorGet_0();
while (true)
/* Line: 111*/ {
bevt_6_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 111*/ {
bevl_ft = bevt_0_ta_loop.bem_nextGet_0();
bevl_toRet = bevl_toRet.bem_add_1(bevl_ft);
} /* Line: 112*/
 else /* Line: 111*/ {
break;
} /* Line: 111*/
} /* Line: 111*/
} /* Line: 111*/
return bevl_toRet;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_klassNameGet_0() {
return (BEC_2_4_6_TextString) bevp_klassName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_addFrame_1(BEC_2_9_5_ExceptionFrame beva_frame) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_frames == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 123*/ {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 124*/
bevp_frames.bem_addValue_1(beva_frame);
return this;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_addFrame_4(BEC_2_4_6_TextString beva__klassName, BEC_2_4_6_TextString beva__methodName, BEC_2_4_6_TextString beva__fileName, BEC_2_4_3_MathInt beva__line) {
BEC_2_9_5_ExceptionFrame bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_9_5_ExceptionFrame) (new BEC_2_9_5_ExceptionFrame()).bem_new_4(beva__klassName, beva__methodName, beva__fileName, beva__line);
bem_addFrame_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_methodNameGet_0() {
return bevp_methodName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_methodNameGetDirect_0() {
return bevp_methodName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_methodNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methodName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_methodNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methodName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_klassNameGetDirect_0() {
return bevp_klassName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_klassNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_klassName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_klassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_klassName = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_descriptionGet_0() {
return bevp_description;
} /*method end*/
public BEC_2_6_6_SystemObject bem_descriptionGetDirect_0() {
return bevp_description;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_descriptionSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_description = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_descriptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_description = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_fileNameGet_0() {
return bevp_fileName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fileNameGetDirect_0() {
return bevp_fileName;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_fileNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fileName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_fileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fileName = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lineNumberGet_0() {
return bevp_lineNumber;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lineNumberGetDirect_0() {
return bevp_lineNumber;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_lineNumberSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lineNumber = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_lineNumberSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lineNumber = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_langGet_0() {
return bevp_lang;
} /*method end*/
public BEC_2_4_6_TextString bem_langGetDirect_0() {
return bevp_lang;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_langSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_langSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_emitLangGet_0() {
return bevp_emitLang;
} /*method end*/
public BEC_2_4_6_TextString bem_emitLangGetDirect_0() {
return bevp_emitLang;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_emitLangSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_emitLangSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLang = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_framesGetDirect_0() {
return bevp_frames;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_framesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_frames = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_framesTextGet_0() {
return bevp_framesText;
} /*method end*/
public BEC_2_4_6_TextString bem_framesTextGetDirect_0() {
return bevp_framesText;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_framesTextSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_framesTextSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_framesText = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_translatedGet_0() {
return bevp_translated;
} /*method end*/
public BEC_2_5_4_LogicBool bem_translatedGetDirect_0() {
return bevp_translated;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_translatedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_translatedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_translated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_vvGet_0() {
return bevp_vv;
} /*method end*/
public BEC_2_5_4_LogicBool bem_vvGetDirect_0() {
return bevp_vv;
} /*method end*/
public virtual BEC_2_6_9_SystemException bem_vvSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_9_SystemException bem_vvSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vv = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {47, 50, 55, 55, 55, 55, 59, 60, 60, 61, 61, 61, 63, 63, 64, 64, 64, 66, 66, 67, 67, 67, 67, 69, 69, 70, 70, 70, 72, 72, 73, 73, 73, 75, 75, 76, 76, 76, 78, 78, 79, 79, 79, 81, 81, 82, 82, 82, 84, 84, 85, 85, 87, 94, 94, 94, 94, 97, 97, 100, 105, 105, 105, 105, 107, 108, 109, 109, 110, 110, 111, 0, 111, 111, 112, 115, 119, 123, 123, 124, 126, 130, 130, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {36, 37, 73, 74, 75, 76, 78, 79, 84, 85, 86, 87, 89, 94, 95, 96, 97, 99, 104, 105, 106, 107, 108, 110, 115, 116, 117, 118, 120, 125, 126, 127, 128, 130, 135, 136, 137, 138, 140, 145, 146, 147, 148, 150, 155, 156, 157, 158, 160, 165, 166, 167, 169, 177, 178, 179, 180, 183, 184, 186, 200, 201, 202, 203, 205, 206, 207, 212, 213, 214, 215, 215, 218, 220, 221, 228, 231, 235, 240, 241, 243, 248, 249, 253, 256, 259, 263, 267, 270, 274, 278, 281, 284, 288, 292, 295, 298, 302, 306, 309, 312, 316, 320, 323, 326, 330, 334, 337, 340, 344, 348, 351, 355, 359, 362, 365, 369, 373, 376, 379, 383, 387, 390, 393, 397};
/* BEGIN LINEINFO 
assign 1 47 36
new 0 47 36
assign 1 50 37
assign 1 55 73
new 0 55 73
assign 1 55 74
createInstance 1 55 74
assign 1 55 75
new 0 55 75
translateEmittedException 1 55 76
assign 1 59 78
new 0 59 78
assign 1 60 79
def 1 60 84
assign 1 61 85
new 0 61 85
assign 1 61 86
add 1 61 86
assign 1 61 87
add 1 61 87
assign 1 63 89
def 1 63 94
assign 1 64 95
new 0 64 95
assign 1 64 96
add 1 64 96
assign 1 64 97
add 1 64 97
assign 1 66 99
def 1 66 104
assign 1 67 105
new 0 67 105
assign 1 67 106
add 1 67 106
assign 1 67 107
toString 0 67 107
assign 1 67 108
add 1 67 108
assign 1 69 110
def 1 69 115
assign 1 70 116
new 0 70 116
assign 1 70 117
add 1 70 117
assign 1 70 118
add 1 70 118
assign 1 72 120
def 1 72 125
assign 1 73 126
new 0 73 126
assign 1 73 127
add 1 73 127
assign 1 73 128
add 1 73 128
assign 1 75 130
def 1 75 135
assign 1 76 136
new 0 76 136
assign 1 76 137
add 1 76 137
assign 1 76 138
add 1 76 138
assign 1 78 140
def 1 78 145
assign 1 79 146
new 0 79 146
assign 1 79 147
add 1 79 147
assign 1 79 148
add 1 79 148
assign 1 81 150
def 1 81 155
assign 1 82 156
new 0 82 156
assign 1 82 157
add 1 82 157
assign 1 82 158
add 1 82 158
assign 1 84 160
def 1 84 165
assign 1 85 166
getFrameText 0 85 166
assign 1 85 167
add 1 85 167
return 1 87 169
assign 1 94 177
new 0 94 177
assign 1 94 178
createInstance 1 94 178
assign 1 94 179
new 0 94 179
translateEmittedException 1 94 180
assign 1 97 183
new 0 97 183
print 0 97 184
return 1 100 186
assign 1 105 200
new 0 105 200
assign 1 105 201
createInstance 1 105 201
assign 1 105 202
new 0 105 202
translateEmittedException 1 105 203
assign 1 107 205
new 0 107 205
assign 1 108 206
framesGet 0 108 206
assign 1 109 207
def 1 109 212
assign 1 110 213
new 0 110 213
assign 1 110 214
add 1 110 214
assign 1 111 215
linkedListIteratorGet 0 0 215
assign 1 111 218
hasNextGet 0 111 218
assign 1 111 220
nextGet 0 111 220
assign 1 112 221
add 1 112 221
return 1 115 228
return 1 119 231
assign 1 123 235
undef 1 123 240
assign 1 124 241
new 0 124 241
addValue 1 126 243
assign 1 130 248
new 4 130 248
addFrame 1 130 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
return 1 0 267
assign 1 0 270
assign 1 0 274
return 1 0 278
return 1 0 281
assign 1 0 284
assign 1 0 288
return 1 0 292
return 1 0 295
assign 1 0 298
assign 1 0 302
return 1 0 306
return 1 0 309
assign 1 0 312
assign 1 0 316
return 1 0 320
return 1 0 323
assign 1 0 326
assign 1 0 330
return 1 0 334
return 1 0 337
assign 1 0 340
assign 1 0 344
return 1 0 348
assign 1 0 351
assign 1 0 355
return 1 0 359
return 1 0 362
assign 1 0 365
assign 1 0 369
return 1 0 373
return 1 0 376
assign 1 0 379
assign 1 0 383
return 1 0 387
return 1 0 390
assign 1 0 393
assign 1 0 397
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1153344161: return bem_serializeContents_0();
case -497415093: return bem_translatedGetDirect_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1422694389: return bem_translatedGet_0();
case 1955283253: return bem_klassNameGet_0();
case -1783934981: return bem_framesTextGetDirect_0();
case -432957830: return bem_descriptionGetDirect_0();
case 421177749: return bem_print_0();
case -269512511: return bem_methodNameGetDirect_0();
case -1122166678: return bem_fileNameGet_0();
case -1485320759: return bem_getFrameText_0();
case 41316592: return bem_emitLangGetDirect_0();
case -1721041178: return bem_descriptionGet_0();
case 1173965200: return bem_vvGetDirect_0();
case -893093197: return bem_toString_0();
case -1076915155: return bem_serializeToString_0();
case 946360922: return bem_serializationIteratorGet_0();
case -1674595379: return bem_framesGet_0();
case 157315275: return bem_lineNumberGet_0();
case 1906790658: return bem_methodNameGet_0();
case -2118708930: return bem_new_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case -192526043: return bem_framesGetDirect_0();
case -1653939165: return bem_iteratorGet_0();
case -193582610: return bem_tagGet_0();
case 1422094797: return bem_emitLangGet_0();
case 1971771638: return bem_klassNameGetDirect_0();
case 2035686675: return bem_framesTextGet_0();
case 1822506121: return bem_langGetDirect_0();
case -40905183: return bem_echo_0();
case -902106455: return bem_langGet_0();
case 1974505938: return bem_hashGet_0();
case 1818692006: return bem_vvGet_0();
case 2081363871: return bem_copy_0();
case 985380887: return bem_fileNameGetDirect_0();
case 1931705863: return bem_sourceFileNameGet_0();
case 1834246217: return bem_classNameGet_0();
case -975498393: return bem_fieldNamesGet_0();
case 954703233: return bem_create_0();
case 387862563: return bem_lineNumberGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2033932833: return bem_langSet_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 1646084805: return bem_klassNameSetDirect_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 1656945082: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 59504167: return bem_new_1(bevd_0);
case 307222774: return bem_emitLangSet_1(bevd_0);
case -798089535: return bem_methodNameSetDirect_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1222964272: return bem_fileNameSetDirect_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 385476643: return bem_vvSetDirect_1(bevd_0);
case 1611094427: return bem_translatedSetDirect_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 296811218: return bem_klassNameSet_1(bevd_0);
case -175977764: return bem_framesTextSetDirect_1(bevd_0);
case -1757788580: return bem_translatedSet_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -714430839: return bem_vvSet_1(bevd_0);
case 991266054: return bem_fileNameSet_1(bevd_0);
case -1992412421: return bem_emitLangSetDirect_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 1939410115: return bem_lineNumberSetDirect_1(bevd_0);
case 357834044: return bem_framesSetDirect_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 1548211566: return bem_descriptionSetDirect_1(bevd_0);
case 1057844660: return bem_methodNameSet_1(bevd_0);
case 1337147400: return bem_framesSet_1(bevd_0);
case 1879717288: return bem_lineNumberSet_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -412425505: return bem_descriptionSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -1639560974: return bem_langSetDirect_1(bevd_0);
case 354208521: return bem_framesTextSet_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 482756533: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_6_9_SystemException_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_9_SystemException_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_9_SystemException();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst = (BEC_2_6_9_SystemException) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_9_SystemException.bece_BEC_2_6_9_SystemException_bevs_type;
}
}
}
