namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_11_ContainerSetKeyIterator : BEC_3_9_3_12_ContainerSetNodeIterator {
public BEC_3_9_3_11_ContainerSetKeyIterator() { }
static BEC_3_9_3_11_ContainerSetKeyIterator() { }
private static byte[] becc_BEC_3_9_3_11_ContainerSetKeyIterator_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x65,0x74,0x3A,0x4B,0x65,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_9_3_11_ContainerSetKeyIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_11_ContainerSetKeyIterator bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst;

public static new BET_3_9_3_11_ContainerSetKeyIterator bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_type;

public override BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_6_6_SystemObject bevl_tr = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevl_tr = base.bem_nextGet_0();
if (bevl_tr == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 531*/ {
bevt_1_ta_ph = bevl_tr.bemd_0(-317365949);
return bevt_1_ta_ph;
} /* Line: 532*/
return bevl_tr;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {530, 531, 531, 532, 532, 534};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 22, 23, 24, 26};
/* BEGIN LINEINFO 
assign 1 530 16
nextGet 0 530 16
assign 1 531 17
def 1 531 22
assign 1 532 23
keyGet 0 532 23
return 1 532 24
return 1 534 26
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1975680234: return bem_hasNextGet_0();
case -356617806: return bem_currentGet_0();
case 2080713205: return bem_containerGet_0();
case 1761603047: return bem_setGetDirect_0();
case -1363819567: return bem_new_0();
case -1194607387: return bem_nodeIteratorIteratorGet_0();
case -467511392: return bem_toString_0();
case -793241295: return bem_iteratorGet_0();
case 1890854002: return bem_tagGet_0();
case -447432319: return bem_many_0();
case -105946774: return bem_serializeToString_0();
case 1050845344: return bem_slotsGetDirect_0();
case 1739898218: return bem_moduGetDirect_0();
case -1760538533: return bem_classNameGet_0();
case -1323898541: return bem_toAny_0();
case -1188922735: return bem_echo_0();
case 1092105192: return bem_hashGet_0();
case 1652521523: return bem_serializeContents_0();
case 1319388306: return bem_copy_0();
case 697836510: return bem_delete_0();
case -725384548: return bem_moduGet_0();
case -921473949: return bem_fieldNamesGet_0();
case 1676979681: return bem_setGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -1094288749: return bem_currentGetDirect_0();
case 1597327951: return bem_create_0();
case 7254011: return bem_fieldIteratorGet_0();
case 895193825: return bem_once_0();
case -1387831588: return bem_print_0();
case 264727971: return bem_slotsGet_0();
case 371157924: return bem_sourceFileNameGet_0();
case -39165288: return bem_deserializeClassNameGet_0();
case 409355098: return bem_nextGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1488511778: return bem_otherType_1(bevd_0);
case -317649604: return bem_moduSetDirect_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -279954183: return bem_setSetDirect_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1929898803: return bem_new_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -104906255: return bem_currentSet_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case 403796802: return bem_setSet_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 476897882: return bem_slotsSet_1(bevd_0);
case -1988368117: return bem_slotsSetDirect_1(bevd_0);
case 759979266: return bem_currentSetDirect_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case 298058979: return bem_moduSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_9_3_11_ContainerSetKeyIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_11_ContainerSetKeyIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_11_ContainerSetKeyIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst = (BEC_3_9_3_11_ContainerSetKeyIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_11_ContainerSetKeyIterator.bece_BEC_3_9_3_11_ContainerSetKeyIterator_bevs_type;
}
}
}
