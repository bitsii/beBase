namespace be {
/* IO:File: source/build/SWEmitter.be */
public sealed class BEC_2_5_9_BuildSWEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildSWEmitter() { }
static BEC_2_5_9_BuildSWEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildSWEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x53,0x57,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildSWEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x57,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_0 = {0x73,0x77};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_1 = {0x2E,0x73,0x77,0x69,0x66,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_3 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_4 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_5 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_6 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_8 = {0x2F,0x2A,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_9 = {0x20,0x2A,0x2F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_10 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_11 = {0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_12 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_12, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_13 = {0x5F,0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_13, 6));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_14 = {};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_15 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_16 = {0x3A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_17 = {0x3F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_18 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_18, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_19 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_19, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_20 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_21 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_22 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_22, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_23 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_24 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_24, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_25 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_25, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_26 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_26, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_27 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_28 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_29 = {0x3A,0x5B,0x55,0x49,0x6E,0x74,0x38,0x5D,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_30, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_31 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_31, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_32 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_32, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_33 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_34 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_35 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_36 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_37 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_38 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_39 = {0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_40 = {0x20,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_41 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_42 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_43 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_44 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_45 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_46 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_47 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_48 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_49 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_50 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_51 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_52 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_53 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_54 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_55 = {0x20,0x2D,0x3E,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_56 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_57 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_58 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_59 = {0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_60 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_61 = {0x20,0x2D,0x3E,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_62 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_63 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_64 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_65 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_66 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_66, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_67 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_67, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_68 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_68, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_69 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_70 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_70, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_71 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_72 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_73 = {0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_73, 28));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_74 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_74, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_75 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_76 = {0x66,0x75,0x6E,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_77 = {0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x75,0x6E,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_78 = {};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_79 = {0x20,0x61,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_79, 4));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_80 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_81 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_82 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_83 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_84 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_85 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_85, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_86 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_86, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_87 = {0x3F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_87, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_88 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_88, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_89 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_89, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_90 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_90, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_91 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_91, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_92 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_92, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_93 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_93, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_94 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_94, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_95 = {0x6D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_95, 19));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_96 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_96, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_97 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_98 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_99 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_100 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_101 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_102 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_102, 3));
public static new BEC_2_5_9_BuildSWEmitter bece_BEC_2_5_9_BuildSWEmitter_bevs_inst;

public static new BET_2_5_9_BuildSWEmitter bece_BEC_2_5_9_BuildSWEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildSWEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildSWEmitter_bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildSWEmitter_bels_4));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_5));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildSWEmitter_bels_6));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_clb = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 36 */
 else  /* Line: 37 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildSWEmitter_bels_7));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 38 */
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildSWEmitter_bels_8));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_inFilePathed);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_9));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevl_clb = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = beva_csyn.bem_isFinalGet_0();
bevt_12_tmpany_phold = bem_klassDec_1(bevt_13_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_10));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildSWEmitter_bels_11));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_17_tmpany_phold);
bevt_16_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_clb;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_0;
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildSWEmitter_bels_14));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
if (!(beva_isArg.bevi_bool)) /* Line: 55 */ {
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_15));
beva_b.bem_addValue_1(bevt_0_tmpany_phold);
} /* Line: 56 */
bevt_1_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_16));
beva_b.bem_addValue_1(bevt_2_tmpany_phold);
bem_typeDecForVar_2(beva_b, beva_v);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_17));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bevp_csyn.bem_namepathGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_equals_1(bevp_objectNp);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 68 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_2;
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_3;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_4_tmpany_phold = bem_baseSpropDec_2(bevt_5_tmpany_phold, bevt_6_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_4_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_20));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 69 */
 else  /* Line: 70 */ {
bevt_15_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_4;
bevt_19_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_5;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_14_tmpany_phold = bem_overrideSpropDec_2(bevt_15_tmpany_phold, bevt_16_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_14_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_23));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 71 */
return bevl_initialDec;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_6;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_7;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_newcc.bem_emitNameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_8;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildSWEmitter_bels_27));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_28));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildSWEmitter_bels_29));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_9;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_anyName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_10;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
bevt_6_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildSWEmitter_bels_33));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_34));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_11_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_relEmitName_1(bevt_11_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_35));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_36));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_16_tmpany_phold);
bevt_20_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-1745874944);
bevt_18_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_19_tmpany_phold );
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_37));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_38));
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_24_tmpany_phold);
bevt_23_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_4_6_TextString bevl_tname = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_vcast = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_0_tmpany_phold.bem_relEmitName_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevl_tname = bevt_2_tmpany_phold.bem_typeEmitNameGet_0();
bevl_mname = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-1745874944);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_11_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(27, bece_BEC_2_5_9_BuildSWEmitter_bels_39));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_40));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_41));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = bevl_mname.bem_notEquals_1(bevl_oname);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 109 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_42));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_43));
bevl_vcast = bem_formCast_3(bevp_classConf, bevt_16_tmpany_phold, bevt_17_tmpany_phold);
} /* Line: 110 */
 else  /* Line: 111 */ {
bevl_vcast = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_44));
} /* Line: 112 */
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_45));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevt_21_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_addValue_1(bevl_vcast);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_46));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevt_23_tmpany_phold);
bevt_18_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_47));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_25_tmpany_phold);
bevt_24_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_32_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildSWEmitter_bels_48));
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) bevt_31_tmpany_phold.bem_addValue_1(bevt_33_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) bevt_30_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_49));
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) bevt_29_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevt_28_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_50));
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_51));
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_39_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevt_38_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_52));
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevt_37_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_36_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_53));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_42_tmpany_phold);
bevt_41_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_47_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_47_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildSWEmitter_bels_54));
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) bevt_46_tmpany_phold.bem_addValue_1(bevt_48_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) bevt_45_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildSWEmitter_bels_55));
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) bevt_44_tmpany_phold.bem_addValue_1(bevt_49_tmpany_phold);
bevt_43_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_56));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_53_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_57));
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_58));
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_56_tmpany_phold);
bevt_55_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_6_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_59));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_60));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildSWEmitter_bels_61));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildSWEmitter_bels_62));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(beva_len);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_63));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_64));
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_10_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_65));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_18_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_12;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_anyName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_13;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_14;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_69));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_71));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_72));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-192101120);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1186376513);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_75));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_76));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildSWEmitter_bels_77));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_newDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildSWEmitter_bels_78));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_18;
bevt_3_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_2_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_3(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type, BEC_2_4_6_TextString beva_targ) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCast_2(beva_cc, beva_type);
bevt_0_tmpany_phold = beva_targ.bem_add_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_80));
bevt_0_tmpany_phold.bem_addValue_1(bevt_2_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_81));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_82));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_10_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_11_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_83));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_84));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_19;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_anyName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_21;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 209 */ {
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 210 */
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_25;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_lisz);
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_26;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(beva_belsName);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_27;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
return bevt_10_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_28;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_29;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_30;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildSWEmitter_bels_97));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_98));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_99));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildSWEmitter_bels_100));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-678621170);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_101));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_31;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 24, 26, 27, 31, 31, 31, 31, 31, 31, 31, 31, 35, 35, 36, 36, 36, 38, 38, 40, 40, 40, 40, 40, 41, 41, 41, 41, 41, 41, 41, 41, 41, 42, 42, 42, 43, 47, 47, 47, 47, 47, 47, 47, 51, 51, 56, 56, 58, 58, 59, 59, 60, 61, 61, 66, 68, 68, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 71, 74, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 82, 82, 86, 86, 86, 86, 86, 90, 90, 90, 90, 90, 90, 90, 90, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 94, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 97, 97, 97, 101, 101, 101, 102, 102, 103, 104, 104, 104, 105, 107, 107, 107, 107, 107, 107, 107, 107, 107, 107, 107, 109, 110, 110, 110, 112, 115, 115, 115, 115, 115, 115, 115, 117, 117, 117, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 122, 122, 122, 122, 122, 122, 124, 124, 124, 126, 128, 128, 128, 128, 128, 128, 128, 128, 130, 130, 130, 130, 130, 130, 132, 132, 132, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 142, 143, 143, 143, 143, 143, 143, 143, 143, 143, 145, 145, 145, 149, 149, 149, 149, 149, 149, 149, 149, 154, 154, 154, 158, 158, 158, 159, 160, 160, 160, 160, 160, 160, 162, 162, 162, 162, 162, 162, 162, 162, 162, 162, 167, 167, 171, 171, 175, 175, 179, 179, 183, 183, 183, 183, 183, 187, 187, 187, 192, 192, 192, 192, 194, 196, 196, 196, 196, 196, 196, 196, 196, 196, 196, 196, 201, 201, 205, 205, 205, 205, 205, 205, 205, 205, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 210, 212, 212, 212, 212, 212, 212, 212, 212, 212, 212, 212, 217, 218, 219, 219, 219, 220, 225, 225, 225, 225, 225, 226, 226, 226, 226, 226, 226, 227, 227, 227, 228, 228, 228, 228, 228, 228, 228, 228, 229, 233, 233, 233, 233};
public static new int[] bevs_smnlec
 = new int[] {148, 149, 150, 151, 152, 153, 164, 165, 166, 167, 168, 169, 170, 171, 195, 200, 201, 202, 203, 206, 207, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 235, 236, 237, 238, 239, 240, 241, 245, 246, 254, 255, 257, 258, 259, 260, 261, 262, 263, 290, 291, 292, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 319, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 346, 347, 354, 355, 356, 357, 358, 369, 370, 371, 372, 373, 374, 375, 376, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 522, 523, 524, 527, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 633, 634, 635, 636, 637, 638, 639, 640, 645, 646, 647, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 692, 693, 697, 698, 702, 703, 707, 708, 715, 716, 717, 718, 719, 724, 725, 726, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 762, 763, 773, 774, 775, 776, 777, 778, 779, 780, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 832, 833, 834, 835, 836, 837, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 888, 889, 890, 891};
/* BEGIN LINEINFO 
assign 1 18 148
new 0 18 148
assign 1 19 149
new 0 19 149
assign 1 20 150
new 0 20 150
new 1 24 151
assign 1 26 152
new 0 26 152
assign 1 27 153
new 0 27 153
assign 1 31 164
new 0 31 164
assign 1 31 165
addValue 1 31 165
assign 1 31 166
secondGet 0 31 166
assign 1 31 167
formTarg 1 31 167
assign 1 31 168
addValue 1 31 168
assign 1 31 169
new 0 31 169
assign 1 31 170
addValue 1 31 170
addValue 1 31 171
assign 1 35 195
def 1 35 200
assign 1 36 201
libNameGet 0 36 201
assign 1 36 202
relEmitName 1 36 202
assign 1 36 203
extend 1 36 203
assign 1 38 206
new 0 38 206
assign 1 38 207
extend 1 38 207
assign 1 40 209
new 0 40 209
assign 1 40 210
addValue 1 40 210
assign 1 40 211
new 0 40 211
assign 1 40 212
addValue 1 40 212
assign 1 40 213
addValue 1 40 213
assign 1 41 214
isFinalGet 0 41 214
assign 1 41 215
klassDec 1 41 215
assign 1 41 216
addValue 1 41 216
assign 1 41 217
emitNameGet 0 41 217
assign 1 41 218
addValue 1 41 218
assign 1 41 219
addValue 1 41 219
assign 1 41 220
new 0 41 220
assign 1 41 221
addValue 1 41 221
addValue 1 41 222
assign 1 42 223
new 0 42 223
assign 1 42 224
addValue 1 42 224
addValue 1 42 225
return 1 43 226
assign 1 47 235
new 0 47 235
assign 1 47 236
emitNameGet 0 47 236
assign 1 47 237
add 1 47 237
assign 1 47 238
new 0 47 238
assign 1 47 239
add 1 47 239
assign 1 47 240
add 1 47 240
return 1 47 241
assign 1 51 245
new 0 51 245
return 1 51 246
assign 1 56 254
new 0 56 254
addValue 1 56 255
assign 1 58 257
nameForVar 1 58 257
addValue 1 58 258
assign 1 59 259
new 0 59 259
addValue 1 59 260
typeDecForVar 2 60 261
assign 1 61 262
new 0 61 262
addValue 1 61 263
assign 1 66 290
new 0 66 290
assign 1 68 291
namepathGet 0 68 291
assign 1 68 292
equals 1 68 292
assign 1 69 294
emitNameGet 0 69 294
assign 1 69 295
new 0 69 295
assign 1 69 296
emitNameGet 0 69 296
assign 1 69 297
add 1 69 297
assign 1 69 298
new 0 69 298
assign 1 69 299
add 1 69 299
assign 1 69 300
baseSpropDec 2 69 300
assign 1 69 301
addValue 1 69 301
assign 1 69 302
new 0 69 302
assign 1 69 303
addValue 1 69 303
addValue 1 69 304
assign 1 71 307
emitNameGet 0 71 307
assign 1 71 308
new 0 71 308
assign 1 71 309
emitNameGet 0 71 309
assign 1 71 310
add 1 71 310
assign 1 71 311
new 0 71 311
assign 1 71 312
add 1 71 312
assign 1 71 313
overrideSpropDec 2 71 313
assign 1 71 314
addValue 1 71 314
assign 1 71 315
new 0 71 315
assign 1 71 316
addValue 1 71 316
addValue 1 71 317
return 1 74 319
assign 1 78 332
libNameGet 0 78 332
assign 1 78 333
relEmitName 1 78 333
assign 1 78 334
new 0 78 334
assign 1 78 335
add 1 78 335
assign 1 78 336
new 0 78 336
assign 1 78 337
add 1 78 337
assign 1 78 338
emitNameGet 0 78 338
assign 1 78 339
add 1 78 339
assign 1 78 340
new 0 78 340
assign 1 78 341
add 1 78 341
return 1 78 342
assign 1 82 346
new 0 82 346
return 1 82 347
assign 1 86 354
new 0 86 354
assign 1 86 355
addValue 1 86 355
assign 1 86 356
addValue 1 86 356
assign 1 86 357
new 0 86 357
addValue 1 86 358
assign 1 90 369
new 0 90 369
assign 1 90 370
add 1 90 370
assign 1 90 371
new 0 90 371
assign 1 90 372
add 1 90 372
assign 1 90 373
add 1 90 373
assign 1 90 374
new 0 90 374
assign 1 90 375
add 1 90 375
return 1 90 376
assign 1 94 404
overrideMtdDecGet 0 94 404
assign 1 94 405
addValue 1 94 405
assign 1 94 406
new 0 94 406
assign 1 94 407
addValue 1 94 407
assign 1 94 408
addValue 1 94 408
assign 1 94 409
new 0 94 409
assign 1 94 410
addValue 1 94 410
assign 1 94 411
getClassConfig 1 94 411
assign 1 94 412
libNameGet 0 94 412
assign 1 94 413
relEmitName 1 94 413
assign 1 94 414
addValue 1 94 414
assign 1 94 415
new 0 94 415
assign 1 94 416
addValue 1 94 416
addValue 1 94 417
assign 1 95 418
new 0 95 418
assign 1 95 419
addValue 1 95 419
assign 1 95 420
heldGet 0 95 420
assign 1 95 421
namepathGet 0 95 421
assign 1 95 422
getClassConfig 1 95 422
assign 1 95 423
libNameGet 0 95 423
assign 1 95 424
relEmitName 1 95 424
assign 1 95 425
addValue 1 95 425
assign 1 95 426
new 0 95 426
assign 1 95 427
addValue 1 95 427
addValue 1 95 428
assign 1 97 429
new 0 97 429
assign 1 97 430
addValue 1 97 430
addValue 1 97 431
assign 1 101 499
getClassConfig 1 101 499
assign 1 101 500
libNameGet 0 101 500
assign 1 101 501
relEmitName 1 101 501
assign 1 102 502
getClassConfig 1 102 502
assign 1 102 503
typeEmitNameGet 0 102 503
assign 1 103 504
emitNameGet 0 103 504
assign 1 104 505
heldGet 0 104 505
assign 1 104 506
namepathGet 0 104 506
assign 1 104 507
getClassConfig 1 104 507
assign 1 105 508
getInitialInst 1 105 508
assign 1 107 509
overrideMtdDecGet 0 107 509
assign 1 107 510
addValue 1 107 510
assign 1 107 511
new 0 107 511
assign 1 107 512
addValue 1 107 512
assign 1 107 513
addValue 1 107 513
assign 1 107 514
new 0 107 514
assign 1 107 515
addValue 1 107 515
assign 1 107 516
addValue 1 107 516
assign 1 107 517
new 0 107 517
assign 1 107 518
addValue 1 107 518
addValue 1 107 519
assign 1 109 520
notEquals 1 109 520
assign 1 110 522
new 0 110 522
assign 1 110 523
new 0 110 523
assign 1 110 524
formCast 3 110 524
assign 1 112 527
new 0 112 527
assign 1 115 529
addValue 1 115 529
assign 1 115 530
new 0 115 530
assign 1 115 531
addValue 1 115 531
assign 1 115 532
addValue 1 115 532
assign 1 115 533
new 0 115 533
assign 1 115 534
addValue 1 115 534
addValue 1 115 535
assign 1 117 536
new 0 117 536
assign 1 117 537
addValue 1 117 537
addValue 1 117 538
assign 1 120 539
overrideMtdDecGet 0 120 539
assign 1 120 540
addValue 1 120 540
assign 1 120 541
new 0 120 541
assign 1 120 542
addValue 1 120 542
assign 1 120 543
addValue 1 120 543
assign 1 120 544
new 0 120 544
assign 1 120 545
addValue 1 120 545
assign 1 120 546
addValue 1 120 546
assign 1 120 547
new 0 120 547
assign 1 120 548
addValue 1 120 548
addValue 1 120 549
assign 1 122 550
new 0 122 550
assign 1 122 551
addValue 1 122 551
assign 1 122 552
addValue 1 122 552
assign 1 122 553
new 0 122 553
assign 1 122 554
addValue 1 122 554
addValue 1 122 555
assign 1 124 556
new 0 124 556
assign 1 124 557
addValue 1 124 557
addValue 1 124 558
assign 1 126 559
getTypeInst 1 126 559
assign 1 128 560
overrideMtdDecGet 0 128 560
assign 1 128 561
addValue 1 128 561
assign 1 128 562
new 0 128 562
assign 1 128 563
addValue 1 128 563
assign 1 128 564
addValue 1 128 564
assign 1 128 565
new 0 128 565
assign 1 128 566
addValue 1 128 566
addValue 1 128 567
assign 1 130 568
new 0 130 568
assign 1 130 569
addValue 1 130 569
assign 1 130 570
addValue 1 130 570
assign 1 130 571
new 0 130 571
assign 1 130 572
addValue 1 130 572
addValue 1 130 573
assign 1 132 574
new 0 132 574
assign 1 132 575
addValue 1 132 575
addValue 1 132 576
assign 1 142 600
overrideMtdDecGet 0 142 600
assign 1 142 601
addValue 1 142 601
assign 1 142 602
new 0 142 602
assign 1 142 603
addValue 1 142 603
assign 1 142 604
addValue 1 142 604
assign 1 142 605
new 0 142 605
assign 1 142 606
addValue 1 142 606
assign 1 142 607
addValue 1 142 607
assign 1 142 608
new 0 142 608
assign 1 142 609
addValue 1 142 609
addValue 1 142 610
assign 1 143 611
new 0 143 611
assign 1 143 612
addValue 1 143 612
assign 1 143 613
addValue 1 143 613
assign 1 143 614
new 0 143 614
assign 1 143 615
addValue 1 143 615
assign 1 143 616
addValue 1 143 616
assign 1 143 617
new 0 143 617
assign 1 143 618
addValue 1 143 618
addValue 1 143 619
assign 1 145 620
new 0 145 620
assign 1 145 621
addValue 1 145 621
addValue 1 145 622
assign 1 149 633
new 0 149 633
assign 1 149 634
add 1 149 634
assign 1 149 635
new 0 149 635
assign 1 149 636
add 1 149 636
assign 1 149 637
add 1 149 637
assign 1 149 638
new 0 149 638
assign 1 149 639
add 1 149 639
return 1 149 640
assign 1 154 645
new 0 154 645
assign 1 154 646
addValue 1 154 646
addValue 1 154 647
assign 1 158 668
new 0 158 668
assign 1 158 669
toString 0 158 669
assign 1 158 670
add 1 158 670
incrementValue 0 159 671
assign 1 160 672
new 0 160 672
assign 1 160 673
addValue 1 160 673
assign 1 160 674
addValue 1 160 674
assign 1 160 675
new 0 160 675
assign 1 160 676
addValue 1 160 676
addValue 1 160 677
assign 1 162 678
containedGet 0 162 678
assign 1 162 679
firstGet 0 162 679
assign 1 162 680
containedGet 0 162 680
assign 1 162 681
firstGet 0 162 681
assign 1 162 682
new 0 162 682
assign 1 162 683
add 1 162 683
assign 1 162 684
new 0 162 684
assign 1 162 685
add 1 162 685
assign 1 162 686
finalAssign 4 162 686
addValue 1 162 687
assign 1 167 692
new 0 167 692
return 1 167 693
assign 1 171 697
new 0 171 697
return 1 171 698
assign 1 175 702
new 0 175 702
return 1 175 703
assign 1 179 707
new 0 179 707
return 1 179 708
assign 1 183 715
new 0 183 715
assign 1 183 716
libNameGet 0 183 716
assign 1 183 717
relEmitName 1 183 717
assign 1 183 718
add 1 183 718
return 1 183 719
assign 1 187 724
formCast 2 187 724
assign 1 187 725
add 1 187 725
return 1 187 726
assign 1 192 742
addValue 1 192 742
assign 1 192 743
addValue 1 192 743
assign 1 192 744
new 0 192 744
addValue 1 192 745
addValue 1 194 746
assign 1 196 747
new 0 196 747
assign 1 196 748
addValue 1 196 748
assign 1 196 749
addValue 1 196 749
assign 1 196 750
new 0 196 750
assign 1 196 751
addValue 1 196 751
assign 1 196 752
libNameGet 0 196 752
assign 1 196 753
relEmitName 1 196 753
assign 1 196 754
addValue 1 196 754
assign 1 196 755
new 0 196 755
assign 1 196 756
addValue 1 196 756
addValue 1 196 757
assign 1 201 762
new 0 201 762
return 1 201 763
assign 1 205 773
new 0 205 773
assign 1 205 774
add 1 205 774
assign 1 205 775
new 0 205 775
assign 1 205 776
add 1 205 776
assign 1 205 777
add 1 205 777
assign 1 205 778
new 0 205 778
assign 1 205 779
add 1 205 779
return 1 205 780
assign 1 210 804
libNameGet 0 210 804
assign 1 210 805
relEmitName 1 210 805
assign 1 210 806
new 0 210 806
assign 1 210 807
add 1 210 807
assign 1 210 808
add 1 210 808
assign 1 210 809
new 0 210 809
assign 1 210 810
add 1 210 810
assign 1 210 811
add 1 210 811
assign 1 210 812
new 0 210 812
assign 1 210 813
add 1 210 813
return 1 210 814
assign 1 212 816
libNameGet 0 212 816
assign 1 212 817
relEmitName 1 212 817
assign 1 212 818
new 0 212 818
assign 1 212 819
add 1 212 819
assign 1 212 820
add 1 212 820
assign 1 212 821
new 0 212 821
assign 1 212 822
add 1 212 822
assign 1 212 823
add 1 212 823
assign 1 212 824
new 0 212 824
assign 1 212 825
add 1 212 825
return 1 212 826
getCode 2 217 832
assign 1 218 833
toHexString 1 218 833
assign 1 219 834
new 0 219 834
assign 1 219 835
once 0 219 835
addValue 1 219 836
addValue 1 220 837
assign 1 225 860
new 0 225 860
assign 1 225 861
add 1 225 861
assign 1 225 862
new 0 225 862
assign 1 225 863
add 1 225 863
assign 1 225 864
add 1 225 864
assign 1 226 865
new 0 226 865
assign 1 226 866
addValue 1 226 866
assign 1 226 867
addValue 1 226 867
assign 1 226 868
new 0 226 868
assign 1 226 869
addValue 1 226 869
addValue 1 226 870
assign 1 227 871
new 0 227 871
assign 1 227 872
addValue 1 227 872
addValue 1 227 873
assign 1 228 874
new 0 228 874
assign 1 228 875
addValue 1 228 875
assign 1 228 876
outputPlatformGet 0 228 876
assign 1 228 877
nameGet 0 228 877
assign 1 228 878
addValue 1 228 878
assign 1 228 879
new 0 228 879
assign 1 228 880
addValue 1 228 880
addValue 1 228 881
return 1 229 882
assign 1 233 888
new 0 233 888
assign 1 233 889
once 0 233 889
assign 1 233 890
add 1 233 890
return 1 233 891
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -78314965: return bem_falseValueGet_0();
case -2143129801: return bem_boolNpGet_0();
case 169322665: return bem_constGetDirect_0();
case 629025591: return bem_lastCallGetDirect_0();
case -222935770: return bem_beginNs_0();
case 1255651783: return bem_mnodeGetDirect_0();
case 472599344: return bem_parentConfGetDirect_0();
case 1010834778: return bem_instanceNotEqualGetDirect_0();
case -457778838: return bem_fullLibEmitNameGet_0();
case 345446904: return bem_instanceEqualGetDirect_0();
case 2145305488: return bem_afterCast_0();
case 490169518: return bem_nameToIdPathGetDirect_0();
case -361305878: return bem_classesInDepthOrderGet_0();
case -204273230: return bem_cnodeGetDirect_0();
case -426480669: return bem_classEmitsGetDirect_0();
case -1262462641: return bem_mainStartGet_0();
case 1122708506: return bem_callNamesGetDirect_0();
case -1132108466: return bem_idToNameGet_0();
case -535189665: return bem_fullLibEmitNameGetDirect_0();
case -37851474: return bem_objectCcGet_0();
case 1717173983: return bem_returnTypeGet_0();
case 110648686: return bem_buildGet_0();
case 1080043069: return bem_csynGetDirect_0();
case -1405180947: return bem_ccMethodsGet_0();
case -1737404292: return bem_scvpGetDirect_0();
case 769897003: return bem_lineCountGetDirect_0();
case -2123848647: return bem_fieldNamesGet_0();
case -87263012: return bem_returnTypeGetDirect_0();
case -536346995: return bem_libEmitNameGet_0();
case -1733128658: return bem_randGetDirect_0();
case 1421482783: return bem_saveSyns_0();
case -850486381: return bem_maxDynArgsGet_0();
case 1208760191: return bem_synEmitPathGetDirect_0();
case -641079719: return bem_useDynMethodsGet_0();
case -1493267834: return bem_intNpGetDirect_0();
case 245502372: return bem_ntypesGet_0();
case -234192182: return bem_preClassGet_0();
case 2023788277: return bem_nlGetDirect_0();
case 1668541846: return bem_sourceFileNameGet_0();
case -821544406: return bem_smnlecsGet_0();
case -872736533: return bem_mnodeGet_0();
case 595072153: return bem_spropDecGet_0();
case 1220119859: return bem_preClassOutput_0();
case -1886598656: return bem_nullValueGet_0();
case -864009358: return bem_baseMtdDecGet_0();
case 1614178935: return bem_inClassGet_0();
case -937082770: return bem_lastCallGet_0();
case -1621804456: return bem_onceDecsGetDirect_0();
case 2093737183: return bem_classEmitsGet_0();
case 1585596432: return bem_mainEndGet_0();
case -1074341902: return bem_print_0();
case -831297809: return bem_synEmitPathGet_0();
case -1804378426: return bem_onceCountGetDirect_0();
case 1066616132: return bem_emitLangGetDirect_0();
case -1282444814: return bem_getClassOutput_0();
case 859371192: return bem_ccCacheGetDirect_0();
case 424451961: return bem_floatNpGet_0();
case 2001856233: return bem_inFilePathedGetDirect_0();
case 2029977409: return bem_superCallsGetDirect_0();
case 835565802: return bem_superCallsGet_0();
case 1849647014: return bem_ccCacheGet_0();
case -333598598: return bem_mainInClassGet_0();
case 1760831944: return bem_baseSmtdDecGet_0();
case -1404219966: return bem_trueValueGetDirect_0();
case -1905108631: return bem_inClassGetDirect_0();
case -1892701373: return bem_invpGetDirect_0();
case 445671354: return bem_buildGetDirect_0();
case 1165329653: return bem_hashGet_0();
case -1759525090: return bem_preClassGetDirect_0();
case -1392862002: return bem_scvpGet_0();
case -1342157479: return bem_falseValueGetDirect_0();
case -1392419171: return bem_instanceEqualGet_0();
case 1715125286: return bem_idToNamePathGetDirect_0();
case 507858949: return bem_nativeCSlotsGetDirect_0();
case -1124832136: return bem_propertyDecsGetDirect_0();
case -193077708: return bem_intNpGet_0();
case 1913950122: return bem_lastMethodBodyLinesGet_0();
case 600460578: return bem_parentConfGet_0();
case 1276762113: return bem_libEmitPathGet_0();
case 426203430: return bem_qGet_0();
case -691708986: return bem_saveIds_0();
case 270959130: return bem_instOfGetDirect_0();
case -875332173: return bem_callNamesGet_0();
case -1391349949: return bem_qGetDirect_0();
case -2124754834: return bem_smnlcsGetDirect_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 934085023: return bem_propertyDecsGet_0();
case 617442909: return bem_dynMethodsGetDirect_0();
case -997668981: return bem_objectNpGet_0();
case 844225351: return bem_classNameGet_0();
case 131757446: return bem_classCallsGetDirect_0();
case -1941167201: return bem_overrideMtdDecGet_0();
case 1905914300: return bem_nlGet_0();
case -769338970: return bem_objectNpGetDirect_0();
case 261068612: return bem_nameToIdGet_0();
case 80244442: return bem_toString_0();
case -1783929376: return bem_superNameGet_0();
case 1315871139: return bem_transGetDirect_0();
case 1434623507: return bem_propDecGet_0();
case -1172114473: return bem_instanceNotEqualGet_0();
case 798635962: return bem_transGet_0();
case -2083934905: return bem_copy_0();
case -2128819235: return bem_boolNpGetDirect_0();
case -1984209275: return bem_nameToIdPathGet_0();
case -1574768079: return bem_ccMethodsGetDirect_0();
case -690615196: return bem_onceCountGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -1116711567: return bem_boolCcGetDirect_0();
case -496832934: return bem_lastMethodBodySizeGet_0();
case 480631437: return bem_methodsGet_0();
case -764075908: return bem_covariantReturnsGet_0();
case 71977147: return bem_writeBET_0();
case 686470736: return bem_getLibOutput_0();
case -538975372: return bem_methodCallsGetDirect_0();
case -18799217: return bem_inFilePathedGet_0();
case -313018470: return bem_floatNpGetDirect_0();
case 335319450: return bem_nullValueGetDirect_0();
case -604029816: return bem_csynGet_0();
case 1459121843: return bem_buildInitial_0();
case -892916460: return bem_methodCallsGet_0();
case 58173536: return bem_stringNpGetDirect_0();
case 2120985552: return bem_nameToIdGetDirect_0();
case 652035666: return bem_buildCreate_0();
case -1875409397: return bem_runtimeInitGet_0();
case 1582879745: return bem_onceDecsGet_0();
case -649617829: return bem_initialDecGet_0();
case 1014225644: return bem_echo_0();
case 330229176: return bem_classConfGet_0();
case -1207503373: return bem_classesInDepthOrderGetDirect_0();
case -1340057898: return bem_lineCountGet_0();
case -792856093: return bem_lastMethodsLinesGetDirect_0();
case -1080375627: return bem_cnodeGet_0();
case -1984252690: return bem_methodsGetDirect_0();
case -1697635816: return bem_constGet_0();
case 1323061772: return bem_newDecGet_0();
case -1625648722: return bem_once_0();
case -1982688121: return bem_methodBodyGetDirect_0();
case 1855284168: return bem_lastMethodBodySizeGetDirect_0();
case 1971234455: return bem_smnlecsGetDirect_0();
case -2032101198: return bem_lastMethodBodyLinesGetDirect_0();
case 525326211: return bem_boolCcGet_0();
case -1249297189: return bem_classCallsGet_0();
case 1003879962: return bem_mainOutsideNsGet_0();
case 1742142204: return bem_typeDecGet_0();
case 259760519: return bem_doEmit_0();
case -784517859: return bem_boolTypeGet_0();
case 334319852: return bem_gcMarksGetDirect_0();
case -1194289304: return bem_serializeToString_0();
case -628560707: return bem_toAny_0();
case 806207848: return bem_trueValueGet_0();
case -451330201: return bem_gcMarksGet_0();
case -1162639317: return bem_emitLib_0();
case -308661352: return bem_msynGetDirect_0();
case -319814182: return bem_methodCatchGet_0();
case -379634769: return bem_emitLangGet_0();
case -2025233470: return bem_fileExtGetDirect_0();
case 1297175099: return bem_fieldIteratorGet_0();
case -160085941: return bem_maxDynArgsGetDirect_0();
case -1148257112: return bem_nativeCSlotsGet_0();
case 956574853: return bem_randGet_0();
case 1939601641: return bem_lastMethodsLinesGet_0();
case -1511021063: return bem_objectCcGetDirect_0();
case -753894116: return bem_new_0();
case -1420507173: return bem_maxSpillArgsLenGet_0();
case 545488855: return bem_classEndGet_0();
case 1146754305: return bem_dynMethodsGet_0();
case 598660659: return bem_maxSpillArgsLenGetDirect_0();
case -211435562: return bem_stringNpGet_0();
case -2131387379: return bem_iteratorGet_0();
case -1551739374: return bem_loadIds_0();
case -1745159060: return bem_buildClassInfo_0();
case 656859578: return bem_idToNameGetDirect_0();
case 1419988809: return bem_smnlcsGet_0();
case -1253246070: return bem_create_0();
case 142309240: return bem_methodCatchGetDirect_0();
case 633639020: return bem_msynGet_0();
case 71599733: return bem_invpGet_0();
case -1138848090: return bem_libEmitNameGetDirect_0();
case -1882364243: return bem_many_0();
case -326723999: return bem_idToNamePathGet_0();
case 849580353: return bem_exceptDecGet_0();
case 1862424080: return bem_ntypesGetDirect_0();
case -1205761857: return bem_fileExtGet_0();
case 1128662784: return bem_instOfGet_0();
case 1700510930: return bem_lastMethodsSizeGet_0();
case -638729435: return bem_libEmitPathGetDirect_0();
case 872689896: return bem_lastMethodsSizeGetDirect_0();
case 770834928: return bem_serializeContents_0();
case -623614214: return bem_exceptDecGetDirect_0();
case 85198253: return bem_methodBodyGet_0();
case 1507976961: return bem_classConfGetDirect_0();
case -1138072028: return bem_tagGet_0();
case -1747422787: return bem_endNs_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1828461255: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1318215766: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -897074069: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1299029440: return bem_lineCountSet_1(bevd_0);
case 767035397: return bem_cnodeSet_1(bevd_0);
case 28776305: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 940810825: return bem_falseValueSetDirect_1(bevd_0);
case -1328198388: return bem_onceCountSet_1(bevd_0);
case 322534726: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 394142553: return bem_onceDecsSetDirect_1(bevd_0);
case -1477057474: return bem_objectNpSet_1(bevd_0);
case 1242841441: return bem_exceptDecSet_1(bevd_0);
case 1103592228: return bem_buildSetDirect_1(bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case 1561323130: return bem_ccMethodsSetDirect_1(bevd_0);
case -1662592283: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 299601698: return bem_objectCcSet_1(bevd_0);
case 1871565959: return bem_begin_1(bevd_0);
case 1864125679: return bem_boolCcSetDirect_1(bevd_0);
case 1421994132: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 933603665: return bem_constSetDirect_1(bevd_0);
case -613192058: return bem_lastMethodsSizeSet_1(bevd_0);
case 1087926497: return bem_methodCatchSetDirect_1(bevd_0);
case -1455615265: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1613671528: return bem_smnlcsSet_1(bevd_0);
case 792032021: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 58910575: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1599862547: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 947572781: return bem_nameToIdPathSet_1(bevd_0);
case -1959864840: return bem_falseValueSet_1(bevd_0);
case -968070207: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case 430412847: return bem_maxDynArgsSet_1(bevd_0);
case 1523563156: return bem_scvpSet_1(bevd_0);
case 1709151165: return bem_mnodeSet_1(bevd_0);
case 1047897056: return bem_csynSetDirect_1(bevd_0);
case 484897412: return bem_objectNpSetDirect_1(bevd_0);
case 1543042423: return bem_inFilePathedSet_1(bevd_0);
case 1114473777: return bem_lastCallSetDirect_1(bevd_0);
case -1086615981: return bem_idToNameSet_1(bevd_0);
case -166795198: return bem_classConfSet_1(bevd_0);
case 717416626: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 10123246: return bem_randSet_1(bevd_0);
case 1960637210: return bem_nameToIdSet_1(bevd_0);
case -1360376176: return bem_dynMethodsSet_1(bevd_0);
case 1400426003: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -830877828: return bem_boolNpSetDirect_1(bevd_0);
case -1710302810: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 207983165: return bem_instanceEqualSetDirect_1(bevd_0);
case -2125774510: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 484199018: return bem_mnodeSetDirect_1(bevd_0);
case -1774370606: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 53088132: return bem_trueValueSetDirect_1(bevd_0);
case 835769391: return bem_instanceNotEqualSet_1(bevd_0);
case 907084378: return bem_methodCallsSetDirect_1(bevd_0);
case 1894140767: return bem_nameToIdPathSetDirect_1(bevd_0);
case 1451656488: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1862183552: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1774370882: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1302331782: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 105277064: return bem_inClassSet_1(bevd_0);
case -1147403507: return bem_fileExtSetDirect_1(bevd_0);
case 1161758364: return bem_libEmitPathSetDirect_1(bevd_0);
case -60755170: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -119518888: return bem_intNpSet_1(bevd_0);
case 169604459: return bem_instOfSet_1(bevd_0);
case -1597594453: return bem_fullLibEmitNameSet_1(bevd_0);
case 1044743653: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 367637389: return bem_inClassSetDirect_1(bevd_0);
case 1167861221: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1911717218: return bem_instanceEqualSet_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case -1926697772: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 749115498: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1051159350: return bem_dynMethodsSetDirect_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case -533260607: return bem_objectCcSetDirect_1(bevd_0);
case 975039483: return bem_superCallsSet_1(bevd_0);
case 1168753254: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -476387023: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case 1413857046: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -510494131: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 756888870: return bem_qSetDirect_1(bevd_0);
case -2128710650: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 483528132: return bem_csynSet_1(bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -101338277: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1052989977: return bem_classConfSetDirect_1(bevd_0);
case 1452003855: return bem_ccCacheSet_1(bevd_0);
case 335022016: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case 949065694: return bem_libEmitNameSet_1(bevd_0);
case 464328805: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1175761675: return bem_nullValueSetDirect_1(bevd_0);
case -1520457427: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -73480760: return bem_floatNpSet_1(bevd_0);
case -1824744055: return bem_onceDecsSet_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case 1647854294: return bem_exceptDecSetDirect_1(bevd_0);
case 241905719: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -813962893: return bem_preClassSet_1(bevd_0);
case 123000869: return bem_parentConfSetDirect_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -406676948: return bem_buildSet_1(bevd_0);
case -2057376515: return bem_invpSet_1(bevd_0);
case 353909481: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1981636011: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -443938369: return bem_synEmitPathSet_1(bevd_0);
case -1794371002: return bem_methodBodySet_1(bevd_0);
case -758114474: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -519719067: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1773887103: return bem_gcMarksSetDirect_1(bevd_0);
case -1375492195: return bem_stringNpSetDirect_1(bevd_0);
case -946231395: return bem_smnlcsSetDirect_1(bevd_0);
case 2111688280: return bem_stringNpSet_1(bevd_0);
case -324062143: return bem_nlSetDirect_1(bevd_0);
case -1189039138: return bem_propertyDecsSetDirect_1(bevd_0);
case -1046116359: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 576985446: return bem_returnTypeSet_1(bevd_0);
case 556055480: return bem_nlSet_1(bevd_0);
case -1572713244: return bem_instOfSetDirect_1(bevd_0);
case -1360412092: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 107814648: return bem_propertyDecsSet_1(bevd_0);
case -651654644: return bem_smnlecsSetDirect_1(bevd_0);
case 2029931834: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case 183595258: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1460184011: return bem_onceCountSetDirect_1(bevd_0);
case -1313175183: return bem_ntypesSet_1(bevd_0);
case -705340827: return bem_msynSetDirect_1(bevd_0);
case 1242286205: return bem_msynSet_1(bevd_0);
case 630738308: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2019596935: return bem_idToNamePathSet_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case 2083664693: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2039795015: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 981823048: return bem_idToNameSetDirect_1(bevd_0);
case -51713617: return bem_lineCountSetDirect_1(bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case 126975074: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -367480124: return bem_idToNamePathSetDirect_1(bevd_0);
case 338397880: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1690973467: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -548210152: return bem_cnodeSetDirect_1(bevd_0);
case 382021494: return bem_callNamesSet_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case -422304247: return bem_lastMethodsLinesSet_1(bevd_0);
case 1472815984: return bem_classEmitsSet_1(bevd_0);
case 217523338: return bem_classEmitsSetDirect_1(bevd_0);
case 1702220577: return bem_intNpSetDirect_1(bevd_0);
case 314260484: return bem_fileExtSet_1(bevd_0);
case 616011506: return bem_lastCallSet_1(bevd_0);
case 30730902: return bem_synEmitPathSetDirect_1(bevd_0);
case -616430800: return bem_boolCcSet_1(bevd_0);
case -1118151269: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -185665984: return bem_methodCallsSet_1(bevd_0);
case -1396902607: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1620251063: return bem_nativeCSlotsSet_1(bevd_0);
case 1005029589: return bem_randSetDirect_1(bevd_0);
case -101254044: return bem_ntypesSetDirect_1(bevd_0);
case 764644429: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 500787092: return bem_boolNpSet_1(bevd_0);
case -1082374198: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1812813690: return bem_methodsSetDirect_1(bevd_0);
case -2079299900: return bem_transSet_1(bevd_0);
case 1880728021: return bem_callNamesSetDirect_1(bevd_0);
case -1530734939: return bem_methodsSet_1(bevd_0);
case 940449784: return bem_maxSpillArgsLenSet_1(bevd_0);
case 2066256225: return bem_preClassSetDirect_1(bevd_0);
case 984659008: return bem_maxDynArgsSetDirect_1(bevd_0);
case -783218824: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -701229238: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -636442813: return bem_def_1(bevd_0);
case 1379999319: return bem_nullValueSet_1(bevd_0);
case 419616286: return bem_transSetDirect_1(bevd_0);
case -1016423407: return bem_ccCacheSetDirect_1(bevd_0);
case -1916505610: return bem_lastMethodBodySizeSet_1(bevd_0);
case -640116544: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1389349790: return bem_invpSetDirect_1(bevd_0);
case 2760631: return bem_ccMethodsSet_1(bevd_0);
case -63094894: return bem_smnlecsSet_1(bevd_0);
case -1268814534: return bem_nameToIdSetDirect_1(bevd_0);
case 421653002: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 131980825: return bem_methodBodySetDirect_1(bevd_0);
case 733739320: return bem_libEmitNameSetDirect_1(bevd_0);
case -1962631749: return bem_gcMarksSet_1(bevd_0);
case -1994436015: return bem_parentConfSet_1(bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -2062829496: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1512221442: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 778494463: return bem_libEmitPathSet_1(bevd_0);
case 1533677259: return bem_superCallsSetDirect_1(bevd_0);
case -1416635858: return bem_scvpSetDirect_1(bevd_0);
case 807157674: return bem_returnTypeSetDirect_1(bevd_0);
case -460126063: return bem_trueValueSet_1(bevd_0);
case -281213046: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2092171698: return bem_inFilePathedSetDirect_1(bevd_0);
case -2000905031: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1958592570: return bem_emitLangSetDirect_1(bevd_0);
case 2120648505: return bem_floatNpSetDirect_1(bevd_0);
case -2141398796: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case 1346232807: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -569474528: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 1087632853: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case -801428140: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1317982585: return bem_classesInDepthOrderSet_1(bevd_0);
case 2072080610: return bem_methodCatchSet_1(bevd_0);
case -274871277: return bem_classCallsSetDirect_1(bevd_0);
case 880616037: return bem_classCallsSet_1(bevd_0);
case 1408969798: return bem_qSet_1(bevd_0);
case -466748319: return bem_constSet_1(bevd_0);
case 1665646633: return bem_emitLangSet_1(bevd_0);
case -564150968: return bem_end_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1879201368: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1217822391: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -152646967: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1185443478: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -932507309: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 876053379: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1461073070: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1496276483: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1620570028: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1313646753: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1253012521: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -295847092: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1974168365: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -2084998657: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1818208840: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1474147189: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1303886738: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -429369067: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 878290706: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 378402382: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildSWEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildSWEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildSWEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_inst = (BEC_2_5_9_BuildSWEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_type;
}
}
}
