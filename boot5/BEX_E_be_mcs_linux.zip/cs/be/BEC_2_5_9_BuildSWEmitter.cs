namespace be {
/* IO:File: source/build/SWEmitter.be */
public sealed class BEC_2_5_9_BuildSWEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildSWEmitter() { }
static BEC_2_5_9_BuildSWEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildSWEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x53,0x57,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildSWEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x57,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_0 = {0x73,0x77};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_1 = {0x2E,0x73,0x77,0x69,0x66,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_2 = {0x20,0x74,0x68,0x72,0x6F,0x77,0x73};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_3 = {0x6E,0x69,0x6C};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_4 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_5 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_6 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_7 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_9 = {0x2F,0x2A,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_10 = {0x20,0x2A,0x2F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_12 = {0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_13 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_13, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_14 = {0x5F,0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_14, 6));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_15 = {};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_16 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_17 = {0x3A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_18 = {0x3F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_19 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_19, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_20 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_20, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_21 = {0x3F,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_22 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_22, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_23 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_23, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_24 = {0x3F,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_25 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_25, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_26 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_26, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_27 = {0x3F,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_28 = {0x3F,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_29 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_30 = {0x20,0x3A,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_31 = {0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x75,0x6E,0x63,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x74,0x68,0x72,0x6F,0x77,0x73,0x20,0x2D,0x3E,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_32 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_33 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_34 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_35 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_36 = {0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_36, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_37 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_37, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_38 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_38, 10));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_39 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_40 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_41 = {0x3A,0x5B,0x55,0x49,0x6E,0x74,0x38,0x5D,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_42 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_42, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_43 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_43, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_44 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_45 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_46 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_47 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_48 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_49 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_50 = {0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3A};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_51 = {0x20,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_52 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_53 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_54 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_55 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_56 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_57 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_58 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_59 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_60 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_61 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_62 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_63 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_64 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_65 = {0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_66 = {0x20,0x2D,0x3E,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_67 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_68 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_69 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_70 = {0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_71 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_72 = {0x20,0x2D,0x3E,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_73 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_74 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_75 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_76 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_77 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_77, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_78 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_78, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_79 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_80 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_80, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_81 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_82 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_83 = {0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_83, 28));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_84 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_84, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_85 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_86 = {0x66,0x75,0x6E,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_87 = {0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x75,0x6E,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_88 = {};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_89 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_89, 9));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_90 = {0x20,0x61,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_90, 4));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_91 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_91, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_92 = {0x20,0x61,0x73,0x21,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_92, 5));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_93 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_93, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_94 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_95 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_96 = {0x20,0x2D,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_97 = {0x3F,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_98 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_99 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x61,0x72,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_99, 11));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_100 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_100, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_101 = {0x3F,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_101, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_102 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_102, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_103 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_103, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_104 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_104, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_105 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_105, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_106 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_106, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_107 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_107, 1));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_108 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_108, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_109 = {0x6D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_109, 19));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_110 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_110, 2));
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_111 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_112 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_113 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_114 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_115 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildSWEmitter_bels_116 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildSWEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildSWEmitter_bels_116, 3));
public static new BEC_2_5_9_BuildSWEmitter bece_BEC_2_5_9_BuildSWEmitter_bevs_inst;

public static new BET_2_5_9_BuildSWEmitter bece_BEC_2_5_9_BuildSWEmitter_bevs_type;

public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildSWEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_2));
bevp_nullValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_3));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildSWEmitter_bels_4));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildSWEmitter_bels_5));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_6));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildSWEmitter_bels_7));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_clb = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 36 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 37 */
 else  /* Line: 38 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildSWEmitter_bels_8));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 39 */
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildSWEmitter_bels_9));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_inFilePathed);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_10));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevl_clb = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = beva_csyn.bem_isFinalGet_0();
bevt_12_tmpany_phold = bem_klassDec_1(bevt_13_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_11));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildSWEmitter_bels_12));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevl_clb.bem_addValue_1(bevt_17_tmpany_phold);
bevt_16_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_clb;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_0;
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildSWEmitter_bels_15));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
if (!(beva_isArg.bevi_bool)) /* Line: 56 */ {
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_16));
beva_b.bem_addValue_1(bevt_0_tmpany_phold);
} /* Line: 57 */
bevt_1_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_17));
beva_b.bem_addValue_1(bevt_2_tmpany_phold);
bem_typeDecForVar_2(beva_b, beva_v);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_18));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bevp_csyn.bem_namepathGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_equals_1(bevp_objectNp);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 69 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_2;
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_3;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_4_tmpany_phold = bem_baseSpropDec_2(bevt_5_tmpany_phold, bevt_6_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_4_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_21));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 70 */
 else  /* Line: 71 */ {
bevt_15_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_4;
bevt_19_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_5;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_14_tmpany_phold = bem_overrideSpropDec_2(bevt_15_tmpany_phold, bevt_16_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_14_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_24));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 72 */
return bevl_initialDec;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_6;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_7;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevp_csyn.bem_namepathGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_equals_1(bevp_objectNp);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_9_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_8_tmpany_phold = bem_baseSpropDec_2(bevt_9_tmpany_phold, bevl_bein);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_27));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 85 */
 else  /* Line: 86 */ {
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_tmpany_phold = bem_overrideSpropDec_2(bevt_14_tmpany_phold, bevl_bein);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_13_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_28));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 87 */
return bevl_initialDec;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_6_6_SystemObject bevl_tout = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_2_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_fileGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_existsGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 94 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_classDirGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_4_tmpany_phold.bem_makeDirs_0();
} /* Line: 95 */
bevt_8_tmpany_phold = bevp_classConf.bem_typePathGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_writerGet_0();
bevl_tout = bevt_6_tmpany_phold.bemd_0(686957318);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildSWEmitter_bels_29));
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildSWEmitter_bels_30));
bevt_9_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(71, bece_BEC_2_5_9_BuildSWEmitter_bels_31));
bevl_bet.bem_addValue_1(bevt_14_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_32));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_33));
bevt_15_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_34));
bevl_bet.bem_addValue_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_35));
bevl_bet.bem_addValue_1(bevt_21_tmpany_phold);
bevl_tout.bemd_1(-1783394952, bevl_bet);
bevl_tout.bemd_0(336528110);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_5_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_4_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_8;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_newcc.bem_emitNameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_10;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildSWEmitter_bels_39));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_40));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildSWEmitter_bels_41));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_12;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
bevt_6_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildSWEmitter_bels_44));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_45));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_11_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_relEmitName_1(bevt_11_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_46));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_47));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_16_tmpany_phold);
bevt_20_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-939370360);
bevt_18_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_19_tmpany_phold );
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_48));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_49));
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_24_tmpany_phold);
bevt_23_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_4_6_TextString bevl_tname = null;
BEC_2_4_6_TextString bevl_mname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_vcast = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_0_tmpany_phold.bem_relEmitName_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevl_tname = bevt_2_tmpany_phold.bem_typeEmitNameGet_0();
bevl_mname = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-939370360);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_11_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(27, bece_BEC_2_5_9_BuildSWEmitter_bels_50));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_51));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_52));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = bevl_mname.bem_notEquals_1(bevl_oname);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 172 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_53));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_54));
bevl_vcast = bem_formCast_3(bevp_classConf, bevt_16_tmpany_phold, bevt_17_tmpany_phold);
} /* Line: 173 */
 else  /* Line: 174 */ {
bevl_vcast = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildSWEmitter_bels_55));
} /* Line: 175 */
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_56));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevt_21_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_addValue_1(bevl_vcast);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_57));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevt_23_tmpany_phold);
bevt_18_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_58));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_25_tmpany_phold);
bevt_24_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_32_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildSWEmitter_bels_59));
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) bevt_31_tmpany_phold.bem_addValue_1(bevt_33_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) bevt_30_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_60));
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) bevt_29_tmpany_phold.bem_addValue_1(bevt_34_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevt_28_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_61));
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_26_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_62));
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_39_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevt_38_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_63));
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevt_37_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_36_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_64));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_42_tmpany_phold);
bevt_41_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_47_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_47_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildSWEmitter_bels_65));
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) bevt_46_tmpany_phold.bem_addValue_1(bevt_48_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) bevt_45_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildSWEmitter_bels_66));
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) bevt_44_tmpany_phold.bem_addValue_1(bevt_49_tmpany_phold);
bevt_43_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_67));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_53_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_68));
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_69));
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_56_tmpany_phold);
bevt_55_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_6_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_70));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_71));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildSWEmitter_bels_72));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildSWEmitter_bels_73));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(beva_len);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildSWEmitter_bels_74));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_75));
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_10_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_76));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_18_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_13;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_14;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_79));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_81));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_82));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1185294088);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1471282368);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_85));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_86));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildSWEmitter_bels_87));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_newDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildSWEmitter_bels_88));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_18;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_19;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 247 */
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_21;
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_11_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_22;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
return bevt_8_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_3(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type, BEC_2_4_6_TextString beva_targ) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCast_2(beva_cc, beva_type);
bevt_0_tmpany_phold = beva_targ.bem_add_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_94));
bevt_0_tmpany_phold.bem_addValue_1(bevt_2_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildSWEmitter_bels_95));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_96));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_10_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_11_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildSWEmitter_bels_97));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildSWEmitter_bels_98));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_23;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_anyName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_24;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_25;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 275 */ {
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_26;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_27;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_28;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 276 */
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_29;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_lisz);
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_30;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(beva_belsName);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_31;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
return bevt_10_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_32;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_33;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_34;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildSWEmitter_bels_111));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildSWEmitter_bels_112));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildSWEmitter_bels_113));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildSWEmitter_bels_114));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-12349386);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildSWEmitter_bels_115));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildSWEmitter_bevo_35;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 21, 25, 27, 28, 32, 32, 32, 32, 32, 32, 32, 32, 36, 36, 37, 37, 37, 39, 39, 41, 41, 41, 41, 41, 42, 42, 42, 42, 42, 42, 42, 42, 42, 43, 43, 43, 44, 48, 48, 48, 48, 48, 48, 48, 52, 52, 57, 57, 59, 59, 60, 60, 61, 62, 62, 67, 69, 69, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 75, 80, 82, 82, 82, 82, 82, 84, 84, 85, 85, 85, 85, 85, 85, 87, 87, 87, 87, 87, 87, 90, 94, 94, 94, 94, 94, 95, 95, 95, 97, 97, 97, 97, 98, 99, 99, 99, 99, 99, 99, 132, 132, 133, 133, 133, 133, 133, 133, 134, 134, 135, 135, 136, 137, 141, 141, 141, 141, 141, 141, 141, 141, 141, 141, 141, 145, 145, 149, 149, 149, 149, 149, 153, 153, 153, 153, 153, 153, 157, 157, 157, 157, 157, 157, 157, 157, 157, 157, 157, 157, 157, 157, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 158, 160, 160, 160, 164, 164, 164, 165, 165, 166, 167, 167, 167, 168, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 172, 173, 173, 173, 175, 178, 178, 178, 178, 178, 178, 178, 180, 180, 180, 183, 183, 183, 183, 183, 183, 183, 183, 183, 183, 183, 185, 185, 185, 185, 185, 185, 187, 187, 187, 189, 191, 191, 191, 191, 191, 191, 191, 191, 193, 193, 193, 193, 193, 193, 195, 195, 195, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 205, 206, 206, 206, 206, 206, 206, 206, 206, 206, 208, 208, 208, 212, 212, 212, 212, 212, 212, 217, 217, 217, 221, 221, 221, 222, 223, 223, 223, 223, 223, 223, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 230, 230, 234, 234, 238, 238, 242, 242, 246, 246, 247, 247, 247, 247, 247, 247, 247, 249, 249, 249, 249, 249, 249, 249, 253, 253, 253, 258, 258, 258, 258, 260, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 267, 267, 271, 271, 271, 271, 271, 271, 271, 271, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 276, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 283, 284, 285, 285, 285, 286, 291, 291, 291, 291, 291, 292, 292, 292, 292, 292, 292, 293, 293, 293, 294, 294, 294, 294, 294, 294, 294, 294, 295, 299, 299, 299, 299};
public static new int[] bevs_smnlec
 = new int[] {166, 167, 168, 169, 170, 171, 172, 183, 184, 185, 186, 187, 188, 189, 190, 214, 219, 220, 221, 222, 225, 226, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 254, 255, 256, 257, 258, 259, 260, 264, 265, 273, 274, 276, 277, 278, 279, 280, 281, 282, 309, 310, 311, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 338, 359, 360, 361, 362, 363, 364, 365, 366, 368, 369, 370, 371, 372, 373, 376, 377, 378, 379, 380, 381, 383, 410, 411, 412, 413, 418, 419, 420, 421, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 475, 476, 483, 484, 485, 486, 487, 496, 497, 498, 499, 500, 501, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 647, 648, 649, 652, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 756, 757, 758, 759, 760, 761, 766, 767, 768, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 813, 814, 818, 819, 823, 824, 828, 829, 846, 847, 849, 850, 851, 852, 853, 854, 855, 857, 858, 859, 860, 861, 862, 863, 868, 869, 870, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 906, 907, 917, 918, 919, 920, 921, 922, 923, 924, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 976, 977, 978, 979, 980, 981, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1032, 1033, 1034, 1035};
/* BEGIN LINEINFO 
assign 1 18 166
new 0 18 166
assign 1 19 167
new 0 19 167
assign 1 20 168
new 0 20 168
assign 1 21 169
new 0 21 169
new 1 25 170
assign 1 27 171
new 0 27 171
assign 1 28 172
new 0 28 172
assign 1 32 183
new 0 32 183
assign 1 32 184
addValue 1 32 184
assign 1 32 185
secondGet 0 32 185
assign 1 32 186
formTarg 1 32 186
assign 1 32 187
addValue 1 32 187
assign 1 32 188
new 0 32 188
assign 1 32 189
addValue 1 32 189
addValue 1 32 190
assign 1 36 214
def 1 36 219
assign 1 37 220
libNameGet 0 37 220
assign 1 37 221
relEmitName 1 37 221
assign 1 37 222
extend 1 37 222
assign 1 39 225
new 0 39 225
assign 1 39 226
extend 1 39 226
assign 1 41 228
new 0 41 228
assign 1 41 229
addValue 1 41 229
assign 1 41 230
new 0 41 230
assign 1 41 231
addValue 1 41 231
assign 1 41 232
addValue 1 41 232
assign 1 42 233
isFinalGet 0 42 233
assign 1 42 234
klassDec 1 42 234
assign 1 42 235
addValue 1 42 235
assign 1 42 236
emitNameGet 0 42 236
assign 1 42 237
addValue 1 42 237
assign 1 42 238
addValue 1 42 238
assign 1 42 239
new 0 42 239
assign 1 42 240
addValue 1 42 240
addValue 1 42 241
assign 1 43 242
new 0 43 242
assign 1 43 243
addValue 1 43 243
addValue 1 43 244
return 1 44 245
assign 1 48 254
new 0 48 254
assign 1 48 255
emitNameGet 0 48 255
assign 1 48 256
add 1 48 256
assign 1 48 257
new 0 48 257
assign 1 48 258
add 1 48 258
assign 1 48 259
add 1 48 259
return 1 48 260
assign 1 52 264
new 0 52 264
return 1 52 265
assign 1 57 273
new 0 57 273
addValue 1 57 274
assign 1 59 276
nameForVar 1 59 276
addValue 1 59 277
assign 1 60 278
new 0 60 278
addValue 1 60 279
typeDecForVar 2 61 280
assign 1 62 281
new 0 62 281
addValue 1 62 282
assign 1 67 309
new 0 67 309
assign 1 69 310
namepathGet 0 69 310
assign 1 69 311
equals 1 69 311
assign 1 70 313
emitNameGet 0 70 313
assign 1 70 314
new 0 70 314
assign 1 70 315
emitNameGet 0 70 315
assign 1 70 316
add 1 70 316
assign 1 70 317
new 0 70 317
assign 1 70 318
add 1 70 318
assign 1 70 319
baseSpropDec 2 70 319
assign 1 70 320
addValue 1 70 320
assign 1 70 321
new 0 70 321
assign 1 70 322
addValue 1 70 322
addValue 1 70 323
assign 1 72 326
emitNameGet 0 72 326
assign 1 72 327
new 0 72 327
assign 1 72 328
emitNameGet 0 72 328
assign 1 72 329
add 1 72 329
assign 1 72 330
new 0 72 330
assign 1 72 331
add 1 72 331
assign 1 72 332
overrideSpropDec 2 72 332
assign 1 72 333
addValue 1 72 333
assign 1 72 334
new 0 72 334
assign 1 72 335
addValue 1 72 335
addValue 1 72 336
return 1 75 338
assign 1 80 359
new 0 80 359
assign 1 82 360
new 0 82 360
assign 1 82 361
emitNameGet 0 82 361
assign 1 82 362
add 1 82 362
assign 1 82 363
new 0 82 363
assign 1 82 364
add 1 82 364
assign 1 84 365
namepathGet 0 84 365
assign 1 84 366
equals 1 84 366
assign 1 85 368
typeEmitNameGet 0 85 368
assign 1 85 369
baseSpropDec 2 85 369
assign 1 85 370
addValue 1 85 370
assign 1 85 371
new 0 85 371
assign 1 85 372
addValue 1 85 372
addValue 1 85 373
assign 1 87 376
typeEmitNameGet 0 87 376
assign 1 87 377
overrideSpropDec 2 87 377
assign 1 87 378
addValue 1 87 378
assign 1 87 379
new 0 87 379
assign 1 87 380
addValue 1 87 380
addValue 1 87 381
return 1 90 383
assign 1 94 410
classDirGet 0 94 410
assign 1 94 411
fileGet 0 94 411
assign 1 94 412
existsGet 0 94 412
assign 1 94 413
not 0 94 418
assign 1 95 419
classDirGet 0 95 419
assign 1 95 420
fileGet 0 95 420
makeDirs 0 95 421
assign 1 97 423
typePathGet 0 97 423
assign 1 97 424
fileGet 0 97 424
assign 1 97 425
writerGet 0 97 425
assign 1 97 426
open 0 97 426
assign 1 98 427
new 0 98 427
assign 1 99 428
new 0 99 428
assign 1 99 429
addValue 1 99 429
assign 1 99 430
typeEmitNameGet 0 99 430
assign 1 99 431
addValue 1 99 431
assign 1 99 432
new 0 99 432
addValue 1 99 433
assign 1 132 434
new 0 132 434
addValue 1 132 435
assign 1 133 436
new 0 133 436
assign 1 133 437
addValue 1 133 437
assign 1 133 438
emitNameGet 0 133 438
assign 1 133 439
addValue 1 133 439
assign 1 133 440
new 0 133 440
addValue 1 133 441
assign 1 134 442
new 0 134 442
addValue 1 134 443
assign 1 135 444
new 0 135 444
addValue 1 135 445
write 1 136 446
close 0 137 447
assign 1 141 461
libNameGet 0 141 461
assign 1 141 462
relEmitName 1 141 462
assign 1 141 463
new 0 141 463
assign 1 141 464
add 1 141 464
assign 1 141 465
new 0 141 465
assign 1 141 466
add 1 141 466
assign 1 141 467
emitNameGet 0 141 467
assign 1 141 468
add 1 141 468
assign 1 141 469
new 0 141 469
assign 1 141 470
add 1 141 470
return 1 141 471
assign 1 145 475
new 0 145 475
return 1 145 476
assign 1 149 483
new 0 149 483
assign 1 149 484
addValue 1 149 484
assign 1 149 485
addValue 1 149 485
assign 1 149 486
new 0 149 486
addValue 1 149 487
assign 1 153 496
new 0 153 496
assign 1 153 497
add 1 153 497
assign 1 153 498
new 0 153 498
assign 1 153 499
add 1 153 499
assign 1 153 500
add 1 153 500
return 1 153 501
assign 1 157 529
overrideMtdDecGet 0 157 529
assign 1 157 530
addValue 1 157 530
assign 1 157 531
new 0 157 531
assign 1 157 532
addValue 1 157 532
assign 1 157 533
addValue 1 157 533
assign 1 157 534
new 0 157 534
assign 1 157 535
addValue 1 157 535
assign 1 157 536
getClassConfig 1 157 536
assign 1 157 537
libNameGet 0 157 537
assign 1 157 538
relEmitName 1 157 538
assign 1 157 539
addValue 1 157 539
assign 1 157 540
new 0 157 540
assign 1 157 541
addValue 1 157 541
addValue 1 157 542
assign 1 158 543
new 0 158 543
assign 1 158 544
addValue 1 158 544
assign 1 158 545
heldGet 0 158 545
assign 1 158 546
namepathGet 0 158 546
assign 1 158 547
getClassConfig 1 158 547
assign 1 158 548
libNameGet 0 158 548
assign 1 158 549
relEmitName 1 158 549
assign 1 158 550
addValue 1 158 550
assign 1 158 551
new 0 158 551
assign 1 158 552
addValue 1 158 552
addValue 1 158 553
assign 1 160 554
new 0 160 554
assign 1 160 555
addValue 1 160 555
addValue 1 160 556
assign 1 164 624
getClassConfig 1 164 624
assign 1 164 625
libNameGet 0 164 625
assign 1 164 626
relEmitName 1 164 626
assign 1 165 627
getClassConfig 1 165 627
assign 1 165 628
typeEmitNameGet 0 165 628
assign 1 166 629
emitNameGet 0 166 629
assign 1 167 630
heldGet 0 167 630
assign 1 167 631
namepathGet 0 167 631
assign 1 167 632
getClassConfig 1 167 632
assign 1 168 633
getInitialInst 1 168 633
assign 1 170 634
overrideMtdDecGet 0 170 634
assign 1 170 635
addValue 1 170 635
assign 1 170 636
new 0 170 636
assign 1 170 637
addValue 1 170 637
assign 1 170 638
addValue 1 170 638
assign 1 170 639
new 0 170 639
assign 1 170 640
addValue 1 170 640
assign 1 170 641
addValue 1 170 641
assign 1 170 642
new 0 170 642
assign 1 170 643
addValue 1 170 643
addValue 1 170 644
assign 1 172 645
notEquals 1 172 645
assign 1 173 647
new 0 173 647
assign 1 173 648
new 0 173 648
assign 1 173 649
formCast 3 173 649
assign 1 175 652
new 0 175 652
assign 1 178 654
addValue 1 178 654
assign 1 178 655
new 0 178 655
assign 1 178 656
addValue 1 178 656
assign 1 178 657
addValue 1 178 657
assign 1 178 658
new 0 178 658
assign 1 178 659
addValue 1 178 659
addValue 1 178 660
assign 1 180 661
new 0 180 661
assign 1 180 662
addValue 1 180 662
addValue 1 180 663
assign 1 183 664
overrideMtdDecGet 0 183 664
assign 1 183 665
addValue 1 183 665
assign 1 183 666
new 0 183 666
assign 1 183 667
addValue 1 183 667
assign 1 183 668
addValue 1 183 668
assign 1 183 669
new 0 183 669
assign 1 183 670
addValue 1 183 670
assign 1 183 671
addValue 1 183 671
assign 1 183 672
new 0 183 672
assign 1 183 673
addValue 1 183 673
addValue 1 183 674
assign 1 185 675
new 0 185 675
assign 1 185 676
addValue 1 185 676
assign 1 185 677
addValue 1 185 677
assign 1 185 678
new 0 185 678
assign 1 185 679
addValue 1 185 679
addValue 1 185 680
assign 1 187 681
new 0 187 681
assign 1 187 682
addValue 1 187 682
addValue 1 187 683
assign 1 189 684
getTypeInst 1 189 684
assign 1 191 685
overrideMtdDecGet 0 191 685
assign 1 191 686
addValue 1 191 686
assign 1 191 687
new 0 191 687
assign 1 191 688
addValue 1 191 688
assign 1 191 689
addValue 1 191 689
assign 1 191 690
new 0 191 690
assign 1 191 691
addValue 1 191 691
addValue 1 191 692
assign 1 193 693
new 0 193 693
assign 1 193 694
addValue 1 193 694
assign 1 193 695
addValue 1 193 695
assign 1 193 696
new 0 193 696
assign 1 193 697
addValue 1 193 697
addValue 1 193 698
assign 1 195 699
new 0 195 699
assign 1 195 700
addValue 1 195 700
addValue 1 195 701
assign 1 205 725
overrideMtdDecGet 0 205 725
assign 1 205 726
addValue 1 205 726
assign 1 205 727
new 0 205 727
assign 1 205 728
addValue 1 205 728
assign 1 205 729
addValue 1 205 729
assign 1 205 730
new 0 205 730
assign 1 205 731
addValue 1 205 731
assign 1 205 732
addValue 1 205 732
assign 1 205 733
new 0 205 733
assign 1 205 734
addValue 1 205 734
addValue 1 205 735
assign 1 206 736
new 0 206 736
assign 1 206 737
addValue 1 206 737
assign 1 206 738
addValue 1 206 738
assign 1 206 739
new 0 206 739
assign 1 206 740
addValue 1 206 740
assign 1 206 741
addValue 1 206 741
assign 1 206 742
new 0 206 742
assign 1 206 743
addValue 1 206 743
addValue 1 206 744
assign 1 208 745
new 0 208 745
assign 1 208 746
addValue 1 208 746
addValue 1 208 747
assign 1 212 756
new 0 212 756
assign 1 212 757
add 1 212 757
assign 1 212 758
new 0 212 758
assign 1 212 759
add 1 212 759
assign 1 212 760
add 1 212 760
return 1 212 761
assign 1 217 766
new 0 217 766
assign 1 217 767
addValue 1 217 767
addValue 1 217 768
assign 1 221 789
new 0 221 789
assign 1 221 790
toString 0 221 790
assign 1 221 791
add 1 221 791
incrementValue 0 222 792
assign 1 223 793
new 0 223 793
assign 1 223 794
addValue 1 223 794
assign 1 223 795
addValue 1 223 795
assign 1 223 796
new 0 223 796
assign 1 223 797
addValue 1 223 797
addValue 1 223 798
assign 1 225 799
containedGet 0 225 799
assign 1 225 800
firstGet 0 225 800
assign 1 225 801
containedGet 0 225 801
assign 1 225 802
firstGet 0 225 802
assign 1 225 803
new 0 225 803
assign 1 225 804
add 1 225 804
assign 1 225 805
new 0 225 805
assign 1 225 806
add 1 225 806
assign 1 225 807
finalAssign 4 225 807
addValue 1 225 808
assign 1 230 813
new 0 230 813
return 1 230 814
assign 1 234 818
new 0 234 818
return 1 234 819
assign 1 238 823
new 0 238 823
return 1 238 824
assign 1 242 828
new 0 242 828
return 1 242 829
assign 1 246 846
new 0 246 846
assign 1 246 847
equals 1 246 847
assign 1 247 849
new 0 247 849
assign 1 247 850
libNameGet 0 247 850
assign 1 247 851
relEmitName 1 247 851
assign 1 247 852
add 1 247 852
assign 1 247 853
new 0 247 853
assign 1 247 854
add 1 247 854
return 1 247 855
assign 1 249 857
new 0 249 857
assign 1 249 858
libNameGet 0 249 858
assign 1 249 859
relEmitName 1 249 859
assign 1 249 860
add 1 249 860
assign 1 249 861
new 0 249 861
assign 1 249 862
add 1 249 862
return 1 249 863
assign 1 253 868
formCast 2 253 868
assign 1 253 869
add 1 253 869
return 1 253 870
assign 1 258 886
addValue 1 258 886
assign 1 258 887
addValue 1 258 887
assign 1 258 888
new 0 258 888
addValue 1 258 889
addValue 1 260 890
assign 1 262 891
new 0 262 891
assign 1 262 892
addValue 1 262 892
assign 1 262 893
addValue 1 262 893
assign 1 262 894
new 0 262 894
assign 1 262 895
addValue 1 262 895
assign 1 262 896
libNameGet 0 262 896
assign 1 262 897
relEmitName 1 262 897
assign 1 262 898
addValue 1 262 898
assign 1 262 899
new 0 262 899
assign 1 262 900
addValue 1 262 900
addValue 1 262 901
assign 1 267 906
new 0 267 906
return 1 267 907
assign 1 271 917
new 0 271 917
assign 1 271 918
add 1 271 918
assign 1 271 919
new 0 271 919
assign 1 271 920
add 1 271 920
assign 1 271 921
add 1 271 921
assign 1 271 922
new 0 271 922
assign 1 271 923
add 1 271 923
return 1 271 924
assign 1 276 948
libNameGet 0 276 948
assign 1 276 949
relEmitName 1 276 949
assign 1 276 950
new 0 276 950
assign 1 276 951
add 1 276 951
assign 1 276 952
add 1 276 952
assign 1 276 953
new 0 276 953
assign 1 276 954
add 1 276 954
assign 1 276 955
add 1 276 955
assign 1 276 956
new 0 276 956
assign 1 276 957
add 1 276 957
return 1 276 958
assign 1 278 960
libNameGet 0 278 960
assign 1 278 961
relEmitName 1 278 961
assign 1 278 962
new 0 278 962
assign 1 278 963
add 1 278 963
assign 1 278 964
add 1 278 964
assign 1 278 965
new 0 278 965
assign 1 278 966
add 1 278 966
assign 1 278 967
add 1 278 967
assign 1 278 968
new 0 278 968
assign 1 278 969
add 1 278 969
return 1 278 970
getCode 2 283 976
assign 1 284 977
toHexString 1 284 977
assign 1 285 978
new 0 285 978
assign 1 285 979
once 0 285 979
addValue 1 285 980
addValue 1 286 981
assign 1 291 1004
new 0 291 1004
assign 1 291 1005
add 1 291 1005
assign 1 291 1006
new 0 291 1006
assign 1 291 1007
add 1 291 1007
assign 1 291 1008
add 1 291 1008
assign 1 292 1009
new 0 292 1009
assign 1 292 1010
addValue 1 292 1010
assign 1 292 1011
addValue 1 292 1011
assign 1 292 1012
new 0 292 1012
assign 1 292 1013
addValue 1 292 1013
addValue 1 292 1014
assign 1 293 1015
new 0 293 1015
assign 1 293 1016
addValue 1 293 1016
addValue 1 293 1017
assign 1 294 1018
new 0 294 1018
assign 1 294 1019
addValue 1 294 1019
assign 1 294 1020
outputPlatformGet 0 294 1020
assign 1 294 1021
nameGet 0 294 1021
assign 1 294 1022
addValue 1 294 1022
assign 1 294 1023
new 0 294 1023
assign 1 294 1024
addValue 1 294 1024
addValue 1 294 1025
return 1 295 1026
assign 1 299 1032
new 0 299 1032
assign 1 299 1033
once 0 299 1033
assign 1 299 1034
add 1 299 1034
return 1 299 1035
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1838379274: return bem_synEmitPathGet_0();
case 1749571405: return bem_getClassOutput_0();
case 1705690371: return bem_boolNpGetDirect_0();
case 1304372006: return bem_mainInClassGet_0();
case -1895103236: return bem_ntypesGet_0();
case -1963935784: return bem_nameToIdPathGet_0();
case -1632683923: return bem_classConfGetDirect_0();
case 1146333674: return bem_inFilePathedGetDirect_0();
case 391184312: return bem_writeBET_0();
case 1616243997: return bem_falseValueGetDirect_0();
case 1311081983: return bem_nameToIdGet_0();
case -972330474: return bem_returnTypeGetDirect_0();
case 1950420474: return bem_classesInDepthOrderGetDirect_0();
case -1421744026: return bem_buildInitial_0();
case -84078774: return bem_lastMethodsSizeGet_0();
case -2066826812: return bem_baseSmtdDecGet_0();
case -1898956540: return bem_copy_0();
case -1410915764: return bem_smnlcsGetDirect_0();
case -1483842085: return bem_dynMethodsGetDirect_0();
case -555340428: return bem_runtimeInitGet_0();
case 1748238975: return bem_doEmit_0();
case -71822217: return bem_callNamesGetDirect_0();
case 765364165: return bem_intNpGetDirect_0();
case -626779800: return bem_onceCountGetDirect_0();
case 1441019278: return bem_buildGet_0();
case 84004918: return bem_initialDecGet_0();
case -252791438: return bem_lineCountGetDirect_0();
case -1255132651: return bem_tagGet_0();
case -1310813830: return bem_lastMethodsSizeGetDirect_0();
case 1708994787: return bem_overrideMtdDecGet_0();
case 1131377981: return bem_idToNameGet_0();
case -1369620221: return bem_mnodeGetDirect_0();
case -1447572008: return bem_print_0();
case 963412132: return bem_objectNpGetDirect_0();
case 1249928428: return bem_saveSyns_0();
case -309299602: return bem_iteratorGet_0();
case -2128986860: return bem_lastMethodBodySizeGet_0();
case 1509136327: return bem_parentConfGetDirect_0();
case -1801696134: return bem_echo_0();
case -350197466: return bem_instOfGet_0();
case -1472415576: return bem_fullLibEmitNameGet_0();
case 1284341666: return bem_randGetDirect_0();
case -1594541507: return bem_trueValueGet_0();
case 124073172: return bem_constGetDirect_0();
case 672212893: return bem_qGetDirect_0();
case -1229104755: return bem_instanceEqualGet_0();
case 423145428: return bem_emitLib_0();
case -589266515: return bem_inClassGet_0();
case 1470601674: return bem_boolTypeGet_0();
case 565780436: return bem_synEmitPathGetDirect_0();
case -221235325: return bem_scvpGet_0();
case 1976915014: return bem_preClassOutput_0();
case -1984380714: return bem_maxDynArgsGet_0();
case -1375435659: return bem_lastMethodsLinesGetDirect_0();
case 209790039: return bem_maxSpillArgsLenGet_0();
case -157730674: return bem_floatNpGet_0();
case 398447086: return bem_invpGet_0();
case -471469043: return bem_stringNpGetDirect_0();
case 805361702: return bem_fullLibEmitNameGetDirect_0();
case 2031371578: return bem_ccMethodsGet_0();
case 706974956: return bem_ccCacheGetDirect_0();
case -1903958044: return bem_nullValueGetDirect_0();
case -581227298: return bem_buildCreate_0();
case 782341586: return bem_classNameGet_0();
case 1169533787: return bem_transGet_0();
case -66637070: return bem_methodCatchGet_0();
case -546990102: return bem_fileExtGetDirect_0();
case -1292412486: return bem_hashGet_0();
case 1725762438: return bem_parentConfGet_0();
case -875996105: return bem_getLibOutput_0();
case -1985627442: return bem_qGet_0();
case 1323879534: return bem_msynGet_0();
case -752253731: return bem_maxDynArgsGetDirect_0();
case 1170292832: return bem_nativeCSlotsGetDirect_0();
case -119788645: return bem_csynGet_0();
case -1187661424: return bem_inFilePathedGet_0();
case -5760912: return bem_gcMarksGet_0();
case 1113840477: return bem_buildClassInfo_0();
case -1344876147: return bem_toString_0();
case -384404608: return bem_libEmitNameGet_0();
case -281782088: return bem_objectCcGet_0();
case -575495696: return bem_new_0();
case 1357614162: return bem_afterCast_0();
case 575628381: return bem_preClassGetDirect_0();
case -324003448: return bem_propertyDecsGetDirect_0();
case 194421189: return bem_spropDecGet_0();
case -683276461: return bem_loadIds_0();
case -1159813380: return bem_ntypesGetDirect_0();
case -160063602: return bem_nlGetDirect_0();
case 440786266: return bem_emitLangGetDirect_0();
case -609304431: return bem_smnlcsGet_0();
case -53356617: return bem_serializeToString_0();
case -1715088833: return bem_libEmitPathGet_0();
case 692176903: return bem_classEmitsGetDirect_0();
case 519099203: return bem_propDecGet_0();
case 561749347: return bem_buildGetDirect_0();
case -1682239859: return bem_classCallsGetDirect_0();
case -817110252: return bem_objectCcGetDirect_0();
case 534727881: return bem_exceptDecGetDirect_0();
case 2046032374: return bem_nullValueGet_0();
case 1269466928: return bem_stringNpGet_0();
case 234255088: return bem_invpGetDirect_0();
case 345484764: return bem_lastMethodBodyLinesGet_0();
case -2113266897: return bem_maxSpillArgsLenGetDirect_0();
case 1987108908: return bem_emitLangGet_0();
case 108461155: return bem_libEmitPathGetDirect_0();
case 212897669: return bem_fieldNamesGet_0();
case -2032529401: return bem_returnTypeGet_0();
case -913053859: return bem_superNameGet_0();
case 1234085138: return bem_methodCatchGetDirect_0();
case -1174051041: return bem_cnodeGetDirect_0();
case 533244135: return bem_randGet_0();
case 698066484: return bem_serializeContents_0();
case 803539562: return bem_methodBodyGetDirect_0();
case 1809107655: return bem_objectNpGet_0();
case 1669662584: return bem_deserializeClassNameGet_0();
case -2080677141: return bem_ccCacheGet_0();
case 1085033499: return bem_methodCallsGetDirect_0();
case 1079656358: return bem_fieldIteratorGet_0();
case -1532099385: return bem_callNamesGet_0();
case 1611470284: return bem_boolCcGet_0();
case -1132635110: return bem_typeDecGet_0();
case -2062781139: return bem_nlGet_0();
case -814084205: return bem_instanceNotEqualGetDirect_0();
case -592328238: return bem_constGet_0();
case -475906539: return bem_libEmitNameGetDirect_0();
case -330029233: return bem_gcMarksGetDirect_0();
case -286027880: return bem_nameToIdPathGetDirect_0();
case 1173039424: return bem_exceptDecGet_0();
case -701065294: return bem_create_0();
case 1475184393: return bem_mainOutsideNsGet_0();
case -1689474667: return bem_dynMethodsGet_0();
case 1894728985: return bem_trueValueGetDirect_0();
case -1751162370: return bem_smnlecsGetDirect_0();
case -1412438644: return bem_inClassGetDirect_0();
case -1688617153: return bem_falseValueGet_0();
case 699512: return bem_lineCountGet_0();
case 1551476575: return bem_onceDecsGetDirect_0();
case -1150222973: return bem_saveIds_0();
case 167869514: return bem_lastMethodBodyLinesGetDirect_0();
case -771786030: return bem_newDecGet_0();
case 1254733578: return bem_mnodeGet_0();
case 720723191: return bem_covariantReturnsGet_0();
case 1226570643: return bem_methodsGetDirect_0();
case -284130910: return bem_endNs_0();
case -2071120248: return bem_nativeCSlotsGet_0();
case -553204644: return bem_classEndGet_0();
case 2013643655: return bem_smnlecsGet_0();
case 811869571: return bem_mainStartGet_0();
case 1393348885: return bem_lastCallGetDirect_0();
case 167521060: return bem_lastMethodBodySizeGetDirect_0();
case 345707583: return bem_lastCallGet_0();
case 558288774: return bem_toAny_0();
case 2099520841: return bem_classConfGet_0();
case -937500068: return bem_classCallsGet_0();
case 514028295: return bem_nameToIdGetDirect_0();
case 440747216: return bem_fileExtGet_0();
case -2098379420: return bem_floatNpGetDirect_0();
case -1930635657: return bem_csynGetDirect_0();
case 1906782485: return bem_intNpGet_0();
case -1452716761: return bem_idToNamePathGet_0();
case 640899021: return bem_ccMethodsGetDirect_0();
case 1201767458: return bem_useDynMethodsGet_0();
case 1923404502: return bem_classesInDepthOrderGet_0();
case -739930716: return bem_baseMtdDecGet_0();
case 322786282: return bem_instanceEqualGetDirect_0();
case 1990290498: return bem_scvpGetDirect_0();
case 1698717905: return bem_mainEndGet_0();
case 288228150: return bem_methodCallsGet_0();
case 2135304032: return bem_idToNamePathGetDirect_0();
case -756370735: return bem_idToNameGetDirect_0();
case 187391863: return bem_cnodeGet_0();
case -1979727507: return bem_boolNpGet_0();
case -244239165: return bem_superCallsGet_0();
case 1244920623: return bem_propertyDecsGet_0();
case -1356782723: return bem_superCallsGetDirect_0();
case -1274015260: return bem_onceCountGet_0();
case -558674716: return bem_methodBodyGet_0();
case -469490488: return bem_instanceNotEqualGet_0();
case -271581608: return bem_lastMethodsLinesGet_0();
case -1214823451: return bem_methodsGet_0();
case 481741071: return bem_classEmitsGet_0();
case -983803251: return bem_msynGetDirect_0();
case 135900270: return bem_onceDecsGet_0();
case 314870399: return bem_preClassGet_0();
case 962411903: return bem_once_0();
case 74866668: return bem_sourceFileNameGet_0();
case 1619122069: return bem_many_0();
case -730133051: return bem_boolCcGetDirect_0();
case -1338707926: return bem_serializationIteratorGet_0();
case 776546921: return bem_instOfGetDirect_0();
case -962452114: return bem_transGetDirect_0();
case 1967724052: return bem_beginNs_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -848622440: return bem_scvpSet_1(bevd_0);
case -133191531: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -678353707: return bem_nameToIdSet_1(bevd_0);
case -603862489: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -835552974: return bem_copyTo_1(bevd_0);
case 600510966: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -881421554: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -242832602: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 383938142: return bem_randSet_1(bevd_0);
case -986416707: return bem_objectNpSetDirect_1(bevd_0);
case 2003389643: return bem_cnodeSet_1(bevd_0);
case -1223330656: return bem_otherType_1(bevd_0);
case -70929786: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -295188114: return bem_propertyDecsSetDirect_1(bevd_0);
case 655723869: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case 1556692522: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 775953976: return bem_lineCountSet_1(bevd_0);
case -1298103127: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 2048130894: return bem_propertyDecsSet_1(bevd_0);
case 728852975: return bem_callNamesSet_1(bevd_0);
case -402685473: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 18509651: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1243625588: return bem_boolNpSetDirect_1(bevd_0);
case -1566518798: return bem_inFilePathedSet_1(bevd_0);
case 430943746: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -893064357: return bem_returnTypeSet_1(bevd_0);
case -230909436: return bem_nameToIdSetDirect_1(bevd_0);
case 143506185: return bem_methodCatchSetDirect_1(bevd_0);
case 700872996: return bem_dynMethodsSet_1(bevd_0);
case 67859672: return bem_boolNpSet_1(bevd_0);
case 1875619721: return bem_methodCallsSetDirect_1(bevd_0);
case 2084411436: return bem_ccCacheSetDirect_1(bevd_0);
case -393230276: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1756548082: return bem_constSet_1(bevd_0);
case 528547033: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1095826451: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1454070179: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -219378352: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1790530260: return bem_classCallsSetDirect_1(bevd_0);
case -896233878: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 519450018: return bem_nlSet_1(bevd_0);
case -1162737367: return bem_objectCcSetDirect_1(bevd_0);
case 1011228126: return bem_boolCcSetDirect_1(bevd_0);
case -1514639377: return bem_trueValueSet_1(bevd_0);
case -961878280: return bem_randSetDirect_1(bevd_0);
case 1909645261: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -498132904: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -983402451: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1393782296: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -229652500: return bem_libEmitNameSet_1(bevd_0);
case -1058672147: return bem_idToNameSetDirect_1(bevd_0);
case 467975033: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 938556397: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1180987318: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -199170292: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1815010780: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case -2069359040: return bem_intNpSetDirect_1(bevd_0);
case 1214305313: return bem_nlSetDirect_1(bevd_0);
case -872655751: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 2129946727: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1115543857: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 833993877: return bem_instanceEqualSet_1(bevd_0);
case -1764687965: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -2063051392: return bem_methodsSet_1(bevd_0);
case 605355387: return bem_returnTypeSetDirect_1(bevd_0);
case 1764607668: return bem_preClassSetDirect_1(bevd_0);
case 1402246350: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 151392872: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -88315507: return bem_onceDecsSet_1(bevd_0);
case 1189327787: return bem_classEmitsSet_1(bevd_0);
case -171477575: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1566741820: return bem_lineCountSetDirect_1(bevd_0);
case -1307120650: return bem_buildSetDirect_1(bevd_0);
case -3485442: return bem_classesInDepthOrderSet_1(bevd_0);
case -943434174: return bem_methodsSetDirect_1(bevd_0);
case -372719809: return bem_stringNpSet_1(bevd_0);
case -2021050417: return bem_synEmitPathSet_1(bevd_0);
case -1480716370: return bem_superCallsSetDirect_1(bevd_0);
case -3034532: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -686098935: return bem_methodBodySet_1(bevd_0);
case 1777093582: return bem_onceCountSetDirect_1(bevd_0);
case 1363927486: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -1311575130: return bem_maxDynArgsSet_1(bevd_0);
case -1435252515: return bem_inFilePathedSetDirect_1(bevd_0);
case -1873433349: return bem_ntypesSetDirect_1(bevd_0);
case 2100786855: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -30906656: return bem_floatNpSet_1(bevd_0);
case -1650537318: return bem_classEmitsSetDirect_1(bevd_0);
case 116719082: return bem_exceptDecSet_1(bevd_0);
case 968844458: return bem_end_1(bevd_0);
case 1811545286: return bem_instanceEqualSetDirect_1(bevd_0);
case 802974433: return bem_emitLangSetDirect_1(bevd_0);
case -93616498: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -342142001: return bem_superCallsSet_1(bevd_0);
case 1739027974: return bem_lastMethodBodySizeSet_1(bevd_0);
case 413840800: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 2054476670: return bem_csynSet_1(bevd_0);
case 1981758524: return bem_objectNpSet_1(bevd_0);
case 1532256544: return bem_idToNamePathSet_1(bevd_0);
case -902140721: return bem_lastMethodsLinesSet_1(bevd_0);
case 640687763: return bem_mnodeSetDirect_1(bevd_0);
case -568874697: return bem_constSetDirect_1(bevd_0);
case 113386206: return bem_onceCountSet_1(bevd_0);
case 543266905: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -816853467: return bem_smnlecsSet_1(bevd_0);
case 364126550: return bem_preClassSet_1(bevd_0);
case 1488250753: return bem_cnodeSetDirect_1(bevd_0);
case 86085765: return bem_invpSet_1(bevd_0);
case 878043594: return bem_sameObject_1(bevd_0);
case 2017887723: return bem_parentConfSet_1(bevd_0);
case -2031689376: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -498661929: return bem_exceptDecSetDirect_1(bevd_0);
case 1505064313: return bem_instOfSetDirect_1(bevd_0);
case -1021981785: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -1156300778: return bem_falseValueSetDirect_1(bevd_0);
case 1088546670: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -397172874: return bem_libEmitPathSetDirect_1(bevd_0);
case -777326869: return bem_onceDecsSetDirect_1(bevd_0);
case -273189729: return bem_mnodeSet_1(bevd_0);
case -1392606315: return bem_def_1(bevd_0);
case 1994519591: return bem_smnlcsSet_1(bevd_0);
case 103112539: return bem_fileExtSet_1(bevd_0);
case -1632575304: return bem_transSetDirect_1(bevd_0);
case 1087962991: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -566292726: return bem_buildSet_1(bevd_0);
case 2018456352: return bem_qSetDirect_1(bevd_0);
case -534182604: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 739236617: return bem_msynSet_1(bevd_0);
case -1396399745: return bem_nullValueSetDirect_1(bevd_0);
case 100653839: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1094882469: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1094530334: return bem_sameType_1(bevd_0);
case -541077302: return bem_trueValueSetDirect_1(bevd_0);
case 1969338258: return bem_nameToIdPathSetDirect_1(bevd_0);
case -1507486478: return bem_nativeCSlotsSet_1(bevd_0);
case 1237022911: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 813783596: return bem_lastCallSetDirect_1(bevd_0);
case -881210304: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2123859434: return bem_libEmitNameSetDirect_1(bevd_0);
case 177582472: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -557690148: return bem_classCallsSet_1(bevd_0);
case -431322287: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 944707917: return bem_classConfSetDirect_1(bevd_0);
case -1982991868: return bem_classConfSet_1(bevd_0);
case -920462371: return bem_scvpSetDirect_1(bevd_0);
case 1407461773: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1932066645: return bem_fileExtSetDirect_1(bevd_0);
case -1041418370: return bem_parentConfSetDirect_1(bevd_0);
case -1817909577: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1517204704: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1217587157: return bem_ntypesSet_1(bevd_0);
case -744781756: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -1209914110: return bem_intNpSet_1(bevd_0);
case -1436501536: return bem_notEquals_1(bevd_0);
case -221443393: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1568964044: return bem_idToNamePathSetDirect_1(bevd_0);
case 1831908994: return bem_methodCatchSet_1(bevd_0);
case 1658535785: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 43584984: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 122008540: return bem_idToNameSet_1(bevd_0);
case -1238814875: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case -453807332: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1580479930: return bem_ccCacheSet_1(bevd_0);
case -319472911: return bem_msynSetDirect_1(bevd_0);
case 117912615: return bem_defined_1(bevd_0);
case 295848286: return bem_lastMethodsSizeSet_1(bevd_0);
case 2064458327: return bem_instOfSet_1(bevd_0);
case 539644530: return bem_csynSetDirect_1(bevd_0);
case -953104092: return bem_dynMethodsSetDirect_1(bevd_0);
case -598669167: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1189838920: return bem_methodCallsSet_1(bevd_0);
case 2015018939: return bem_begin_1(bevd_0);
case -566160567: return bem_ccMethodsSetDirect_1(bevd_0);
case 251910424: return bem_nameToIdPathSet_1(bevd_0);
case -1452085811: return bem_fullLibEmitNameSet_1(bevd_0);
case -127840806: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 2074367994: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 340014970: return bem_emitLangSet_1(bevd_0);
case -737226396: return bem_qSet_1(bevd_0);
case -523235941: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1900846552: return bem_undef_1(bevd_0);
case -1614752682: return bem_invpSetDirect_1(bevd_0);
case -538835485: return bem_smnlcsSetDirect_1(bevd_0);
case -1737206880: return bem_synEmitPathSetDirect_1(bevd_0);
case 1129103252: return bem_ccMethodsSet_1(bevd_0);
case 1334413639: return bem_inClassSetDirect_1(bevd_0);
case 676938543: return bem_falseValueSet_1(bevd_0);
case 246980644: return bem_instanceNotEqualSet_1(bevd_0);
case 1832561277: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 416523532: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 2036836893: return bem_maxSpillArgsLenSet_1(bevd_0);
case 1970457378: return bem_smnlecsSetDirect_1(bevd_0);
case 600714476: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 362876921: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 312279122: return bem_nullValueSet_1(bevd_0);
case -42235657: return bem_sameClass_1(bevd_0);
case 685763958: return bem_gcMarksSet_1(bevd_0);
case 825331194: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1388286017: return bem_lastCallSet_1(bevd_0);
case -1628724515: return bem_stringNpSetDirect_1(bevd_0);
case -1897220417: return bem_otherClass_1(bevd_0);
case 1264772381: return bem_floatNpSetDirect_1(bevd_0);
case -138933829: return bem_inClassSet_1(bevd_0);
case 1839641475: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 741359884: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -840637258: return bem_objectCcSet_1(bevd_0);
case -359349436: return bem_callNamesSetDirect_1(bevd_0);
case 709586460: return bem_equals_1(bevd_0);
case -79751718: return bem_gcMarksSetDirect_1(bevd_0);
case 1743925765: return bem_libEmitPathSet_1(bevd_0);
case 2112381710: return bem_methodBodySetDirect_1(bevd_0);
case 1564010089: return bem_transSet_1(bevd_0);
case 2140259954: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1169084540: return bem_boolCcSet_1(bevd_0);
case 1314233570: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1718471450: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1268439952: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1098698353: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -410185754: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -34590906: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -51634007: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 341313233: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1305873634: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1622471235: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -391332986: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -967075287: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1720352263: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 982159513: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1119751740: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -1025139592: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1785416818: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1484757297: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 279327090: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -536716735: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 732910394: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -844746747: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -2019434146: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 1515797006: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1139320443: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -658580980: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -306122414: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1958208229: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildSWEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildSWEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildSWEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_inst = (BEC_2_5_9_BuildSWEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildSWEmitter.bece_BEC_2_5_9_BuildSWEmitter_bevs_type;
}
}
}
