namespace be {
/* IO:File: source/build/Pass8.be */
public sealed class BEC_3_5_5_5_BuildVisitPass8 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass8() { }
static BEC_3_5_5_5_BuildVisitPass8() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_24 = {0x67,0x65,0x74,0x5F,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_25 = {0x67,0x65,0x74,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_26 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_27 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_28 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_29 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_30 = {0x3D,0x40};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_31 = {0x3D,0x23};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_32 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
public static new BEC_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;
public BEC_3_5_5_5_BuildVisitPass8 bem_acceptClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_8_BuildEmitData bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_0_tmpany_phold.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepOps_0() {
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_ops = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 20 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_1_tmpany_phold = bevl_i.bemd_1(-905744815, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 20 */ {
bevt_3_tmpany_phold = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(1501770348, bevl_i, bevt_3_tmpany_phold);
bevl_i = bevl_i.bemd_0(-1531231962);
} /* Line: 20 */
 else  /* Line: 20 */ {
break;
} /* Line: 20 */
} /* Line: 20 */
return bevl_ops;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_prec = null;
BEC_2_6_6_SystemObject bevl_cont = null;
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_onode = null;
BEC_2_6_6_SystemObject bevl_mo = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_mt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_3_tmpany_phold.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 30 */ {
bem_acceptClass_1(beva_node);
bevt_5_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpany_phold;
} /* Line: 32 */
bevt_6_tmpany_phold = bevp_const.bem_operGet_0();
bevt_7_tmpany_phold = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_tmpany_phold.bem_get_1(bevt_7_tmpany_phold);
if (bevl_prec == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
 /* Line: 45 */ {
if (bevl_onode == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 45 */ {
if (bevl_prec == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 45 */ {
bevt_12_tmpany_phold = bevl_onode.bemd_0(-511282318);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(-420585939, bevl_cont);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 45 */ {
bevt_13_tmpany_phold = bevl_ops.bemd_1(-694821516, bevl_prec);
bevt_13_tmpany_phold.bemd_1(-1005707696, bevl_onode);
bevl_inode = bevl_onode.bemd_0(454599434);
if (bevl_inode == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevl_inode = bevl_inode.bemd_0(454599434);
if (bevl_inode == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_17_tmpany_phold = bevl_inode.bemd_0(-769176973);
bevt_18_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_1(-420585939, bevt_18_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevl_inode = bevl_inode.bemd_0(454599434);
if (bevl_inode == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevl_inode = bevl_inode.bemd_0(454599434);
} /* Line: 54 */
} /* Line: 53 */
} /* Line: 51 */
} /* Line: 50 */
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_21_tmpany_phold = bevp_const.bem_operGet_0();
bevt_22_tmpany_phold = bevl_onode.bemd_0(-769176973);
bevl_prec = bevt_21_tmpany_phold.bem_get_1(bevt_22_tmpany_phold);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevl_prec = null;
} /* Line: 63 */
} /* Line: 60 */
 else  /* Line: 45 */ {
break;
} /* Line: 45 */
} /* Line: 45 */
bevl_prec = (new BEC_2_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(-537857901);
while (true)
 /* Line: 67 */ {
bevt_23_tmpany_phold = bevl_it.bemd_0(2083701427);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 67 */ {
bevl_i = bevl_it.bemd_0(283546086);
bevt_25_tmpany_phold = bevl_i.bemd_0(-1075192928);
bevt_26_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(-1047999444, bevt_26_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 69 */ {
bevl_mt = bevl_i.bemd_0(-537857901);
while (true)
 /* Line: 70 */ {
bevt_27_tmpany_phold = bevl_mt.bemd_0(2083701427);
if (((BEC_2_5_4_LogicBool) bevt_27_tmpany_phold).bevi_bool) /* Line: 70 */ {
bevl_mo = bevl_mt.bemd_0(283546086);
bevt_28_tmpany_phold = bevl_mo.bemd_0(1444112607);
bevt_29_tmpany_phold = bevl_mo.bemd_0(454599434);
bevl_mo = bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_tmpany_phold, bevt_29_tmpany_phold);
beva_node = (BEC_2_5_4_BuildNode) bevl_mo;
} /* Line: 73 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
} /* Line: 70 */
bevl_prec = bevl_prec.bemd_0(-1531231962);
} /* Line: 76 */
 else  /* Line: 67 */ {
break;
} /* Line: 67 */
} /* Line: 67 */
} /* Line: 67 */
bevt_30_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callFromOper_4(BEC_2_6_6_SystemObject beva_op, BEC_2_6_6_SystemObject beva_prec, BEC_2_6_6_SystemObject beva_pr, BEC_2_6_6_SystemObject beva_nx) {
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1507447015, bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bevp_const.bem_operNamesGet_0();
bevt_6_tmpany_phold = beva_op.bemd_0(-769176973);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_get_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(78018540);
bevl_gc.bemd_1(648097328, bevt_3_tmpany_phold);
bevt_8_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_0));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(-420585939, bevt_9_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 88 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_1));
bevl_gc.bemd_1(648097328, bevt_10_tmpany_phold);
} /* Line: 89 */
bevt_12_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_2));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(-420585939, bevt_13_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_3));
bevl_gc.bemd_1(648097328, bevt_14_tmpany_phold);
} /* Line: 92 */
bevt_16_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_4));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(-420585939, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_5));
bevl_gc.bemd_1(648097328, bevt_18_tmpany_phold);
} /* Line: 95 */
bevt_20_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_6));
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(-420585939, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_19_tmpany_phold).bevi_bool) /* Line: 97 */ {
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_7));
bevl_gc.bemd_1(648097328, bevt_22_tmpany_phold);
} /* Line: 98 */
bevt_24_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_8));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-420585939, bevt_25_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 100 */ {
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_9));
bevl_gc.bemd_1(648097328, bevt_26_tmpany_phold);
} /* Line: 101 */
bevt_28_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_10));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_1(-420585939, bevt_29_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_27_tmpany_phold).bevi_bool) /* Line: 103 */ {
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_11));
bevl_gc.bemd_1(648097328, bevt_30_tmpany_phold);
} /* Line: 104 */
bevt_32_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_12));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(-420585939, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 106 */ {
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_13));
bevl_gc.bemd_1(648097328, bevt_34_tmpany_phold);
} /* Line: 107 */
bevt_36_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_14));
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_1(-420585939, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_35_tmpany_phold).bevi_bool) /* Line: 109 */ {
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_15));
bevl_gc.bemd_1(648097328, bevt_38_tmpany_phold);
} /* Line: 110 */
bevt_40_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_16));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(-420585939, bevt_41_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_39_tmpany_phold).bevi_bool) /* Line: 112 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_17));
bevl_gc.bemd_1(648097328, bevt_42_tmpany_phold);
} /* Line: 113 */
bevt_44_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_18));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_1(-420585939, bevt_45_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_43_tmpany_phold).bevi_bool) /* Line: 115 */ {
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_19));
bevl_gc.bemd_1(648097328, bevt_46_tmpany_phold);
} /* Line: 116 */
bevt_48_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_20));
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_1(-420585939, bevt_49_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 118 */ {
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_21));
bevl_gc.bemd_1(648097328, bevt_50_tmpany_phold);
} /* Line: 119 */
bevt_52_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_22));
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_1(-420585939, bevt_53_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 121 */ {
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_23));
bevl_gc.bemd_1(648097328, bevt_54_tmpany_phold);
} /* Line: 122 */
bevt_56_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_24));
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_1(-420585939, bevt_57_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_55_tmpany_phold).bevi_bool) /* Line: 124 */ {
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_25));
bevl_gc.bemd_1(648097328, bevt_58_tmpany_phold);
} /* Line: 126 */
bevt_60_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_26));
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_1(-420585939, bevt_61_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 128 */ {
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_27));
bevl_gc.bemd_1(648097328, bevt_62_tmpany_phold);
} /* Line: 129 */
bevt_64_tmpany_phold = bevl_gc.bemd_0(-20081513);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_28));
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_1(-420585939, bevt_65_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass8_bels_29));
bevl_gc.bemd_1(648097328, bevt_66_tmpany_phold);
} /* Line: 132 */
bevt_67_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1587788735, bevt_67_tmpany_phold);
bevt_69_tmpany_phold = beva_op.bemd_0(-769176973);
bevt_70_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_1(-420585939, bevt_70_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_68_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevt_72_tmpany_phold = beva_op.bemd_0(643127393);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_5_BuildVisitPass8_bels_30));
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_1(-420585939, bevt_73_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_71_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 136 */
 else  /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 136 */ {
bevt_74_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1912134644, bevt_74_tmpany_phold);
} /* Line: 138 */
bevt_76_tmpany_phold = beva_op.bemd_0(-769176973);
bevt_77_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bemd_1(-420585939, bevt_77_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_75_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevt_79_tmpany_phold = beva_op.bemd_0(643127393);
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_5_BuildVisitPass8_bels_31));
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_1(-420585939, bevt_80_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_78_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 140 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 140 */
 else  /* Line: 140 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 140 */ {
bevt_81_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(640018644, bevt_81_tmpany_phold);
} /* Line: 142 */
bevt_83_tmpany_phold = beva_op.bemd_0(-769176973);
bevt_84_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(-420585939, bevt_84_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 144 */ {
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_32));
bevp_build.bem_buildLiteral_2(beva_nx, bevt_85_tmpany_phold);
} /* Line: 145 */
bevt_86_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(-2088718715, bevt_86_tmpany_phold);
beva_op.bemd_1(-1334163881, bevl_gc);
beva_pr.bemd_0(785054256);
beva_op.bemd_1(-1005707696, beva_pr);
bevt_88_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_87_tmpany_phold = beva_prec.bemd_1(-1047999444, bevt_88_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_87_tmpany_phold).bevi_bool) /* Line: 151 */ {
beva_nx.bemd_0(785054256);
beva_op.bemd_1(-1005707696, beva_nx);
} /* Line: 153 */
return beva_op;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 15, 19, 19, 20, 20, 20, 21, 21, 20, 23, 30, 30, 30, 30, 31, 32, 32, 34, 34, 34, 35, 35, 40, 41, 42, 44, 45, 45, 45, 45, 0, 0, 0, 45, 45, 0, 0, 0, 46, 46, 47, 48, 48, 49, 50, 50, 51, 51, 51, 52, 53, 53, 54, 59, 60, 60, 61, 61, 61, 63, 66, 67, 67, 68, 69, 69, 69, 70, 70, 71, 72, 72, 72, 73, 76, 81, 81, 85, 86, 86, 87, 87, 87, 87, 87, 88, 88, 88, 89, 89, 91, 91, 91, 92, 92, 94, 94, 94, 95, 95, 97, 97, 97, 98, 98, 100, 100, 100, 101, 101, 103, 103, 103, 104, 104, 106, 106, 106, 107, 107, 109, 109, 109, 110, 110, 112, 112, 112, 113, 113, 115, 115, 115, 116, 116, 118, 118, 118, 119, 119, 121, 121, 121, 122, 122, 124, 124, 124, 126, 126, 128, 128, 128, 129, 129, 131, 131, 131, 132, 132, 135, 135, 136, 136, 136, 136, 136, 136, 0, 0, 0, 138, 138, 140, 140, 140, 140, 140, 140, 0, 0, 0, 142, 142, 144, 144, 144, 145, 145, 147, 147, 148, 149, 150, 151, 151, 152, 153, 155};
public static new int[] bevs_smnlec
 = new int[] {44, 45, 55, 56, 57, 60, 61, 63, 64, 65, 71, 114, 115, 116, 121, 122, 123, 124, 126, 127, 128, 129, 134, 135, 136, 137, 138, 141, 146, 147, 152, 153, 156, 160, 163, 164, 166, 169, 173, 176, 177, 178, 179, 184, 185, 186, 191, 192, 193, 194, 196, 197, 202, 203, 208, 209, 214, 215, 216, 217, 220, 227, 228, 231, 233, 234, 235, 236, 238, 241, 243, 244, 245, 246, 247, 254, 261, 262, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 367, 368, 370, 371, 372, 374, 375, 377, 378, 379, 381, 382, 384, 385, 386, 388, 389, 391, 392, 393, 395, 396, 398, 399, 400, 402, 403, 405, 406, 407, 409, 410, 412, 413, 414, 416, 417, 419, 420, 421, 423, 424, 426, 427, 428, 430, 431, 433, 434, 435, 437, 438, 440, 441, 442, 444, 445, 447, 448, 449, 451, 452, 454, 455, 456, 458, 459, 461, 462, 463, 465, 466, 468, 469, 470, 471, 472, 474, 475, 476, 478, 481, 485, 488, 489, 491, 492, 493, 495, 496, 497, 499, 502, 506, 509, 510, 512, 513, 514, 516, 517, 519, 520, 521, 522, 523, 524, 525, 527, 528, 530};
/* BEGIN LINEINFO 
assign 1 15 44
emitDataGet 0 15 44
addParsedClass 1 15 45
assign 1 19 55
new 0 19 55
assign 1 19 56
new 1 19 56
assign 1 20 57
new 0 20 57
assign 1 20 60
new 0 20 60
assign 1 20 61
lesser 1 20 61
assign 1 21 63
new 0 21 63
put 2 21 64
assign 1 20 65
increment 0 20 65
return 1 23 71
assign 1 30 114
typenameGet 0 30 114
assign 1 30 115
CLASSGet 0 30 115
assign 1 30 116
equals 1 30 121
acceptClass 1 31 122
assign 1 32 123
nextDescendGet 0 32 123
return 1 32 124
assign 1 34 126
operGet 0 34 126
assign 1 34 127
typenameGet 0 34 127
assign 1 34 128
get 1 34 128
assign 1 35 129
def 1 35 134
assign 1 40 135
containerGet 0 40 135
assign 1 41 136
prepOps 0 41 136
assign 1 42 137
assign 1 44 138
assign 1 45 141
def 1 45 146
assign 1 45 147
def 1 45 152
assign 1 0 153
assign 1 0 156
assign 1 0 160
assign 1 45 163
containerGet 0 45 163
assign 1 45 164
equals 1 45 164
assign 1 0 166
assign 1 0 169
assign 1 0 173
assign 1 46 176
get 1 46 176
addValue 1 46 177
assign 1 47 178
nextPeerGet 0 47 178
assign 1 48 179
def 1 48 184
assign 1 49 185
nextPeerGet 0 49 185
assign 1 50 186
def 1 50 191
assign 1 51 192
typenameGet 0 51 192
assign 1 51 193
COMMAGet 0 51 193
assign 1 51 194
equals 1 51 194
assign 1 52 196
nextPeerGet 0 52 196
assign 1 53 197
def 1 53 202
assign 1 54 203
nextPeerGet 0 54 203
assign 1 59 208
assign 1 60 209
def 1 60 214
assign 1 61 215
operGet 0 61 215
assign 1 61 216
typenameGet 0 61 216
assign 1 61 217
get 1 61 217
assign 1 63 220
assign 1 66 227
new 0 66 227
assign 1 67 228
iteratorGet 0 67 228
assign 1 67 231
hasNextGet 0 67 231
assign 1 68 233
nextGet 0 68 233
assign 1 69 234
lengthGet 0 69 234
assign 1 69 235
new 0 69 235
assign 1 69 236
greater 1 69 236
assign 1 70 238
iteratorGet 0 70 238
assign 1 70 241
hasNextGet 0 70 241
assign 1 71 243
nextGet 0 71 243
assign 1 72 244
priorPeerGet 0 72 244
assign 1 72 245
nextPeerGet 0 72 245
assign 1 72 246
callFromOper 4 72 246
assign 1 73 247
assign 1 76 254
increment 0 76 254
assign 1 81 261
nextDescendGet 0 81 261
return 1 81 262
assign 1 85 355
new 0 85 355
assign 1 86 356
new 0 86 356
wasOperSet 1 86 357
assign 1 87 358
operNamesGet 0 87 358
assign 1 87 359
typenameGet 0 87 359
assign 1 87 360
get 1 87 360
assign 1 87 361
lower 0 87 361
nameSet 1 87 362
assign 1 88 363
nameGet 0 88 363
assign 1 88 364
new 0 88 364
assign 1 88 365
equals 1 88 365
assign 1 89 367
new 0 89 367
nameSet 1 89 368
assign 1 91 370
nameGet 0 91 370
assign 1 91 371
new 0 91 371
assign 1 91 372
equals 1 91 372
assign 1 92 374
new 0 92 374
nameSet 1 92 375
assign 1 94 377
nameGet 0 94 377
assign 1 94 378
new 0 94 378
assign 1 94 379
equals 1 94 379
assign 1 95 381
new 0 95 381
nameSet 1 95 382
assign 1 97 384
nameGet 0 97 384
assign 1 97 385
new 0 97 385
assign 1 97 386
equals 1 97 386
assign 1 98 388
new 0 98 388
nameSet 1 98 389
assign 1 100 391
nameGet 0 100 391
assign 1 100 392
new 0 100 392
assign 1 100 393
equals 1 100 393
assign 1 101 395
new 0 101 395
nameSet 1 101 396
assign 1 103 398
nameGet 0 103 398
assign 1 103 399
new 0 103 399
assign 1 103 400
equals 1 103 400
assign 1 104 402
new 0 104 402
nameSet 1 104 403
assign 1 106 405
nameGet 0 106 405
assign 1 106 406
new 0 106 406
assign 1 106 407
equals 1 106 407
assign 1 107 409
new 0 107 409
nameSet 1 107 410
assign 1 109 412
nameGet 0 109 412
assign 1 109 413
new 0 109 413
assign 1 109 414
equals 1 109 414
assign 1 110 416
new 0 110 416
nameSet 1 110 417
assign 1 112 419
nameGet 0 112 419
assign 1 112 420
new 0 112 420
assign 1 112 421
equals 1 112 421
assign 1 113 423
new 0 113 423
nameSet 1 113 424
assign 1 115 426
nameGet 0 115 426
assign 1 115 427
new 0 115 427
assign 1 115 428
equals 1 115 428
assign 1 116 430
new 0 116 430
nameSet 1 116 431
assign 1 118 433
nameGet 0 118 433
assign 1 118 434
new 0 118 434
assign 1 118 435
equals 1 118 435
assign 1 119 437
new 0 119 437
nameSet 1 119 438
assign 1 121 440
nameGet 0 121 440
assign 1 121 441
new 0 121 441
assign 1 121 442
equals 1 121 442
assign 1 122 444
new 0 122 444
nameSet 1 122 445
assign 1 124 447
nameGet 0 124 447
assign 1 124 448
new 0 124 448
assign 1 124 449
equals 1 124 449
assign 1 126 451
new 0 126 451
nameSet 1 126 452
assign 1 128 454
nameGet 0 128 454
assign 1 128 455
new 0 128 455
assign 1 128 456
equals 1 128 456
assign 1 129 458
new 0 129 458
nameSet 1 129 459
assign 1 131 461
nameGet 0 131 461
assign 1 131 462
new 0 131 462
assign 1 131 463
equals 1 131 463
assign 1 132 465
new 0 132 465
nameSet 1 132 466
assign 1 135 468
new 0 135 468
wasBoundSet 1 135 469
assign 1 136 470
typenameGet 0 136 470
assign 1 136 471
ASSIGNGet 0 136 471
assign 1 136 472
equals 1 136 472
assign 1 136 474
heldGet 0 136 474
assign 1 136 475
new 0 136 475
assign 1 136 476
equals 1 136 476
assign 1 0 478
assign 1 0 481
assign 1 0 485
assign 1 138 488
new 0 138 488
isOnceSet 1 138 489
assign 1 140 491
typenameGet 0 140 491
assign 1 140 492
ASSIGNGet 0 140 492
assign 1 140 493
equals 1 140 493
assign 1 140 495
heldGet 0 140 495
assign 1 140 496
new 0 140 496
assign 1 140 497
equals 1 140 497
assign 1 0 499
assign 1 0 502
assign 1 0 506
assign 1 142 509
new 0 142 509
isManySet 1 142 510
assign 1 144 512
typenameGet 0 144 512
assign 1 144 513
GET_METHODGet 0 144 513
assign 1 144 514
equals 1 144 514
assign 1 145 516
new 0 145 516
buildLiteral 2 145 517
assign 1 147 519
CALLGet 0 147 519
typenameSet 1 147 520
heldSet 1 148 521
delete 0 149 522
addValue 1 150 523
assign 1 151 524
new 0 151 524
assign 1 151 525
greater 1 151 525
delete 0 152 527
addValue 1 153 528
return 1 155 530
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -125946934: return bem_serializeContents_0();
case -173186399: return bem_toAny_0();
case 402152236: return bem_prepOps_0();
case -2129255989: return bem_hashGet_0();
case -109602708: return bem_toString_0();
case 99641680: return bem_sourceFileNameGet_0();
case 34035866: return bem_classNameGet_0();
case -2089907154: return bem_create_0();
case -498367570: return bem_ntypesGet_0();
case -326152805: return bem_copy_0();
case -1556753014: return bem_buildGet_0();
case -2046784533: return bem_echo_0();
case 717158289: return bem_fieldIteratorGet_0();
case -2049991627: return bem_once_0();
case 2048361265: return bem_many_0();
case -1653307562: return bem_serializationIteratorGet_0();
case 2036051133: return bem_tagGet_0();
case 1973131926: return bem_serializeToString_0();
case 648165913: return bem_print_0();
case 432735873: return bem_deserializeClassNameGet_0();
case -91772231: return bem_constGet_0();
case -2106654919: return bem_transGet_0();
case -537857901: return bem_iteratorGet_0();
case 814639632: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1091318965: return bem_defined_1(bevd_0);
case -1587074662: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 991182700: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1342415374: return bem_constSet_1(bevd_0);
case -1393267925: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 549239575: return bem_otherType_1(bevd_0);
case 755365358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 484096285: return bem_acceptClass_1(bevd_0);
case -143017218: return bem_copyTo_1(bevd_0);
case -420585939: return bem_equals_1(bevd_0);
case -169401475: return bem_otherClass_1(bevd_0);
case 569199667: return bem_undefined_1(bevd_0);
case 1492255674: return bem_def_1(bevd_0);
case -1957594462: return bem_ntypesSet_1(bevd_0);
case -1038696049: return bem_transSet_1(bevd_0);
case 1940516897: return bem_sameClass_1(bevd_0);
case -1369439027: return bem_notEquals_1(bevd_0);
case -1052976456: return bem_begin_1(bevd_0);
case -2031862922: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -491345013: return bem_sameType_1(bevd_0);
case -1634298187: return bem_end_1(bevd_0);
case -1725813495: return bem_buildSet_1(bevd_0);
case -1887120745: return bem_sameObject_1(bevd_0);
case 1290400575: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1008056884: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1151786117: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1422666964: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 466148991: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1823742306: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -50371904: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 967378502: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 327018988: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass8_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass8_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass8();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst = (BEC_3_5_5_5_BuildVisitPass8) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;
}
}
}
