namespace be {
/* IO:File: source/build/Pass8.be */
public sealed class BEC_3_5_5_5_BuildVisitPass8 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass8() { }
static BEC_3_5_5_5_BuildVisitPass8() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_24 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_25 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_26 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_27 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
public static new BEC_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;

public BEC_3_5_5_5_BuildVisitPass8 bem_acceptClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_8_BuildEmitData bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_emitDataGet_0();
bevt_0_ta_ph.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepOps_0() {
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_3_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_ops = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 19*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = bevl_i.bemd_1(119748808, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 19*/ {
bevt_3_ta_ph = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(-1373042537, bevl_i, bevt_3_ta_ph);
bevl_i = bevl_i.bemd_0(639017651);
} /* Line: 19*/
 else /* Line: 19*/ {
break;
} /* Line: 19*/
} /* Line: 19*/
return bevl_ops;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_prec = null;
BEC_2_6_6_SystemObject bevl_cont = null;
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_onode = null;
BEC_2_6_6_SystemObject bevl_mo = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_mt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_5_4_BuildNode bevt_30_ta_ph = null;
bevt_3_ta_ph = beva_node.bem_typenameGet_0();
bevt_4_ta_ph = bevp_ntypes.bem_CLASSGet_0();
if (bevt_3_ta_ph.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 29*/ {
bem_acceptClass_1(beva_node);
bevt_5_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_5_ta_ph;
} /* Line: 31*/
bevt_6_ta_ph = bevp_const.bem_operGet_0();
bevt_7_ta_ph = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_ta_ph.bem_get_1(bevt_7_ta_ph);
if (bevl_prec == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 34*/ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
/* Line: 44*/ {
if (bevl_onode == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 44*/ {
if (bevl_prec == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_12_ta_ph = bevl_onode.bemd_0(-2102703130);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_1(-575162425, bevl_cont);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 44*/
 else /* Line: 44*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 44*/ {
bevt_13_ta_ph = bevl_ops.bemd_1(517117201, bevl_prec);
bevt_13_ta_ph.bemd_1(-1648734891, bevl_onode);
bevl_inode = bevl_onode.bemd_0(-281201913);
if (bevl_inode == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 47*/ {
bevl_inode = bevl_inode.bemd_0(-281201913);
if (bevl_inode == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 49*/ {
bevt_17_ta_ph = bevl_inode.bemd_0(1755711417);
bevt_18_ta_ph = bevp_ntypes.bem_COMMAGet_0();
bevt_16_ta_ph = bevt_17_ta_ph.bemd_1(-575162425, bevt_18_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_16_ta_ph).bevi_bool)/* Line: 50*/ {
bevl_inode = bevl_inode.bemd_0(-281201913);
if (bevl_inode == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 52*/ {
bevl_inode = bevl_inode.bemd_0(-281201913);
} /* Line: 53*/
} /* Line: 52*/
} /* Line: 50*/
} /* Line: 49*/
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 59*/ {
bevt_21_ta_ph = bevp_const.bem_operGet_0();
bevt_22_ta_ph = bevl_onode.bemd_0(1755711417);
bevl_prec = bevt_21_ta_ph.bem_get_1(bevt_22_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
bevl_prec = null;
} /* Line: 62*/
} /* Line: 59*/
 else /* Line: 44*/ {
break;
} /* Line: 44*/
} /* Line: 44*/
bevl_prec = (new BEC_2_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(-1653939165);
while (true)
/* Line: 66*/ {
bevt_23_ta_ph = bevl_it.bemd_0(-211510432);
if (((BEC_2_5_4_LogicBool) bevt_23_ta_ph).bevi_bool)/* Line: 66*/ {
bevl_i = bevl_it.bemd_0(581391667);
bevt_25_ta_ph = bevl_i.bemd_0(1288269900);
bevt_26_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(1916991214, bevt_26_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 68*/ {
bevl_mt = bevl_i.bemd_0(-1653939165);
while (true)
/* Line: 69*/ {
bevt_27_ta_ph = bevl_mt.bemd_0(-211510432);
if (((BEC_2_5_4_LogicBool) bevt_27_ta_ph).bevi_bool)/* Line: 69*/ {
bevl_mo = bevl_mt.bemd_0(581391667);
bevt_28_ta_ph = bevl_mo.bemd_0(2038272748);
bevt_29_ta_ph = bevl_mo.bemd_0(-281201913);
bevl_mo = bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_ta_ph, bevt_29_ta_ph);
beva_node = (BEC_2_5_4_BuildNode) bevl_mo;
} /* Line: 72*/
 else /* Line: 69*/ {
break;
} /* Line: 69*/
} /* Line: 69*/
} /* Line: 69*/
bevl_prec = bevl_prec.bemd_0(639017651);
} /* Line: 75*/
 else /* Line: 66*/ {
break;
} /* Line: 66*/
} /* Line: 66*/
} /* Line: 66*/
bevt_30_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_30_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callFromOper_4(BEC_2_6_6_SystemObject beva_op, BEC_2_6_6_SystemObject beva_prec, BEC_2_6_6_SystemObject beva_pr, BEC_2_6_6_SystemObject beva_nx) {
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_6_6_SystemObject bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-488132362, bevt_0_ta_ph);
bevt_3_ta_ph = bevp_const.bem_operNamesGet_0();
bevt_4_ta_ph = beva_op.bemd_0(1755711417);
bevt_2_ta_ph = bevt_3_ta_ph.bem_get_1(bevt_4_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1151038820);
bevl_gc.bemd_1(1122223586, bevt_1_ta_ph);
bevt_6_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_0));
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(-575162425, bevt_7_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 87*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_1));
bevl_gc.bemd_1(1122223586, bevt_8_ta_ph);
} /* Line: 88*/
bevt_10_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_2));
bevt_9_ta_ph = bevt_10_ta_ph.bemd_1(-575162425, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_9_ta_ph).bevi_bool)/* Line: 90*/ {
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_3));
bevl_gc.bemd_1(1122223586, bevt_12_ta_ph);
} /* Line: 91*/
bevt_14_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_4));
bevt_13_ta_ph = bevt_14_ta_ph.bemd_1(-575162425, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 93*/ {
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_5));
bevl_gc.bemd_1(1122223586, bevt_16_ta_ph);
} /* Line: 94*/
bevt_18_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_6));
bevt_17_ta_ph = bevt_18_ta_ph.bemd_1(-575162425, bevt_19_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 96*/ {
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_7));
bevl_gc.bemd_1(1122223586, bevt_20_ta_ph);
} /* Line: 97*/
bevt_22_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_8));
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(-575162425, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 99*/ {
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_9));
bevl_gc.bemd_1(1122223586, bevt_24_ta_ph);
} /* Line: 100*/
bevt_26_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_10));
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(-575162425, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 102*/ {
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_11));
bevl_gc.bemd_1(1122223586, bevt_28_ta_ph);
} /* Line: 103*/
bevt_30_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_12));
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(-575162425, bevt_31_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_29_ta_ph).bevi_bool)/* Line: 105*/ {
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_13));
bevl_gc.bemd_1(1122223586, bevt_32_ta_ph);
} /* Line: 106*/
bevt_34_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_14));
bevt_33_ta_ph = bevt_34_ta_ph.bemd_1(-575162425, bevt_35_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 108*/ {
bevt_36_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_15));
bevl_gc.bemd_1(1122223586, bevt_36_ta_ph);
} /* Line: 109*/
bevt_38_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_16));
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(-575162425, bevt_39_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_37_ta_ph).bevi_bool)/* Line: 111*/ {
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_17));
bevl_gc.bemd_1(1122223586, bevt_40_ta_ph);
} /* Line: 112*/
bevt_42_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_18));
bevt_41_ta_ph = bevt_42_ta_ph.bemd_1(-575162425, bevt_43_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_41_ta_ph).bevi_bool)/* Line: 114*/ {
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_19));
bevl_gc.bemd_1(1122223586, bevt_44_ta_ph);
} /* Line: 115*/
bevt_46_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_47_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_20));
bevt_45_ta_ph = bevt_46_ta_ph.bemd_1(-575162425, bevt_47_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_45_ta_ph).bevi_bool)/* Line: 117*/ {
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_21));
bevl_gc.bemd_1(1122223586, bevt_48_ta_ph);
} /* Line: 118*/
bevt_50_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_51_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_22));
bevt_49_ta_ph = bevt_50_ta_ph.bemd_1(-575162425, bevt_51_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_49_ta_ph).bevi_bool)/* Line: 120*/ {
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_23));
bevl_gc.bemd_1(1122223586, bevt_52_ta_ph);
} /* Line: 121*/
bevt_54_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_55_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_24));
bevt_53_ta_ph = bevt_54_ta_ph.bemd_1(-575162425, bevt_55_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 123*/ {
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_25));
bevl_gc.bemd_1(1122223586, bevt_56_ta_ph);
} /* Line: 124*/
bevt_58_ta_ph = bevl_gc.bemd_0(1437514936);
bevt_59_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_26));
bevt_57_ta_ph = bevt_58_ta_ph.bemd_1(-575162425, bevt_59_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_57_ta_ph).bevi_bool)/* Line: 126*/ {
bevt_60_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass8_bels_27));
bevl_gc.bemd_1(1122223586, bevt_60_ta_ph);
} /* Line: 127*/
bevt_61_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(645390874, bevt_61_ta_ph);
bevt_62_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(-1029713057, bevt_62_ta_ph);
beva_op.bemd_1(30618025, bevl_gc);
beva_pr.bemd_0(293247152);
beva_op.bemd_1(-1648734891, beva_pr);
bevt_64_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_63_ta_ph = beva_prec.bemd_1(1916991214, bevt_64_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 135*/ {
beva_nx.bemd_0(293247152);
beva_op.bemd_1(-1648734891, beva_nx);
} /* Line: 137*/
return beva_op;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {14, 14, 18, 18, 19, 19, 19, 20, 20, 19, 22, 29, 29, 29, 29, 30, 31, 31, 33, 33, 33, 34, 34, 39, 40, 41, 43, 44, 44, 44, 44, 0, 0, 0, 44, 44, 0, 0, 0, 45, 45, 46, 47, 47, 48, 49, 49, 50, 50, 50, 51, 52, 52, 53, 58, 59, 59, 60, 60, 60, 62, 65, 66, 66, 67, 68, 68, 68, 69, 69, 70, 71, 71, 71, 72, 75, 80, 80, 84, 85, 85, 86, 86, 86, 86, 86, 87, 87, 87, 88, 88, 90, 90, 90, 91, 91, 93, 93, 93, 94, 94, 96, 96, 96, 97, 97, 99, 99, 99, 100, 100, 102, 102, 102, 103, 103, 105, 105, 105, 106, 106, 108, 108, 108, 109, 109, 111, 111, 111, 112, 112, 114, 114, 114, 115, 115, 117, 117, 117, 118, 118, 120, 120, 120, 121, 121, 123, 123, 123, 124, 124, 126, 126, 126, 127, 127, 130, 130, 131, 131, 132, 133, 134, 135, 135, 136, 137, 139};
public static new int[] bevs_smnlec
 = new int[] {42, 43, 53, 54, 55, 58, 59, 61, 62, 63, 69, 112, 113, 114, 119, 120, 121, 122, 124, 125, 126, 127, 132, 133, 134, 135, 136, 139, 144, 145, 150, 151, 154, 158, 161, 162, 164, 167, 171, 174, 175, 176, 177, 182, 183, 184, 189, 190, 191, 192, 194, 195, 200, 201, 206, 207, 212, 213, 214, 215, 218, 225, 226, 229, 231, 232, 233, 234, 236, 239, 241, 242, 243, 244, 245, 252, 259, 260, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 341, 342, 344, 345, 346, 348, 349, 351, 352, 353, 355, 356, 358, 359, 360, 362, 363, 365, 366, 367, 369, 370, 372, 373, 374, 376, 377, 379, 380, 381, 383, 384, 386, 387, 388, 390, 391, 393, 394, 395, 397, 398, 400, 401, 402, 404, 405, 407, 408, 409, 411, 412, 414, 415, 416, 418, 419, 421, 422, 423, 425, 426, 428, 429, 430, 432, 433, 435, 436, 437, 438, 439, 440, 441, 442, 443, 445, 446, 448};
/* BEGIN LINEINFO 
assign 1 14 42
emitDataGet 0 14 42
addParsedClass 1 14 43
assign 1 18 53
new 0 18 53
assign 1 18 54
new 1 18 54
assign 1 19 55
new 0 19 55
assign 1 19 58
new 0 19 58
assign 1 19 59
lesser 1 19 59
assign 1 20 61
new 0 20 61
put 2 20 62
assign 1 19 63
increment 0 19 63
return 1 22 69
assign 1 29 112
typenameGet 0 29 112
assign 1 29 113
CLASSGet 0 29 113
assign 1 29 114
equals 1 29 119
acceptClass 1 30 120
assign 1 31 121
nextDescendGet 0 31 121
return 1 31 122
assign 1 33 124
operGet 0 33 124
assign 1 33 125
typenameGet 0 33 125
assign 1 33 126
get 1 33 126
assign 1 34 127
def 1 34 132
assign 1 39 133
containerGet 0 39 133
assign 1 40 134
prepOps 0 40 134
assign 1 41 135
assign 1 43 136
assign 1 44 139
def 1 44 144
assign 1 44 145
def 1 44 150
assign 1 0 151
assign 1 0 154
assign 1 0 158
assign 1 44 161
containerGet 0 44 161
assign 1 44 162
equals 1 44 162
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 45 174
get 1 45 174
addValue 1 45 175
assign 1 46 176
nextPeerGet 0 46 176
assign 1 47 177
def 1 47 182
assign 1 48 183
nextPeerGet 0 48 183
assign 1 49 184
def 1 49 189
assign 1 50 190
typenameGet 0 50 190
assign 1 50 191
COMMAGet 0 50 191
assign 1 50 192
equals 1 50 192
assign 1 51 194
nextPeerGet 0 51 194
assign 1 52 195
def 1 52 200
assign 1 53 201
nextPeerGet 0 53 201
assign 1 58 206
assign 1 59 207
def 1 59 212
assign 1 60 213
operGet 0 60 213
assign 1 60 214
typenameGet 0 60 214
assign 1 60 215
get 1 60 215
assign 1 62 218
assign 1 65 225
new 0 65 225
assign 1 66 226
iteratorGet 0 66 226
assign 1 66 229
hasNextGet 0 66 229
assign 1 67 231
nextGet 0 67 231
assign 1 68 232
lengthGet 0 68 232
assign 1 68 233
new 0 68 233
assign 1 68 234
greater 1 68 234
assign 1 69 236
iteratorGet 0 69 236
assign 1 69 239
hasNextGet 0 69 239
assign 1 70 241
nextGet 0 70 241
assign 1 71 242
priorPeerGet 0 71 242
assign 1 71 243
nextPeerGet 0 71 243
assign 1 71 244
callFromOper 4 71 244
assign 1 72 245
assign 1 75 252
increment 0 75 252
assign 1 80 259
nextDescendGet 0 80 259
return 1 80 260
assign 1 84 329
new 0 84 329
assign 1 85 330
new 0 85 330
wasOperSet 1 85 331
assign 1 86 332
operNamesGet 0 86 332
assign 1 86 333
typenameGet 0 86 333
assign 1 86 334
get 1 86 334
assign 1 86 335
lower 0 86 335
nameSet 1 86 336
assign 1 87 337
nameGet 0 87 337
assign 1 87 338
new 0 87 338
assign 1 87 339
equals 1 87 339
assign 1 88 341
new 0 88 341
nameSet 1 88 342
assign 1 90 344
nameGet 0 90 344
assign 1 90 345
new 0 90 345
assign 1 90 346
equals 1 90 346
assign 1 91 348
new 0 91 348
nameSet 1 91 349
assign 1 93 351
nameGet 0 93 351
assign 1 93 352
new 0 93 352
assign 1 93 353
equals 1 93 353
assign 1 94 355
new 0 94 355
nameSet 1 94 356
assign 1 96 358
nameGet 0 96 358
assign 1 96 359
new 0 96 359
assign 1 96 360
equals 1 96 360
assign 1 97 362
new 0 97 362
nameSet 1 97 363
assign 1 99 365
nameGet 0 99 365
assign 1 99 366
new 0 99 366
assign 1 99 367
equals 1 99 367
assign 1 100 369
new 0 100 369
nameSet 1 100 370
assign 1 102 372
nameGet 0 102 372
assign 1 102 373
new 0 102 373
assign 1 102 374
equals 1 102 374
assign 1 103 376
new 0 103 376
nameSet 1 103 377
assign 1 105 379
nameGet 0 105 379
assign 1 105 380
new 0 105 380
assign 1 105 381
equals 1 105 381
assign 1 106 383
new 0 106 383
nameSet 1 106 384
assign 1 108 386
nameGet 0 108 386
assign 1 108 387
new 0 108 387
assign 1 108 388
equals 1 108 388
assign 1 109 390
new 0 109 390
nameSet 1 109 391
assign 1 111 393
nameGet 0 111 393
assign 1 111 394
new 0 111 394
assign 1 111 395
equals 1 111 395
assign 1 112 397
new 0 112 397
nameSet 1 112 398
assign 1 114 400
nameGet 0 114 400
assign 1 114 401
new 0 114 401
assign 1 114 402
equals 1 114 402
assign 1 115 404
new 0 115 404
nameSet 1 115 405
assign 1 117 407
nameGet 0 117 407
assign 1 117 408
new 0 117 408
assign 1 117 409
equals 1 117 409
assign 1 118 411
new 0 118 411
nameSet 1 118 412
assign 1 120 414
nameGet 0 120 414
assign 1 120 415
new 0 120 415
assign 1 120 416
equals 1 120 416
assign 1 121 418
new 0 121 418
nameSet 1 121 419
assign 1 123 421
nameGet 0 123 421
assign 1 123 422
new 0 123 422
assign 1 123 423
equals 1 123 423
assign 1 124 425
new 0 124 425
nameSet 1 124 426
assign 1 126 428
nameGet 0 126 428
assign 1 126 429
new 0 126 429
assign 1 126 430
equals 1 126 430
assign 1 127 432
new 0 127 432
nameSet 1 127 433
assign 1 130 435
new 0 130 435
wasBoundSet 1 130 436
assign 1 131 437
CALLGet 0 131 437
typenameSet 1 131 438
heldSet 1 132 439
delete 0 133 440
addValue 1 134 441
assign 1 135 442
new 0 135 442
assign 1 135 443
greater 1 135 443
delete 0 136 445
addValue 1 137 446
return 1 139 448
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1931705863: return bem_sourceFileNameGet_0();
case -893093197: return bem_toString_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case -606522170: return bem_transGetDirect_0();
case 954703233: return bem_create_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1834246217: return bem_classNameGet_0();
case -458218411: return bem_constGet_0();
case -574574637: return bem_transGet_0();
case -193582610: return bem_tagGet_0();
case -975498393: return bem_fieldNamesGet_0();
case 1910033340: return bem_buildGet_0();
case 58217918: return bem_ntypesGet_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case 876676878: return bem_ntypesGetDirect_0();
case -1473471919: return bem_prepOps_0();
case 1232394224: return bem_buildGetDirect_0();
case 88195190: return bem_constGetDirect_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 177409367: return bem_otherType_1(bevd_0);
case -996640729: return bem_buildSet_1(bevd_0);
case 1322219409: return bem_acceptClass_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1865062933: return bem_buildSetDirect_1(bevd_0);
case 537433000: return bem_end_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 2011490434: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -669415086: return bem_constSet_1(bevd_0);
case -631003549: return bem_begin_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 215907131: return bem_transSet_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -1537135787: return bem_ntypesSet_1(bevd_0);
case 1819306118: return bem_constSetDirect_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -2042501127: return bem_ntypesSetDirect_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 1736101817: return bem_transSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1835876388: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass8_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass8_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass8();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst = (BEC_3_5_5_5_BuildVisitPass8) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;
}
}
}
