namespace be {
/* IO:File: source/build/Pass8.be */
public sealed class BEC_3_5_5_5_BuildVisitPass8 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass8() { }
static BEC_3_5_5_5_BuildVisitPass8() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x38};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass8_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x38,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_0 = {0x6E,0x6F,0x74,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_1 = {0x6E,0x6F,0x74,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_2 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_3 = {0x6C,0x65,0x73,0x73,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_4 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x5F,0x65,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_5 = {0x67,0x72,0x65,0x61,0x74,0x65,0x72,0x45,0x71,0x75,0x61,0x6C,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_6 = {0x61,0x64,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_7 = {0x61,0x64,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_8 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_9 = {0x73,0x75,0x62,0x74,0x72,0x61,0x63,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_10 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_11 = {0x69,0x6E,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_12 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_13 = {0x64,0x65,0x63,0x72,0x65,0x6D,0x65,0x6E,0x74,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_14 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_15 = {0x6D,0x75,0x6C,0x74,0x69,0x70,0x6C,0x79,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_16 = {0x64,0x69,0x76,0x69,0x64,0x65,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_17 = {0x64,0x69,0x76,0x69,0x64,0x65,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_18 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_19 = {0x6D,0x6F,0x64,0x75,0x6C,0x75,0x73,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_20 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x61,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_21 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x41,0x6E,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_22 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x5F,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_23 = {0x6C,0x6F,0x67,0x69,0x63,0x61,0x6C,0x4F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_24 = {0x67,0x65,0x74,0x5F,0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_25 = {0x67,0x65,0x74,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_26 = {0x61,0x6E,0x64,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_27 = {0x61,0x6E,0x64,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_28 = {0x6F,0x72,0x5F,0x76,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_29 = {0x6F,0x72,0x56,0x61,0x6C,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_30 = {0x3D,0x40};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_31 = {0x3D,0x23};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass8_bels_32 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
public static new BEC_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass8 bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;

public BEC_3_5_5_5_BuildVisitPass8 bem_acceptClass_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_8_BuildEmitData bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_0_tmpany_phold.bem_addParsedClass_1(beva_node);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_prepOps_0() {
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_ops = (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 20 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_1_tmpany_phold = bevl_i.bemd_1(-832969151, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 20 */ {
bevt_3_tmpany_phold = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_ops.bemd_2(-1566202298, bevl_i, bevt_3_tmpany_phold);
bevl_i = bevl_i.bemd_0(2017555316);
} /* Line: 20 */
 else  /* Line: 20 */ {
break;
} /* Line: 20 */
} /* Line: 20 */
return bevl_ops;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_6_6_SystemObject bevl_prec = null;
BEC_2_6_6_SystemObject bevl_cont = null;
BEC_2_6_6_SystemObject bevl_ops = null;
BEC_2_6_6_SystemObject bevl_onode = null;
BEC_2_6_6_SystemObject bevl_mo = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_mt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
bevt_3_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_4_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_3_tmpany_phold.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 30 */ {
bem_acceptClass_1(beva_node);
bevt_5_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_5_tmpany_phold;
} /* Line: 32 */
bevt_6_tmpany_phold = bevp_const.bem_operGet_0();
bevt_7_tmpany_phold = beva_node.bem_typenameGet_0();
bevl_prec = bevt_6_tmpany_phold.bem_get_1(bevt_7_tmpany_phold);
if (bevl_prec == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 35 */ {
bevl_cont = beva_node.bem_containerGet_0();
bevl_ops = bem_prepOps_0();
bevl_onode = beva_node;
beva_node = null;
while (true)
 /* Line: 45 */ {
if (bevl_onode == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 45 */ {
if (bevl_prec == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 45 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 45 */ {
bevt_12_tmpany_phold = bevl_onode.bemd_0(-258580511);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(506068861, bevl_cont);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 45 */
 else  /* Line: 45 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 45 */ {
bevt_13_tmpany_phold = bevl_ops.bemd_1(-686021029, bevl_prec);
bevt_13_tmpany_phold.bemd_1(1380835473, bevl_onode);
bevl_inode = bevl_onode.bemd_0(-432564249);
if (bevl_inode == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevl_inode = bevl_inode.bemd_0(-432564249);
if (bevl_inode == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_17_tmpany_phold = bevl_inode.bemd_0(-63115513);
bevt_18_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_1(506068861, bevt_18_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevl_inode = bevl_inode.bemd_0(-432564249);
if (bevl_inode == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevl_inode = bevl_inode.bemd_0(-432564249);
} /* Line: 54 */
} /* Line: 53 */
} /* Line: 51 */
} /* Line: 50 */
bevl_onode = bevl_inode;
if (bevl_onode == null) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_21_tmpany_phold = bevp_const.bem_operGet_0();
bevt_22_tmpany_phold = bevl_onode.bemd_0(-63115513);
bevl_prec = bevt_21_tmpany_phold.bem_get_1(bevt_22_tmpany_phold);
} /* Line: 61 */
 else  /* Line: 62 */ {
bevl_prec = null;
} /* Line: 63 */
} /* Line: 60 */
 else  /* Line: 45 */ {
break;
} /* Line: 45 */
} /* Line: 45 */
bevl_prec = (new BEC_2_4_3_MathInt(0));
bevl_it = bevl_ops.bemd_0(-1554789119);
while (true)
 /* Line: 67 */ {
bevt_23_tmpany_phold = bevl_it.bemd_0(-1203212053);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 67 */ {
bevl_i = bevl_it.bemd_0(-1925596472);
bevt_25_tmpany_phold = bevl_i.bemd_0(-1127822594);
bevt_26_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_1(-1244641607, bevt_26_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 69 */ {
bevl_mt = bevl_i.bemd_0(-1554789119);
while (true)
 /* Line: 70 */ {
bevt_27_tmpany_phold = bevl_mt.bemd_0(-1203212053);
if (((BEC_2_5_4_LogicBool) bevt_27_tmpany_phold).bevi_bool) /* Line: 70 */ {
bevl_mo = bevl_mt.bemd_0(-1925596472);
bevt_28_tmpany_phold = bevl_mo.bemd_0(1380318408);
bevt_29_tmpany_phold = bevl_mo.bemd_0(-432564249);
bevl_mo = bem_callFromOper_4(bevl_mo, bevl_prec, bevt_28_tmpany_phold, bevt_29_tmpany_phold);
beva_node = (BEC_2_5_4_BuildNode) bevl_mo;
} /* Line: 73 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
} /* Line: 70 */
bevl_prec = bevl_prec.bemd_0(2017555316);
} /* Line: 76 */
 else  /* Line: 67 */ {
break;
} /* Line: 67 */
} /* Line: 67 */
} /* Line: 67 */
bevt_30_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callFromOper_4(BEC_2_6_6_SystemObject beva_op, BEC_2_6_6_SystemObject beva_prec, BEC_2_6_6_SystemObject beva_pr, BEC_2_6_6_SystemObject beva_nx) {
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-1619240921, bevt_2_tmpany_phold);
bevt_5_tmpany_phold = bevp_const.bem_operNamesGet_0();
bevt_6_tmpany_phold = beva_op.bemd_0(-63115513);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_get_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1934731982);
bevl_gc.bemd_1(1400380236, bevt_3_tmpany_phold);
bevt_8_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_0));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(506068861, bevt_9_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 88 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_1));
bevl_gc.bemd_1(1400380236, bevt_10_tmpany_phold);
} /* Line: 89 */
bevt_12_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_2));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(506068861, bevt_13_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_3));
bevl_gc.bemd_1(1400380236, bevt_14_tmpany_phold);
} /* Line: 92 */
bevt_16_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_4));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(506068861, bevt_17_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 94 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_5));
bevl_gc.bemd_1(1400380236, bevt_18_tmpany_phold);
} /* Line: 95 */
bevt_20_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_6));
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_1(506068861, bevt_21_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_19_tmpany_phold).bevi_bool) /* Line: 97 */ {
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_7));
bevl_gc.bemd_1(1400380236, bevt_22_tmpany_phold);
} /* Line: 98 */
bevt_24_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_8));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(506068861, bevt_25_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_23_tmpany_phold).bevi_bool) /* Line: 100 */ {
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_9));
bevl_gc.bemd_1(1400380236, bevt_26_tmpany_phold);
} /* Line: 101 */
bevt_28_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_10));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_1(506068861, bevt_29_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_27_tmpany_phold).bevi_bool) /* Line: 103 */ {
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_11));
bevl_gc.bemd_1(1400380236, bevt_30_tmpany_phold);
} /* Line: 104 */
bevt_32_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_3_5_5_5_BuildVisitPass8_bels_12));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(506068861, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 106 */ {
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_13));
bevl_gc.bemd_1(1400380236, bevt_34_tmpany_phold);
} /* Line: 107 */
bevt_36_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_3_5_5_5_BuildVisitPass8_bels_14));
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_1(506068861, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_35_tmpany_phold).bevi_bool) /* Line: 109 */ {
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_15));
bevl_gc.bemd_1(1400380236, bevt_38_tmpany_phold);
} /* Line: 110 */
bevt_40_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_16));
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_1(506068861, bevt_41_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_39_tmpany_phold).bevi_bool) /* Line: 112 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_17));
bevl_gc.bemd_1(1400380236, bevt_42_tmpany_phold);
} /* Line: 113 */
bevt_44_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_3_5_5_5_BuildVisitPass8_bels_18));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bemd_1(506068861, bevt_45_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_43_tmpany_phold).bevi_bool) /* Line: 115 */ {
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_3_5_5_5_BuildVisitPass8_bels_19));
bevl_gc.bemd_1(1400380236, bevt_46_tmpany_phold);
} /* Line: 116 */
bevt_48_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_20));
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bemd_1(506068861, bevt_49_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_47_tmpany_phold).bevi_bool) /* Line: 118 */ {
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_21));
bevl_gc.bemd_1(1400380236, bevt_50_tmpany_phold);
} /* Line: 119 */
bevt_52_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_22));
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_1(506068861, bevt_53_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 121 */ {
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_23));
bevl_gc.bemd_1(1400380236, bevt_54_tmpany_phold);
} /* Line: 122 */
bevt_56_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass8_bels_24));
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bemd_1(506068861, bevt_57_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_55_tmpany_phold).bevi_bool) /* Line: 124 */ {
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_25));
bevl_gc.bemd_1(1400380236, bevt_58_tmpany_phold);
} /* Line: 126 */
bevt_60_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_3_5_5_5_BuildVisitPass8_bels_26));
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_1(506068861, bevt_61_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 128 */ {
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_27));
bevl_gc.bemd_1(1400380236, bevt_62_tmpany_phold);
} /* Line: 129 */
bevt_64_tmpany_phold = bevl_gc.bemd_0(-2034918263);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass8_bels_28));
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_1(506068861, bevt_65_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_3_5_5_5_BuildVisitPass8_bels_29));
bevl_gc.bemd_1(1400380236, bevt_66_tmpany_phold);
} /* Line: 132 */
bevt_67_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-1912741706, bevt_67_tmpany_phold);
bevt_69_tmpany_phold = beva_op.bemd_0(-63115513);
bevt_70_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bemd_1(506068861, bevt_70_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_68_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevt_72_tmpany_phold = beva_op.bemd_0(-341587645);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_5_BuildVisitPass8_bels_30));
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_1(506068861, bevt_73_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_71_tmpany_phold).bevi_bool) /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 136 */
 else  /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 136 */ {
bevt_74_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1197233576, bevt_74_tmpany_phold);
} /* Line: 138 */
bevt_76_tmpany_phold = beva_op.bemd_0(-63115513);
bevt_77_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_75_tmpany_phold = bevt_76_tmpany_phold.bemd_1(506068861, bevt_77_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_75_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevt_79_tmpany_phold = beva_op.bemd_0(-341587645);
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_3_5_5_5_BuildVisitPass8_bels_31));
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_1(506068861, bevt_80_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_78_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 140 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 140 */
 else  /* Line: 140 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 140 */ {
bevt_81_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(-58052666, bevt_81_tmpany_phold);
} /* Line: 142 */
bevt_83_tmpany_phold = beva_op.bemd_0(-63115513);
bevt_84_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(506068861, bevt_84_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 144 */ {
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass8_bels_32));
bevp_build.bem_buildLiteral_2(beva_nx, bevt_85_tmpany_phold);
} /* Line: 145 */
bevt_86_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_op.bemd_1(-1350221590, bevt_86_tmpany_phold);
beva_op.bemd_1(-574949036, bevl_gc);
beva_pr.bemd_0(-1809164609);
beva_op.bemd_1(1380835473, beva_pr);
bevt_88_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_87_tmpany_phold = beva_prec.bemd_1(-1244641607, bevt_88_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_87_tmpany_phold).bevi_bool) /* Line: 151 */ {
beva_nx.bemd_0(-1809164609);
beva_op.bemd_1(1380835473, beva_nx);
} /* Line: 153 */
return beva_op;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 15, 19, 19, 20, 20, 20, 21, 21, 20, 23, 30, 30, 30, 30, 31, 32, 32, 34, 34, 34, 35, 35, 40, 41, 42, 44, 45, 45, 45, 45, 0, 0, 0, 45, 45, 0, 0, 0, 46, 46, 47, 48, 48, 49, 50, 50, 51, 51, 51, 52, 53, 53, 54, 59, 60, 60, 61, 61, 61, 63, 66, 67, 67, 68, 69, 69, 69, 70, 70, 71, 72, 72, 72, 73, 76, 81, 81, 85, 86, 86, 87, 87, 87, 87, 87, 88, 88, 88, 89, 89, 91, 91, 91, 92, 92, 94, 94, 94, 95, 95, 97, 97, 97, 98, 98, 100, 100, 100, 101, 101, 103, 103, 103, 104, 104, 106, 106, 106, 107, 107, 109, 109, 109, 110, 110, 112, 112, 112, 113, 113, 115, 115, 115, 116, 116, 118, 118, 118, 119, 119, 121, 121, 121, 122, 122, 124, 124, 124, 126, 126, 128, 128, 128, 129, 129, 131, 131, 131, 132, 132, 135, 135, 136, 136, 136, 136, 136, 136, 0, 0, 0, 138, 138, 140, 140, 140, 140, 140, 140, 0, 0, 0, 142, 142, 144, 144, 144, 145, 145, 147, 147, 148, 149, 150, 151, 151, 152, 153, 155};
public static new int[] bevs_smnlec
 = new int[] {47, 48, 58, 59, 60, 63, 64, 66, 67, 68, 74, 117, 118, 119, 124, 125, 126, 127, 129, 130, 131, 132, 137, 138, 139, 140, 141, 144, 149, 150, 155, 156, 159, 163, 166, 167, 169, 172, 176, 179, 180, 181, 182, 187, 188, 189, 194, 195, 196, 197, 199, 200, 205, 206, 211, 212, 217, 218, 219, 220, 223, 230, 231, 234, 236, 237, 238, 239, 241, 244, 246, 247, 248, 249, 250, 257, 264, 265, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 370, 371, 373, 374, 375, 377, 378, 380, 381, 382, 384, 385, 387, 388, 389, 391, 392, 394, 395, 396, 398, 399, 401, 402, 403, 405, 406, 408, 409, 410, 412, 413, 415, 416, 417, 419, 420, 422, 423, 424, 426, 427, 429, 430, 431, 433, 434, 436, 437, 438, 440, 441, 443, 444, 445, 447, 448, 450, 451, 452, 454, 455, 457, 458, 459, 461, 462, 464, 465, 466, 468, 469, 471, 472, 473, 474, 475, 477, 478, 479, 481, 484, 488, 491, 492, 494, 495, 496, 498, 499, 500, 502, 505, 509, 512, 513, 515, 516, 517, 519, 520, 522, 523, 524, 525, 526, 527, 528, 530, 531, 533};
/* BEGIN LINEINFO 
assign 1 15 47
emitDataGet 0 15 47
addParsedClass 1 15 48
assign 1 19 58
new 0 19 58
assign 1 19 59
new 1 19 59
assign 1 20 60
new 0 20 60
assign 1 20 63
new 0 20 63
assign 1 20 64
lesser 1 20 64
assign 1 21 66
new 0 21 66
put 2 21 67
assign 1 20 68
increment 0 20 68
return 1 23 74
assign 1 30 117
typenameGet 0 30 117
assign 1 30 118
CLASSGet 0 30 118
assign 1 30 119
equals 1 30 124
acceptClass 1 31 125
assign 1 32 126
nextDescendGet 0 32 126
return 1 32 127
assign 1 34 129
operGet 0 34 129
assign 1 34 130
typenameGet 0 34 130
assign 1 34 131
get 1 34 131
assign 1 35 132
def 1 35 137
assign 1 40 138
containerGet 0 40 138
assign 1 41 139
prepOps 0 41 139
assign 1 42 140
assign 1 44 141
assign 1 45 144
def 1 45 149
assign 1 45 150
def 1 45 155
assign 1 0 156
assign 1 0 159
assign 1 0 163
assign 1 45 166
containerGet 0 45 166
assign 1 45 167
equals 1 45 167
assign 1 0 169
assign 1 0 172
assign 1 0 176
assign 1 46 179
get 1 46 179
addValue 1 46 180
assign 1 47 181
nextPeerGet 0 47 181
assign 1 48 182
def 1 48 187
assign 1 49 188
nextPeerGet 0 49 188
assign 1 50 189
def 1 50 194
assign 1 51 195
typenameGet 0 51 195
assign 1 51 196
COMMAGet 0 51 196
assign 1 51 197
equals 1 51 197
assign 1 52 199
nextPeerGet 0 52 199
assign 1 53 200
def 1 53 205
assign 1 54 206
nextPeerGet 0 54 206
assign 1 59 211
assign 1 60 212
def 1 60 217
assign 1 61 218
operGet 0 61 218
assign 1 61 219
typenameGet 0 61 219
assign 1 61 220
get 1 61 220
assign 1 63 223
assign 1 66 230
new 0 66 230
assign 1 67 231
iteratorGet 0 67 231
assign 1 67 234
hasNextGet 0 67 234
assign 1 68 236
nextGet 0 68 236
assign 1 69 237
lengthGet 0 69 237
assign 1 69 238
new 0 69 238
assign 1 69 239
greater 1 69 239
assign 1 70 241
iteratorGet 0 70 241
assign 1 70 244
hasNextGet 0 70 244
assign 1 71 246
nextGet 0 71 246
assign 1 72 247
priorPeerGet 0 72 247
assign 1 72 248
nextPeerGet 0 72 248
assign 1 72 249
callFromOper 4 72 249
assign 1 73 250
assign 1 76 257
increment 0 76 257
assign 1 81 264
nextDescendGet 0 81 264
return 1 81 265
assign 1 85 358
new 0 85 358
assign 1 86 359
new 0 86 359
wasOperSet 1 86 360
assign 1 87 361
operNamesGet 0 87 361
assign 1 87 362
typenameGet 0 87 362
assign 1 87 363
get 1 87 363
assign 1 87 364
lower 0 87 364
nameSet 1 87 365
assign 1 88 366
nameGet 0 88 366
assign 1 88 367
new 0 88 367
assign 1 88 368
equals 1 88 368
assign 1 89 370
new 0 89 370
nameSet 1 89 371
assign 1 91 373
nameGet 0 91 373
assign 1 91 374
new 0 91 374
assign 1 91 375
equals 1 91 375
assign 1 92 377
new 0 92 377
nameSet 1 92 378
assign 1 94 380
nameGet 0 94 380
assign 1 94 381
new 0 94 381
assign 1 94 382
equals 1 94 382
assign 1 95 384
new 0 95 384
nameSet 1 95 385
assign 1 97 387
nameGet 0 97 387
assign 1 97 388
new 0 97 388
assign 1 97 389
equals 1 97 389
assign 1 98 391
new 0 98 391
nameSet 1 98 392
assign 1 100 394
nameGet 0 100 394
assign 1 100 395
new 0 100 395
assign 1 100 396
equals 1 100 396
assign 1 101 398
new 0 101 398
nameSet 1 101 399
assign 1 103 401
nameGet 0 103 401
assign 1 103 402
new 0 103 402
assign 1 103 403
equals 1 103 403
assign 1 104 405
new 0 104 405
nameSet 1 104 406
assign 1 106 408
nameGet 0 106 408
assign 1 106 409
new 0 106 409
assign 1 106 410
equals 1 106 410
assign 1 107 412
new 0 107 412
nameSet 1 107 413
assign 1 109 415
nameGet 0 109 415
assign 1 109 416
new 0 109 416
assign 1 109 417
equals 1 109 417
assign 1 110 419
new 0 110 419
nameSet 1 110 420
assign 1 112 422
nameGet 0 112 422
assign 1 112 423
new 0 112 423
assign 1 112 424
equals 1 112 424
assign 1 113 426
new 0 113 426
nameSet 1 113 427
assign 1 115 429
nameGet 0 115 429
assign 1 115 430
new 0 115 430
assign 1 115 431
equals 1 115 431
assign 1 116 433
new 0 116 433
nameSet 1 116 434
assign 1 118 436
nameGet 0 118 436
assign 1 118 437
new 0 118 437
assign 1 118 438
equals 1 118 438
assign 1 119 440
new 0 119 440
nameSet 1 119 441
assign 1 121 443
nameGet 0 121 443
assign 1 121 444
new 0 121 444
assign 1 121 445
equals 1 121 445
assign 1 122 447
new 0 122 447
nameSet 1 122 448
assign 1 124 450
nameGet 0 124 450
assign 1 124 451
new 0 124 451
assign 1 124 452
equals 1 124 452
assign 1 126 454
new 0 126 454
nameSet 1 126 455
assign 1 128 457
nameGet 0 128 457
assign 1 128 458
new 0 128 458
assign 1 128 459
equals 1 128 459
assign 1 129 461
new 0 129 461
nameSet 1 129 462
assign 1 131 464
nameGet 0 131 464
assign 1 131 465
new 0 131 465
assign 1 131 466
equals 1 131 466
assign 1 132 468
new 0 132 468
nameSet 1 132 469
assign 1 135 471
new 0 135 471
wasBoundSet 1 135 472
assign 1 136 473
typenameGet 0 136 473
assign 1 136 474
ASSIGNGet 0 136 474
assign 1 136 475
equals 1 136 475
assign 1 136 477
heldGet 0 136 477
assign 1 136 478
new 0 136 478
assign 1 136 479
equals 1 136 479
assign 1 0 481
assign 1 0 484
assign 1 0 488
assign 1 138 491
new 0 138 491
isOnceSet 1 138 492
assign 1 140 494
typenameGet 0 140 494
assign 1 140 495
ASSIGNGet 0 140 495
assign 1 140 496
equals 1 140 496
assign 1 140 498
heldGet 0 140 498
assign 1 140 499
new 0 140 499
assign 1 140 500
equals 1 140 500
assign 1 0 502
assign 1 0 505
assign 1 0 509
assign 1 142 512
new 0 142 512
isManySet 1 142 513
assign 1 144 515
typenameGet 0 144 515
assign 1 144 516
GET_METHODGet 0 144 516
assign 1 144 517
equals 1 144 517
assign 1 145 519
new 0 145 519
buildLiteral 2 145 520
assign 1 147 522
CALLGet 0 147 522
typenameSet 1 147 523
heldSet 1 148 524
delete 0 149 525
addValue 1 150 526
assign 1 151 527
new 0 151 527
assign 1 151 528
greater 1 151 528
delete 0 152 530
addValue 1 153 531
return 1 155 533
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1189966673: return bem_toAny_0();
case 1045959947: return bem_deserializeClassNameGet_0();
case 353310865: return bem_constGet_0();
case -212029696: return bem_many_0();
case -533988464: return bem_prepOps_0();
case -1554789119: return bem_iteratorGet_0();
case 1039721337: return bem_fieldIteratorGet_0();
case -177474376: return bem_serializeToString_0();
case -960534087: return bem_transGet_0();
case 266181284: return bem_tagGet_0();
case -1948098255: return bem_classNameGet_0();
case -467364468: return bem_ntypesGetDirect_0();
case 1936518897: return bem_buildGet_0();
case 1657059163: return bem_fieldNamesGet_0();
case 2110316685: return bem_serializeContents_0();
case 1329517290: return bem_once_0();
case -174321978: return bem_serializationIteratorGet_0();
case 254210050: return bem_copy_0();
case -1519514970: return bem_print_0();
case -1846614886: return bem_constGetDirect_0();
case -1641539908: return bem_toString_0();
case -1963952686: return bem_hashGet_0();
case -1886421584: return bem_new_0();
case -1841512138: return bem_sourceFileNameGet_0();
case -1063147421: return bem_create_0();
case -1146801221: return bem_transGetDirect_0();
case 2065774234: return bem_ntypesGet_0();
case 1380145557: return bem_buildGetDirect_0();
case 900120920: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 412046405: return bem_constSetDirect_1(bevd_0);
case -120618989: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1733222638: return bem_defined_1(bevd_0);
case -2127380557: return bem_end_1(bevd_0);
case -1751970442: return bem_undef_1(bevd_0);
case -1837267423: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 506068861: return bem_equals_1(bevd_0);
case -1245948247: return bem_transSetDirect_1(bevd_0);
case 1581368506: return bem_otherClass_1(bevd_0);
case -1775010996: return bem_ntypesSet_1(bevd_0);
case 789094035: return bem_def_1(bevd_0);
case 670434524: return bem_copyTo_1(bevd_0);
case -1873596814: return bem_constSet_1(bevd_0);
case -1967256533: return bem_acceptClass_1(bevd_0);
case -2101355929: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1038314311: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1827212883: return bem_ntypesSetDirect_1(bevd_0);
case -985468058: return bem_undefined_1(bevd_0);
case 1739465388: return bem_buildSetDirect_1(bevd_0);
case 1908367666: return bem_buildSet_1(bevd_0);
case 768759292: return bem_begin_1(bevd_0);
case 17112028: return bem_sameClass_1(bevd_0);
case 1688875848: return bem_sameType_1(bevd_0);
case 911117738: return bem_notEquals_1(bevd_0);
case 1794882951: return bem_sameObject_1(bevd_0);
case 1733689419: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1337665439: return bem_otherType_1(bevd_0);
case -1113553492: return bem_transSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 35608937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 925887327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1673554568: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 35788340: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -719350484: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1172756878: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1834730412: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -920497275: return bem_callFromOper_4(bevd_0, bevd_1, bevd_2, bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass8_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass8_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass8();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst = (BEC_3_5_5_5_BuildVisitPass8) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass8.bece_BEC_3_5_5_5_BuildVisitPass8_bevs_type;
}
}
}
