namespace be {

using System;
using System.Threading;
/* IO:File: source/base/Time.be */
public class BEC_2_4_8_TimeInterval : BEC_2_6_6_SystemObject {
public BEC_2_4_8_TimeInterval() { }
static BEC_2_4_8_TimeInterval() { }

    public static readonly DateTime epochStart = new DateTime
    (1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    private static byte[] becc_BEC_2_4_8_TimeInterval_clname = {0x54,0x69,0x6D,0x65,0x3A,0x49,0x6E,0x74,0x65,0x72,0x76,0x61,0x6C};
private static byte[] becc_BEC_2_4_8_TimeInterval_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_0 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_1 = (new BEC_2_4_3_MathInt(60));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_2 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_3 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_4 = (new BEC_2_4_3_MathInt(3600));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_5 = (new BEC_2_4_3_MathInt(86400));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_6 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_7 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_11 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_13 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_14 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_15 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_16 = (new BEC_2_4_3_MathInt(1000));
private static BEC_2_4_3_MathInt bece_BEC_2_4_8_TimeInterval_bevo_17 = (new BEC_2_4_3_MathInt(3600));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_0 = {0x20,0x6D,0x69,0x6E,0x75,0x74,0x65,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_0, 10));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_1 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_1, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_2 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_2, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_3 = {0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_3, 1));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_4 = {0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73,0x20,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_4, 13));
private static byte[] bece_BEC_2_4_8_TimeInterval_bels_5 = {0x20,0x6D,0x69,0x6C,0x6C,0x69,0x73,0x65,0x63,0x6F,0x6E,0x64,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_TimeInterval_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_TimeInterval_bels_5, 13));
public static new BEC_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_inst;

public static new BET_2_4_8_TimeInterval bece_BEC_2_4_8_TimeInterval_bevs_type;

public BEC_2_4_3_MathInt bevp_secs;
public BEC_2_4_3_MathInt bevp_millis;
public virtual BEC_2_4_8_TimeInterval bem_now_0() {
bevp_secs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_millis = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        long ctm = (long) (DateTime.UtcNow - epochStart).TotalMilliseconds;
        bevp_secs.bevi_int = (int) (ctm / 1000);
        bevp_millis.bevi_int = (int) (ctm % 1000);
        return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_secs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_millis = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_new_2(BEC_2_4_3_MathInt beva__secs, BEC_2_4_3_MathInt beva__millis) {
bevp_secs = beva__secs;
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_8_TimeInterval bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_2(bevp_secs, bevp_millis);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_secondInMinuteGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_0;
bevt_0_tmpany_phold = bevp_secs.bem_modulus_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_millisecondInSecondGet_0() {
return bevp_millis;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_minutesGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_1;
bevt_0_tmpany_phold = bevp_secs.bem_divide_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_secondsGet_0() {
return bevp_secs;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_secondsSet_1(BEC_2_4_3_MathInt beva__secs) {
bevp_secs = beva__secs;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_millisecondsGet_0() {
return bevp_millis;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_millisecondsSet_1(BEC_2_4_3_MathInt beva__millis) {
bevp_millis = beva__millis;
bem_carryMillis_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_addHours_1(BEC_2_4_3_MathInt beva_hours) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_2;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_addDays_1(BEC_2_4_3_MathInt beva_days) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_3;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_subtractHours_1(BEC_2_4_3_MathInt beva_hours) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_hours);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_subtractDays_1(BEC_2_4_3_MathInt beva_days) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_5;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_multiply_1(beva_days);
bevp_secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_addSeconds_1(BEC_2_4_3_MathInt beva__secs) {
bevp_secs = bevp_secs.bem_add_1(beva__secs);
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_addMilliseconds_1(BEC_2_4_3_MathInt beva__millis) {
bevp_millis = bevp_millis.bem_add_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_carryMillis_0() {
BEC_2_4_3_MathInt bevl_mmod = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_6;
bevl_mmod = bevp_millis.bem_modulus_1(bevt_2_tmpany_phold);
if (bevl_mmod.bevi_int != bevp_millis.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_7;
bevt_4_tmpany_phold = bevp_millis.bem_divide_1(bevt_5_tmpany_phold);
bevp_secs = bevp_secs.bem_add_1(bevt_4_tmpany_phold);
bevp_millis = bevl_mmod;
} /* Line: 240 */
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_8;
if (bevp_millis.bevi_int < bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_9;
if (bevp_secs.bevi_int > bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_10;
bevp_secs = bevp_secs.bem_subtract_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_11;
bevp_millis = bevt_11_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 244 */
 else  /* Line: 242 */ {
bevt_13_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_12;
if (bevp_millis.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 245 */ {
bevt_15_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_13;
if (bevp_secs.bevi_int < bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 245 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 245 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 245 */
 else  /* Line: 245 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 245 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_14;
bevp_secs = bevp_secs.bem_add_1(bevt_16_tmpany_phold);
bevt_18_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_15;
bevt_19_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_16;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_subtract_1(bevt_19_tmpany_phold);
bevp_millis = bevt_17_tmpany_phold.bem_add_1(bevp_millis);
} /* Line: 247 */
} /* Line: 242 */
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_subtractSeconds_1(BEC_2_4_3_MathInt beva__secs) {
bevp_secs = bevp_secs.bem_subtract_1(beva__secs);
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_subtractMilliseconds_1(BEC_2_4_3_MathInt beva__millis) {
bevp_millis = bevp_millis.bem_subtract_1(beva__millis);
bem_carryMillis_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_add_1(BEC_2_4_8_TimeInterval beva_other) {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_add_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_add_1(bevt_1_tmpany_phold);
bevl_res = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_subtract_1(BEC_2_4_8_TimeInterval beva_other) {
BEC_2_4_3_MathInt bevl__secs = null;
BEC_2_4_3_MathInt bevl__millis = null;
BEC_2_4_8_TimeInterval bevl_res = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = beva_other.bem_secsGet_0();
bevl__secs = bevp_secs.bem_subtract_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_other.bem_millisGet_0();
bevl__millis = bevp_millis.bem_subtract_1(bevt_1_tmpany_phold);
bevl_res = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_2(bevl__secs, bevl__millis);
bevl_res.bem_carryMillis_0();
return bevl_res;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_8_TimeInterval beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int > bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 277 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 277 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 277 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 278 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_8_TimeInterval beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int < bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 284 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 284 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 284 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 285 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_8_TimeInterval beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 291 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 291 */
 else  /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 291 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 291 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 291 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 292 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_8_TimeInterval beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int <= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_4_tmpany_phold = beva_other.bem_secsGet_0();
if (bevp_secs.bevi_int == bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_6_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int <= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 298 */
 else  /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 298 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 298 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 298 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 299 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
bevt_2_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 305 */ {
bevt_4_tmpany_phold = beva_other.bemd_0(-1647154763);
bevt_3_tmpany_phold = bevp_secs.bem_equals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 305 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 305 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 305 */
 else  /* Line: 305 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 305 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(1238015350);
bevt_5_tmpany_phold = bevp_millis.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 305 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 305 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 305 */
 else  /* Line: 305 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 305 */ {
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 306 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bem_sameClass_1(beva_other);
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_5_tmpany_phold = beva_other.bemd_0(-1647154763);
bevt_4_tmpany_phold = bevp_secs.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 312 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(1238015350);
bevt_6_tmpany_phold = bevp_millis.bem_notEquals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 312 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 312 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_8_tmpany_phold;
} /* Line: 313 */
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_9_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_offByHour_1(BEC_2_4_8_TimeInterval beva_other) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
if (beva_other == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 320 */
bevt_3_tmpany_phold = beva_other.bem_millisGet_0();
if (bevp_millis.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevt_7_tmpany_phold = beva_other.bem_secsGet_0();
bevt_6_tmpany_phold = bevp_secs.bem_subtract_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_abs_0();
bevt_8_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_17;
if (bevt_5_tmpany_phold.bevi_int == bevt_8_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 322 */ {
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_9_tmpany_phold;
} /* Line: 323 */
} /* Line: 322 */
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_10_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toStringMinutes_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_6_tmpany_phold = bem_minutesGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_toString_0();
bevt_7_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_18;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bem_secondInMinuteGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_19;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_10_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_20;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toShortString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_secs.bem_toString_0();
bevt_3_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_21;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_millis.bem_toString_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_secs.bem_toString_0();
bevt_4_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_millis);
bevt_5_tmpany_phold = bece_BEC_2_4_8_TimeInterval_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_secsGet_0() {
return bevp_secs;
} /*method end*/
public BEC_2_4_3_MathInt bem_secsGetDirect_0() {
return bevp_secs;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_secsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_secsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_secs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_millisGet_0() {
return bevp_millis;
} /*method end*/
public BEC_2_4_3_MathInt bem_millisGetDirect_0() {
return bevp_millis;
} /*method end*/
public virtual BEC_2_4_8_TimeInterval bem_millisSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_millisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_millis = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {118, 119, 165, 166, 172, 173, 174, 178, 178, 182, 182, 182, 186, 190, 190, 190, 194, 198, 202, 206, 207, 211, 211, 211, 215, 215, 215, 219, 219, 219, 223, 223, 223, 228, 232, 233, 237, 237, 238, 238, 239, 239, 239, 240, 242, 242, 242, 242, 242, 242, 0, 0, 0, 243, 243, 244, 244, 245, 245, 245, 245, 245, 245, 0, 0, 0, 246, 246, 247, 247, 247, 247, 252, 256, 257, 261, 261, 262, 262, 263, 264, 265, 269, 269, 270, 270, 271, 272, 273, 277, 277, 277, 0, 277, 277, 277, 277, 277, 277, 0, 0, 0, 0, 0, 278, 278, 280, 280, 284, 284, 284, 0, 284, 284, 284, 284, 284, 284, 0, 0, 0, 0, 0, 285, 285, 287, 287, 291, 291, 291, 0, 291, 291, 291, 291, 291, 291, 0, 0, 0, 0, 0, 292, 292, 294, 294, 298, 298, 298, 0, 298, 298, 298, 298, 298, 298, 0, 0, 0, 0, 0, 299, 299, 301, 301, 305, 305, 305, 0, 0, 0, 305, 305, 0, 0, 0, 306, 306, 308, 308, 312, 312, 312, 0, 312, 312, 0, 0, 0, 312, 312, 0, 0, 313, 313, 315, 315, 320, 320, 320, 320, 321, 321, 321, 322, 322, 322, 322, 322, 322, 323, 323, 326, 326, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 330, 334, 334, 334, 334, 334, 334, 338, 338, 338, 338, 338, 338, 338, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {51, 52, 60, 61, 65, 66, 67, 72, 73, 78, 79, 80, 83, 88, 89, 90, 93, 96, 100, 103, 104, 110, 111, 112, 118, 119, 120, 126, 127, 128, 134, 135, 136, 140, 144, 145, 170, 171, 172, 177, 178, 179, 180, 181, 183, 184, 189, 190, 191, 196, 197, 200, 204, 207, 208, 209, 210, 213, 214, 219, 220, 221, 226, 227, 230, 234, 237, 238, 239, 240, 241, 242, 248, 252, 253, 262, 263, 264, 265, 266, 267, 268, 276, 277, 278, 279, 280, 281, 282, 294, 295, 300, 301, 304, 305, 310, 311, 312, 317, 318, 321, 325, 328, 331, 335, 336, 338, 339, 351, 352, 357, 358, 361, 362, 367, 368, 369, 374, 375, 378, 382, 385, 388, 392, 393, 395, 396, 408, 409, 414, 415, 418, 419, 424, 425, 426, 431, 432, 435, 439, 442, 445, 449, 450, 452, 453, 465, 466, 471, 472, 475, 476, 481, 482, 483, 488, 489, 492, 496, 499, 502, 506, 507, 509, 510, 522, 524, 525, 527, 530, 534, 537, 538, 540, 543, 547, 550, 551, 553, 554, 567, 568, 573, 574, 577, 578, 580, 583, 587, 590, 591, 593, 596, 600, 601, 603, 604, 618, 623, 624, 625, 627, 628, 633, 634, 635, 636, 637, 638, 643, 644, 645, 648, 649, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 682, 683, 684, 685, 686, 687, 696, 697, 698, 699, 700, 701, 702, 705, 708, 711, 715, 719, 722, 725, 729};
/* BEGIN LINEINFO 
assign 1 118 51
new 0 118 51
assign 1 119 52
new 0 119 52
assign 1 165 60
new 0 165 60
assign 1 166 61
new 0 166 61
assign 1 172 65
assign 1 173 66
carryMillis 0 174 67
assign 1 178 72
new 2 178 72
return 1 178 73
assign 1 182 78
new 0 182 78
assign 1 182 79
modulus 1 182 79
return 1 182 80
return 1 186 83
assign 1 190 88
new 0 190 88
assign 1 190 89
divide 1 190 89
return 1 190 90
return 1 194 93
assign 1 198 96
return 1 202 100
assign 1 206 103
carryMillis 0 207 104
assign 1 211 110
new 0 211 110
assign 1 211 111
multiply 1 211 111
assign 1 211 112
add 1 211 112
assign 1 215 118
new 0 215 118
assign 1 215 119
multiply 1 215 119
assign 1 215 120
add 1 215 120
assign 1 219 126
new 0 219 126
assign 1 219 127
multiply 1 219 127
assign 1 219 128
subtract 1 219 128
assign 1 223 134
new 0 223 134
assign 1 223 135
multiply 1 223 135
assign 1 223 136
subtract 1 223 136
assign 1 228 140
add 1 228 140
assign 1 232 144
add 1 232 144
carryMillis 0 233 145
assign 1 237 170
new 0 237 170
assign 1 237 171
modulus 1 237 171
assign 1 238 172
notEquals 1 238 177
assign 1 239 178
new 0 239 178
assign 1 239 179
divide 1 239 179
assign 1 239 180
add 1 239 180
assign 1 240 181
assign 1 242 183
new 0 242 183
assign 1 242 184
lesser 1 242 189
assign 1 242 190
new 0 242 190
assign 1 242 191
greater 1 242 196
assign 1 0 197
assign 1 0 200
assign 1 0 204
assign 1 243 207
new 0 243 207
assign 1 243 208
subtract 1 243 208
assign 1 244 209
new 0 244 209
assign 1 244 210
add 1 244 210
assign 1 245 213
new 0 245 213
assign 1 245 214
greater 1 245 219
assign 1 245 220
new 0 245 220
assign 1 245 221
lesser 1 245 226
assign 1 0 227
assign 1 0 230
assign 1 0 234
assign 1 246 237
new 0 246 237
assign 1 246 238
add 1 246 238
assign 1 247 239
new 0 247 239
assign 1 247 240
new 0 247 240
assign 1 247 241
subtract 1 247 241
assign 1 247 242
add 1 247 242
assign 1 252 248
subtract 1 252 248
assign 1 256 252
subtract 1 256 252
carryMillis 0 257 253
assign 1 261 262
secsGet 0 261 262
assign 1 261 263
add 1 261 263
assign 1 262 264
millisGet 0 262 264
assign 1 262 265
add 1 262 265
assign 1 263 266
new 2 263 266
carryMillis 0 264 267
return 1 265 268
assign 1 269 276
secsGet 0 269 276
assign 1 269 277
subtract 1 269 277
assign 1 270 278
millisGet 0 270 278
assign 1 270 279
subtract 1 270 279
assign 1 271 280
new 2 271 280
carryMillis 0 272 281
return 1 273 282
assign 1 277 294
secsGet 0 277 294
assign 1 277 295
greater 1 277 300
assign 1 0 301
assign 1 277 304
secsGet 0 277 304
assign 1 277 305
equals 1 277 310
assign 1 277 311
millisGet 0 277 311
assign 1 277 312
greater 1 277 317
assign 1 0 318
assign 1 0 321
assign 1 0 325
assign 1 0 328
assign 1 0 331
assign 1 278 335
new 0 278 335
return 1 278 336
assign 1 280 338
new 0 280 338
return 1 280 339
assign 1 284 351
secsGet 0 284 351
assign 1 284 352
lesser 1 284 357
assign 1 0 358
assign 1 284 361
secsGet 0 284 361
assign 1 284 362
equals 1 284 367
assign 1 284 368
millisGet 0 284 368
assign 1 284 369
lesser 1 284 374
assign 1 0 375
assign 1 0 378
assign 1 0 382
assign 1 0 385
assign 1 0 388
assign 1 285 392
new 0 285 392
return 1 285 393
assign 1 287 395
new 0 287 395
return 1 287 396
assign 1 291 408
secsGet 0 291 408
assign 1 291 409
greaterEquals 1 291 414
assign 1 0 415
assign 1 291 418
secsGet 0 291 418
assign 1 291 419
equals 1 291 424
assign 1 291 425
millisGet 0 291 425
assign 1 291 426
greaterEquals 1 291 431
assign 1 0 432
assign 1 0 435
assign 1 0 439
assign 1 0 442
assign 1 0 445
assign 1 292 449
new 0 292 449
return 1 292 450
assign 1 294 452
new 0 294 452
return 1 294 453
assign 1 298 465
secsGet 0 298 465
assign 1 298 466
lesserEquals 1 298 471
assign 1 0 472
assign 1 298 475
secsGet 0 298 475
assign 1 298 476
equals 1 298 481
assign 1 298 482
millisGet 0 298 482
assign 1 298 483
lesserEquals 1 298 488
assign 1 0 489
assign 1 0 492
assign 1 0 496
assign 1 0 499
assign 1 0 502
assign 1 299 506
new 0 299 506
return 1 299 507
assign 1 301 509
new 0 301 509
return 1 301 510
assign 1 305 522
sameClass 1 305 522
assign 1 305 524
secsGet 0 305 524
assign 1 305 525
equals 1 305 525
assign 1 0 527
assign 1 0 530
assign 1 0 534
assign 1 305 537
millisGet 0 305 537
assign 1 305 538
equals 1 305 538
assign 1 0 540
assign 1 0 543
assign 1 0 547
assign 1 306 550
new 0 306 550
return 1 306 551
assign 1 308 553
new 0 308 553
return 1 308 554
assign 1 312 567
sameClass 1 312 567
assign 1 312 568
not 0 312 573
assign 1 0 574
assign 1 312 577
secsGet 0 312 577
assign 1 312 578
notEquals 1 312 578
assign 1 0 580
assign 1 0 583
assign 1 0 587
assign 1 312 590
millisGet 0 312 590
assign 1 312 591
notEquals 1 312 591
assign 1 0 593
assign 1 0 596
assign 1 313 600
new 0 313 600
return 1 313 601
assign 1 315 603
new 0 315 603
return 1 315 604
assign 1 320 618
undef 1 320 623
assign 1 320 624
new 0 320 624
return 1 320 625
assign 1 321 627
millisGet 0 321 627
assign 1 321 628
equals 1 321 633
assign 1 322 634
secsGet 0 322 634
assign 1 322 635
subtract 1 322 635
assign 1 322 636
abs 0 322 636
assign 1 322 637
new 0 322 637
assign 1 322 638
equals 1 322 643
assign 1 323 644
new 0 323 644
return 1 323 645
assign 1 326 648
new 0 326 648
return 1 326 649
assign 1 330 663
minutesGet 0 330 663
assign 1 330 664
toString 0 330 664
assign 1 330 665
new 0 330 665
assign 1 330 666
add 1 330 666
assign 1 330 667
secondInMinuteGet 0 330 667
assign 1 330 668
add 1 330 668
assign 1 330 669
new 0 330 669
assign 1 330 670
add 1 330 670
assign 1 330 671
add 1 330 671
assign 1 330 672
new 0 330 672
assign 1 330 673
add 1 330 673
return 1 330 674
assign 1 334 682
toString 0 334 682
assign 1 334 683
new 0 334 683
assign 1 334 684
add 1 334 684
assign 1 334 685
toString 0 334 685
assign 1 334 686
add 1 334 686
return 1 334 687
assign 1 338 696
toString 0 338 696
assign 1 338 697
new 0 338 697
assign 1 338 698
add 1 338 698
assign 1 338 699
add 1 338 699
assign 1 338 700
new 0 338 700
assign 1 338 701
add 1 338 701
return 1 338 702
return 1 0 705
return 1 0 708
assign 1 0 711
assign 1 0 715
return 1 0 719
return 1 0 722
assign 1 0 725
assign 1 0 729
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1519514970: return bem_print_0();
case 1238015350: return bem_millisGet_0();
case 1039721337: return bem_fieldIteratorGet_0();
case -187871508: return bem_millisGetDirect_0();
case 1695100602: return bem_toStringMinutes_0();
case 900120920: return bem_echo_0();
case -1647154763: return bem_secsGet_0();
case 1657059163: return bem_fieldNamesGet_0();
case 2110316685: return bem_serializeContents_0();
case 266181284: return bem_tagGet_0();
case -212029696: return bem_many_0();
case -970889810: return bem_secsGetDirect_0();
case 754748385: return bem_carryMillis_0();
case -1948098255: return bem_classNameGet_0();
case -1795025826: return bem_secondInMinuteGet_0();
case 1329517290: return bem_once_0();
case 1622105548: return bem_minutesGet_0();
case -177474376: return bem_serializeToString_0();
case -1189966673: return bem_toAny_0();
case -1554789119: return bem_iteratorGet_0();
case -1841512138: return bem_sourceFileNameGet_0();
case -1886421584: return bem_new_0();
case -174321978: return bem_serializationIteratorGet_0();
case 216521690: return bem_secondsGet_0();
case -1963952686: return bem_hashGet_0();
case -1978024109: return bem_millisecondInSecondGet_0();
case 254210050: return bem_copy_0();
case -1063147421: return bem_create_0();
case 1981162044: return bem_now_0();
case -134087118: return bem_toShortString_0();
case 1045959947: return bem_deserializeClassNameGet_0();
case 1946043273: return bem_millisecondsGet_0();
case -1641539908: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1968801216: return bem_millisSet_1(bevd_0);
case -193878533: return bem_millisSetDirect_1(bevd_0);
case -1038314311: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1751970442: return bem_undef_1(bevd_0);
case 2040282826: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 33956170: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case -26356621: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case -2101355929: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -985468058: return bem_undefined_1(bevd_0);
case 17112028: return bem_sameClass_1(bevd_0);
case -1837267423: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 424211553: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case 412339429: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case -1723767212: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case 1733222638: return bem_defined_1(bevd_0);
case -1026877873: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1581368506: return bem_otherClass_1(bevd_0);
case 506068861: return bem_equals_1(bevd_0);
case -1244641607: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1688875848: return bem_sameType_1(bevd_0);
case 206689225: return bem_secsSetDirect_1(bevd_0);
case -1059458962: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 1084866515: return bem_secsSet_1(bevd_0);
case 1184159318: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 670434524: return bem_copyTo_1(bevd_0);
case 93607197: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1363950238: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case 1337665439: return bem_otherType_1(bevd_0);
case 808439541: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -722036484: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1794882951: return bem_sameObject_1(bevd_0);
case 789094035: return bem_def_1(bevd_0);
case -464445662: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 911117738: return bem_notEquals_1(bevd_0);
case 116852716: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -120618989: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -832969151: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -719350484: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1673554568: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1783344195: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1172756878: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1834730412: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 35608937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 925887327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 35788340: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_TimeInterval_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_8_TimeInterval_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_8_TimeInterval();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst = (BEC_2_4_8_TimeInterval) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_8_TimeInterval.bece_BEC_2_4_8_TimeInterval_bevs_type;
}
}
}
