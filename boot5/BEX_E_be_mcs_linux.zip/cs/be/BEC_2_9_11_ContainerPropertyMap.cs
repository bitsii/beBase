namespace be {
/* IO:File: source/extended/Properties.be */
public class BEC_2_9_11_ContainerPropertyMap : BEC_2_6_6_SystemObject {
public BEC_2_9_11_ContainerPropertyMap() { }
static BEC_2_9_11_ContainerPropertyMap() { }
private static byte[] becc_BEC_2_9_11_ContainerPropertyMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerPropertyMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerPropertyMap bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst;

public static new BET_2_9_11_ContainerPropertyMap bece_BEC_2_9_11_ContainerPropertyMap_bevs_type;

public BEC_2_9_3_ContainerMap bevp_map;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_9_11_ContainerPropertyMap bem_set_2(BEC_2_4_6_TextString beva_key, BEC_2_4_6_TextString beva_value) {
bevp_map.bem_put_2(beva_key, beva_value);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_get_1(BEC_2_4_6_TextString beva_key) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_map.bem_get_1(beva_key);
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getCached_1(BEC_2_4_6_TextString beva_key) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_map.bem_get_1(beva_key);
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_11_ContainerPropertyMap bem_unset_1(BEC_2_4_6_TextString beva_key) {
bevp_map.bem_delete_1(beva_key);
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_mapGet_0() {
return null;
} /*method end*/
public virtual BEC_2_9_11_ContainerPropertyMap bem_mapSet_1(BEC_2_9_3_ContainerMap beva__map) {
return this;
} /*method end*/
public virtual BEC_2_9_11_ContainerPropertyMap bem_load_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_map.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGetDirect_0() {
return bevp_map;
} /*method end*/
public BEC_2_9_11_ContainerPropertyMap bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 23, 27, 27, 31, 31, 35, 38, 39, 44, 44, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 18, 23, 24, 28, 29, 32, 36, 39, 46, 47, 50, 53};
/* BEGIN LINEINFO 
assign 1 17 14
new 0 17 14
put 2 23 18
assign 1 27 23
get 1 27 23
return 1 27 24
assign 1 31 28
get 1 31 28
return 1 31 29
delete 1 35 32
return 1 38 36
return 1 39 39
assign 1 44 46
iteratorGet 0 44 46
return 1 44 47
return 1 0 50
assign 1 0 53
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1764716287: return bem_once_0();
case 2098994482: return bem_hashGet_0();
case -98046751: return bem_tagGet_0();
case -1509690672: return bem_iteratorGet_0();
case 1669654091: return bem_many_0();
case 329044611: return bem_fieldNamesGet_0();
case -1058456741: return bem_print_0();
case 1163805126: return bem_new_0();
case -925049268: return bem_mapGet_0();
case 1929688279: return bem_classNameGet_0();
case 281585293: return bem_toAny_0();
case -1101624703: return bem_deserializeClassNameGet_0();
case 538389441: return bem_serializeToString_0();
case -1006908471: return bem_serializeContents_0();
case 1898972892: return bem_mapGetDirect_0();
case 1945143392: return bem_fieldIteratorGet_0();
case -1032171260: return bem_toString_0();
case 2098483713: return bem_copy_0();
case -1610742202: return bem_create_0();
case 334648449: return bem_serializationIteratorGet_0();
case 705622040: return bem_sourceFileNameGet_0();
case 812544411: return bem_echo_0();
case -149849911: return bem_load_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2475225: return bem_getCached_1((BEC_2_4_6_TextString) bevd_0);
case -115873590: return bem_mapSet_1((BEC_2_9_3_ContainerMap) bevd_0);
case 1863898392: return bem_equals_1(bevd_0);
case 714503183: return bem_sameObject_1(bevd_0);
case 220285540: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1033255450: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1446306055: return bem_otherClass_1(bevd_0);
case 613414930: return bem_def_1(bevd_0);
case -833799554: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1381792903: return bem_unset_1((BEC_2_4_6_TextString) bevd_0);
case -1207491940: return bem_undef_1(bevd_0);
case 2108235391: return bem_defined_1(bevd_0);
case -1685877365: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 99127990: return bem_otherType_1(bevd_0);
case -1010197940: return bem_mapSetDirect_1(bevd_0);
case 1867834674: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1837978646: return bem_sameType_1(bevd_0);
case -1776959106: return bem_notEquals_1(bevd_0);
case 1538927011: return bem_copyTo_1(bevd_0);
case -1524968669: return bem_sameClass_1(bevd_0);
case 1300185187: return bem_undefined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1729205107: return bem_set_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1997741826: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 937271141: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -906378356: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 395811446: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1670352859: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -903966108: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -319646499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerPropertyMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(29, becc_BEC_2_9_11_ContainerPropertyMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerPropertyMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst = (BEC_2_9_11_ContainerPropertyMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerPropertyMap.bece_BEC_2_9_11_ContainerPropertyMap_bevs_type;
}
}
}
