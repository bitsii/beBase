namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet : BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
static BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static new BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {199, 199, 203, 204, 205, 206, 207, 208};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 199 14
new 0 199 14
new 1 199 15
assign 1 203 19
new 1 203 19
assign 1 204 20
assign 1 205 21
new 0 205 21
assign 1 206 22
new 0 206 22
assign 1 207 23
new 0 207 23
assign 1 208 24
new 0 208 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1942512195: return bem_setIteratorGet_0();
case -1972444899: return bem_slotsGet_0();
case -536373449: return bem_keyIteratorGet_0();
case 645227528: return bem_copy_0();
case 1805899516: return bem_many_0();
case 1128561166: return bem_baseNodeGet_0();
case 1325586833: return bem_isEmptyGet_0();
case -414566530: return bem_fieldIteratorGet_0();
case 947325272: return bem_sizeGet_0();
case 1501620573: return bem_deserializeClassNameGet_0();
case 709049511: return bem_multiGet_0();
case -439307572: return bem_hashGet_0();
case -1520733892: return bem_moduGet_0();
case -2015845334: return bem_keysGet_0();
case -1893478750: return bem_notEmptyGet_0();
case 1991051685: return bem_print_0();
case -2067310143: return bem_create_0();
case -1791312022: return bem_serializationIteratorGet_0();
case 569170195: return bem_clear_0();
case 1545403777: return bem_relGet_0();
case 1163377727: return bem_toAny_0();
case 1754190679: return bem_classNameGet_0();
case 1193477558: return bem_new_0();
case -185986075: return bem_nodeIteratorGet_0();
case -1466347886: return bem_serializeContents_0();
case 793830133: return bem_tagGet_0();
case -637230318: return bem_serializeToString_0();
case 956121033: return bem_sourceFileNameGet_0();
case -213541934: return bem_echo_0();
case -873762602: return bem_innerPutAddedGet_0();
case -1889481920: return bem_once_0();
case 153829440: return bem_iteratorGet_0();
case -865380737: return bem_nodesGet_0();
case 491585243: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -505152552: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1595171473: return bem_addValue_1(bevd_0);
case 100980215: return bem_otherClass_1(bevd_0);
case -1001612683: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 279657909: return bem_equals_1(bevd_0);
case -1871751942: return bem_def_1(bevd_0);
case 1513065171: return bem_get_1(bevd_0);
case -207342363: return bem_sizeSet_1(bevd_0);
case -1504728618: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 1596320235: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1328329722: return bem_moduSet_1(bevd_0);
case 1771727296: return bem_has_1(bevd_0);
case 2034032536: return bem_innerPutAddedSet_1(bevd_0);
case 1267197459: return bem_otherType_1(bevd_0);
case 1979194181: return bem_notEquals_1(bevd_0);
case -1865897580: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 2133421449: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -753626955: return bem_baseNodeSet_1(bevd_0);
case 1114375968: return bem_sameClass_1(bevd_0);
case 259205323: return bem_relSet_1(bevd_0);
case 2010343570: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1372650183: return bem_delete_1(bevd_0);
case -1314037522: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1603994454: return bem_sameType_1(bevd_0);
case -704128729: return bem_copyTo_1(bevd_0);
case -1057598101: return bem_put_1(bevd_0);
case 385893729: return bem_undefined_1(bevd_0);
case -463711263: return bem_slotsSet_1(bevd_0);
case -1489116348: return bem_multiSet_1(bevd_0);
case -1192171297: return bem_defined_1(bevd_0);
case 769079683: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1963771415: return bem_undef_1(bevd_0);
case 417172649: return bem_sameObject_1(bevd_0);
case -287855524: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1596177832: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1919067749: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1086524794: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1313996982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1153243887: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 966288160: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -962439482: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1636303925: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1006435310: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentitySet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
}
