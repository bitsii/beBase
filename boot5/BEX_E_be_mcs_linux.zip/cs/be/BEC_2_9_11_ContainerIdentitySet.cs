namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentitySet : BEC_2_9_3_ContainerSet {
public BEC_2_9_11_ContainerIdentitySet() { }
static BEC_2_9_11_ContainerIdentitySet() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x53,0x65,0x74};
private static byte[] becc_BEC_2_9_11_ContainerIdentitySet_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;

public static new BET_2_9_11_ContainerIdentitySet bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerSetSetNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {199, 199, 203, 204, 205, 206, 207, 208};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 199 14
new 0 199 14
new 1 199 15
assign 1 203 19
new 1 203 19
assign 1 204 20
assign 1 205 21
new 0 205 21
assign 1 206 22
new 0 206 22
assign 1 207 23
new 0 207 23
assign 1 208 24
new 0 208 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -647765420: return bem_keyIteratorGet_0();
case -196471174: return bem_toAny_0();
case -564780370: return bem_sizeGet_0();
case -627661593: return bem_serializationIteratorGet_0();
case -2127113784: return bem_sourceFileNameGet_0();
case 561389448: return bem_copy_0();
case 70409796: return bem_fieldIteratorGet_0();
case 1662200945: return bem_nodesGet_0();
case -751296258: return bem_toString_0();
case 725436643: return bem_nodeIteratorGet_0();
case -100607846: return bem_moduGet_0();
case -520744539: return bem_baseNodeGet_0();
case 2049921022: return bem_serializeContents_0();
case 1292715747: return bem_baseNodeGetDirect_0();
case -1391094119: return bem_tagGet_0();
case -374298812: return bem_iteratorGet_0();
case 896506852: return bem_multiGet_0();
case 1610207827: return bem_serializeToString_0();
case 1848232636: return bem_setIteratorGet_0();
case -808549585: return bem_classNameGet_0();
case 1406395122: return bem_innerPutAddedGet_0();
case 1425659715: return bem_relGet_0();
case 968580594: return bem_notEmptyGet_0();
case -678308100: return bem_innerPutAddedGetDirect_0();
case -168798537: return bem_slotsGet_0();
case 441719677: return bem_hashGet_0();
case -1612673222: return bem_echo_0();
case 722156191: return bem_create_0();
case -1279033391: return bem_multiGetDirect_0();
case 59246170: return bem_sizeGetDirect_0();
case 701763907: return bem_new_0();
case -1125939672: return bem_clear_0();
case -1030871144: return bem_slotsGetDirect_0();
case 73901351: return bem_fieldNamesGet_0();
case -512259678: return bem_many_0();
case 1031468675: return bem_isEmptyGet_0();
case 235564665: return bem_moduGetDirect_0();
case 330207183: return bem_once_0();
case 193429232: return bem_keysGet_0();
case -796966532: return bem_print_0();
case -182708794: return bem_relGetDirect_0();
case 1280430641: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 803653343: return bem_otherClass_1(bevd_0);
case -1531658029: return bem_moduSet_1(bevd_0);
case -663969275: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1971058587: return bem_moduSetDirect_1(bevd_0);
case 680756917: return bem_defined_1(bevd_0);
case 1482196188: return bem_delete_1(bevd_0);
case -191286971: return bem_def_1(bevd_0);
case 1771514735: return bem_multiSetDirect_1(bevd_0);
case 978579138: return bem_relSetDirect_1(bevd_0);
case 1649757588: return bem_sameObject_1(bevd_0);
case -1518485447: return bem_get_1(bevd_0);
case 1294009481: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -2007498716: return bem_innerPutAddedSetDirect_1(bevd_0);
case -1334876329: return bem_baseNodeSet_1(bevd_0);
case 1483383065: return bem_relSet_1(bevd_0);
case -1934236484: return bem_sameType_1(bevd_0);
case 1645946581: return bem_notEquals_1(bevd_0);
case 974027661: return bem_has_1(bevd_0);
case -603916323: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1093373543: return bem_innerPutAddedSet_1(bevd_0);
case -1380437617: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1110748051: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1587984688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -838690785: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1197345309: return bem_otherType_1(bevd_0);
case -1360832571: return bem_slotsSet_1(bevd_0);
case -1668696125: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1330553735: return bem_sizeSetDirect_1(bevd_0);
case -234216772: return bem_sizeSet_1(bevd_0);
case 1381682421: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -184067589: return bem_baseNodeSetDirect_1(bevd_0);
case 788956945: return bem_undefined_1(bevd_0);
case -597111792: return bem_put_1(bevd_0);
case -1272706644: return bem_copyTo_1(bevd_0);
case 1320952802: return bem_sameClass_1(bevd_0);
case 463890253: return bem_undef_1(bevd_0);
case -108998047: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1719673601: return bem_slotsSetDirect_1(bevd_0);
case -1922512711: return bem_addValue_1(bevd_0);
case 725850689: return bem_equals_1(bevd_0);
case -1912311780: return bem_multiSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 235947300: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2053867671: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1365336246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1806210068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2137630710: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1094925459: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1242672538: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -910986713: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1672933493: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentitySet_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentitySet_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentitySet();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst = (BEC_2_9_11_ContainerIdentitySet) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentitySet.bece_BEC_2_9_11_ContainerIdentitySet_bevs_type;
}
}
}
