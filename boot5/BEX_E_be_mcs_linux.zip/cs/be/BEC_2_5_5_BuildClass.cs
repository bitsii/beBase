namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_5_BuildClass : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildClass() { }
static BEC_2_5_5_BuildClass() { }
private static byte[] becc_BEC_2_5_5_BuildClass_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73};
private static byte[] becc_BEC_2_5_5_BuildClass_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_0 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_1 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_2 = {0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x3A,0x20};
private static byte[] bece_BEC_2_5_5_BuildClass_bels_3 = {0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x73,0x3A,0x20};
public static new BEC_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_inst;

public static new BET_2_5_5_BuildClass bece_BEC_2_5_5_BuildClass_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_extends;
public BEC_2_9_10_ContainerLinkedList bevp_emits;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_libName;
public BEC_2_9_3_ContainerMap bevp_methods;
public BEC_2_9_10_ContainerLinkedList bevp_orderedMethods;
public BEC_2_9_10_ContainerLinkedList bevp_used;
public BEC_2_9_3_ContainerMap bevp_anyMap;
public BEC_2_9_10_ContainerLinkedList bevp_orderedVars;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_5_4_LogicBool bevp_freeFirstSlot;
public BEC_2_5_4_LogicBool bevp_firstSlotNative;
public BEC_2_4_3_MathInt bevp_nativeSlots;
public BEC_2_5_4_LogicBool bevp_isList;
public BEC_2_4_3_MathInt bevp_onceEvalCount;
public BEC_2_9_3_ContainerSet bevp_referencedProperties;
public BEC_2_5_4_LogicBool bevp_shouldWrite;
public BEC_2_4_3_MathInt bevp_belsCount;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevp_methods = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_used = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_anyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isLocal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isNotNull = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_nativeSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isList = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_onceEvalCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_shouldWrite = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_belsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_0));
bevl_np.bem_fromString_1(bevt_0_ta_ph);
bem_addUsed_1(bevl_np);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_1));
bevl_np.bem_fromString_1(bevt_1_ta_ph);
bem_addUsed_1(bevl_np);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addUsed_1(BEC_2_6_6_SystemObject beva_touse) {
bevp_used.bem_addValue_1(beva_touse);
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_addEmit_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_emits == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 137*/ {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 138*/
bevp_emits.bem_addValue_1(beva_node);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevl_ret = bem_classNameGet_0();
if (bevp_namepath == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildClass_bels_2));
bevt_1_ta_ph = bevl_ret.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = bevp_namepath.bem_toString_0();
bevl_ret = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
if (bevp_extends == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildClass_bels_3));
bevt_5_ta_ph = bevl_ret.bem_add_1(bevt_6_ta_ph);
bevt_7_ta_ph = bevp_extends.bem_toString_0();
bevl_ret = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
} /* Line: 148*/
} /* Line: 147*/
return bevl_ret;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGet_0() {
return bevp_extends;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_extendsGetDirect_0() {
return bevp_extends;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_extendsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extends = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGet_0() {
return bevp_emits;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitsGetDirect_0() {
return bevp_emits;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_emitsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGet_0() {
return bevp_methods;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_methodsGetDirect_0() {
return bevp_methods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_methodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_methods = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGet_0() {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedMethodsGetDirect_0() {
return bevp_orderedMethods;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedMethods = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGet_0() {
return bevp_used;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedGetDirect_0() {
return bevp_used;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_usedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_used = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGet_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anyMapGetDirect_0() {
return bevp_anyMap;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_anyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_anyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGet_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_orderedVarsGetDirect_0() {
return bevp_orderedVars;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_orderedVarsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orderedVars = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGet_0() {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_4_LogicBool bem_freeFirstSlotGetDirect_0() {
return bevp_freeFirstSlot;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_freeFirstSlotSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_freeFirstSlot = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGet_0() {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_4_LogicBool bem_firstSlotNativeGetDirect_0() {
return bevp_firstSlotNative;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_firstSlotNativeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_firstSlotNative = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGet_0() {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_4_3_MathInt bem_nativeSlotsGetDirect_0() {
return bevp_nativeSlots;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_nativeSlotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nativeSlots = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGet_0() {
return bevp_isList;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isListGetDirect_0() {
return bevp_isList;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_isListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isList = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGet_0() {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceEvalCountGetDirect_0() {
return bevp_onceEvalCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_onceEvalCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_onceEvalCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGet_0() {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_referencedPropertiesGetDirect_0() {
return bevp_referencedProperties;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_referencedPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_referencedProperties = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGet_0() {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_4_LogicBool bem_shouldWriteGetDirect_0() {
return bevp_shouldWrite;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_shouldWriteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shouldWrite = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGet_0() {
return bevp_belsCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_belsCountGetDirect_0() {
return bevp_belsCount;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildClass bem_belsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_belsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 123, 124, 124, 125, 127, 128, 128, 129, 133, 137, 137, 138, 140, 144, 145, 145, 146, 146, 146, 146, 147, 147, 148, 148, 148, 148, 151, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 70, 75, 80, 81, 83, 96, 97, 102, 103, 104, 105, 106, 107, 112, 113, 114, 115, 116, 119, 122, 125, 128, 132, 136, 139, 142, 146, 150, 153, 156, 160, 164, 167, 170, 174, 178, 181, 184, 188, 192, 195, 198, 202, 206, 209, 212, 216, 220, 223, 226, 230, 234, 237, 240, 244, 248, 251, 254, 258, 262, 265, 268, 272, 276, 279, 282, 286, 290, 293, 296, 300, 304, 307, 310, 314, 318, 321, 324, 328, 332, 335, 338, 342, 346, 349, 352, 356, 360, 363, 366, 370, 374, 377, 380, 384, 388, 391, 394, 398, 402, 405, 408, 412, 416, 419, 422, 426, 430, 433, 436, 440};
/* BEGIN LINEINFO 
assign 1 103 43
new 0 103 43
assign 1 104 44
new 0 104 44
assign 1 105 45
new 0 105 45
assign 1 106 46
new 0 106 46
assign 1 107 47
new 0 107 47
assign 1 108 48
new 0 108 48
assign 1 109 49
new 0 109 49
assign 1 110 50
new 0 110 50
assign 1 111 51
new 0 111 51
assign 1 112 52
new 0 112 52
assign 1 113 53
new 0 113 53
assign 1 114 54
new 0 114 54
assign 1 115 55
new 0 115 55
assign 1 116 56
new 0 116 56
assign 1 117 57
new 0 117 57
assign 1 118 58
new 0 118 58
assign 1 123 59
new 0 123 59
assign 1 124 60
new 0 124 60
fromString 1 124 61
addUsed 1 125 62
assign 1 127 63
new 0 127 63
assign 1 128 64
new 0 128 64
fromString 1 128 65
addUsed 1 129 66
addValue 1 133 70
assign 1 137 75
undef 1 137 80
assign 1 138 81
new 0 138 81
addValue 1 140 83
assign 1 144 96
classNameGet 0 144 96
assign 1 145 97
def 1 145 102
assign 1 146 103
new 0 146 103
assign 1 146 104
add 1 146 104
assign 1 146 105
toString 0 146 105
assign 1 146 106
add 1 146 106
assign 1 147 107
def 1 147 112
assign 1 148 113
new 0 148 113
assign 1 148 114
add 1 148 114
assign 1 148 115
toString 0 148 115
assign 1 148 116
add 1 148 116
return 1 151 119
return 1 0 122
return 1 0 125
assign 1 0 128
assign 1 0 132
return 1 0 136
return 1 0 139
assign 1 0 142
assign 1 0 146
return 1 0 150
return 1 0 153
assign 1 0 156
assign 1 0 160
return 1 0 164
return 1 0 167
assign 1 0 170
assign 1 0 174
return 1 0 178
return 1 0 181
assign 1 0 184
assign 1 0 188
return 1 0 192
return 1 0 195
assign 1 0 198
assign 1 0 202
return 1 0 206
return 1 0 209
assign 1 0 212
assign 1 0 216
return 1 0 220
return 1 0 223
assign 1 0 226
assign 1 0 230
return 1 0 234
return 1 0 237
assign 1 0 240
assign 1 0 244
return 1 0 248
return 1 0 251
assign 1 0 254
assign 1 0 258
return 1 0 262
return 1 0 265
assign 1 0 268
assign 1 0 272
return 1 0 276
return 1 0 279
assign 1 0 282
assign 1 0 286
return 1 0 290
return 1 0 293
assign 1 0 296
assign 1 0 300
return 1 0 304
return 1 0 307
assign 1 0 310
assign 1 0 314
return 1 0 318
return 1 0 321
assign 1 0 324
assign 1 0 328
return 1 0 332
return 1 0 335
assign 1 0 338
assign 1 0 342
return 1 0 346
return 1 0 349
assign 1 0 352
assign 1 0 356
return 1 0 360
return 1 0 363
assign 1 0 366
assign 1 0 370
return 1 0 374
return 1 0 377
assign 1 0 380
assign 1 0 384
return 1 0 388
return 1 0 391
assign 1 0 394
assign 1 0 398
return 1 0 402
return 1 0 405
assign 1 0 408
assign 1 0 412
return 1 0 416
return 1 0 419
assign 1 0 422
assign 1 0 426
return 1 0 430
return 1 0 433
assign 1 0 436
assign 1 0 440
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1339599063: return bem_orderedMethodsGet_0();
case -175141450: return bem_orderedVarsGet_0();
case 1092105192: return bem_hashGet_0();
case 1652521523: return bem_serializeContents_0();
case -1177885430: return bem_emitsGetDirect_0();
case 934833595: return bem_synGet_0();
case -467511392: return bem_toString_0();
case -343928073: return bem_isLocalGetDirect_0();
case 895193825: return bem_once_0();
case 7254011: return bem_fieldIteratorGet_0();
case -447432319: return bem_many_0();
case 346326499: return bem_onceEvalCountGetDirect_0();
case -1287942591: return bem_libNameGetDirect_0();
case -225649058: return bem_isLocalGet_0();
case -1744100192: return bem_fromFileGetDirect_0();
case -1988862761: return bem_referencedPropertiesGet_0();
case -321491131: return bem_namepathGetDirect_0();
case 1033734258: return bem_belsCountGet_0();
case -1323898541: return bem_toAny_0();
case 1604675729: return bem_shouldWriteGetDirect_0();
case 1403688004: return bem_serializationIteratorGet_0();
case 1277686024: return bem_nativeSlotsGet_0();
case 1333151991: return bem_anyMapGetDirect_0();
case 1890854002: return bem_tagGet_0();
case -921473949: return bem_fieldNamesGet_0();
case 371157924: return bem_sourceFileNameGet_0();
case 1394040921: return bem_isFinalGet_0();
case -907869212: return bem_freeFirstSlotGetDirect_0();
case -39165288: return bem_deserializeClassNameGet_0();
case 1252416502: return bem_usedGetDirect_0();
case 1901659451: return bem_usedGet_0();
case -793241295: return bem_iteratorGet_0();
case -103940610: return bem_isNotNullGet_0();
case -1662902255: return bem_libNameGet_0();
case -1193032601: return bem_referencedPropertiesGetDirect_0();
case 1858581255: return bem_extendsGetDirect_0();
case 1513194421: return bem_isListGetDirect_0();
case 494090088: return bem_isFinalGetDirect_0();
case 1331552330: return bem_nameGetDirect_0();
case -1328332178: return bem_emitsGet_0();
case -668005194: return bem_orderedMethodsGetDirect_0();
case 1597327951: return bem_create_0();
case -754179516: return bem_orderedVarsGetDirect_0();
case -1387831588: return bem_print_0();
case -1935640673: return bem_methodsGet_0();
case -1188922735: return bem_echo_0();
case 1755281620: return bem_fromFileGet_0();
case -1363819567: return bem_new_0();
case -1760538533: return bem_classNameGet_0();
case -31632820: return bem_firstSlotNativeGet_0();
case -909505161: return bem_freeFirstSlotGet_0();
case -45924066: return bem_firstSlotNativeGetDirect_0();
case -298004599: return bem_isListGet_0();
case -988361524: return bem_shouldWriteGet_0();
case 1859403938: return bem_onceEvalCountGet_0();
case -38585101: return bem_nativeSlotsGetDirect_0();
case -1513625883: return bem_methodsGetDirect_0();
case -1206522889: return bem_anyMapGet_0();
case 639505885: return bem_isNotNullGetDirect_0();
case 1527025322: return bem_nameGet_0();
case 1319388306: return bem_copy_0();
case 782632493: return bem_namepathGet_0();
case 1586131442: return bem_synGetDirect_0();
case 2056024194: return bem_extendsGet_0();
case -585507671: return bem_belsCountGetDirect_0();
case -105946774: return bem_serializeToString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 656775083: return bem_isListSet_1(bevd_0);
case 1622774011: return bem_isLocalSetDirect_1(bevd_0);
case 758508567: return bem_anyMapSet_1(bevd_0);
case -1794855469: return bem_libNameSet_1(bevd_0);
case -96028512: return bem_orderedVarsSetDirect_1(bevd_0);
case 556253518: return bem_namepathSet_1(bevd_0);
case -1513265895: return bem_onceEvalCountSet_1(bevd_0);
case -1565599707: return bem_orderedVarsSet_1(bevd_0);
case 1791193820: return bem_onceEvalCountSetDirect_1(bevd_0);
case 610893279: return bem_usedSet_1(bevd_0);
case 1090784027: return bem_firstSlotNativeSet_1(bevd_0);
case 532709917: return bem_isNotNullSetDirect_1(bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 857879216: return bem_extendsSetDirect_1(bevd_0);
case 1968077034: return bem_isFinalSetDirect_1(bevd_0);
case -148499109: return bem_isFinalSet_1(bevd_0);
case 1145586542: return bem_freeFirstSlotSet_1(bevd_0);
case -198314404: return bem_methodsSetDirect_1(bevd_0);
case -281232665: return bem_nameSet_1(bevd_0);
case 201146939: return bem_freeFirstSlotSetDirect_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -487553557: return bem_anyMapSetDirect_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1906969876: return bem_emitsSetDirect_1(bevd_0);
case 2029234133: return bem_nativeSlotsSet_1(bevd_0);
case -889472010: return bem_orderedMethodsSetDirect_1(bevd_0);
case -1265006852: return bem_addUsed_1(bevd_0);
case -402438439: return bem_nameSetDirect_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1302593563: return bem_usedSetDirect_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 526846115: return bem_fromFileSet_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 5921506: return bem_firstSlotNativeSetDirect_1(bevd_0);
case 1282102331: return bem_shouldWriteSetDirect_1(bevd_0);
case 1012132050: return bem_belsCountSetDirect_1(bevd_0);
case 2062208226: return bem_isNotNullSet_1(bevd_0);
case -733951636: return bem_nativeSlotsSetDirect_1(bevd_0);
case -335487056: return bem_isListSetDirect_1(bevd_0);
case 257729819: return bem_shouldWriteSet_1(bevd_0);
case 679108099: return bem_synSet_1(bevd_0);
case -1153240770: return bem_referencedPropertiesSetDirect_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1177561765: return bem_extendsSet_1(bevd_0);
case 1521909557: return bem_orderedMethodsSet_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case 912797382: return bem_synSetDirect_1(bevd_0);
case 81047965: return bem_referencedPropertiesSet_1(bevd_0);
case 1292658187: return bem_methodsSet_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case 221744300: return bem_fromFileSetDirect_1(bevd_0);
case 1913806233: return bem_libNameSetDirect_1(bevd_0);
case 683339734: return bem_belsCountSet_1(bevd_0);
case 1913678463: return bem_emitsSet_1(bevd_0);
case -1651563624: return bem_isLocalSet_1(bevd_0);
case 215092546: return bem_addEmit_1(bevd_0);
case -244405125: return bem_namepathSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildClass_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_5_BuildClass_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildClass();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst = (BEC_2_5_5_BuildClass) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildClass.bece_BEC_2_5_5_BuildClass_bevs_type;
}
}
}
