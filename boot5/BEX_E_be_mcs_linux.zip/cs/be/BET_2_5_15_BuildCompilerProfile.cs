namespace be {
public class BET_2_5_15_BuildCompilerProfile : BETS_Object {
public BET_2_5_15_BuildCompilerProfile() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "new_1", "doMakeDirs_1", "exeExtGet_0", "exeExtSet_1", "libExtGet_0", "libExtSet_1", "ccObjGet_0", "ccObjSet_1", "ccGet_0", "ccSet_1", "cextGet_0", "cextSet_1", "oextGet_0", "oextSet_1", "lBuildGet_0", "lBuildSet_1", "ccoutGet_0", "ccoutSet_1", "doCopyGet_0", "doCopySet_1", "mkdirsGet_0", "mkdirsSet_1", "lexeGet_0", "lexeSet_1", "exeLibExtGet_0", "exeLibExtSet_1", "nameGet_0", "nameSet_1", "diGet_0", "diSet_1", "smacGet_0", "smacSet_1", "dialectGet_0", "dialectSet_1", "compilerGet_0", "compilerSet_1" };
bems_buildMethodNames(bevs_mtnames);
}
static BET_2_5_15_BuildCompilerProfile() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_5_15_BuildCompilerProfile();
}
}
}
