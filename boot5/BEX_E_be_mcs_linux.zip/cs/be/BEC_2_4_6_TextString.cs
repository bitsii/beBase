namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
      //do copy, isOnce
      this.bevi_bytes = new byte[bevi_length];
      Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
      bevp_size = new BEC_2_4_3_MathInt(bevi_length);
      bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
public static new BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static new BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_6_TextString bem_vstringGet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_capacity == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 256*/ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 257*/
 else /* Line: 256*/ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 258*/ {
return this;
} /* Line: 259*/
} /* Line: 256*/

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 295*/ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 296*/
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_setHex_2(bevt_2_ta_ph, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_1_ta_ph = bem_getCode_2(beva_pos, bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_toString_3(bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_sizi = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_7_TextStrings bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(-893093197);
bevl_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bevl_str.bem_sizeGet_0();
bevl_sizi.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevl_sizi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_3_ta_ph = bevl_sizi.bem_add_1(bevt_4_ta_ph);
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevt_2_ta_ph = bevt_3_ta_ph.bem_multiply_1(bevt_5_ta_ph);
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_nsize = bevt_2_ta_ph.bem_divide_1(bevt_6_ta_ph);
bem_capacitySet_1(bevl_nsize);
} /* Line: 325*/
bevt_8_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_7_ta_ph = bevt_8_ta_ph.bem_zeroGet_0();
bevt_9_ta_ph = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_7_ta_ph, bevt_9_ta_ph, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(-487853278, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 359*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_setIntUnchecked_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_size.bevi_int = bevt_4_ta_ph.bevi_int;
} /* Line: 361*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_setCodeUnchecked_2(bevt_2_ta_ph, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_0_ta_ph = bem_ends_1(bevl_nl);
if (bevt_0_ta_ph.bevi_bool)/* Line: 373*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_3_ta_ph = bevp_size.bem_subtract_1(bevt_4_ta_ph);
bevt_1_ta_ph = bem_substring_2(bevt_2_ta_ph, bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 374*/
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_5_ta_ph = bem_ends_1(bevl_nl);
if (bevt_5_ta_ph.bevi_bool)/* Line: 377*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_8_ta_ph = bevp_size.bem_subtract_1(bevt_9_ta_ph);
bevt_6_ta_ph = bem_substring_2(bevt_7_ta_ph, bevt_8_ta_ph);
return bevt_6_ta_ph;
} /* Line: 378*/
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 391*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 391*/ {
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_found.bevi_int != bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 391*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 391*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 391*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 391*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 392*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 398*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 398*/
bevt_3_ta_ph = beva_str.bem_sizeGet_0();
bevt_2_ta_ph = bevp_size.bem_subtract_1(bevt_3_ta_ph);
bevl_found = bem_find_2(beva_str, bevt_2_ta_ph);
if (bevl_found == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 401*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 407*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 407*/ {
bevt_3_ta_ph = bem_find_1(beva_str);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 407*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 407*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 407*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 407*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 408*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isIntegerGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isInteger_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 419*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 419*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 421*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 421*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 421*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 421*/
 else /* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 421*/ {
} /* Line: 421*/
 else /* Line: 421*/ {
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57));
if (bevl_ic.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 423*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 423*/ {
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
if (bevl_ic.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 423*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 423*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 423*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 423*/ {
bevt_13_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 424*/
} /* Line: 421*/
bevl_j.bevi_int++;
} /* Line: 419*/
 else /* Line: 419*/ {
break;
} /* Line: 419*/
} /* Line: 419*/
bevt_14_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumGet_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 432*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 432*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 434*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
if (bevl_ic.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 434*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 434*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 434*/
 else /* Line: 434*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 434*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 434*/ {
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 434*/ {
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
if (bevl_ic.bevi_int < bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 434*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 434*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 434*/
 else /* Line: 434*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 434*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 434*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 434*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 434*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 434*/ {
bevt_13_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 434*/ {
bevt_15_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
if (bevl_ic.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 434*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 434*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 434*/
 else /* Line: 434*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 434*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 434*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 434*/
if (!(bevt_0_ta_anchor.bevi_bool))/* Line: 434*/ {
bevt_16_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 435*/
bevl_j.bevi_int++;
} /* Line: 432*/
 else /* Line: 432*/ {
break;
} /* Line: 432*/
} /* Line: 432*/
bevt_17_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumericGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAlphaNumGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 447*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 447*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 449*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 449*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 449*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 449*/
 else /* Line: 449*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 449*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_ta_ph.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 451*/
bevl_j.bevi_int++;
} /* Line: 447*/
 else /* Line: 447*/ {
break;
} /* Line: 447*/
} /* Line: 447*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lowerValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 462*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 462*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 464*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 464*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 464*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 464*/
 else /* Line: 464*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 464*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_ta_ph);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 466*/
bevl_j.bevi_int++;
} /* Line: 462*/
 else /* Line: 462*/ {
break;
} /* Line: 462*/
} /* Line: 462*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_upperValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 481*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_2_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = bem_sizeGet_0();
bevt_3_ta_ph = bem_substring_2(bevl_last, bevt_4_ta_ph);
bevl_res.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 485*/
 else /* Line: 486*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) beva_from.bem_copy_0();
return bevt_5_ta_ph;
} /* Line: 487*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 497*/ {
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 497*/ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 499*/ {
bevt_2_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_3_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_ta_ph);
} /* Line: 502*/
 else /* Line: 504*/ {
bevt_5_ta_ph = bem_sizeGet_0();
bevt_4_ta_ph = bem_substring_2(bevl_last, bevt_5_ta_ph);
bevl_res.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 505*/
} /* Line: 499*/
 else /* Line: 497*/ {
break;
} /* Line: 497*/
} /* Line: 497*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_j = bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 516*/ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 516*/ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 516*/
 else /* Line: 516*/ {
break;
} /* Line: 516*/
} /* Line: 516*/
bevt_2_ta_ph = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_ta_ph.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 526*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 526*/ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_ta_ph);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 526*/
 else /* Line: 526*/ {
break;
} /* Line: 526*/
} /* Line: 526*/
return beva_into;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_hashValue_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getCode_2(beva_pos, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 550*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 550*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 550*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 550*/
 else /* Line: 550*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 550*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 578*/
 else /* Line: 586*/ {
return null;
} /* Line: 587*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 600*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 600*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 600*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 600*/
 else /* Line: 600*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 600*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 629*/
 else /* Line: 634*/ {
return null;
} /* Line: 635*/
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 641*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 641*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 641*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 641*/
 else /* Line: 641*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 641*/ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 642*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 647*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 647*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 647*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 647*/
 else /* Line: 647*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 647*/ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 648*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevl_input = this;
bevt_3_ta_ph = bevl_input.bem_sizeGet_0();
bevl_insz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_copy_0();
bevl_output = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_p = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 658*/ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 658*/ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_c.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 660*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
if (bevl_c.bevi_int < bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 660*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 660*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 660*/
 else /* Line: 660*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 660*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 660*/ {
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
if (bevl_c.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 660*/ {
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
if (bevl_c.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 660*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 660*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 660*/
 else /* Line: 660*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 660*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 660*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 660*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 660*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 660*/ {
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
if (bevl_c.bevi_int > bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 660*/ {
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
if (bevl_c.bevi_int < bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 660*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 660*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 660*/
 else /* Line: 660*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 660*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 660*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 660*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 660*/ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 662*/
bevl_i.bevi_int++;
} /* Line: 658*/
 else /* Line: 658*/ {
break;
} /* Line: 658*/
} /* Line: 658*/
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 670*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 671*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_rfind_1(beva_str);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_reverseBytes_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_reverseBytes_0();
bevl_rpos = bevt_0_ta_ph.bem_find_1(bevt_2_ta_ph);
if (bevl_rpos == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 778*/ {
bevt_5_ta_ph = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_ta_ph.bevi_int;
bevt_6_ta_ph = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_ta_ph;
} /* Line: 780*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_find_2(beva_str, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
if (beva_str == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 792*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
if (beva_start == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 792*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 792*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 792*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_start.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 792*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 792*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 792*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 792*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 792*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 792*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_12_ta_ph = beva_str.bem_sizeGet_0();
if (bevt_12_ta_ph.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 792*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 792*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 792*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 792*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 792*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 792*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_16_ta_ph = beva_str.bem_sizeGet_0();
bevt_17_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 792*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 792*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 792*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 792*/ {
return null;
} /* Line: 793*/
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_ta_ph, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevl_strsize.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 804*/ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 807*/
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
/* Line: 810*/ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 810*/ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 812*/ {
bevt_24_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevl_strsize.bevi_int == bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 813*/ {
return bevl_current;
} /* Line: 814*/
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_ta_ph = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_ta_ph.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 820*/ {
return null;
} /* Line: 821*/
bevt_27_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_currentstr2.bevi_int = bevt_27_ta_ph.bevi_int;
while (true)
/* Line: 824*/ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 824*/ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 827*/ {
break;
} /* Line: 828*/
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 831*/
 else /* Line: 824*/ {
break;
} /* Line: 824*/
} /* Line: 824*/
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 833*/ {
return bevl_current;
} /* Line: 834*/
} /* Line: 833*/
bevl_current.bevi_int++;
} /* Line: 837*/
 else /* Line: 810*/ {
break;
} /* Line: 810*/
} /* Line: 810*/
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
/* Line: 847*/ {
if (bevl_i == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 847*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_ta_ph);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 850*/
 else /* Line: 847*/ {
break;
} /* Line: 847*/
} /* Line: 847*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 852*/ {
bevt_3_ta_ph = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 853*/
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_join_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_stri == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 871*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 871*/ {
bevt_2_ta_ph = beva_stri.bemd_1(177409367, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 871*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 871*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 871*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 871*/ {
return null;
} /* Line: 872*/
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(123269264);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 876*/ {
bevl_maxsize = bevl_osize;
} /* Line: 877*/
 else /* Line: 878*/ {
bevl_maxsize = bevl_mysize;
} /* Line: 879*/
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 884*/ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 884*/ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(394071772, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 887*/ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 888*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_ta_ph;
} /* Line: 889*/
 else /* Line: 890*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_ta_ph;
} /* Line: 891*/
} /* Line: 888*/
bevl_i.bevi_int++;
} /* Line: 884*/
 else /* Line: 884*/ {
break;
} /* Line: 884*/
} /* Line: 884*/
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_myret.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 895*/ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 896*/ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 897*/
 else /* Line: 896*/ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 898*/ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 899*/
} /* Line: 896*/
} /* Line: 896*/
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 906*/ {
return null;
} /* Line: 906*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 907*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 908*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 914*/ {
return null;
} /* Line: 914*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 915*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 916*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_str);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(-893093197);
bevt_1_ta_ph = bevl_str.bem_sizeGet_0();
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_ta_ph, bevp_size, bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_ta_ph, bevt_5_ta_ph, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_leni = null;
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_4_3_MathInt bevl_sizi = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_7_TextStrings bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_9_SystemException bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_7_TextStrings bevt_13_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_zeroGet_0();
if (beva_starti.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1000*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1000*/ {
bevt_5_ta_ph = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 1000*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1000*/ {
bevt_7_ta_ph = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1000*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1000*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1000*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1000*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1000*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1000*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1000*/ {
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_8_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_9_ta_ph);
throw new be.BECS_ThrowBack(bevt_8_ta_ph);
} /* Line: 1001*/
 else /* Line: 1002*/ {
bevl_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_leni.bevi_int = beva_endi.bevi_int;
bevl_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevl_leni;
bevl_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_sizi.bevi_int = beva_dstarti.bevi_int;
bevl_sizi.bevi_int += bevl_leni.bevi_int;
if (bevl_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1013*/ {
bem_capacitySet_1(bevl_sizi);
} /* Line: 1014*/

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevl_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 1047*/ {
bevp_size.bevi_int = bevl_sizi.bevi_int;
} /* Line: 1051*/
return this;
} /* Line: 1053*/
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sizeGet_0();
bevt_0_ta_ph = bem_substring_2(beva_starti, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_2_ta_ph = beva_endi.bem_subtract_1(beva_starti);
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_snw == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1188*/ {
bem_new_0();
} /* Line: 1189*/
 else /* Line: 1190*/ {
bevt_2_ta_ph = beva_snw.bem_sizeGet_0();
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_new_1(bevt_1_ta_ph);
bem_addValue_1(beva_snw);
} /* Line: 1192*/
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_strip_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_e = bevp_size.bem_subtract_1(bevt_0_ta_ph);
while (true)
/* Line: 1209*/ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1209*/ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1215*/
 else /* Line: 1209*/ {
break;
} /* Line: 1209*/
} /* Line: 1209*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGetDirect_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {242, 243, 252, 252, 256, 256, 257, 258, 258, 259, 295, 295, 296, 298, 302, 302, 303, 303, 304, 304, 308, 308, 308, 308, 308, 308, 308, 312, 313, 317, 319, 320, 320, 321, 323, 323, 324, 324, 324, 324, 324, 324, 325, 327, 327, 327, 327, 331, 335, 339, 343, 353, 354, 355, 359, 359, 359, 360, 360, 360, 361, 361, 366, 366, 367, 367, 368, 368, 372, 373, 374, 374, 374, 374, 374, 376, 377, 378, 378, 378, 378, 378, 380, 384, 384, 384, 385, 386, 390, 391, 391, 0, 391, 391, 391, 0, 0, 392, 392, 394, 394, 398, 398, 398, 398, 399, 399, 399, 400, 400, 401, 401, 403, 403, 407, 407, 0, 407, 407, 407, 0, 0, 408, 408, 410, 410, 414, 414, 418, 419, 419, 419, 420, 421, 421, 421, 421, 421, 421, 0, 421, 421, 421, 0, 0, 0, 0, 0, 423, 423, 423, 0, 423, 423, 423, 0, 0, 424, 424, 419, 427, 427, 431, 432, 432, 432, 433, 434, 434, 434, 434, 434, 434, 0, 0, 0, 0, 434, 434, 434, 434, 434, 434, 0, 0, 0, 0, 0, 0, 434, 434, 434, 434, 434, 434, 0, 0, 0, 0, 0, 435, 435, 432, 438, 438, 442, 442, 446, 447, 447, 447, 448, 449, 449, 449, 449, 449, 449, 0, 0, 0, 450, 450, 451, 447, 457, 457, 457, 461, 462, 462, 462, 463, 464, 464, 464, 464, 464, 464, 0, 0, 0, 465, 465, 466, 462, 472, 472, 472, 477, 478, 479, 480, 481, 481, 482, 482, 483, 484, 484, 485, 485, 485, 487, 487, 489, 494, 495, 496, 497, 497, 498, 499, 499, 500, 500, 501, 502, 502, 505, 505, 505, 509, 514, 514, 515, 516, 516, 516, 517, 516, 519, 519, 520, 524, 525, 525, 526, 526, 526, 527, 528, 528, 529, 526, 532, 536, 536, 536, 540, 540, 540, 550, 550, 550, 550, 550, 0, 0, 0, 587, 589, 600, 600, 600, 600, 600, 0, 0, 0, 635, 637, 641, 641, 641, 641, 641, 0, 0, 0, 642, 647, 647, 647, 647, 647, 0, 0, 0, 648, 653, 654, 654, 655, 656, 657, 658, 658, 658, 659, 660, 660, 660, 660, 660, 660, 0, 0, 0, 0, 660, 660, 660, 660, 660, 660, 0, 0, 0, 0, 0, 0, 660, 660, 660, 660, 660, 660, 0, 0, 0, 0, 0, 661, 662, 658, 665, 666, 670, 670, 670, 671, 671, 673, 673, 770, 770, 776, 776, 776, 776, 776, 778, 778, 779, 779, 780, 780, 782, 786, 786, 786, 792, 792, 0, 792, 792, 0, 0, 0, 792, 792, 792, 0, 0, 0, 792, 792, 0, 0, 0, 792, 792, 792, 0, 0, 0, 792, 792, 792, 0, 0, 0, 792, 792, 792, 792, 0, 0, 793, 796, 797, 798, 799, 800, 800, 802, 804, 804, 804, 805, 806, 807, 809, 810, 810, 811, 812, 812, 813, 813, 813, 814, 816, 817, 818, 819, 819, 820, 820, 821, 823, 823, 824, 824, 825, 826, 827, 827, 830, 831, 833, 833, 834, 837, 839, 843, 844, 845, 846, 847, 847, 848, 848, 849, 850, 852, 852, 853, 853, 855, 859, 859, 859, 863, 871, 871, 0, 871, 0, 0, 872, 874, 875, 876, 876, 877, 879, 881, 882, 883, 884, 884, 884, 885, 886, 887, 887, 888, 888, 889, 889, 891, 891, 884, 895, 895, 895, 896, 896, 897, 898, 898, 899, 902, 906, 906, 906, 907, 907, 907, 907, 908, 908, 910, 910, 914, 914, 914, 915, 915, 915, 915, 916, 916, 918, 918, 981, 981, 985, 985, 985, 989, 990, 990, 990, 991, 991, 991, 992, 992, 992, 993, 996, 996, 1000, 1000, 1000, 1000, 0, 1000, 1000, 1000, 0, 1000, 1000, 1000, 0, 0, 0, 0, 1001, 1001, 1001, 1004, 1005, 1006, 1007, 1009, 1010, 1011, 1013, 1013, 1014, 1047, 1047, 1051, 1053, 1058, 1058, 1058, 1062, 1062, 1062, 1062, 1062, 1156, 1160, 1160, 1164, 1164, 1168, 1168, 1172, 1172, 1176, 1176, 1180, 1180, 1184, 1188, 1188, 1189, 1191, 1191, 1191, 1191, 1192, 1197, 1197, 1201, 1201, 1201, 1205, 1206, 1207, 1208, 1208, 1209, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {59, 60, 65, 66, 73, 78, 79, 82, 87, 88, 99, 104, 105, 107, 114, 115, 116, 117, 118, 119, 129, 130, 131, 132, 133, 134, 135, 139, 140, 157, 158, 159, 160, 161, 162, 167, 168, 169, 170, 171, 172, 173, 174, 176, 177, 178, 179, 183, 186, 189, 193, 204, 205, 206, 214, 215, 220, 221, 222, 223, 224, 225, 233, 234, 235, 236, 237, 238, 253, 254, 256, 257, 258, 259, 260, 262, 263, 265, 266, 267, 268, 269, 271, 277, 278, 279, 280, 281, 291, 292, 297, 298, 301, 302, 307, 308, 311, 315, 316, 318, 319, 330, 335, 336, 337, 339, 340, 341, 342, 347, 348, 349, 351, 352, 361, 366, 367, 370, 371, 376, 377, 380, 384, 385, 387, 388, 392, 393, 413, 414, 417, 422, 423, 424, 425, 430, 431, 432, 437, 438, 441, 442, 447, 448, 451, 455, 458, 462, 467, 468, 473, 474, 477, 478, 483, 484, 487, 491, 492, 495, 501, 502, 525, 526, 529, 534, 535, 536, 537, 542, 543, 544, 549, 550, 553, 557, 560, 563, 564, 569, 570, 571, 576, 577, 580, 584, 587, 590, 594, 597, 598, 603, 604, 605, 610, 611, 614, 618, 621, 624, 628, 629, 631, 637, 638, 642, 643, 655, 656, 659, 664, 665, 666, 667, 672, 673, 674, 679, 680, 683, 687, 690, 691, 692, 694, 705, 706, 707, 719, 720, 723, 728, 729, 730, 731, 736, 737, 738, 743, 744, 747, 751, 754, 755, 756, 758, 769, 770, 771, 783, 784, 785, 786, 787, 792, 793, 794, 795, 796, 797, 798, 799, 800, 803, 804, 806, 818, 819, 820, 823, 828, 829, 830, 835, 836, 837, 838, 839, 840, 843, 844, 845, 852, 862, 863, 864, 865, 868, 873, 874, 875, 881, 882, 883, 891, 892, 893, 894, 897, 902, 903, 904, 905, 906, 907, 913, 918, 919, 920, 925, 926, 927, 934, 935, 940, 941, 946, 947, 950, 954, 964, 966, 973, 974, 979, 980, 985, 986, 989, 993, 1000, 1002, 1009, 1010, 1015, 1016, 1021, 1022, 1025, 1029, 1032, 1041, 1042, 1047, 1048, 1053, 1054, 1057, 1061, 1064, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1101, 1106, 1107, 1108, 1109, 1114, 1115, 1116, 1121, 1122, 1125, 1129, 1132, 1135, 1136, 1141, 1142, 1143, 1148, 1149, 1152, 1156, 1159, 1162, 1166, 1169, 1170, 1175, 1176, 1177, 1182, 1183, 1186, 1190, 1193, 1196, 1200, 1201, 1203, 1209, 1210, 1217, 1218, 1223, 1224, 1225, 1227, 1228, 1246, 1247, 1258, 1259, 1260, 1261, 1262, 1263, 1268, 1269, 1270, 1271, 1272, 1274, 1279, 1280, 1281, 1324, 1329, 1330, 1333, 1338, 1339, 1342, 1346, 1349, 1350, 1355, 1356, 1359, 1363, 1366, 1371, 1372, 1375, 1379, 1382, 1383, 1388, 1389, 1392, 1396, 1399, 1400, 1405, 1406, 1409, 1413, 1416, 1417, 1418, 1423, 1424, 1427, 1431, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440, 1441, 1446, 1447, 1448, 1449, 1451, 1454, 1459, 1460, 1461, 1466, 1467, 1468, 1473, 1474, 1476, 1477, 1478, 1479, 1480, 1481, 1486, 1487, 1489, 1490, 1493, 1498, 1499, 1500, 1501, 1506, 1509, 1510, 1516, 1521, 1522, 1525, 1531, 1542, 1543, 1544, 1545, 1548, 1553, 1554, 1555, 1556, 1557, 1563, 1568, 1569, 1570, 1572, 1577, 1578, 1579, 1582, 1605, 1610, 1611, 1614, 1616, 1619, 1623, 1625, 1626, 1627, 1632, 1633, 1636, 1638, 1639, 1640, 1641, 1644, 1649, 1650, 1651, 1652, 1657, 1658, 1663, 1664, 1665, 1668, 1669, 1672, 1678, 1679, 1684, 1685, 1690, 1691, 1694, 1699, 1700, 1704, 1713, 1718, 1719, 1721, 1722, 1723, 1728, 1729, 1730, 1732, 1733, 1742, 1747, 1748, 1750, 1751, 1752, 1757, 1758, 1759, 1761, 1762, 1776, 1777, 1782, 1783, 1788, 1799, 1800, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1809, 1813, 1814, 1834, 1835, 1836, 1841, 1842, 1845, 1846, 1851, 1852, 1855, 1856, 1861, 1862, 1865, 1869, 1872, 1876, 1877, 1878, 1881, 1882, 1883, 1884, 1885, 1886, 1887, 1888, 1893, 1894, 1899, 1904, 1905, 1907, 1913, 1914, 1915, 1922, 1923, 1924, 1925, 1926, 1942, 1947, 1948, 1952, 1953, 1957, 1958, 1962, 1963, 1967, 1968, 1972, 1973, 1976, 1983, 1988, 1989, 1992, 1993, 1994, 1995, 1996, 2002, 2003, 2008, 2009, 2010, 2019, 2020, 2021, 2022, 2023, 2026, 2031, 2032, 2033, 2034, 2035, 2036, 2037, 2046, 2049, 2052, 2056, 2060, 2063, 2066};
/* BEGIN LINEINFO 
assign 1 242 59
new 0 242 59
capacitySet 1 243 60
assign 1 252 65
new 0 252 65
new 1 252 66
assign 1 256 73
undef 1 256 78
assign 1 257 79
new 0 257 79
assign 1 258 82
equals 1 258 87
return 1 259 88
assign 1 295 99
greater 1 295 104
setValue 1 296 105
setValue 1 298 107
assign 1 302 114
new 0 302 114
new 1 302 115
assign 1 303 116
new 0 303 116
setValue 1 303 117
assign 1 304 118
new 0 304 118
setHex 2 304 119
assign 1 308 129
new 0 308 129
assign 1 308 130
getCode 2 308 130
assign 1 308 131
new 0 308 131
assign 1 308 132
new 0 308 132
assign 1 308 133
new 0 308 133
assign 1 308 134
toString 3 308 134
return 1 308 135
assign 1 312 139
hexNew 1 312 139
setCode 2 313 140
assign 1 317 157
toString 0 317 157
assign 1 319 158
new 0 319 158
assign 1 320 159
sizeGet 0 320 159
setValue 1 320 160
addValue 1 321 161
assign 1 323 162
lesser 1 323 167
assign 1 324 168
new 0 324 168
assign 1 324 169
add 1 324 169
assign 1 324 170
new 0 324 170
assign 1 324 171
multiply 1 324 171
assign 1 324 172
new 0 324 172
assign 1 324 173
divide 1 324 173
capacitySet 1 325 174
assign 1 327 176
new 0 327 176
assign 1 327 177
zeroGet 0 327 177
assign 1 327 178
sizeGet 0 327 178
copyValue 4 327 179
return 1 331 183
return 1 335 186
addValue 1 339 189
write 1 343 193
assign 1 353 204
copy 0 353 204
clear 0 354 205
return 1 355 206
assign 1 359 214
new 0 359 214
assign 1 359 215
greater 1 359 220
assign 1 360 221
new 0 360 221
assign 1 360 222
new 0 360 222
setIntUnchecked 2 360 223
assign 1 361 224
new 0 361 224
setValue 1 361 225
assign 1 366 233
new 0 366 233
new 1 366 234
assign 1 367 235
new 0 367 235
setValue 1 367 236
assign 1 368 237
new 0 368 237
setCodeUnchecked 2 368 238
assign 1 372 253
new 0 372 253
assign 1 373 254
ends 1 373 254
assign 1 374 256
new 0 374 256
assign 1 374 257
sizeGet 0 374 257
assign 1 374 258
subtract 1 374 258
assign 1 374 259
substring 2 374 259
return 1 374 260
assign 1 376 262
new 0 376 262
assign 1 377 263
ends 1 377 263
assign 1 378 265
new 0 378 265
assign 1 378 266
sizeGet 0 378 266
assign 1 378 267
subtract 1 378 267
assign 1 378 268
substring 2 378 268
return 1 378 269
return 1 380 271
assign 1 384 277
new 0 384 277
assign 1 384 278
add 1 384 278
assign 1 384 279
new 1 384 279
addValue 1 385 280
return 1 386 281
assign 1 390 291
find 1 390 291
assign 1 391 292
undef 1 391 297
assign 1 0 298
assign 1 391 301
new 0 391 301
assign 1 391 302
notEquals 1 391 307
assign 1 0 308
assign 1 0 311
assign 1 392 315
new 0 392 315
return 1 392 316
assign 1 394 318
new 0 394 318
return 1 394 319
assign 1 398 330
undef 1 398 335
assign 1 398 336
new 0 398 336
return 1 398 337
assign 1 399 339
sizeGet 0 399 339
assign 1 399 340
subtract 1 399 340
assign 1 399 341
find 2 399 341
assign 1 400 342
undef 1 400 347
assign 1 401 348
new 0 401 348
return 1 401 349
assign 1 403 351
new 0 403 351
return 1 403 352
assign 1 407 361
undef 1 407 366
assign 1 0 367
assign 1 407 370
find 1 407 370
assign 1 407 371
undef 1 407 376
assign 1 0 377
assign 1 0 380
assign 1 408 384
new 0 408 384
return 1 408 385
assign 1 410 387
new 0 410 387
return 1 410 388
assign 1 414 392
isInteger 0 414 392
return 1 414 393
assign 1 418 413
new 0 418 413
assign 1 419 414
new 0 419 414
assign 1 419 417
lesser 1 419 422
getInt 2 420 423
assign 1 421 424
new 0 421 424
assign 1 421 425
equals 1 421 430
assign 1 421 431
new 0 421 431
assign 1 421 432
equals 1 421 437
assign 1 0 438
assign 1 421 441
new 0 421 441
assign 1 421 442
equals 1 421 447
assign 1 0 448
assign 1 0 451
assign 1 0 455
assign 1 0 458
assign 1 0 462
assign 1 423 467
new 0 423 467
assign 1 423 468
greater 1 423 473
assign 1 0 474
assign 1 423 477
new 0 423 477
assign 1 423 478
lesser 1 423 483
assign 1 0 484
assign 1 0 487
assign 1 424 491
new 0 424 491
return 1 424 492
incrementValue 0 419 495
assign 1 427 501
new 0 427 501
return 1 427 502
assign 1 431 525
new 0 431 525
assign 1 432 526
new 0 432 526
assign 1 432 529
lesser 1 432 534
getInt 2 433 535
assign 1 434 536
new 0 434 536
assign 1 434 537
greater 1 434 542
assign 1 434 543
new 0 434 543
assign 1 434 544
lesser 1 434 549
assign 1 0 550
assign 1 0 553
assign 1 0 557
assign 1 0 560
assign 1 434 563
new 0 434 563
assign 1 434 564
greater 1 434 569
assign 1 434 570
new 0 434 570
assign 1 434 571
lesser 1 434 576
assign 1 0 577
assign 1 0 580
assign 1 0 584
assign 1 0 587
assign 1 0 590
assign 1 0 594
assign 1 434 597
new 0 434 597
assign 1 434 598
greater 1 434 603
assign 1 434 604
new 0 434 604
assign 1 434 605
lesser 1 434 610
assign 1 0 611
assign 1 0 614
assign 1 0 618
assign 1 0 621
assign 1 0 624
assign 1 435 628
new 0 435 628
return 1 435 629
incrementValue 0 432 631
assign 1 438 637
new 0 438 637
return 1 438 638
assign 1 442 642
isAlphaNumGet 0 442 642
return 1 442 643
assign 1 446 655
new 0 446 655
assign 1 447 656
new 0 447 656
assign 1 447 659
lesser 1 447 664
getInt 2 448 665
assign 1 449 666
new 0 449 666
assign 1 449 667
greater 1 449 672
assign 1 449 673
new 0 449 673
assign 1 449 674
lesser 1 449 679
assign 1 0 680
assign 1 0 683
assign 1 0 687
assign 1 450 690
new 0 450 690
addValue 1 450 691
setIntUnchecked 2 451 692
incrementValue 0 447 694
assign 1 457 705
copy 0 457 705
assign 1 457 706
lowerValue 0 457 706
return 1 457 707
assign 1 461 719
new 0 461 719
assign 1 462 720
new 0 462 720
assign 1 462 723
lesser 1 462 728
getInt 2 463 729
assign 1 464 730
new 0 464 730
assign 1 464 731
greater 1 464 736
assign 1 464 737
new 0 464 737
assign 1 464 738
lesser 1 464 743
assign 1 0 744
assign 1 0 747
assign 1 0 751
assign 1 465 754
new 0 465 754
subtractValue 1 465 755
setIntUnchecked 2 466 756
incrementValue 0 462 758
assign 1 472 769
copy 0 472 769
assign 1 472 770
upperValue 0 472 770
return 1 472 771
assign 1 477 783
new 0 477 783
assign 1 478 784
new 0 478 784
assign 1 479 785
new 0 479 785
assign 1 480 786
find 2 480 786
assign 1 481 787
def 1 481 792
assign 1 482 793
substring 2 482 793
addValue 1 482 794
addValue 1 483 795
assign 1 484 796
sizeGet 0 484 796
assign 1 484 797
add 1 484 797
assign 1 485 798
sizeGet 0 485 798
assign 1 485 799
substring 2 485 799
addValue 1 485 800
assign 1 487 803
copy 0 487 803
return 1 487 804
return 1 489 806
assign 1 494 818
new 0 494 818
assign 1 495 819
new 0 495 819
assign 1 496 820
new 0 496 820
assign 1 497 823
def 1 497 828
assign 1 498 829
find 2 498 829
assign 1 499 830
def 1 499 835
assign 1 500 836
substring 2 500 836
addValue 1 500 837
addValue 1 501 838
assign 1 502 839
sizeGet 0 502 839
assign 1 502 840
add 1 502 840
assign 1 505 843
sizeGet 0 505 843
assign 1 505 844
substring 2 505 844
addValue 1 505 845
return 1 509 852
assign 1 514 862
new 0 514 862
assign 1 514 863
new 1 514 863
assign 1 515 864
mbiterGet 0 515 864
assign 1 516 865
new 0 516 865
assign 1 516 868
lesser 1 516 873
next 1 517 874
incrementValue 0 516 875
assign 1 519 881
next 1 519 881
assign 1 519 882
toString 0 519 882
return 1 520 883
assign 1 524 891
new 0 524 891
assign 1 525 892
new 0 525 892
setValue 1 525 893
assign 1 526 894
new 0 526 894
assign 1 526 897
lesser 1 526 902
getInt 2 527 903
assign 1 528 904
new 0 528 904
multiplyValue 1 528 905
addValue 1 529 906
incrementValue 0 526 907
return 1 532 913
assign 1 536 918
new 0 536 918
assign 1 536 919
hashValue 1 536 919
return 1 536 920
assign 1 540 925
new 0 540 925
assign 1 540 926
getCode 2 540 926
return 1 540 927
assign 1 550 934
new 0 550 934
assign 1 550 935
greaterEquals 1 550 940
assign 1 550 941
greater 1 550 946
assign 1 0 947
assign 1 0 950
assign 1 0 954
return 1 587 964
return 1 589 966
assign 1 600 973
new 0 600 973
assign 1 600 974
greaterEquals 1 600 979
assign 1 600 980
greater 1 600 985
assign 1 0 986
assign 1 0 989
assign 1 0 993
return 1 635 1000
return 1 637 1002
assign 1 641 1009
new 0 641 1009
assign 1 641 1010
greaterEquals 1 641 1015
assign 1 641 1016
greater 1 641 1021
assign 1 0 1022
assign 1 0 1025
assign 1 0 1029
setIntUnchecked 2 642 1032
assign 1 647 1041
new 0 647 1041
assign 1 647 1042
greaterEquals 1 647 1047
assign 1 647 1048
greater 1 647 1053
assign 1 0 1054
assign 1 0 1057
assign 1 0 1061
setCodeUnchecked 2 648 1064
assign 1 653 1092
assign 1 654 1093
sizeGet 0 654 1093
assign 1 654 1094
copy 0 654 1094
assign 1 655 1095
new 1 655 1095
assign 1 656 1096
new 0 656 1096
assign 1 657 1097
new 0 657 1097
assign 1 658 1098
new 0 658 1098
assign 1 658 1101
lesser 1 658 1106
getInt 2 659 1107
assign 1 660 1108
new 0 660 1108
assign 1 660 1109
greater 1 660 1114
assign 1 660 1115
new 0 660 1115
assign 1 660 1116
lesser 1 660 1121
assign 1 0 1122
assign 1 0 1125
assign 1 0 1129
assign 1 0 1132
assign 1 660 1135
new 0 660 1135
assign 1 660 1136
greater 1 660 1141
assign 1 660 1142
new 0 660 1142
assign 1 660 1143
lesser 1 660 1148
assign 1 0 1149
assign 1 0 1152
assign 1 0 1156
assign 1 0 1159
assign 1 0 1162
assign 1 0 1166
assign 1 660 1169
new 0 660 1169
assign 1 660 1170
greater 1 660 1175
assign 1 660 1176
new 0 660 1176
assign 1 660 1177
lesser 1 660 1182
assign 1 0 1183
assign 1 0 1186
assign 1 0 1190
assign 1 0 1193
assign 1 0 1196
setIntUnchecked 2 661 1200
incrementValue 0 662 1201
incrementValue 0 658 1203
sizeSet 1 665 1209
return 1 666 1210
assign 1 670 1217
new 0 670 1217
assign 1 670 1218
lesserEquals 1 670 1223
assign 1 671 1224
new 0 671 1224
return 1 671 1225
assign 1 673 1227
new 0 673 1227
return 1 673 1228
assign 1 770 1246
rfind 1 770 1246
return 1 770 1247
assign 1 776 1258
copy 0 776 1258
assign 1 776 1259
reverseBytes 0 776 1259
assign 1 776 1260
copy 0 776 1260
assign 1 776 1261
reverseBytes 0 776 1261
assign 1 776 1262
find 1 776 1262
assign 1 778 1263
def 1 778 1268
assign 1 779 1269
sizeGet 0 779 1269
addValue 1 779 1270
assign 1 780 1271
subtract 1 780 1271
return 1 780 1272
return 1 782 1274
assign 1 786 1279
new 0 786 1279
assign 1 786 1280
find 2 786 1280
return 1 786 1281
assign 1 792 1324
undef 1 792 1329
assign 1 0 1330
assign 1 792 1333
undef 1 792 1338
assign 1 0 1339
assign 1 0 1342
assign 1 0 1346
assign 1 792 1349
new 0 792 1349
assign 1 792 1350
lesser 1 792 1355
assign 1 0 1356
assign 1 0 1359
assign 1 0 1363
assign 1 792 1366
greaterEquals 1 792 1371
assign 1 0 1372
assign 1 0 1375
assign 1 0 1379
assign 1 792 1382
sizeGet 0 792 1382
assign 1 792 1383
greater 1 792 1388
assign 1 0 1389
assign 1 0 1392
assign 1 0 1396
assign 1 792 1399
new 0 792 1399
assign 1 792 1400
equals 1 792 1405
assign 1 0 1406
assign 1 0 1409
assign 1 0 1413
assign 1 792 1416
sizeGet 0 792 1416
assign 1 792 1417
new 0 792 1417
assign 1 792 1418
equals 1 792 1423
assign 1 0 1424
assign 1 0 1427
return 1 793 1431
assign 1 796 1433
assign 1 797 1434
copy 0 797 1434
assign 1 798 1435
new 0 798 1435
assign 1 799 1436
new 0 799 1436
assign 1 800 1437
new 0 800 1437
getInt 2 800 1438
assign 1 802 1439
sizeGet 0 802 1439
assign 1 804 1440
new 0 804 1440
assign 1 804 1441
greater 1 804 1446
assign 1 805 1447
new 0 805 1447
assign 1 806 1448
new 0 806 1448
assign 1 807 1449
new 0 807 1449
assign 1 809 1451
new 0 809 1451
assign 1 810 1454
lesser 1 810 1459
getInt 2 811 1460
assign 1 812 1461
equals 1 812 1466
assign 1 813 1467
new 0 813 1467
assign 1 813 1468
equals 1 813 1473
return 1 814 1474
setValue 1 816 1476
incrementValue 0 817 1477
setValue 1 818 1478
assign 1 819 1479
sizeGet 0 819 1479
addValue 1 819 1480
assign 1 820 1481
greater 1 820 1486
return 1 821 1487
assign 1 823 1489
new 0 823 1489
setValue 1 823 1490
assign 1 824 1493
lesser 1 824 1498
getInt 2 825 1499
getInt 2 826 1500
assign 1 827 1501
notEquals 1 827 1506
incrementValue 0 830 1509
incrementValue 0 831 1510
assign 1 833 1516
equals 1 833 1521
return 1 834 1522
incrementValue 0 837 1525
return 1 839 1531
assign 1 843 1542
new 0 843 1542
assign 1 844 1543
new 0 844 1543
assign 1 845 1544
find 2 845 1544
assign 1 846 1545
sizeGet 0 846 1545
assign 1 847 1548
def 1 847 1553
assign 1 848 1554
substring 2 848 1554
addValue 1 848 1555
assign 1 849 1556
add 1 849 1556
assign 1 850 1557
find 2 850 1557
assign 1 852 1563
lesser 1 852 1568
assign 1 853 1569
substring 2 853 1569
addValue 1 853 1570
return 1 855 1572
assign 1 859 1577
new 0 859 1577
assign 1 859 1578
join 2 859 1578
return 1 859 1579
return 1 863 1582
assign 1 871 1605
undef 1 871 1610
assign 1 0 1611
assign 1 871 1614
otherType 1 871 1614
assign 1 0 1616
assign 1 0 1619
return 1 872 1623
assign 1 874 1625
assign 1 875 1626
sizeGet 0 875 1626
assign 1 876 1627
greater 1 876 1632
assign 1 877 1633
assign 1 879 1636
assign 1 881 1638
new 0 881 1638
assign 1 882 1639
new 0 882 1639
assign 1 883 1640
new 0 883 1640
assign 1 884 1641
new 0 884 1641
assign 1 884 1644
lesser 1 884 1649
getCode 2 885 1650
getCode 2 886 1651
assign 1 887 1652
notEquals 1 887 1657
assign 1 888 1658
greater 1 888 1663
assign 1 889 1664
new 0 889 1664
return 1 889 1665
assign 1 891 1668
new 0 891 1668
return 1 891 1669
incrementValue 0 884 1672
assign 1 895 1678
new 0 895 1678
assign 1 895 1679
equals 1 895 1684
assign 1 896 1685
greater 1 896 1690
assign 1 897 1691
new 0 897 1691
assign 1 898 1694
greater 1 898 1699
assign 1 899 1700
new 0 899 1700
return 1 902 1704
assign 1 906 1713
undef 1 906 1718
return 1 906 1719
assign 1 907 1721
compare 1 907 1721
assign 1 907 1722
new 0 907 1722
assign 1 907 1723
equals 1 907 1728
assign 1 908 1729
new 0 908 1729
return 1 908 1730
assign 1 910 1732
new 0 910 1732
return 1 910 1733
assign 1 914 1742
undef 1 914 1747
return 1 914 1748
assign 1 915 1750
compare 1 915 1750
assign 1 915 1751
new 0 915 1751
assign 1 915 1752
equals 1 915 1757
assign 1 916 1758
new 0 916 1758
return 1 916 1759
assign 1 918 1761
new 0 918 1761
return 1 918 1762
assign 1 981 1776
new 0 981 1776
return 1 981 1777
assign 1 985 1782
equals 1 985 1782
assign 1 985 1783
not 0 985 1788
return 1 985 1788
assign 1 989 1799
toString 0 989 1799
assign 1 990 1800
sizeGet 0 990 1800
assign 1 990 1801
add 1 990 1801
assign 1 990 1802
new 1 990 1802
assign 1 991 1803
new 0 991 1803
assign 1 991 1804
new 0 991 1804
copyValue 4 991 1805
assign 1 992 1806
new 0 992 1806
assign 1 992 1807
sizeGet 0 992 1807
copyValue 4 992 1808
return 1 993 1809
assign 1 996 1813
new 0 996 1813
return 1 996 1814
assign 1 1000 1834
new 0 1000 1834
assign 1 1000 1835
zeroGet 0 1000 1835
assign 1 1000 1836
lesser 1 1000 1841
assign 1 0 1842
assign 1 1000 1845
sizeGet 0 1000 1845
assign 1 1000 1846
greater 1 1000 1851
assign 1 0 1852
assign 1 1000 1855
sizeGet 0 1000 1855
assign 1 1000 1856
greater 1 1000 1861
assign 1 0 1862
assign 1 0 1865
assign 1 0 1869
assign 1 0 1872
assign 1 1001 1876
new 0 1001 1876
assign 1 1001 1877
new 1 1001 1877
throw 1 1001 1878
assign 1 1004 1881
new 0 1004 1881
setValue 1 1005 1882
subtractValue 1 1006 1883
assign 1 1007 1884
assign 1 1009 1885
new 0 1009 1885
setValue 1 1010 1886
addValue 1 1011 1887
assign 1 1013 1888
greater 1 1013 1893
capacitySet 1 1014 1894
assign 1 1047 1899
greater 1 1047 1904
setValue 1 1051 1905
return 1 1053 1907
assign 1 1058 1913
sizeGet 0 1058 1913
assign 1 1058 1914
substring 2 1058 1914
return 1 1058 1915
assign 1 1062 1922
subtract 1 1062 1922
assign 1 1062 1923
new 1 1062 1923
assign 1 1062 1924
new 0 1062 1924
assign 1 1062 1925
copyValue 4 1062 1925
return 1 1062 1926
output 0 1156 1942
assign 1 1160 1947
new 1 1160 1947
return 1 1160 1948
assign 1 1164 1952
new 1 1164 1952
return 1 1164 1953
assign 1 1168 1957
new 1 1168 1957
return 1 1168 1958
assign 1 1172 1962
new 1 1172 1962
return 1 1172 1963
assign 1 1176 1967
new 1 1176 1967
return 1 1176 1968
assign 1 1180 1972
new 1 1180 1972
return 1 1180 1973
return 1 1184 1976
assign 1 1188 1983
undef 1 1188 1988
new 0 1189 1989
assign 1 1191 1992
sizeGet 0 1191 1992
assign 1 1191 1993
new 0 1191 1993
assign 1 1191 1994
add 1 1191 1994
new 1 1191 1995
addValue 1 1192 1996
assign 1 1197 2002
new 0 1197 2002
return 1 1197 2003
assign 1 1201 2008
new 0 1201 2008
assign 1 1201 2009
strip 1 1201 2009
return 1 1201 2010
assign 1 1205 2019
new 0 1205 2019
assign 1 1206 2020
new 0 1206 2020
assign 1 1207 2021
new 0 1207 2021
assign 1 1208 2022
new 0 1208 2022
assign 1 1208 2023
subtract 1 1208 2023
assign 1 1209 2026
greater 1 1209 2031
getInt 2 1210 2032
getInt 2 1211 2033
setInt 2 1212 2034
setInt 2 1213 2035
incrementValue 0 1214 2036
decrementValue 0 1215 2037
return 1 0 2046
return 1 0 2049
assign 1 0 2052
assign 1 0 2056
return 1 0 2060
return 1 0 2063
assign 1 0 2066
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 253089486: return bem_output_0();
case 1597243429: return bem_upper_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -836370094: return bem_isEmptyGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -2118708930: return bem_new_0();
case 740565953: return bem_extractString_0();
case 771127733: return bem_multiByteIteratorGet_0();
case 482177670: return bem_stringIteratorGet_0();
case 1984704399: return bem_biterGet_0();
case 1409293062: return bem_sizeGetDirect_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1120247824: return bem_byteIteratorGet_0();
case 123269264: return bem_sizeGet_0();
case 326083590: return bem_isInteger_0();
case 1947374815: return bem_open_0();
case 1586815430: return bem_fieldIteratorGet_0();
case -1537094449: return bem_chomp_0();
case -1618121415: return bem_mbiterGet_0();
case 1447596838: return bem_vstringSet_0();
case 1834246217: return bem_classNameGet_0();
case -893093197: return bem_toString_0();
case -1841381746: return bem_isIntegerGet_0();
case 954703233: return bem_create_0();
case 260124928: return bem_capacityGet_0();
case -193582610: return bem_tagGet_0();
case 1153344161: return bem_serializeContents_0();
case -1076915155: return bem_serializeToString_0();
case -2026067879: return bem_readString_0();
case 1151038820: return bem_lower_0();
case 1974505938: return bem_hashGet_0();
case 1186846401: return bem_toAlphaNum_0();
case 421177749: return bem_print_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case -978188014: return bem_readBuffer_0();
case 1335628955: return bem_isAlphaNumGet_0();
case -1653939165: return bem_iteratorGet_0();
case 1251255223: return bem_capacityGetDirect_0();
case 1873326764: return bem_lowerValue_0();
case 289782757: return bem_vstringGet_0();
case 925559139: return bem_close_0();
case -975498393: return bem_fieldNamesGet_0();
case -1166381907: return bem_clear_0();
case -427708830: return bem_reverseBytes_0();
case 1654799933: return bem_strip_0();
case -2016066764: return bem_upperValue_0();
case -1016967477: return bem_isAlphaNumericGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1967907235: return bem_sizeSet_1(bevd_0);
case 1007780901: return bem_add_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -239354312: return bem_compare_1(bevd_0);
case 2032172558: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case 600661260: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -1648734891: return bem_addValue_1(bevd_0);
case -270190367: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case 659221263: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -665907845: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1618858264: return bem_sizeSetDirect_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1433271210: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case -1579143808: return bem_capacitySetDirect_1(bevd_0);
case -2130252112: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case -1724613323: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case 1002801424: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -805834986: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 1256229611: return bem_writeTo_1(bevd_0);
case 779059147: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 1014305749: return bem_codeNew_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 59504167: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -487853278: return bem_write_1(bevd_0);
case -730699213: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 119748808: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -501724714: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1637949895: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case 1916991214: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1834941570: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -300503760: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1060702275: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1441119009: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1867266038: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -969101444: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -945494192: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -887226647: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 218230059: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 394071772: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1523301577: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1938767623: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1892842301: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
}
