namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_6_TextString : BEC_2_6_6_SystemObject {
public BEC_2_4_6_TextString() { }
static BEC_2_4_6_TextString() { }

   
    public byte[] bevi_bytes;
    public BEC_2_4_6_TextString(byte[] bevi_bytes) { 
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public BEC_2_4_6_TextString(byte[] bevi_bytes, int bevi_length) { 
      //do copy, isOnce
      this.bevi_bytes = new byte[bevi_length];
      Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
      bevp_size = new BEC_2_4_3_MathInt(bevi_length);
      bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(int bevi_length, byte[] bevi_bytes) { 
        //do copy, not isOnce
        this.bevi_bytes = new byte[bevi_length];
        Array.Copy( bevi_bytes, 0, this.bevi_bytes, 0, bevi_length );
        bevp_size = new BEC_2_4_3_MathInt(bevi_length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_length);
    }
    public BEC_2_4_6_TextString(string bevi_string) {
        byte[] bevi_bytes = System.Text.Encoding.UTF8.GetBytes(bevi_string);
        this.bevi_bytes = bevi_bytes; 
        bevp_size = new BEC_2_4_3_MathInt(bevi_bytes.Length);
        bevp_capacity = new BEC_2_4_3_MathInt(bevi_bytes.Length);
    }
    public string bems_toCsString() {
        string csString = System.Text.Encoding.UTF8.GetString(bevi_bytes, 0, bevp_size.bevi_int);
        return csString;
    }
    
   private static byte[] becc_BEC_2_4_6_TextString_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_4_6_TextString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_TextString_bels_0 = {0x0A};
private static byte[] bece_BEC_2_4_6_TextString_bels_1 = {0x63,0x6F,0x70,0x79,0x56,0x61,0x6C,0x75,0x65,0x20,0x72,0x65,0x71,0x75,0x65,0x73,0x74,0x20,0x6F,0x75,0x74,0x20,0x6F,0x66,0x20,0x62,0x6F,0x75,0x6E,0x64,0x73};
public static new BEC_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_inst;

public static new BET_2_4_6_TextString bece_BEC_2_4_6_TextString_bevs_type;

public BEC_2_4_3_MathInt bevp_size;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_leni;
public BEC_2_4_3_MathInt bevp_sizi;
public BEC_2_4_6_TextString bem_vstringGet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_vstringSet_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_new_1(BEC_2_4_3_MathInt beva__capacity) {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_capacitySet_1(beva__capacity);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySet_1(BEC_2_4_3_MathInt beva_ncap) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_capacity == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 277*/ {
bevp_capacity = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 278*/
 else /* Line: 277*/ {
if (bevp_capacity.bevi_int == beva_ncap.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 279*/ {
return this;
} /* Line: 280*/
} /* Line: 277*/

      if (this.bevi_bytes == null) {
        this.bevi_bytes = new byte[beva_ncap.bevi_int];
      } else {
        byte[] bevls_bytes = new byte[beva_ncap.bevi_int];
        Array.Copy(this.bevi_bytes, bevls_bytes, Math.Min(this.bevi_bytes.Length, bevls_bytes.Length));
        this.bevi_bytes = bevls_bytes;
      }
      if (bevp_size.bevi_int > beva_ncap.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 316*/ {
bevp_size.bevi_int = beva_ncap.bevi_int;
} /* Line: 317*/
bevp_capacity.bevi_int = beva_ncap.bevi_int;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_hexNew_1(BEC_2_4_6_TextString beva_val) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_setHex_2(bevt_2_ta_ph, beva_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getHex_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_1_ta_ph = bem_getCode_2(beva_pos, bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bevt_1_ta_ph.bem_toString_3(bevt_3_ta_ph, bevt_4_ta_ph, bevt_5_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setHex_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_6_TextString beva_hval) {
BEC_2_4_3_MathInt bevl_val = null;
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(beva_hval);
bem_setCode_2(beva_pos, bevl_val);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_addValue_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(-467511392);
if (bevp_leni == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 339*/ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 341*/
bevt_1_ta_ph = bevl_str.bem_sizeGet_0();
bevp_sizi.bevi_int = bevt_1_ta_ph.bevi_int;
bevp_sizi.bevi_int += bevp_size.bevi_int;
if (bevp_capacity.bevi_int < bevp_sizi.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 346*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_4_ta_ph = bevp_sizi.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevt_3_ta_ph = bevt_4_ta_ph.bem_multiply_1(bevt_6_ta_ph);
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_nsize = bevt_3_ta_ph.bem_divide_1(bevt_7_ta_ph);
bem_capacitySet_1(bevl_nsize);
} /* Line: 348*/
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = bevl_str.bem_sizeGet_0();
bem_copyValue_4(bevl_str, bevt_8_ta_ph, bevt_9_ta_ph, bevp_size);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBuffer_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readString_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_write_1(BEC_2_6_6_SystemObject beva_stri) {
bem_addValue_1(beva_stri);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_writeTo_1(BEC_2_6_6_SystemObject beva_w) {
beva_w.bemd_1(-231846695, this);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_open_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_close_0() {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_extractString_0() {
BEC_2_4_6_TextString bevl_str = null;
bevl_str = (BEC_2_4_6_TextString) bem_copy_0();
bem_clear_0();
return bevl_str;
} /*method end*/
public BEC_2_4_6_TextString bem_clear_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 382*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_setIntUnchecked_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_size.bevi_int = bevt_4_ta_ph.bevi_int;
} /* Line: 384*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_codeNew_1(BEC_2_6_6_SystemObject beva_codei) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bem_new_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_size.bevi_int = bevt_1_ta_ph.bevi_int;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_setCodeUnchecked_2(bevt_2_ta_ph, (BEC_2_4_3_MathInt) beva_codei );
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_chomp_0() {
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_0_ta_ph = bem_ends_1(bevl_nl);
if (bevt_0_ta_ph.bevi_bool)/* Line: 396*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_3_ta_ph = bevp_size.bem_subtract_1(bevt_4_ta_ph);
bevt_1_ta_ph = bem_substring_2(bevt_2_ta_ph, bevt_3_ta_ph);
return bevt_1_ta_ph;
} /* Line: 397*/
bevl_nl = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_TextString_bels_0));
bevt_5_ta_ph = bem_ends_1(bevl_nl);
if (bevt_5_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = bevl_nl.bem_sizeGet_0();
bevt_8_ta_ph = bevp_size.bem_subtract_1(bevt_9_ta_ph);
bevt_6_ta_ph = bem_substring_2(bevt_7_ta_ph, bevt_8_ta_ph);
return bevt_6_ta_ph;
} /* Line: 401*/
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_6_TextString bevl_c = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_c = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_c.bem_addValue_1(this);
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_5_4_LogicBool bem_begins_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_found = bem_find_1(beva_str);
if (bevl_found == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 414*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 414*/ {
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_found.bevi_int != bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 414*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 414*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 414*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 414*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 415*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ends_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 421*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /* Line: 421*/
bevt_3_ta_ph = beva_str.bem_sizeGet_0();
bevt_2_ta_ph = bevp_size.bem_subtract_1(bevt_3_ta_ph);
bevl_found = bem_find_2(beva_str, bevt_2_ta_ph);
if (bevl_found == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 423*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /* Line: 424*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_str) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 430*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 430*/ {
bevt_3_ta_ph = bem_find_1(beva_str);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 430*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 430*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 430*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 430*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 431*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isIntegerGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isInteger_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isInteger_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 442*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 442*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int == bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 444*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 444*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 444*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 444*/
 else /* Line: 444*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 444*/ {
} /* Line: 444*/
 else /* Line: 444*/ {
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57));
if (bevl_ic.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 446*/ {
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
if (bevl_ic.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 446*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 446*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 446*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 446*/ {
bevt_13_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_13_ta_ph;
} /* Line: 447*/
} /* Line: 444*/
bevl_j.bevi_int++;
} /* Line: 442*/
 else /* Line: 442*/ {
break;
} /* Line: 442*/
} /* Line: 442*/
bevt_14_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_14_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumGet_0() {
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 455*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 455*/ {
bem_getInt_2(bevl_j, bevl_ic);
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
if (bevl_ic.bevi_int < bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
 else /* Line: 457*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
if (bevl_ic.bevi_int < bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
 else /* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_13_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_13_ta_ph.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_15_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
if (bevl_ic.bevi_int < bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
 else /* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 457*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 457*/
if (!(bevt_0_ta_anchor.bevi_bool))/* Line: 457*/ {
bevt_16_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 458*/
bevl_j.bevi_int++;
} /* Line: 455*/
 else /* Line: 455*/ {
break;
} /* Line: 455*/
} /* Line: 455*/
bevt_17_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_17_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAlphaNumericGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAlphaNumGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_lowerValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 470*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 470*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 472*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 472*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 472*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 472*/
 else /* Line: 472*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 472*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bevi_int += bevt_6_ta_ph.bevi_int;
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 474*/
bevl_j.bevi_int++;
} /* Line: 470*/
 else /* Line: 470*/ {
break;
} /* Line: 470*/
} /* Line: 470*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lower_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_lowerValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_upperValue_0() {
BEC_2_4_3_MathInt bevl_vc = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevl_vc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 485*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 485*/ {
bem_getInt_2(bevl_j, bevl_vc);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
if (bevl_vc.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 487*/ {
bevt_5_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
if (bevl_vc.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 487*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 487*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 487*/
 else /* Line: 487*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 487*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_vc.bem_subtractValue_1(bevt_6_ta_ph);
bem_setIntUnchecked_2(bevl_j, bevl_vc);
} /* Line: 489*/
bevl_j.bevi_int++;
} /* Line: 485*/
 else /* Line: 485*/ {
break;
} /* Line: 485*/
} /* Line: 485*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_upper_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_upperValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap0_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_ta_ph = bem_split_1(beva_from);
bevt_0_ta_ph = bevt_1_ta_ph.bem_join_2(beva_to, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swapFirst_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 509*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_1_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_2_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = bem_sizeGet_0();
bevt_3_ta_ph = bem_substring_2(bevl_last, bevt_4_ta_ph);
bevl_res.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 513*/
 else /* Line: 514*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) beva_from.bem_copy_0();
return bevt_5_ta_ph;
} /* Line: 515*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_swap_2(BEC_2_4_6_TextString beva_from, BEC_2_4_6_TextString beva_to) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nxt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 525*/ {
if (bevl_nxt == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 525*/ {
bevl_nxt = bem_find_2(beva_from, bevl_last);
if (bevl_nxt == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 527*/ {
bevt_2_ta_ph = bem_substring_2(bevl_last, bevl_nxt);
bevl_res.bem_addValue_1(bevt_2_ta_ph);
bevl_res.bem_addValue_1(beva_to);
bevt_3_ta_ph = beva_from.bem_sizeGet_0();
bevl_last = bevl_nxt.bem_add_1(bevt_3_ta_ph);
} /* Line: 530*/
 else /* Line: 532*/ {
bevt_5_ta_ph = bem_sizeGet_0();
bevt_4_ta_ph = bem_substring_2(bevl_last, bevt_5_ta_ph);
bevl_res.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 533*/
} /* Line: 527*/
 else /* Line: 525*/ {
break;
} /* Line: 525*/
} /* Line: 525*/
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_getPoint_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_4_17_TextMultiByteIterator bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_6_TextString bevl_y = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_j = bem_mbiterGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 544*/ {
if (bevl_i.bevi_int < beva_posi.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 544*/ {
bevl_j.bem_next_1(bevl_buf);
bevl_i.bevi_int++;
} /* Line: 544*/
 else /* Line: 544*/ {
break;
} /* Line: 544*/
} /* Line: 544*/
bevt_2_ta_ph = bevl_j.bem_next_1(bevl_buf);
bevl_y = bevt_2_ta_ph.bem_toString_0();
return bevl_y;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashValue_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_into.bevi_int = bevt_0_ta_ph.bevi_int;
bevl_j = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 554*/ {
if (bevl_j.bevi_int < bevp_size.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 554*/ {
bem_getInt_2(bevl_j, bevl_c);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
beva_into.bem_multiplyValue_1(bevt_2_ta_ph);
beva_into.bevi_int += bevl_c.bevi_int;
bevl_j.bevi_int++;
} /* Line: 554*/
 else /* Line: 554*/ {
break;
} /* Line: 554*/
} /* Line: 554*/
return beva_into;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_hashValue_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getCode_2(beva_pos, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 578*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 578*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 578*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 578*/
 else /* Line: 578*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 578*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         if (beva_into.bevi_int > 127) {
            beva_into.bevi_int -= 256;
         }
         } /* Line: 606*/
 else /* Line: 614*/ {
return null;
} /* Line: 615*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_getCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 628*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 628*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 628*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 628*/
 else /* Line: 628*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 628*/ {

         beva_into.bevi_int = (int) bevi_bytes[beva_pos.bevi_int];
         } /* Line: 657*/
 else /* Line: 662*/ {
return null;
} /* Line: 663*/
return beva_into;
} /*method end*/
public BEC_2_4_6_TextString bem_setInt_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 669*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 669*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 669*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 669*/
 else /* Line: 669*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 669*/ {
bem_setIntUnchecked_2(beva_pos, beva_into);
} /* Line: 670*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCode_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_pos.bevi_int >= bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 675*/ {
if (bevp_size.bevi_int > beva_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 675*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 675*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 675*/
 else /* Line: 675*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 675*/ {
bem_setCodeUnchecked_2(beva_pos, beva_into);
} /* Line: 676*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toAlphaNum_0() {
BEC_2_4_6_TextString bevl_input = null;
BEC_2_4_3_MathInt bevl_insz = null;
BEC_2_4_6_TextString bevl_output = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_p = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevl_input = this;
bevt_3_ta_ph = bevl_input.bem_sizeGet_0();
bevl_insz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_copy_0();
bevl_output = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevl_insz);
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_p = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 686*/ {
if (bevl_i.bevi_int < bevl_insz.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 686*/ {
bevl_input.bem_getInt_2(bevl_i, bevl_c);
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_c.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
if (bevl_c.bevi_int < bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
 else /* Line: 688*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
if (bevl_c.bevi_int > bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(123));
if (bevl_c.bevi_int < bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
 else /* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
if (bevl_c.bevi_int > bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
if (bevl_c.bevi_int < bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
 else /* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 688*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 688*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 688*/ {
bevl_output.bem_setIntUnchecked_2(bevl_p, bevl_c);
bevl_p.bevi_int++;
} /* Line: 690*/
bevl_i.bevi_int++;
} /* Line: 686*/
 else /* Line: 686*/ {
break;
} /* Line: 686*/
} /* Line: 686*/
bevl_output.bem_sizeSet_1(bevl_p);
return bevl_output;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 698*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 699*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_setIntUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     int twvls_b = beva_into.bevi_int;
     if (twvls_b < 0) {
        twvls_b += 256;
     }
     bevi_bytes[beva_pos.bevi_int] = (byte) twvls_b;
     return this;
} /*method end*/
public BEC_2_4_6_TextString bem_setCodeUnchecked_2(BEC_2_4_3_MathInt beva_pos, BEC_2_4_3_MathInt beva_into) {

     bevi_bytes[beva_pos.bevi_int] = (byte) beva_into.bevi_int;
     return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_reverseFind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_rfind_1(beva_str);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_rfind_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_rpos = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) bem_copy_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_reverseBytes_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) beva_str.bem_copy_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_reverseBytes_0();
bevl_rpos = bevt_0_ta_ph.bem_find_1(bevt_2_ta_ph);
if (bevl_rpos == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 806*/ {
bevt_5_ta_ph = beva_str.bem_sizeGet_0();
bevl_rpos.bevi_int += bevt_5_ta_ph.bevi_int;
bevt_6_ta_ph = bevp_size.bem_subtract_1(bevl_rpos);
return bevt_6_ta_ph;
} /* Line: 808*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = bem_find_2(beva_str, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_start) {
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_3_MathInt bevl_current = null;
BEC_2_4_3_MathInt bevl_myval = null;
BEC_2_4_3_MathInt bevl_strfirst = null;
BEC_2_4_3_MathInt bevl_strsize = null;
BEC_2_4_3_MathInt bevl_strval = null;
BEC_2_4_3_MathInt bevl_current2 = null;
BEC_2_4_3_MathInt bevl_end2 = null;
BEC_2_4_3_MathInt bevl_currentstr2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
if (beva_str == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
if (beva_start == null) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_start.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
if (beva_start.bevi_int >= bevp_size.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_12_ta_ph = beva_str.bem_sizeGet_0();
if (bevt_12_ta_ph.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevp_size.bevi_int == bevt_14_ta_ph.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 820*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_16_ta_ph = beva_str.bem_sizeGet_0();
bevt_17_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevt_16_ta_ph.bevi_int == bevt_17_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 820*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 820*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 820*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 820*/ {
return null;
} /* Line: 821*/
bevl_end = bevp_size;
bevl_current = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
bevl_myval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_strfirst = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
beva_str.bem_getInt_2(bevt_18_ta_ph, bevl_strfirst);
bevl_strsize = beva_str.bem_sizeGet_0();
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevl_strsize.bevi_int > bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 832*/ {
bevl_strval = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_current2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_end2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 835*/
bevl_currentstr2 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
/* Line: 838*/ {
if (bevl_current.bevi_int < bevl_end.bevi_int) {
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 838*/ {
bem_getInt_2(bevl_current, bevl_myval);
if (bevl_myval.bevi_int == bevl_strfirst.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 840*/ {
bevt_24_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevl_strsize.bevi_int == bevt_24_ta_ph.bevi_int) {
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 841*/ {
return bevl_current;
} /* Line: 842*/
bevl_current2.bevi_int = bevl_current.bevi_int;
bevl_current2.bevi_int++;
bevl_end2.bevi_int = bevl_current.bevi_int;
bevt_25_ta_ph = beva_str.bem_sizeGet_0();
bevl_end2.bevi_int += bevt_25_ta_ph.bevi_int;
if (bevl_end2.bevi_int > bevp_size.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 848*/ {
return null;
} /* Line: 849*/
bevt_27_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_currentstr2.bevi_int = bevt_27_ta_ph.bevi_int;
while (true)
/* Line: 852*/ {
if (bevl_current2.bevi_int < bevl_end2.bevi_int) {
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 852*/ {
bem_getInt_2(bevl_current2, bevl_myval);
beva_str.bem_getInt_2(bevl_currentstr2, bevl_strval);
if (bevl_myval.bevi_int != bevl_strval.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 855*/ {
break;
} /* Line: 856*/
bevl_current2.bevi_int++;
bevl_currentstr2.bevi_int++;
} /* Line: 859*/
 else /* Line: 852*/ {
break;
} /* Line: 852*/
} /* Line: 852*/
if (bevl_current2.bevi_int == bevl_end2.bevi_int) {
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 861*/ {
return bevl_current;
} /* Line: 862*/
} /* Line: 861*/
bevl_current.bevi_int++;
} /* Line: 865*/
 else /* Line: 838*/ {
break;
} /* Line: 838*/
} /* Line: 838*/
return null;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_split_1(BEC_2_4_6_TextString beva_delim) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_find_2(beva_delim, bevl_last);
bevl_ds = beva_delim.bem_sizeGet_0();
while (true)
/* Line: 875*/ {
if (bevl_i == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 875*/ {
bevt_1_ta_ph = bem_substring_2(bevl_last, bevl_i);
bevl_splits.bem_addValue_1(bevt_1_ta_ph);
bevl_last = bevl_i.bem_add_1(bevl_ds);
bevl_i = bem_find_2(beva_delim, bevl_last);
} /* Line: 878*/
 else /* Line: 875*/ {
break;
} /* Line: 875*/
} /* Line: 875*/
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 880*/ {
bevt_3_ta_ph = bem_substring_2(bevl_last, bevp_size);
bevl_splits.bem_addValue_1(bevt_3_ta_ph);
} /* Line: 881*/
return bevl_splits;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_join_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitLines_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_9_TextTokenizer bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_lineSplitterGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_tokenize_1(this);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_compare_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_4_3_MathInt bevl_mysize = null;
BEC_2_4_3_MathInt bevl_osize = null;
BEC_2_4_3_MathInt bevl_maxsize = null;
BEC_2_4_3_MathInt bevl_myret = null;
BEC_2_4_3_MathInt bevl_mv = null;
BEC_2_4_3_MathInt bevl_ov = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_stri == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 903*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 903*/ {
bevt_2_ta_ph = beva_stri.bemd_1(-1488511778, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 903*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 903*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 903*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 903*/ {
return null;
} /* Line: 904*/
bevl_mysize = bevp_size;
bevl_osize = (BEC_2_4_3_MathInt) beva_stri.bemd_0(-220982197);
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 908*/ {
bevl_maxsize = bevl_osize;
} /* Line: 909*/
 else /* Line: 910*/ {
bevl_maxsize = bevl_mysize;
} /* Line: 911*/
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_mv = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ov = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 916*/ {
if (bevl_i.bevi_int < bevl_maxsize.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 916*/ {
bem_getCode_2(bevl_i, bevl_mv);
beva_stri.bemd_2(-1056819278, bevl_i, bevl_ov);
if (bevl_mv.bevi_int != bevl_ov.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 919*/ {
if (bevl_mv.bevi_int > bevl_ov.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 920*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_7_ta_ph;
} /* Line: 921*/
 else /* Line: 922*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_8_ta_ph;
} /* Line: 923*/
} /* Line: 920*/
bevl_i.bevi_int++;
} /* Line: 916*/
 else /* Line: 916*/ {
break;
} /* Line: 916*/
} /* Line: 916*/
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_myret.bevi_int == bevt_10_ta_ph.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 927*/ {
if (bevl_mysize.bevi_int > bevl_osize.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 928*/ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 929*/
 else /* Line: 928*/ {
if (bevl_osize.bevi_int > bevl_mysize.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 930*/ {
bevl_myret = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 931*/
} /* Line: 928*/
} /* Line: 928*/
return bevl_myret;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 938*/ {
return null;
} /* Line: 938*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 939*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 940*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_6_TextString beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_stri == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 946*/ {
return null;
} /* Line: 946*/
bevt_2_ta_ph = bem_compare_1(beva_stri);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 947*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 948*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_stri) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

  var bevls_stri = beva_stri as BEC_2_4_6_TextString;
    if (this.bevp_size.bevi_int == bevls_stri.bevp_size.bevi_int) {
       for (int i = 0;i < this.bevp_size.bevi_int;i++) {
          if (this.bevi_bytes[i] != bevls_stri.bevi_bytes[i]) {
            return be.BECS_Runtime.boolFalse;
          }
       }
       return be.BECS_Runtime.boolTrue;
   }
  bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_equals_1(beva_str);
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_add_1(BEC_2_6_6_SystemObject beva_astr) {
BEC_2_4_6_TextString bevl_str = null;
BEC_2_4_6_TextString bevl_res = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
bevl_str = (BEC_2_4_6_TextString) beva_astr.bemd_0(-467511392);
bevt_1_ta_ph = bevl_str.bem_sizeGet_0();
bevt_0_ta_ph = bevp_size.bem_add_1(bevt_1_ta_ph);
bevl_res = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_res.bem_copyValue_4(this, bevt_2_ta_ph, bevp_size, bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevl_str.bem_sizeGet_0();
bevl_res.bem_copyValue_4(bevl_str, bevt_4_ta_ph, bevt_5_ta_ph, bevp_size);
return bevl_res;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_copyValue_4(BEC_2_4_6_TextString beva_org, BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi, BEC_2_4_3_MathInt beva_dstarti) {
BEC_2_4_3_MathInt bevl_mleni = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_9_SystemException bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (beva_starti.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1032*/ {
bevt_4_ta_ph = beva_org.bem_sizeGet_0();
if (beva_starti.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1032*/ {
bevt_6_ta_ph = beva_org.bem_sizeGet_0();
if (beva_endi.bevi_int > bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1032*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1032*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1032*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1032*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_4_6_TextString_bels_1));
bevt_7_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_8_ta_ph);
throw new be.BECS_ThrowBack(bevt_7_ta_ph);
} /* Line: 1033*/
 else /* Line: 1034*/ {
if (bevp_leni == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 1037*/ {
bevp_leni = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_sizi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
} /* Line: 1039*/
bevp_leni.bevi_int = beva_endi.bevi_int;
bevp_leni.bem_subtractValue_1(beva_starti);
bevl_mleni = bevp_leni;
bevp_sizi.bevi_int = beva_dstarti.bevi_int;
bevp_sizi.bevi_int += bevp_leni.bevi_int;
if (bevp_sizi.bevi_int > bevp_capacity.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1048*/ {
bem_capacitySet_1(bevp_sizi);
} /* Line: 1049*/

         //source, sourceStart, dest, destStart, length
         Array.Copy(beva_org.bevi_bytes, beva_starti.bevi_int, this.bevi_bytes, beva_dstarti.bevi_int, bevl_mleni.bevi_int); 
         if (bevp_sizi.bevi_int > bevp_size.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 1082*/ {
bevp_size.bevi_int = bevp_sizi.bevi_int;
} /* Line: 1086*/
return this;
} /* Line: 1088*/
} /*method end*/
public BEC_2_4_6_TextString bem_substring_1(BEC_2_4_3_MathInt beva_starti) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_sizeGet_0();
bevt_0_ta_ph = bem_substring_2(beva_starti, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_substring_2(BEC_2_4_3_MathInt beva_starti, BEC_2_4_3_MathInt beva_endi) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_2_ta_ph = beva_endi.bem_subtract_1(beva_starti);
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_copyValue_4(this, beva_starti, beva_endi, bevt_3_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_output_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevi_bytes.Length - 1);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_print_0() {

Stream stdout = Console.OpenStandardOutput();
stdout.Write(bevi_bytes, 0, bevp_size.bevi_int);
stdout.WriteByte(10);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_echo_0() {
bem_output_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_multiByteIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_biterGet_0() {
BEC_2_4_12_TextByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiterGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_stringIteratorGet_0() {
BEC_2_4_17_TextMultiByteIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_snw == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1223*/ {
bem_new_0();
} /* Line: 1224*/
 else /* Line: 1225*/ {
bevt_2_ta_ph = beva_snw.bem_sizeGet_0();
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_new_1(bevt_1_ta_ph);
bem_addValue_1(beva_snw);
} /* Line: 1227*/
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_strip_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_reverseBytes_0() {
BEC_2_4_3_MathInt bevl_vb = null;
BEC_2_4_3_MathInt bevl_ve = null;
BEC_2_4_3_MathInt bevl_b = null;
BEC_2_4_3_MathInt bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevl_vb = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_ve = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_b = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_e = bevp_size.bem_subtract_1(bevt_0_ta_ph);
while (true)
/* Line: 1244*/ {
if (bevl_e.bevi_int > bevl_b.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1244*/ {
bem_getInt_2(bevl_b, bevl_vb);
bem_getInt_2(bevl_e, bevl_ve);
bem_setInt_2(bevl_b, bevl_ve);
bem_setInt_2(bevl_e, bevl_vb);
bevl_b.bevi_int++;
bevl_e.bem_decrementValue_0();
} /* Line: 1250*/
 else /* Line: 1244*/ {
break;
} /* Line: 1244*/
} /* Line: 1244*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGetDirect_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_6_TextString bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGet_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_3_MathInt bem_leniGetDirect_0() {
return bevp_leni;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_leniSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_leni = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGet_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_3_MathInt bem_siziGetDirect_0() {
return bevp_sizi;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_siziSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sizi = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {259, 260, 273, 273, 277, 277, 278, 279, 279, 280, 316, 316, 317, 319, 323, 323, 324, 324, 325, 325, 329, 329, 329, 329, 329, 329, 329, 333, 334, 338, 339, 339, 340, 341, 343, 343, 344, 346, 346, 347, 347, 347, 347, 347, 347, 348, 350, 350, 350, 354, 358, 362, 366, 376, 377, 378, 382, 382, 382, 383, 383, 383, 384, 384, 389, 389, 390, 390, 391, 391, 395, 396, 397, 397, 397, 397, 397, 399, 400, 401, 401, 401, 401, 401, 403, 407, 407, 407, 408, 409, 413, 414, 414, 0, 414, 414, 414, 0, 0, 415, 415, 417, 417, 421, 421, 421, 421, 422, 422, 422, 423, 423, 424, 424, 426, 426, 430, 430, 0, 430, 430, 430, 0, 0, 431, 431, 433, 433, 437, 437, 441, 442, 442, 442, 443, 444, 444, 444, 444, 444, 444, 0, 444, 444, 444, 0, 0, 0, 0, 0, 446, 446, 446, 0, 446, 446, 446, 0, 0, 447, 447, 442, 450, 450, 454, 455, 455, 455, 456, 457, 457, 457, 457, 457, 457, 0, 0, 0, 0, 457, 457, 457, 457, 457, 457, 0, 0, 0, 0, 0, 0, 457, 457, 457, 457, 457, 457, 0, 0, 0, 0, 0, 458, 458, 455, 461, 461, 465, 465, 469, 470, 470, 470, 471, 472, 472, 472, 472, 472, 472, 0, 0, 0, 473, 473, 474, 470, 480, 480, 480, 484, 485, 485, 485, 486, 487, 487, 487, 487, 487, 487, 0, 0, 0, 488, 488, 489, 485, 495, 495, 495, 499, 499, 499, 499, 505, 506, 507, 508, 509, 509, 510, 510, 511, 512, 512, 513, 513, 513, 515, 515, 517, 522, 523, 524, 525, 525, 526, 527, 527, 528, 528, 529, 530, 530, 533, 533, 533, 537, 542, 542, 543, 544, 544, 544, 545, 544, 547, 547, 548, 552, 553, 553, 554, 554, 554, 555, 556, 556, 557, 554, 560, 564, 564, 564, 568, 568, 568, 578, 578, 578, 578, 578, 0, 0, 0, 615, 617, 628, 628, 628, 628, 628, 0, 0, 0, 663, 665, 669, 669, 669, 669, 669, 0, 0, 0, 670, 675, 675, 675, 675, 675, 0, 0, 0, 676, 681, 682, 682, 683, 684, 685, 686, 686, 686, 687, 688, 688, 688, 688, 688, 688, 0, 0, 0, 0, 688, 688, 688, 688, 688, 688, 0, 0, 0, 0, 0, 0, 688, 688, 688, 688, 688, 688, 0, 0, 0, 0, 0, 689, 690, 686, 693, 694, 698, 698, 698, 699, 699, 701, 701, 798, 798, 804, 804, 804, 804, 804, 806, 806, 807, 807, 808, 808, 810, 814, 814, 814, 820, 820, 0, 820, 820, 0, 0, 0, 820, 820, 820, 0, 0, 0, 820, 820, 0, 0, 0, 820, 820, 820, 0, 0, 0, 820, 820, 820, 0, 0, 0, 820, 820, 820, 820, 0, 0, 821, 824, 825, 826, 827, 828, 828, 830, 832, 832, 832, 833, 834, 835, 837, 838, 838, 839, 840, 840, 841, 841, 841, 842, 844, 845, 846, 847, 847, 848, 848, 849, 851, 851, 852, 852, 853, 854, 855, 855, 858, 859, 861, 861, 862, 865, 867, 871, 872, 873, 874, 875, 875, 876, 876, 877, 878, 880, 880, 881, 881, 883, 887, 887, 887, 891, 891, 891, 891, 895, 903, 903, 0, 903, 0, 0, 904, 906, 907, 908, 908, 909, 911, 913, 914, 915, 916, 916, 916, 917, 918, 919, 919, 920, 920, 921, 921, 923, 923, 916, 927, 927, 927, 928, 928, 929, 930, 930, 931, 934, 938, 938, 938, 939, 939, 939, 939, 940, 940, 942, 942, 946, 946, 946, 947, 947, 947, 947, 948, 948, 950, 950, 1013, 1013, 1017, 1017, 1017, 1021, 1022, 1022, 1022, 1023, 1023, 1023, 1024, 1024, 1024, 1025, 1028, 1028, 1032, 1032, 1032, 0, 1032, 1032, 1032, 0, 1032, 1032, 1032, 0, 0, 0, 0, 1033, 1033, 1033, 1037, 1037, 1038, 1039, 1041, 1042, 1043, 1045, 1046, 1048, 1048, 1049, 1082, 1082, 1086, 1088, 1093, 1093, 1093, 1097, 1097, 1097, 1097, 1097, 1191, 1195, 1195, 1199, 1199, 1203, 1203, 1207, 1207, 1211, 1211, 1215, 1215, 1219, 1223, 1223, 1224, 1226, 1226, 1226, 1226, 1227, 1232, 1232, 1236, 1236, 1236, 1240, 1241, 1242, 1243, 1243, 1244, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {61, 62, 67, 68, 75, 80, 81, 84, 89, 90, 101, 106, 107, 109, 116, 117, 118, 119, 120, 121, 131, 132, 133, 134, 135, 136, 137, 141, 142, 158, 159, 164, 165, 166, 168, 169, 170, 171, 176, 177, 178, 179, 180, 181, 182, 183, 185, 186, 187, 191, 194, 197, 201, 212, 213, 214, 222, 223, 228, 229, 230, 231, 232, 233, 241, 242, 243, 244, 245, 246, 261, 262, 264, 265, 266, 267, 268, 270, 271, 273, 274, 275, 276, 277, 279, 285, 286, 287, 288, 289, 299, 300, 305, 306, 309, 310, 315, 316, 319, 323, 324, 326, 327, 338, 343, 344, 345, 347, 348, 349, 350, 355, 356, 357, 359, 360, 369, 374, 375, 378, 379, 384, 385, 388, 392, 393, 395, 396, 400, 401, 421, 422, 425, 430, 431, 432, 433, 438, 439, 440, 445, 446, 449, 450, 455, 456, 459, 463, 466, 470, 475, 476, 481, 482, 485, 486, 491, 492, 495, 499, 500, 503, 509, 510, 533, 534, 537, 542, 543, 544, 545, 550, 551, 552, 557, 558, 561, 565, 568, 571, 572, 577, 578, 579, 584, 585, 588, 592, 595, 598, 602, 605, 606, 611, 612, 613, 618, 619, 622, 626, 629, 632, 636, 637, 639, 645, 646, 650, 651, 663, 664, 667, 672, 673, 674, 675, 680, 681, 682, 687, 688, 691, 695, 698, 699, 700, 702, 713, 714, 715, 727, 728, 731, 736, 737, 738, 739, 744, 745, 746, 751, 752, 755, 759, 762, 763, 764, 766, 777, 778, 779, 785, 786, 787, 788, 800, 801, 802, 803, 804, 809, 810, 811, 812, 813, 814, 815, 816, 817, 820, 821, 823, 835, 836, 837, 840, 845, 846, 847, 852, 853, 854, 855, 856, 857, 860, 861, 862, 869, 879, 880, 881, 882, 885, 890, 891, 892, 898, 899, 900, 908, 909, 910, 911, 914, 919, 920, 921, 922, 923, 924, 930, 935, 936, 937, 942, 943, 944, 951, 952, 957, 958, 963, 964, 967, 971, 981, 983, 990, 991, 996, 997, 1002, 1003, 1006, 1010, 1017, 1019, 1026, 1027, 1032, 1033, 1038, 1039, 1042, 1046, 1049, 1058, 1059, 1064, 1065, 1070, 1071, 1074, 1078, 1081, 1109, 1110, 1111, 1112, 1113, 1114, 1115, 1118, 1123, 1124, 1125, 1126, 1131, 1132, 1133, 1138, 1139, 1142, 1146, 1149, 1152, 1153, 1158, 1159, 1160, 1165, 1166, 1169, 1173, 1176, 1179, 1183, 1186, 1187, 1192, 1193, 1194, 1199, 1200, 1203, 1207, 1210, 1213, 1217, 1218, 1220, 1226, 1227, 1234, 1235, 1240, 1241, 1242, 1244, 1245, 1263, 1264, 1275, 1276, 1277, 1278, 1279, 1280, 1285, 1286, 1287, 1288, 1289, 1291, 1296, 1297, 1298, 1341, 1346, 1347, 1350, 1355, 1356, 1359, 1363, 1366, 1367, 1372, 1373, 1376, 1380, 1383, 1388, 1389, 1392, 1396, 1399, 1400, 1405, 1406, 1409, 1413, 1416, 1417, 1422, 1423, 1426, 1430, 1433, 1434, 1435, 1440, 1441, 1444, 1448, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1463, 1464, 1465, 1466, 1468, 1471, 1476, 1477, 1478, 1483, 1484, 1485, 1490, 1491, 1493, 1494, 1495, 1496, 1497, 1498, 1503, 1504, 1506, 1507, 1510, 1515, 1516, 1517, 1518, 1523, 1526, 1527, 1533, 1538, 1539, 1542, 1548, 1559, 1560, 1561, 1562, 1565, 1570, 1571, 1572, 1573, 1574, 1580, 1585, 1586, 1587, 1589, 1594, 1595, 1596, 1602, 1603, 1604, 1605, 1608, 1631, 1636, 1637, 1640, 1642, 1645, 1649, 1651, 1652, 1653, 1658, 1659, 1662, 1664, 1665, 1666, 1667, 1670, 1675, 1676, 1677, 1678, 1683, 1684, 1689, 1690, 1691, 1694, 1695, 1698, 1704, 1705, 1710, 1711, 1716, 1717, 1720, 1725, 1726, 1730, 1739, 1744, 1745, 1747, 1748, 1749, 1754, 1755, 1756, 1758, 1759, 1768, 1773, 1774, 1776, 1777, 1778, 1783, 1784, 1785, 1787, 1788, 1802, 1803, 1808, 1809, 1814, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1833, 1834, 1835, 1839, 1840, 1857, 1858, 1863, 1864, 1867, 1868, 1873, 1874, 1877, 1878, 1883, 1884, 1887, 1891, 1894, 1898, 1899, 1900, 1903, 1908, 1909, 1910, 1912, 1913, 1914, 1915, 1916, 1917, 1922, 1923, 1928, 1933, 1934, 1936, 1942, 1943, 1944, 1951, 1952, 1953, 1954, 1955, 1971, 1976, 1977, 1981, 1982, 1986, 1987, 1991, 1992, 1996, 1997, 2001, 2002, 2005, 2012, 2017, 2018, 2021, 2022, 2023, 2024, 2025, 2031, 2032, 2037, 2038, 2039, 2048, 2049, 2050, 2051, 2052, 2055, 2060, 2061, 2062, 2063, 2064, 2065, 2066, 2075, 2078, 2081, 2085, 2089, 2092, 2095, 2099, 2102, 2105, 2109, 2113, 2116, 2119, 2123};
/* BEGIN LINEINFO 
assign 1 259 61
new 0 259 61
capacitySet 1 260 62
assign 1 273 67
new 0 273 67
new 1 273 68
assign 1 277 75
undef 1 277 80
assign 1 278 81
new 0 278 81
assign 1 279 84
equals 1 279 89
return 1 280 90
assign 1 316 101
greater 1 316 106
setValue 1 317 107
setValue 1 319 109
assign 1 323 116
new 0 323 116
new 1 323 117
assign 1 324 118
new 0 324 118
setValue 1 324 119
assign 1 325 120
new 0 325 120
setHex 2 325 121
assign 1 329 131
new 0 329 131
assign 1 329 132
getCode 2 329 132
assign 1 329 133
new 0 329 133
assign 1 329 134
new 0 329 134
assign 1 329 135
new 0 329 135
assign 1 329 136
toString 3 329 136
return 1 329 137
assign 1 333 141
hexNew 1 333 141
setCode 2 334 142
assign 1 338 158
toString 0 338 158
assign 1 339 159
undef 1 339 164
assign 1 340 165
new 0 340 165
assign 1 341 166
new 0 341 166
assign 1 343 168
sizeGet 0 343 168
setValue 1 343 169
addValue 1 344 170
assign 1 346 171
lesser 1 346 176
assign 1 347 177
new 0 347 177
assign 1 347 178
add 1 347 178
assign 1 347 179
new 0 347 179
assign 1 347 180
multiply 1 347 180
assign 1 347 181
new 0 347 181
assign 1 347 182
divide 1 347 182
capacitySet 1 348 183
assign 1 350 185
new 0 350 185
assign 1 350 186
sizeGet 0 350 186
copyValue 4 350 187
return 1 354 191
return 1 358 194
addValue 1 362 197
write 1 366 201
assign 1 376 212
copy 0 376 212
clear 0 377 213
return 1 378 214
assign 1 382 222
new 0 382 222
assign 1 382 223
greater 1 382 228
assign 1 383 229
new 0 383 229
assign 1 383 230
new 0 383 230
setIntUnchecked 2 383 231
assign 1 384 232
new 0 384 232
setValue 1 384 233
assign 1 389 241
new 0 389 241
new 1 389 242
assign 1 390 243
new 0 390 243
setValue 1 390 244
assign 1 391 245
new 0 391 245
setCodeUnchecked 2 391 246
assign 1 395 261
new 0 395 261
assign 1 396 262
ends 1 396 262
assign 1 397 264
new 0 397 264
assign 1 397 265
sizeGet 0 397 265
assign 1 397 266
subtract 1 397 266
assign 1 397 267
substring 2 397 267
return 1 397 268
assign 1 399 270
new 0 399 270
assign 1 400 271
ends 1 400 271
assign 1 401 273
new 0 401 273
assign 1 401 274
sizeGet 0 401 274
assign 1 401 275
subtract 1 401 275
assign 1 401 276
substring 2 401 276
return 1 401 277
return 1 403 279
assign 1 407 285
new 0 407 285
assign 1 407 286
add 1 407 286
assign 1 407 287
new 1 407 287
addValue 1 408 288
return 1 409 289
assign 1 413 299
find 1 413 299
assign 1 414 300
undef 1 414 305
assign 1 0 306
assign 1 414 309
new 0 414 309
assign 1 414 310
notEquals 1 414 315
assign 1 0 316
assign 1 0 319
assign 1 415 323
new 0 415 323
return 1 415 324
assign 1 417 326
new 0 417 326
return 1 417 327
assign 1 421 338
undef 1 421 343
assign 1 421 344
new 0 421 344
return 1 421 345
assign 1 422 347
sizeGet 0 422 347
assign 1 422 348
subtract 1 422 348
assign 1 422 349
find 2 422 349
assign 1 423 350
undef 1 423 355
assign 1 424 356
new 0 424 356
return 1 424 357
assign 1 426 359
new 0 426 359
return 1 426 360
assign 1 430 369
undef 1 430 374
assign 1 0 375
assign 1 430 378
find 1 430 378
assign 1 430 379
undef 1 430 384
assign 1 0 385
assign 1 0 388
assign 1 431 392
new 0 431 392
return 1 431 393
assign 1 433 395
new 0 433 395
return 1 433 396
assign 1 437 400
isInteger 0 437 400
return 1 437 401
assign 1 441 421
new 0 441 421
assign 1 442 422
new 0 442 422
assign 1 442 425
lesser 1 442 430
getInt 2 443 431
assign 1 444 432
new 0 444 432
assign 1 444 433
equals 1 444 438
assign 1 444 439
new 0 444 439
assign 1 444 440
equals 1 444 445
assign 1 0 446
assign 1 444 449
new 0 444 449
assign 1 444 450
equals 1 444 455
assign 1 0 456
assign 1 0 459
assign 1 0 463
assign 1 0 466
assign 1 0 470
assign 1 446 475
new 0 446 475
assign 1 446 476
greater 1 446 481
assign 1 0 482
assign 1 446 485
new 0 446 485
assign 1 446 486
lesser 1 446 491
assign 1 0 492
assign 1 0 495
assign 1 447 499
new 0 447 499
return 1 447 500
incrementValue 0 442 503
assign 1 450 509
new 0 450 509
return 1 450 510
assign 1 454 533
new 0 454 533
assign 1 455 534
new 0 455 534
assign 1 455 537
lesser 1 455 542
getInt 2 456 543
assign 1 457 544
new 0 457 544
assign 1 457 545
greater 1 457 550
assign 1 457 551
new 0 457 551
assign 1 457 552
lesser 1 457 557
assign 1 0 558
assign 1 0 561
assign 1 0 565
assign 1 0 568
assign 1 457 571
new 0 457 571
assign 1 457 572
greater 1 457 577
assign 1 457 578
new 0 457 578
assign 1 457 579
lesser 1 457 584
assign 1 0 585
assign 1 0 588
assign 1 0 592
assign 1 0 595
assign 1 0 598
assign 1 0 602
assign 1 457 605
new 0 457 605
assign 1 457 606
greater 1 457 611
assign 1 457 612
new 0 457 612
assign 1 457 613
lesser 1 457 618
assign 1 0 619
assign 1 0 622
assign 1 0 626
assign 1 0 629
assign 1 0 632
assign 1 458 636
new 0 458 636
return 1 458 637
incrementValue 0 455 639
assign 1 461 645
new 0 461 645
return 1 461 646
assign 1 465 650
isAlphaNumGet 0 465 650
return 1 465 651
assign 1 469 663
new 0 469 663
assign 1 470 664
new 0 470 664
assign 1 470 667
lesser 1 470 672
getInt 2 471 673
assign 1 472 674
new 0 472 674
assign 1 472 675
greater 1 472 680
assign 1 472 681
new 0 472 681
assign 1 472 682
lesser 1 472 687
assign 1 0 688
assign 1 0 691
assign 1 0 695
assign 1 473 698
new 0 473 698
addValue 1 473 699
setIntUnchecked 2 474 700
incrementValue 0 470 702
assign 1 480 713
copy 0 480 713
assign 1 480 714
lowerValue 0 480 714
return 1 480 715
assign 1 484 727
new 0 484 727
assign 1 485 728
new 0 485 728
assign 1 485 731
lesser 1 485 736
getInt 2 486 737
assign 1 487 738
new 0 487 738
assign 1 487 739
greater 1 487 744
assign 1 487 745
new 0 487 745
assign 1 487 746
lesser 1 487 751
assign 1 0 752
assign 1 0 755
assign 1 0 759
assign 1 488 762
new 0 488 762
subtractValue 1 488 763
setIntUnchecked 2 489 764
incrementValue 0 485 766
assign 1 495 777
copy 0 495 777
assign 1 495 778
upperValue 0 495 778
return 1 495 779
assign 1 499 785
new 0 499 785
assign 1 499 786
split 1 499 786
assign 1 499 787
join 2 499 787
return 1 499 788
assign 1 505 800
new 0 505 800
assign 1 506 801
new 0 506 801
assign 1 507 802
new 0 507 802
assign 1 508 803
find 2 508 803
assign 1 509 804
def 1 509 809
assign 1 510 810
substring 2 510 810
addValue 1 510 811
addValue 1 511 812
assign 1 512 813
sizeGet 0 512 813
assign 1 512 814
add 1 512 814
assign 1 513 815
sizeGet 0 513 815
assign 1 513 816
substring 2 513 816
addValue 1 513 817
assign 1 515 820
copy 0 515 820
return 1 515 821
return 1 517 823
assign 1 522 835
new 0 522 835
assign 1 523 836
new 0 523 836
assign 1 524 837
new 0 524 837
assign 1 525 840
def 1 525 845
assign 1 526 846
find 2 526 846
assign 1 527 847
def 1 527 852
assign 1 528 853
substring 2 528 853
addValue 1 528 854
addValue 1 529 855
assign 1 530 856
sizeGet 0 530 856
assign 1 530 857
add 1 530 857
assign 1 533 860
sizeGet 0 533 860
assign 1 533 861
substring 2 533 861
addValue 1 533 862
return 1 537 869
assign 1 542 879
new 0 542 879
assign 1 542 880
new 1 542 880
assign 1 543 881
mbiterGet 0 543 881
assign 1 544 882
new 0 544 882
assign 1 544 885
lesser 1 544 890
next 1 545 891
incrementValue 0 544 892
assign 1 547 898
next 1 547 898
assign 1 547 899
toString 0 547 899
return 1 548 900
assign 1 552 908
new 0 552 908
assign 1 553 909
new 0 553 909
setValue 1 553 910
assign 1 554 911
new 0 554 911
assign 1 554 914
lesser 1 554 919
getInt 2 555 920
assign 1 556 921
new 0 556 921
multiplyValue 1 556 922
addValue 1 557 923
incrementValue 0 554 924
return 1 560 930
assign 1 564 935
new 0 564 935
assign 1 564 936
hashValue 1 564 936
return 1 564 937
assign 1 568 942
new 0 568 942
assign 1 568 943
getCode 2 568 943
return 1 568 944
assign 1 578 951
new 0 578 951
assign 1 578 952
greaterEquals 1 578 957
assign 1 578 958
greater 1 578 963
assign 1 0 964
assign 1 0 967
assign 1 0 971
return 1 615 981
return 1 617 983
assign 1 628 990
new 0 628 990
assign 1 628 991
greaterEquals 1 628 996
assign 1 628 997
greater 1 628 1002
assign 1 0 1003
assign 1 0 1006
assign 1 0 1010
return 1 663 1017
return 1 665 1019
assign 1 669 1026
new 0 669 1026
assign 1 669 1027
greaterEquals 1 669 1032
assign 1 669 1033
greater 1 669 1038
assign 1 0 1039
assign 1 0 1042
assign 1 0 1046
setIntUnchecked 2 670 1049
assign 1 675 1058
new 0 675 1058
assign 1 675 1059
greaterEquals 1 675 1064
assign 1 675 1065
greater 1 675 1070
assign 1 0 1071
assign 1 0 1074
assign 1 0 1078
setCodeUnchecked 2 676 1081
assign 1 681 1109
assign 1 682 1110
sizeGet 0 682 1110
assign 1 682 1111
copy 0 682 1111
assign 1 683 1112
new 1 683 1112
assign 1 684 1113
new 0 684 1113
assign 1 685 1114
new 0 685 1114
assign 1 686 1115
new 0 686 1115
assign 1 686 1118
lesser 1 686 1123
getInt 2 687 1124
assign 1 688 1125
new 0 688 1125
assign 1 688 1126
greater 1 688 1131
assign 1 688 1132
new 0 688 1132
assign 1 688 1133
lesser 1 688 1138
assign 1 0 1139
assign 1 0 1142
assign 1 0 1146
assign 1 0 1149
assign 1 688 1152
new 0 688 1152
assign 1 688 1153
greater 1 688 1158
assign 1 688 1159
new 0 688 1159
assign 1 688 1160
lesser 1 688 1165
assign 1 0 1166
assign 1 0 1169
assign 1 0 1173
assign 1 0 1176
assign 1 0 1179
assign 1 0 1183
assign 1 688 1186
new 0 688 1186
assign 1 688 1187
greater 1 688 1192
assign 1 688 1193
new 0 688 1193
assign 1 688 1194
lesser 1 688 1199
assign 1 0 1200
assign 1 0 1203
assign 1 0 1207
assign 1 0 1210
assign 1 0 1213
setIntUnchecked 2 689 1217
incrementValue 0 690 1218
incrementValue 0 686 1220
sizeSet 1 693 1226
return 1 694 1227
assign 1 698 1234
new 0 698 1234
assign 1 698 1235
lesserEquals 1 698 1240
assign 1 699 1241
new 0 699 1241
return 1 699 1242
assign 1 701 1244
new 0 701 1244
return 1 701 1245
assign 1 798 1263
rfind 1 798 1263
return 1 798 1264
assign 1 804 1275
copy 0 804 1275
assign 1 804 1276
reverseBytes 0 804 1276
assign 1 804 1277
copy 0 804 1277
assign 1 804 1278
reverseBytes 0 804 1278
assign 1 804 1279
find 1 804 1279
assign 1 806 1280
def 1 806 1285
assign 1 807 1286
sizeGet 0 807 1286
addValue 1 807 1287
assign 1 808 1288
subtract 1 808 1288
return 1 808 1289
return 1 810 1291
assign 1 814 1296
new 0 814 1296
assign 1 814 1297
find 2 814 1297
return 1 814 1298
assign 1 820 1341
undef 1 820 1346
assign 1 0 1347
assign 1 820 1350
undef 1 820 1355
assign 1 0 1356
assign 1 0 1359
assign 1 0 1363
assign 1 820 1366
new 0 820 1366
assign 1 820 1367
lesser 1 820 1372
assign 1 0 1373
assign 1 0 1376
assign 1 0 1380
assign 1 820 1383
greaterEquals 1 820 1388
assign 1 0 1389
assign 1 0 1392
assign 1 0 1396
assign 1 820 1399
sizeGet 0 820 1399
assign 1 820 1400
greater 1 820 1405
assign 1 0 1406
assign 1 0 1409
assign 1 0 1413
assign 1 820 1416
new 0 820 1416
assign 1 820 1417
equals 1 820 1422
assign 1 0 1423
assign 1 0 1426
assign 1 0 1430
assign 1 820 1433
sizeGet 0 820 1433
assign 1 820 1434
new 0 820 1434
assign 1 820 1435
equals 1 820 1440
assign 1 0 1441
assign 1 0 1444
return 1 821 1448
assign 1 824 1450
assign 1 825 1451
copy 0 825 1451
assign 1 826 1452
new 0 826 1452
assign 1 827 1453
new 0 827 1453
assign 1 828 1454
new 0 828 1454
getInt 2 828 1455
assign 1 830 1456
sizeGet 0 830 1456
assign 1 832 1457
new 0 832 1457
assign 1 832 1458
greater 1 832 1463
assign 1 833 1464
new 0 833 1464
assign 1 834 1465
new 0 834 1465
assign 1 835 1466
new 0 835 1466
assign 1 837 1468
new 0 837 1468
assign 1 838 1471
lesser 1 838 1476
getInt 2 839 1477
assign 1 840 1478
equals 1 840 1483
assign 1 841 1484
new 0 841 1484
assign 1 841 1485
equals 1 841 1490
return 1 842 1491
setValue 1 844 1493
incrementValue 0 845 1494
setValue 1 846 1495
assign 1 847 1496
sizeGet 0 847 1496
addValue 1 847 1497
assign 1 848 1498
greater 1 848 1503
return 1 849 1504
assign 1 851 1506
new 0 851 1506
setValue 1 851 1507
assign 1 852 1510
lesser 1 852 1515
getInt 2 853 1516
getInt 2 854 1517
assign 1 855 1518
notEquals 1 855 1523
incrementValue 0 858 1526
incrementValue 0 859 1527
assign 1 861 1533
equals 1 861 1538
return 1 862 1539
incrementValue 0 865 1542
return 1 867 1548
assign 1 871 1559
new 0 871 1559
assign 1 872 1560
new 0 872 1560
assign 1 873 1561
find 2 873 1561
assign 1 874 1562
sizeGet 0 874 1562
assign 1 875 1565
def 1 875 1570
assign 1 876 1571
substring 2 876 1571
addValue 1 876 1572
assign 1 877 1573
add 1 877 1573
assign 1 878 1574
find 2 878 1574
assign 1 880 1580
lesser 1 880 1585
assign 1 881 1586
substring 2 881 1586
addValue 1 881 1587
return 1 883 1589
assign 1 887 1594
new 0 887 1594
assign 1 887 1595
join 2 887 1595
return 1 887 1596
assign 1 891 1602
new 0 891 1602
assign 1 891 1603
lineSplitterGet 0 891 1603
assign 1 891 1604
tokenize 1 891 1604
return 1 891 1605
return 1 895 1608
assign 1 903 1631
undef 1 903 1636
assign 1 0 1637
assign 1 903 1640
otherType 1 903 1640
assign 1 0 1642
assign 1 0 1645
return 1 904 1649
assign 1 906 1651
assign 1 907 1652
sizeGet 0 907 1652
assign 1 908 1653
greater 1 908 1658
assign 1 909 1659
assign 1 911 1662
assign 1 913 1664
new 0 913 1664
assign 1 914 1665
new 0 914 1665
assign 1 915 1666
new 0 915 1666
assign 1 916 1667
new 0 916 1667
assign 1 916 1670
lesser 1 916 1675
getCode 2 917 1676
getCode 2 918 1677
assign 1 919 1678
notEquals 1 919 1683
assign 1 920 1684
greater 1 920 1689
assign 1 921 1690
new 0 921 1690
return 1 921 1691
assign 1 923 1694
new 0 923 1694
return 1 923 1695
incrementValue 0 916 1698
assign 1 927 1704
new 0 927 1704
assign 1 927 1705
equals 1 927 1710
assign 1 928 1711
greater 1 928 1716
assign 1 929 1717
new 0 929 1717
assign 1 930 1720
greater 1 930 1725
assign 1 931 1726
new 0 931 1726
return 1 934 1730
assign 1 938 1739
undef 1 938 1744
return 1 938 1745
assign 1 939 1747
compare 1 939 1747
assign 1 939 1748
new 0 939 1748
assign 1 939 1749
equals 1 939 1754
assign 1 940 1755
new 0 940 1755
return 1 940 1756
assign 1 942 1758
new 0 942 1758
return 1 942 1759
assign 1 946 1768
undef 1 946 1773
return 1 946 1774
assign 1 947 1776
compare 1 947 1776
assign 1 947 1777
new 0 947 1777
assign 1 947 1778
equals 1 947 1783
assign 1 948 1784
new 0 948 1784
return 1 948 1785
assign 1 950 1787
new 0 950 1787
return 1 950 1788
assign 1 1013 1802
new 0 1013 1802
return 1 1013 1803
assign 1 1017 1808
equals 1 1017 1808
assign 1 1017 1809
not 0 1017 1814
return 1 1017 1814
assign 1 1021 1825
toString 0 1021 1825
assign 1 1022 1826
sizeGet 0 1022 1826
assign 1 1022 1827
add 1 1022 1827
assign 1 1022 1828
new 1 1022 1828
assign 1 1023 1829
new 0 1023 1829
assign 1 1023 1830
new 0 1023 1830
copyValue 4 1023 1831
assign 1 1024 1832
new 0 1024 1832
assign 1 1024 1833
sizeGet 0 1024 1833
copyValue 4 1024 1834
return 1 1025 1835
assign 1 1028 1839
new 0 1028 1839
return 1 1028 1840
assign 1 1032 1857
new 0 1032 1857
assign 1 1032 1858
lesser 1 1032 1863
assign 1 0 1864
assign 1 1032 1867
sizeGet 0 1032 1867
assign 1 1032 1868
greater 1 1032 1873
assign 1 0 1874
assign 1 1032 1877
sizeGet 0 1032 1877
assign 1 1032 1878
greater 1 1032 1883
assign 1 0 1884
assign 1 0 1887
assign 1 0 1891
assign 1 0 1894
assign 1 1033 1898
new 0 1033 1898
assign 1 1033 1899
new 1 1033 1899
throw 1 1033 1900
assign 1 1037 1903
undef 1 1037 1908
assign 1 1038 1909
new 0 1038 1909
assign 1 1039 1910
new 0 1039 1910
setValue 1 1041 1912
subtractValue 1 1042 1913
assign 1 1043 1914
setValue 1 1045 1915
addValue 1 1046 1916
assign 1 1048 1917
greater 1 1048 1922
capacitySet 1 1049 1923
assign 1 1082 1928
greater 1 1082 1933
setValue 1 1086 1934
return 1 1088 1936
assign 1 1093 1942
sizeGet 0 1093 1942
assign 1 1093 1943
substring 2 1093 1943
return 1 1093 1944
assign 1 1097 1951
subtract 1 1097 1951
assign 1 1097 1952
new 1 1097 1952
assign 1 1097 1953
new 0 1097 1953
assign 1 1097 1954
copyValue 4 1097 1954
return 1 1097 1955
output 0 1191 1971
assign 1 1195 1976
new 1 1195 1976
return 1 1195 1977
assign 1 1199 1981
new 1 1199 1981
return 1 1199 1982
assign 1 1203 1986
new 1 1203 1986
return 1 1203 1987
assign 1 1207 1991
new 1 1207 1991
return 1 1207 1992
assign 1 1211 1996
new 1 1211 1996
return 1 1211 1997
assign 1 1215 2001
new 1 1215 2001
return 1 1215 2002
return 1 1219 2005
assign 1 1223 2012
undef 1 1223 2017
new 0 1224 2018
assign 1 1226 2021
sizeGet 0 1226 2021
assign 1 1226 2022
new 0 1226 2022
assign 1 1226 2023
add 1 1226 2023
new 1 1226 2024
addValue 1 1227 2025
assign 1 1232 2031
new 0 1232 2031
return 1 1232 2032
assign 1 1236 2037
new 0 1236 2037
assign 1 1236 2038
strip 1 1236 2038
return 1 1236 2039
assign 1 1240 2048
new 0 1240 2048
assign 1 1241 2049
new 0 1241 2049
assign 1 1242 2050
new 0 1242 2050
assign 1 1243 2051
new 0 1243 2051
assign 1 1243 2052
subtract 1 1243 2052
assign 1 1244 2055
greater 1 1244 2060
getInt 2 1245 2061
getInt 2 1246 2062
setInt 2 1247 2063
setInt 2 1248 2064
incrementValue 0 1249 2065
decrementValue 0 1250 2066
return 1 0 2075
return 1 0 2078
assign 1 0 2081
assign 1 0 2085
return 1 0 2089
return 1 0 2092
assign 1 0 2095
return 1 0 2099
return 1 0 2102
assign 1 0 2105
assign 1 0 2109
return 1 0 2113
return 1 0 2116
assign 1 0 2119
assign 1 0 2123
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1264017643: return bem_capacityGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -175688907: return bem_vstringGet_0();
case -1040535372: return bem_readString_0();
case 136900920: return bem_output_0();
case -220982197: return bem_sizeGet_0();
case -1469993846: return bem_close_0();
case -1475577858: return bem_multiByteIteratorGet_0();
case -1197869870: return bem_chomp_0();
case -1363819567: return bem_new_0();
case 1597327951: return bem_create_0();
case 472553335: return bem_reverseBytes_0();
case -1284876249: return bem_readBuffer_0();
case -1188922735: return bem_echo_0();
case -447432319: return bem_many_0();
case -1760538533: return bem_classNameGet_0();
case 1383286834: return bem_mbiterGet_0();
case 135689245: return bem_leniGet_0();
case -476395750: return bem_isEmptyGet_0();
case 57156876: return bem_upper_0();
case -321957230: return bem_siziGet_0();
case 371157924: return bem_sourceFileNameGet_0();
case 1677381792: return bem_isInteger_0();
case -793241295: return bem_iteratorGet_0();
case -1323898541: return bem_toAny_0();
case 1890854002: return bem_tagGet_0();
case 7254011: return bem_fieldIteratorGet_0();
case -1709120295: return bem_siziGetDirect_0();
case 912873104: return bem_capacityGetDirect_0();
case -921473949: return bem_fieldNamesGet_0();
case 212584225: return bem_open_0();
case 895193825: return bem_once_0();
case -852651260: return bem_isIntegerGet_0();
case 52151129: return bem_toAlphaNum_0();
case -2106243830: return bem_splitLines_0();
case 1319388306: return bem_copy_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -1387831588: return bem_print_0();
case -16280661: return bem_vstringSet_0();
case -137834818: return bem_upperValue_0();
case 247065467: return bem_byteIteratorGet_0();
case -2076109796: return bem_leniGetDirect_0();
case 1092105192: return bem_hashGet_0();
case -2002616011: return bem_stringIteratorGet_0();
case -467511392: return bem_toString_0();
case -1085074418: return bem_isAlphaNumGet_0();
case 1186376529: return bem_lowerValue_0();
case -105946774: return bem_serializeToString_0();
case 1433715441: return bem_biterGet_0();
case 1720785179: return bem_clear_0();
case 2045554024: return bem_strip_0();
case -894995631: return bem_lower_0();
case 1466460989: return bem_sizeGetDirect_0();
case -1762524994: return bem_extractString_0();
case 683376437: return bem_isAlphaNumericGet_0();
case 1652521523: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 315559451: return bem_begins_1((BEC_2_4_6_TextString) bevd_0);
case -183042992: return bem_capacitySetDirect_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1243270878: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1728508146: return bem_sizeSetDirect_1(bevd_0);
case 2069899029: return bem_sizeSet_1(bevd_0);
case -1140993442: return bem_ends_1((BEC_2_4_6_TextString) bevd_0);
case 604750553: return bem_leniSet_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 1252324679: return bem_siziSet_1(bevd_0);
case 1968692867: return bem_find_1((BEC_2_4_6_TextString) bevd_0);
case 1929898803: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1300115836: return bem_rfind_1((BEC_2_4_6_TextString) bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case 1791337107: return bem_writeTo_1(bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case 973483529: return bem_getPoint_1((BEC_2_4_3_MathInt) bevd_0);
case -873283838: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -308697036: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 738335329: return bem_leniSetDirect_1(bevd_0);
case 800888043: return bem_reverseFind_1((BEC_2_4_6_TextString) bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case 859854351: return bem_compare_1(bevd_0);
case -936741227: return bem_getCode_1((BEC_2_4_3_MathInt) bevd_0);
case 2036819915: return bem_lesser_1((BEC_2_4_6_TextString) bevd_0);
case 1803941746: return bem_siziSetDirect_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1634078582: return bem_addValue_1(bevd_0);
case -1172028153: return bem_substring_1((BEC_2_4_3_MathInt) bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -475350780: return bem_add_1(bevd_0);
case 1337540855: return bem_split_1((BEC_2_4_6_TextString) bevd_0);
case -1719481098: return bem_getHex_1((BEC_2_4_3_MathInt) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case -1899526351: return bem_codeNew_1(bevd_0);
case -231846695: return bem_write_1(bevd_0);
case -1483853795: return bem_greater_1((BEC_2_4_6_TextString) bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case 735636898: return bem_hashValue_1((BEC_2_4_3_MathInt) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 491010198: return bem_swap_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1436580721: return bem_swapFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1739110802: return bem_find_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -585982881: return bem_setIntUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1056819278: return bem_getCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1901542946: return bem_setInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -565818650: return bem_getInt_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1916145695: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1391112301: return bem_setCodeUnchecked_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -987597109: return bem_setHex_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 981885887: return bem_swap0_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 535409262: return bem_substring_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1104187018: return bem_setCode_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -442551652: return bem_copyValue_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_TextString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_6_TextString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_TextString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst = (BEC_2_4_6_TextString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_6_TextString.bece_BEC_2_4_6_TextString_bevs_type;
}
}
}
