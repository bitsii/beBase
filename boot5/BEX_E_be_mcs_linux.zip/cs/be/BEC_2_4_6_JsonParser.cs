namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_6_JsonParser : BEC_2_6_6_SystemObject {
public BEC_2_4_6_JsonParser() { }
static BEC_2_4_6_JsonParser() { }
private static byte[] becc_BEC_2_4_6_JsonParser_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x72};
private static byte[] becc_BEC_2_4_6_JsonParser_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_0 = {0x7B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_1 = {0x7D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_2 = {0x5B};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_3 = {0x5D};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_4 = {0x5C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_5 = {0x2C};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_6 = {0x62,0x66,0x6E,0x72,0x74,0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_6, 6));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_8 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_9 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_1 = (new BEC_2_4_3_MathInt(55296));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_2 = (new BEC_2_4_3_MathInt(56319));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_3 = (new BEC_2_4_3_MathInt(56320));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_4 = (new BEC_2_4_3_MathInt(57343));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_5 = (new BEC_2_4_3_MathInt(6));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_6 = (new BEC_2_4_3_MathInt(5));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_10 = {0x74,0x6F,0x6B,0x20,0x74,0x6F,0x6F,0x20,0x73,0x6D,0x61,0x6C,0x6C};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_7 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_8 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_9 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_11 = {0x38,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_12 = {0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_13 = {0x43,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_14 = {0x37,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_15 = {0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_16 = {0x45,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_17 = {0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_18 = {0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_12 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_19 = {0x30,0x30,0x33,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_20 = {0x31,0x30,0x46,0x46,0x46,0x46};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_21 = {0x46,0x30};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_22 = {0x31,0x43,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_23 = {0x30,0x33,0x46,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_24 = {0x30,0x30,0x30,0x46,0x43,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_15 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_25 = {0x30,0x30,0x30,0x30,0x33,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_6_JsonParser_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_26 = {0x66,0x61,0x69,0x6C,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x76,0x61,0x6C,0x75,0x65,0x20,0x74,0x6F,0x20,0x62,0x75,0x66,0x66,0x65,0x72,0x20,0x63,0x6F,0x6E,0x76,0x65,0x72,0x74};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_27 = {0x75};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_27, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_28 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x69,0x73,0x20,0x69,0x6E,0x76,0x61,0x6C,0x69,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_29 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x65,0x73,0x63,0x61,0x70,0x65,0x20,0x73,0x74,0x61,0x74,0x65,0x2C,0x20,0x66,0x69,0x72,0x73,0x74,0x20,0x70,0x61,0x72,0x74,0x20,0x6F,0x66,0x20,0x73,0x75,0x72,0x72,0x6F,0x67,0x61,0x74,0x65,0x20,0x70,0x61,0x69,0x72,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x6C,0x6C,0x6F,0x77,0x65,0x64,0x20,0x62,0x79,0x20,0x73,0x65,0x63,0x6F,0x6E,0x64};
private static byte[] bece_BEC_2_4_6_JsonParser_bels_30 = {0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_30, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_31 = {0x72};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_31, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_32 = {0x66};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_32, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_33 = {0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_33, 1));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_34 = {0x75,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_34, 2));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_35 = {0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_35, 4));
private static byte[] bece_BEC_2_4_6_JsonParser_bels_36 = {0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_4_6_JsonParser_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_4_6_JsonParser_bels_36, 3));
public static new BEC_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_inst;

public static new BET_2_4_6_JsonParser bece_BEC_2_4_6_JsonParser_bevs_type;

public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_lbrace;
public BEC_2_4_6_TextString bevp_rbrace;
public BEC_2_4_6_TextString bevp_lbracket;
public BEC_2_4_6_TextString bevp_rbracket;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_6_TextString bevp_escape;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_comma;
public BEC_2_4_6_TextString bevp_tokens;
public BEC_2_4_9_TextTokenizer bevp_toker;
public BEC_2_4_3_MathInt bevp_hsub;
public BEC_2_4_3_MathInt bevp_vsub;
public BEC_2_4_3_MathInt bevp_hmAdd;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_quote = bevt_0_tmpany_phold.bem_quoteGet_0();
bevp_lbrace = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_0));
bevp_rbrace = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_1));
bevp_lbracket = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_2));
bevp_rbracket = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_3));
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_space = bevt_1_tmpany_phold.bem_spaceGet_0();
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_colon = bevt_2_tmpany_phold.bem_colonGet_0();
bevp_escape = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_4));
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_cr = bevt_3_tmpany_phold.bem_crGet_0();
bevt_4_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_lf = bevt_4_tmpany_phold.bem_lfGet_0();
bevp_comma = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_6_JsonParser_bels_5));
bevt_14_tmpany_phold = bevp_quote.bem_add_1(bevp_lbrace);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevp_rbrace);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_lbracket);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevp_rbracket);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevp_space);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_colon);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevp_escape);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevp_cr);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_lf);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevp_comma);
bevt_15_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_0;
bevp_tokens = bevt_5_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_toker = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevp_tokens, bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_7));
bevp_hsub = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_8));
bevp_vsub = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevp_hmAdd = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_19_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parse_2(BEC_2_4_6_TextString beva_str, BEC_2_6_6_SystemObject beva_handler) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_toker.bem_tokenize_1(beva_str);
bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold , beva_handler);
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_jsonUcIsPairStart_1(BEC_2_4_3_MathInt beva_value) {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_1;
if (bevt_2_tmpany_phold.bevi_int <= beva_value.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 62 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_2;
if (beva_value.bevi_int <= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 62 */
 else  /* Line: 62 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 62 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 63 */
 else  /* Line: 64 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 65 */
return bevl_result;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_jsonUcIsPairEnd_1(BEC_2_4_3_MathInt beva_value) {
BEC_2_5_4_LogicBool bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_3;
if (bevt_2_tmpany_phold.bevi_int <= beva_value.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_4;
if (beva_value.bevi_int <= bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 73 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 74 */
 else  /* Line: 75 */ {
bevl_result = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 76 */
return bevl_result;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_jsonUcGetAfterPart_1(BEC_2_4_6_TextString beva_tok) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_5;
if (bevt_1_tmpany_phold.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 83 */ {
return null;
} /* Line: 84 */
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevt_3_tmpany_phold = beva_tok.bem_substring_1(bevt_4_tmpany_phold);
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_jsonUcUnescape_1(BEC_2_4_6_TextString beva_tok) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = beva_tok.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_6;
if (bevt_1_tmpany_phold.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 90 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_4_6_JsonParser_bels_10));
bevt_3_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 91 */
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_6_tmpany_phold = beva_tok.bem_substring_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_6_tmpany_phold);
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_jsonUcAppendValue_3(BEC_2_4_3_MathInt beva_heldValue, BEC_2_4_3_MathInt beva_value, BEC_2_4_6_TextString beva_accum) {
BEC_2_4_3_MathInt bevl_sizeNow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_heldm = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
bevt_2_tmpany_phold = beva_accum.bem_capacityGet_0();
bevt_3_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_subtract_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_7;
if (bevt_1_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 98 */ {
bevt_6_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_7_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_8;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
beva_accum.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 99 */
bevl_sizeNow = beva_accum.bem_sizeGet_0();
if (beva_heldValue == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 104 */ {
bevl_heldm = beva_heldValue;
bevl_heldm.bem_subtractValue_1(bevp_hsub);
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevl_heldm.bem_shiftLeftValue_1(bevt_9_tmpany_phold);
bevl_heldm.bem_subtractValue_1(bevp_vsub);
bevl_heldm.bevi_int += beva_value.bevi_int;
bevl_heldm.bevi_int += bevp_hmAdd.bevi_int;
beva_value = bevl_heldm;
} /* Line: 112 */
bevt_11_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_9;
if (beva_value.bevi_int < bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 119 */
 else  /* Line: 118 */ {
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_13_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_14_tmpany_phold);
if (beva_value.bevi_int < bevt_13_tmpany_phold.bevi_int) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 120 */ {
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, beva_value);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 122 */
 else  /* Line: 118 */ {
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_12));
bevt_16_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_17_tmpany_phold);
if (beva_value.bevi_int < bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 123 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_13));
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_20_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_14));
bevt_23_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_24_tmpany_phold);
bevt_22_tmpany_phold = beva_value.bem_and_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_shiftRight_1(bevt_25_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_18_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_10;
bevt_26_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_29_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_30_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_4_6_JsonParser_bels_15));
bevt_32_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_33_tmpany_phold);
bevt_31_tmpany_phold = beva_value.bem_and_1(bevt_32_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_28_tmpany_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 126 */
 else  /* Line: 118 */ {
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_6_JsonParser_bels_9));
bevt_35_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_36_tmpany_phold);
if (beva_value.bevi_int < bevt_35_tmpany_phold.bevi_int) {
bevt_34_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_34_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 127 */ {
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_16));
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_39_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_17));
bevt_42_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_43_tmpany_phold);
bevt_41_tmpany_phold = beva_value.bem_and_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevt_40_tmpany_phold = bevt_41_tmpany_phold.bem_shiftRight_1(bevt_44_tmpany_phold);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_37_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_11;
bevt_45_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_46_tmpany_phold);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_48_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_18));
bevt_52_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_53_tmpany_phold);
bevt_51_tmpany_phold = beva_value.bem_and_1(bevt_52_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_shiftRight_1(bevt_54_tmpany_phold);
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_50_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_45_tmpany_phold, bevt_47_tmpany_phold);
bevt_56_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_12;
bevt_55_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_56_tmpany_phold);
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_58_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_59_tmpany_phold);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_6_JsonParser_bels_19));
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_tmpany_phold);
bevt_60_tmpany_phold = beva_value.bem_and_1(bevt_61_tmpany_phold);
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_add_1(bevt_60_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_55_tmpany_phold, bevt_57_tmpany_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
} /* Line: 131 */
 else  /* Line: 118 */ {
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_20));
bevt_64_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_tmpany_phold);
if (beva_value.bevi_int <= bevt_64_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_21));
bevt_67_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_tmpany_phold);
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_22));
bevt_71_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_72_tmpany_phold);
bevt_70_tmpany_phold = beva_value.bem_and_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(18));
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_shiftRight_1(bevt_73_tmpany_phold);
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bem_add_1(bevt_69_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevl_sizeNow, bevt_66_tmpany_phold);
bevt_75_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_13;
bevt_74_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_75_tmpany_phold);
bevt_78_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_77_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_78_tmpany_phold);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_23));
bevt_81_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_82_tmpany_phold);
bevt_80_tmpany_phold = beva_value.bem_and_1(bevt_81_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevt_79_tmpany_phold = bevt_80_tmpany_phold.bem_shiftRight_1(bevt_83_tmpany_phold);
bevt_76_tmpany_phold = bevt_77_tmpany_phold.bem_add_1(bevt_79_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_74_tmpany_phold, bevt_76_tmpany_phold);
bevt_85_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_14;
bevt_84_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_85_tmpany_phold);
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_87_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_88_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_24));
bevt_91_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_92_tmpany_phold);
bevt_90_tmpany_phold = beva_value.bem_and_1(bevt_91_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bem_shiftRight_1(bevt_93_tmpany_phold);
bevt_86_tmpany_phold = bevt_87_tmpany_phold.bem_add_1(bevt_89_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_84_tmpany_phold, bevt_86_tmpany_phold);
bevt_95_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_15;
bevt_94_tmpany_phold = bevl_sizeNow.bem_add_1(bevt_95_tmpany_phold);
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_6_JsonParser_bels_11));
bevt_97_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_98_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_4_6_JsonParser_bels_25));
bevt_100_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_101_tmpany_phold);
bevt_99_tmpany_phold = beva_value.bem_and_1(bevt_100_tmpany_phold);
bevt_96_tmpany_phold = bevt_97_tmpany_phold.bem_add_1(bevt_99_tmpany_phold);
beva_accum.bem_setIntUnchecked_2(bevt_94_tmpany_phold, bevt_96_tmpany_phold);
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
} /* Line: 137 */
 else  /* Line: 138 */ {
bevl_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
} /* Line: 139 */
} /* Line: 118 */
} /* Line: 118 */
} /* Line: 118 */
} /* Line: 118 */
bevt_103_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_16;
if (bevl_size.bevi_int < bevt_103_tmpany_phold.bevi_int) {
bevt_102_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_102_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_102_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_4_6_JsonParser_bels_26));
bevt_104_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_105_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_104_tmpany_phold);
} /* Line: 143 */
bevt_107_tmpany_phold = beva_accum.bem_sizeGet_0();
bevt_106_tmpany_phold = bevt_107_tmpany_phold.bem_add_1(bevl_size);
beva_accum.bem_sizeSet_1(bevt_106_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_parseTokens_2(BEC_2_9_10_ContainerLinkedList beva_toks, BEC_2_6_6_SystemObject beva_handler) {
BEC_2_5_4_LogicBool bevl_inString = null;
BEC_2_5_4_LogicBool bevl_inEscape = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_9_3_ContainerMap bevl_fromEscapes = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_tokIter = null;
BEC_2_4_3_MathInt bevl_heldValue = null;
BEC_2_4_6_TextString bevl_tok = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_6_TextString bevl_remainder = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_anchor = null;
BEC_2_4_7_JsonEscapes bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
bevl_inString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevl_fromEscapes = bevt_9_tmpany_phold.bem_fromEscapesGet_0();
bevl_tokIter = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 176 */ {
bevt_10_tmpany_phold = bevl_tokIter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 176 */ {
bevl_tok = (BEC_2_4_6_TextString) bevl_tokIter.bem_nextGet_0();
if (bevl_inString.bevi_bool) /* Line: 179 */ {
if (bevl_inEscape.bevi_bool) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 180 */ {
bevt_12_tmpany_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 180 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 180 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 180 */
 else  /* Line: 180 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 180 */ {
bevl_inString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_13_tmpany_phold = bevl_accum.bem_extractString_0();
beva_handler.bemd_1(268061539, bevt_13_tmpany_phold);
} /* Line: 182 */
 else  /* Line: 183 */ {
if (bevl_inEscape.bevi_bool) /* Line: 184 */ {
bevl_escval = (BEC_2_4_6_TextString) bevl_fromEscapes.bem_get_1(bevl_tok);
if (bevl_escval == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevl_accum.bem_addValue_1(bevl_escval);
} /* Line: 187 */
 else  /* Line: 186 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_17;
bevt_15_tmpany_phold = bevl_tok.bem_begins_1(bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 188 */ {
bevl_value = bem_jsonUcUnescape_1(bevl_tok);
bevl_remainder = bem_jsonUcGetAfterPart_1(bevl_tok);
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_heldValue == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_19_tmpany_phold = bem_jsonUcIsPairEnd_1(bevl_value);
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 192 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 192 */
 else  /* Line: 192 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 192 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(62, bece_BEC_2_4_6_JsonParser_bels_28));
bevt_20_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_21_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_20_tmpany_phold);
} /* Line: 193 */
 else  /* Line: 192 */ {
if (bevl_heldValue == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevl_isStart = bem_jsonUcIsPairStart_1(bevl_value);
} /* Line: 195 */
} /* Line: 192 */
if (bevl_isStart.bevi_bool) /* Line: 197 */ {
if (bevl_remainder == null) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 197 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 197 */
 else  /* Line: 197 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 197 */ {
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(73, bece_BEC_2_4_6_JsonParser_bels_29));
bevt_24_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 198 */
if (bevl_isStart.bevi_bool) /* Line: 200 */ {
bevl_heldValue = bevl_value;
} /* Line: 201 */
 else  /* Line: 202 */ {
bem_jsonUcAppendValue_3(bevl_heldValue, bevl_value, bevl_accum);
bevl_heldValue = null;
if (bevl_remainder == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevl_accum.bem_addValue_1(bevl_remainder);
} /* Line: 206 */
} /* Line: 205 */
} /* Line: 200 */
 else  /* Line: 209 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 210 */
} /* Line: 186 */
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 212 */
 else  /* Line: 184 */ {
bevt_27_tmpany_phold = bevl_tok.bem_equals_1(bevp_escape);
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevl_inEscape = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 214 */
 else  /* Line: 215 */ {
bevl_accum.bem_addValue_1(bevl_tok);
} /* Line: 216 */
} /* Line: 184 */
} /* Line: 184 */
} /* Line: 180 */
 else  /* Line: 219 */ {
bevt_28_tmpany_phold = bevl_tok.bem_equals_1(bevp_space);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_29_tmpany_phold = bevl_tok.bem_equals_1(bevp_cr);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 221 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_30_tmpany_phold = bevl_tok.bem_equals_1(bevp_lf);
if (bevt_30_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 221 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_31_tmpany_phold = bevl_tok.bem_equals_1(bevp_comma);
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 221 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 221 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 221 */ {
} /* Line: 221 */
 else  /* Line: 221 */ {
bevt_32_tmpany_phold = bevl_tok.bem_equals_1(bevp_quote);
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevl_inString = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 223 */
 else  /* Line: 221 */ {
bevt_33_tmpany_phold = bevl_tok.bem_equals_1(bevp_lbrace);
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 224 */ {
beva_handler.bemd_0(-580724);
} /* Line: 225 */
 else  /* Line: 221 */ {
bevt_34_tmpany_phold = bevl_tok.bem_equals_1(bevp_rbrace);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 226 */ {
beva_handler.bemd_0(715144535);
} /* Line: 227 */
 else  /* Line: 221 */ {
bevt_35_tmpany_phold = bevl_tok.bem_equals_1(bevp_colon);
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 228 */ {
beva_handler.bemd_0(-782789677);
} /* Line: 229 */
 else  /* Line: 221 */ {
bevt_36_tmpany_phold = bevl_tok.bem_equals_1(bevp_lbracket);
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 230 */ {
beva_handler.bemd_0(960965492);
} /* Line: 231 */
 else  /* Line: 221 */ {
bevt_37_tmpany_phold = bevl_tok.bem_equals_1(bevp_rbracket);
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 232 */ {
beva_handler.bemd_0(-1313533629);
} /* Line: 233 */
 else  /* Line: 234 */ {
bevt_39_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_18;
bevt_38_tmpany_phold = bevl_tok.bem_equals_1(bevt_39_tmpany_phold);
if (bevt_38_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_41_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_19;
bevt_40_tmpany_phold = bevl_tok.bem_equals_1(bevt_41_tmpany_phold);
if (bevt_40_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_8_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
if (bevt_8_tmpany_anchor.bevi_bool) /* Line: 237 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_43_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_20;
bevt_42_tmpany_phold = bevl_tok.bem_equals_1(bevt_43_tmpany_phold);
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 237 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_45_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_21;
bevt_44_tmpany_phold = bevl_tok.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 237 */ {
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_47_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_22;
bevt_46_tmpany_phold = bevl_tok.bem_equals_1(bevt_47_tmpany_phold);
if (bevt_46_tmpany_phold.bevi_bool) /* Line: 240 */ {
beva_handler.bemd_0(-641770758);
} /* Line: 241 */
 else  /* Line: 237 */ {
bevt_49_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_23;
bevt_48_tmpany_phold = bevl_tok.bem_equals_1(bevt_49_tmpany_phold);
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 242 */ {
beva_handler.bemd_0(931113773);
} /* Line: 243 */
 else  /* Line: 237 */ {
bevt_51_tmpany_phold = bece_BEC_2_4_6_JsonParser_bevo_24;
bevt_50_tmpany_phold = bevl_tok.bem_equals_1(bevt_51_tmpany_phold);
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 244 */ {
beva_handler.bemd_0(1838411266);
} /* Line: 245 */
 else  /* Line: 246 */ {
bevt_52_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevl_tok);
beva_handler.bemd_1(-1513439777, bevt_52_tmpany_phold);
} /* Line: 248 */
} /* Line: 237 */
} /* Line: 237 */
} /* Line: 237 */
} /* Line: 237 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 221 */
} /* Line: 179 */
 else  /* Line: 176 */ {
break;
} /* Line: 176 */
} /* Line: 176 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGetDirect_0() {
return bevp_quote;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lbraceGet_0() {
return bevp_lbrace;
} /*method end*/
public BEC_2_4_6_TextString bem_lbraceGetDirect_0() {
return bevp_lbrace;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_lbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_rbraceGet_0() {
return bevp_rbrace;
} /*method end*/
public BEC_2_4_6_TextString bem_rbraceGetDirect_0() {
return bevp_rbrace;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_rbraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rbrace = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lbracketGet_0() {
return bevp_lbracket;
} /*method end*/
public BEC_2_4_6_TextString bem_lbracketGetDirect_0() {
return bevp_lbracket;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_lbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lbracketSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_rbracketGet_0() {
return bevp_rbracket;
} /*method end*/
public BEC_2_4_6_TextString bem_rbracketGetDirect_0() {
return bevp_rbracket;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_rbracketSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_rbracketSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rbracket = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGetDirect_0() {
return bevp_space;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGetDirect_0() {
return bevp_colon;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_escapeGet_0() {
return bevp_escape;
} /*method end*/
public BEC_2_4_6_TextString bem_escapeGetDirect_0() {
return bevp_escape;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_escapeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_escapeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_escape = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_TextString bem_crGetDirect_0() {
return bevp_cr;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGetDirect_0() {
return bevp_lf;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_commaGet_0() {
return bevp_comma;
} /*method end*/
public BEC_2_4_6_TextString bem_commaGetDirect_0() {
return bevp_comma;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_commaSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_commaSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_comma = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_tokensGet_0() {
return bevp_tokens;
} /*method end*/
public BEC_2_4_6_TextString bem_tokensGetDirect_0() {
return bevp_tokens;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_tokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokensSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tokens = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_tokerGet_0() {
return bevp_toker;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokerGetDirect_0() {
return bevp_toker;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_tokerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_tokerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toker = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hsubGet_0() {
return bevp_hsub;
} /*method end*/
public BEC_2_4_3_MathInt bem_hsubGetDirect_0() {
return bevp_hsub;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_hsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hsubSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vsubGet_0() {
return bevp_vsub;
} /*method end*/
public BEC_2_4_3_MathInt bem_vsubGetDirect_0() {
return bevp_vsub;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_vsubSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_vsubSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vsub = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_hmAddGet_0() {
return bevp_hmAdd;
} /*method end*/
public BEC_2_4_3_MathInt bem_hmAddGetDirect_0() {
return bevp_hmAdd;
} /*method end*/
public virtual BEC_2_4_6_JsonParser bem_hmAddSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_JsonParser bem_hmAddSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_hmAdd = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {36, 36, 37, 38, 39, 40, 41, 41, 42, 42, 43, 44, 44, 45, 45, 46, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 47, 48, 48, 49, 49, 50, 50, 51, 51, 57, 57, 62, 62, 62, 62, 62, 62, 0, 0, 0, 63, 65, 67, 73, 73, 73, 73, 73, 73, 0, 0, 0, 74, 76, 78, 83, 83, 83, 83, 84, 86, 86, 86, 90, 90, 90, 90, 91, 91, 91, 93, 93, 93, 93, 98, 98, 98, 98, 98, 98, 99, 99, 99, 99, 101, 104, 104, 106, 107, 108, 108, 109, 110, 111, 112, 118, 118, 118, 119, 120, 120, 120, 120, 121, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 125, 126, 127, 127, 127, 127, 128, 128, 128, 128, 128, 128, 128, 128, 128, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 129, 130, 130, 130, 130, 130, 130, 130, 130, 130, 131, 132, 132, 132, 132, 133, 133, 133, 133, 133, 133, 133, 133, 133, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 136, 136, 136, 136, 136, 136, 136, 136, 136, 137, 139, 142, 142, 142, 143, 143, 143, 145, 145, 145, 166, 167, 168, 170, 170, 172, 176, 177, 180, 180, 180, 0, 0, 0, 181, 182, 182, 185, 186, 186, 187, 188, 188, 189, 190, 191, 192, 192, 192, 192, 192, 0, 0, 0, 193, 193, 193, 194, 194, 195, 197, 197, 0, 0, 0, 198, 198, 198, 201, 203, 204, 205, 205, 206, 210, 212, 213, 214, 216, 221, 0, 221, 0, 0, 0, 221, 0, 0, 0, 221, 0, 0, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 237, 237, 0, 237, 237, 0, 0, 0, 237, 237, 0, 0, 0, 237, 237, 0, 0, 240, 240, 241, 242, 242, 243, 244, 244, 245, 248, 248, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 151, 152, 162, 163, 168, 169, 170, 175, 176, 179, 183, 186, 189, 191, 200, 201, 206, 207, 208, 213, 214, 217, 221, 224, 227, 229, 237, 238, 239, 244, 245, 247, 248, 249, 260, 261, 262, 267, 268, 269, 270, 272, 273, 274, 275, 389, 390, 391, 392, 393, 398, 399, 400, 401, 402, 404, 405, 410, 411, 412, 413, 414, 415, 416, 417, 418, 420, 421, 426, 427, 430, 431, 432, 437, 438, 439, 442, 443, 444, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 471, 472, 473, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 511, 512, 513, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 562, 568, 569, 574, 575, 576, 577, 579, 580, 581, 649, 650, 651, 652, 653, 654, 657, 659, 661, 666, 667, 669, 672, 676, 679, 680, 681, 685, 686, 691, 692, 695, 696, 698, 699, 700, 701, 706, 707, 708, 713, 714, 717, 721, 724, 725, 726, 729, 734, 735, 739, 744, 745, 748, 752, 755, 756, 757, 760, 763, 764, 765, 770, 771, 776, 779, 782, 784, 787, 793, 795, 798, 800, 803, 807, 810, 812, 815, 819, 822, 824, 827, 833, 835, 838, 840, 843, 845, 848, 850, 853, 855, 858, 860, 863, 864, 866, 869, 870, 872, 875, 879, 882, 883, 885, 888, 892, 895, 896, 898, 901, 907, 908, 910, 913, 914, 916, 919, 920, 922, 925, 926, 947, 950, 953, 957, 961, 964, 967, 971, 975, 978, 981, 985, 989, 992, 995, 999, 1003, 1006, 1009, 1013, 1017, 1020, 1023, 1027, 1031, 1034, 1037, 1041, 1045, 1048, 1051, 1055, 1059, 1062, 1065, 1069, 1073, 1076, 1079, 1083, 1087, 1090, 1093, 1097, 1101, 1104, 1107, 1111, 1115, 1118, 1121, 1125, 1129, 1132, 1135, 1139, 1143, 1146, 1149, 1153, 1157, 1160, 1163, 1167};
/* BEGIN LINEINFO 
assign 1 36 111
new 0 36 111
assign 1 36 112
quoteGet 0 36 112
assign 1 37 113
new 0 37 113
assign 1 38 114
new 0 38 114
assign 1 39 115
new 0 39 115
assign 1 40 116
new 0 40 116
assign 1 41 117
new 0 41 117
assign 1 41 118
spaceGet 0 41 118
assign 1 42 119
new 0 42 119
assign 1 42 120
colonGet 0 42 120
assign 1 43 121
new 0 43 121
assign 1 44 122
new 0 44 122
assign 1 44 123
crGet 0 44 123
assign 1 45 124
new 0 45 124
assign 1 45 125
lfGet 0 45 125
assign 1 46 126
new 0 46 126
assign 1 47 127
add 1 47 127
assign 1 47 128
add 1 47 128
assign 1 47 129
add 1 47 129
assign 1 47 130
add 1 47 130
assign 1 47 131
add 1 47 131
assign 1 47 132
add 1 47 132
assign 1 47 133
add 1 47 133
assign 1 47 134
add 1 47 134
assign 1 47 135
add 1 47 135
assign 1 47 136
add 1 47 136
assign 1 47 137
new 0 47 137
assign 1 47 138
add 1 47 138
assign 1 48 139
new 0 48 139
assign 1 48 140
new 2 48 140
assign 1 49 141
new 0 49 141
assign 1 49 142
hexNew 1 49 142
assign 1 50 143
new 0 50 143
assign 1 50 144
hexNew 1 50 144
assign 1 51 145
new 0 51 145
assign 1 51 146
hexNew 1 51 146
assign 1 57 151
tokenize 1 57 151
parseTokens 2 57 152
assign 1 62 162
new 0 62 162
assign 1 62 163
lesserEquals 1 62 168
assign 1 62 169
new 0 62 169
assign 1 62 170
lesserEquals 1 62 175
assign 1 0 176
assign 1 0 179
assign 1 0 183
assign 1 63 186
new 0 63 186
assign 1 65 189
new 0 65 189
return 1 67 191
assign 1 73 200
new 0 73 200
assign 1 73 201
lesserEquals 1 73 206
assign 1 73 207
new 0 73 207
assign 1 73 208
lesserEquals 1 73 213
assign 1 0 214
assign 1 0 217
assign 1 0 221
assign 1 74 224
new 0 74 224
assign 1 76 227
new 0 76 227
return 1 78 229
assign 1 83 237
sizeGet 0 83 237
assign 1 83 238
new 0 83 238
assign 1 83 239
lesser 1 83 244
return 1 84 245
assign 1 86 247
new 0 86 247
assign 1 86 248
substring 1 86 248
return 1 86 249
assign 1 90 260
sizeGet 0 90 260
assign 1 90 261
new 0 90 261
assign 1 90 262
lesser 1 90 267
assign 1 91 268
new 0 91 268
assign 1 91 269
new 1 91 269
throw 1 91 270
assign 1 93 272
new 0 93 272
assign 1 93 273
substring 1 93 273
assign 1 93 274
hexNew 1 93 274
return 1 93 275
assign 1 98 389
capacityGet 0 98 389
assign 1 98 390
sizeGet 0 98 390
assign 1 98 391
subtract 1 98 391
assign 1 98 392
new 0 98 392
assign 1 98 393
lesser 1 98 398
assign 1 99 399
sizeGet 0 99 399
assign 1 99 400
new 0 99 400
assign 1 99 401
add 1 99 401
capacitySet 1 99 402
assign 1 101 404
sizeGet 0 101 404
assign 1 104 405
def 1 104 410
assign 1 106 411
subtractValue 1 107 412
assign 1 108 413
new 0 108 413
shiftLeftValue 1 108 414
subtractValue 1 109 415
addValue 1 110 416
addValue 1 111 417
assign 1 112 418
assign 1 118 420
new 0 118 420
assign 1 118 421
lesser 1 118 426
assign 1 119 427
new 0 119 427
assign 1 120 430
new 0 120 430
assign 1 120 431
hexNew 1 120 431
assign 1 120 432
lesser 1 120 437
setIntUnchecked 2 121 438
assign 1 122 439
new 0 122 439
assign 1 123 442
new 0 123 442
assign 1 123 443
hexNew 1 123 443
assign 1 123 444
lesser 1 123 449
assign 1 124 450
new 0 124 450
assign 1 124 451
hexNew 1 124 451
assign 1 124 452
new 0 124 452
assign 1 124 453
hexNew 1 124 453
assign 1 124 454
and 1 124 454
assign 1 124 455
new 0 124 455
assign 1 124 456
shiftRight 1 124 456
assign 1 124 457
add 1 124 457
setIntUnchecked 2 124 458
assign 1 125 459
new 0 125 459
assign 1 125 460
add 1 125 460
assign 1 125 461
new 0 125 461
assign 1 125 462
hexNew 1 125 462
assign 1 125 463
new 0 125 463
assign 1 125 464
hexNew 1 125 464
assign 1 125 465
and 1 125 465
assign 1 125 466
add 1 125 466
setIntUnchecked 2 125 467
assign 1 126 468
new 0 126 468
assign 1 127 471
new 0 127 471
assign 1 127 472
hexNew 1 127 472
assign 1 127 473
lesser 1 127 478
assign 1 128 479
new 0 128 479
assign 1 128 480
hexNew 1 128 480
assign 1 128 481
new 0 128 481
assign 1 128 482
hexNew 1 128 482
assign 1 128 483
and 1 128 483
assign 1 128 484
new 0 128 484
assign 1 128 485
shiftRight 1 128 485
assign 1 128 486
add 1 128 486
setIntUnchecked 2 128 487
assign 1 129 488
new 0 129 488
assign 1 129 489
add 1 129 489
assign 1 129 490
new 0 129 490
assign 1 129 491
hexNew 1 129 491
assign 1 129 492
new 0 129 492
assign 1 129 493
hexNew 1 129 493
assign 1 129 494
and 1 129 494
assign 1 129 495
new 0 129 495
assign 1 129 496
shiftRight 1 129 496
assign 1 129 497
add 1 129 497
setIntUnchecked 2 129 498
assign 1 130 499
new 0 130 499
assign 1 130 500
add 1 130 500
assign 1 130 501
new 0 130 501
assign 1 130 502
hexNew 1 130 502
assign 1 130 503
new 0 130 503
assign 1 130 504
hexNew 1 130 504
assign 1 130 505
and 1 130 505
assign 1 130 506
add 1 130 506
setIntUnchecked 2 130 507
assign 1 131 508
new 0 131 508
assign 1 132 511
new 0 132 511
assign 1 132 512
hexNew 1 132 512
assign 1 132 513
lesserEquals 1 132 518
assign 1 133 519
new 0 133 519
assign 1 133 520
hexNew 1 133 520
assign 1 133 521
new 0 133 521
assign 1 133 522
hexNew 1 133 522
assign 1 133 523
and 1 133 523
assign 1 133 524
new 0 133 524
assign 1 133 525
shiftRight 1 133 525
assign 1 133 526
add 1 133 526
setIntUnchecked 2 133 527
assign 1 134 528
new 0 134 528
assign 1 134 529
add 1 134 529
assign 1 134 530
new 0 134 530
assign 1 134 531
hexNew 1 134 531
assign 1 134 532
new 0 134 532
assign 1 134 533
hexNew 1 134 533
assign 1 134 534
and 1 134 534
assign 1 134 535
new 0 134 535
assign 1 134 536
shiftRight 1 134 536
assign 1 134 537
add 1 134 537
setIntUnchecked 2 134 538
assign 1 135 539
new 0 135 539
assign 1 135 540
add 1 135 540
assign 1 135 541
new 0 135 541
assign 1 135 542
hexNew 1 135 542
assign 1 135 543
new 0 135 543
assign 1 135 544
hexNew 1 135 544
assign 1 135 545
and 1 135 545
assign 1 135 546
new 0 135 546
assign 1 135 547
shiftRight 1 135 547
assign 1 135 548
add 1 135 548
setIntUnchecked 2 135 549
assign 1 136 550
new 0 136 550
assign 1 136 551
add 1 136 551
assign 1 136 552
new 0 136 552
assign 1 136 553
hexNew 1 136 553
assign 1 136 554
new 0 136 554
assign 1 136 555
hexNew 1 136 555
assign 1 136 556
and 1 136 556
assign 1 136 557
add 1 136 557
setIntUnchecked 2 136 558
assign 1 137 559
new 0 137 559
assign 1 139 562
new 0 139 562
assign 1 142 568
new 0 142 568
assign 1 142 569
lesser 1 142 574
assign 1 143 575
new 0 143 575
assign 1 143 576
new 1 143 576
throw 1 143 577
assign 1 145 579
sizeGet 0 145 579
assign 1 145 580
add 1 145 580
sizeSet 1 145 581
assign 1 166 649
new 0 166 649
assign 1 167 650
new 0 167 650
assign 1 168 651
new 0 168 651
assign 1 170 652
new 0 170 652
assign 1 170 653
fromEscapesGet 0 170 653
assign 1 172 654
linkedListIteratorGet 0 172 654
assign 1 176 657
hasNextGet 0 176 657
assign 1 177 659
nextGet 0 177 659
assign 1 180 661
not 0 180 666
assign 1 180 667
equals 1 180 667
assign 1 0 669
assign 1 0 672
assign 1 0 676
assign 1 181 679
new 0 181 679
assign 1 182 680
extractString 0 182 680
handleString 1 182 681
assign 1 185 685
get 1 185 685
assign 1 186 686
def 1 186 691
addValue 1 187 692
assign 1 188 695
new 0 188 695
assign 1 188 696
begins 1 188 696
assign 1 189 698
jsonUcUnescape 1 189 698
assign 1 190 699
jsonUcGetAfterPart 1 190 699
assign 1 191 700
new 0 191 700
assign 1 192 701
def 1 192 706
assign 1 192 707
jsonUcIsPairEnd 1 192 707
assign 1 192 708
not 0 192 713
assign 1 0 714
assign 1 0 717
assign 1 0 721
assign 1 193 724
new 0 193 724
assign 1 193 725
new 1 193 725
throw 1 193 726
assign 1 194 729
undef 1 194 734
assign 1 195 735
jsonUcIsPairStart 1 195 735
assign 1 197 739
def 1 197 744
assign 1 0 745
assign 1 0 748
assign 1 0 752
assign 1 198 755
new 0 198 755
assign 1 198 756
new 1 198 756
throw 1 198 757
assign 1 201 760
jsonUcAppendValue 3 203 763
assign 1 204 764
assign 1 205 765
def 1 205 770
addValue 1 206 771
addValue 1 210 776
assign 1 212 779
new 0 212 779
assign 1 213 782
equals 1 213 782
assign 1 214 784
new 0 214 784
addValue 1 216 787
assign 1 221 793
equals 1 221 793
assign 1 0 795
assign 1 221 798
equals 1 221 798
assign 1 0 800
assign 1 0 803
assign 1 0 807
assign 1 221 810
equals 1 221 810
assign 1 0 812
assign 1 0 815
assign 1 0 819
assign 1 221 822
equals 1 221 822
assign 1 0 824
assign 1 0 827
assign 1 222 833
equals 1 222 833
assign 1 223 835
new 0 223 835
assign 1 224 838
equals 1 224 838
beginMap 0 225 840
assign 1 226 843
equals 1 226 843
endMap 0 227 845
assign 1 228 848
equals 1 228 848
kvMid 0 229 850
assign 1 230 853
equals 1 230 853
beginList 0 231 855
assign 1 232 858
equals 1 232 858
endList 0 233 860
assign 1 237 863
new 0 237 863
assign 1 237 864
equals 1 237 864
assign 1 0 866
assign 1 237 869
new 0 237 869
assign 1 237 870
equals 1 237 870
assign 1 0 872
assign 1 0 875
assign 1 0 879
assign 1 237 882
new 0 237 882
assign 1 237 883
equals 1 237 883
assign 1 0 885
assign 1 0 888
assign 1 0 892
assign 1 237 895
new 0 237 895
assign 1 237 896
equals 1 237 896
assign 1 0 898
assign 1 0 901
assign 1 240 907
new 0 240 907
assign 1 240 908
equals 1 240 908
handleTrue 0 241 910
assign 1 242 913
new 0 242 913
assign 1 242 914
equals 1 242 914
handleFalse 0 243 916
assign 1 244 919
new 0 244 919
assign 1 244 920
equals 1 244 920
handleNull 0 245 922
assign 1 248 925
new 1 248 925
handleInteger 1 248 926
return 1 0 947
return 1 0 950
assign 1 0 953
assign 1 0 957
return 1 0 961
return 1 0 964
assign 1 0 967
assign 1 0 971
return 1 0 975
return 1 0 978
assign 1 0 981
assign 1 0 985
return 1 0 989
return 1 0 992
assign 1 0 995
assign 1 0 999
return 1 0 1003
return 1 0 1006
assign 1 0 1009
assign 1 0 1013
return 1 0 1017
return 1 0 1020
assign 1 0 1023
assign 1 0 1027
return 1 0 1031
return 1 0 1034
assign 1 0 1037
assign 1 0 1041
return 1 0 1045
return 1 0 1048
assign 1 0 1051
assign 1 0 1055
return 1 0 1059
return 1 0 1062
assign 1 0 1065
assign 1 0 1069
return 1 0 1073
return 1 0 1076
assign 1 0 1079
assign 1 0 1083
return 1 0 1087
return 1 0 1090
assign 1 0 1093
assign 1 0 1097
return 1 0 1101
return 1 0 1104
assign 1 0 1107
assign 1 0 1111
return 1 0 1115
return 1 0 1118
assign 1 0 1121
assign 1 0 1125
return 1 0 1129
return 1 0 1132
assign 1 0 1135
assign 1 0 1139
return 1 0 1143
return 1 0 1146
assign 1 0 1149
assign 1 0 1153
return 1 0 1157
return 1 0 1160
assign 1 0 1163
assign 1 0 1167
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1851908877: return bem_hashGet_0();
case -322023006: return bem_spaceGetDirect_0();
case -573019162: return bem_tokensGet_0();
case -1123278056: return bem_tagGet_0();
case -1362850090: return bem_serializeContents_0();
case 96033137: return bem_serializeToString_0();
case 1845705525: return bem_tokensGetDirect_0();
case 990360647: return bem_new_0();
case 1181292604: return bem_hsubGet_0();
case 1071461198: return bem_echo_0();
case 535422713: return bem_rbraceGet_0();
case 214645977: return bem_spaceGet_0();
case 1942283510: return bem_sourceFileNameGet_0();
case -1539176166: return bem_escapeGetDirect_0();
case 611670694: return bem_fieldIteratorGet_0();
case 1052257532: return bem_tokerGet_0();
case -1271235603: return bem_lbraceGet_0();
case 21779751: return bem_lbraceGetDirect_0();
case -449079106: return bem_iteratorGet_0();
case -1173869143: return bem_escapeGet_0();
case -2102432892: return bem_rbraceGetDirect_0();
case -1652236334: return bem_lfGetDirect_0();
case -1676076847: return bem_lbracketGetDirect_0();
case 341575045: return bem_many_0();
case -170207851: return bem_vsubGetDirect_0();
case 1406551785: return bem_commaGet_0();
case -1519333444: return bem_commaGetDirect_0();
case -713163994: return bem_toAny_0();
case -1559257695: return bem_colonGetDirect_0();
case 711792431: return bem_hmAddGetDirect_0();
case 1503944855: return bem_lfGet_0();
case -495312262: return bem_rbracketGet_0();
case -2051518290: return bem_once_0();
case 1194804327: return bem_fieldNamesGet_0();
case -1520988939: return bem_crGetDirect_0();
case 1800073141: return bem_crGet_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case -1086782351: return bem_print_0();
case 1156702397: return bem_quoteGetDirect_0();
case -1266447496: return bem_classNameGet_0();
case -1690728143: return bem_quoteGet_0();
case 1513233059: return bem_toString_0();
case 1213119171: return bem_hmAddGet_0();
case 1920247642: return bem_tokerGetDirect_0();
case -756044833: return bem_colonGet_0();
case -10010145: return bem_copy_0();
case -1667838045: return bem_lbracketGet_0();
case -501851149: return bem_rbracketGetDirect_0();
case 1752124974: return bem_hsubGetDirect_0();
case 144584723: return bem_create_0();
case -21030099: return bem_vsubGet_0();
case 1577195459: return bem_serializationIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1449340032: return bem_otherClass_1(bevd_0);
case -195613098: return bem_lfSetDirect_1(bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1023673539: return bem_hmAddSetDirect_1(bevd_0);
case 8428042: return bem_escapeSetDirect_1(bevd_0);
case 871744930: return bem_jsonUcUnescape_1((BEC_2_4_6_TextString) bevd_0);
case -710042583: return bem_quoteSetDirect_1(bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case -1031490054: return bem_crSetDirect_1(bevd_0);
case -2064353214: return bem_spaceSetDirect_1(bevd_0);
case -1221527741: return bem_lbracketSet_1(bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case -300867936: return bem_vsubSet_1(bevd_0);
case -1572846802: return bem_jsonUcIsPairEnd_1((BEC_2_4_3_MathInt) bevd_0);
case -940049438: return bem_commaSetDirect_1(bevd_0);
case -980765305: return bem_hmAddSet_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case -1352389939: return bem_tokensSetDirect_1(bevd_0);
case 458777342: return bem_quoteSet_1(bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case -2129983132: return bem_jsonUcIsPairStart_1((BEC_2_4_3_MathInt) bevd_0);
case 1305362535: return bem_tokerSet_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
case 276607161: return bem_lbraceSet_1(bevd_0);
case -516749105: return bem_hsubSetDirect_1(bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case 813894548: return bem_hsubSet_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case 827084579: return bem_rbraceSetDirect_1(bevd_0);
case -2001486017: return bem_rbracketSetDirect_1(bevd_0);
case 864885155: return bem_lfSet_1(bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1476578041: return bem_colonSetDirect_1(bevd_0);
case -1624532954: return bem_colonSet_1(bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1679331816: return bem_rbraceSet_1(bevd_0);
case 2010773703: return bem_lbracketSetDirect_1(bevd_0);
case -1712591852: return bem_tokensSet_1(bevd_0);
case 2104047764: return bem_rbracketSet_1(bevd_0);
case 2012808989: return bem_escapeSet_1(bevd_0);
case -1685629723: return bem_commaSet_1(bevd_0);
case 26118900: return bem_jsonUcGetAfterPart_1((BEC_2_4_6_TextString) bevd_0);
case 659386277: return bem_tokerSetDirect_1(bevd_0);
case -655019399: return bem_def_1(bevd_0);
case 1352374465: return bem_lbraceSetDirect_1(bevd_0);
case 1394518783: return bem_spaceSet_1(bevd_0);
case 1288546306: return bem_crSet_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1513034924: return bem_vsubSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -950083166: return bem_parse_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -704141179: return bem_parseTokens_2((BEC_2_9_10_ContainerLinkedList) bevd_0, bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1705232268: return bem_jsonUcAppendValue_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_4_6_JsonParser_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_6_JsonParser_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_6_JsonParser();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst = (BEC_2_4_6_JsonParser) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_6_JsonParser.bece_BEC_2_4_6_JsonParser_bevs_type;
}
}
}
