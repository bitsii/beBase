namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_4_ContainerMaps : BEC_2_6_8_SystemVariadic {
public BEC_2_9_4_ContainerMaps() { }
static BEC_2_9_4_ContainerMaps() { }
private static byte[] becc_BEC_2_9_4_ContainerMaps_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x73};
private static byte[] becc_BEC_2_9_4_ContainerMaps_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerMaps_bevo_0 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_inst;

public static new BET_2_9_4_ContainerMaps bece_BEC_2_9_4_ContainerMaps_bevs_type;

public virtual BEC_2_9_4_ContainerMaps bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_from_1(BEC_2_9_4_ContainerList beva_list) {
BEC_2_4_3_MathInt bevl_ls = null;
BEC_2_9_3_ContainerMap bevl_map = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevl_ls = beva_list.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerMaps_bevo_0;
bevt_0_tmpany_phold = bevl_ls.bem_add_1(bevt_1_tmpany_phold);
bevl_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 725 */ {
if (bevl_i.bevi_int < bevl_ls.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 725 */ {
bevt_3_tmpany_phold = beva_list.bem_get_1(bevl_i);
bevl_i.bevi_int++;
bevt_5_tmpany_phold = bevl_i;
bevt_4_tmpany_phold = beva_list.bem_get_1(bevt_5_tmpany_phold);
bevl_map.bem_put_2(bevt_3_tmpany_phold, bevt_4_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 725 */
 else  /* Line: 725 */ {
break;
} /* Line: 725 */
} /* Line: 725 */
return bevl_map;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_fieldsIntoMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_9_3_ContainerMap beva_res) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(1297175099);
while (true)
 /* Line: 732 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(-816433081);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 732 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(-1887247858);
bevt_2_tmpany_phold = bevl_i.bemd_0(804428484);
beva_res.bem_put_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 733 */
 else  /* Line: 732 */ {
break;
} /* Line: 732 */
} /* Line: 732 */
return beva_res;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_mapIntoFields_2(BEC_2_9_3_ContainerMap beva_from, BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_i = beva_inst.bemd_0(1297175099);
while (true)
 /* Line: 739 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(-816433081);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 739 */ {
bevt_2_tmpany_phold = bevl_i.bemd_0(-1887247858);
bevt_1_tmpany_phold = beva_from.bem_get_1(bevt_2_tmpany_phold);
bevl_i.bemd_1(492435786, bevt_1_tmpany_phold);
} /* Line: 740 */
 else  /* Line: 739 */ {
break;
} /* Line: 739 */
} /* Line: 739 */
return beva_inst;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {723, 724, 724, 724, 725, 725, 725, 726, 726, 726, 726, 725, 728, 732, 732, 733, 733, 733, 735, 739, 739, 740, 740, 740, 742};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 29, 30, 33, 38, 39, 40, 42, 43, 44, 50, 57, 60, 62, 63, 64, 70, 77, 80, 82, 83, 84, 90};
/* BEGIN LINEINFO 
assign 1 723 26
sizeGet 0 723 26
assign 1 724 27
new 0 724 27
assign 1 724 28
add 1 724 28
assign 1 724 29
new 1 724 29
assign 1 725 30
new 0 725 30
assign 1 725 33
lesser 1 725 38
assign 1 726 39
get 1 726 39
assign 1 726 40
incrementValue 0 726 40
assign 1 726 42
get 1 726 42
put 2 726 43
incrementValue 0 725 44
return 1 728 50
assign 1 732 57
fieldIteratorGet 0 732 57
assign 1 732 60
hasNextGet 0 732 60
assign 1 733 62
nextNameGet 0 733 62
assign 1 733 63
currentGet 0 733 63
put 2 733 64
return 1 735 70
assign 1 739 77
fieldIteratorGet 0 739 77
assign 1 739 80
hasNextGet 0 739 80
assign 1 740 82
nextNameGet 0 740 82
assign 1 740 83
get 1 740 83
currentSet 1 740 84
return 1 742 90
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1253246070: return bem_create_0();
case 1014225644: return bem_echo_0();
case -1882364243: return bem_many_0();
case -628560707: return bem_toAny_0();
case -2123848647: return bem_fieldNamesGet_0();
case 770834928: return bem_serializeContents_0();
case 1297175099: return bem_fieldIteratorGet_0();
case -753894116: return bem_new_0();
case -1074341902: return bem_print_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -1138072028: return bem_tagGet_0();
case 844225351: return bem_classNameGet_0();
case -2083934905: return bem_copy_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 80244442: return bem_toString_0();
case -2131387379: return bem_iteratorGet_0();
case -1625648722: return bem_once_0();
case -1194289304: return bem_serializeToString_0();
case -720093952: return bem_default_0();
case 1165329653: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 84991399: return bem_from_1((BEC_2_9_4_ContainerList) bevd_0);
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -636442813: return bem_def_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -503522834: return bem_mapIntoFields_2((BEC_2_9_3_ContainerMap) bevd_0, bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -582050424: return bem_fieldsIntoMap_2(bevd_0, (BEC_2_9_3_ContainerMap) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerMaps_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_4_ContainerMaps_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerMaps();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst = (BEC_2_9_4_ContainerMaps) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_type;
}
}
}
