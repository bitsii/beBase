namespace be {
/* IO:File: source/base/Map.be */
public class BEC_3_9_3_7_ContainerMapMapNode : BEC_3_9_3_7_ContainerSetSetNode {
public BEC_3_9_3_7_ContainerMapMapNode() { }
static BEC_3_9_3_7_ContainerMapMapNode() { }
private static byte[] becc_BEC_3_9_3_7_ContainerMapMapNode_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70,0x3A,0x4D,0x61,0x70,0x4E,0x6F,0x64,0x65};
private static byte[] becc_BEC_3_9_3_7_ContainerMapMapNode_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_3_9_3_7_ContainerMapMapNode bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst;

public static new BET_3_9_3_7_ContainerMapMapNode bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_type;

public BEC_2_6_6_SystemObject bevp_value;
public override BEC_3_9_3_7_ContainerSetSetNode bem_new_3(BEC_2_6_6_SystemObject beva__hval, BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) {
base.bem_new_3(beva__hval, beva__key, beva__value);
bevp_value = beva__value;
return this;
} /*method end*/
public override BEC_3_9_3_7_ContainerSetSetNode bem_putTo_2(BEC_2_6_6_SystemObject beva__key, BEC_2_6_6_SystemObject beva__value) {
bevp_key = beva__key;
bevp_value = beva__value;
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFrom_0() {
return bevp_value;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_valueGet_0() {
return bevp_value;
} /*method end*/
public BEC_2_6_6_SystemObject bem_valueGetDirect_0() {
return bevp_value;
} /*method end*/
public virtual BEC_3_9_3_7_ContainerMapMapNode bem_valueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_value = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_3_7_ContainerMapMapNode bem_valueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_value = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {41, 44, 50, 51, 55, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 24, 27, 30, 33, 37};
/* BEGIN LINEINFO 
new 3 41 14
assign 1 44 15
assign 1 50 19
assign 1 51 20
return 1 55 24
return 1 0 27
return 1 0 30
assign 1 0 33
assign 1 0 37
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -448727787: return bem_hvalGet_0();
case -1916417292: return bem_keyGetDirect_0();
case 1388220454: return bem_once_0();
case 2105223545: return bem_keyGet_0();
case 855089063: return bem_toAny_0();
case 876979386: return bem_iteratorGet_0();
case 1699975688: return bem_hvalGetDirect_0();
case -1287291624: return bem_toString_0();
case 262448459: return bem_fieldNamesGet_0();
case -485032950: return bem_print_0();
case -1242864862: return bem_sourceFileNameGet_0();
case -1497387944: return bem_many_0();
case -1820718044: return bem_echo_0();
case -393212436: return bem_valueGetDirect_0();
case 1739040137: return bem_fieldIteratorGet_0();
case -1718750264: return bem_tagGet_0();
case 1978340744: return bem_copy_0();
case 1139687182: return bem_serializeToString_0();
case -380774728: return bem_serializationIteratorGet_0();
case 1516511629: return bem_serializeContents_0();
case 1115941233: return bem_hashGet_0();
case 1915551322: return bem_getFrom_0();
case 1452290892: return bem_valueGet_0();
case 1044385788: return bem_new_0();
case 347445468: return bem_deserializeClassNameGet_0();
case -1936404363: return bem_create_0();
case 1846641427: return bem_classNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 477404510: return bem_undefined_1(bevd_0);
case 1787200380: return bem_hvalSetDirect_1(bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case -1972578172: return bem_keySetDirect_1(bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case -649656411: return bem_keySet_1(bevd_0);
case -847200836: return bem_def_1(bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case 1799302662: return bem_valueSet_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case -1422665383: return bem_valueSetDirect_1(bevd_0);
case 919988915: return bem_hvalSet_1(bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1298300720: return bem_putTo_2(bevd_0, bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -557582082: return bem_new_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_9_3_7_ContainerMapMapNode_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_3_9_3_7_ContainerMapMapNode_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_9_3_7_ContainerMapMapNode();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst = (BEC_3_9_3_7_ContainerMapMapNode) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_9_3_7_ContainerMapMapNode.bece_BEC_3_9_3_7_ContainerMapMapNode_bevs_type;
}
}
}
