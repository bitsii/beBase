namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_7_TextStrings : BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
static BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_7_TextStrings_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_6_TextString bece_BEC_2_4_7_TextStrings_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_7_TextStrings_bels_4, 0));
public static new BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static new BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_4_9_TextTokenizer bevp_lineSplitter;
public BEC_2_9_3_ContainerSet bevp_ws;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_space = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevp_quote = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_tab = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_cr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevp_dosNewline);
bevp_ws = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(2045941275);
bevt_1_ta_ph = bevl_i.bemd_0(-508298247);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1080161714);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1289*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1290*/
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(450495808);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1294*/ {
bevt_4_ta_ph = bevl_i.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1294*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(450495808);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1296*/
 else /* Line: 1294*/ {
break;
} /* Line: 1294*/
} /* Line: 1294*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_beg = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1306*/ {
bevt_0_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 1306*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_ta_ph = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_ta_ph.bevi_bool)/* Line: 1308*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1309*/ {
bevl_end.bevi_int++;
} /* Line: 1310*/
 else /* Line: 1311*/ {
bevl_beg.bevi_int++;
} /* Line: 1312*/
} /* Line: 1309*/
 else /* Line: 1314*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_ta_ph.bevi_int;
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1316*/
} /* Line: 1308*/
 else /* Line: 1306*/ {
break;
} /* Line: 1306*/
} /* Line: 1306*/
if (bevl_foundChar.bevi_bool)/* Line: 1319*/ {
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_ta_ph);
} /* Line: 1320*/
 else /* Line: 1321*/ {
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1322*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1328*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1328*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1328*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1328*/ {
return null;
} /* Line: 1328*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1334*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1334*/ {
bevl_ai.bemd_1(-464526900, bevl_av);
bevl_bi.bemd_1(-464526900, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1337*/ {
bevt_9_ta_ph = bece_BEC_2_4_7_TextStrings_bevo_0;
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1338*/
bevl_i.bevi_int++;
} /* Line: 1334*/
 else /* Line: 1334*/ {
break;
} /* Line: 1334*/
} /* Line: 1334*/
bevt_11_ta_ph = bece_BEC_2_4_7_TextStrings_bevo_1;
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(2045941275);
while (true)
/* Line: 1345*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1345*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(450495808);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1346*/ {
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1347*/
} /* Line: 1346*/
 else /* Line: 1345*/ {
break;
} /* Line: 1345*/
} /* Line: 1345*/
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1354*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = bece_BEC_2_4_7_TextStrings_bevo_2;
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1354*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1354*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1354*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1355*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1361*/ {
bevt_3_ta_ph = bece_BEC_2_4_7_TextStrings_bevo_3;
bevt_2_ta_ph = beva_value.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1361*/
 else /* Line: 1361*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1361*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1362*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGetDirect_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGetDirect_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGetDirect_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGetDirect_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_TextString bem_crGetDirect_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGetDirect_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGetDirect_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGet_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lineSplitterGetDirect_0() {
return bevp_lineSplitter;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lineSplitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lineSplitter = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() {
return bevp_ws;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGetDirect_0() {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1263, 1264, 1265, 1265, 1266, 1266, 1267, 1268, 1270, 1270, 1271, 1272, 1273, 1274, 1277, 1278, 1279, 1280, 1284, 1284, 1288, 1289, 1289, 1290, 1290, 1292, 1293, 1293, 1294, 1295, 1296, 1296, 1298, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1310, 1312, 1315, 1315, 1316, 1320, 1320, 1320, 1322, 1324, 1328, 1328, 0, 1328, 1328, 0, 0, 1328, 1329, 1329, 1329, 1329, 1330, 1331, 1332, 1333, 1334, 1334, 1334, 1335, 1336, 1337, 1338, 1338, 1338, 1334, 1341, 1341, 1341, 1345, 0, 1345, 1345, 1346, 1347, 1347, 1350, 1350, 1354, 1354, 0, 1354, 1354, 1354, 1354, 0, 0, 1355, 1355, 1357, 1357, 1361, 1361, 1361, 1361, 0, 0, 0, 1362, 1362, 1364, 1364, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 65, 66, 77, 78, 79, 81, 82, 84, 85, 86, 89, 91, 92, 93, 99, 113, 114, 115, 116, 119, 121, 122, 125, 128, 132, 133, 134, 142, 143, 144, 147, 149, 170, 175, 176, 179, 184, 185, 188, 192, 194, 195, 196, 197, 198, 199, 200, 201, 202, 205, 210, 211, 212, 213, 215, 216, 217, 219, 225, 226, 227, 236, 236, 239, 241, 242, 244, 245, 252, 253, 263, 268, 269, 272, 273, 274, 279, 280, 283, 287, 288, 290, 291, 300, 305, 306, 307, 309, 312, 316, 319, 320, 322, 323, 326, 329, 332, 336, 340, 343, 346, 350, 354, 357, 360, 364, 368, 371, 374, 378, 382, 385, 388, 392, 396, 399, 402, 406, 410, 413, 416, 420, 424, 427, 430, 434, 438, 441, 444, 448, 452, 455, 458, 462, 466, 469, 472, 476, 480, 483, 486, 490};
/* BEGIN LINEINFO 
assign 1 1263 43
new 0 1263 43
assign 1 1264 44
new 0 1264 44
assign 1 1265 45
new 0 1265 45
assign 1 1265 46
codeNew 1 1265 46
assign 1 1266 47
new 0 1266 47
assign 1 1266 48
codeNew 1 1266 48
assign 1 1267 49
new 0 1267 49
assign 1 1268 50
new 0 1268 50
assign 1 1270 51
new 0 1270 51
assign 1 1270 52
codeNew 1 1270 52
assign 1 1271 53
new 0 1271 53
assign 1 1272 54
new 0 1272 54
assign 1 1273 55
new 1 1273 55
assign 1 1274 56
new 0 1274 56
put 1 1277 57
put 1 1278 58
put 1 1279 59
put 1 1280 60
assign 1 1284 65
joinBuffer 2 1284 65
return 1 1284 66
assign 1 1288 77
iteratorGet 0 1288 77
assign 1 1289 78
hasNextGet 0 1289 78
assign 1 1289 79
not 0 1289 79
assign 1 1290 81
new 0 1290 81
return 1 1290 82
assign 1 1292 84
new 0 1292 84
assign 1 1293 85
nextGet 0 1293 85
addValue 1 1293 86
assign 1 1294 89
hasNextGet 0 1294 89
addValue 1 1295 91
assign 1 1296 92
nextGet 0 1296 92
addValue 1 1296 93
return 1 1298 99
assign 1 1302 113
new 0 1302 113
assign 1 1303 114
new 0 1303 114
assign 1 1304 115
new 0 1304 115
assign 1 1305 116
mbiterGet 0 1305 116
assign 1 1306 119
hasNextGet 0 1306 119
assign 1 1307 121
nextGet 0 1307 121
assign 1 1308 122
has 1 1308 122
incrementValue 0 1310 125
incrementValue 0 1312 128
assign 1 1315 132
new 0 1315 132
setValue 1 1315 133
assign 1 1316 134
new 0 1316 134
assign 1 1320 142
sizeGet 0 1320 142
assign 1 1320 143
subtract 1 1320 143
assign 1 1320 144
substring 2 1320 144
assign 1 1322 147
new 0 1322 147
return 1 1324 149
assign 1 1328 170
undef 1 1328 175
assign 1 0 176
assign 1 1328 179
undef 1 1328 184
assign 1 0 185
assign 1 0 188
return 1 1328 192
assign 1 1329 194
new 0 1329 194
assign 1 1329 195
sizeGet 0 1329 195
assign 1 1329 196
sizeGet 0 1329 196
assign 1 1329 197
min 2 1329 197
assign 1 1330 198
biterGet 0 1330 198
assign 1 1331 199
biterGet 0 1331 199
assign 1 1332 200
new 0 1332 200
assign 1 1333 201
new 0 1333 201
assign 1 1334 202
new 0 1334 202
assign 1 1334 205
lesser 1 1334 210
next 1 1335 211
next 1 1336 212
assign 1 1337 213
notEquals 1 1337 213
assign 1 1338 215
new 0 1338 215
assign 1 1338 216
substring 2 1338 216
return 1 1338 217
incrementValue 0 1334 219
assign 1 1341 225
new 0 1341 225
assign 1 1341 226
substring 2 1341 226
return 1 1341 227
assign 1 1345 236
iteratorGet 0 0 236
assign 1 1345 239
hasNextGet 0 1345 239
assign 1 1345 241
nextGet 0 1345 241
assign 1 1346 242
isEmpty 1 1346 242
assign 1 1347 244
new 0 1347 244
return 1 1347 245
assign 1 1350 252
new 0 1350 252
return 1 1350 253
assign 1 1354 263
undef 1 1354 268
assign 1 0 269
assign 1 1354 272
sizeGet 0 1354 272
assign 1 1354 273
new 0 1354 273
assign 1 1354 274
lesser 1 1354 279
assign 1 0 280
assign 1 0 283
assign 1 1355 287
new 0 1355 287
return 1 1355 288
assign 1 1357 290
new 0 1357 290
return 1 1357 291
assign 1 1361 300
def 1 1361 305
assign 1 1361 306
new 0 1361 306
assign 1 1361 307
notEquals 1 1361 307
assign 1 0 309
assign 1 0 312
assign 1 0 316
assign 1 1362 319
new 0 1362 319
return 1 1362 320
assign 1 1364 322
new 0 1364 322
return 1 1364 323
return 1 0 326
return 1 0 329
assign 1 0 332
assign 1 0 336
return 1 0 340
return 1 0 343
assign 1 0 346
assign 1 0 350
return 1 0 354
return 1 0 357
assign 1 0 360
assign 1 0 364
return 1 0 368
return 1 0 371
assign 1 0 374
assign 1 0 378
return 1 0 382
return 1 0 385
assign 1 0 388
assign 1 0 392
return 1 0 396
return 1 0 399
assign 1 0 402
assign 1 0 406
return 1 0 410
return 1 0 413
assign 1 0 416
assign 1 0 420
return 1 0 424
return 1 0 427
assign 1 0 430
assign 1 0 434
return 1 0 438
return 1 0 441
assign 1 0 444
assign 1 0 448
return 1 0 452
return 1 0 455
assign 1 0 458
assign 1 0 462
return 1 0 466
return 1 0 469
assign 1 0 472
assign 1 0 476
return 1 0 480
return 1 0 483
assign 1 0 486
assign 1 0 490
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1722350338: return bem_dosNewlineGet_0();
case 119461913: return bem_tagGet_0();
case 281444821: return bem_fieldIteratorGet_0();
case -146225034: return bem_default_0();
case -678541085: return bem_classNameGet_0();
case 523024307: return bem_lfGet_0();
case -1072147214: return bem_wsGet_0();
case -1371927266: return bem_lineSplitterGetDirect_0();
case -1754478112: return bem_print_0();
case -460907505: return bem_colonGetDirect_0();
case -2017009146: return bem_new_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -1005119995: return bem_many_0();
case -879939360: return bem_newlineGet_0();
case -552136570: return bem_lineSplitterGet_0();
case -1475550710: return bem_create_0();
case -225870373: return bem_serializeToString_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 1560025621: return bem_emptyGet_0();
case 2045941275: return bem_iteratorGet_0();
case -744679096: return bem_fieldNamesGet_0();
case -1486279572: return bem_serializeContents_0();
case 493613226: return bem_quoteGet_0();
case -1275325619: return bem_toString_0();
case 749981649: return bem_wsGetDirect_0();
case -1754024727: return bem_crGet_0();
case 537009404: return bem_lfGetDirect_0();
case 501088997: return bem_sourceFileNameGet_0();
case -1898043901: return bem_colonGet_0();
case -639297756: return bem_toAny_0();
case -235374203: return bem_tabGetDirect_0();
case -545556484: return bem_once_0();
case 1116498858: return bem_emptyGetDirect_0();
case 1315815191: return bem_tabGet_0();
case 1969977777: return bem_unixNewlineGet_0();
case -143833654: return bem_quoteGetDirect_0();
case 611702865: return bem_copy_0();
case 559892397: return bem_newlineGetDirect_0();
case 440530393: return bem_unixNewlineGetDirect_0();
case 1047054713: return bem_crGetDirect_0();
case -1583672278: return bem_echo_0();
case 605777878: return bem_spaceGet_0();
case 1303235199: return bem_spaceGetDirect_0();
case 637821193: return bem_dosNewlineGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 68490123: return bem_quoteSet_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1142292898: return bem_crSetDirect_1(bevd_0);
case -286639257: return bem_lineSplitterSetDirect_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1262983326: return bem_wsSet_1(bevd_0);
case -335235590: return bem_wsSetDirect_1(bevd_0);
case 165573925: return bem_emptySetDirect_1(bevd_0);
case 1313209651: return bem_anyEmpty_1(bevd_0);
case 1703030547: return bem_lineSplitterSet_1(bevd_0);
case 703237041: return bem_dosNewlineSetDirect_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case -1898111280: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case 1696098987: return bem_lfSetDirect_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case -1913038896: return bem_newlineSet_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case -1161395071: return bem_spaceSetDirect_1(bevd_0);
case -1310245574: return bem_unixNewlineSetDirect_1(bevd_0);
case 1324430954: return bem_crSet_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 2081050147: return bem_tabSetDirect_1(bevd_0);
case 1123803803: return bem_emptySet_1(bevd_0);
case 1237530361: return bem_spaceSet_1(bevd_0);
case -1821959613: return bem_lfSet_1(bevd_0);
case -733263625: return bem_tabSet_1(bevd_0);
case -1860502079: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 231736416: return bem_quoteSetDirect_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case -251165338: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case -1991429753: return bem_unixNewlineSet_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case 1207788668: return bem_colonSet_1(bevd_0);
case -84156298: return bem_colonSetDirect_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1784722133: return bem_newlineSetDirect_1(bevd_0);
case -1542971338: return bem_dosNewlineSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1639603967: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1001732955: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -363231201: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TextStrings();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
}
