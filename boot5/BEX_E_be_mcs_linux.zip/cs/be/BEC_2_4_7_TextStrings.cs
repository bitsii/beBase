namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public sealed class BEC_2_4_7_TextStrings : BEC_2_6_6_SystemObject {
public BEC_2_4_7_TextStrings() { }
static BEC_2_4_7_TextStrings() { }
private static byte[] becc_BEC_2_4_7_TextStrings_clname = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x73};
private static byte[] becc_BEC_2_4_7_TextStrings_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_0 = {0x20};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_1 = {0x0D,0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_2 = {0x0A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_3 = {0x3A};
private static byte[] bece_BEC_2_4_7_TextStrings_bels_4 = {};
public static new BEC_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_inst;

public static new BET_2_4_7_TextStrings bece_BEC_2_4_7_TextStrings_bevs_type;

public BEC_2_4_3_MathInt bevp_zero;
public BEC_2_4_6_TextString bevp_space;
public BEC_2_4_6_TextString bevp_empty;
public BEC_2_4_6_TextString bevp_quote;
public BEC_2_4_6_TextString bevp_tab;
public BEC_2_4_6_TextString bevp_dosNewline;
public BEC_2_4_6_TextString bevp_unixNewline;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_4_6_TextString bevp_cr;
public BEC_2_4_6_TextString bevp_lf;
public BEC_2_4_6_TextString bevp_colon;
public BEC_2_9_3_ContainerSet bevp_ws;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_default_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevp_zero = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_space = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_0));
bevp_empty = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevp_quote = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_tab = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_1_ta_ph);
bevp_dosNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_7_TextStrings_bels_1));
bevp_unixNewline = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_cr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_2_ta_ph);
bevp_lf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_2));
bevp_colon = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_7_TextStrings_bels_3));
bevp_ws = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_ws.bem_put_1(bevp_space);
bevp_ws.bem_put_1(bevp_tab);
bevp_ws.bem_put_1(bevp_cr);
bevp_ws.bem_put_1(bevp_unixNewline);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_join_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_joinBuffer_2(beva_delim, beva_splits);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_joinBuffer_2(BEC_2_4_6_TextString beva_delim, BEC_2_6_6_SystemObject beva_splits) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_6_TextString bevl_buf = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_i = beva_splits.bemd_0(-1653939165);
bevt_1_ta_ph = bevl_i.bemd_0(-211510432);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1340623042);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 1254*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return bevt_2_ta_ph;
} /* Line: 1255*/
bevl_buf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_3_ta_ph = bevl_i.bemd_0(581391667);
bevl_buf.bem_addValue_1(bevt_3_ta_ph);
while (true)
/* Line: 1259*/ {
bevt_4_ta_ph = bevl_i.bemd_0(-211510432);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 1259*/ {
bevl_buf.bem_addValue_1(beva_delim);
bevt_5_ta_ph = bevl_i.bemd_0(581391667);
bevl_buf.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 1261*/
 else /* Line: 1259*/ {
break;
} /* Line: 1259*/
} /* Line: 1259*/
return bevl_buf;
} /*method end*/
public BEC_2_6_6_SystemObject bem_strip_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_beg = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_5_4_LogicBool bevl_foundChar = null;
BEC_2_4_17_TextMultiByteIterator bevl_mb = null;
BEC_2_4_6_TextString bevl_step = null;
BEC_2_4_6_TextString bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevl_beg = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_mb = beva_str.bem_mbiterGet_0();
while (true)
/* Line: 1271*/ {
bevt_0_ta_ph = bevl_mb.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 1271*/ {
bevl_step = bevl_mb.bem_nextGet_0();
bevt_1_ta_ph = bevp_ws.bem_has_1(bevl_step);
if (bevt_1_ta_ph.bevi_bool)/* Line: 1273*/ {
if (bevl_foundChar.bevi_bool)/* Line: 1274*/ {
bevl_end.bevi_int++;
} /* Line: 1275*/
 else /* Line: 1276*/ {
bevl_beg.bevi_int++;
} /* Line: 1277*/
} /* Line: 1274*/
 else /* Line: 1279*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_end.bevi_int = bevt_2_ta_ph.bevi_int;
bevl_foundChar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 1281*/
} /* Line: 1273*/
 else /* Line: 1271*/ {
break;
} /* Line: 1271*/
} /* Line: 1271*/
if (bevl_foundChar.bevi_bool)/* Line: 1284*/ {
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_subtract_1(bevl_end);
bevl_toRet = beva_str.bem_substring_2(bevl_beg, bevt_3_ta_ph);
} /* Line: 1285*/
 else /* Line: 1286*/ {
bevl_toRet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
} /* Line: 1287*/
return bevl_toRet;
} /*method end*/
public BEC_2_4_6_TextString bem_commonPrefix_2(BEC_2_4_6_TextString beva_a, BEC_2_4_6_TextString beva_b) {
BEC_2_4_3_MathInt bevl_sz = null;
BEC_2_6_6_SystemObject bevl_ai = null;
BEC_2_6_6_SystemObject bevl_bi = null;
BEC_2_4_6_TextString bevl_av = null;
BEC_2_4_6_TextString bevl_bv = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_4_MathInts bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
if (beva_a == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1293*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1293*/ {
if (beva_b == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1293*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1293*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1293*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1293*/ {
return null;
} /* Line: 1293*/
bevt_3_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_4_ta_ph = beva_a.bem_sizeGet_0();
bevt_5_ta_ph = beva_b.bem_sizeGet_0();
bevl_sz = (BEC_2_4_3_MathInt) bevt_3_ta_ph.bem_min_2(bevt_4_ta_ph, bevt_5_ta_ph);
bevl_ai = beva_a.bem_biterGet_0();
bevl_bi = beva_b.bem_biterGet_0();
bevl_av = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_bv = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1299*/ {
if (bevl_i.bevi_int < bevl_sz.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1299*/ {
bevl_ai.bemd_1(375857535, bevl_av);
bevl_bi.bemd_1(375857535, bevl_bv);
bevt_7_ta_ph = bevl_av.bem_notEquals_1(bevl_bv);
if (bevt_7_ta_ph.bevi_bool)/* Line: 1302*/ {
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = beva_a.bem_substring_2(bevt_9_ta_ph, bevl_i);
return bevt_8_ta_ph;
} /* Line: 1303*/
bevl_i.bevi_int++;
} /* Line: 1299*/
 else /* Line: 1299*/ {
break;
} /* Line: 1299*/
} /* Line: 1299*/
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_10_ta_ph = beva_a.bem_substring_2(bevt_11_ta_ph, bevl_i);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_anyEmpty_1(BEC_2_6_6_SystemObject beva_strs) {
BEC_2_4_6_TextString bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevt_0_ta_loop = beva_strs.bemd_0(-1653939165);
while (true)
/* Line: 1310*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(-211510432);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 1310*/ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(581391667);
bevt_2_ta_ph = bem_isEmpty_1(bevl_i);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1311*/ {
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1312*/
} /* Line: 1311*/
 else /* Line: 1310*/ {
break;
} /* Line: 1310*/
} /* Line: 1310*/
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1319*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1319*/ {
bevt_3_ta_ph = beva_value.bem_sizeGet_0();
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1319*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1319*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1319*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1319*/ {
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_5_ta_ph;
} /* Line: 1320*/
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEmpty_1(BEC_2_4_6_TextString beva_value) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_value == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1326*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_4_7_TextStrings_bels_4));
bevt_2_ta_ph = beva_value.bem_notEquals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 1326*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1326*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1326*/
 else /* Line: 1326*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1326*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 1327*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGet_0() {
return bevp_zero;
} /*method end*/
public BEC_2_4_3_MathInt bem_zeroGetDirect_0() {
return bevp_zero;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_zeroSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_zero = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGet_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_6_TextString bem_spaceGetDirect_0() {
return bevp_space;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_spaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_space = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGet_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_6_TextString bem_emptyGetDirect_0() {
return bevp_empty;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_emptySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_empty = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGet_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_6_TextString bem_quoteGetDirect_0() {
return bevp_quote;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_quoteSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_quote = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGet_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_6_TextString bem_tabGetDirect_0() {
return bevp_tab;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_tabSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_tab = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGet_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_dosNewlineGetDirect_0() {
return bevp_dosNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_dosNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_dosNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGet_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_6_TextString bem_unixNewlineGetDirect_0() {
return bevp_unixNewline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_unixNewlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_unixNewline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_crGet_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_6_TextString bem_crGetDirect_0() {
return bevp_cr;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_crSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_cr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGet_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_6_TextString bem_lfGetDirect_0() {
return bevp_lf;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_lfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lf = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGet_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_6_TextString bem_colonGetDirect_0() {
return bevp_colon;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_colonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_colon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGet_0() {
return bevp_ws;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_wsGetDirect_0() {
return bevp_ws;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_7_TextStrings bem_wsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ws = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1228, 1229, 1230, 1231, 1231, 1232, 1232, 1233, 1234, 1236, 1236, 1237, 1238, 1239, 1242, 1243, 1244, 1245, 1249, 1249, 1253, 1254, 1254, 1255, 1255, 1257, 1258, 1258, 1259, 1260, 1261, 1261, 1263, 1267, 1268, 1269, 1270, 1271, 1272, 1273, 1275, 1277, 1280, 1280, 1281, 1285, 1285, 1285, 1287, 1289, 1293, 1293, 0, 1293, 1293, 0, 0, 1293, 1294, 1294, 1294, 1294, 1295, 1296, 1297, 1298, 1299, 1299, 1299, 1300, 1301, 1302, 1303, 1303, 1303, 1299, 1306, 1306, 1306, 1310, 0, 1310, 1310, 1311, 1312, 1312, 1315, 1315, 1319, 1319, 0, 1319, 1319, 1319, 1319, 0, 0, 1320, 1320, 1322, 1322, 1326, 1326, 1326, 1326, 0, 0, 0, 1327, 1327, 1329, 1329, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 61, 62, 73, 74, 75, 77, 78, 80, 81, 82, 85, 87, 88, 89, 95, 109, 110, 111, 112, 115, 117, 118, 121, 124, 128, 129, 130, 138, 139, 140, 143, 145, 166, 171, 172, 175, 180, 181, 184, 188, 190, 191, 192, 193, 194, 195, 196, 197, 198, 201, 206, 207, 208, 209, 211, 212, 213, 215, 221, 222, 223, 232, 232, 235, 237, 238, 240, 241, 248, 249, 259, 264, 265, 268, 269, 270, 275, 276, 279, 283, 284, 286, 287, 296, 301, 302, 303, 305, 308, 312, 315, 316, 318, 319, 322, 325, 328, 332, 336, 339, 342, 346, 350, 353, 356, 360, 364, 367, 370, 374, 378, 381, 384, 388, 392, 395, 398, 402, 406, 409, 412, 416, 420, 423, 426, 430, 434, 437, 440, 444, 448, 451, 454, 458, 462, 465, 468, 472, 476, 479, 482, 486};
/* BEGIN LINEINFO 
assign 1 1228 39
new 0 1228 39
assign 1 1229 40
new 0 1229 40
assign 1 1230 41
new 0 1230 41
assign 1 1231 42
new 0 1231 42
assign 1 1231 43
codeNew 1 1231 43
assign 1 1232 44
new 0 1232 44
assign 1 1232 45
codeNew 1 1232 45
assign 1 1233 46
new 0 1233 46
assign 1 1234 47
new 0 1234 47
assign 1 1236 48
new 0 1236 48
assign 1 1236 49
codeNew 1 1236 49
assign 1 1237 50
new 0 1237 50
assign 1 1238 51
new 0 1238 51
assign 1 1239 52
new 0 1239 52
put 1 1242 53
put 1 1243 54
put 1 1244 55
put 1 1245 56
assign 1 1249 61
joinBuffer 2 1249 61
return 1 1249 62
assign 1 1253 73
iteratorGet 0 1253 73
assign 1 1254 74
hasNextGet 0 1254 74
assign 1 1254 75
not 0 1254 75
assign 1 1255 77
new 0 1255 77
return 1 1255 78
assign 1 1257 80
new 0 1257 80
assign 1 1258 81
nextGet 0 1258 81
addValue 1 1258 82
assign 1 1259 85
hasNextGet 0 1259 85
addValue 1 1260 87
assign 1 1261 88
nextGet 0 1261 88
addValue 1 1261 89
return 1 1263 95
assign 1 1267 109
new 0 1267 109
assign 1 1268 110
new 0 1268 110
assign 1 1269 111
new 0 1269 111
assign 1 1270 112
mbiterGet 0 1270 112
assign 1 1271 115
hasNextGet 0 1271 115
assign 1 1272 117
nextGet 0 1272 117
assign 1 1273 118
has 1 1273 118
incrementValue 0 1275 121
incrementValue 0 1277 124
assign 1 1280 128
new 0 1280 128
setValue 1 1280 129
assign 1 1281 130
new 0 1281 130
assign 1 1285 138
sizeGet 0 1285 138
assign 1 1285 139
subtract 1 1285 139
assign 1 1285 140
substring 2 1285 140
assign 1 1287 143
new 0 1287 143
return 1 1289 145
assign 1 1293 166
undef 1 1293 171
assign 1 0 172
assign 1 1293 175
undef 1 1293 180
assign 1 0 181
assign 1 0 184
return 1 1293 188
assign 1 1294 190
new 0 1294 190
assign 1 1294 191
sizeGet 0 1294 191
assign 1 1294 192
sizeGet 0 1294 192
assign 1 1294 193
min 2 1294 193
assign 1 1295 194
biterGet 0 1295 194
assign 1 1296 195
biterGet 0 1296 195
assign 1 1297 196
new 0 1297 196
assign 1 1298 197
new 0 1298 197
assign 1 1299 198
new 0 1299 198
assign 1 1299 201
lesser 1 1299 206
next 1 1300 207
next 1 1301 208
assign 1 1302 209
notEquals 1 1302 209
assign 1 1303 211
new 0 1303 211
assign 1 1303 212
substring 2 1303 212
return 1 1303 213
incrementValue 0 1299 215
assign 1 1306 221
new 0 1306 221
assign 1 1306 222
substring 2 1306 222
return 1 1306 223
assign 1 1310 232
iteratorGet 0 0 232
assign 1 1310 235
hasNextGet 0 1310 235
assign 1 1310 237
nextGet 0 1310 237
assign 1 1311 238
isEmpty 1 1311 238
assign 1 1312 240
new 0 1312 240
return 1 1312 241
assign 1 1315 248
new 0 1315 248
return 1 1315 249
assign 1 1319 259
undef 1 1319 264
assign 1 0 265
assign 1 1319 268
sizeGet 0 1319 268
assign 1 1319 269
new 0 1319 269
assign 1 1319 270
lesser 1 1319 275
assign 1 0 276
assign 1 0 279
assign 1 1320 283
new 0 1320 283
return 1 1320 284
assign 1 1322 286
new 0 1322 286
return 1 1322 287
assign 1 1326 296
def 1 1326 301
assign 1 1326 302
new 0 1326 302
assign 1 1326 303
notEquals 1 1326 303
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 1327 315
new 0 1327 315
return 1 1327 316
assign 1 1329 318
new 0 1329 318
return 1 1329 319
return 1 0 322
return 1 0 325
assign 1 0 328
assign 1 0 332
return 1 0 336
return 1 0 339
assign 1 0 342
assign 1 0 346
return 1 0 350
return 1 0 353
assign 1 0 356
assign 1 0 360
return 1 0 364
return 1 0 367
assign 1 0 370
assign 1 0 374
return 1 0 378
return 1 0 381
assign 1 0 384
assign 1 0 388
return 1 0 392
return 1 0 395
assign 1 0 398
assign 1 0 402
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
return 1 0 434
return 1 0 437
assign 1 0 440
assign 1 0 444
return 1 0 448
return 1 0 451
assign 1 0 454
assign 1 0 458
return 1 0 462
return 1 0 465
assign 1 0 468
assign 1 0 472
return 1 0 476
return 1 0 479
assign 1 0 482
assign 1 0 486
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -323816947: return bem_emptyGet_0();
case 1383677426: return bem_lfGet_0();
case -1758074273: return bem_tabGet_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case -972486890: return bem_dosNewlineGet_0();
case 85831002: return bem_wsGet_0();
case -259229537: return bem_unixNewlineGetDirect_0();
case -1076915155: return bem_serializeToString_0();
case -829143300: return bem_newlineGetDirect_0();
case 1110136254: return bem_lfGetDirect_0();
case -629133561: return bem_zeroGetDirect_0();
case 1650889651: return bem_colonGet_0();
case 1834246217: return bem_classNameGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -487191921: return bem_default_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case 1322767282: return bem_quoteGet_0();
case 2138955793: return bem_zeroGet_0();
case 1287277111: return bem_crGetDirect_0();
case -1146572779: return bem_unixNewlineGet_0();
case 1586815430: return bem_fieldIteratorGet_0();
case -479088263: return bem_tabGetDirect_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case 2081363871: return bem_copy_0();
case -1149850336: return bem_spaceGet_0();
case 1658333351: return bem_colonGetDirect_0();
case -975498393: return bem_fieldNamesGet_0();
case 954703233: return bem_create_0();
case -893093197: return bem_toString_0();
case -1021212966: return bem_spaceGetDirect_0();
case -701464464: return bem_dosNewlineGetDirect_0();
case -1487048190: return bem_crGet_0();
case -835298004: return bem_emptyGetDirect_0();
case 1063657341: return bem_quoteGetDirect_0();
case -40905183: return bem_echo_0();
case 234082358: return bem_newlineGet_0();
case -1653939165: return bem_iteratorGet_0();
case -836455050: return bem_wsGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 906682978: return bem_sameClass_1(bevd_0);
case -814320131: return bem_spaceSet_1(bevd_0);
case 1166179849: return bem_colonSet_1(bevd_0);
case -304275117: return bem_notEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 1862516154: return bem_newlineSet_1(bevd_0);
case 1011236674: return bem_strip_1((BEC_2_4_6_TextString) bevd_0);
case -580901362: return bem_unixNewlineSet_1(bevd_0);
case 1584389711: return bem_quoteSetDirect_1(bevd_0);
case -931110519: return bem_zeroSetDirect_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -1716851440: return bem_dosNewlineSetDirect_1(bevd_0);
case 177761630: return bem_crSet_1(bevd_0);
case -2117331328: return bem_wsSetDirect_1(bevd_0);
case 1020005908: return bem_lfSetDirect_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 55505724: return bem_unixNewlineSetDirect_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1166680132: return bem_lfSet_1(bevd_0);
case -93717728: return bem_colonSetDirect_1(bevd_0);
case -163751740: return bem_dosNewlineSet_1(bevd_0);
case -1268772476: return bem_tabSet_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 139260682: return bem_tabSetDirect_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -348843535: return bem_emptySetDirect_1(bevd_0);
case -969599661: return bem_spaceSetDirect_1(bevd_0);
case -2072267265: return bem_emptySet_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -155016576: return bem_zeroSet_1(bevd_0);
case 931950033: return bem_newlineSetDirect_1(bevd_0);
case -2045626402: return bem_anyEmpty_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -35270370: return bem_crSetDirect_1(bevd_0);
case -364508209: return bem_isEmpty_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -710762770: return bem_wsSet_1(bevd_0);
case 364000554: return bem_quoteSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 158196760: return bem_commonPrefix_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 218230059: return bem_join_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 1255151803: return bem_joinBuffer_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TextStrings_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_7_TextStrings_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TextStrings();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst = (BEC_2_4_7_TextStrings) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_type;
}
}
}
