namespace be {
public class BET_2_6_10_SystemSerializer : BETS_Object {
public BET_2_6_10_SystemSerializer() {
string[] bevs_mtnames = new string[] { "new_0", "undefined_1", "defined_1", "undef_1", "def_1", "toAny_0", "methodNotDefined_2", "forwardCall_2", "createInstance_1", "createInstance_2", "fieldNamesGet_0", "invoke_2", "can_2", "classNameGet_0", "sourceFileNameGet_0", "equals_1", "sameObject_1", "tagGet_0", "hashGet_0", "notEquals_1", "toString_0", "print_0", "echo_0", "copy_0", "copyTo_1", "deserializeClassNameGet_0", "deserializeFromString_1", "serializeToString_0", "deserializeFromStringNew_1", "serializationIteratorGet_0", "iteratorGet_0", "fieldIteratorGet_0", "serializeContents_0", "create_0", "sameClass_1", "otherClass_1", "sameType_1", "otherType_1", "getMethod_1", "getMethod_2", "getInvocation_2", "once_0", "many_0", "new_10", "serialize_1", "serialize_2", "serializeI_2", "serializeC_2", "defineInstance_2", "deserialize_1", "groupGet_0", "groupGetDirect_0", "groupSet_1", "groupSetDirect_1", "defineReferenceGet_0", "defineReferenceGetDirect_0", "defineReferenceSet_1", "defineReferenceSetDirect_1", "getReferenceGet_0", "getReferenceGetDirect_0", "getReferenceSet_1", "getReferenceSetDirect_1", "constructStringGet_0", "constructStringGetDirect_0", "constructStringSet_1", "constructStringSetDirect_1", "nullMarkGet_0", "nullMarkGetDirect_0", "nullMarkSet_1", "nullMarkSetDirect_1", "getClassTagGet_0", "getClassTagGetDirect_0", "getClassTagSet_1", "getClassTagSetDirect_1", "shiftGet_0", "shiftGetDirect_0", "shiftSet_1", "shiftSetDirect_1", "defineClassTagGet_0", "defineClassTagGetDirect_0", "defineClassTagSet_1", "defineClassTagSetDirect_1", "multiNullMarkGet_0", "multiNullMarkGetDirect_0", "multiNullMarkSet_1", "multiNullMarkSetDirect_1", "endGroupGet_0", "endGroupGetDirect_0", "endGroupSet_1", "endGroupSetDirect_1", "tokerGet_0", "tokerGetDirect_0", "tokerSet_1", "tokerSetDirect_1", "encoderGet_0", "encoderGetDirect_0", "encoderSet_1", "encoderSetDirect_1", "saveIdentityGet_0", "saveIdentityGetDirect_0", "saveIdentitySet_1", "saveIdentitySetDirect_1" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new string[] { "group", "defineReference", "getReference", "constructString", "nullMark", "getClassTag", "shift", "defineClassTag", "multiNullMark", "endGroup", "toker", "encoder", "saveIdentity" };
}
static BET_2_6_10_SystemSerializer() { }
public override BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_6_10_SystemSerializer();
}
}
}
