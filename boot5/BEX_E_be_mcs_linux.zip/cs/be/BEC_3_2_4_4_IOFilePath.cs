namespace be {
/* IO:File: source/extended/FilePath.be */
public class BEC_3_2_4_4_IOFilePath : BEC_2_6_8_SystemBasePath {
public BEC_3_2_4_4_IOFilePath() { }
static BEC_3_2_4_4_IOFilePath() { }
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_3_2_4_4_IOFilePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x50,0x61,0x74,0x68,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_4_IOFilePath_bels_0 = {0x3A};
public static new BEC_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_inst;

public static new BET_3_2_4_4_IOFilePath bece_BEC_3_2_4_4_IOFilePath_bevs_type;

public BEC_2_2_4_IOFile bevp_file;
public BEC_2_4_6_TextString bevp_driveLetter;
public override BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_6_15_SystemCurrentPlatform bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevp_separator = bevt_0_ta_ph.bem_separatorGet_0();
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_apNew_1(BEC_2_4_6_TextString beva_spath) {
BEC_2_6_8_SystemPlatform bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_15_ta_ph = null;
bevt_2_ta_ph = beva_spath.bem_sizeGet_0();
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 24*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_5_ta_ph = beva_spath.bem_getPoint_1(bevt_6_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_2_4_4_IOFilePath_bels_0));
bevt_4_ta_ph = bevt_5_ta_ph.bem_equals_1(bevt_7_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 24*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 24*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 24*/
 else /* Line: 24*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 24*/ {
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_driveLetter = beva_spath.bem_substring_2(bevt_8_ta_ph, bevt_9_ta_ph);
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_11_ta_ph = beva_spath.bem_sizeGet_0();
beva_spath = beva_spath.bem_substring_2(bevt_10_ta_ph, bevt_11_ta_ph);
} /* Line: 26*/
bevt_12_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl_p = bevt_12_ta_ph.bem_platformGet_0();
bevt_13_ta_ph = bevl_p.bem_otherSeparatorGet_0();
bevt_14_ta_ph = bevl_p.bem_separatorGet_0();
beva_spath = (BEC_2_4_6_TextString) beva_spath.bem_swap_2(bevt_13_ta_ph, bevt_14_ta_ph);
bevt_15_ta_ph = (BEC_3_2_4_4_IOFilePath) bem_new_1(beva_spath);
return (BEC_3_2_4_4_IOFilePath) bevt_15_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = base.bem_isAbsoluteGet_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_apNew_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_2_4_IOFile bem_fileGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_file == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 55*/ {
bevp_file = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_0();
bevp_file.bem_pathSet_1(this);
} /* Line: 57*/
return bevp_file;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_3_2_4_4_IOFilePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_other = (BEC_3_2_4_4_IOFilePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_ta_ph);
bevl_other.bem_fileSet_1(null);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_driveLetter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 71*/ {
bevt_1_ta_ph = bevp_driveLetter.bem_add_1(bevp_path);
return bevt_1_ta_ph;
} /* Line: 72*/
return bevp_path;
} /*method end*/
public override BEC_2_6_8_SystemBasePath bem_parentGet_0() {
BEC_2_6_8_SystemBasePath bevt_0_ta_ph = null;
bevt_0_ta_ph = base.bem_parentGet_0();
return (BEC_2_6_8_SystemBasePath) bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_isAbsoluteGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 82*/ {
bevp_driveLetter = null;
base.bem_makeNonAbsolute_0();
} /* Line: 84*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_matchesGlob_1(BEC_2_4_6_TextString beva_glob) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_4_TextGlob bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_4_TextGlob) (new BEC_2_4_4_TextGlob()).bem_new_1(beva_glob);
bevt_2_ta_ph = bem_toString_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_match_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_6_6_SystemObject bevl_res = null;
bevl_res = base.bem_subPath_2(beva_start, beva_end);
bevl_res.bemd_1(663194088, bevp_driveLetter);
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_lastStepGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_2_4_IOFile bem_fileGetDirect_0() {
return bevp_file;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_fileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_file = (BEC_2_2_4_IOFile) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_driveLetterGet_0() {
return bevp_driveLetter;
} /*method end*/
public BEC_2_4_6_TextString bem_driveLetterGetDirect_0() {
return bevp_driveLetter;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_driveLetterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_driveLetterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_driveLetter = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 18, 19, 24, 24, 24, 24, 24, 24, 24, 24, 0, 0, 0, 25, 25, 25, 26, 26, 26, 28, 28, 29, 29, 29, 30, 30, 37, 37, 41, 41, 45, 49, 49, 55, 55, 56, 57, 59, 63, 64, 65, 65, 66, 67, 71, 71, 72, 72, 74, 78, 78, 82, 83, 84, 89, 89, 89, 89, 93, 94, 95, 99, 99, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 40, 41, 42, 47, 48, 49, 50, 51, 53, 56, 60, 63, 64, 65, 66, 67, 68, 70, 71, 72, 73, 74, 75, 76, 80, 81, 85, 86, 89, 94, 95, 99, 104, 105, 106, 108, 113, 114, 115, 116, 117, 118, 123, 128, 129, 130, 132, 136, 137, 141, 143, 144, 152, 153, 154, 155, 159, 160, 161, 165, 166, 169, 172, 176, 180, 183, 186, 190};
/* BEGIN LINEINFO 
assign 1 18 17
new 0 18 17
assign 1 18 18
separatorGet 0 18 18
fromString 1 19 19
assign 1 24 40
sizeGet 0 24 40
assign 1 24 41
new 0 24 41
assign 1 24 42
greater 1 24 47
assign 1 24 48
new 0 24 48
assign 1 24 49
getPoint 1 24 49
assign 1 24 50
new 0 24 50
assign 1 24 51
equals 1 24 51
assign 1 0 53
assign 1 0 56
assign 1 0 60
assign 1 25 63
new 0 25 63
assign 1 25 64
new 0 25 64
assign 1 25 65
substring 2 25 65
assign 1 26 66
new 0 26 66
assign 1 26 67
sizeGet 0 26 67
assign 1 26 68
substring 2 26 68
assign 1 28 70
new 0 28 70
assign 1 28 71
platformGet 0 28 71
assign 1 29 72
otherSeparatorGet 0 29 72
assign 1 29 73
separatorGet 0 29 73
assign 1 29 74
swap 2 29 74
assign 1 30 75
new 1 30 75
return 1 30 76
assign 1 37 80
isAbsoluteGet 0 37 80
return 1 37 81
assign 1 41 85
toString 0 41 85
return 1 41 86
apNew 1 45 89
assign 1 49 94
new 0 49 94
return 1 49 95
assign 1 55 99
undef 1 55 104
assign 1 56 105
new 0 56 105
pathSet 1 57 106
return 1 59 108
assign 1 63 113
create 0 63 113
copyTo 1 64 114
assign 1 65 115
copy 0 65 115
pathSet 1 65 116
fileSet 1 66 117
return 1 67 118
assign 1 71 123
def 1 71 128
assign 1 72 129
add 1 72 129
return 1 72 130
return 1 74 132
assign 1 78 136
parentGet 0 78 136
return 1 78 137
assign 1 82 141
isAbsoluteGet 0 82 141
assign 1 83 143
makeNonAbsolute 0 84 144
assign 1 89 152
new 1 89 152
assign 1 89 153
toString 0 89 153
assign 1 89 154
match 1 89 154
return 1 89 155
assign 1 93 159
subPath 2 93 159
driveLetterSet 1 94 160
return 1 95 161
assign 1 99 165
lastStepGet 0 99 165
return 1 99 166
return 1 0 169
assign 1 0 172
assign 1 0 176
return 1 0 180
return 1 0 183
assign 1 0 186
assign 1 0 190
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 242392133: return bem_makeAbsolute_0();
case 1931705863: return bem_sourceFileNameGet_0();
case 119343176: return bem_stepsGet_0();
case 162075081: return bem_makeNonAbsolute_0();
case 336108203: return bem_lastStepGet_0();
case -893093197: return bem_toString_0();
case -226993264: return bem_driveLetterGet_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case -220942490: return bem_fileGetDirect_0();
case 1153595261: return bem_separatorGetDirect_0();
case -151747519: return bem_pathGet_0();
case -2143569824: return bem_driveLetterGetDirect_0();
case 954703233: return bem_create_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1834246217: return bem_classNameGet_0();
case 271468176: return bem_separatorGet_0();
case 1695610993: return bem_isAbsoluteGet_0();
case -193582610: return bem_tagGet_0();
case 1728703826: return bem_deleteFirstStep_0();
case -876745880: return bem_stepListGet_0();
case -975498393: return bem_fieldNamesGet_0();
case 155723965: return bem_pathGetDirect_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case -2110599528: return bem_parentGet_0();
case 357438225: return bem_firstStepGet_0();
case 2104038037: return bem_fileGet_0();
case 1437514936: return bem_nameGet_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -260432710: return bem_sameObject_1(bevd_0);
case 235403884: return bem_addStep_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 1196186031: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case 968225625: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case 59504167: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -128704815: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 1199958905: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case 663194088: return bem_driveLetterSet_1(bevd_0);
case -701965760: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 147091306: return bem_apNew_1((BEC_2_4_6_TextString) bevd_0);
case 140461508: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1421462792: return bem_pathSetDirect_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -1170645036: return bem_fileSetDirect_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -1528801751: return bem_driveLetterSetDirect_1(bevd_0);
case -1816713243: return bem_matchesGlob_1((BEC_2_4_6_TextString) bevd_0);
case 1188845634: return bem_fileSet_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 1098483927: return bem_separatorSetDirect_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1007780901: return bem_add_1(bevd_0);
case -74273945: return bem_pathSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -981386057: return bem_addSteps_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 584496470: return bem_separatorSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2072938511: return bem_addSteps_2(bevd_0, bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1227095263: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_3_2_4_4_IOFilePath_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_3_2_4_4_IOFilePath_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_4_IOFilePath();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst = (BEC_3_2_4_4_IOFilePath) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_4_IOFilePath.bece_BEC_3_2_4_4_IOFilePath_bevs_type;
}
}
}
