namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_3_2_4_12_IOFileNamedWriters : BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedWriters() { }
static BEC_3_2_4_12_IOFileNamedWriters() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x57,0x72,0x69,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_3_2_4_12_IOFileNamedWriters bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;
public BEC_3_2_4_6_IOFileWriter bevp_output;
public BEC_3_2_4_6_IOFileWriter bevp_error;
public BEC_3_2_4_6_IOFileWriter bevp_exceptionConsole;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_default_0() {
BEC_4_2_4_6_6_IOFileWriterStdout bevt_0_tmpany_phold = null;
BEC_4_2_4_6_6_IOFileWriterStderr bevt_1_tmpany_phold = null;
BEC_4_2_4_6_8_IOFileWriterNoOutput bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_4_2_4_6_6_IOFileWriterStdout) BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst.bem_new_0();
bem_outputSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_4_2_4_6_6_IOFileWriterStderr) BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst.bem_new_0();
bem_errorSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_4_2_4_6_8_IOFileWriterNoOutput) BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst.bem_new_0();
bem_exceptionConsoleSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_outputSet_1(BEC_3_2_4_6_IOFileWriter beva__output) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_output = beva__output;
bevt_0_tmpany_phold = bevp_output.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 576 */ {
bevp_output.bem_open_0();
} /* Line: 577 */
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_errorSet_1(BEC_3_2_4_6_IOFileWriter beva__error) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_error = beva__error;
bevt_0_tmpany_phold = bevp_error.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 583 */ {
bevp_error.bem_open_0();
} /* Line: 584 */
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_exceptionConsoleSet_1(BEC_3_2_4_6_IOFileWriter beva__exceptionConsole) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_exceptionConsole = beva__exceptionConsole;
bevt_0_tmpany_phold = bevp_exceptionConsole.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 590 */ {
bevp_exceptionConsole.bem_open_0();
} /* Line: 591 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_outputGet_0() {
return bevp_output;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_errorGet_0() {
return bevp_error;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_exceptionConsoleGet_0() {
return bevp_exceptionConsole;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {569, 569, 570, 570, 571, 571, 575, 576, 577, 582, 583, 584, 589, 590, 591, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 26, 27, 32, 33, 35, 41, 42, 44, 50, 51, 53, 58, 61, 64};
/* BEGIN LINEINFO 
assign 1 569 22
new 0 569 22
outputSet 1 569 23
assign 1 570 24
new 0 570 24
errorSet 1 570 25
assign 1 571 26
new 0 571 26
exceptionConsoleSet 1 571 27
assign 1 575 32
assign 1 576 33
isClosedGet 0 576 33
open 0 577 35
assign 1 582 41
assign 1 583 42
isClosedGet 0 583 42
open 0 584 44
assign 1 589 50
assign 1 590 51
isClosedGet 0 590 51
open 0 591 53
return 1 0 58
return 1 0 61
return 1 0 64
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 460304834: return bem_fieldIteratorGet_0();
case 607966049: return bem_serializationIteratorGet_0();
case -1533121038: return bem_new_0();
case -853598946: return bem_serializeContents_0();
case -1233972717: return bem_create_0();
case -1569136637: return bem_default_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 1307328857: return bem_toAny_0();
case -827921680: return bem_copy_0();
case 1165489654: return bem_sourceFileNameGet_0();
case -2146069227: return bem_errorGet_0();
case 1503053792: return bem_exceptionConsoleGet_0();
case 466290922: return bem_iteratorGet_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -590451146: return bem_serializeToString_0();
case -1802544452: return bem_many_0();
case 247385301: return bem_toString_0();
case 210264567: return bem_print_0();
case -1687211887: return bem_outputGet_0();
case 2043795865: return bem_echo_0();
case 212191548: return bem_tagGet_0();
case -315420442: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case -510482336: return bem_outputSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1377833517: return bem_exceptionConsoleSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case -541008114: return bem_errorSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 172009000: return bem_otherType_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedWriters_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedWriters_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_12_IOFileNamedWriters();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst = (BEC_3_2_4_12_IOFileNamedWriters) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;
}
}
}
