namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_3_2_4_12_IOFileNamedWriters : BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedWriters() { }
static BEC_3_2_4_12_IOFileNamedWriters() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x57,0x72,0x69,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedWriters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_3_2_4_12_IOFileNamedWriters bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;

public static new BET_3_2_4_12_IOFileNamedWriters bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_type;

public BEC_3_2_4_6_IOFileWriter bevp_output;
public BEC_3_2_4_6_IOFileWriter bevp_error;
public BEC_3_2_4_6_IOFileWriter bevp_exceptionConsole;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_default_0() {
BEC_4_2_4_6_6_IOFileWriterStdout bevt_0_tmpany_phold = null;
BEC_4_2_4_6_6_IOFileWriterStderr bevt_1_tmpany_phold = null;
BEC_4_2_4_6_8_IOFileWriterNoOutput bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_4_2_4_6_6_IOFileWriterStdout) BEC_4_2_4_6_6_IOFileWriterStdout.bece_BEC_4_2_4_6_6_IOFileWriterStdout_bevs_inst.bem_new_0();
bem_outputSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_4_2_4_6_6_IOFileWriterStderr) BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst.bem_new_0();
bem_errorSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_4_2_4_6_8_IOFileWriterNoOutput) BEC_4_2_4_6_8_IOFileWriterNoOutput.bece_BEC_4_2_4_6_8_IOFileWriterNoOutput_bevs_inst.bem_new_0();
bem_exceptionConsoleSet_1(bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_outputSet_1(BEC_3_2_4_6_IOFileWriter beva__output) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_output = beva__output;
bevt_0_tmpany_phold = bevp_output.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 576 */ {
bevp_output.bem_open_0();
} /* Line: 577 */
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_errorSet_1(BEC_3_2_4_6_IOFileWriter beva__error) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_error = beva__error;
bevt_0_tmpany_phold = bevp_error.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 583 */ {
bevp_error.bem_open_0();
} /* Line: 584 */
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_exceptionConsoleSet_1(BEC_3_2_4_6_IOFileWriter beva__exceptionConsole) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_exceptionConsole = beva__exceptionConsole;
bevt_0_tmpany_phold = bevp_exceptionConsole.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 590 */ {
bevp_exceptionConsole.bem_open_0();
} /* Line: 591 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_outputGet_0() {
return bevp_output;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_outputGetDirect_0() {
return bevp_output;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_outputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_output = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_errorGet_0() {
return bevp_error;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_errorGetDirect_0() {
return bevp_error;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_errorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_error = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_exceptionConsoleGet_0() {
return bevp_exceptionConsole;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_exceptionConsoleGetDirect_0() {
return bevp_exceptionConsole;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedWriters bem_exceptionConsoleSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exceptionConsole = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {569, 569, 570, 570, 571, 571, 575, 576, 577, 582, 583, 584, 589, 590, 591, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 28, 29, 30, 35, 36, 38, 44, 45, 47, 53, 54, 56, 61, 64, 67, 71, 74, 77, 81, 84, 87};
/* BEGIN LINEINFO 
assign 1 569 25
new 0 569 25
outputSet 1 569 26
assign 1 570 27
new 0 570 27
errorSet 1 570 28
assign 1 571 29
new 0 571 29
exceptionConsoleSet 1 571 30
assign 1 575 35
assign 1 576 36
isClosedGet 0 576 36
open 0 577 38
assign 1 582 44
assign 1 583 45
isClosedGet 0 583 45
open 0 584 47
assign 1 589 53
assign 1 590 54
isClosedGet 0 590 54
open 0 591 56
return 1 0 61
return 1 0 64
assign 1 0 67
return 1 0 71
return 1 0 74
assign 1 0 77
return 1 0 81
return 1 0 84
assign 1 0 87
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1897894802: return bem_exceptionConsoleGetDirect_0();
case 1291754014: return bem_fieldIteratorGet_0();
case 376318330: return bem_toAny_0();
case -188774864: return bem_fieldNamesGet_0();
case 1892440434: return bem_serializeToString_0();
case 2022591848: return bem_new_0();
case 123890466: return bem_tagGet_0();
case -1336547559: return bem_copy_0();
case -1914264312: return bem_serializationIteratorGet_0();
case 1924878947: return bem_serializeContents_0();
case -2097142996: return bem_many_0();
case -92876860: return bem_echo_0();
case -1673560399: return bem_toString_0();
case 1684359161: return bem_classNameGet_0();
case 1106096180: return bem_outputGetDirect_0();
case 313786352: return bem_exceptionConsoleGet_0();
case 782585161: return bem_deserializeClassNameGet_0();
case 1714059697: return bem_iteratorGet_0();
case -267342231: return bem_outputGet_0();
case 2032518799: return bem_default_0();
case 1726245742: return bem_hashGet_0();
case -172634187: return bem_once_0();
case -870016446: return bem_print_0();
case -997138031: return bem_create_0();
case 693975385: return bem_errorGetDirect_0();
case -1076599574: return bem_errorGet_0();
case -939140314: return bem_sourceFileNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1299087238: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -9743810: return bem_sameObject_1(bevd_0);
case -490404: return bem_exceptionConsoleSetDirect_1(bevd_0);
case -1139805373: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1783619507: return bem_sameClass_1(bevd_0);
case -148425027: return bem_otherType_1(bevd_0);
case 2108385190: return bem_undefined_1(bevd_0);
case 921396152: return bem_copyTo_1(bevd_0);
case -502649276: return bem_notEquals_1(bevd_0);
case 1802133619: return bem_undef_1(bevd_0);
case -1259222473: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1560831110: return bem_equals_1(bevd_0);
case -1860558101: return bem_sameType_1(bevd_0);
case -1994787564: return bem_def_1(bevd_0);
case -628251942: return bem_defined_1(bevd_0);
case 352888535: return bem_errorSetDirect_1(bevd_0);
case 1782015704: return bem_errorSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 551602517: return bem_exceptionConsoleSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -2040414469: return bem_outputSetDirect_1(bevd_0);
case 2024151813: return bem_otherClass_1(bevd_0);
case -1554389120: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1619319667: return bem_outputSet_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -402932836: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1915330817: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -518118155: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -355453886: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1141599202: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1078652527: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1443758120: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedWriters_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedWriters_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_12_IOFileNamedWriters();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst = (BEC_3_2_4_12_IOFileNamedWriters) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_12_IOFileNamedWriters.bece_BEC_3_2_4_12_IOFileNamedWriters_bevs_type;
}
}
}
