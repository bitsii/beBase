namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_2_2_6_IOReader : BEC_2_6_6_SystemObject {
public BEC_2_2_6_IOReader() { }
static BEC_2_2_6_IOReader() { }

    public System.IO.Stream bevi_is;
    
   private static byte[] becc_BEC_2_2_6_IOReader_clname = {0x49,0x4F,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_2_2_6_IOReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_2 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_3 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_5 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_2_6_IOReader_bevo_8 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_2_6_IOReader bece_BEC_2_2_6_IOReader_bevs_inst;

public static new BET_2_2_6_IOReader bece_BEC_2_2_6_IOReader_bevs_type;

public BEC_2_6_6_SystemObject bevp_vfile;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_3_MathInt bevp_blockSize;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_blockSize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(256));
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_extOpen_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_close_0() {

      if (this.bevi_is != null) {
        this.bevi_is.Dispose();
        this.bevi_is = null;
      }
      bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_vfileGet_0() {
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_vfileSet_1(BEC_2_6_6_SystemObject beva_vfile) {
return this;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_byteReaderGet_0() {
BEC_2_2_10_IOByteReader bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_2_10_IOByteReader) (new BEC_2_2_10_IOByteReader()).bem_readerNew_1(this);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_2_10_IOByteReader bem_byteReader_1(BEC_2_4_3_MathInt beva_blockSize) {
BEC_2_2_10_IOByteReader bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_2_10_IOByteReader) (new BEC_2_2_10_IOByteReader()).bem_readerBlockNew_2(this, beva_blockSize);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_readIntoBuffer_1(BEC_2_4_6_TextString beva_readBuf) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_2_6_IOReader_bevo_0;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) bevt_2_ta_ph.bem_once_0();
bevt_0_ta_ph = bem_readIntoBuffer_2(beva_readBuf, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_readIntoBuffer_2(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_readIntoBuffer_3(beva_readBuf, beva_at, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_readIntoBuffer_3(BEC_2_4_6_TextString beva_readBuf, BEC_2_4_3_MathInt beva_at, BEC_2_4_3_MathInt beva_readsz) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;

      beva_readsz.bevi_int = this.bevi_is.Read(beva_readBuf.bevi_bytes, beva_at.bevi_int, beva_readBuf.bevi_bytes.Length - beva_at.bevi_int) + beva_at.bevi_int;
      bevt_0_ta_ph = beva_readBuf.bem_sizeGet_0();
bevt_0_ta_ph.bevi_int = beva_readsz.bevi_int;
return beva_readsz;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_copyData_3(BEC_2_2_6_IOWriter beva_outw, BEC_2_4_6_TextString beva_rwbufE, BEC_2_4_3_MathInt beva_rsz) {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_at = bece_BEC_2_2_6_IOReader_bevo_1;
while (true)
/* Line: 292*/ {
bevt_1_ta_ph = bem_readIntoBuffer_3(beva_rwbufE, bevl_at, beva_rsz);
bevt_2_ta_ph = bece_BEC_2_2_6_IOReader_bevo_2;
if (bevt_1_ta_ph.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 292*/ {
beva_outw.bem_write_1(beva_rwbufE);
} /* Line: 293*/
 else /* Line: 292*/ {
break;
} /* Line: 292*/
} /* Line: 292*/
return this;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_copyData_1(BEC_2_2_6_IOWriter beva_outw) {
BEC_2_4_6_TextString bevl_rwbufE = null;
BEC_2_4_3_MathInt bevl_rsz = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevl_rwbufE = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_ta_ph);
bevl_rsz = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bem_copyData_3(beva_outw, bevl_rwbufE, bevl_rsz);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBuffer_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevp_blockSize);
bevt_0_ta_ph = bem_readBuffer_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBuffer_1(BEC_2_4_6_TextString beva_builder) {
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_4_3_MathInt bevl_nowAt = null;
BEC_2_4_3_MathInt bevl_nsize = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
bevl_at = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nowAt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
while (true)
/* Line: 311*/ {
if (bevl_nowAt.bevi_int > bevl_at.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 311*/ {
bevl_at.bevi_int = bevl_nowAt.bevi_int;
bevt_3_ta_ph = beva_builder.bem_capacityGet_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_subtract_1(bevl_at);
bevt_4_ta_ph = bece_BEC_2_2_6_IOReader_bevo_3;
if (bevt_2_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 313*/ {
bevt_7_ta_ph = bevl_at.bem_add_1(bevp_blockSize);
bevt_8_ta_ph = bece_BEC_2_2_6_IOReader_bevo_4;
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = bece_BEC_2_2_6_IOReader_bevo_5;
bevt_5_ta_ph = bevt_6_ta_ph.bem_multiply_1(bevt_9_ta_ph);
bevt_10_ta_ph = bece_BEC_2_2_6_IOReader_bevo_6;
bevl_nsize = bevt_5_ta_ph.bem_divide_1(bevt_10_ta_ph);
beva_builder.bem_capacitySet_1(bevl_nsize);
} /* Line: 315*/
bem_readIntoBuffer_3(beva_builder, bevl_at, bevl_nowAt);
} /* Line: 317*/
 else /* Line: 311*/ {
break;
} /* Line: 311*/
} /* Line: 311*/
return beva_builder;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_readDiscard_0() {
BEC_2_4_6_TextString bevl_builder = null;
BEC_2_4_3_MathInt bevl_at = null;
BEC_2_4_3_MathInt bevl_nowAt = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevl_builder = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevp_blockSize);
bevl_at = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nowAt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bem_readIntoBuffer_3(bevl_builder, bevl_at, bevl_nowAt);
while (true)
/* Line: 327*/ {
if (bevl_nowAt.bevi_int > bevl_at.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 327*/ {
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_nowAt.bevi_int = bevt_1_ta_ph.bevi_int;
bem_readIntoBuffer_3(bevl_builder, bevl_at, bevl_nowAt);
} /* Line: 329*/
 else /* Line: 327*/ {
break;
} /* Line: 327*/
} /* Line: 327*/
return bevl_builder;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBufferLine_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = bem_readBufferLine_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readBufferLine_1(BEC_2_4_6_TextString beva_builder) {
BEC_2_4_6_TextString bevl_crb = null;
BEC_2_4_6_TextString bevl_rbuf = null;
BEC_2_4_3_MathInt bevl_got = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_7_TextStrings bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_ta_ph = bevt_2_ta_ph.bem_newlineGet_0();
bevl_crb = (BEC_2_4_6_TextString) bevt_0_ta_ph.bem_addValue_1(bevt_1_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_rbuf = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_3_ta_ph);
bevl_got = bem_readIntoBuffer_1(bevl_rbuf);
bevt_5_ta_ph = bece_BEC_2_2_6_IOReader_bevo_7;
if (bevl_got.bevi_int == bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 345*/ {
beva_builder = null;
return beva_builder;
} /* Line: 347*/
beva_builder.bem_addValue_1(bevl_rbuf);
while (true)
/* Line: 350*/ {
bevt_7_ta_ph = bece_BEC_2_2_6_IOReader_bevo_8;
if (bevl_got.bevi_int != bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_8_ta_ph = bevl_rbuf.bem_equals_1(bevl_crb);
if (bevt_8_ta_ph.bevi_bool)/* Line: 351*/ {
return beva_builder;
} /* Line: 352*/
bevl_got = bem_readIntoBuffer_1(bevl_rbuf);
beva_builder.bem_addValue_1(bevl_rbuf);
} /* Line: 355*/
 else /* Line: 350*/ {
break;
} /* Line: 350*/
} /* Line: 350*/
return beva_builder;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_readBuffer_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readString_1(BEC_2_4_6_TextString beva_builder) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_readBuffer_1(beva_builder);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readStringClose_0() {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = bem_readString_0();
bem_close_0();
return bevl_res;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_readDiscardClose_0() {
BEC_2_4_6_TextString bevl_res = null;
bevl_res = (BEC_2_4_6_TextString) bem_readDiscard_0();
bem_close_0();
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_vfileGetDirect_0() {
return bevp_vfile;
} /*method end*/
public BEC_2_2_6_IOReader bem_vfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vfile = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isClosedGet_0() {
return bevp_isClosed;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGetDirect_0() {
return bevp_isClosed;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_isClosedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_blockSizeGet_0() {
return bevp_blockSize;
} /*method end*/
public BEC_2_4_3_MathInt bem_blockSizeGetDirect_0() {
return bevp_blockSize;
} /*method end*/
public virtual BEC_2_2_6_IOReader bem_blockSizeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_blockSize = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_6_IOReader bem_blockSizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_blockSize = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {173, 174, 180, 224, 232, 232, 236, 236, 240, 240, 240, 240, 244, 244, 244, 286, 286, 287, 291, 292, 292, 292, 292, 293, 298, 298, 299, 300, 304, 304, 304, 308, 309, 310, 311, 311, 312, 313, 313, 313, 313, 313, 314, 314, 314, 314, 314, 314, 314, 315, 317, 319, 323, 324, 325, 326, 327, 327, 328, 328, 329, 331, 335, 335, 335, 342, 342, 342, 342, 343, 343, 344, 345, 345, 345, 346, 347, 349, 350, 350, 350, 351, 352, 354, 355, 357, 361, 361, 365, 365, 369, 370, 371, 375, 376, 377, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {31, 32, 36, 45, 56, 57, 61, 62, 68, 69, 70, 71, 76, 77, 78, 84, 85, 86, 93, 96, 97, 98, 103, 104, 116, 117, 118, 119, 125, 126, 127, 144, 145, 146, 149, 154, 155, 156, 157, 158, 159, 164, 165, 166, 167, 168, 169, 170, 171, 172, 174, 180, 188, 189, 190, 191, 194, 199, 200, 201, 202, 208, 213, 214, 215, 230, 231, 232, 233, 234, 235, 236, 237, 238, 243, 244, 245, 247, 250, 251, 256, 257, 259, 261, 262, 268, 272, 273, 277, 278, 282, 283, 284, 288, 289, 290, 293, 296, 300, 303, 306, 310, 314, 317, 320, 324};
/* BEGIN LINEINFO 
assign 1 173 31
new 0 173 31
assign 1 174 32
new 0 174 32
assign 1 180 36
new 0 180 36
assign 1 224 45
new 0 224 45
assign 1 232 56
readerNew 1 232 56
return 1 232 57
assign 1 236 61
readerBlockNew 2 236 61
return 1 236 62
assign 1 240 68
new 0 240 68
assign 1 240 69
once 0 240 69
assign 1 240 70
readIntoBuffer 2 240 70
return 1 240 71
assign 1 244 76
new 0 244 76
assign 1 244 77
readIntoBuffer 3 244 77
return 1 244 78
assign 1 286 84
sizeGet 0 286 84
setValue 1 286 85
return 1 287 86
assign 1 291 93
new 0 291 93
assign 1 292 96
readIntoBuffer 3 292 96
assign 1 292 97
new 0 292 97
assign 1 292 98
greater 1 292 103
write 1 293 104
assign 1 298 116
new 0 298 116
assign 1 298 117
new 1 298 117
assign 1 299 118
new 0 299 118
copyData 3 300 119
assign 1 304 125
new 1 304 125
assign 1 304 126
readBuffer 1 304 126
return 1 304 127
assign 1 308 144
new 0 308 144
assign 1 309 145
new 0 309 145
readIntoBuffer 3 310 146
assign 1 311 149
greater 1 311 154
setValue 1 312 155
assign 1 313 156
capacityGet 0 313 156
assign 1 313 157
subtract 1 313 157
assign 1 313 158
new 0 313 158
assign 1 313 159
lesser 1 313 164
assign 1 314 165
add 1 314 165
assign 1 314 166
new 0 314 166
assign 1 314 167
add 1 314 167
assign 1 314 168
new 0 314 168
assign 1 314 169
multiply 1 314 169
assign 1 314 170
new 0 314 170
assign 1 314 171
divide 1 314 171
capacitySet 1 315 172
readIntoBuffer 3 317 174
return 1 319 180
assign 1 323 188
new 1 323 188
assign 1 324 189
new 0 324 189
assign 1 325 190
new 0 325 190
readIntoBuffer 3 326 191
assign 1 327 194
greater 1 327 199
assign 1 328 200
new 0 328 200
setValue 1 328 201
readIntoBuffer 3 329 202
return 1 331 208
assign 1 335 213
new 0 335 213
assign 1 335 214
readBufferLine 1 335 214
return 1 335 215
assign 1 342 230
new 0 342 230
assign 1 342 231
new 0 342 231
assign 1 342 232
newlineGet 0 342 232
assign 1 342 233
addValue 1 342 233
assign 1 343 234
new 0 343 234
assign 1 343 235
new 1 343 235
assign 1 344 236
readIntoBuffer 1 344 236
assign 1 345 237
new 0 345 237
assign 1 345 238
equals 1 345 243
assign 1 346 244
return 1 347 245
addValue 1 349 247
assign 1 350 250
new 0 350 250
assign 1 350 251
notEquals 1 350 256
assign 1 351 257
equals 1 351 257
return 1 352 259
assign 1 354 261
readIntoBuffer 1 354 261
addValue 1 355 262
return 1 357 268
assign 1 361 272
readBuffer 0 361 272
return 1 361 273
assign 1 365 277
readBuffer 1 365 277
return 1 365 278
assign 1 369 282
readString 0 369 282
close 0 370 283
return 1 371 284
assign 1 375 288
readDiscard 0 375 288
close 0 376 289
return 1 377 290
return 1 0 293
assign 1 0 296
return 1 0 300
return 1 0 303
assign 1 0 306
assign 1 0 310
return 1 0 314
return 1 0 317
assign 1 0 320
assign 1 0 324
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 119461913: return bem_tagGet_0();
case 1986846950: return bem_close_0();
case 281444821: return bem_fieldIteratorGet_0();
case -678541085: return bem_classNameGet_0();
case -24113205: return bem_readString_0();
case -806099499: return bem_isClosedGetDirect_0();
case -961837466: return bem_readBuffer_0();
case -1754478112: return bem_print_0();
case -1204597521: return bem_blockSizeGetDirect_0();
case -2017009146: return bem_new_0();
case -442003668: return bem_readBufferLine_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -1005119995: return bem_many_0();
case -1475550710: return bem_create_0();
case -225870373: return bem_serializeToString_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 2045941275: return bem_iteratorGet_0();
case -744679096: return bem_fieldNamesGet_0();
case -1486279572: return bem_serializeContents_0();
case 1214001816: return bem_readStringClose_0();
case -1275325619: return bem_toString_0();
case -1737496730: return bem_byteReaderGet_0();
case 526878761: return bem_readDiscardClose_0();
case 501088997: return bem_sourceFileNameGet_0();
case -194123929: return bem_vfileGetDirect_0();
case 2022064601: return bem_extOpen_0();
case 1575784889: return bem_vfileGet_0();
case -639297756: return bem_toAny_0();
case -545556484: return bem_once_0();
case 1166484122: return bem_isClosedGet_0();
case -991084437: return bem_readDiscard_0();
case 611702865: return bem_copy_0();
case -1583672278: return bem_echo_0();
case -50240246: return bem_blockSizeGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1161438565: return bem_blockSizeSet_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 1936041691: return bem_blockSizeSetDirect_1(bevd_0);
case -1625335738: return bem_isClosedSetDirect_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -677874151: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 1961622357: return bem_vfileSetDirect_1(bevd_0);
case -216684494: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1598599718: return bem_vfileSet_1(bevd_0);
case -1274030604: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case -1670055117: return bem_isClosedSet_1(bevd_0);
case -1158387778: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1856501662: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case -1673117857: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1967906273: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1197093835: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1656581670: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_2_6_IOReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_2_2_6_IOReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_6_IOReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst = (BEC_2_2_6_IOReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_6_IOReader.bece_BEC_2_2_6_IOReader_bevs_type;
}
}
}
