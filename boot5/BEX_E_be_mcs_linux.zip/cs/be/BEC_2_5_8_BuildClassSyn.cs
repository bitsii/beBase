namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_8_BuildClassSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_8_BuildClassSyn() { }
static BEC_2_5_8_BuildClassSyn() { }
private static byte[] becc_BEC_2_5_8_BuildClassSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_8_BuildClassSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x30};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_1 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_2 = {0x56,0x61,0x72,0x69,0x61,0x62,0x6C,0x65,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_3 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x72,0x20,0x73,0x75,0x70,0x65,0x72,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6F,0x66,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_4 = {0x50,0x61,0x72,0x65,0x6E,0x74,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x68,0x61,0x73,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x62,0x75,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x6F,0x74,0x20,0x73,0x70,0x65,0x63,0x69,0x66,0x69,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_5 = {0x20,0x66,0x6F,0x72,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_6 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_7 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x65,0x78,0x74,0x65,0x6E,0x64,0x20,0x61,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x66,0x72,0x6F,0x6D,0x20,0x6F,0x75,0x74,0x73,0x69,0x64,0x65,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x27,0x73,0x20,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20,0x69,0x6E,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_8 = {0x44,0x65,0x73,0x63,0x65,0x6E,0x64,0x65,0x6E,0x74,0x73,0x20,0x6F,0x66,0x20,0x63,0x6C,0x61,0x73,0x73,0x65,0x73,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x20,0x6D,0x75,0x73,0x74,0x20,0x61,0x6C,0x73,0x6F,0x20,0x62,0x65,0x20,0x6C,0x6F,0x63,0x61,0x6C,0x2C,0x20,0x74,0x68,0x69,0x73,0x20,0x6F,0x6E,0x65,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_9 = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_10 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x20,0x66,0x72,0x6F,0x6D,0x20,0x73,0x75,0x70,0x65,0x72,0x63,0x6C,0x61,0x73,0x73,0x20,0x72,0x65,0x2D,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x20,0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x3A};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_11 = {0x20,0x73,0x75,0x62,0x63,0x6C,0x61,0x73,0x73,0x3A,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_12 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20,0x66,0x69,0x6E,0x61,0x6C,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_13 = {0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_14 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_15 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x2C,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x74,0x79,0x70,0x65,0x20,0x69,0x73,0x20,0x22,0x74,0x68,0x69,0x73,0x22,0x20,0x62,0x75,0x74,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_16 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6F,0x6E,0x65,0x20,0x6F,0x66,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x6F,0x72,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x61,0x72,0x65,0x20,0x74,0x79,0x70,0x65,0x64,0x20,0x62,0x75,0x74,0x20,0x6E,0x6F,0x74,0x20,0x62,0x6F,0x74,0x68,0x21,0x21,0x21,0x21,0x21,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_17 = {0x49,0x6E,0x68,0x65,0x72,0x69,0x74,0x61,0x6E,0x63,0x65,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x69,0x73,0x6D,0x61,0x74,0x63,0x68,0x20,0x65,0x72,0x72,0x6F,0x72,0x2C,0x20,0x63,0x68,0x69,0x6C,0x64,0x20,0x74,0x79,0x70,0x65,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x6D,0x61,0x74,0x63,0x68,0x20,0x70,0x61,0x72,0x65,0x6E,0x74,0x20,0x74,0x79,0x70,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68,0x20};
private static byte[] bece_BEC_2_5_8_BuildClassSyn_bels_18 = {0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x65,0x64,0x20,0x69,0x6E,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
public static new BEC_2_5_8_BuildClassSyn bece_BEC_2_5_8_BuildClassSyn_bevs_inst;

public static new BET_2_5_8_BuildClassSyn bece_BEC_2_5_8_BuildClassSyn_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_superNp;
public BEC_2_4_3_MathInt bevp_depth;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_3_2_4_4_IOFilePath bevp_fromFile;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_5_4_LogicBool bevp_isLocal;
public BEC_2_5_4_LogicBool bevp_isNotNull;
public BEC_2_4_3_MathInt bevp_newMbrs;
public BEC_2_4_3_MathInt bevp_newMtds;
public BEC_2_4_3_MathInt bevp_defMtds;
public BEC_2_5_4_LogicBool bevp_directProperties;
public BEC_2_5_4_LogicBool bevp_directMethods;
public BEC_2_9_3_ContainerMap bevp_allTypes;
public BEC_2_9_10_ContainerLinkedList bevp_superList;
public BEC_2_9_3_ContainerMap bevp_mtdMap;
public BEC_2_9_4_ContainerList bevp_mtdList;
public BEC_2_9_3_ContainerMap bevp_ptyMap;
public BEC_2_9_4_ContainerList bevp_ptyList;
public BEC_2_9_3_ContainerMap bevp_allNames;
public BEC_2_9_3_ContainerMap bevp_foreignClasses;
public BEC_2_5_4_LogicBool bevp_allAncestorsClose;
public BEC_2_5_4_LogicBool bevp_integrated;
public BEC_2_5_4_LogicBool bevp_iChecked;
public BEC_2_9_3_ContainerSet bevp_uses;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_5_4_LogicBool bevp_signatureChanged;
public BEC_2_5_4_LogicBool bevp_signatureChecked;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_superList = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_isFinal = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxMtdxGet_0() {
BEC_2_4_3_MathInt bevl_maxMtdx = null;
BEC_3_9_3_13_ContainerMapValueIterator bevl_vi = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevl_maxMtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_vi = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
/* Line: 95*/ {
bevt_0_ta_ph = bevl_vi.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 95*/ {
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevl_vi.bem_nextGet_0();
bevt_2_ta_ph = bevl_ms.bem_mtdxGet_0();
if (bevt_2_ta_ph.bevi_int > bevl_maxMtdx.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 97*/ {
bevl_maxMtdx = bevl_ms.bem_mtdxGet_0();
} /* Line: 98*/
} /* Line: 97*/
 else /* Line: 95*/ {
break;
} /* Line: 95*/
} /* Line: 95*/
return bevl_maxMtdx;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasDefaultGet_0() {
BEC_2_6_6_SystemObject bevl_dmtd = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_8_BuildClassSyn_bels_0));
bevl_dmtd = bevp_mtdMap.bem_get_1(bevt_0_ta_ph);
if (bevl_dmtd == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 106*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 108*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_psyn) {
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
bevp_allTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_mtdMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ptyMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_signatureChanged = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_signatureChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_uses = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_ta_ph = beva_psyn.bemd_0(1136580693);
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_2_ta_ph.bemd_0(1319388306);
bevt_3_ta_ph = beva_psyn.bemd_0(782632493);
bevp_superList.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = beva_psyn.bemd_0(-1841567201);
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_4_ta_ph.bemd_0(1319388306);
bevt_5_ta_ph = beva_psyn.bemd_0(746644508);
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_5_ta_ph.bemd_0(1319388306);
bevt_7_ta_ph = beva_klass.bemd_0(-64275311);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-175141450);
bevl_iv = bevt_6_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 131*/ {
bevt_8_ta_ph = bevl_iv.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 131*/ {
bevl_ov = bevl_iv.bemd_0(409355098);
bevt_9_ta_ph = beva_psyn.bemd_0(-1532808570);
bevt_11_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(1527025322);
bevl_pv = bevt_9_ta_ph.bemd_1(978995616, bevt_10_ta_ph);
bevt_14_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(1527025322);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_8_BuildClassSyn_bels_1));
bevt_12_ta_ph = bevt_13_ta_ph.bemd_1(-1519277296, bevt_15_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 134*/ {
if (bevl_pv == null) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 134*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 134*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 134*/
 else /* Line: 134*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 134*/ {
bevt_19_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-180800260);
bevt_17_ta_ph = bevt_18_ta_ph.bemd_0(-534139924);
if (((BEC_2_5_4_LogicBool) bevt_17_ta_ph).bevi_bool)/* Line: 134*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 134*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 134*/
 else /* Line: 134*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 134*/ {
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_8_BuildClassSyn_bels_2));
bevt_26_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(1527025322);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(44, bece_BEC_2_5_8_BuildClassSyn_bels_3));
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_30_ta_ph = beva_klass.bemd_0(-64275311);
bevt_29_ta_ph = bevt_30_ta_ph.bemd_0(782632493);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-467511392);
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_20_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_21_ta_ph, bevl_ov);
throw new be.BECS_ThrowBack(bevt_20_ta_ph);
} /* Line: 135*/
} /* Line: 134*/
 else /* Line: 131*/ {
break;
} /* Line: 131*/
} /* Line: 131*/
bevt_31_ta_ph = beva_psyn.bemd_0(746644508);
bevl_iv = bevt_31_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 140*/ {
bevt_32_ta_ph = bevl_iv.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 140*/ {
bevl_ov = bevl_iv.bemd_0(409355098);
bevt_34_ta_ph = bevl_ov.bemd_0(-454815927);
bevt_33_ta_ph = bevt_34_ta_ph.bemd_0(1868188754);
if (((BEC_2_5_4_LogicBool) bevt_33_ta_ph).bevi_bool)/* Line: 142*/ {
bevt_35_ta_ph = beva_klass.bemd_0(-64275311);
bevt_37_ta_ph = bevl_ov.bemd_0(-454815927);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(782632493);
bevt_35_ta_ph.bemd_1(-1265006852, bevt_36_ta_ph);
} /* Line: 143*/
} /* Line: 142*/
 else /* Line: 140*/ {
break;
} /* Line: 140*/
} /* Line: 140*/
bevt_39_ta_ph = beva_klass.bemd_0(-64275311);
bevt_38_ta_ph = bevt_39_ta_ph.bemd_0(-1339599063);
bevl_im = bevt_38_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 147*/ {
bevt_40_ta_ph = bevl_im.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 147*/ {
bevl_om = bevl_im.bemd_0(409355098);
bevt_41_ta_ph = beva_psyn.bemd_0(432467742);
bevt_43_ta_ph = bevl_om.bemd_0(-64275311);
bevt_42_ta_ph = bevt_43_ta_ph.bemd_0(1527025322);
bevl_pm = bevt_41_ta_ph.bemd_1(978995616, bevt_42_ta_ph);
if (bevl_pm == null) {
bevt_44_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_44_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_44_ta_ph.bevi_bool)/* Line: 150*/ {
bevt_46_ta_ph = bevl_pm.bemd_0(1417571167);
if (bevt_46_ta_ph == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 151*/ {
bevt_49_ta_ph = bevl_om.bemd_0(-64275311);
bevt_48_ta_ph = bevt_49_ta_ph.bemd_0(2114150480);
if (bevt_48_ta_ph == null) {
bevt_47_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_47_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_47_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_54_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(78, bece_BEC_2_5_8_BuildClassSyn_bels_4));
bevt_56_ta_ph = beva_klass.bemd_0(-64275311);
bevt_55_ta_ph = bevt_56_ta_ph.bemd_0(1527025322);
bevt_53_ta_ph = bevt_54_ta_ph.bem_add_1(bevt_55_ta_ph);
bevt_57_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_8_BuildClassSyn_bels_5));
bevt_52_ta_ph = bevt_53_ta_ph.bem_add_1(bevt_57_ta_ph);
bevt_59_ta_ph = bevl_om.bemd_0(-64275311);
bevt_58_ta_ph = bevt_59_ta_ph.bemd_0(1527025322);
bevt_51_ta_ph = bevt_52_ta_ph.bem_add_1(bevt_58_ta_ph);
bevt_50_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_51_ta_ph, bevl_om);
throw new be.BECS_ThrowBack(bevt_50_ta_ph);
} /* Line: 153*/
} /* Line: 152*/
} /* Line: 151*/
} /* Line: 150*/
 else /* Line: 147*/ {
break;
} /* Line: 147*/
} /* Line: 147*/
bem_loadClass_1(beva_klass);
bevt_60_ta_ph = beva_psyn.bemd_0(-1944361733);
bevt_61_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_depth = (BEC_2_4_3_MathInt) bevt_60_ta_ph.bemd_1(-475350780, bevt_61_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_castsTo_1(BEC_2_5_8_BuildNamePath beva_cto) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = bevp_allTypes.bem_has_1(beva_cto);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integrate_1(BEC_2_5_5_BuildBuild beva_build) {
BEC_2_5_6_BuildMtdSyn bevl_om = null;
BEC_2_5_8_BuildClassSyn bevl_psyn = null;
BEC_2_5_8_BuildNamePath bevl_pn = null;
BEC_2_5_8_BuildClassSyn bevl_pnsyn = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_5_6_BuildMtdSyn bevl_pm = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_8_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_9_ta_ph = null;
BEC_2_5_11_BuildMethodIndex bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_9_4_ContainerList bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_5_4_LogicBool bevt_30_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_5_4_LogicBool bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_55_ta_ph = null;
BEC_2_5_8_BuildEmitData bevt_56_ta_ph = null;
BEC_2_5_11_BuildMethodIndex bevt_57_ta_ph = null;
if (bevp_integrated.bevi_bool)/* Line: 167*/ {
return this;
} /* Line: 167*/
bevp_integrated = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 172*/ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_newMbrs = bevp_ptyList.bem_sizeGet_0();
bevp_newMtds = bevp_mtdList.bem_sizeGet_0();
bevp_defMtds = bevp_newMtds;
bevt_0_ta_loop = bevp_mtdList.bem_iteratorGet_0();
while (true)
/* Line: 177*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 177*/ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(409355098);
bevt_9_ta_ph = beva_build.bem_emitDataGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_methodIndexesGet_0();
bevt_10_ta_ph = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_8_ta_ph.bem_put_1(bevt_10_ta_ph);
} /* Line: 178*/
 else /* Line: 177*/ {
break;
} /* Line: 177*/
} /* Line: 177*/
return this;
} /* Line: 180*/
bevl_psyn = beva_build.bem_getSynNp_1(bevp_superNp);
bevp_newMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_defMtds = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_11_ta_ph = bevp_ptyList.bem_sizeGet_0();
bevt_13_ta_ph = bevl_psyn.bem_ptyListGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_sizeGet_0();
bevp_newMbrs = bevt_11_ta_ph.bem_subtract_1(bevt_12_ta_ph);
bevt_15_ta_ph = bevl_psyn.bem_libNameGet_0();
bevt_14_ta_ph = bevt_15_ta_ph.bem_equals_1(bevp_libName);
if (bevt_14_ta_ph.bevi_bool)/* Line: 187*/ {
bevl_psyn.bem_integrate_1(beva_build);
} /* Line: 187*/
bevt_16_ta_ph = bevl_psyn.bem_isFinalGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bece_BEC_2_5_8_BuildClassSyn_bels_6));
bevt_20_ta_ph = bevp_namepath.bem_toString_0();
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_17_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_18_ta_ph);
throw new be.BECS_ThrowBack(bevt_17_ta_ph);
} /* Line: 189*/
bevt_21_ta_ph = bevl_psyn.bem_isLocalGet_0();
if (bevt_21_ta_ph.bevi_bool)/* Line: 191*/ {
bevt_23_ta_ph = bevl_psyn.bem_libNameGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_notEquals_1(bevp_libName);
if (bevt_22_ta_ph.bevi_bool)/* Line: 191*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 191*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 191*/
 else /* Line: 191*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 191*/ {
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(68, bece_BEC_2_5_8_BuildClassSyn_bels_7));
bevt_27_ta_ph = bevp_namepath.bem_toString_0();
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_24_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 192*/
bevt_28_ta_ph = bevl_psyn.bem_isLocalGet_0();
if (bevt_28_ta_ph.bevi_bool)/* Line: 194*/ {
if (bevp_isLocal.bevi_bool) {
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 194*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 194*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 194*/
 else /* Line: 194*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 194*/ {
if (bevp_isFinal.bevi_bool) {
bevt_30_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_30_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_30_ta_ph.bevi_bool)/* Line: 194*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 194*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 194*/
 else /* Line: 194*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 194*/ {
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(75, bece_BEC_2_5_8_BuildClassSyn_bels_8));
bevt_34_ta_ph = bevp_namepath.bem_toString_0();
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_34_ta_ph);
bevt_31_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_32_ta_ph);
throw new be.BECS_ThrowBack(bevt_31_ta_ph);
} /* Line: 195*/
bevt_1_ta_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
/* Line: 197*/ {
bevt_35_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_35_ta_ph).bevi_bool)/* Line: 197*/ {
bevl_pn = (BEC_2_5_8_BuildNamePath) bevt_1_ta_loop.bem_nextGet_0();
bevl_pnsyn = beva_build.bem_getSynNp_1(bevl_pn);
bevt_38_ta_ph = beva_build.bem_closeLibrariesGet_0();
bevt_39_ta_ph = bevl_pnsyn.bem_libNameGet_0();
bevt_37_ta_ph = bevt_38_ta_ph.bem_has_1(bevt_39_ta_ph);
if (bevt_37_ta_ph.bevi_bool) {
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 199*/ {
bevt_41_ta_ph = bevl_pn.bem_toString_0();
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_8_BuildClassSyn_bels_9));
bevt_40_ta_ph = bevt_41_ta_ph.bem_notEquals_1(bevt_42_ta_ph);
if (bevt_40_ta_ph.bevi_bool)/* Line: 199*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 199*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 199*/
 else /* Line: 199*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 199*/ {
bevp_directProperties = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_directMethods = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 202*/
bevt_45_ta_ph = beva_build.bem_closeLibrariesGet_0();
bevt_46_ta_ph = bevl_pnsyn.bem_libNameGet_0();
bevt_44_ta_ph = bevt_45_ta_ph.bem_has_1(bevt_46_ta_ph);
if (bevt_44_ta_ph.bevi_bool) {
bevt_43_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_43_ta_ph.bevi_bool)/* Line: 204*/ {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 205*/
} /* Line: 204*/
 else /* Line: 197*/ {
break;
} /* Line: 197*/
} /* Line: 197*/
bevl_im = bevp_mtdMap.bem_valueIteratorGet_0();
while (true)
/* Line: 209*/ {
bevt_47_ta_ph = bevl_im.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_47_ta_ph).bevi_bool)/* Line: 209*/ {
bevl_om = (BEC_2_5_6_BuildMtdSyn) bevl_im.bemd_0(409355098);
bevt_48_ta_ph = bevl_psyn.bem_mtdMapGet_0();
bevt_49_ta_ph = bevl_om.bem_nameGet_0();
bevl_pm = (BEC_2_5_6_BuildMtdSyn) bevt_48_ta_ph.bem_get_1(bevt_49_ta_ph);
if (bevl_pm == null) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 212*/ {
bevt_51_ta_ph = bevl_om.bem_notEquals_1(bevl_pm);
if (bevt_51_ta_ph.bevi_bool)/* Line: 213*/ {
bevt_52_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pm.bem_lastDefSet_1(bevt_52_ta_ph);
bevt_53_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_om.bem_isOverrideSet_1(bevt_53_ta_ph);
bevp_defMtds = bevp_defMtds.bem_increment_0();
} /* Line: 216*/
} /* Line: 213*/
 else /* Line: 218*/ {
bevt_54_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_om.bem_isOverrideSet_1(bevt_54_ta_ph);
bevp_newMtds = bevp_newMtds.bem_increment_0();
bevp_defMtds = bevp_defMtds.bem_increment_0();
bevt_56_ta_ph = beva_build.bem_emitDataGet_0();
bevt_55_ta_ph = bevt_56_ta_ph.bem_methodIndexesGet_0();
bevt_57_ta_ph = (BEC_2_5_11_BuildMethodIndex) (new BEC_2_5_11_BuildMethodIndex()).bem_new_2(this, bevl_om);
bevt_55_ta_ph.bem_put_1(bevt_57_ta_ph);
} /* Line: 222*/
} /* Line: 212*/
 else /* Line: 209*/ {
break;
} /* Line: 209*/
} /* Line: 209*/
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkInheritance_2(BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_pv = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_pm = null;
BEC_2_6_6_SystemObject bevl_oa = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_pmr = null;
BEC_2_6_6_SystemObject bevl_omr = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_6_6_SystemObject bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_5_4_LogicBool bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_5_4_LogicBool bevt_61_ta_ph = null;
BEC_2_5_4_LogicBool bevt_62_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_6_6_SystemObject bevt_67_ta_ph = null;
BEC_2_6_6_SystemObject bevt_68_ta_ph = null;
BEC_2_6_6_SystemObject bevt_69_ta_ph = null;
BEC_2_6_6_SystemObject bevt_70_ta_ph = null;
BEC_2_6_6_SystemObject bevt_71_ta_ph = null;
BEC_2_6_6_SystemObject bevt_72_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
if (bevp_iChecked.bevi_bool)/* Line: 229*/ {
return this;
} /* Line: 229*/
bevp_iChecked = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_superNp == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 231*/ {
return this;
} /* Line: 231*/
bevl_psyn = beva_build.bemd_1(-1268569717, bevp_superNp);
bevt_5_ta_ph = beva_klass.bemd_0(-64275311);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-175141450);
bevl_iv = bevt_4_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 233*/ {
bevt_6_ta_ph = bevl_iv.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 233*/ {
bevl_ov = bevl_iv.bemd_0(409355098);
bevt_7_ta_ph = bevl_psyn.bemd_0(-1532808570);
bevt_9_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1527025322);
bevl_pv = bevt_7_ta_ph.bemd_1(978995616, bevt_8_ta_ph);
if (bevl_pv == null) {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 236*/ {
bevt_12_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-180800260);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 237*/ {
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_8_BuildClassSyn_bels_10));
bevt_19_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(1527025322);
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_18_ta_ph);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_8_BuildClassSyn_bels_11));
bevt_15_ta_ph = bevt_16_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_23_ta_ph = beva_klass.bemd_0(-64275311);
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(782632493);
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-467511392);
bevt_14_ta_ph = bevt_15_ta_ph.bem_add_1(bevt_21_ta_ph);
bevt_13_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_1(bevt_14_ta_ph);
throw new be.BECS_ThrowBack(bevt_13_ta_ph);
} /* Line: 238*/
 else /* Line: 239*/ {
bevt_24_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_26_ta_ph = bevl_pv.bemd_0(-454815927);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_0(1868188754);
bevt_24_ta_ph.bemd_1(1302681807, bevt_25_ta_ph);
bevt_27_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_29_ta_ph = bevl_pv.bemd_0(-454815927);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(782632493);
bevt_27_ta_ph.bemd_1(556253518, bevt_28_ta_ph);
} /* Line: 241*/
} /* Line: 237*/
} /* Line: 236*/
 else /* Line: 233*/ {
break;
} /* Line: 233*/
} /* Line: 233*/
bevt_31_ta_ph = beva_klass.bemd_0(-64275311);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_0(-1339599063);
bevl_im = bevt_30_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 245*/ {
bevt_32_ta_ph = bevl_im.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 245*/ {
bevl_om = bevl_im.bemd_0(409355098);
bevt_33_ta_ph = bevl_psyn.bemd_0(432467742);
bevt_35_ta_ph = bevl_om.bemd_0(-64275311);
bevt_34_ta_ph = bevt_35_ta_ph.bemd_0(1527025322);
bevl_pm = bevt_33_ta_ph.bemd_1(978995616, bevt_34_ta_ph);
if (bevl_pm == null) {
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_37_ta_ph = bevl_pm.bemd_0(1394040921);
if (((BEC_2_5_4_LogicBool) bevt_37_ta_ph).bevi_bool)/* Line: 249*/ {
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_8_BuildClassSyn_bels_12));
bevt_44_ta_ph = bevl_om.bemd_0(-64275311);
bevt_43_ta_ph = bevt_44_ta_ph.bemd_0(1527025322);
bevt_41_ta_ph = bevt_42_ta_ph.bem_add_1(bevt_43_ta_ph);
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_8_BuildClassSyn_bels_13));
bevt_40_ta_ph = bevt_41_ta_ph.bem_add_1(bevt_45_ta_ph);
bevt_48_ta_ph = beva_klass.bemd_0(-64275311);
bevt_47_ta_ph = bevt_48_ta_ph.bemd_0(782632493);
bevt_46_ta_ph = bevt_47_ta_ph.bemd_0(-467511392);
bevt_39_ta_ph = bevt_40_ta_ph.bem_add_1(bevt_46_ta_ph);
bevt_38_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_39_ta_ph, bevl_om);
throw new be.BECS_ThrowBack(bevt_38_ta_ph);
} /* Line: 250*/
bevt_50_ta_ph = bevl_om.bemd_0(1815203708);
bevt_49_ta_ph = bevt_50_ta_ph.bemd_0(1171374908);
bevl_oa = bevt_49_ta_ph.bemd_0(1815203708);
bevl_i = (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 253*/ {
bevt_53_ta_ph = bevl_pm.bemd_0(2060553150);
bevt_52_ta_ph = bevt_53_ta_ph.bemd_0(69333303);
bevt_51_ta_ph = bevl_i.bemd_1(2036819915, bevt_52_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 253*/ {
bevt_54_ta_ph = bevl_pm.bemd_0(2060553150);
bevl_pmr = bevt_54_ta_ph.bemd_1(978995616, bevl_i);
bevt_55_ta_ph = bevl_oa.bemd_1(978995616, bevl_i);
bevl_omr = bevt_55_ta_ph.bemd_0(-64275311);
bem_checkTypes_5(beva_klass, beva_build, bevl_omr, bevl_pmr, bevl_om);
bevl_i = bevl_i.bemd_0(-27893732);
} /* Line: 253*/
 else /* Line: 253*/ {
break;
} /* Line: 253*/
} /* Line: 253*/
bevl_pmr = bevl_pm.bemd_0(1417571167);
bevt_56_ta_ph = bevl_om.bemd_0(-64275311);
bevl_omr = bevt_56_ta_ph.bemd_0(2114150480);
if (bevl_pmr == null) {
bevt_57_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_57_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_57_ta_ph.bevi_bool)/* Line: 261*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 261*/ {
if (bevl_omr == null) {
bevt_58_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_58_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_58_ta_ph.bevi_bool)/* Line: 261*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 261*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 261*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 261*/ {
if (bevl_pmr == null) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool) {
bevt_59_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_59_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_59_ta_ph.bevi_bool)/* Line: 262*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 262*/ {
if (bevl_omr == null) {
bevt_62_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_62_ta_ph.bevi_bool) {
bevt_61_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_61_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_61_ta_ph.bevi_bool)/* Line: 262*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 262*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 262*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 262*/ {
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(95, bece_BEC_2_5_8_BuildClassSyn_bels_14));
bevt_68_ta_ph = beva_klass.bemd_0(-64275311);
bevt_67_ta_ph = bevt_68_ta_ph.bemd_0(782632493);
bevt_66_ta_ph = bevt_67_ta_ph.bemd_0(-467511392);
bevt_64_ta_ph = bevt_65_ta_ph.bem_add_1(bevt_66_ta_ph);
bevt_63_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_64_ta_ph, bevl_om);
throw new be.BECS_ThrowBack(bevt_63_ta_ph);
} /* Line: 267*/
} /* Line: 262*/
 else /* Line: 269*/ {
bevt_69_ta_ph = bevl_pmr.bemd_0(527909107);
if (((BEC_2_5_4_LogicBool) bevt_69_ta_ph).bevi_bool)/* Line: 271*/ {
bevt_71_ta_ph = bevl_pmr.bemd_0(527909107);
bevt_72_ta_ph = bevl_omr.bemd_0(527909107);
bevt_70_ta_ph = bevt_71_ta_ph.bemd_1(-1519277296, bevt_72_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_70_ta_ph).bevi_bool)/* Line: 271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 271*/
 else /* Line: 271*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 271*/ {
bevt_75_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(90, bece_BEC_2_5_8_BuildClassSyn_bels_15));
bevt_78_ta_ph = beva_klass.bemd_0(-64275311);
bevt_77_ta_ph = bevt_78_ta_ph.bemd_0(782632493);
bevt_76_ta_ph = bevt_77_ta_ph.bemd_0(-467511392);
bevt_74_ta_ph = bevt_75_ta_ph.bem_add_1(bevt_76_ta_ph);
bevt_73_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_74_ta_ph, bevl_om);
throw new be.BECS_ThrowBack(bevt_73_ta_ph);
} /* Line: 272*/
bem_checkTypes_5(beva_klass, beva_build, bevl_pmr, bevl_omr, bevl_om);
} /* Line: 274*/
} /* Line: 261*/
} /* Line: 248*/
 else /* Line: 245*/ {
break;
} /* Line: 245*/
} /* Line: 245*/
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_checkTypes_5(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_build, BEC_2_6_6_SystemObject beva_pmr, BEC_2_6_6_SystemObject beva_omr, BEC_2_6_6_SystemObject beva_om) {
BEC_2_6_6_SystemObject bevl_osyn = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
bevt_2_ta_ph = beva_pmr.bemd_0(1868188754);
bevt_3_ta_ph = beva_omr.bemd_0(1868188754);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_1(-1519277296, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 281*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(84, bece_BEC_2_5_8_BuildClassSyn_bels_16));
bevt_9_ta_ph = beva_klass.bemd_0(-64275311);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(782632493);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-467511392);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_4_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_5_ta_ph, beva_om);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 282*/
 else /* Line: 281*/ {
bevt_10_ta_ph = beva_pmr.bemd_0(1868188754);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 283*/ {
bevt_11_ta_ph = beva_pmr.bemd_0(-1813683359);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 286*/ {
bevt_12_ta_ph = beva_omr.bemd_0(-1813683359);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 286*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 286*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 286*/
 else /* Line: 286*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 286*/ {
return this;
} /* Line: 287*/
bevt_13_ta_ph = beva_omr.bemd_0(782632493);
bevl_osyn = beva_build.bemd_1(-1268569717, bevt_13_ta_ph);
bevt_16_ta_ph = bevl_osyn.bemd_0(963817456);
bevt_17_ta_ph = beva_pmr.bemd_0(782632493);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-1243270878, bevt_17_ta_ph);
bevt_14_ta_ph = bevt_15_ta_ph.bemd_0(-534139924);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 290*/ {
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(80, bece_BEC_2_5_8_BuildClassSyn_bels_17));
bevt_23_ta_ph = beva_klass.bemd_0(-64275311);
bevt_22_ta_ph = bevt_23_ta_ph.bemd_0(782632493);
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(-467511392);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevt_21_ta_ph);
bevt_18_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_19_ta_ph, beva_om);
throw new be.BECS_ThrowBack(bevt_18_ta_ph);
} /* Line: 291*/
} /* Line: 290*/
} /* Line: 281*/
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_new_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_10_BuildVisitError bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
bem_new_0();
bevt_1_ta_ph = beva_klass.bemd_0(-64275311);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-175141450);
bevl_iv = bevt_0_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 298*/ {
bevt_2_ta_ph = bevl_iv.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 298*/ {
bevl_ov = bevl_iv.bemd_0(409355098);
bevt_5_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-180800260);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-534139924);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 300*/ {
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_8_BuildClassSyn_bels_2));
bevt_12_ta_ph = bevl_ov.bemd_0(-64275311);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(1527025322);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevt_11_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_8_BuildClassSyn_bels_18));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_13_ta_ph);
bevt_16_ta_ph = beva_klass.bemd_0(-64275311);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(782632493);
bevt_14_ta_ph = bevt_15_ta_ph.bemd_0(-467511392);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_6_ta_ph = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_7_ta_ph, bevl_ov);
throw new be.BECS_ThrowBack(bevt_6_ta_ph);
} /* Line: 301*/
} /* Line: 300*/
 else /* Line: 298*/ {
break;
} /* Line: 298*/
} /* Line: 298*/
bem_loadClass_1(beva_klass);
bevp_depth = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_loadClass_1(BEC_2_6_6_SystemObject beva_klass) {
BEC_2_6_6_SystemObject bevl_iu = null;
BEC_2_6_6_SystemObject bevl_ou = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_prop = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_6_6_SystemObject bevl_msyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
bevt_0_ta_ph = beva_klass.bemd_0(-64275311);
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_ph.bemd_0(1755281620);
bevt_1_ta_ph = beva_klass.bemd_0(-64275311);
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_1_ta_ph.bemd_0(782632493);
bevt_2_ta_ph = beva_klass.bemd_0(-64275311);
bevp_libName = (BEC_2_4_6_TextString) bevt_2_ta_ph.bemd_0(-1662902255);
bevt_3_ta_ph = beva_klass.bemd_0(-64275311);
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_3_ta_ph.bemd_0(1394040921);
bevt_4_ta_ph = beva_klass.bemd_0(-64275311);
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_4_ta_ph.bemd_0(-225649058);
bevt_5_ta_ph = beva_klass.bemd_0(-64275311);
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_5_ta_ph.bemd_0(-103940610);
bevt_7_ta_ph = beva_klass.bemd_0(-64275311);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(1901659451);
bevl_iu = bevt_6_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 316*/ {
bevt_8_ta_ph = bevl_iu.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 316*/ {
bevl_ou = bevl_iu.bemd_0(409355098);
bevt_9_ta_ph = bevl_ou.bemd_0(-467511392);
bevp_uses.bem_put_1(bevt_9_ta_ph);
} /* Line: 318*/
 else /* Line: 316*/ {
break;
} /* Line: 316*/
} /* Line: 316*/
bevt_11_ta_ph = beva_klass.bemd_0(-64275311);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-175141450);
bevl_iv = bevt_10_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 320*/ {
bevt_12_ta_ph = bevl_iv.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_12_ta_ph).bevi_bool)/* Line: 320*/ {
bevl_ov = bevl_iv.bemd_0(409355098);
bevl_prop = (new BEC_2_5_6_BuildPtySyn()).bem_new_2(bevl_ov, bevp_namepath);
bevp_ptyList.bem_addValue_1(bevl_prop);
} /* Line: 323*/
 else /* Line: 320*/ {
break;
} /* Line: 320*/
} /* Line: 320*/
bevt_14_ta_ph = beva_klass.bemd_0(-64275311);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(-1339599063);
bevl_im = bevt_13_ta_ph.bemd_0(-793241295);
while (true)
/* Line: 325*/ {
bevt_15_ta_ph = bevl_im.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 325*/ {
bevl_om = bevl_im.bemd_0(409355098);
bevl_msyn = (new BEC_2_5_6_BuildMtdSyn()).bem_new_2(bevl_om, bevp_namepath);
bevp_mtdList.bem_addValue_1(bevl_msyn);
} /* Line: 328*/
 else /* Line: 325*/ {
break;
} /* Line: 325*/
} /* Line: 325*/
bem_postLoad_0();
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_postLoad_0() {
BEC_2_9_4_ContainerList bevl_nptyList = null;
BEC_2_9_4_ContainerList bevl_mtdnList = null;
BEC_2_9_3_ContainerMap bevl_unq = null;
BEC_2_6_6_SystemObject bevl_iv = null;
BEC_2_6_6_SystemObject bevl_ov = null;
BEC_2_6_6_SystemObject bevl_mpos = null;
BEC_2_6_6_SystemObject bevl_nom = null;
BEC_2_9_3_ContainerMap bevl_mtdOmap = null;
BEC_2_6_6_SystemObject bevl_im = null;
BEC_2_6_6_SystemObject bevl_om = null;
BEC_2_4_3_MathInt bevl_mtdx = null;
BEC_2_6_6_SystemObject bevl_oma = null;
BEC_2_5_6_BuildMtdSyn bevl_msyno = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_27_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_28_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
bevl_nptyList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_mtdnList = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 338*/ {
bevt_1_ta_ph = bevl_iv.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 338*/ {
bevl_ov = bevl_iv.bemd_0(409355098);
bevt_4_ta_ph = bevl_ov.bemd_0(1527025322);
bevt_3_ta_ph = bevp_ptyMap.bem_has_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 340*/ {
bevt_5_ta_ph = bevl_ov.bemd_0(1527025322);
bevp_ptyMap.bem_put_2(bevt_5_ta_ph, bevl_ov);
} /* Line: 342*/
} /* Line: 340*/
 else /* Line: 338*/ {
break;
} /* Line: 338*/
} /* Line: 338*/
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mpos = (new BEC_2_4_3_MathInt(0));
bevl_iv = bevp_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 348*/ {
bevt_6_ta_ph = bevl_iv.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 348*/ {
bevl_ov = bevl_iv.bemd_0(409355098);
bevt_9_ta_ph = bevl_ov.bemd_0(1527025322);
bevt_8_ta_ph = bevl_unq.bem_has_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool) {
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 350*/ {
bevt_10_ta_ph = bevl_ov.bemd_0(1527025322);
bevl_nom = bevp_ptyMap.bem_get_1(bevt_10_ta_ph);
bevl_nom.bemd_1(-1520669085, bevl_mpos);
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_mpos = bevl_mpos.bemd_1(-475350780, bevt_11_ta_ph);
bevl_nptyList.bem_addValue_1(bevl_nom);
bevt_12_ta_ph = bevl_ov.bemd_0(1527025322);
bevt_13_ta_ph = bevl_ov.bemd_0(1527025322);
bevl_unq.bem_put_2(bevt_12_ta_ph, bevt_13_ta_ph);
} /* Line: 355*/
} /* Line: 350*/
 else /* Line: 348*/ {
break;
} /* Line: 348*/
} /* Line: 348*/
bevp_ptyList = bevl_nptyList;
bevl_mtdOmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
/* Line: 362*/ {
bevt_14_ta_ph = bevl_im.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 362*/ {
bevl_om = bevl_im.bemd_0(409355098);
bevt_15_ta_ph = bevl_om.bemd_0(1527025322);
bevp_mtdMap.bem_put_2(bevt_15_ta_ph, bevl_om);
bevt_18_ta_ph = bevl_om.bemd_0(1527025322);
bevt_17_ta_ph = bevl_mtdOmap.bem_has_1(bevt_18_ta_ph);
if (bevt_17_ta_ph.bevi_bool) {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 367*/ {
bevt_19_ta_ph = bevl_om.bemd_0(1527025322);
bevl_mtdOmap.bem_put_2(bevt_19_ta_ph, bevl_om);
} /* Line: 368*/
} /* Line: 367*/
 else /* Line: 362*/ {
break;
} /* Line: 362*/
} /* Line: 362*/
bevl_unq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_mtdx = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_im = bevp_mtdList.bem_iteratorGet_0();
while (true)
/* Line: 374*/ {
bevt_20_ta_ph = bevl_im.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_20_ta_ph).bevi_bool)/* Line: 374*/ {
bevl_om = bevl_im.bemd_0(409355098);
bevt_23_ta_ph = bevl_om.bemd_0(1527025322);
bevt_22_ta_ph = bevl_unq.bem_has_1(bevt_23_ta_ph);
if (bevt_22_ta_ph.bevi_bool) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 376*/ {
bevt_24_ta_ph = bevl_om.bemd_0(1527025322);
bevl_oma = bevp_mtdMap.bem_get_1(bevt_24_ta_ph);
bevt_25_ta_ph = bevl_om.bemd_0(1527025322);
bevl_msyno = (BEC_2_5_6_BuildMtdSyn) bevl_mtdOmap.bem_get_1(bevt_25_ta_ph);
bevt_27_ta_ph = bevl_msyno.bem_declarationGet_0();
if (bevt_27_ta_ph == null) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 387*/ {
bevt_28_ta_ph = bevl_msyno.bem_originGet_0();
bevl_msyno.bem_declarationSet_1(bevt_28_ta_ph);
} /* Line: 388*/
bevt_29_ta_ph = bevl_msyno.bem_declarationGet_0();
bevl_oma.bemd_1(-204926474, bevt_29_ta_ph);
bevl_oma.bemd_1(-2070095672, bevl_mtdx);
bevl_mtdx = bevl_mtdx.bem_increment_0();
bevl_mtdnList.bem_addValue_1(bevl_oma);
bevt_30_ta_ph = bevl_om.bemd_0(1527025322);
bevt_31_ta_ph = bevl_om.bemd_0(1527025322);
bevl_unq.bem_put_2(bevt_30_ta_ph, bevt_31_ta_ph);
} /* Line: 394*/
} /* Line: 376*/
 else /* Line: 374*/ {
break;
} /* Line: 374*/
} /* Line: 374*/
bevp_mtdList = bevl_mtdnList;
bevt_0_ta_loop = bevp_superList.bem_linkedListIteratorGet_0();
while (true)
/* Line: 399*/ {
bevt_32_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_32_ta_ph).bevi_bool)/* Line: 399*/ {
bevl_s = bevt_0_ta_loop.bem_nextGet_0();
bevp_allTypes.bem_put_2(bevl_s, bevl_s);
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevl_s;
} /* Line: 401*/
 else /* Line: 399*/ {
break;
} /* Line: 399*/
} /* Line: 399*/
bevp_allTypes.bem_put_2(bevp_namepath, bevp_namepath);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGet_0() {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_superNpGetDirect_0() {
return bevp_superNp;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_superNp = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGet_0() {
return bevp_depth;
} /*method end*/
public BEC_2_4_3_MathInt bem_depthGetDirect_0() {
return bevp_depth;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_depthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_depth = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGet_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isLocalGetDirect_0() {
return bevp_isLocal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isLocalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isLocal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGet_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNotNullGetDirect_0() {
return bevp_isNotNull;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isNotNullSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isNotNull = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGet_0() {
return bevp_newMbrs;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMbrsGetDirect_0() {
return bevp_newMbrs;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMbrsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newMbrs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGet_0() {
return bevp_newMtds;
} /*method end*/
public BEC_2_4_3_MathInt bem_newMtdsGetDirect_0() {
return bevp_newMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_newMtdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newMtds = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGet_0() {
return bevp_defMtds;
} /*method end*/
public BEC_2_4_3_MathInt bem_defMtdsGetDirect_0() {
return bevp_defMtds;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_defMtdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_defMtds = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGet_0() {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directPropertiesGetDirect_0() {
return bevp_directProperties;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directPropertiesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_directProperties = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGet_0() {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_4_LogicBool bem_directMethodsGetDirect_0() {
return bevp_directMethods;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_directMethodsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_directMethods = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGet_0() {
return bevp_allTypes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allTypesGetDirect_0() {
return bevp_allTypes;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allTypes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGet_0() {
return bevp_superList;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_superListGetDirect_0() {
return bevp_superList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_superListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_superList = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGet_0() {
return bevp_mtdMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mtdMapGetDirect_0() {
return bevp_mtdMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mtdMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGet_0() {
return bevp_mtdList;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mtdListGetDirect_0() {
return bevp_mtdList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_mtdListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mtdList = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGet_0() {
return bevp_ptyMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_ptyMapGetDirect_0() {
return bevp_ptyMap;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ptyMap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGet_0() {
return bevp_ptyList;
} /*method end*/
public BEC_2_9_4_ContainerList bem_ptyListGetDirect_0() {
return bevp_ptyList;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_ptyListSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ptyList = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGet_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_allNamesGetDirect_0() {
return bevp_allNames;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allNames = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGet_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_foreignClassesGetDirect_0() {
return bevp_foreignClasses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_foreignClassesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_foreignClasses = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGet_0() {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_4_LogicBool bem_allAncestorsCloseGetDirect_0() {
return bevp_allAncestorsClose;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_allAncestorsCloseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allAncestorsClose = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGet_0() {
return bevp_integrated;
} /*method end*/
public BEC_2_5_4_LogicBool bem_integratedGetDirect_0() {
return bevp_integrated;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_integratedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_integrated = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGet_0() {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_4_LogicBool bem_iCheckedGetDirect_0() {
return bevp_iChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_iCheckedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_iChecked = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGet_0() {
return bevp_uses;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_usesGetDirect_0() {
return bevp_uses;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_usesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_uses = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGet_0() {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureChangedGetDirect_0() {
return bevp_signatureChanged;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureChangedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_signatureChanged = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGet_0() {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_4_LogicBool bem_signatureCheckedGetDirect_0() {
return bevp_signatureChecked;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_signatureCheckedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_signatureChecked = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {71, 73, 75, 77, 78, 79, 80, 81, 82, 83, 84, 86, 87, 88, 89, 94, 95, 95, 96, 97, 97, 97, 98, 101, 105, 105, 106, 106, 108, 108, 110, 110, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 125, 126, 126, 127, 127, 128, 128, 131, 131, 131, 131, 132, 133, 133, 133, 133, 134, 134, 134, 134, 134, 134, 0, 0, 0, 134, 134, 134, 0, 0, 0, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 135, 140, 140, 140, 141, 142, 142, 143, 143, 143, 143, 147, 147, 147, 147, 148, 149, 149, 149, 149, 150, 150, 151, 151, 151, 152, 152, 152, 152, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 158, 159, 159, 159, 163, 163, 167, 168, 169, 170, 171, 172, 172, 173, 174, 175, 176, 177, 0, 177, 177, 178, 178, 178, 178, 180, 182, 183, 184, 186, 186, 186, 186, 187, 187, 187, 188, 189, 189, 189, 189, 189, 191, 191, 191, 0, 0, 0, 192, 192, 192, 192, 192, 194, 194, 194, 0, 0, 0, 194, 194, 0, 0, 0, 195, 195, 195, 195, 195, 197, 0, 197, 197, 198, 199, 199, 199, 199, 199, 199, 199, 199, 0, 0, 0, 201, 202, 204, 204, 204, 204, 204, 205, 209, 209, 210, 211, 211, 211, 212, 212, 213, 214, 214, 215, 215, 216, 219, 219, 220, 221, 222, 222, 222, 222, 229, 230, 231, 231, 231, 232, 233, 233, 233, 233, 234, 235, 235, 235, 235, 236, 236, 237, 237, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 240, 240, 240, 240, 241, 241, 241, 241, 245, 245, 245, 245, 246, 247, 247, 247, 247, 248, 248, 249, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 252, 252, 252, 253, 253, 253, 253, 254, 254, 255, 255, 257, 253, 259, 260, 260, 261, 261, 0, 261, 261, 0, 0, 262, 262, 262, 0, 262, 262, 262, 0, 0, 267, 267, 267, 267, 267, 267, 267, 271, 271, 271, 271, 0, 0, 0, 272, 272, 272, 272, 272, 272, 272, 274, 281, 281, 281, 282, 282, 282, 282, 282, 282, 282, 283, 286, 286, 0, 0, 0, 287, 289, 289, 290, 290, 290, 290, 291, 291, 291, 291, 291, 291, 291, 297, 298, 298, 298, 298, 299, 300, 300, 300, 301, 301, 301, 301, 301, 301, 301, 301, 301, 301, 301, 301, 304, 305, 310, 310, 311, 311, 312, 312, 313, 313, 314, 314, 315, 315, 316, 316, 316, 316, 317, 318, 318, 320, 320, 320, 320, 321, 322, 323, 325, 325, 325, 325, 326, 327, 328, 330, 334, 335, 338, 338, 339, 340, 340, 340, 340, 342, 342, 346, 347, 348, 348, 349, 350, 350, 350, 350, 351, 351, 352, 353, 353, 354, 355, 355, 355, 358, 360, 362, 362, 363, 365, 365, 367, 367, 367, 367, 368, 368, 372, 373, 374, 374, 375, 376, 376, 376, 376, 377, 377, 386, 386, 387, 387, 387, 388, 388, 390, 390, 391, 392, 393, 394, 394, 394, 397, 399, 0, 399, 399, 400, 401, 404, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 83, 84, 87, 89, 90, 91, 96, 97, 104, 112, 113, 114, 119, 120, 121, 123, 124, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 221, 223, 224, 225, 226, 227, 228, 229, 230, 231, 233, 238, 239, 242, 246, 249, 250, 251, 253, 256, 260, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 281, 282, 285, 287, 288, 289, 291, 292, 293, 294, 301, 302, 303, 306, 308, 309, 310, 311, 312, 313, 318, 319, 320, 325, 326, 327, 328, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 353, 354, 355, 356, 361, 362, 430, 432, 433, 434, 435, 436, 441, 442, 443, 444, 445, 446, 446, 449, 451, 452, 453, 454, 455, 461, 463, 464, 465, 466, 467, 468, 469, 470, 471, 473, 475, 477, 478, 479, 480, 481, 483, 485, 486, 488, 491, 495, 498, 499, 500, 501, 502, 504, 506, 511, 512, 515, 519, 522, 527, 528, 531, 535, 538, 539, 540, 541, 542, 544, 544, 547, 549, 550, 551, 552, 553, 554, 559, 560, 561, 562, 564, 567, 571, 574, 575, 577, 578, 579, 580, 585, 586, 593, 596, 598, 599, 600, 601, 602, 607, 608, 610, 611, 612, 613, 614, 618, 619, 620, 621, 622, 623, 624, 625, 726, 728, 729, 734, 735, 737, 738, 739, 740, 743, 745, 746, 747, 748, 749, 750, 755, 756, 757, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 773, 774, 775, 776, 777, 778, 779, 780, 788, 789, 790, 793, 795, 796, 797, 798, 799, 800, 805, 806, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 821, 822, 823, 824, 827, 828, 829, 831, 832, 833, 834, 835, 836, 842, 843, 844, 845, 850, 851, 854, 859, 860, 863, 867, 872, 877, 878, 881, 886, 891, 892, 895, 899, 900, 901, 902, 903, 904, 905, 909, 911, 912, 913, 915, 918, 922, 925, 926, 927, 928, 929, 930, 931, 933, 969, 970, 971, 973, 974, 975, 976, 977, 978, 979, 982, 984, 986, 988, 991, 995, 998, 1000, 1001, 1002, 1003, 1004, 1005, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1039, 1040, 1041, 1042, 1045, 1047, 1048, 1049, 1050, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1070, 1071, 1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1116, 1118, 1119, 1120, 1126, 1127, 1128, 1131, 1133, 1134, 1135, 1141, 1142, 1143, 1146, 1148, 1149, 1150, 1156, 1207, 1208, 1209, 1212, 1214, 1215, 1216, 1217, 1222, 1223, 1224, 1231, 1232, 1233, 1236, 1238, 1239, 1240, 1241, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1255, 1262, 1263, 1264, 1267, 1269, 1270, 1271, 1272, 1273, 1274, 1279, 1280, 1281, 1288, 1289, 1290, 1293, 1295, 1296, 1297, 1298, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1314, 1315, 1316, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1332, 1333, 1333, 1336, 1338, 1339, 1340, 1346, 1350, 1353, 1356, 1360, 1364, 1367, 1370, 1374, 1378, 1381, 1384, 1388, 1392, 1395, 1398, 1402, 1406, 1409, 1412, 1416, 1420, 1423, 1426, 1430, 1434, 1437, 1440, 1444, 1448, 1451, 1454, 1458, 1462, 1465, 1468, 1472, 1476, 1479, 1482, 1486, 1490, 1493, 1496, 1500, 1504, 1507, 1510, 1514, 1518, 1521, 1524, 1528, 1532, 1535, 1538, 1542, 1546, 1549, 1552, 1556, 1560, 1563, 1566, 1570, 1574, 1577, 1580, 1584, 1588, 1591, 1594, 1598, 1602, 1605, 1608, 1612, 1616, 1619, 1622, 1626, 1630, 1633, 1636, 1640, 1644, 1647, 1650, 1654, 1658, 1661, 1664, 1668, 1672, 1675, 1678, 1682, 1686, 1689, 1692, 1696, 1700, 1703, 1706, 1710, 1714, 1717, 1720, 1724};
/* BEGIN LINEINFO 
assign 1 71 59
new 0 71 59
assign 1 73 60
new 0 73 60
assign 1 75 61
new 0 75 61
assign 1 77 62
new 0 77 62
assign 1 78 63
new 0 78 63
assign 1 79 64
new 0 79 64
assign 1 80 65
new 0 80 65
assign 1 81 66
new 0 81 66
assign 1 82 67
new 0 82 67
assign 1 83 68
new 0 83 68
assign 1 84 69
new 0 84 69
assign 1 86 70
new 0 86 70
assign 1 87 71
new 0 87 71
assign 1 88 72
new 0 88 72
assign 1 89 73
new 0 89 73
assign 1 94 83
new 0 94 83
assign 1 95 84
valueIteratorGet 0 95 84
assign 1 95 87
hasNextGet 0 95 87
assign 1 96 89
nextGet 0 96 89
assign 1 97 90
mtdxGet 0 97 90
assign 1 97 91
greater 1 97 96
assign 1 98 97
mtdxGet 0 98 97
return 1 101 104
assign 1 105 112
new 0 105 112
assign 1 105 113
get 1 105 113
assign 1 106 114
def 1 106 119
assign 1 108 120
new 0 108 120
return 1 108 121
assign 1 110 123
new 0 110 123
return 1 110 124
assign 1 114 197
new 0 114 197
assign 1 115 198
new 0 115 198
assign 1 116 199
new 0 116 199
assign 1 117 200
new 0 117 200
assign 1 118 201
new 0 118 201
assign 1 119 202
new 0 119 202
assign 1 120 203
new 0 120 203
assign 1 121 204
new 0 121 204
assign 1 122 205
new 0 122 205
assign 1 123 206
new 0 123 206
assign 1 124 207
new 0 124 207
assign 1 125 208
superListGet 0 125 208
assign 1 125 209
copy 0 125 209
assign 1 126 210
namepathGet 0 126 210
addValue 1 126 211
assign 1 127 212
mtdListGet 0 127 212
assign 1 127 213
copy 0 127 213
assign 1 128 214
ptyListGet 0 128 214
assign 1 128 215
copy 0 128 215
assign 1 131 216
heldGet 0 131 216
assign 1 131 217
orderedVarsGet 0 131 217
assign 1 131 218
iteratorGet 0 131 218
assign 1 131 221
hasNextGet 0 131 221
assign 1 132 223
nextGet 0 132 223
assign 1 133 224
ptyMapGet 0 133 224
assign 1 133 225
heldGet 0 133 225
assign 1 133 226
nameGet 0 133 226
assign 1 133 227
get 1 133 227
assign 1 134 228
heldGet 0 134 228
assign 1 134 229
nameGet 0 134 229
assign 1 134 230
new 0 134 230
assign 1 134 231
notEquals 1 134 231
assign 1 134 233
undef 1 134 238
assign 1 0 239
assign 1 0 242
assign 1 0 246
assign 1 134 249
heldGet 0 134 249
assign 1 134 250
isDeclaredGet 0 134 250
assign 1 134 251
not 0 134 251
assign 1 0 253
assign 1 0 256
assign 1 0 260
assign 1 135 263
new 0 135 263
assign 1 135 264
heldGet 0 135 264
assign 1 135 265
nameGet 0 135 265
assign 1 135 266
add 1 135 266
assign 1 135 267
new 0 135 267
assign 1 135 268
add 1 135 268
assign 1 135 269
heldGet 0 135 269
assign 1 135 270
namepathGet 0 135 270
assign 1 135 271
toString 0 135 271
assign 1 135 272
add 1 135 272
assign 1 135 273
new 2 135 273
throw 1 135 274
assign 1 140 281
ptyListGet 0 140 281
assign 1 140 282
iteratorGet 0 140 282
assign 1 140 285
hasNextGet 0 140 285
assign 1 141 287
nextGet 0 141 287
assign 1 142 288
memSynGet 0 142 288
assign 1 142 289
isTypedGet 0 142 289
assign 1 143 291
heldGet 0 143 291
assign 1 143 292
memSynGet 0 143 292
assign 1 143 293
namepathGet 0 143 293
addUsed 1 143 294
assign 1 147 301
heldGet 0 147 301
assign 1 147 302
orderedMethodsGet 0 147 302
assign 1 147 303
iteratorGet 0 147 303
assign 1 147 306
hasNextGet 0 147 306
assign 1 148 308
nextGet 0 148 308
assign 1 149 309
mtdMapGet 0 149 309
assign 1 149 310
heldGet 0 149 310
assign 1 149 311
nameGet 0 149 311
assign 1 149 312
get 1 149 312
assign 1 150 313
def 1 150 318
assign 1 151 319
rsynGet 0 151 319
assign 1 151 320
def 1 151 325
assign 1 152 326
heldGet 0 152 326
assign 1 152 327
rtypeGet 0 152 327
assign 1 152 328
undef 1 152 333
assign 1 153 334
new 0 153 334
assign 1 153 335
heldGet 0 153 335
assign 1 153 336
nameGet 0 153 336
assign 1 153 337
add 1 153 337
assign 1 153 338
new 0 153 338
assign 1 153 339
add 1 153 339
assign 1 153 340
heldGet 0 153 340
assign 1 153 341
nameGet 0 153 341
assign 1 153 342
add 1 153 342
assign 1 153 343
new 2 153 343
throw 1 153 344
loadClass 1 158 353
assign 1 159 354
depthGet 0 159 354
assign 1 159 355
new 0 159 355
assign 1 159 356
add 1 159 356
assign 1 163 361
has 1 163 361
return 1 163 362
return 1 167 430
assign 1 168 432
new 0 168 432
assign 1 169 433
new 0 169 433
assign 1 170 434
new 0 170 434
assign 1 171 435
new 0 171 435
assign 1 172 436
undef 1 172 441
assign 1 173 442
new 0 173 442
assign 1 174 443
sizeGet 0 174 443
assign 1 175 444
sizeGet 0 175 444
assign 1 176 445
assign 1 177 446
iteratorGet 0 0 446
assign 1 177 449
hasNextGet 0 177 449
assign 1 177 451
nextGet 0 177 451
assign 1 178 452
emitDataGet 0 178 452
assign 1 178 453
methodIndexesGet 0 178 453
assign 1 178 454
new 2 178 454
put 1 178 455
return 1 180 461
assign 1 182 463
getSynNp 1 182 463
assign 1 183 464
new 0 183 464
assign 1 184 465
new 0 184 465
assign 1 186 466
sizeGet 0 186 466
assign 1 186 467
ptyListGet 0 186 467
assign 1 186 468
sizeGet 0 186 468
assign 1 186 469
subtract 1 186 469
assign 1 187 470
libNameGet 0 187 470
assign 1 187 471
equals 1 187 471
integrate 1 187 473
assign 1 188 475
isFinalGet 0 188 475
assign 1 189 477
new 0 189 477
assign 1 189 478
toString 0 189 478
assign 1 189 479
add 1 189 479
assign 1 189 480
new 1 189 480
throw 1 189 481
assign 1 191 483
isLocalGet 0 191 483
assign 1 191 485
libNameGet 0 191 485
assign 1 191 486
notEquals 1 191 486
assign 1 0 488
assign 1 0 491
assign 1 0 495
assign 1 192 498
new 0 192 498
assign 1 192 499
toString 0 192 499
assign 1 192 500
add 1 192 500
assign 1 192 501
new 1 192 501
throw 1 192 502
assign 1 194 504
isLocalGet 0 194 504
assign 1 194 506
not 0 194 511
assign 1 0 512
assign 1 0 515
assign 1 0 519
assign 1 194 522
not 0 194 527
assign 1 0 528
assign 1 0 531
assign 1 0 535
assign 1 195 538
new 0 195 538
assign 1 195 539
toString 0 195 539
assign 1 195 540
add 1 195 540
assign 1 195 541
new 1 195 541
throw 1 195 542
assign 1 197 544
linkedListIteratorGet 0 0 544
assign 1 197 547
hasNextGet 0 197 547
assign 1 197 549
nextGet 0 197 549
assign 1 198 550
getSynNp 1 198 550
assign 1 199 551
closeLibrariesGet 0 199 551
assign 1 199 552
libNameGet 0 199 552
assign 1 199 553
has 1 199 553
assign 1 199 554
not 0 199 559
assign 1 199 560
toString 0 199 560
assign 1 199 561
new 0 199 561
assign 1 199 562
notEquals 1 199 562
assign 1 0 564
assign 1 0 567
assign 1 0 571
assign 1 201 574
new 0 201 574
assign 1 202 575
new 0 202 575
assign 1 204 577
closeLibrariesGet 0 204 577
assign 1 204 578
libNameGet 0 204 578
assign 1 204 579
has 1 204 579
assign 1 204 580
not 0 204 585
assign 1 205 586
new 0 205 586
assign 1 209 593
valueIteratorGet 0 209 593
assign 1 209 596
hasNextGet 0 209 596
assign 1 210 598
nextGet 0 210 598
assign 1 211 599
mtdMapGet 0 211 599
assign 1 211 600
nameGet 0 211 600
assign 1 211 601
get 1 211 601
assign 1 212 602
def 1 212 607
assign 1 213 608
notEquals 1 213 608
assign 1 214 610
new 0 214 610
lastDefSet 1 214 611
assign 1 215 612
new 0 215 612
isOverrideSet 1 215 613
assign 1 216 614
increment 0 216 614
assign 1 219 618
new 0 219 618
isOverrideSet 1 219 619
assign 1 220 620
increment 0 220 620
assign 1 221 621
increment 0 221 621
assign 1 222 622
emitDataGet 0 222 622
assign 1 222 623
methodIndexesGet 0 222 623
assign 1 222 624
new 2 222 624
put 1 222 625
return 1 229 726
assign 1 230 728
new 0 230 728
assign 1 231 729
undef 1 231 734
return 1 231 735
assign 1 232 737
getSynNp 1 232 737
assign 1 233 738
heldGet 0 233 738
assign 1 233 739
orderedVarsGet 0 233 739
assign 1 233 740
iteratorGet 0 233 740
assign 1 233 743
hasNextGet 0 233 743
assign 1 234 745
nextGet 0 234 745
assign 1 235 746
ptyMapGet 0 235 746
assign 1 235 747
heldGet 0 235 747
assign 1 235 748
nameGet 0 235 748
assign 1 235 749
get 1 235 749
assign 1 236 750
def 1 236 755
assign 1 237 756
heldGet 0 237 756
assign 1 237 757
isDeclaredGet 0 237 757
assign 1 238 759
new 0 238 759
assign 1 238 760
heldGet 0 238 760
assign 1 238 761
nameGet 0 238 761
assign 1 238 762
add 1 238 762
assign 1 238 763
new 0 238 763
assign 1 238 764
add 1 238 764
assign 1 238 765
heldGet 0 238 765
assign 1 238 766
namepathGet 0 238 766
assign 1 238 767
toString 0 238 767
assign 1 238 768
add 1 238 768
assign 1 238 769
new 1 238 769
throw 1 238 770
assign 1 240 773
heldGet 0 240 773
assign 1 240 774
memSynGet 0 240 774
assign 1 240 775
isTypedGet 0 240 775
isTypedSet 1 240 776
assign 1 241 777
heldGet 0 241 777
assign 1 241 778
memSynGet 0 241 778
assign 1 241 779
namepathGet 0 241 779
namepathSet 1 241 780
assign 1 245 788
heldGet 0 245 788
assign 1 245 789
orderedMethodsGet 0 245 789
assign 1 245 790
iteratorGet 0 245 790
assign 1 245 793
hasNextGet 0 245 793
assign 1 246 795
nextGet 0 246 795
assign 1 247 796
mtdMapGet 0 247 796
assign 1 247 797
heldGet 0 247 797
assign 1 247 798
nameGet 0 247 798
assign 1 247 799
get 1 247 799
assign 1 248 800
def 1 248 805
assign 1 249 806
isFinalGet 0 249 806
assign 1 250 808
new 0 250 808
assign 1 250 809
heldGet 0 250 809
assign 1 250 810
nameGet 0 250 810
assign 1 250 811
add 1 250 811
assign 1 250 812
new 0 250 812
assign 1 250 813
add 1 250 813
assign 1 250 814
heldGet 0 250 814
assign 1 250 815
namepathGet 0 250 815
assign 1 250 816
toString 0 250 816
assign 1 250 817
add 1 250 817
assign 1 250 818
new 2 250 818
throw 1 250 819
assign 1 252 821
containedGet 0 252 821
assign 1 252 822
firstGet 0 252 822
assign 1 252 823
containedGet 0 252 823
assign 1 253 824
new 0 253 824
assign 1 253 827
argSynsGet 0 253 827
assign 1 253 828
lengthGet 0 253 828
assign 1 253 829
lesser 1 253 829
assign 1 254 831
argSynsGet 0 254 831
assign 1 254 832
get 1 254 832
assign 1 255 833
get 1 255 833
assign 1 255 834
heldGet 0 255 834
checkTypes 5 257 835
assign 1 253 836
increment 0 253 836
assign 1 259 842
rsynGet 0 259 842
assign 1 260 843
heldGet 0 260 843
assign 1 260 844
rtypeGet 0 260 844
assign 1 261 845
undef 1 261 850
assign 1 0 851
assign 1 261 854
undef 1 261 859
assign 1 0 860
assign 1 0 863
assign 1 262 867
undef 1 262 872
assign 1 262 872
not 0 262 877
assign 1 0 878
assign 1 262 881
undef 1 262 886
assign 1 262 886
not 0 262 891
assign 1 0 892
assign 1 0 895
assign 1 267 899
new 0 267 899
assign 1 267 900
heldGet 0 267 900
assign 1 267 901
namepathGet 0 267 901
assign 1 267 902
toString 0 267 902
assign 1 267 903
add 1 267 903
assign 1 267 904
new 2 267 904
throw 1 267 905
assign 1 271 909
isThisGet 0 271 909
assign 1 271 911
isThisGet 0 271 911
assign 1 271 912
isThisGet 0 271 912
assign 1 271 913
notEquals 1 271 913
assign 1 0 915
assign 1 0 918
assign 1 0 922
assign 1 272 925
new 0 272 925
assign 1 272 926
heldGet 0 272 926
assign 1 272 927
namepathGet 0 272 927
assign 1 272 928
toString 0 272 928
assign 1 272 929
add 1 272 929
assign 1 272 930
new 2 272 930
throw 1 272 931
checkTypes 5 274 933
assign 1 281 969
isTypedGet 0 281 969
assign 1 281 970
isTypedGet 0 281 970
assign 1 281 971
notEquals 1 281 971
assign 1 282 973
new 0 282 973
assign 1 282 974
heldGet 0 282 974
assign 1 282 975
namepathGet 0 282 975
assign 1 282 976
toString 0 282 976
assign 1 282 977
add 1 282 977
assign 1 282 978
new 2 282 978
throw 1 282 979
assign 1 283 982
isTypedGet 0 283 982
assign 1 286 984
isSelfGet 0 286 984
assign 1 286 986
isSelfGet 0 286 986
assign 1 0 988
assign 1 0 991
assign 1 0 995
return 1 287 998
assign 1 289 1000
namepathGet 0 289 1000
assign 1 289 1001
getSynNp 1 289 1001
assign 1 290 1002
allTypesGet 0 290 1002
assign 1 290 1003
namepathGet 0 290 1003
assign 1 290 1004
has 1 290 1004
assign 1 290 1005
not 0 290 1005
assign 1 291 1007
new 0 291 1007
assign 1 291 1008
heldGet 0 291 1008
assign 1 291 1009
namepathGet 0 291 1009
assign 1 291 1010
toString 0 291 1010
assign 1 291 1011
add 1 291 1011
assign 1 291 1012
new 2 291 1012
throw 1 291 1013
new 0 297 1039
assign 1 298 1040
heldGet 0 298 1040
assign 1 298 1041
orderedVarsGet 0 298 1041
assign 1 298 1042
iteratorGet 0 298 1042
assign 1 298 1045
hasNextGet 0 298 1045
assign 1 299 1047
nextGet 0 299 1047
assign 1 300 1048
heldGet 0 300 1048
assign 1 300 1049
isDeclaredGet 0 300 1049
assign 1 300 1050
not 0 300 1050
assign 1 301 1052
new 0 301 1052
assign 1 301 1053
heldGet 0 301 1053
assign 1 301 1054
nameGet 0 301 1054
assign 1 301 1055
add 1 301 1055
assign 1 301 1056
new 0 301 1056
assign 1 301 1057
add 1 301 1057
assign 1 301 1058
heldGet 0 301 1058
assign 1 301 1059
namepathGet 0 301 1059
assign 1 301 1060
toString 0 301 1060
assign 1 301 1061
add 1 301 1061
assign 1 301 1062
new 2 301 1062
throw 1 301 1063
loadClass 1 304 1070
assign 1 305 1071
new 0 305 1071
assign 1 310 1099
heldGet 0 310 1099
assign 1 310 1100
fromFileGet 0 310 1100
assign 1 311 1101
heldGet 0 311 1101
assign 1 311 1102
namepathGet 0 311 1102
assign 1 312 1103
heldGet 0 312 1103
assign 1 312 1104
libNameGet 0 312 1104
assign 1 313 1105
heldGet 0 313 1105
assign 1 313 1106
isFinalGet 0 313 1106
assign 1 314 1107
heldGet 0 314 1107
assign 1 314 1108
isLocalGet 0 314 1108
assign 1 315 1109
heldGet 0 315 1109
assign 1 315 1110
isNotNullGet 0 315 1110
assign 1 316 1111
heldGet 0 316 1111
assign 1 316 1112
usedGet 0 316 1112
assign 1 316 1113
iteratorGet 0 316 1113
assign 1 316 1116
hasNextGet 0 316 1116
assign 1 317 1118
nextGet 0 317 1118
assign 1 318 1119
toString 0 318 1119
put 1 318 1120
assign 1 320 1126
heldGet 0 320 1126
assign 1 320 1127
orderedVarsGet 0 320 1127
assign 1 320 1128
iteratorGet 0 320 1128
assign 1 320 1131
hasNextGet 0 320 1131
assign 1 321 1133
nextGet 0 321 1133
assign 1 322 1134
new 2 322 1134
addValue 1 323 1135
assign 1 325 1141
heldGet 0 325 1141
assign 1 325 1142
orderedMethodsGet 0 325 1142
assign 1 325 1143
iteratorGet 0 325 1143
assign 1 325 1146
hasNextGet 0 325 1146
assign 1 326 1148
nextGet 0 326 1148
assign 1 327 1149
new 2 327 1149
addValue 1 328 1150
postLoad 0 330 1156
assign 1 334 1207
new 0 334 1207
assign 1 335 1208
new 0 335 1208
assign 1 338 1209
iteratorGet 0 338 1209
assign 1 338 1212
hasNextGet 0 338 1212
assign 1 339 1214
nextGet 0 339 1214
assign 1 340 1215
nameGet 0 340 1215
assign 1 340 1216
has 1 340 1216
assign 1 340 1217
not 0 340 1222
assign 1 342 1223
nameGet 0 342 1223
put 2 342 1224
assign 1 346 1231
new 0 346 1231
assign 1 347 1232
new 0 347 1232
assign 1 348 1233
iteratorGet 0 348 1233
assign 1 348 1236
hasNextGet 0 348 1236
assign 1 349 1238
nextGet 0 349 1238
assign 1 350 1239
nameGet 0 350 1239
assign 1 350 1240
has 1 350 1240
assign 1 350 1241
not 0 350 1246
assign 1 351 1247
nameGet 0 351 1247
assign 1 351 1248
get 1 351 1248
mposSet 1 352 1249
assign 1 353 1250
new 0 353 1250
assign 1 353 1251
add 1 353 1251
addValue 1 354 1252
assign 1 355 1253
nameGet 0 355 1253
assign 1 355 1254
nameGet 0 355 1254
put 2 355 1255
assign 1 358 1262
assign 1 360 1263
new 0 360 1263
assign 1 362 1264
iteratorGet 0 362 1264
assign 1 362 1267
hasNextGet 0 362 1267
assign 1 363 1269
nextGet 0 363 1269
assign 1 365 1270
nameGet 0 365 1270
put 2 365 1271
assign 1 367 1272
nameGet 0 367 1272
assign 1 367 1273
has 1 367 1273
assign 1 367 1274
not 0 367 1279
assign 1 368 1280
nameGet 0 368 1280
put 2 368 1281
assign 1 372 1288
new 0 372 1288
assign 1 373 1289
new 0 373 1289
assign 1 374 1290
iteratorGet 0 374 1290
assign 1 374 1293
hasNextGet 0 374 1293
assign 1 375 1295
nextGet 0 375 1295
assign 1 376 1296
nameGet 0 376 1296
assign 1 376 1297
has 1 376 1297
assign 1 376 1298
not 0 376 1303
assign 1 377 1304
nameGet 0 377 1304
assign 1 377 1305
get 1 377 1305
assign 1 386 1306
nameGet 0 386 1306
assign 1 386 1307
get 1 386 1307
assign 1 387 1308
declarationGet 0 387 1308
assign 1 387 1309
undef 1 387 1314
assign 1 388 1315
originGet 0 388 1315
declarationSet 1 388 1316
assign 1 390 1318
declarationGet 0 390 1318
declarationSet 1 390 1319
mtdxSet 1 391 1320
assign 1 392 1321
increment 0 392 1321
addValue 1 393 1322
assign 1 394 1323
nameGet 0 394 1323
assign 1 394 1324
nameGet 0 394 1324
put 2 394 1325
assign 1 397 1332
assign 1 399 1333
linkedListIteratorGet 0 0 1333
assign 1 399 1336
hasNextGet 0 399 1336
assign 1 399 1338
nextGet 0 399 1338
put 2 400 1339
assign 1 401 1340
put 2 404 1346
return 1 0 1350
return 1 0 1353
assign 1 0 1356
assign 1 0 1360
return 1 0 1364
return 1 0 1367
assign 1 0 1370
assign 1 0 1374
return 1 0 1378
return 1 0 1381
assign 1 0 1384
assign 1 0 1388
return 1 0 1392
return 1 0 1395
assign 1 0 1398
assign 1 0 1402
return 1 0 1406
return 1 0 1409
assign 1 0 1412
assign 1 0 1416
return 1 0 1420
return 1 0 1423
assign 1 0 1426
assign 1 0 1430
return 1 0 1434
return 1 0 1437
assign 1 0 1440
assign 1 0 1444
return 1 0 1448
return 1 0 1451
assign 1 0 1454
assign 1 0 1458
return 1 0 1462
return 1 0 1465
assign 1 0 1468
assign 1 0 1472
return 1 0 1476
return 1 0 1479
assign 1 0 1482
assign 1 0 1486
return 1 0 1490
return 1 0 1493
assign 1 0 1496
assign 1 0 1500
return 1 0 1504
return 1 0 1507
assign 1 0 1510
assign 1 0 1514
return 1 0 1518
return 1 0 1521
assign 1 0 1524
assign 1 0 1528
return 1 0 1532
return 1 0 1535
assign 1 0 1538
assign 1 0 1542
return 1 0 1546
return 1 0 1549
assign 1 0 1552
assign 1 0 1556
return 1 0 1560
return 1 0 1563
assign 1 0 1566
assign 1 0 1570
return 1 0 1574
return 1 0 1577
assign 1 0 1580
assign 1 0 1584
return 1 0 1588
return 1 0 1591
assign 1 0 1594
assign 1 0 1598
return 1 0 1602
return 1 0 1605
assign 1 0 1608
assign 1 0 1612
return 1 0 1616
return 1 0 1619
assign 1 0 1622
assign 1 0 1626
return 1 0 1630
return 1 0 1633
assign 1 0 1636
assign 1 0 1640
return 1 0 1644
return 1 0 1647
assign 1 0 1650
assign 1 0 1654
return 1 0 1658
return 1 0 1661
assign 1 0 1664
assign 1 0 1668
return 1 0 1672
return 1 0 1675
assign 1 0 1678
assign 1 0 1682
return 1 0 1686
return 1 0 1689
assign 1 0 1692
assign 1 0 1696
return 1 0 1700
return 1 0 1703
assign 1 0 1706
assign 1 0 1710
return 1 0 1714
return 1 0 1717
assign 1 0 1720
assign 1 0 1724
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 958706830: return bem_ptyMapGetDirect_0();
case 494090088: return bem_isFinalGetDirect_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -1944361733: return bem_depthGet_0();
case 432467742: return bem_mtdMapGet_0();
case 1755281620: return bem_fromFileGet_0();
case -343928073: return bem_isLocalGetDirect_0();
case -702532128: return bem_signatureChangedGetDirect_0();
case -1363819567: return bem_new_0();
case 1136580693: return bem_superListGet_0();
case 2091984602: return bem_defMtdsGetDirect_0();
case -321491131: return bem_namepathGetDirect_0();
case -1779151053: return bem_usesGet_0();
case 1597327951: return bem_create_0();
case 713676617: return bem_directMethodsGet_0();
case 312180878: return bem_directPropertiesGetDirect_0();
case -1188922735: return bem_echo_0();
case -957382648: return bem_postLoad_0();
case -447432319: return bem_many_0();
case 744222090: return bem_maxMtdxGet_0();
case -1760538533: return bem_classNameGet_0();
case -1287942591: return bem_libNameGetDirect_0();
case 680351779: return bem_integratedGet_0();
case 66042208: return bem_integratedGetDirect_0();
case 1195347477: return bem_signatureCheckedGetDirect_0();
case 371157924: return bem_sourceFileNameGet_0();
case -1146471584: return bem_allNamesGetDirect_0();
case 932983062: return bem_iCheckedGet_0();
case -793241295: return bem_iteratorGet_0();
case -1744100192: return bem_fromFileGetDirect_0();
case -1323898541: return bem_toAny_0();
case 380791418: return bem_superListGetDirect_0();
case 1890854002: return bem_tagGet_0();
case -2142308197: return bem_mtdMapGetDirect_0();
case 7254011: return bem_fieldIteratorGet_0();
case -178884661: return bem_superNpGet_0();
case -225649058: return bem_isLocalGet_0();
case -1532808570: return bem_ptyMapGet_0();
case -1337913031: return bem_directMethodsGetDirect_0();
case 746644508: return bem_ptyListGet_0();
case -948480259: return bem_ptyListGetDirect_0();
case -921473949: return bem_fieldNamesGet_0();
case -1568522677: return bem_allNamesGet_0();
case 895193825: return bem_once_0();
case -2100534928: return bem_defMtdsGet_0();
case 963817456: return bem_allTypesGet_0();
case 1319388306: return bem_copy_0();
case 292045901: return bem_superNpGetDirect_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -1443143746: return bem_newMbrsGetDirect_0();
case 639505885: return bem_isNotNullGetDirect_0();
case -1841567201: return bem_mtdListGet_0();
case -1387831588: return bem_print_0();
case -1095264439: return bem_mtdListGetDirect_0();
case 185392836: return bem_foreignClassesGet_0();
case 81481270: return bem_usesGetDirect_0();
case 1092105192: return bem_hashGet_0();
case -467511392: return bem_toString_0();
case -105946774: return bem_serializeToString_0();
case -1454506129: return bem_signatureCheckedGet_0();
case 1842935824: return bem_hasDefaultGet_0();
case -103940610: return bem_isNotNullGet_0();
case -1955750286: return bem_newMtdsGetDirect_0();
case 1648357498: return bem_newMbrsGet_0();
case -1662902255: return bem_libNameGet_0();
case 925475645: return bem_depthGetDirect_0();
case 198290981: return bem_allTypesGetDirect_0();
case -2032459671: return bem_iCheckedGetDirect_0();
case 1394040921: return bem_isFinalGet_0();
case -163424773: return bem_directPropertiesGet_0();
case 1511787817: return bem_foreignClassesGetDirect_0();
case 132029466: return bem_newMtdsGet_0();
case -1814667931: return bem_allAncestorsCloseGet_0();
case 782632493: return bem_namepathGet_0();
case 1652521523: return bem_serializeContents_0();
case -1276070215: return bem_allAncestorsCloseGetDirect_0();
case 718873506: return bem_signatureChangedGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1223126793: return bem_usesSetDirect_1(bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case 596499496: return bem_signatureChangedSetDirect_1(bevd_0);
case 1854794541: return bem_newMbrsSetDirect_1(bevd_0);
case -957123886: return bem_superNpSetDirect_1(bevd_0);
case 1929898803: return bem_new_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 1248135247: return bem_newMtdsSetDirect_1(bevd_0);
case -237253722: return bem_directPropertiesSetDirect_1(bevd_0);
case -1732350048: return bem_ptyMapSetDirect_1(bevd_0);
case -1275168123: return bem_superListSetDirect_1(bevd_0);
case -1943628419: return bem_iCheckedSet_1(bevd_0);
case -488376716: return bem_defMtdsSetDirect_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case 1913806233: return bem_libNameSetDirect_1(bevd_0);
case -148499109: return bem_isFinalSet_1(bevd_0);
case -745708969: return bem_allTypesSet_1(bevd_0);
case 566985386: return bem_mtdListSetDirect_1(bevd_0);
case 1204522922: return bem_usesSet_1(bevd_0);
case -285839021: return bem_newMtdsSet_1(bevd_0);
case 902351022: return bem_directMethodsSetDirect_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case -289854130: return bem_allNamesSetDirect_1(bevd_0);
case -1912762557: return bem_mtdMapSetDirect_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case -1532372198: return bem_directMethodsSet_1(bevd_0);
case 1968077034: return bem_isFinalSetDirect_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case 1296646135: return bem_signatureCheckedSetDirect_1(bevd_0);
case 1457240339: return bem_allTypesSetDirect_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -1794855469: return bem_libNameSet_1(bevd_0);
case 1063664945: return bem_signatureCheckedSet_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case 651677514: return bem_directPropertiesSet_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 556253518: return bem_namepathSet_1(bevd_0);
case 2084641116: return bem_mtdListSet_1(bevd_0);
case 753702493: return bem_ptyListSetDirect_1(bevd_0);
case -1651563624: return bem_isLocalSet_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1087284894: return bem_defMtdsSet_1(bevd_0);
case 526846115: return bem_fromFileSet_1(bevd_0);
case 221744300: return bem_fromFileSetDirect_1(bevd_0);
case -2038121135: return bem_castsTo_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1578255053: return bem_depthSetDirect_1(bevd_0);
case 2124858339: return bem_loadClass_1(bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -850008318: return bem_mtdMapSet_1(bevd_0);
case 532709917: return bem_isNotNullSetDirect_1(bevd_0);
case 1741237042: return bem_depthSet_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1126239543: return bem_superNpSet_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1888251471: return bem_integratedSet_1(bevd_0);
case -1141677164: return bem_allNamesSet_1(bevd_0);
case -244405125: return bem_namepathSetDirect_1(bevd_0);
case 1818474885: return bem_iCheckedSetDirect_1(bevd_0);
case -1117341597: return bem_allAncestorsCloseSetDirect_1(bevd_0);
case -592478110: return bem_signatureChangedSet_1(bevd_0);
case -2069881250: return bem_superListSet_1(bevd_0);
case -1342109095: return bem_newMbrsSet_1(bevd_0);
case 1129761729: return bem_integratedSetDirect_1(bevd_0);
case 1164475335: return bem_foreignClassesSet_1(bevd_0);
case -182283986: return bem_ptyMapSet_1(bevd_0);
case 1453155809: return bem_foreignClassesSetDirect_1(bevd_0);
case 2062208226: return bem_isNotNullSet_1(bevd_0);
case -512332773: return bem_ptyListSet_1(bevd_0);
case -1724020981: return bem_allAncestorsCloseSet_1(bevd_0);
case 1863675641: return bem_integrate_1((BEC_2_5_5_BuildBuild) bevd_0);
case 1622774011: return bem_isLocalSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1973904590: return bem_new_2(bevd_0, bevd_1);
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -526631604: return bem_checkInheritance_2(bevd_0, bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 586641063: return bem_checkTypes_5(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_5_8_BuildClassSyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_8_BuildClassSyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_8_BuildClassSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_inst = (BEC_2_5_8_BuildClassSyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_8_BuildClassSyn.bece_BEC_2_5_8_BuildClassSyn_bevs_type;
}
}
}
