namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_11_XmlTagIterator : BEC_2_6_6_SystemObject {
public BEC_2_3_11_XmlTagIterator() { }
static BEC_2_3_11_XmlTagIterator() { }
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_3_11_XmlTagIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_1 = {0x3E};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_2 = {0x2D,0x2D};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_3 = {0x20};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_4 = {0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_5 = {0x3C,0x3F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_6 = {0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_7 = {0x3C,0x21};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_8 = {0x2F};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_9 = {0x3D};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_10 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x74,0x74,0x72,0x69,0x62,0x75,0x74,0x65,0x65,0x74,0x65,0x72,0x20,0x64,0x65,0x66,0x20,0x61,0x74,0x20,0x6C,0x69,0x6E,0x65,0x20};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_11 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_12 = {0x4D,0x61,0x6C,0x66,0x6F,0x72,0x6D,0x65,0x64,0x20,0x58,0x6D,0x6C,0x2C,0x20,0x74,0x61,0x67,0x20,0x64,0x6F,0x65,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x3A};
private static byte[] bece_BEC_2_3_11_XmlTagIterator_bels_13 = {0x3A};
public static new BEC_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_inst;

public static new BET_2_3_11_XmlTagIterator bece_BEC_2_3_11_XmlTagIterator_bevs_type;

public BEC_2_4_6_TextString bevp_xmlString;
public BEC_2_5_4_LogicBool bevp_started;
public BEC_2_3_10_XmlXTokenizer bevp_xt;
public BEC_2_9_10_ContainerLinkedList bevp_res;
public BEC_2_6_6_SystemObject bevp_iter;
public BEC_2_5_4_LogicBool bevp_textNode;
public BEC_2_4_3_MathInt bevp_line;
public BEC_2_5_4_LogicBool bevp_skip;
public BEC_2_5_4_LogicBool bevp_debug;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_started = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_xt = (BEC_2_3_10_XmlXTokenizer) BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
bevp_res = null;
bevp_iter = null;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_debug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_stringNew_1(BEC_2_4_6_TextString beva__xmlString) {
bem_new_0();
bevp_xmlString = beva__xmlString;
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_restart_0() {
bem_new_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_start_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_4_9_TextTokenizer bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevt_2_ta_ph = bevp_xt.bem_tokGet_0();
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_2_ta_ph.bem_tokenize_1(bevp_xmlString);
bevp_iter = bevp_res.bem_iteratorGet_0();
bevp_started = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
while (true)
/* Line: 167*/ {
if (bevl_nxt == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_4_ta_ph = bevl_nxt.bem_notEquals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 167*/
 else /* Line: 167*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 167*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 168*/
 else /* Line: 167*/ {
break;
} /* Line: 167*/
} /* Line: 167*/
if (bevl_nxt == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_7_ta_ph = bevl_nxt.bem_equals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 170*/
 else /* Line: 170*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 170*/ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 171*/
return this;
} /*method end*/
public virtual BEC_2_3_3_XmlTag bem_nextGet_0() {
BEC_2_4_6_TextString bevl_nxt = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_4_6_TextString bevl_nl = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_5_4_LogicBool bevl_tagName = null;
BEC_2_5_4_LogicBool bevl_attributeName = null;
BEC_2_5_4_LogicBool bevl_attributeValue = null;
BEC_2_5_4_LogicBool bevl_pinstruct = null;
BEC_2_5_4_LogicBool bevl_comment = null;
BEC_2_5_4_LogicBool bevl_isStart = null;
BEC_2_5_4_LogicBool bevl_instr = null;
BEC_2_3_12_XmlStartElement bevl_myElement = null;
BEC_2_3_3_XmlTag bevl_myTag = null;
BEC_2_3_10_XmlEndElement bevl_myEndElement = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_12_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_13_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_14_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_15_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_16_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_17_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_18_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_19_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_4_7_TextStrings bevt_21_ta_ph = null;
BEC_2_4_7_TextStrings bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_3_8_XmlTextNode bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_5_4_LogicBool bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_3_21_XmlProcessingInstruction bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_5_4_LogicBool bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_5_4_LogicBool bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_3_7_XmlComment bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_5_4_LogicBool bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_5_4_LogicBool bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_5_4_LogicBool bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_5_4_LogicBool bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_5_4_LogicBool bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_5_4_LogicBool bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_5_4_LogicBool bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_5_4_LogicBool bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_5_4_LogicBool bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_5_4_LogicBool bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_5_4_LogicBool bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_5_4_LogicBool bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_5_4_LogicBool bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_5_4_LogicBool bevt_116_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_117_ta_ph = null;
BEC_2_4_6_TextString bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_5_4_LogicBool bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_5_4_LogicBool bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_5_4_LogicBool bevt_126_ta_ph = null;
BEC_2_4_6_TextString bevt_127_ta_ph = null;
BEC_2_5_4_LogicBool bevt_128_ta_ph = null;
BEC_2_5_4_LogicBool bevt_129_ta_ph = null;
BEC_2_5_4_LogicBool bevt_130_ta_ph = null;
BEC_2_4_6_TextString bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_3_20_XmlTagIteratorException bevt_133_ta_ph = null;
BEC_2_4_6_TextString bevt_134_ta_ph = null;
BEC_2_4_6_TextString bevt_135_ta_ph = null;
BEC_2_4_6_TextString bevt_136_ta_ph = null;
BEC_2_4_6_TextString bevt_137_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_20_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_20_ta_ph.bevi_bool)/* Line: 176*/ {
bem_start_0();
} /* Line: 177*/
bevt_21_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_21_ta_ph.bem_quoteGet_0();
bevt_22_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_22_ta_ph.bem_newlineGet_0();
if (bevp_skip.bevi_bool)/* Line: 182*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(-1605246562);
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 184*/
 else /* Line: 185*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 186*/
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
if (bevl_nxt == null) {
bevt_23_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_23_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_23_ta_ph.bevi_bool)/* Line: 189*/ {
if (bevp_textNode.bevi_bool)/* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 189*/
 else /* Line: 189*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 189*/ {
while (true)
/* Line: 190*/ {
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_24_ta_ph = bevl_nxt.bem_notEquals_1(bevt_25_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 190*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 192*/
 else /* Line: 190*/ {
break;
} /* Line: 190*/
} /* Line: 190*/
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_27_ta_ph = bevl_accum.bem_extractString_0();
bevt_26_ta_ph = (BEC_2_3_8_XmlTextNode) (new BEC_2_3_8_XmlTextNode()).bem_new_1(bevt_27_ta_ph);
return bevt_26_ta_ph;
} /* Line: 196*/
 else /* Line: 189*/ {
if (bevl_nxt == null) {
bevt_28_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_28_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_29_ta_ph = bevl_nxt.bem_equals_1(bevt_30_ta_ph);
if (bevt_29_ta_ph.bevi_bool)/* Line: 198*/ {
bevl_tagName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
while (true)
/* Line: 205*/ {
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_31_ta_ph = bevl_nxt.bem_notEquals_1(bevt_32_ta_ph);
if (bevt_31_ta_ph.bevi_bool)/* Line: 205*/ {
if (bevl_pinstruct.bevi_bool)/* Line: 206*/ {
bevl_instr = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
/* Line: 208*/ {
if (bevl_instr.bevi_bool)/* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 208*/ {
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_33_ta_ph = bevl_nxt.bem_notEquals_1(bevt_34_ta_ph);
if (bevt_33_ta_ph.bevi_bool)/* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 208*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 208*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 208*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevt_35_ta_ph = bevl_nxt.bem_equals_1(bevl_q);
if (bevt_35_ta_ph.bevi_bool)/* Line: 210*/ {
if (bevl_instr.bevi_bool) {
bevl_instr = be.BECS_Runtime.boolFalse;
 } else { 
bevl_instr = be.BECS_Runtime.boolTrue;
}
} /* Line: 211*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 213*/
 else /* Line: 208*/ {
break;
} /* Line: 208*/
} /* Line: 208*/
bevt_36_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_36_ta_ph);
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
/* Line: 217*/ {
if (bevl_nxt == null) {
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_38_ta_ph = bevl_nxt.bem_notEquals_1(bevt_39_ta_ph);
if (bevt_38_ta_ph.bevi_bool)/* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 217*/
 else /* Line: 217*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 217*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 218*/
 else /* Line: 217*/ {
break;
} /* Line: 217*/
} /* Line: 217*/
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_41_ta_ph = bevl_accum.bem_toString_0();
bevt_40_ta_ph = (BEC_2_3_21_XmlProcessingInstruction) (new BEC_2_3_21_XmlProcessingInstruction()).bem_new_1(bevt_41_ta_ph);
return bevt_40_ta_ph;
} /* Line: 221*/
if (bevl_comment.bevi_bool)/* Line: 223*/ {
while (true)
/* Line: 224*/ {
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_42_ta_ph = bevl_nxt.bem_notEquals_1(bevt_43_ta_ph);
if (bevt_42_ta_ph.bevi_bool)/* Line: 224*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_44_ta_ph = bevl_nxt.bem_equals_1(bevt_45_ta_ph);
if (bevt_44_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_48_ta_ph = bevl_accum.bem_toString_0();
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_2));
bevt_47_ta_ph = bevt_48_ta_ph.bem_ends_1(bevt_49_ta_ph);
if (bevt_47_ta_ph.bevi_bool) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 227*/
 else /* Line: 227*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 227*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 229*/
} /* Line: 227*/
 else /* Line: 224*/ {
break;
} /* Line: 224*/
} /* Line: 224*/
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
while (true)
/* Line: 233*/ {
if (bevl_nxt == null) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_51_ta_ph = bevl_nxt.bem_notEquals_1(bevt_52_ta_ph);
if (bevt_51_ta_ph.bevi_bool)/* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 233*/
 else /* Line: 233*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 233*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 234*/
 else /* Line: 233*/ {
break;
} /* Line: 233*/
} /* Line: 233*/
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevl_accum.bem_addValue_1(bevt_53_ta_ph);
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_55_ta_ph = bevl_accum.bem_extractString_0();
bevt_54_ta_ph = (BEC_2_3_7_XmlComment) (new BEC_2_3_7_XmlComment()).bem_new_1(bevt_55_ta_ph);
return bevt_54_ta_ph;
} /* Line: 238*/
if (bevl_tagName.bevi_bool)/* Line: 240*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
while (true)
/* Line: 242*/ {
bevt_57_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_56_ta_ph = bevl_nxt.bem_equals_1(bevt_57_ta_ph);
if (bevt_56_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_58_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_58_ta_ph.bevi_bool)/* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 242*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 242*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 242*/ {
bevt_59_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_59_ta_ph.bevi_bool)/* Line: 243*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 243*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 244*/
 else /* Line: 242*/ {
break;
} /* Line: 242*/
} /* Line: 242*/
bevt_61_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_4));
bevt_60_ta_ph = bevl_nxt.bem_equals_1(bevt_61_ta_ph);
if (bevt_60_ta_ph.bevi_bool)/* Line: 246*/ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_pinstruct = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
bevl_accum.bem_extractString_0();
bevt_62_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_5));
bevl_accum.bem_addValue_1(bevt_62_ta_ph);
} /* Line: 251*/
 else /* Line: 246*/ {
bevt_64_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_6));
bevt_63_ta_ph = bevl_nxt.bem_equals_1(bevt_64_ta_ph);
if (bevt_63_ta_ph.bevi_bool)/* Line: 252*/ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_comment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
bevl_accum.bem_extractString_0();
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_11_XmlTagIterator_bels_7));
bevl_accum.bem_addValue_1(bevt_65_ta_ph);
} /* Line: 257*/
 else /* Line: 258*/ {
bevt_67_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_66_ta_ph = bevl_nxt.bem_equals_1(bevt_67_ta_ph);
if (bevt_66_ta_ph.bevi_bool)/* Line: 259*/ {
bevl_isStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 261*/
while (true)
/* Line: 263*/ {
bevt_69_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_68_ta_ph = bevl_nxt.bem_notEquals_1(bevt_69_ta_ph);
if (bevt_68_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_70_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_70_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 263*/ {
bevt_72_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_71_ta_ph = bevl_nxt.bem_notEquals_1(bevt_72_ta_ph);
if (bevt_71_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 263*/ {
bevt_74_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_73_ta_ph = bevl_nxt.bem_notEquals_1(bevt_74_ta_ph);
if (bevt_73_ta_ph.bevi_bool)/* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 263*/
 else /* Line: 263*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 263*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 265*/
 else /* Line: 263*/ {
break;
} /* Line: 263*/
} /* Line: 263*/
bevt_75_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_75_ta_ph.bevi_bool)/* Line: 267*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 267*/
bevl_tagName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 269*/ {
bevl_myElement = (BEC_2_3_12_XmlStartElement) (new BEC_2_3_12_XmlStartElement()).bem_new_0();
bevl_myTag = bevl_myElement;
bevt_76_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_nameSet_1(bevt_76_ta_ph);
} /* Line: 272*/
 else /* Line: 273*/ {
bevl_myEndElement = (BEC_2_3_10_XmlEndElement) (new BEC_2_3_10_XmlEndElement()).bem_new_0();
bevt_77_ta_ph = bevl_accum.bem_extractString_0();
bevl_myEndElement.bem_nameSet_1(bevt_77_ta_ph);
bevl_myTag = bevl_myEndElement;
} /* Line: 276*/
bevt_79_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_78_ta_ph = bevl_nxt.bem_equals_1(bevt_79_ta_ph);
if (bevt_78_ta_ph.bevi_bool)/* Line: 278*/ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevl_isStart.bevi_bool)/* Line: 280*/ {
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 281*/
} /* Line: 280*/
 else /* Line: 278*/ {
bevt_81_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_80_ta_ph = bevl_nxt.bem_equals_1(bevt_81_ta_ph);
if (bevt_80_ta_ph.bevi_bool)/* Line: 283*/ {
if (bevl_isStart.bevi_bool)/* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 283*/
 else /* Line: 283*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 283*/ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_82_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_82_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 286*/
 else /* Line: 278*/ {
if (bevl_isStart.bevi_bool)/* Line: 287*/ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 288*/
 else /* Line: 289*/ {
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 290*/
} /* Line: 278*/
} /* Line: 278*/
} /* Line: 278*/
} /* Line: 246*/
} /* Line: 246*/
if (bevl_attributeName.bevi_bool)/* Line: 294*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
while (true)
/* Line: 296*/ {
bevt_84_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_83_ta_ph = bevl_nxt.bem_equals_1(bevt_84_ta_ph);
if (bevt_83_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_85_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_85_ta_ph.bevi_bool)/* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 296*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 296*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 296*/ {
bevt_86_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_86_ta_ph.bevi_bool)/* Line: 297*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 297*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 298*/
 else /* Line: 296*/ {
break;
} /* Line: 296*/
} /* Line: 296*/
while (true)
/* Line: 300*/ {
bevt_88_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_87_ta_ph = bevl_nxt.bem_notEquals_1(bevt_88_ta_ph);
if (bevt_87_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_89_ta_ph = bevl_nxt.bem_notEquals_1(bevl_nl);
if (bevt_89_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_14_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_14_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_91_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_90_ta_ph = bevl_nxt.bem_notEquals_1(bevt_91_ta_ph);
if (bevt_90_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_13_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_13_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_93_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_92_ta_ph = bevl_nxt.bem_notEquals_1(bevt_93_ta_ph);
if (bevt_92_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_12_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_12_ta_anchor.bevi_bool)/* Line: 300*/ {
bevt_95_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_9));
bevt_94_ta_ph = bevl_nxt.bem_notEquals_1(bevt_95_ta_ph);
if (bevt_94_ta_ph.bevi_bool)/* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 300*/
 else /* Line: 300*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_11_ta_anchor.bevi_bool)/* Line: 300*/ {
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 302*/
 else /* Line: 300*/ {
break;
} /* Line: 300*/
} /* Line: 300*/
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_96_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_96_ta_ph.bevi_bool)/* Line: 305*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 305*/
bevt_98_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_1));
bevt_97_ta_ph = bevl_nxt.bem_equals_1(bevt_98_ta_ph);
if (bevt_97_ta_ph.bevi_bool)/* Line: 306*/ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_textNode = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 308*/
 else /* Line: 306*/ {
bevt_100_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_8));
bevt_99_ta_ph = bevl_nxt.bem_equals_1(bevt_100_ta_ph);
if (bevt_99_ta_ph.bevi_bool)/* Line: 309*/ {
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_101_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_myElement.bem_isClosedSet_1(bevt_101_ta_ph);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 312*/
 else /* Line: 313*/ {
bevt_102_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeName_1(bevt_102_ta_ph);
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 315*/
} /* Line: 306*/
} /* Line: 306*/
if (bevl_attributeValue.bevi_bool)/* Line: 318*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
while (true)
/* Line: 320*/ {
bevt_104_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_103_ta_ph = bevl_nxt.bem_equals_1(bevt_104_ta_ph);
if (bevt_103_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_105_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_105_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_16_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 320*/
if (bevt_16_ta_anchor.bevi_bool)/* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_107_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_9));
bevt_106_ta_ph = bevl_nxt.bem_equals_1(bevt_107_ta_ph);
if (bevt_106_ta_ph.bevi_bool)/* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 320*/ {
bevt_15_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 320*/
if (bevt_15_ta_anchor.bevi_bool)/* Line: 320*/ {
bevt_108_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_108_ta_ph.bevi_bool)/* Line: 322*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 322*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 323*/
 else /* Line: 320*/ {
break;
} /* Line: 320*/
} /* Line: 320*/
bevt_109_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_109_ta_ph.bevi_bool)/* Line: 325*/ {
bevt_112_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_2_3_11_XmlTagIterator_bels_10));
bevt_113_ta_ph = bevp_line.bem_toString_0();
bevt_111_ta_ph = bevt_112_ta_ph.bem_add_1(bevt_113_ta_ph);
bevt_110_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_111_ta_ph);
throw new be.BECS_ThrowBack(bevt_110_ta_ph);
} /* Line: 326*/
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
while (true)
/* Line: 329*/ {
bevt_114_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_114_ta_ph.bevi_bool)/* Line: 329*/ {
bevt_115_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_115_ta_ph.bevi_bool)/* Line: 330*/ {
bevp_line = bevp_line.bem_increment_0();
} /* Line: 330*/
bevl_accum.bem_addValue_1(bevl_nxt);
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 332*/
 else /* Line: 329*/ {
break;
} /* Line: 329*/
} /* Line: 329*/
bevt_116_ta_ph = bevl_nxt.bem_notEquals_1(bevl_q);
if (bevt_116_ta_ph.bevi_bool)/* Line: 334*/ {
bevt_119_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_2_3_11_XmlTagIterator_bels_10));
bevt_120_ta_ph = bevp_line.bem_toString_0();
bevt_118_ta_ph = bevt_119_ta_ph.bem_add_1(bevt_120_ta_ph);
bevt_117_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_118_ta_ph);
throw new be.BECS_ThrowBack(bevt_117_ta_ph);
} /* Line: 335*/
bevl_attributeValue = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_121_ta_ph = bevl_accum.bem_extractString_0();
bevl_myElement.bem_addAttributeValue_1(bevt_121_ta_ph);
bevl_attributeName = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 339*/
} /* Line: 318*/
 else /* Line: 205*/ {
break;
} /* Line: 205*/
} /* Line: 205*/
if (bevl_myEndElement == null) {
bevt_122_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_122_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
if (bevl_myElement == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_124_ta_ph = bevl_myElement.bem_isClosedGet_0();
if (bevt_124_ta_ph.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 342*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 342*/ {
bevt_17_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 342*/
if (bevt_17_ta_anchor.bevi_bool)/* Line: 342*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
while (true)
/* Line: 344*/ {
if (bevl_nxt == null) {
bevt_125_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_125_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_125_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_127_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_3));
bevt_126_ta_ph = bevl_nxt.bem_equals_1(bevt_127_ta_ph);
if (bevt_126_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_128_ta_ph = bevl_nxt.bem_equals_1(bevl_nl);
if (bevt_128_ta_ph.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 344*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 344*/
 else /* Line: 344*/ {
bevt_18_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_18_ta_anchor.bevi_bool)/* Line: 344*/ {
bevl_nxt = (BEC_2_4_6_TextString) bevp_iter.bemd_0(581391667);
} /* Line: 344*/
 else /* Line: 344*/ {
break;
} /* Line: 344*/
} /* Line: 344*/
if (bevl_nxt == null) {
bevt_129_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_129_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_129_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_131_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_0));
bevt_130_ta_ph = bevl_nxt.bem_equals_1(bevt_131_ta_ph);
if (bevt_130_ta_ph.bevi_bool)/* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 345*/
 else /* Line: 345*/ {
bevt_19_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_19_ta_anchor.bevi_bool)/* Line: 345*/ {
bevp_skip = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 345*/
} /* Line: 345*/
} /* Line: 342*/
 else /* Line: 347*/ {
if (bevl_nxt == null) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 348*/ {
bevl_nxt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_3_11_XmlTagIterator_bels_11));
} /* Line: 348*/
bevt_136_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_3_11_XmlTagIterator_bels_12));
bevt_135_ta_ph = bevt_136_ta_ph.bem_add_1(bevl_nxt);
bevt_137_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_11_XmlTagIterator_bels_13));
bevt_134_ta_ph = bevt_135_ta_ph.bem_add_1(bevt_137_ta_ph);
bevt_133_ta_ph = (BEC_2_3_20_XmlTagIteratorException) (new BEC_2_3_20_XmlTagIteratorException()).bem_new_1(bevt_134_ta_ph);
throw new be.BECS_ThrowBack(bevt_133_ta_ph);
} /* Line: 349*/
} /* Line: 198*/
} /* Line: 189*/
return bevl_myTag;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (bevp_started.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 356*/
bevt_2_ta_ph = bevp_iter.bemd_0(-211510432);
return (BEC_2_5_4_LogicBool) bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_xmlStringGet_0() {
return bevp_xmlString;
} /*method end*/
public BEC_2_4_6_TextString bem_xmlStringGetDirect_0() {
return bevp_xmlString;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_xmlStringSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xmlStringSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xmlString = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_startedGet_0() {
return bevp_started;
} /*method end*/
public BEC_2_5_4_LogicBool bem_startedGetDirect_0() {
return bevp_started;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_startedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_started = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_3_10_XmlXTokenizer bem_xtGet_0() {
return bevp_xt;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_xtGetDirect_0() {
return bevp_xt;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_xtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_xtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_xt = (BEC_2_3_10_XmlXTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_resGet_0() {
return bevp_res;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_resGetDirect_0() {
return bevp_res;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_resSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_resSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_res = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_iterGet_0() {
return bevp_iter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iterGetDirect_0() {
return bevp_iter;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_iterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_iter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_iterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_iter = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_textNodeGet_0() {
return bevp_textNode;
} /*method end*/
public BEC_2_5_4_LogicBool bem_textNodeGetDirect_0() {
return bevp_textNode;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_textNodeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_textNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_textNode = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lineGet_0() {
return bevp_line;
} /*method end*/
public BEC_2_4_3_MathInt bem_lineGetDirect_0() {
return bevp_line;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_lineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_lineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_line = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_skipGet_0() {
return bevp_skip;
} /*method end*/
public BEC_2_5_4_LogicBool bem_skipGetDirect_0() {
return bevp_skip;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_skipSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_skipSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_skip = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_debugGet_0() {
return bevp_debug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_debugGetDirect_0() {
return bevp_debug;
} /*method end*/
public virtual BEC_2_3_11_XmlTagIterator bem_debugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_11_XmlTagIterator bem_debugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_debug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {137, 138, 139, 140, 141, 142, 143, 144, 149, 150, 154, 158, 162, 162, 163, 164, 166, 167, 167, 167, 167, 0, 0, 0, 168, 170, 170, 170, 170, 0, 0, 0, 171, 176, 176, 177, 180, 180, 181, 181, 183, 184, 186, 188, 189, 189, 0, 0, 0, 190, 190, 191, 192, 194, 195, 196, 196, 196, 197, 197, 198, 198, 199, 200, 201, 202, 203, 204, 205, 205, 207, 0, 208, 208, 0, 0, 209, 210, 211, 211, 213, 215, 215, 216, 217, 217, 217, 217, 0, 0, 0, 218, 220, 221, 221, 221, 224, 224, 225, 226, 227, 227, 227, 227, 227, 227, 227, 0, 0, 0, 228, 229, 232, 233, 233, 233, 233, 0, 0, 0, 234, 236, 236, 237, 238, 238, 238, 241, 242, 242, 0, 242, 0, 0, 243, 243, 244, 246, 246, 247, 248, 249, 250, 251, 251, 252, 252, 253, 254, 255, 256, 257, 257, 259, 259, 260, 261, 263, 263, 263, 0, 0, 0, 263, 263, 0, 0, 0, 263, 263, 0, 0, 0, 264, 265, 267, 267, 268, 270, 271, 272, 272, 274, 275, 275, 276, 278, 278, 279, 281, 283, 283, 0, 0, 0, 284, 285, 285, 286, 288, 290, 295, 296, 296, 0, 296, 0, 0, 297, 297, 298, 300, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 300, 300, 0, 0, 0, 301, 302, 304, 305, 305, 306, 306, 307, 308, 309, 309, 310, 311, 311, 312, 314, 314, 315, 319, 320, 320, 0, 320, 0, 0, 0, 320, 320, 0, 0, 322, 322, 323, 325, 326, 326, 326, 326, 326, 328, 329, 330, 330, 331, 332, 334, 335, 335, 335, 335, 335, 337, 338, 338, 339, 342, 342, 0, 342, 342, 342, 0, 0, 0, 0, 0, 343, 344, 344, 344, 344, 0, 344, 0, 0, 0, 0, 0, 344, 345, 345, 345, 345, 0, 0, 0, 345, 348, 348, 348, 349, 349, 349, 349, 349, 349, 352, 356, 356, 356, 356, 357, 357, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {36, 37, 38, 39, 40, 41, 42, 43, 47, 48, 52, 56, 69, 70, 71, 72, 73, 76, 81, 82, 83, 85, 88, 92, 95, 101, 106, 107, 108, 110, 113, 117, 120, 277, 282, 283, 285, 286, 287, 288, 290, 291, 294, 296, 297, 302, 304, 307, 311, 316, 317, 319, 320, 326, 327, 328, 329, 330, 333, 338, 339, 340, 342, 343, 344, 345, 346, 347, 350, 351, 354, 358, 361, 362, 364, 367, 371, 372, 374, 379, 380, 386, 387, 388, 391, 396, 397, 398, 400, 403, 407, 410, 416, 417, 418, 419, 424, 425, 427, 428, 429, 430, 432, 433, 434, 435, 440, 441, 444, 448, 451, 452, 459, 462, 467, 468, 469, 471, 474, 478, 481, 487, 488, 489, 490, 491, 492, 495, 498, 499, 501, 504, 506, 509, 513, 515, 517, 523, 524, 526, 527, 528, 529, 530, 531, 534, 535, 537, 538, 539, 540, 541, 542, 545, 546, 548, 549, 553, 554, 556, 558, 561, 565, 568, 569, 571, 574, 578, 581, 582, 584, 587, 591, 594, 595, 601, 603, 605, 607, 608, 609, 610, 613, 614, 615, 616, 618, 619, 621, 623, 627, 628, 631, 634, 638, 641, 642, 643, 644, 648, 651, 659, 662, 663, 665, 668, 670, 673, 677, 679, 681, 689, 690, 692, 694, 697, 701, 704, 705, 707, 710, 714, 717, 718, 720, 723, 727, 730, 731, 733, 736, 740, 743, 744, 750, 751, 753, 755, 756, 758, 759, 762, 763, 765, 766, 767, 768, 771, 772, 773, 778, 781, 782, 784, 787, 789, 792, 796, 799, 800, 802, 805, 809, 811, 813, 819, 821, 822, 823, 824, 825, 827, 830, 832, 834, 836, 837, 843, 845, 846, 847, 848, 849, 851, 852, 853, 854, 861, 866, 867, 870, 875, 876, 878, 881, 885, 888, 891, 895, 898, 903, 904, 905, 907, 910, 912, 915, 919, 922, 926, 929, 935, 940, 941, 942, 944, 947, 951, 954, 959, 964, 965, 967, 968, 969, 970, 971, 972, 976, 982, 987, 988, 989, 991, 992, 995, 998, 1001, 1005, 1009, 1012, 1015, 1019, 1023, 1026, 1029, 1033, 1037, 1040, 1043, 1047, 1051, 1054, 1057, 1061, 1065, 1068, 1071, 1075, 1079, 1082, 1085, 1089, 1093, 1096, 1099, 1103, 1107, 1110, 1113, 1117};
/* BEGIN LINEINFO 
assign 1 137 36
new 0 137 36
assign 1 138 37
new 0 138 37
assign 1 139 38
assign 1 140 39
assign 1 141 40
new 0 141 40
assign 1 142 41
new 0 142 41
assign 1 143 42
new 0 143 42
assign 1 144 43
new 0 144 43
new 0 149 47
assign 1 150 48
new 0 154 52
return 1 158 56
assign 1 162 69
tokGet 0 162 69
assign 1 162 70
tokenize 1 162 70
assign 1 163 71
iteratorGet 0 163 71
assign 1 164 72
new 0 164 72
assign 1 166 73
nextGet 0 166 73
assign 1 167 76
def 1 167 81
assign 1 167 82
new 0 167 82
assign 1 167 83
notEquals 1 167 83
assign 1 0 85
assign 1 0 88
assign 1 0 92
assign 1 168 95
nextGet 0 168 95
assign 1 170 101
def 1 170 106
assign 1 170 107
new 0 170 107
assign 1 170 108
equals 1 170 108
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 171 120
new 0 171 120
assign 1 176 277
not 0 176 282
start 0 177 283
assign 1 180 285
new 0 180 285
assign 1 180 286
quoteGet 0 180 286
assign 1 181 287
new 0 181 287
assign 1 181 288
newlineGet 0 181 288
assign 1 183 290
currentGet 0 183 290
assign 1 184 291
new 0 184 291
assign 1 186 294
nextGet 0 186 294
assign 1 188 296
new 0 188 296
assign 1 189 297
def 1 189 302
assign 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 190 316
new 0 190 316
assign 1 190 317
notEquals 1 190 317
addValue 1 191 319
assign 1 192 320
nextGet 0 192 320
assign 1 194 326
new 0 194 326
assign 1 195 327
new 0 195 327
assign 1 196 328
extractString 0 196 328
assign 1 196 329
new 1 196 329
return 1 196 330
assign 1 197 333
def 1 197 338
assign 1 198 339
new 0 198 339
assign 1 198 340
equals 1 198 340
assign 1 199 342
new 0 199 342
assign 1 200 343
new 0 200 343
assign 1 201 344
new 0 201 344
assign 1 202 345
new 0 202 345
assign 1 203 346
new 0 203 346
assign 1 204 347
new 0 204 347
assign 1 205 350
new 0 205 350
assign 1 205 351
notEquals 1 205 351
assign 1 207 354
new 0 207 354
assign 1 0 358
assign 1 208 361
new 0 208 361
assign 1 208 362
notEquals 1 208 362
assign 1 0 364
assign 1 0 367
addValue 1 209 371
assign 1 210 372
equals 1 210 372
assign 1 211 374
not 0 211 379
assign 1 213 380
nextGet 0 213 380
assign 1 215 386
new 0 215 386
addValue 1 215 387
assign 1 216 388
new 0 216 388
assign 1 217 391
def 1 217 396
assign 1 217 397
new 0 217 397
assign 1 217 398
notEquals 1 217 398
assign 1 0 400
assign 1 0 403
assign 1 0 407
assign 1 218 410
nextGet 0 218 410
assign 1 220 416
new 0 220 416
assign 1 221 417
toString 0 221 417
assign 1 221 418
new 1 221 418
return 1 221 419
assign 1 224 424
new 0 224 424
assign 1 224 425
notEquals 1 224 425
addValue 1 225 427
assign 1 226 428
nextGet 0 226 428
assign 1 227 429
new 0 227 429
assign 1 227 430
equals 1 227 430
assign 1 227 432
toString 0 227 432
assign 1 227 433
new 0 227 433
assign 1 227 434
ends 1 227 434
assign 1 227 435
not 0 227 440
assign 1 0 441
assign 1 0 444
assign 1 0 448
addValue 1 228 451
assign 1 229 452
nextGet 0 229 452
assign 1 232 459
new 0 232 459
assign 1 233 462
def 1 233 467
assign 1 233 468
new 0 233 468
assign 1 233 469
notEquals 1 233 469
assign 1 0 471
assign 1 0 474
assign 1 0 478
assign 1 234 481
nextGet 0 234 481
assign 1 236 487
new 0 236 487
addValue 1 236 488
assign 1 237 489
new 0 237 489
assign 1 238 490
extractString 0 238 490
assign 1 238 491
new 1 238 491
return 1 238 492
assign 1 241 495
nextGet 0 241 495
assign 1 242 498
new 0 242 498
assign 1 242 499
equals 1 242 499
assign 1 0 501
assign 1 242 504
equals 1 242 504
assign 1 0 506
assign 1 0 509
assign 1 243 513
equals 1 243 513
assign 1 243 515
increment 0 243 515
assign 1 244 517
nextGet 0 244 517
assign 1 246 523
new 0 246 523
assign 1 246 524
equals 1 246 524
assign 1 247 526
new 0 247 526
assign 1 248 527
new 0 248 527
assign 1 249 528
nextGet 0 249 528
extractString 0 250 529
assign 1 251 530
new 0 251 530
addValue 1 251 531
assign 1 252 534
new 0 252 534
assign 1 252 535
equals 1 252 535
assign 1 253 537
new 0 253 537
assign 1 254 538
new 0 254 538
assign 1 255 539
nextGet 0 255 539
extractString 0 256 540
assign 1 257 541
new 0 257 541
addValue 1 257 542
assign 1 259 545
new 0 259 545
assign 1 259 546
equals 1 259 546
assign 1 260 548
new 0 260 548
assign 1 261 549
nextGet 0 261 549
assign 1 263 553
new 0 263 553
assign 1 263 554
notEquals 1 263 554
assign 1 263 556
notEquals 1 263 556
assign 1 0 558
assign 1 0 561
assign 1 0 565
assign 1 263 568
new 0 263 568
assign 1 263 569
notEquals 1 263 569
assign 1 0 571
assign 1 0 574
assign 1 0 578
assign 1 263 581
new 0 263 581
assign 1 263 582
notEquals 1 263 582
assign 1 0 584
assign 1 0 587
assign 1 0 591
addValue 1 264 594
assign 1 265 595
nextGet 0 265 595
assign 1 267 601
equals 1 267 601
assign 1 267 603
increment 0 267 603
assign 1 268 605
new 0 268 605
assign 1 270 607
new 0 270 607
assign 1 271 608
assign 1 272 609
extractString 0 272 609
nameSet 1 272 610
assign 1 274 613
new 0 274 613
assign 1 275 614
extractString 0 275 614
nameSet 1 275 615
assign 1 276 616
assign 1 278 618
new 0 278 618
assign 1 278 619
equals 1 278 619
assign 1 279 621
new 0 279 621
assign 1 281 623
new 0 281 623
assign 1 283 627
new 0 283 627
assign 1 283 628
equals 1 283 628
assign 1 0 631
assign 1 0 634
assign 1 0 638
assign 1 284 641
new 0 284 641
assign 1 285 642
new 0 285 642
isClosedSet 1 285 643
assign 1 286 644
nextGet 0 286 644
assign 1 288 648
new 0 288 648
assign 1 290 651
new 0 290 651
assign 1 295 659
nextGet 0 295 659
assign 1 296 662
new 0 296 662
assign 1 296 663
equals 1 296 663
assign 1 0 665
assign 1 296 668
equals 1 296 668
assign 1 0 670
assign 1 0 673
assign 1 297 677
equals 1 297 677
assign 1 297 679
increment 0 297 679
assign 1 298 681
nextGet 0 298 681
assign 1 300 689
new 0 300 689
assign 1 300 690
notEquals 1 300 690
assign 1 300 692
notEquals 1 300 692
assign 1 0 694
assign 1 0 697
assign 1 0 701
assign 1 300 704
new 0 300 704
assign 1 300 705
notEquals 1 300 705
assign 1 0 707
assign 1 0 710
assign 1 0 714
assign 1 300 717
new 0 300 717
assign 1 300 718
notEquals 1 300 718
assign 1 0 720
assign 1 0 723
assign 1 0 727
assign 1 300 730
new 0 300 730
assign 1 300 731
notEquals 1 300 731
assign 1 0 733
assign 1 0 736
assign 1 0 740
addValue 1 301 743
assign 1 302 744
nextGet 0 302 744
assign 1 304 750
new 0 304 750
assign 1 305 751
equals 1 305 751
assign 1 305 753
increment 0 305 753
assign 1 306 755
new 0 306 755
assign 1 306 756
equals 1 306 756
assign 1 307 758
new 0 307 758
assign 1 308 759
new 0 308 759
assign 1 309 762
new 0 309 762
assign 1 309 763
equals 1 309 763
assign 1 310 765
new 0 310 765
assign 1 311 766
new 0 311 766
isClosedSet 1 311 767
assign 1 312 768
nextGet 0 312 768
assign 1 314 771
extractString 0 314 771
addAttributeName 1 314 772
assign 1 315 773
new 0 315 773
assign 1 319 778
nextGet 0 319 778
assign 1 320 781
new 0 320 781
assign 1 320 782
equals 1 320 782
assign 1 0 784
assign 1 320 787
equals 1 320 787
assign 1 0 789
assign 1 0 792
assign 1 0 796
assign 1 320 799
new 0 320 799
assign 1 320 800
equals 1 320 800
assign 1 0 802
assign 1 0 805
assign 1 322 809
equals 1 322 809
assign 1 322 811
increment 0 322 811
assign 1 323 813
nextGet 0 323 813
assign 1 325 819
notEquals 1 325 819
assign 1 326 821
new 0 326 821
assign 1 326 822
toString 0 326 822
assign 1 326 823
add 1 326 823
assign 1 326 824
new 1 326 824
throw 1 326 825
assign 1 328 827
nextGet 0 328 827
assign 1 329 830
notEquals 1 329 830
assign 1 330 832
equals 1 330 832
assign 1 330 834
increment 0 330 834
addValue 1 331 836
assign 1 332 837
nextGet 0 332 837
assign 1 334 843
notEquals 1 334 843
assign 1 335 845
new 0 335 845
assign 1 335 846
toString 0 335 846
assign 1 335 847
add 1 335 847
assign 1 335 848
new 1 335 848
throw 1 335 849
assign 1 337 851
new 0 337 851
assign 1 338 852
extractString 0 338 852
addAttributeValue 1 338 853
assign 1 339 854
new 0 339 854
assign 1 342 861
def 1 342 866
assign 1 0 867
assign 1 342 870
def 1 342 875
assign 1 342 876
isClosedGet 0 342 876
assign 1 0 878
assign 1 0 881
assign 1 0 885
assign 1 0 888
assign 1 0 891
assign 1 343 895
nextGet 0 343 895
assign 1 344 898
def 1 344 903
assign 1 344 904
new 0 344 904
assign 1 344 905
equals 1 344 905
assign 1 0 907
assign 1 344 910
equals 1 344 910
assign 1 0 912
assign 1 0 915
assign 1 0 919
assign 1 0 922
assign 1 0 926
assign 1 344 929
nextGet 0 344 929
assign 1 345 935
def 1 345 940
assign 1 345 941
new 0 345 941
assign 1 345 942
equals 1 345 942
assign 1 0 944
assign 1 0 947
assign 1 0 951
assign 1 345 954
new 0 345 954
assign 1 348 959
undef 1 348 964
assign 1 348 965
new 0 348 965
assign 1 349 967
new 0 349 967
assign 1 349 968
add 1 349 968
assign 1 349 969
new 0 349 969
assign 1 349 970
add 1 349 970
assign 1 349 971
new 1 349 971
throw 1 349 972
return 1 352 976
assign 1 356 982
not 0 356 987
assign 1 356 988
new 0 356 988
return 1 356 989
assign 1 357 991
hasNextGet 0 357 991
return 1 357 992
return 1 0 995
return 1 0 998
assign 1 0 1001
assign 1 0 1005
return 1 0 1009
return 1 0 1012
assign 1 0 1015
assign 1 0 1019
return 1 0 1023
return 1 0 1026
assign 1 0 1029
assign 1 0 1033
return 1 0 1037
return 1 0 1040
assign 1 0 1043
assign 1 0 1047
return 1 0 1051
return 1 0 1054
assign 1 0 1057
assign 1 0 1061
return 1 0 1065
return 1 0 1068
assign 1 0 1071
assign 1 0 1075
return 1 0 1079
return 1 0 1082
assign 1 0 1085
assign 1 0 1089
return 1 0 1093
return 1 0 1096
assign 1 0 1099
assign 1 0 1103
return 1 0 1107
return 1 0 1110
assign 1 0 1113
assign 1 0 1117
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 581391667: return bem_nextGet_0();
case 362213735: return bem_iterGet_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case -1513883149: return bem_xtGetDirect_0();
case -175742742: return bem_xtGet_0();
case 1605474977: return bem_startedGet_0();
case -1485913223: return bem_xmlStringGet_0();
case -1076915155: return bem_serializeToString_0();
case -94616378: return bem_startedGetDirect_0();
case 1956178583: return bem_skipGet_0();
case 446504410: return bem_lineGetDirect_0();
case -77992915: return bem_debugGet_0();
case 1864801973: return bem_textNodeGetDirect_0();
case 1834246217: return bem_classNameGet_0();
case -539010678: return bem_debugGetDirect_0();
case -818366022: return bem_resGetDirect_0();
case 946360922: return bem_serializationIteratorGet_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case -921881964: return bem_textNodeGet_0();
case -1497298352: return bem_start_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case 2077250455: return bem_restart_0();
case -878526683: return bem_skipGetDirect_0();
case 2081363871: return bem_copy_0();
case -975498393: return bem_fieldNamesGet_0();
case -1287957486: return bem_iterGetDirect_0();
case -979668744: return bem_lineGet_0();
case -571961265: return bem_resGet_0();
case 954703233: return bem_create_0();
case -893093197: return bem_toString_0();
case 1140687300: return bem_xmlStringGetDirect_0();
case -40905183: return bem_echo_0();
case -211510432: return bem_hasNextGet_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 711649767: return bem_skipSet_1(bevd_0);
case -903769411: return bem_xmlStringSetDirect_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -1392302917: return bem_startedSet_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 252762159: return bem_iterSet_1(bevd_0);
case 1246608323: return bem_iterSetDirect_1(bevd_0);
case 1084056822: return bem_textNodeSetDirect_1(bevd_0);
case 730140516: return bem_debugSetDirect_1(bevd_0);
case -173503500: return bem_xmlStringSet_1(bevd_0);
case 154996556: return bem_stringNew_1((BEC_2_4_6_TextString) bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -2101745537: return bem_lineSet_1(bevd_0);
case -1897857440: return bem_textNodeSet_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 1853779442: return bem_xtSetDirect_1(bevd_0);
case 525294222: return bem_skipSetDirect_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 733739224: return bem_xtSet_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 541118601: return bem_lineSetDirect_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 1923365170: return bem_resSetDirect_1(bevd_0);
case -1807271562: return bem_startedSetDirect_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 531333155: return bem_debugSet_1(bevd_0);
case 510330224: return bem_resSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_3_11_XmlTagIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_11_XmlTagIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_11_XmlTagIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst = (BEC_2_3_11_XmlTagIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_11_XmlTagIterator.bece_BEC_2_3_11_XmlTagIterator_bevs_type;
}
}
}
