namespace be {
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_10_SystemParameters : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemParameters() { }
static BEC_2_6_10_SystemParameters() { }
private static byte[] becc_BEC_2_6_10_SystemParameters_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x61,0x72,0x61,0x6D,0x65,0x74,0x65,0x72,0x73};
private static byte[] becc_BEC_2_6_10_SystemParameters_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_0 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_1 = {0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_2 = {0x70,0x61,0x72,0x61,0x6D,0x73};
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_3 = {0x6F,0x72,0x64,0x65,0x72,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_1, 4));
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_2, 6));
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_3, 7));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_6 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_7 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_9 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_10 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_11 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_4 = {0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_4, 2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_13 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_5 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_5, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_15 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_6 = {0x3D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_6, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_17 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_18 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_7 = {0x23,0x2D,0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_7, 3));
private static BEC_2_4_3_MathInt bece_BEC_2_6_10_SystemParameters_bevo_20 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_6_10_SystemParameters_bels_8 = {0x23};
private static BEC_2_4_6_TextString bece_BEC_2_6_10_SystemParameters_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_6_10_SystemParameters_bels_8, 1));
public static new BEC_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_inst;

public static new BET_2_6_10_SystemParameters bece_BEC_2_6_10_SystemParameters_bevs_type;

public BEC_2_9_4_ContainerList bevp_initialArgs;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_9_3_ContainerMap bevp_params;
public BEC_2_9_4_ContainerList bevp_ordered;
public BEC_2_4_9_TextTokenizer bevp_fileTok;
public BEC_2_6_6_SystemObject bevp_preProcessor;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevp_initialArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_args = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevp_params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_ordered = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_10_SystemParameters_bels_0));
bevp_fileTok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_toJson_0() {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_9_4_ContainerMaps bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_10_JsonMarshaller bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[7];
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerMaps) BEC_2_9_4_ContainerMaps.bece_BEC_2_9_4_ContainerMaps_bevs_inst;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_6_10_SystemParameters_bels_1));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_6_10_SystemParameters_bels_2));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_10_SystemParameters_bels_3));
bevd_x[0] = bevt_1_tmpany_phold;
bevd_x[1] = bevp_args;
bevd_x[2] = bevt_2_tmpany_phold;
bevd_x[3] = bevp_params;
bevd_x[4] = bevt_3_tmpany_phold;
bevd_x[5] = bevp_ordered;
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_phold.bems_forwardCallCp(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes("from")), new BEC_2_9_4_ContainerList(bevd_x, 6));
bevt_5_tmpany_phold = (BEC_2_4_10_JsonMarshaller) (new BEC_2_4_10_JsonMarshaller()).bem_new_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_marshall_1(bevl_jsm);
return bevt_4_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fromJson_1(BEC_2_4_6_TextString beva_jsms) {
BEC_2_9_3_ContainerMap bevl_jsm = null;
BEC_2_4_12_JsonUnmarshaller bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_12_JsonUnmarshaller) (new BEC_2_4_12_JsonUnmarshaller()).bem_new_0();
bevl_jsm = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_phold.bem_unmarshall_1(beva_jsms);
bevt_1_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_0;
bevp_args = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_1;
bevp_params = (BEC_2_9_3_ContainerMap) bevl_jsm.bem_get_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_2;
bevp_ordered = (BEC_2_9_4_ContainerList) bevl_jsm.bem_get_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fromJsonFile_1(BEC_2_2_4_IOFile beva_jsf) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = beva_jsf.bem_readerGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(688503232);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1946950351);
bem_fromJson_1((BEC_2_4_6_TextString) bevt_0_tmpany_phold );
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_toJsonFile_1(BEC_2_2_4_IOFile beva_jsf) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = beva_jsf.bem_writerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(688503232);
bevt_2_tmpany_phold = bem_toJson_0();
bevt_0_tmpany_phold.bemd_1(194824257, bevt_2_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addValue_1(BEC_2_6_10_SystemParameters beva_p) {
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_9_10_ContainerLinkedList bevl_cp = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_9_4_ContainerList bevt_1_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_p.bem_argsGet_0();
bevp_args.bem_addValue_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = beva_p.bem_orderedGet_0();
bevp_ordered.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = beva_p.bem_paramsGet_0();
bevt_0_tmpany_loop = bevt_3_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 140 */ {
bevt_4_tmpany_phold = bevt_0_tmpany_loop.bemd_0(856020715);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_kv = bevt_0_tmpany_loop.bemd_0(-115978313);
bevt_5_tmpany_phold = bevl_kv.bemd_0(-1563886426);
bevl_cp = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevt_5_tmpany_phold);
if (bevl_cp == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevt_7_tmpany_phold = bevl_kv.bemd_0(14478678);
bevl_cp.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 143 */
 else  /* Line: 144 */ {
bevt_8_tmpany_phold = bevl_kv.bemd_0(-1563886426);
bevt_9_tmpany_phold = bevl_kv.bemd_0(14478678);
bevp_params.bem_put_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
} /* Line: 145 */
} /* Line: 142 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_new_1(BEC_2_9_4_ContainerList beva__args) {
bem_new_0();
bevp_initialArgs = beva__args;
bem_addArgs_1(beva__args);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addArgs_1(BEC_2_6_6_SystemObject beva__args) {
BEC_2_4_3_MathInt bevl_ii = null;
BEC_2_4_6_TextString bevl_pname = null;
BEC_2_5_4_LogicBool bevl_pnameComment = null;
BEC_2_4_6_TextString bevl_i = null;
BEC_2_4_6_TextString bevl_fa = null;
BEC_2_4_6_TextString bevl_fb = null;
BEC_2_4_6_TextString bevl_fc = null;
BEC_2_4_6_TextString bevl_par = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_4_6_TextString bevl_value = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
if (bevp_preProcessor == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevl_ii = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 158 */ {
bevt_7_tmpany_phold = beva__args.bemd_0(-587890144);
bevt_6_tmpany_phold = bevl_ii.bem_lesser_1((BEC_2_4_3_MathInt) bevt_7_tmpany_phold );
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevt_9_tmpany_phold = beva__args.bemd_1(1033255450, bevl_ii);
bevt_8_tmpany_phold = bevp_preProcessor.bemd_1(-2009715671, bevt_9_tmpany_phold);
beva__args.bemd_2(1909580244, bevl_ii, bevt_8_tmpany_phold);
bevl_ii = bevl_ii.bem_increment_0();
} /* Line: 158 */
 else  /* Line: 158 */ {
break;
} /* Line: 158 */
} /* Line: 158 */
} /* Line: 158 */
bevp_args = (BEC_2_9_4_ContainerList) bevp_args.bem_add_1((BEC_2_9_4_ContainerList) beva__args );
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_loop = beva__args.bemd_0(-1509690672);
while (true)
 /* Line: 165 */ {
bevt_10_tmpany_phold = bevt_0_tmpany_loop.bemd_0(856020715);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 165 */ {
bevl_i = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-115978313);
bevl_fa = null;
bevl_fb = null;
bevl_fc = null;
bevt_12_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_13_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_3;
if (bevt_12_tmpany_phold.bevi_int > bevt_13_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_14_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_4;
bevt_15_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_5;
bevl_fa = bevl_i.bem_substring_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_18_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_6;
if (bevt_17_tmpany_phold.bevi_int > bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_19_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_7;
bevt_20_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_8;
bevl_fb = bevl_i.bem_substring_2(bevt_19_tmpany_phold, bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_i.bem_sizeGet_0();
bevt_23_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_9;
if (bevt_22_tmpany_phold.bevi_int > bevt_23_tmpany_phold.bevi_int) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 173 */ {
bevt_24_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_10;
bevt_25_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_11;
bevl_fc = bevl_i.bem_substring_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
} /* Line: 174 */
} /* Line: 173 */
} /* Line: 171 */
if (bevl_pname == null) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 178 */ {
if (bevl_pnameComment.bevi_bool) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 179 */ {
bem_addParameter_2(bevl_pname, bevl_i);
} /* Line: 180 */
bevl_pname = null;
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 183 */
 else  /* Line: 178 */ {
if (bevl_fb == null) {
bevt_28_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_28_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 184 */ {
bevt_30_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_12;
bevt_29_tmpany_phold = bevl_fb.bem_equals_1(bevt_30_tmpany_phold);
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 184 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 184 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 184 */
 else  /* Line: 184 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 184 */ {
bevt_31_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_13;
bevt_32_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_31_tmpany_phold, bevt_32_tmpany_phold);
} /* Line: 185 */
 else  /* Line: 178 */ {
if (bevl_fa == null) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_35_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_14;
bevt_34_tmpany_phold = bevl_fa.bem_equals_1(bevt_35_tmpany_phold);
if (bevt_34_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 186 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 186 */
 else  /* Line: 186 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 186 */ {
bevt_36_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_15;
bevt_37_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_par = bevl_i.bem_substring_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_16;
bevl_pos = bevl_par.bem_find_1(bevt_38_tmpany_phold);
if (bevl_pos == null) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevt_40_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_17;
bevl_key = bevl_par.bem_substring_2(bevt_40_tmpany_phold, bevl_pos);
bevt_42_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_18;
bevt_41_tmpany_phold = bevl_pos.bem_add_1(bevt_42_tmpany_phold);
bevl_value = bevl_par.bem_substring_1(bevt_41_tmpany_phold);
bem_addParameter_2(bevl_key, bevl_value);
} /* Line: 192 */
} /* Line: 189 */
 else  /* Line: 178 */ {
if (bevl_fc == null) {
bevt_43_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_43_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_45_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_19;
bevt_44_tmpany_phold = bevl_fc.bem_equals_1(bevt_45_tmpany_phold);
if (bevt_44_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 194 */
 else  /* Line: 194 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 194 */ {
bevt_46_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_20;
bevt_47_tmpany_phold = bevl_i.bem_sizeGet_0();
bevl_pname = bevl_i.bem_substring_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevl_pnameComment = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 196 */
 else  /* Line: 178 */ {
if (bevl_fa == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_50_tmpany_phold = bece_BEC_2_6_10_SystemParameters_bevo_21;
bevt_49_tmpany_phold = bevl_fa.bem_equals_1(bevt_50_tmpany_phold);
if (bevt_49_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 197 */
 else  /* Line: 197 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevp_ordered.bem_addValue_1(bevl_i);
} /* Line: 198 */
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
} /* Line: 178 */
 else  /* Line: 165 */ {
break;
} /* Line: 165 */
} /* Line: 165 */
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_preProcessorSet_1(BEC_2_6_6_SystemObject beva__preProcessor) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_9_3_ContainerMap bevl__params = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_4_6_TextString bevl_key = null;
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_9_10_ContainerLinkedList bevl__vals = null;
BEC_2_4_6_TextString bevl_istr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
bevp_preProcessor = beva__preProcessor;
if (bevp_args == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 206 */ {
bevt_3_tmpany_phold = bevp_args.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevl_i);
bevt_4_tmpany_phold = bevp_preProcessor.bemd_1(-2009715671, bevt_5_tmpany_phold);
bevp_args.bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 206 */
 else  /* Line: 206 */ {
break;
} /* Line: 206 */
} /* Line: 206 */
} /* Line: 206 */
if (bevp_ordered == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 210 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 211 */ {
bevt_8_tmpany_phold = bevp_ordered.bem_lengthGet_0();
if (bevl_i.bevi_int < bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 211 */ {
bevt_10_tmpany_phold = bevp_ordered.bem_get_1(bevl_i);
bevt_9_tmpany_phold = bevp_preProcessor.bemd_1(-2009715671, bevt_10_tmpany_phold);
bevp_ordered.bem_put_2(bevl_i, bevt_9_tmpany_phold);
bevl_i = bevl_i.bem_increment_0();
} /* Line: 211 */
 else  /* Line: 211 */ {
break;
} /* Line: 211 */
} /* Line: 211 */
} /* Line: 211 */
if (bevp_params == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 215 */ {
bevl__params = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_it = bevp_params.bem_keyIteratorGet_0();
while (true)
 /* Line: 217 */ {
bevt_12_tmpany_phold = bevl_it.bemd_0(856020715);
if (((BEC_2_5_4_LogicBool) bevt_12_tmpany_phold).bevi_bool) /* Line: 217 */ {
bevl_key = (BEC_2_4_6_TextString) bevl_it.bemd_0(-115978313);
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(bevl_key);
bevl__vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_0_tmpany_loop = bevl_vals.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 221 */ {
bevt_13_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 221 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevt_14_tmpany_phold = bevp_preProcessor.bemd_1(-2009715671, bevl_istr);
bevl__vals.bem_addValue_1(bevt_14_tmpany_phold);
} /* Line: 222 */
 else  /* Line: 221 */ {
break;
} /* Line: 221 */
} /* Line: 221 */
bevl_key = (BEC_2_4_6_TextString) bevp_preProcessor.bemd_1(-2009715671, bevl_key);
bevl__params.bem_put_2(bevl_key, bevl__vals);
} /* Line: 225 */
 else  /* Line: 217 */ {
break;
} /* Line: 217 */
} /* Line: 217 */
bevp_params = bevl__params;
} /* Line: 227 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_2(BEC_2_4_6_TextString beva_name, BEC_2_5_4_LogicBool beva_isit) {
BEC_2_4_6_TextString bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_res = bem_getFirst_1(beva_name);
if (bevl_res == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 233 */ {
beva_isit = (new BEC_2_5_4_LogicBool()).bem_new_1(bevl_res);
} /* Line: 235 */
return beva_isit;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isTrue_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_isTrue_2(beva_name, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_has_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_has_1(beva_name);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_1(BEC_2_4_6_TextString beva_name) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_get_1(beva_name);
return (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_get_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 255 */ {
bevl_pl = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_pl.bem_addValue_1(beva_default);
} /* Line: 257 */
return bevl_pl;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_1(BEC_2_4_6_TextString beva_name) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getFirst_2(beva_name, null);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_getFirst_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_default) {
BEC_2_9_10_ContainerLinkedList bevl_pl = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_pl = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_pl == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 268 */ {
return beva_default;
} /* Line: 269 */
bevt_1_tmpany_phold = bevl_pl.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParameter_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
bem_addParam_2(beva_name, beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addParam_2(BEC_2_4_6_TextString beva_name, BEC_2_4_6_TextString beva_value) {
BEC_2_9_10_ContainerLinkedList bevl_vals = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_vals = (BEC_2_9_10_ContainerLinkedList) bevp_params.bem_get_1(beva_name);
if (bevl_vals == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 281 */ {
bevl_vals = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_params.bem_put_2(beva_name, bevl_vals);
} /* Line: 283 */
bevl_vals.bem_addValue_1(beva_value);
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_addFile_1(BEC_2_2_4_IOFile beva_file) {
BEC_2_6_6_SystemObject bevl_fcontents = null;
BEC_2_9_4_ContainerList bevl_fargs = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = beva_file.bem_readerGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(688503232);
bevl_fcontents = bevt_0_tmpany_phold.bemd_0(1236826741);
bevt_2_tmpany_phold = beva_file.bem_readerGet_0();
bevt_2_tmpany_phold.bemd_0(1681461651);
bevt_3_tmpany_phold = bevp_fileTok.bem_tokenize_1(bevl_fcontents);
bevl_fargs = (BEC_2_9_4_ContainerList) bevt_3_tmpany_phold.bemd_0(1033629167);
bem_addArgs_1(bevl_fargs);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_params.bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_initialArgsGet_0() {
return bevp_initialArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_initialArgsGetDirect_0() {
return bevp_initialArgs;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_initialArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_initialArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initialArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_orderedGet_0() {
return bevp_ordered;
} /*method end*/
public BEC_2_9_4_ContainerList bem_orderedGetDirect_0() {
return bevp_ordered;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_orderedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_orderedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ordered = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_fileTokGet_0() {
return bevp_fileTok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_fileTokGetDirect_0() {
return bevp_fileTok;
} /*method end*/
public virtual BEC_2_6_10_SystemParameters bem_fileTokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_fileTokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fileTok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_preProcessorGet_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_6_SystemObject bem_preProcessorGetDirect_0() {
return bevp_preProcessor;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_preProcessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_preProcessor = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {107, 108, 109, 110, 111, 111, 118, 118, 118, 118, 118, 119, 119, 119, 123, 123, 124, 124, 125, 125, 126, 126, 130, 130, 130, 130, 134, 134, 134, 134, 138, 138, 139, 139, 140, 140, 0, 140, 140, 141, 141, 142, 142, 143, 143, 145, 145, 145, 151, 152, 153, 157, 157, 158, 158, 158, 159, 159, 159, 158, 162, 163, 164, 165, 0, 165, 165, 166, 167, 168, 169, 169, 169, 169, 170, 170, 170, 171, 171, 171, 171, 172, 172, 172, 173, 173, 173, 173, 174, 174, 174, 178, 178, 179, 179, 180, 182, 183, 184, 184, 184, 184, 0, 0, 0, 185, 185, 185, 186, 186, 186, 186, 0, 0, 0, 187, 187, 187, 188, 188, 189, 189, 190, 190, 191, 191, 191, 192, 194, 194, 194, 194, 0, 0, 0, 195, 195, 195, 196, 197, 197, 197, 197, 0, 0, 0, 197, 197, 198, 204, 205, 205, 206, 206, 206, 206, 207, 207, 207, 206, 210, 210, 211, 211, 211, 211, 212, 212, 212, 211, 215, 215, 216, 217, 217, 218, 219, 220, 221, 0, 221, 221, 222, 222, 224, 225, 227, 232, 233, 233, 235, 238, 242, 242, 242, 246, 246, 250, 250, 254, 255, 255, 256, 257, 259, 263, 263, 267, 268, 268, 269, 271, 271, 275, 280, 281, 281, 282, 283, 285, 290, 290, 290, 291, 291, 292, 292, 293, 297, 297, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {51, 52, 53, 54, 55, 56, 68, 69, 70, 71, 72, 79, 80, 81, 89, 90, 91, 92, 93, 94, 95, 96, 103, 104, 105, 106, 113, 114, 115, 116, 132, 133, 134, 135, 136, 137, 137, 140, 142, 143, 144, 145, 150, 151, 152, 155, 156, 157, 167, 168, 169, 236, 241, 242, 245, 246, 248, 249, 250, 251, 258, 259, 260, 261, 261, 264, 266, 267, 268, 269, 270, 271, 272, 277, 278, 279, 280, 281, 282, 283, 288, 289, 290, 291, 292, 293, 294, 299, 300, 301, 302, 306, 311, 312, 317, 318, 320, 321, 324, 329, 330, 331, 333, 336, 340, 343, 344, 345, 348, 353, 354, 355, 357, 360, 364, 367, 368, 369, 370, 371, 372, 377, 378, 379, 380, 381, 382, 383, 387, 392, 393, 394, 396, 399, 403, 406, 407, 408, 409, 412, 417, 418, 419, 421, 424, 428, 430, 435, 436, 472, 473, 478, 479, 482, 483, 488, 489, 490, 491, 492, 499, 504, 505, 508, 509, 514, 515, 516, 517, 518, 525, 530, 531, 532, 535, 537, 538, 539, 540, 540, 543, 545, 546, 547, 553, 554, 560, 567, 568, 573, 574, 576, 581, 582, 583, 587, 588, 592, 593, 598, 599, 604, 605, 606, 608, 612, 613, 619, 620, 625, 626, 628, 629, 632, 638, 639, 644, 645, 646, 648, 658, 659, 660, 661, 662, 663, 664, 665, 670, 671, 674, 677, 680, 684, 688, 691, 694, 698, 702, 705, 708, 712, 716, 719, 722, 726, 730, 733, 736, 740, 744, 747, 750};
/* BEGIN LINEINFO 
assign 1 107 51
new 0 107 51
assign 1 108 52
new 0 108 52
assign 1 109 53
new 0 109 53
assign 1 110 54
new 0 110 54
assign 1 111 55
new 0 111 55
assign 1 111 56
new 1 111 56
assign 1 118 68
new 0 118 68
assign 1 118 69
new 0 118 69
assign 1 118 70
new 0 118 70
assign 1 118 71
new 0 118 71
assign 1 118 72
from 6 118 72
assign 1 119 79
new 0 119 79
assign 1 119 80
marshall 1 119 80
return 1 119 81
assign 1 123 89
new 0 123 89
assign 1 123 90
unmarshall 1 123 90
assign 1 124 91
new 0 124 91
assign 1 124 92
get 1 124 92
assign 1 125 93
new 0 125 93
assign 1 125 94
get 1 125 94
assign 1 126 95
new 0 126 95
assign 1 126 96
get 1 126 96
assign 1 130 103
readerGet 0 130 103
assign 1 130 104
open 0 130 104
assign 1 130 105
readStringClose 0 130 105
fromJson 1 130 106
assign 1 134 113
writerGet 0 134 113
assign 1 134 114
open 0 134 114
assign 1 134 115
toJson 0 134 115
writeStringClose 1 134 116
assign 1 138 132
argsGet 0 138 132
addValue 1 138 133
assign 1 139 134
orderedGet 0 139 134
addValue 1 139 135
assign 1 140 136
paramsGet 0 140 136
assign 1 140 137
iteratorGet 0 0 137
assign 1 140 140
hasNextGet 0 140 140
assign 1 140 142
nextGet 0 140 142
assign 1 141 143
keyGet 0 141 143
assign 1 141 144
get 1 141 144
assign 1 142 145
def 1 142 150
assign 1 143 151
valueGet 0 143 151
addValue 1 143 152
assign 1 145 155
keyGet 0 145 155
assign 1 145 156
valueGet 0 145 156
put 2 145 157
new 0 151 167
assign 1 152 168
addArgs 1 153 169
assign 1 157 236
def 1 157 241
assign 1 158 242
new 0 158 242
assign 1 158 245
lengthGet 0 158 245
assign 1 158 246
lesser 1 158 246
assign 1 159 248
get 1 159 248
assign 1 159 249
process 1 159 249
put 2 159 250
assign 1 158 251
increment 0 158 251
assign 1 162 258
add 1 162 258
assign 1 163 259
assign 1 164 260
new 0 164 260
assign 1 165 261
iteratorGet 0 0 261
assign 1 165 264
hasNextGet 0 165 264
assign 1 165 266
nextGet 0 165 266
assign 1 166 267
assign 1 167 268
assign 1 168 269
assign 1 169 270
sizeGet 0 169 270
assign 1 169 271
new 0 169 271
assign 1 169 272
greater 1 169 277
assign 1 170 278
new 0 170 278
assign 1 170 279
new 0 170 279
assign 1 170 280
substring 2 170 280
assign 1 171 281
sizeGet 0 171 281
assign 1 171 282
new 0 171 282
assign 1 171 283
greater 1 171 288
assign 1 172 289
new 0 172 289
assign 1 172 290
new 0 172 290
assign 1 172 291
substring 2 172 291
assign 1 173 292
sizeGet 0 173 292
assign 1 173 293
new 0 173 293
assign 1 173 294
greater 1 173 299
assign 1 174 300
new 0 174 300
assign 1 174 301
new 0 174 301
assign 1 174 302
substring 2 174 302
assign 1 178 306
def 1 178 311
assign 1 179 312
not 0 179 317
addParameter 2 180 318
assign 1 182 320
assign 1 183 321
new 0 183 321
assign 1 184 324
def 1 184 329
assign 1 184 330
new 0 184 330
assign 1 184 331
equals 1 184 331
assign 1 0 333
assign 1 0 336
assign 1 0 340
assign 1 185 343
new 0 185 343
assign 1 185 344
sizeGet 0 185 344
assign 1 185 345
substring 2 185 345
assign 1 186 348
def 1 186 353
assign 1 186 354
new 0 186 354
assign 1 186 355
equals 1 186 355
assign 1 0 357
assign 1 0 360
assign 1 0 364
assign 1 187 367
new 0 187 367
assign 1 187 368
sizeGet 0 187 368
assign 1 187 369
substring 2 187 369
assign 1 188 370
new 0 188 370
assign 1 188 371
find 1 188 371
assign 1 189 372
def 1 189 377
assign 1 190 378
new 0 190 378
assign 1 190 379
substring 2 190 379
assign 1 191 380
new 0 191 380
assign 1 191 381
add 1 191 381
assign 1 191 382
substring 1 191 382
addParameter 2 192 383
assign 1 194 387
def 1 194 392
assign 1 194 393
new 0 194 393
assign 1 194 394
equals 1 194 394
assign 1 0 396
assign 1 0 399
assign 1 0 403
assign 1 195 406
new 0 195 406
assign 1 195 407
sizeGet 0 195 407
assign 1 195 408
substring 2 195 408
assign 1 196 409
new 0 196 409
assign 1 197 412
def 1 197 417
assign 1 197 418
new 0 197 418
assign 1 197 419
equals 1 197 419
assign 1 0 421
assign 1 0 424
assign 1 0 428
assign 1 197 430
not 0 197 435
addValue 1 198 436
assign 1 204 472
assign 1 205 473
def 1 205 478
assign 1 206 479
new 0 206 479
assign 1 206 482
lengthGet 0 206 482
assign 1 206 483
lesser 1 206 488
assign 1 207 489
get 1 207 489
assign 1 207 490
process 1 207 490
put 2 207 491
assign 1 206 492
increment 0 206 492
assign 1 210 499
def 1 210 504
assign 1 211 505
new 0 211 505
assign 1 211 508
lengthGet 0 211 508
assign 1 211 509
lesser 1 211 514
assign 1 212 515
get 1 212 515
assign 1 212 516
process 1 212 516
put 2 212 517
assign 1 211 518
increment 0 211 518
assign 1 215 525
def 1 215 530
assign 1 216 531
new 0 216 531
assign 1 217 532
keyIteratorGet 0 217 532
assign 1 217 535
hasNextGet 0 217 535
assign 1 218 537
nextGet 0 218 537
assign 1 219 538
get 1 219 538
assign 1 220 539
new 0 220 539
assign 1 221 540
linkedListIteratorGet 0 0 540
assign 1 221 543
hasNextGet 0 221 543
assign 1 221 545
nextGet 0 221 545
assign 1 222 546
process 1 222 546
addValue 1 222 547
assign 1 224 553
process 1 224 553
put 2 225 554
assign 1 227 560
assign 1 232 567
getFirst 1 232 567
assign 1 233 568
def 1 233 573
assign 1 235 574
new 1 235 574
return 1 238 576
assign 1 242 581
new 0 242 581
assign 1 242 582
isTrue 2 242 582
return 1 242 583
assign 1 246 587
has 1 246 587
return 1 246 588
assign 1 250 592
get 1 250 592
return 1 250 593
assign 1 254 598
get 1 254 598
assign 1 255 599
undef 1 255 604
assign 1 256 605
new 0 256 605
addValue 1 257 606
return 1 259 608
assign 1 263 612
getFirst 2 263 612
return 1 263 613
assign 1 267 619
get 1 267 619
assign 1 268 620
undef 1 268 625
return 1 269 626
assign 1 271 628
firstGet 0 271 628
return 1 271 629
addParam 2 275 632
assign 1 280 638
get 1 280 638
assign 1 281 639
undef 1 281 644
assign 1 282 645
new 0 282 645
put 2 283 646
addValue 1 285 648
assign 1 290 658
readerGet 0 290 658
assign 1 290 659
open 0 290 659
assign 1 290 660
readString 0 290 660
assign 1 291 661
readerGet 0 291 661
close 0 291 662
assign 1 292 663
tokenize 1 292 663
assign 1 292 664
toList 0 292 664
addArgs 1 293 665
assign 1 297 670
iteratorGet 0 297 670
return 1 297 671
return 1 0 674
return 1 0 677
assign 1 0 680
assign 1 0 684
return 1 0 688
return 1 0 691
assign 1 0 694
assign 1 0 698
return 1 0 702
return 1 0 705
assign 1 0 708
assign 1 0 712
return 1 0 716
return 1 0 719
assign 1 0 722
assign 1 0 726
return 1 0 730
return 1 0 733
assign 1 0 736
assign 1 0 740
return 1 0 744
return 1 0 747
assign 1 0 750
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2098994482: return bem_hashGet_0();
case 1764716287: return bem_once_0();
case -98046751: return bem_tagGet_0();
case 329044611: return bem_fieldNamesGet_0();
case -1042589864: return bem_fileTokGetDirect_0();
case 334648449: return bem_serializationIteratorGet_0();
case 2098483713: return bem_copy_0();
case -1248029915: return bem_initialArgsGetDirect_0();
case -1706011364: return bem_initialArgsGet_0();
case -1006908471: return bem_serializeContents_0();
case 265980647: return bem_orderedGet_0();
case -598728085: return bem_preProcessorGet_0();
case 281585293: return bem_toAny_0();
case -685092357: return bem_toJson_0();
case 1654455733: return bem_argsGet_0();
case -1101624703: return bem_deserializeClassNameGet_0();
case 1355527710: return bem_paramsGet_0();
case 812544411: return bem_echo_0();
case 1163805126: return bem_new_0();
case -1467086316: return bem_fileTokGet_0();
case 487833474: return bem_paramsGetDirect_0();
case 1669654091: return bem_many_0();
case -1008646345: return bem_preProcessorGetDirect_0();
case 275979338: return bem_argsGetDirect_0();
case 1929688279: return bem_classNameGet_0();
case -1032171260: return bem_toString_0();
case 538389441: return bem_serializeToString_0();
case -1509690672: return bem_iteratorGet_0();
case 370451746: return bem_orderedGetDirect_0();
case 705622040: return bem_sourceFileNameGet_0();
case -1610742202: return bem_create_0();
case 1945143392: return bem_fieldIteratorGet_0();
case -1058456741: return bem_print_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1446306055: return bem_otherClass_1(bevd_0);
case 1224467768: return bem_new_1((BEC_2_9_4_ContainerList) bevd_0);
case -1758099234: return bem_orderedSetDirect_1(bevd_0);
case -1685877365: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1660184431: return bem_fromJson_1((BEC_2_4_6_TextString) bevd_0);
case 1867834674: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 794367880: return bem_addArgs_1(bevd_0);
case -1638870181: return bem_orderedSet_1(bevd_0);
case -1524968669: return bem_sameClass_1(bevd_0);
case -338857524: return bem_addFile_1((BEC_2_2_4_IOFile) bevd_0);
case -1304412184: return bem_preProcessorSetDirect_1(bevd_0);
case 2127772510: return bem_getFirst_1((BEC_2_4_6_TextString) bevd_0);
case -538669708: return bem_initialArgsSetDirect_1(bevd_0);
case 1300185187: return bem_undefined_1(bevd_0);
case 319955808: return bem_initialArgsSet_1(bevd_0);
case 1863898392: return bem_equals_1(bevd_0);
case -1207491940: return bem_undef_1(bevd_0);
case 714503183: return bem_sameObject_1(bevd_0);
case 1033255450: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case 1342527237: return bem_isTrue_1((BEC_2_4_6_TextString) bevd_0);
case 220285540: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1069574879: return bem_fileTokSetDirect_1(bevd_0);
case -1762878331: return bem_addValue_1((BEC_2_6_10_SystemParameters) bevd_0);
case 1538927011: return bem_copyTo_1(bevd_0);
case 613414930: return bem_def_1(bevd_0);
case -1050544035: return bem_fromJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
case 2108235391: return bem_defined_1(bevd_0);
case -833799554: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2004704427: return bem_argsSet_1(bevd_0);
case 99127990: return bem_otherType_1(bevd_0);
case -1951897524: return bem_paramsSetDirect_1(bevd_0);
case 899871629: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 1923275992: return bem_preProcessorSet_1(bevd_0);
case -1776959106: return bem_notEquals_1(bevd_0);
case -297445795: return bem_fileTokSet_1(bevd_0);
case 1837978646: return bem_sameType_1(bevd_0);
case -921291931: return bem_argsSetDirect_1(bevd_0);
case -1374995625: return bem_paramsSet_1(bevd_0);
case -1650586664: return bem_toJsonFile_1((BEC_2_2_4_IOFile) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -491423906: return bem_isTrue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -319646499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 937271141: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1640145582: return bem_addParameter_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -945714295: return bem_get_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1621074608: return bem_getFirst_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -903966108: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 395811446: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1997741826: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1670352859: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -906378356: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1643239798: return bem_addParam_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemParameters_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_10_SystemParameters_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemParameters();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst = (BEC_2_6_10_SystemParameters) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemParameters.bece_BEC_2_6_10_SystemParameters_bevs_type;
}
}
}
