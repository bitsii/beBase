namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_7_IOFileReaderCommand : BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
static BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
public static new BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static new BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva__command) {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) {
base.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_open_0() {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool)/* Line: 832*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevp_command);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_4_ta_ph);
bevt_0_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_ta_ph);
throw new be.BECS_ThrowBack(bevt_0_ta_ph);
} /* Line: 833*/
return this;
} /*method end*/
public override BEC_2_2_6_IOReader bem_close_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGetDirect_0() {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {795, 799, 803, 805, 816, 831, 833, 833, 833, 833, 833, 833, 846, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 23, 27, 28, 39, 40, 42, 43, 44, 45, 46, 47, 52, 56, 59, 62, 66};
/* BEGIN LINEINFO 
new 0 795 19
commandNew 1 799 23
new 0 803 27
assign 1 805 28
assign 1 816 39
assign 1 831 40
assign 1 833 42
new 0 833 42
assign 1 833 43
add 1 833 43
assign 1 833 44
new 0 833 44
assign 1 833 45
add 1 833 45
assign 1 833 46
new 1 833 46
throw 1 833 47
assign 1 846 52
new 0 846 52
return 1 0 56
return 1 0 59
assign 1 0 62
assign 1 0 66
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -2026067879: return bem_readString_0();
case 884288379: return bem_readStringClose_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case -1749612006: return bem_vfileGetDirect_0();
case 925559139: return bem_close_0();
case -1387774069: return bem_readBufferLine_0();
case -1076915155: return bem_serializeToString_0();
case -640072781: return bem_blockSizeGet_0();
case 691840994: return bem_commandGetDirect_0();
case -1503223037: return bem_byteReaderGet_0();
case 1834246217: return bem_classNameGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case -151747519: return bem_pathGet_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -978188014: return bem_readBuffer_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case 2081363871: return bem_copy_0();
case -975498393: return bem_fieldNamesGet_0();
case 157865864: return bem_readDiscardClose_0();
case 942248168: return bem_readDiscard_0();
case 954703233: return bem_create_0();
case -348414384: return bem_commandGet_0();
case -893093197: return bem_toString_0();
case -1765844603: return bem_blockSizeGetDirect_0();
case 1908183650: return bem_extOpen_0();
case 155723965: return bem_pathGetDirect_0();
case 397219271: return bem_vfileGet_0();
case 1947374815: return bem_open_0();
case -40905183: return bem_echo_0();
case -1805795806: return bem_isClosedGet_0();
case -125356968: return bem_isClosedGetDirect_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 59504167: return bem_new_1(bevd_0);
case -1421462792: return bem_pathSetDirect_1(bevd_0);
case 1130965068: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 714792787: return bem_isClosedSetDirect_1(bevd_0);
case -2121635251: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -1424213306: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 1237794651: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -1865727198: return bem_commandSetDirect_1(bevd_0);
case 1898156000: return bem_blockSizeSet_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 149757160: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 1677488410: return bem_blockSizeSetDirect_1(bevd_0);
case -142472315: return bem_commandSet_1(bevd_0);
case 87576062: return bem_vfileSet_1(bevd_0);
case -1339687555: return bem_vfileSetDirect_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -1769906857: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1671787762: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case -74273945: return bem_pathSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1224708572: return bem_isClosedSet_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2106637717: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -2135975890: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1599501837: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
}
