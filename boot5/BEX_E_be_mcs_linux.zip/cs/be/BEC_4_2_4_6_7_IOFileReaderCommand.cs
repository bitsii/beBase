namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_7_IOFileReaderCommand : BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
static BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0, 8));
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1, 30));
public static new BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static new BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva__command) {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) {
base.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_open_0() {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool) /* Line: 832 */ {
bevt_3_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_command);
bevt_4_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 833 */
return this;
} /*method end*/
public override BEC_2_2_6_IOReader bem_close_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGetDirect_0() {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {795, 799, 803, 805, 816, 831, 833, 833, 833, 833, 833, 833, 846, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 25, 29, 30, 41, 42, 44, 45, 46, 47, 48, 49, 54, 58, 61, 64, 68};
/* BEGIN LINEINFO 
new 0 795 21
commandNew 1 799 25
new 0 803 29
assign 1 805 30
assign 1 816 41
assign 1 831 42
assign 1 833 44
new 0 833 44
assign 1 833 45
add 1 833 45
assign 1 833 46
new 0 833 46
assign 1 833 47
add 1 833 47
assign 1 833 48
new 1 833 48
throw 1 833 49
assign 1 846 54
new 0 846 54
return 1 0 58
return 1 0 61
assign 1 0 64
assign 1 0 68
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1194804327: return bem_fieldNamesGet_0();
case -1964263357: return bem_readStringClose_0();
case 1513930674: return bem_extOpen_0();
case 481124440: return bem_blockSizeGetDirect_0();
case 997592500: return bem_vfileGetDirect_0();
case 1513233059: return bem_toString_0();
case -491501183: return bem_readDiscardClose_0();
case 1496723504: return bem_commandGet_0();
case 144584723: return bem_create_0();
case -1123278056: return bem_tagGet_0();
case 140259447: return bem_vfileGet_0();
case -1120214942: return bem_isClosedGet_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case 1577195459: return bem_serializationIteratorGet_0();
case -713163994: return bem_toAny_0();
case -1362850090: return bem_serializeContents_0();
case -2051518290: return bem_once_0();
case 1627167354: return bem_readDiscard_0();
case -449079106: return bem_iteratorGet_0();
case 1135378825: return bem_byteReaderGet_0();
case -1045111996: return bem_open_0();
case 611670694: return bem_fieldIteratorGet_0();
case 1942283510: return bem_sourceFileNameGet_0();
case 1550228949: return bem_isClosedGetDirect_0();
case 96033137: return bem_serializeToString_0();
case 868833177: return bem_readBufferLine_0();
case 341575045: return bem_many_0();
case -1901210116: return bem_readBuffer_0();
case -2056320704: return bem_close_0();
case -777650278: return bem_pathGet_0();
case -1266447496: return bem_classNameGet_0();
case 1103552481: return bem_readString_0();
case -1965608615: return bem_commandGetDirect_0();
case 1851908877: return bem_hashGet_0();
case -2103456303: return bem_blockSizeGet_0();
case -10010145: return bem_copy_0();
case 1071461198: return bem_echo_0();
case 990360647: return bem_new_0();
case -1086782351: return bem_print_0();
case -1897454358: return bem_pathGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 822097185: return bem_commandSetDirect_1(bevd_0);
case -119863578: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -900841113: return bem_pathSet_1(bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1071001840: return bem_new_1(bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2107035481: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1904046533: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1128095708: return bem_isClosedSet_1(bevd_0);
case -132439165: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case -1988153166: return bem_isClosedSetDirect_1(bevd_0);
case 1828463962: return bem_pathSetDirect_1(bevd_0);
case 713429202: return bem_commandSet_1(bevd_0);
case -893970149: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case 378093986: return bem_blockSizeSet_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
case 1476931473: return bem_vfileSetDirect_1(bevd_0);
case -844536929: return bem_blockSizeSetDirect_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case 544521652: return bem_vfileSet_1(bevd_0);
case -1792149021: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case -655019399: return bem_def_1(bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case 508583571: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 1449340032: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -405598603: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -822562988: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 1497919081: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
}
