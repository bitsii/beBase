namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_7_IOFileReaderCommand : BEC_3_2_4_6_IOFileReader {
public BEC_4_2_4_6_7_IOFileReaderCommand() { }
static BEC_4_2_4_6_7_IOFileReaderCommand() { }
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72,0x3A,0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64};
private static byte[] becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0 = {0x43,0x6F,0x6D,0x6D,0x61,0x6E,0x64,0x20};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_0, 8));
private static byte[] bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_4_2_4_6_7_IOFileReaderCommand_bels_1, 30));
public static new BEC_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;

public static new BET_4_2_4_6_7_IOFileReaderCommand bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;

public BEC_2_4_6_TextString bevp_command;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva__command) {
bem_commandNew_1((BEC_2_4_6_TextString) beva__command );
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandNew_1(BEC_2_4_6_TextString beva__command) {
base.bem_new_0();
bevp_command = beva__command;
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileReader bem_open_0() {
BEC_2_4_6_TextString bevl__command = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_6_9_SystemException bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl__command = bevp_command;
bevp_isClosed = bevl__isClosed;
if (bevp_isClosed.bevi_bool) /* Line: 758 */ {
bevt_3_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_0;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_command);
bevt_4_tmpany_phold = bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevo_1;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_1_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_0_tmpany_phold);
} /* Line: 759 */
return this;
} /*method end*/
public override BEC_2_2_6_IOReader bem_close_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGet_0() {
return bevp_command;
} /*method end*/
public BEC_2_4_6_TextString bem_commandGetDirect_0() {
return bevp_command;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_4_2_4_6_7_IOFileReaderCommand bem_commandSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_command = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {721, 725, 729, 731, 742, 757, 759, 759, 759, 759, 759, 759, 772, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 25, 29, 30, 41, 42, 44, 45, 46, 47, 48, 49, 54, 58, 61, 64, 68};
/* BEGIN LINEINFO 
new 0 721 21
commandNew 1 725 25
new 0 729 29
assign 1 731 30
assign 1 742 41
assign 1 757 42
assign 1 759 44
new 0 759 44
assign 1 759 45
add 1 759 45
assign 1 759 46
new 0 759 46
assign 1 759 47
add 1 759 47
assign 1 759 48
new 1 759 48
throw 1 759 49
assign 1 772 54
new 0 772 54
return 1 0 58
return 1 0 61
assign 1 0 64
assign 1 0 68
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 430406055: return bem_readStringClose_0();
case -721749399: return bem_readBuffer_0();
case 1131385505: return bem_toAny_0();
case 125000155: return bem_vfileGet_0();
case 1091573386: return bem_extOpen_0();
case 1585945693: return bem_vfileGetDirect_0();
case 916294969: return bem_sourceFileNameGet_0();
case 343375430: return bem_create_0();
case -867096085: return bem_close_0();
case 818429488: return bem_readBufferLine_0();
case 1970758688: return bem_fieldNamesGet_0();
case -1013699431: return bem_commandGetDirect_0();
case 1962569597: return bem_blockSizeGet_0();
case -634095112: return bem_blockSizeGetDirect_0();
case -928163909: return bem_fieldIteratorGet_0();
case -1574932366: return bem_print_0();
case 2118073021: return bem_byteReaderGet_0();
case 431618869: return bem_once_0();
case -825084265: return bem_hashGet_0();
case -2107201227: return bem_open_0();
case 131226213: return bem_toString_0();
case -1031399474: return bem_echo_0();
case 1253953314: return bem_serializationIteratorGet_0();
case -1944290386: return bem_isClosedGetDirect_0();
case -2051799514: return bem_new_0();
case -926098441: return bem_readString_0();
case 911313117: return bem_tagGet_0();
case -1846550974: return bem_serializeContents_0();
case -1485517163: return bem_copy_0();
case -1554766847: return bem_pathGet_0();
case 2063546474: return bem_classNameGet_0();
case 1471896260: return bem_isClosedGet_0();
case 421749162: return bem_iteratorGet_0();
case -2079266983: return bem_pathGetDirect_0();
case -109121931: return bem_commandGet_0();
case 1279906777: return bem_serializeToString_0();
case -957769093: return bem_deserializeClassNameGet_0();
case 2061421621: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 747155616: return bem_notEquals_1(bevd_0);
case 1450717154: return bem_pathSetDirect_1(bevd_0);
case 1473844328: return bem_commandNew_1((BEC_2_4_6_TextString) bevd_0);
case 1889683305: return bem_new_1(bevd_0);
case -1551421646: return bem_copyTo_1(bevd_0);
case 192530319: return bem_otherType_1(bevd_0);
case -628476976: return bem_otherClass_1(bevd_0);
case -1679716913: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -687255572: return bem_blockSizeSet_1(bevd_0);
case -436556280: return bem_undef_1(bevd_0);
case 1555616281: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -126208732: return bem_commandSetDirect_1(bevd_0);
case -1655018142: return bem_sameType_1(bevd_0);
case -82544672: return bem_commandSet_1(bevd_0);
case -826801569: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -470643685: return bem_pathSet_1(bevd_0);
case -1181240679: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1248747112: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 535407594: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 230885422: return bem_blockSizeSetDirect_1(bevd_0);
case 623413496: return bem_isClosedSet_1(bevd_0);
case 140440570: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 1170450780: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -2095451198: return bem_vfileSetDirect_1(bevd_0);
case 1768644351: return bem_sameClass_1(bevd_0);
case -1065536512: return bem_equals_1(bevd_0);
case 1889492512: return bem_isClosedSetDirect_1(bevd_0);
case 1383324451: return bem_sameObject_1(bevd_0);
case -1809169317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1147111468: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1014928301: return bem_vfileSet_1(bevd_0);
case 1928047187: return bem_undefined_1(bevd_0);
case 1044863323: return bem_defined_1(bevd_0);
case -2018944701: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1990600260: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1260241587: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -598891548: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1655882914: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1041029455: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 802380860: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -214435591: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -40143354: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 10496104: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 2017130211: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_7_IOFileReaderCommand_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_7_IOFileReaderCommand();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst = (BEC_4_2_4_6_7_IOFileReaderCommand) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_4_2_4_6_7_IOFileReaderCommand.bece_BEC_4_2_4_6_7_IOFileReaderCommand_bevs_type;
}
}
}
