namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_3_2_4_12_IOFileNamedReaders : BEC_2_6_6_SystemObject {
public BEC_3_2_4_12_IOFileNamedReaders() { }
static BEC_3_2_4_12_IOFileNamedReaders() { }
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x52,0x65,0x61,0x64,0x65,0x72,0x73};
private static byte[] becc_BEC_3_2_4_12_IOFileNamedReaders_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;

public static new BET_3_2_4_12_IOFileNamedReaders bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_type;

public BEC_3_2_4_6_IOFileReader bevp_input;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_default_0() {
BEC_4_2_4_6_5_IOFileReaderStdin bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_4_2_4_6_5_IOFileReaderStdin) BEC_4_2_4_6_5_IOFileReaderStdin.bece_BEC_4_2_4_6_5_IOFileReaderStdin_bevs_inst.bem_new_0();
bem_inputSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_inputSet_1(BEC_3_2_4_6_IOFileReader beva__input) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevp_input = beva__input;
bevt_0_tmpany_phold = bevp_input.bem_isClosedGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 608 */ {
bevp_input.bem_open_0();
} /* Line: 609 */
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_inputGet_0() {
return bevp_input;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_inputGetDirect_0() {
return bevp_input;
} /*method end*/
public BEC_3_2_4_12_IOFileNamedReaders bem_inputSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_input = (BEC_3_2_4_6_IOFileReader) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {603, 603, 607, 608, 609, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 27, 28, 30, 35, 38, 41};
/* BEGIN LINEINFO 
assign 1 603 21
new 0 603 21
inputSet 1 603 22
assign 1 607 27
assign 1 608 28
isClosedGet 0 608 28
open 0 609 30
return 1 0 35
return 1 0 38
assign 1 0 41
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1253246070: return bem_create_0();
case 1014225644: return bem_echo_0();
case -1882364243: return bem_many_0();
case -628560707: return bem_toAny_0();
case -2123848647: return bem_fieldNamesGet_0();
case 253852410: return bem_inputGetDirect_0();
case 770834928: return bem_serializeContents_0();
case 1297175099: return bem_fieldIteratorGet_0();
case -753894116: return bem_new_0();
case -1074341902: return bem_print_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -1138072028: return bem_tagGet_0();
case 844225351: return bem_classNameGet_0();
case -2083934905: return bem_copy_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 80244442: return bem_toString_0();
case -2131387379: return bem_iteratorGet_0();
case -1625648722: return bem_once_0();
case -1194289304: return bem_serializeToString_0();
case -35866257: return bem_inputGet_0();
case -720093952: return bem_default_0();
case 1165329653: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -746295633: return bem_inputSetDirect_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1060676876: return bem_inputSet_1((BEC_3_2_4_6_IOFileReader) bevd_0);
case -636442813: return bem_def_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_2_4_12_IOFileNamedReaders_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_12_IOFileNamedReaders_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_12_IOFileNamedReaders();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst = (BEC_3_2_4_12_IOFileNamedReaders) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_12_IOFileNamedReaders.bece_BEC_3_2_4_12_IOFileNamedReaders_bevs_type;
}
}
}
