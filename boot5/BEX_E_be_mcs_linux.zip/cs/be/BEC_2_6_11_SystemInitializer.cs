namespace be {

 using System;
 using System.Security.Cryptography;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_11_SystemInitializer : BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemInitializer() { }
static BEC_2_6_11_SystemInitializer() { }
private static byte[] becc_BEC_2_6_11_SystemInitializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_11_SystemInitializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_11_SystemInitializer_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
public static new BEC_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_inst;

public static new BET_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_type;

public BEC_2_6_6_SystemObject bem_initializeIfShould_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_ta_ph = beva_inst.bemd_2(-256440385, bevt_1_ta_ph, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 22*/ {
bevt_3_ta_ph = bem_initializeIt_1(beva_inst);
return bevt_3_ta_ph;
} /* Line: 23*/
bevt_4_ta_ph = beva_inst.bemd_0(-1363819567);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitConstruct_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 43*/ {
bevl_init = beva_inst;

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 50*/
return bevl_init;
} /*method end*/
public BEC_2_6_11_SystemInitializer bem_notNullInitDefault_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_init = null;

      bevl_init = beva_inst.bemc_getInitial();
      bevl_init.bemd_0(1948584685);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitIt_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 96*/ {
bevl_init = beva_inst;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = bevl_init.bemd_2(-256440385, bevt_2_ta_ph, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 98*/ {
bevl_init.bemd_0(1948584685);
} /* Line: 99*/

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 107*/
return bevl_init;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initializeIt_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 136*/ {
bevl_init = beva_inst;
bevl_init.bemd_0(1948584685);

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 145*/
return bevl_init;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {22, 22, 22, 23, 23, 25, 25, 43, 43, 44, 56, 72, 96, 96, 97, 98, 98, 98, 99, 113, 136, 136, 137, 138, 151};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 26, 27, 29, 30, 37, 42, 43, 47, 53, 64, 69, 70, 71, 72, 73, 75, 80, 87, 92, 93, 94, 98};
/* BEGIN LINEINFO 
assign 1 22 22
new 0 22 22
assign 1 22 23
new 0 22 23
assign 1 22 24
can 2 22 24
assign 1 23 26
initializeIt 1 23 26
return 1 23 27
assign 1 25 29
new 0 25 29
return 1 25 30
assign 1 43 37
undef 1 43 42
assign 1 44 43
return 1 56 47
default 0 72 53
assign 1 96 64
undef 1 96 69
assign 1 97 70
assign 1 98 71
new 0 98 71
assign 1 98 72
new 0 98 72
assign 1 98 73
can 2 98 73
default 0 99 75
return 1 113 80
assign 1 136 87
undef 1 136 92
assign 1 137 93
default 0 138 94
return 1 151 98
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1363819567: return bem_new_0();
case -467511392: return bem_toString_0();
case -793241295: return bem_iteratorGet_0();
case 1890854002: return bem_tagGet_0();
case -447432319: return bem_many_0();
case -105946774: return bem_serializeToString_0();
case -1760538533: return bem_classNameGet_0();
case -1323898541: return bem_toAny_0();
case -1188922735: return bem_echo_0();
case 1092105192: return bem_hashGet_0();
case 1652521523: return bem_serializeContents_0();
case 1319388306: return bem_copy_0();
case -921473949: return bem_fieldNamesGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case 1597327951: return bem_create_0();
case 7254011: return bem_fieldIteratorGet_0();
case 895193825: return bem_once_0();
case -1387831588: return bem_print_0();
case 371157924: return bem_sourceFileNameGet_0();
case -39165288: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1849559275: return bem_initializeIt_1(bevd_0);
case -958309746: return bem_notNullInitConstruct_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -893860329: return bem_notNullInitIt_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 867136276: return bem_notNullInitDefault_1(bevd_0);
case 715396010: return bem_initializeIfShould_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemInitializer_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_11_SystemInitializer_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_11_SystemInitializer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst = (BEC_2_6_11_SystemInitializer) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_type;
}
}
}
