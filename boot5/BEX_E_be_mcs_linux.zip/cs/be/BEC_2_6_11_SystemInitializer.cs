namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_11_SystemInitializer : BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemInitializer() { }
static BEC_2_6_11_SystemInitializer() { }
private static byte[] becc_BEC_2_6_11_SystemInitializer_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_6_11_SystemInitializer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_11_SystemInitializer_bels_0 = {0x64,0x65,0x66,0x61,0x75,0x6C,0x74};
public static new BEC_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_inst;

public static new BET_2_6_11_SystemInitializer bece_BEC_2_6_11_SystemInitializer_bevs_type;

public BEC_2_6_6_SystemObject bem_initializeIfShould_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_inst.bemd_2(-1611590654, bevt_1_tmpany_phold, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 44 */ {
bevt_3_tmpany_phold = bem_initializeIt_1(beva_inst);
return bevt_3_tmpany_phold;
} /* Line: 45 */
bevt_4_tmpany_phold = beva_inst.bemd_0(1091579640);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitConstruct_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 65 */ {
bevl_init = beva_inst;

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 72 */
return bevl_init;
} /*method end*/
public BEC_2_6_11_SystemInitializer bem_notNullInitDefault_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_init = null;

      bevl_init = beva_inst.bemc_getInitial();
      bevl_init.bemd_0(-328331891);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_notNullInitIt_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevl_init = beva_inst;
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_6_11_SystemInitializer_bels_0));
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_tmpany_phold = bevl_init.bemd_2(-1611590654, bevt_2_tmpany_phold, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 120 */ {
bevl_init.bemd_0(-328331891);
} /* Line: 121 */

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 129 */
return bevl_init;
} /*method end*/
public BEC_2_6_6_SystemObject bem_initializeIt_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_6_6_SystemObject bevl_init = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

      bevl_init = beva_inst.bemc_getInitial();
      if (bevl_init == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevl_init = beva_inst;
bevl_init.bemd_0(-328331891);

          beva_inst.bemc_setInitial(bevl_init);
          } /* Line: 167 */
return bevl_init;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {44, 44, 44, 45, 45, 47, 47, 65, 65, 66, 78, 94, 118, 118, 119, 120, 120, 120, 121, 135, 158, 158, 159, 160, 173};
public static new int[] bevs_smnlec
 = new int[] {24, 25, 26, 28, 29, 31, 32, 39, 44, 45, 49, 55, 66, 71, 72, 73, 74, 75, 77, 82, 89, 94, 95, 96, 100};
/* BEGIN LINEINFO 
assign 1 44 24
new 0 44 24
assign 1 44 25
new 0 44 25
assign 1 44 26
can 2 44 26
assign 1 45 28
initializeIt 1 45 28
return 1 45 29
assign 1 47 31
new 0 47 31
return 1 47 32
assign 1 65 39
undef 1 65 44
assign 1 66 45
return 1 78 49
default 0 94 55
assign 1 118 66
undef 1 118 71
assign 1 119 72
assign 1 120 73
new 0 120 73
assign 1 120 74
new 0 120 74
assign 1 120 75
can 2 120 75
default 0 121 77
return 1 135 82
assign 1 158 89
undef 1 158 94
assign 1 159 95
default 0 160 96
return 1 173 100
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1091579640: return bem_new_0();
case -304660926: return bem_sourceFileNameGet_0();
case -448869219: return bem_print_0();
case 1017833055: return bem_many_0();
case -497450892: return bem_hashGet_0();
case 546322415: return bem_echo_0();
case -1616792218: return bem_deserializeClassNameGet_0();
case -275053926: return bem_fieldIteratorGet_0();
case 1747771860: return bem_classNameGet_0();
case -926676223: return bem_iteratorGet_0();
case 1062973207: return bem_serializationIteratorGet_0();
case -1442113467: return bem_create_0();
case 583026473: return bem_toAny_0();
case 1505927918: return bem_serializeContents_0();
case -1975328143: return bem_once_0();
case 1884049010: return bem_toString_0();
case -2039257540: return bem_tagGet_0();
case 1287866350: return bem_copy_0();
case 767177150: return bem_fieldNamesGet_0();
case -470506305: return bem_serializeToString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -162262858: return bem_initializeIfShould_1(bevd_0);
case -1132198926: return bem_sameType_1(bevd_0);
case -13945303: return bem_defined_1(bevd_0);
case -1680819360: return bem_undefined_1(bevd_0);
case -1361252397: return bem_notNullInitDefault_1(bevd_0);
case 1011958071: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2047213073: return bem_equals_1(bevd_0);
case -1507083548: return bem_otherClass_1(bevd_0);
case 205081622: return bem_sameObject_1(bevd_0);
case 486943805: return bem_notNullInitIt_1(bevd_0);
case 745295406: return bem_sameClass_1(bevd_0);
case 38080717: return bem_undef_1(bevd_0);
case -396792969: return bem_otherType_1(bevd_0);
case -1396938224: return bem_notEquals_1(bevd_0);
case -1916951160: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 13577034: return bem_def_1(bevd_0);
case -149148452: return bem_copyTo_1(bevd_0);
case -1732969657: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -942274895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 895761551: return bem_initializeIt_1(bevd_0);
case -414504478: return bem_notNullInitConstruct_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 276198978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1047719554: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1611590654: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -927828157: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 62716626: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -931383679: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1041543114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemInitializer_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_11_SystemInitializer_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_11_SystemInitializer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst = (BEC_2_6_11_SystemInitializer) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_11_SystemInitializer.bece_BEC_2_6_11_SystemInitializer_bevs_type;
}
}
}
