namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemExceptionBuilder : BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
static BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_0, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_1, 25));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_2 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_2, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_3 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_3, 25));
public static new BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_thing;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
if (beva_klass == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
if (beva_eline == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 396 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 396 */ {
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_3_tmpany_phold;
} /* Line: 398 */
bevl_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toCsString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 432 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 433 */
 else  /* Line: 434 */ {
try  /* Line: 435 */ {
beva_ex.bemd_0(210264567);
} /* Line: 436 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 438 */
} /* Line: 437 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 445 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 446 */
 else  /* Line: 447 */ {
try  /* Line: 448 */ {
} /* Line: 448 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_tmpany_phold = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 451 */
} /* Line: 450 */
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_passBack == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 457 */ {
bevt_2_tmpany_phold = beva_passBack.bemd_1(524373837, bevp_except);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 457 */
 else  /* Line: 457 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 457 */ {
beva_passBack.bemd_1(1908719486, beva_sinClass);
beva_passBack.bemd_1(-1267557435, beva_sinMtd);
beva_passBack.bemd_1(1987967965, beva_sfname);
beva_passBack.bemd_1(-1509953739, beva_ilinep);
} /* Line: 461 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_except = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGet_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_thing = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {386, 387, 388, 396, 396, 0, 396, 396, 0, 0, 398, 398, 401, 427, 432, 432, 433, 433, 436, 438, 438, 444, 445, 445, 446, 446, 451, 451, 457, 457, 457, 0, 0, 0, 458, 459, 460, 461, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 36, 41, 42, 45, 50, 51, 54, 58, 59, 61, 66, 73, 78, 79, 80, 84, 88, 89, 99, 100, 105, 106, 107, 114, 115, 124, 129, 130, 132, 135, 139, 142, 143, 144, 145, 150, 153, 157, 160, 164, 167, 171, 174};
/* BEGIN LINEINFO 
assign 1 386 25
new 0 386 25
assign 1 387 26
new 0 387 26
assign 1 388 27
new 0 388 27
assign 1 396 36
undef 1 396 41
assign 1 0 42
assign 1 396 45
undef 1 396 50
assign 1 0 51
assign 1 0 54
assign 1 398 58
new 0 398 58
return 1 398 59
assign 1 401 61
new 0 401 61
return 1 427 66
assign 1 432 73
undef 1 432 78
assign 1 433 79
new 0 433 79
print 0 433 80
print 0 436 84
assign 1 438 88
new 0 438 88
print 0 438 89
assign 1 444 99
assign 1 445 100
undef 1 445 105
assign 1 446 106
new 0 446 106
print 0 446 107
assign 1 451 114
new 0 451 114
print 0 451 115
assign 1 457 124
def 1 457 129
assign 1 457 130
sameType 1 457 130
assign 1 0 132
assign 1 0 135
assign 1 0 139
klassNameSet 1 458 142
methodNameSet 1 459 143
fileNameSet 1 460 144
lineNumberSet 1 461 145
return 1 0 150
assign 1 0 153
return 1 0 157
assign 1 0 160
return 1 0 164
assign 1 0 167
return 1 0 171
assign 1 0 174
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 460304834: return bem_fieldIteratorGet_0();
case 607966049: return bem_serializationIteratorGet_0();
case -1533121038: return bem_new_0();
case -853598946: return bem_serializeContents_0();
case -1233972717: return bem_create_0();
case -1569136637: return bem_default_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 1307328857: return bem_toAny_0();
case -827921680: return bem_copy_0();
case 1165489654: return bem_sourceFileNameGet_0();
case 702299808: return bem_thingGet_0();
case 466290922: return bem_iteratorGet_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -590451146: return bem_serializeToString_0();
case -1802544452: return bem_many_0();
case -403586319: return bem_lastStrGet_0();
case 247385301: return bem_toString_0();
case 210264567: return bem_print_0();
case 2043795865: return bem_echo_0();
case 212191548: return bem_tagGet_0();
case -315420442: return bem_once_0();
case -1306319220: return bem_exceptGet_0();
case -1883081562: return bem_intGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1129614215: return bem_printException_1(bevd_0);
case 443386631: return bem_sendToConsole_1(bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2355250: return bem_thingSet_1(bevd_0);
case 1787518229: return bem_intSet_1(bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case 676185325: return bem_exceptSet_1(bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case 858958646: return bem_lastStrSet_1(bevd_0);
case 172009000: return bem_otherType_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1394501153: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) {
switch (callId) {
case -1500783908: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return base.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
}
}
