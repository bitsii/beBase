namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemExceptionBuilder : BEC_2_6_6_SystemObject {
public BEC_2_6_16_SystemExceptionBuilder() { }
static BEC_2_6_16_SystemExceptionBuilder() { }
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x42,0x75,0x69,0x6C,0x64,0x65,0x72};
private static byte[] becc_BEC_2_6_16_SystemExceptionBuilder_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_0 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x2C,0x20,0x70,0x61,0x73,0x73,0x65,0x64,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_0, 51));
private static byte[] bece_BEC_2_6_16_SystemExceptionBuilder_bels_1 = {0x55,0x6E,0x61,0x62,0x6C,0x65,0x20,0x74,0x6F,0x20,0x70,0x72,0x69,0x6E,0x74,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_1, 25));
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_0, 51));
private static BEC_2_4_6_TextString bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_6_16_SystemExceptionBuilder_bels_1, 25));
public static new BEC_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;

public static new BET_2_6_16_SystemExceptionBuilder bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;

public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_6_SystemObject bevp_thing;
public BEC_2_6_6_SystemObject bevp_int;
public BEC_2_6_6_SystemObject bevp_lastStr;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_default_0() {
bevp_except = (new BEC_2_6_9_SystemException());
bevp_thing = (new BEC_2_6_5_SystemThing()).bem_new_0();
bevp_int = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getLineForEmitLine_2(BEC_2_4_6_TextString beva_klass, BEC_2_4_3_MathInt beva_eline) {
BEC_2_4_3_MathInt bevl_line = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
if (beva_klass == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 421*/ {
if (beva_eline == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 421*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 421*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 421*/ {
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
return bevt_3_ta_ph;
} /* Line: 423*/
bevl_line = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

       bevl_line.bevi_int = 
         be.BECS_Runtime.getNlcForNlec(beva_klass.bems_toCsString(),
           beva_eline.bevi_int);
     return bevl_line;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_printException_1(BEC_2_6_6_SystemObject beva_ex) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
if (beva_ex == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 457*/ {
bevt_1_ta_ph = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_0;
bevt_1_ta_ph.bem_print_0();
} /* Line: 458*/
 else /* Line: 459*/ {
try /* Line: 460*/ {
beva_ex.bemd_0(-1754478112);
} /* Line: 461*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_ta_ph = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_1;
bevt_2_ta_ph.bem_print_0();
} /* Line: 463*/
} /* Line: 462*/
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_sendToConsole_1(BEC_2_6_6_SystemObject beva_ex) {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevp_lastStr = null;
if (beva_ex == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 470*/ {
bevt_1_ta_ph = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_2;
bevt_1_ta_ph.bem_print_0();
} /* Line: 471*/
 else /* Line: 472*/ {
try /* Line: 473*/ {
} /* Line: 473*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_2_ta_ph = bece_BEC_2_6_16_SystemExceptionBuilder_bevo_3;
bevt_2_ta_ph.bem_print_0();
} /* Line: 476*/
} /* Line: 475*/
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_buildException_6(BEC_2_6_6_SystemObject beva_passBack, BEC_2_6_6_SystemObject beva_smsg, BEC_2_6_6_SystemObject beva_sinClass, BEC_2_6_6_SystemObject beva_sinMtd, BEC_2_6_6_SystemObject beva_sfname, BEC_2_6_6_SystemObject beva_ilinep) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
if (beva_passBack == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 482*/ {
bevt_2_ta_ph = beva_passBack.bemd_1(-8419053, bevp_except);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 482*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 482*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 482*/
 else /* Line: 482*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 482*/ {
beva_passBack.bemd_1(65088657, beva_sinClass);
beva_passBack.bemd_1(328346857, beva_sinMtd);
beva_passBack.bemd_1(-1556501171, beva_sfname);
beva_passBack.bemd_1(1606810499, beva_ilinep);
} /* Line: 486*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGetDirect_0() {
return bevp_except;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_except = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_exceptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_except = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGet_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_6_SystemObject bem_thingGetDirect_0() {
return bevp_thing;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_thing = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_thingSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_thing = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_6_SystemObject bem_intGetDirect_0() {
return bevp_int;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_int = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_int = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGet_0() {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastStrGetDirect_0() {
return bevp_lastStr;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lastStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_16_SystemExceptionBuilder bem_lastStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lastStr = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {411, 412, 413, 421, 421, 0, 421, 421, 0, 0, 423, 423, 426, 452, 457, 457, 458, 458, 461, 463, 463, 469, 470, 470, 471, 471, 476, 476, 482, 482, 482, 0, 0, 0, 483, 484, 485, 486, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 37, 42, 43, 46, 51, 52, 55, 59, 60, 62, 67, 74, 79, 80, 81, 85, 89, 90, 100, 101, 106, 107, 108, 115, 116, 125, 130, 131, 133, 136, 140, 143, 144, 145, 146, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189, 193, 196, 199, 203};
/* BEGIN LINEINFO 
assign 1 411 26
new 0 411 26
assign 1 412 27
new 0 412 27
assign 1 413 28
new 0 413 28
assign 1 421 37
undef 1 421 42
assign 1 0 43
assign 1 421 46
undef 1 421 51
assign 1 0 52
assign 1 0 55
assign 1 423 59
new 0 423 59
return 1 423 60
assign 1 426 62
new 0 426 62
return 1 452 67
assign 1 457 74
undef 1 457 79
assign 1 458 80
new 0 458 80
print 0 458 81
print 0 461 85
assign 1 463 89
new 0 463 89
print 0 463 90
assign 1 469 100
assign 1 470 101
undef 1 470 106
assign 1 471 107
new 0 471 107
print 0 471 108
assign 1 476 115
new 0 476 115
print 0 476 116
assign 1 482 125
def 1 482 130
assign 1 482 131
sameType 1 482 131
assign 1 0 133
assign 1 0 136
assign 1 0 140
klassNameSet 1 483 143
methodNameSet 1 484 144
fileNameSet 1 485 145
lineNumberSet 1 486 146
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
return 1 0 193
return 1 0 196
assign 1 0 199
assign 1 0 203
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 119461913: return bem_tagGet_0();
case 281444821: return bem_fieldIteratorGet_0();
case -146225034: return bem_default_0();
case 1650533017: return bem_thingGetDirect_0();
case -678541085: return bem_classNameGet_0();
case -1754478112: return bem_print_0();
case -2017009146: return bem_new_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -1005119995: return bem_many_0();
case 1182578865: return bem_intGetDirect_0();
case -1475550710: return bem_create_0();
case -225870373: return bem_serializeToString_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 2045941275: return bem_iteratorGet_0();
case -744679096: return bem_fieldNamesGet_0();
case -1486279572: return bem_serializeContents_0();
case -1090274313: return bem_lastStrGetDirect_0();
case -1275325619: return bem_toString_0();
case 501088997: return bem_sourceFileNameGet_0();
case -105829593: return bem_exceptGet_0();
case -639297756: return bem_toAny_0();
case -545556484: return bem_once_0();
case 1621126017: return bem_thingGet_0();
case 611702865: return bem_copy_0();
case -305692229: return bem_exceptGetDirect_0();
case -1583672278: return bem_echo_0();
case -695132453: return bem_intGet_0();
case -51860127: return bem_lastStrGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -361389786: return bem_thingSetDirect_1(bevd_0);
case 107935681: return bem_intSetDirect_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case -290893625: return bem_lastStrSet_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 857942559: return bem_sendToConsole_1(bevd_0);
case -2035468339: return bem_printException_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case 1232799663: return bem_lastStrSetDirect_1(bevd_0);
case -402958230: return bem_intSet_1(bevd_0);
case -1939455171: return bem_exceptSetDirect_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case 2131075972: return bem_thingSet_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case 1744665679: return bem_exceptSet_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 633046878: return bem_getLineForEmitLine_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_6(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4, BEC_2_6_6_SystemObject bevd_5) {
switch (callId) {
case 596867975: return bem_buildException_6(bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
return base.bemd_6(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4, bevd_5);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemExceptionBuilder_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemExceptionBuilder_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemExceptionBuilder();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst = (BEC_2_6_16_SystemExceptionBuilder) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_16_SystemExceptionBuilder.bece_BEC_2_6_16_SystemExceptionBuilder_bevs_type;
}
}
}
