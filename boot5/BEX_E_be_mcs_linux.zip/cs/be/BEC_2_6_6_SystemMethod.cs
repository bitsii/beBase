namespace be {
/* IO:File: source/base/Functions.be */
public class BEC_2_6_6_SystemMethod : BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemMethod() { }
static BEC_2_6_6_SystemMethod() { }
private static byte[] becc_BEC_2_6_6_SystemMethod_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] becc_BEC_2_6_6_SystemMethod_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_inst;

public static new BET_2_6_6_SystemMethod bece_BEC_2_6_6_SystemMethod_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_4_3_MathInt bevp_ac;
public virtual BEC_2_6_6_SystemMethod bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_4_3_MathInt beva__ac) {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_ac = beva__ac;
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(973582611, bevp_callName, beva_args);
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGetDirect_0() {
return bevp_target;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGetDirect_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_acGet_0() {
return bevp_ac;
} /*method end*/
public BEC_2_6_6_SystemObject bem_acGetDirect_0() {
return bevp_ac;
} /*method end*/
public virtual BEC_2_6_6_SystemMethod bem_acSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemMethod bem_acSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ac = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {37, 38, 39, 45, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 18, 23, 24, 27, 30, 33, 37, 41, 44, 47, 51, 55, 58, 61, 65};
/* BEGIN LINEINFO 
assign 1 37 16
assign 1 38 17
assign 1 39 18
assign 1 45 23
invoke 2 45 23
return 1 46 24
return 1 0 27
return 1 0 30
assign 1 0 33
assign 1 0 37
return 1 0 41
return 1 0 44
assign 1 0 47
assign 1 0 51
return 1 0 55
return 1 0 58
assign 1 0 61
assign 1 0 65
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1115941233: return bem_hashGet_0();
case 1978340744: return bem_copy_0();
case 347445468: return bem_deserializeClassNameGet_0();
case 1739040137: return bem_fieldIteratorGet_0();
case -1497387944: return bem_many_0();
case 876979386: return bem_iteratorGet_0();
case -1820718044: return bem_echo_0();
case 855089063: return bem_toAny_0();
case -1718750264: return bem_tagGet_0();
case 1044385788: return bem_new_0();
case -1936404363: return bem_create_0();
case -485032950: return bem_print_0();
case 855005444: return bem_callNameGetDirect_0();
case 1846641427: return bem_classNameGet_0();
case 1139687182: return bem_serializeToString_0();
case -1105369305: return bem_acGetDirect_0();
case 1434856859: return bem_acGet_0();
case -1532378927: return bem_targetGetDirect_0();
case 262448459: return bem_fieldNamesGet_0();
case -1287291624: return bem_toString_0();
case 1516511629: return bem_serializeContents_0();
case -1372410892: return bem_targetGet_0();
case -1242864862: return bem_sourceFileNameGet_0();
case 1693315475: return bem_callNameGet_0();
case -380774728: return bem_serializationIteratorGet_0();
case 1388220454: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 477404510: return bem_undefined_1(bevd_0);
case 1532085691: return bem_callNameSetDirect_1(bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 222127306: return bem_targetSetDirect_1(bevd_0);
case -235744269: return bem_acSet_1(bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case -847200836: return bem_def_1(bevd_0);
case -237202610: return bem_callNameSet_1(bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case -1630312341: return bem_acSetDirect_1(bevd_0);
case -1521148016: return bem_targetSet_1(bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -557582082: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemMethod_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_6_SystemMethod_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_6_SystemMethod();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst = (BEC_2_6_6_SystemMethod) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_6_SystemMethod.bece_BEC_2_6_6_SystemMethod_bevs_type;
}
}
}
