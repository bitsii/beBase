namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap : BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
static BEC_2_9_3_ContainerMap() { }
private static byte[] becc_BEC_2_9_3_ContainerMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_3_ContainerMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_inst;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_21_ContainerMapSerializationIterator) (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_6_tmpany_phold = bevl_other.bem_sizeGet_0();
bevt_7_tmpany_phold = bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int != bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 126 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 126 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 126 */ {
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /* Line: 127 */
bevt_0_tmpany_loop = bem_mapIteratorGet_0();
while (true)
 /* Line: 129 */ {
bevt_9_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 129 */ {
bevl_i = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_10_tmpany_phold = bevl_i.bemd_0(-1908822291);
bevl_v = bevl_other.bem_get_1(bevt_10_tmpany_phold);
if (bevl_v == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_13_tmpany_phold = bevl_i.bemd_0(70279241);
if (bevt_13_tmpany_phold == null) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 131 */ {
if (bevl_v == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_16_tmpany_phold = bevl_i.bemd_0(70279241);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_1(938569326, bevl_v);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 131 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 131 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 131 */ {
bevt_17_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_17_tmpany_phold;
} /* Line: 131 */
} /* Line: 131 */
 else  /* Line: 129 */ {
break;
} /* Line: 129 */
} /* Line: 129 */
bevt_18_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_18_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1078813239);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 137 */ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
 /* Line: 140 */ {
bevt_3_tmpany_phold = bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1078813239);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 140 */ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 141 */
 else  /* Line: 140 */ {
break;
} /* Line: 140 */
} /* Line: 140 */
bevp_slots = bevl_slt;
} /* Line: 143 */
if (bevp_innerPutAdded.bevi_bool) /* Line: 145 */ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 146 */
return this;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_valueIteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_3_16_ContainerMapKeyValueIterator) (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_addValue_1(BEC_2_6_6_SystemObject beva_other) {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
if (beva_other == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_2_tmpany_phold = beva_other.bemd_1(343567700, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_tmpany_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
 /* Line: 174 */ {
bevt_3_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 174 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_4_tmpany_phold = bevl_x.bemd_0(-1908822291);
bevt_5_tmpany_phold = bevl_x.bemd_0(70279241);
bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 175 */
 else  /* Line: 174 */ {
break;
} /* Line: 174 */
} /* Line: 174 */
} /* Line: 174 */
 else  /* Line: 172 */ {
bevt_6_tmpany_phold = beva_other.bemd_1(343567700, bevp_baseNode);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 177 */ {
bevt_7_tmpany_phold = beva_other.bemd_0(-1908822291);
bevt_8_tmpany_phold = beva_other.bemd_0(70279241);
bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
} /* Line: 178 */
 else  /* Line: 179 */ {
bem_put_2(beva_other, beva_other);
} /* Line: 180 */
} /* Line: 172 */
} /* Line: 172 */
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_toRet = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = bem_mapIteratorGet_0();
while (true)
 /* Line: 187 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevl_x = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_3_tmpany_phold = bevl_x.bemd_0(-1908822291);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-1857272468, beva_prefix);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 188 */ {
bevt_4_tmpany_phold = bevl_x.bemd_0(-1908822291);
bevt_5_tmpany_phold = bevl_x.bemd_0(70279241);
bevl_toRet.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
} /* Line: 189 */
} /* Line: 188 */
 else  /* Line: 187 */ {
break;
} /* Line: 187 */
} /* Line: 187 */
return bevl_toRet;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {108, 108, 112, 113, 114, 115, 116, 117, 121, 121, 125, 126, 126, 0, 126, 126, 126, 126, 0, 0, 127, 127, 129, 0, 129, 129, 130, 130, 131, 131, 0, 131, 131, 131, 131, 131, 0, 0, 0, 0, 0, 0, 131, 131, 0, 0, 131, 131, 133, 133, 137, 137, 138, 139, 140, 140, 141, 143, 146, 151, 151, 155, 155, 159, 159, 163, 163, 167, 167, 171, 171, 172, 173, 174, 0, 174, 174, 175, 175, 175, 177, 178, 178, 178, 180, 186, 187, 0, 187, 187, 188, 188, 189, 189, 189, 192};
public static new int[] bevs_smnlec
 = new int[] {11, 12, 16, 17, 18, 19, 20, 21, 26, 27, 52, 53, 58, 59, 62, 63, 64, 69, 70, 73, 77, 78, 80, 80, 83, 85, 86, 87, 88, 93, 94, 97, 98, 103, 104, 109, 110, 113, 117, 120, 123, 127, 130, 131, 133, 136, 140, 141, 148, 149, 157, 158, 160, 161, 164, 165, 167, 173, 176, 182, 183, 187, 188, 192, 193, 197, 198, 202, 203, 217, 222, 223, 225, 226, 226, 229, 231, 232, 233, 234, 242, 244, 245, 246, 249, 264, 265, 265, 268, 270, 271, 272, 274, 275, 276, 283};
/* BEGIN LINEINFO 
assign 1 108 11
new 0 108 11
new 1 108 12
assign 1 112 16
new 1 112 16
assign 1 113 17
assign 1 114 18
new 0 114 18
assign 1 115 19
new 0 115 19
assign 1 116 20
new 0 116 20
assign 1 117 21
new 0 117 21
assign 1 121 26
new 1 121 26
return 1 121 27
assign 1 125 52
assign 1 126 53
undef 1 126 58
assign 1 0 59
assign 1 126 62
sizeGet 0 126 62
assign 1 126 63
sizeGet 0 126 63
assign 1 126 64
notEquals 1 126 69
assign 1 0 70
assign 1 0 73
assign 1 127 77
new 0 127 77
return 1 127 78
assign 1 129 80
mapIteratorGet 0 0 80
assign 1 129 83
hasNextGet 0 129 83
assign 1 129 85
nextGet 0 129 85
assign 1 130 86
keyGet 0 130 86
assign 1 130 87
get 1 130 87
assign 1 131 88
undef 1 131 93
assign 1 0 94
assign 1 131 97
valueGet 0 131 97
assign 1 131 98
undef 1 131 103
assign 1 131 104
def 1 131 109
assign 1 0 110
assign 1 0 113
assign 1 0 117
assign 1 0 120
assign 1 0 123
assign 1 0 127
assign 1 131 130
valueGet 0 131 130
assign 1 131 131
notEquals 1 131 131
assign 1 0 133
assign 1 0 136
assign 1 131 140
new 0 131 140
return 1 131 141
assign 1 133 148
new 0 133 148
return 1 133 149
assign 1 137 157
innerPut 4 137 157
assign 1 137 158
not 0 137 158
assign 1 138 160
assign 1 139 161
rehash 1 139 161
assign 1 140 164
innerPut 4 140 164
assign 1 140 165
not 0 140 165
assign 1 141 167
rehash 1 141 167
assign 1 143 173
assign 1 146 176
increment 0 146 176
assign 1 151 182
new 1 151 182
return 1 151 183
assign 1 155 187
valueIteratorGet 0 155 187
return 1 155 188
assign 1 159 192
new 1 159 192
return 1 159 193
assign 1 163 197
new 1 163 197
return 1 163 198
assign 1 167 202
new 1 167 202
return 1 167 203
assign 1 171 217
def 1 171 222
assign 1 172 223
sameType 1 172 223
assign 1 173 225
assign 1 174 226
mapIteratorGet 0 0 226
assign 1 174 229
hasNextGet 0 174 229
assign 1 174 231
nextGet 0 174 231
assign 1 175 232
keyGet 0 175 232
assign 1 175 233
valueGet 0 175 233
put 2 175 234
assign 1 177 242
sameType 1 177 242
assign 1 178 244
keyGet 0 178 244
assign 1 178 245
valueGet 0 178 245
put 2 178 246
put 2 180 249
assign 1 186 264
new 0 186 264
assign 1 187 265
mapIteratorGet 0 0 265
assign 1 187 268
hasNextGet 0 187 268
assign 1 187 270
nextGet 0 187 270
assign 1 188 271
keyGet 0 188 271
assign 1 188 272
begins 1 188 272
assign 1 189 274
keyGet 0 189 274
assign 1 189 275
valueGet 0 189 275
put 2 189 276
return 1 192 283
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1090256343: return bem_multiGet_0();
case 820088259: return bem_echo_0();
case -617246235: return bem_nodeIteratorGet_0();
case -2143843780: return bem_tagGet_0();
case 1829615340: return bem_fieldIteratorGet_0();
case -693169976: return bem_serializeToString_0();
case 628114265: return bem_many_0();
case 1870212438: return bem_relGet_0();
case 477578396: return bem_keyValueIteratorGet_0();
case -388275022: return bem_sizeGet_0();
case 386499474: return bem_deserializeClassNameGet_0();
case -719548369: return bem_baseNodeGet_0();
case 97896812: return bem_slotsGet_0();
case -289190594: return bem_new_0();
case -536798028: return bem_nodesGet_0();
case 1491689624: return bem_valueIteratorGet_0();
case -1896702956: return bem_serializeContents_0();
case -1710921376: return bem_iteratorGet_0();
case -383639502: return bem_keyIteratorGet_0();
case 154399642: return bem_hashGet_0();
case 1110687349: return bem_serializationIteratorGet_0();
case -288685906: return bem_setIteratorGet_0();
case -1679072038: return bem_toString_0();
case -682270320: return bem_valuesGet_0();
case -1289887071: return bem_moduGet_0();
case 1606100185: return bem_toAny_0();
case -86198663: return bem_print_0();
case 468841666: return bem_sourceFileNameGet_0();
case 1055362490: return bem_mapIteratorGet_0();
case 1006123506: return bem_notEmptyGet_0();
case 639073446: return bem_isEmptyGet_0();
case 596238408: return bem_keysGet_0();
case 402795231: return bem_once_0();
case -457712006: return bem_classNameGet_0();
case 737689510: return bem_innerPutAddedGet_0();
case 1323527258: return bem_copy_0();
case 10194441: return bem_clear_0();
case -285521200: return bem_create_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 2033308650: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 405603043: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759835639: return bem_defined_1(bevd_0);
case -1134002561: return bem_get_1(bevd_0);
case 1958076839: return bem_undefined_1(bevd_0);
case -1579329003: return bem_addValue_1(bevd_0);
case -1718544897: return bem_relSet_1(bevd_0);
case 2086659962: return bem_sameObject_1(bevd_0);
case 1519077869: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 542560005: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1318089914: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1253393632: return bem_def_1(bevd_0);
case -1211467604: return bem_copyTo_1(bevd_0);
case -383607716: return bem_put_1(bevd_0);
case -432261146: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -867821369: return bem_delete_1(bevd_0);
case -1751025233: return bem_multiSet_1(bevd_0);
case 743628976: return bem_baseNodeSet_1(bevd_0);
case -1694742512: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 365385951: return bem_equals_1(bevd_0);
case -2019094896: return bem_sizeSet_1(bevd_0);
case 2069301731: return bem_has_1(bevd_0);
case 938569326: return bem_notEquals_1(bevd_0);
case -1927736361: return bem_slotsSet_1(bevd_0);
case -641584584: return bem_sameClass_1(bevd_0);
case 918372241: return bem_moduSet_1(bevd_0);
case -1706185549: return bem_otherType_1(bevd_0);
case 713999383: return bem_undef_1(bevd_0);
case -861317881: return bem_otherClass_1(bevd_0);
case 723568309: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 343567700: return bem_sameType_1(bevd_0);
case -1185435345: return bem_innerPutAddedSet_1(bevd_0);
case -1770369050: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 823180387: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1360504071: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -2109777534: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1389614349: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1936973: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1125341844: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1064357370: return bem_put_2(bevd_0, bevd_1);
case -1447567526: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1790570920: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1812156494: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1299212473: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callCase) {
case -93266094: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callCase, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_3_ContainerMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst = (BEC_2_9_3_ContainerMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst;
}
}
}
