namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_10_XmlXTokenizer : BEC_2_6_6_SystemObject {
public BEC_2_3_10_XmlXTokenizer() { }
static BEC_2_3_10_XmlXTokenizer() { }
private static byte[] becc_BEC_2_3_10_XmlXTokenizer_clname = {0x58,0x6D,0x6C,0x3A,0x58,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_3_10_XmlXTokenizer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_10_XmlXTokenizer_bels_0 = {0x3C,0x3E,0x3D,0x2F,0x3F,0x21,0x20,0x22};
public static new BEC_2_3_10_XmlXTokenizer bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;

public static new BET_2_3_10_XmlXTokenizer bece_BEC_2_3_10_XmlXTokenizer_bevs_type;

public BEC_2_4_9_TextTokenizer bevp_tok;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_3_10_XmlXTokenizer bem_default_0() {
BEC_2_4_6_TextString bevl_tokString = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_tokString = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_3_10_XmlXTokenizer_bels_0));
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_tok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevl_tokString, bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_9_TextTokenizer bem_tokGet_0() {
return bevp_tok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokGetDirect_0() {
return bevp_tok;
} /*method end*/
public virtual BEC_2_3_10_XmlXTokenizer bem_tokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_3_10_XmlXTokenizer bem_tokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {126, 128, 128, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 21, 22, 26, 29, 32, 36};
/* BEGIN LINEINFO 
assign 1 126 20
new 0 126 20
assign 1 128 21
new 0 128 21
assign 1 128 22
new 2 128 22
return 1 0 26
return 1 0 29
assign 1 0 32
assign 1 0 36
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1778497682: return bem_serializeToString_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case -855016083: return bem_tokGetDirect_0();
case 1254813232: return bem_toAny_0();
case 167710369: return bem_print_0();
case -2120499139: return bem_iteratorGet_0();
case 1562662552: return bem_many_0();
case 39810102: return bem_tagGet_0();
case 1804773996: return bem_create_0();
case -1799416909: return bem_serializationIteratorGet_0();
case -1072030744: return bem_sourceFileNameGet_0();
case -1960297657: return bem_fieldIteratorGet_0();
case 959038598: return bem_echo_0();
case -1338195926: return bem_tokGet_0();
case 653349672: return bem_copy_0();
case 1769468354: return bem_fieldNamesGet_0();
case -1071008216: return bem_serializeContents_0();
case -73436994: return bem_new_0();
case -297374401: return bem_hashGet_0();
case 1307569908: return bem_default_0();
case -1067704397: return bem_once_0();
case -1628372783: return bem_classNameGet_0();
case 621276181: return bem_toString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1049172860: return bem_defined_1(bevd_0);
case 49545277: return bem_tokSetDirect_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -438924354: return bem_undefined_1(bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case 74523014: return bem_tokSet_1(bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_3_10_XmlXTokenizer_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_10_XmlXTokenizer_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_10_XmlXTokenizer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst = (BEC_2_3_10_XmlXTokenizer) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_10_XmlXTokenizer.bece_BEC_2_3_10_XmlXTokenizer_bevs_type;
}
}
}
