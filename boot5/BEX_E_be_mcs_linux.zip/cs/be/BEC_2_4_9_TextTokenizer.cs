namespace be {
/* IO:File: source/base/Tokenize.be */
public sealed class BEC_2_4_9_TextTokenizer : BEC_2_6_6_SystemObject {
public BEC_2_4_9_TextTokenizer() { }
static BEC_2_4_9_TextTokenizer() { }
private static byte[] becc_BEC_2_4_9_TextTokenizer_clname = {0x54,0x65,0x78,0x74,0x3A,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_4_9_TextTokenizer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_2 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_9_TextTokenizer_bevo_3 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_inst;

public static new BET_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_type;

public BEC_2_9_3_ContainerMap bevp_tmap;
public BEC_2_5_4_LogicBool bevp_includeTokens;
public BEC_2_4_9_TextTokenizer bem_new_1(BEC_2_4_6_TextString beva_delims) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_new_2(BEC_2_4_6_TextString beva_delims, BEC_2_5_4_LogicBool beva__includeTokens) {
bevp_includeTokens = beva__includeTokens;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokensStringSet_1(BEC_2_4_6_TextString beva_delims) {
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_4_17_TextMultiByteIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevp_tmap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_loop = beva_delims.bem_stringIteratorGet_0();
while (true)
 /* Line: 24 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevl_chi = bevt_0_tmpany_loop.bem_nextGet_0();
bevt_2_tmpany_phold = bevl_chi.bem_toString_0();
bevp_tmap.bem_put_2(bevl_chi, bevt_2_tmpany_phold);
} /* Line: 25 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_addToken_1(BEC_2_4_6_TextString beva__delim) {
BEC_2_4_6_TextString bevl_delim = null;
bevl_delim = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_delim.bem_addValue_1(beva__delim);
bevp_tmap.bem_put_2(bevl_delim, beva__delim);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_tmpany_phold = bem_tokenizeIterator_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_2(BEC_2_6_6_SystemObject beva_str, BEC_2_6_6_SystemObject beva_tokenAcceptor) {
BEC_2_4_9_TextTokenizer bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_tmpany_phold = (BEC_2_4_9_TextTokenizer) bem_tokenizeIterator_2(bevt_1_tmpany_phold, beva_tokenAcceptor);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokenizeIterator_2(BEC_2_6_6_SystemObject beva_i, BEC_2_6_6_SystemObject beva_acceptor) {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 46 */ {
bevt_0_tmpany_phold = beva_i.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 46 */ {
beva_i.bemd_1(-216199502, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_3_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_0;
if (bevt_3_tmpany_phold.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_5_tmpany_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(1683570810, bevt_5_tmpany_phold);
} /* Line: 51 */
if (bevp_includeTokens.bevi_bool) /* Line: 53 */ {
beva_acceptor.bemd_1(1683570810, bevl_cc);
} /* Line: 54 */
} /* Line: 53 */
 else  /* Line: 56 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 57 */
} /* Line: 49 */
 else  /* Line: 46 */ {
break;
} /* Line: 46 */
} /* Line: 46 */
bevt_7_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_1;
if (bevt_7_tmpany_phold.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_9_tmpany_phold = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(1683570810, bevt_9_tmpany_phold);
} /* Line: 61 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_1(BEC_2_6_6_SystemObject beva_i) {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
 /* Line: 69 */ {
bevt_0_tmpany_phold = beva_i.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 69 */ {
beva_i.bemd_1(-216199502, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 72 */ {
bevt_3_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_2;
if (bevt_3_tmpany_phold.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_5_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 74 */
if (bevp_includeTokens.bevi_bool) /* Line: 76 */ {
bevl_splits.bem_addValue_1(bevl_cc);
} /* Line: 77 */
} /* Line: 76 */
 else  /* Line: 79 */ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 80 */
} /* Line: 72 */
 else  /* Line: 69 */ {
break;
} /* Line: 69 */
} /* Line: 69 */
bevt_7_tmpany_phold = bevl_accum.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_9_TextTokenizer_bevo_3;
if (bevt_7_tmpany_phold.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_9_tmpany_phold = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_9_tmpany_phold);
} /* Line: 84 */
return bevl_splits;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGet_0() {
return bevp_tmap;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tmapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGet_0() {
return bevp_includeTokens;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_includeTokensSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {13, 14, 18, 19, 23, 24, 0, 24, 24, 25, 25, 30, 31, 32, 36, 36, 36, 40, 40, 40, 44, 45, 46, 47, 48, 49, 49, 50, 50, 50, 50, 51, 51, 54, 57, 60, 60, 60, 60, 61, 61, 66, 67, 68, 69, 70, 71, 72, 72, 73, 73, 73, 73, 74, 74, 77, 80, 83, 83, 83, 83, 84, 84, 86, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 24, 25, 33, 34, 34, 37, 39, 40, 41, 51, 52, 53, 59, 60, 61, 66, 67, 68, 84, 85, 88, 90, 91, 92, 97, 98, 99, 100, 105, 106, 107, 110, 114, 121, 122, 123, 128, 129, 130, 149, 150, 151, 154, 156, 157, 158, 163, 164, 165, 166, 171, 172, 173, 176, 180, 187, 188, 189, 194, 195, 196, 198, 201, 204, 208, 211};
/* BEGIN LINEINFO 
assign 1 13 19
new 0 13 19
tokensStringSet 1 14 20
assign 1 18 24
tokensStringSet 1 19 25
assign 1 23 33
new 0 23 33
assign 1 24 34
stringIteratorGet 0 0 34
assign 1 24 37
hasNextGet 0 24 37
assign 1 24 39
nextGet 0 24 39
assign 1 25 40
toString 0 25 40
put 2 25 41
assign 1 30 51
new 0 30 51
addValue 1 31 52
put 2 32 53
assign 1 36 59
new 1 36 59
assign 1 36 60
tokenizeIterator 1 36 60
return 1 36 61
assign 1 40 66
new 1 40 66
assign 1 40 67
tokenizeIterator 2 40 67
return 1 40 68
assign 1 44 84
new 0 44 84
assign 1 45 85
new 0 45 85
assign 1 46 88
hasNextGet 0 46 88
next 1 47 90
assign 1 48 91
get 1 48 91
assign 1 49 92
def 1 49 97
assign 1 50 98
sizeGet 0 50 98
assign 1 50 99
new 0 50 99
assign 1 50 100
greater 1 50 105
assign 1 51 106
extractString 0 51 106
acceptToken 1 51 107
acceptToken 1 54 110
addValue 1 57 114
assign 1 60 121
sizeGet 0 60 121
assign 1 60 122
new 0 60 122
assign 1 60 123
greater 1 60 128
assign 1 61 129
extractString 0 61 129
acceptToken 1 61 130
assign 1 66 149
new 0 66 149
assign 1 67 150
new 0 67 150
assign 1 68 151
new 0 68 151
assign 1 69 154
hasNextGet 0 69 154
next 1 70 156
assign 1 71 157
get 1 71 157
assign 1 72 158
def 1 72 163
assign 1 73 164
sizeGet 0 73 164
assign 1 73 165
new 0 73 165
assign 1 73 166
greater 1 73 171
assign 1 74 172
extractString 0 74 172
addValue 1 74 173
addValue 1 77 176
addValue 1 80 180
assign 1 83 187
sizeGet 0 83 187
assign 1 83 188
new 0 83 188
assign 1 83 189
greater 1 83 194
assign 1 84 195
extractString 0 84 195
addValue 1 84 196
return 1 86 198
return 1 0 201
assign 1 0 204
return 1 0 208
assign 1 0 211
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -386157741: return bem_serializeToString_0();
case 1028683886: return bem_toString_0();
case -1036233638: return bem_new_0();
case -1493103250: return bem_many_0();
case -1312519804: return bem_hashGet_0();
case 863669946: return bem_toAny_0();
case -454910570: return bem_create_0();
case -1057001629: return bem_copy_0();
case -354590014: return bem_print_0();
case 1048772166: return bem_echo_0();
case 714392359: return bem_classNameGet_0();
case -1874213289: return bem_tagGet_0();
case -362321661: return bem_deserializeClassNameGet_0();
case -354093047: return bem_serializationIteratorGet_0();
case -551298753: return bem_sourceFileNameGet_0();
case 654084467: return bem_iteratorGet_0();
case 661751202: return bem_tmapGet_0();
case 1836947478: return bem_serializeContents_0();
case -76505233: return bem_once_0();
case -1963468660: return bem_fieldIteratorGet_0();
case -1313679513: return bem_includeTokensGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -403482348: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1184340301: return bem_otherClass_1(bevd_0);
case 1301577712: return bem_sameClass_1(bevd_0);
case -1535071217: return bem_tokenize_1(bevd_0);
case -747350143: return bem_undef_1(bevd_0);
case -625315046: return bem_includeTokensSet_1(bevd_0);
case 2095964872: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -97465384: return bem_tokenizeIterator_1(bevd_0);
case -1978731115: return bem_sameType_1(bevd_0);
case 604922157: return bem_equals_1(bevd_0);
case 729561267: return bem_copyTo_1(bevd_0);
case -558198774: return bem_def_1(bevd_0);
case -965306462: return bem_undefined_1(bevd_0);
case 1672825312: return bem_notEquals_1(bevd_0);
case -1188536421: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -999936361: return bem_defined_1(bevd_0);
case 1639203817: return bem_addToken_1((BEC_2_4_6_TextString) bevd_0);
case 824179568: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -504315826: return bem_sameObject_1(bevd_0);
case 761242547: return bem_tmapSet_1(bevd_0);
case 1782921206: return bem_otherType_1(bevd_0);
case -1374275511: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -685506718: return bem_tokensStringSet_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 300820890: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -249962556: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 917608240: return bem_tokenize_2(bevd_0, bevd_1);
case -608983707: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 913536943: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1310736180: return bem_tokenizeIterator_2(bevd_0, bevd_1);
case -1192068648: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1655666515: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 478589859: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2045713194: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_4_9_TextTokenizer_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_9_TextTokenizer_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_9_TextTokenizer();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst = (BEC_2_4_9_TextTokenizer) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_type;
}
}
}
