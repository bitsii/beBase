namespace be {
/* IO:File: source/extended/Serialize.be */
public sealed class BEC_2_6_23_SystemNamedPropertiesIterator : BEC_2_6_6_SystemObject {
public BEC_2_6_23_SystemNamedPropertiesIterator() { }
static BEC_2_6_23_SystemNamedPropertiesIterator() { }
private static byte[] becc_BEC_2_6_23_SystemNamedPropertiesIterator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4E,0x61,0x6D,0x65,0x64,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x69,0x65,0x73,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_23_SystemNamedPropertiesIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_0 = {0x47,0x65,0x74};
private static byte[] bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_1 = {0x53,0x65,0x74};
public static new BEC_2_6_23_SystemNamedPropertiesIterator bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst;

public static new BET_2_6_23_SystemNamedPropertiesIterator bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_type;

public BEC_2_9_4_ContainerList bevp_propNames;
public BEC_3_9_4_8_ContainerListIterator bevp_subIter;
public BEC_2_6_6_SystemObject bevp_inst;
public BEC_2_9_4_ContainerList bevp_setArgs;
public BEC_2_9_4_ContainerList bevp_getArgs;
public BEC_2_6_23_SystemNamedPropertiesIterator bem_new_2(BEC_2_6_6_SystemObject beva__inst, BEC_2_9_4_ContainerList beva__propNames) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_propNames = beva__propNames;
bevp_inst = beva__inst;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_setArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_getArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_subIterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_subIter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 446 */ {
bevp_subIter = bevp_propNames.bem_arrayIteratorGet_0();
} /* Line: 447 */
return bevp_subIter;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hasNextGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nextGet_0() {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_nextGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_0));
bevl_name = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(478721017, bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_3_tmpany_phold = bevp_inst.bemd_2(1062769401, bevl_name, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 458 */ {
bevt_5_tmpany_phold = bevp_inst.bemd_2(2027545450, bevl_name, bevp_getArgs);
return bevt_5_tmpany_phold;
} /* Line: 459 */
return null;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_nextSet_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_6_TextString bevl_name = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_3_9_4_8_ContainerListIterator bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bem_subIterGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_nextGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_6_23_SystemNamedPropertiesIterator_bels_1));
bevl_name = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bemd_1(478721017, bevt_2_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_3_tmpany_phold = bevp_inst.bemd_2(1062769401, bevl_name, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 466 */ {
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_setArgs.bem_put_2(bevt_5_tmpany_phold, beva_value);
bevp_inst.bemd_2(2027545450, bevl_name, bevp_setArgs);
} /* Line: 468 */
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_skip_1(BEC_2_4_3_MathInt beva_multiNullCount) {
BEC_2_4_3_MathInt bevl_mi = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_mi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 473 */ {
if (bevl_mi.bevi_int < beva_multiNullCount.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 473 */ {
bem_nextSet_1(null);
bevl_mi = bevl_mi.bem_increment_0();
} /* Line: 473 */
 else  /* Line: 473 */ {
break;
} /* Line: 473 */
} /* Line: 473 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_propNamesGet_0() {
return bevp_propNames;
} /*method end*/
public BEC_2_9_4_ContainerList bem_propNamesGetDirect_0() {
return bevp_propNames;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_propNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_propNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propNames = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_subIterGetDirect_0() {
return bevp_subIter;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_subIterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_subIterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_subIter = (BEC_3_9_4_8_ContainerListIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instGet_0() {
return bevp_inst;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instGetDirect_0() {
return bevp_inst;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_instSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inst = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_instSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inst = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_setArgsGet_0() {
return bevp_setArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_setArgsGetDirect_0() {
return bevp_setArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_setArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_setArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_getArgsGet_0() {
return bevp_getArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_getArgsGetDirect_0() {
return bevp_getArgs;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_getArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_getArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_23_SystemNamedPropertiesIterator bem_getArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_getArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {437, 439, 440, 440, 441, 441, 446, 446, 447, 449, 453, 453, 453, 457, 457, 457, 457, 458, 458, 459, 459, 461, 465, 465, 465, 465, 466, 466, 467, 467, 468, 473, 473, 473, 474, 473, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 26, 27, 32, 37, 38, 40, 45, 46, 47, 57, 58, 59, 60, 61, 62, 64, 65, 67, 77, 78, 79, 80, 81, 82, 84, 85, 86, 93, 96, 101, 102, 103, 112, 115, 118, 122, 126, 129, 133, 137, 140, 143, 147, 151, 154, 157, 161, 165, 168, 171, 175};
/* BEGIN LINEINFO 
assign 1 437 22
assign 1 439 23
assign 1 440 24
new 0 440 24
assign 1 440 25
new 1 440 25
assign 1 441 26
new 0 441 26
assign 1 441 27
new 1 441 27
assign 1 446 32
undef 1 446 37
assign 1 447 38
arrayIteratorGet 0 447 38
return 1 449 40
assign 1 453 45
subIterGet 0 453 45
assign 1 453 46
hasNextGet 0 453 46
return 1 453 47
assign 1 457 57
subIterGet 0 457 57
assign 1 457 58
nextGet 0 457 58
assign 1 457 59
new 0 457 59
assign 1 457 60
add 1 457 60
assign 1 458 61
new 0 458 61
assign 1 458 62
can 2 458 62
assign 1 459 64
invoke 2 459 64
return 1 459 65
return 1 461 67
assign 1 465 77
subIterGet 0 465 77
assign 1 465 78
nextGet 0 465 78
assign 1 465 79
new 0 465 79
assign 1 465 80
add 1 465 80
assign 1 466 81
new 0 466 81
assign 1 466 82
can 2 466 82
assign 1 467 84
new 0 467 84
put 2 467 85
invoke 2 468 86
assign 1 473 93
new 0 473 93
assign 1 473 96
lesser 1 473 101
nextSet 1 474 102
assign 1 473 103
increment 0 473 103
return 1 0 112
return 1 0 115
assign 1 0 118
assign 1 0 122
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
return 1 0 140
assign 1 0 143
assign 1 0 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1043543071: return bem_create_0();
case -391394201: return bem_instGet_0();
case -1200514874: return bem_once_0();
case -1048585343: return bem_copy_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -2011984947: return bem_classNameGet_0();
case -1021558772: return bem_fieldIteratorGet_0();
case 795649196: return bem_serializationIteratorGet_0();
case -1800587860: return bem_serializeToString_0();
case -42539088: return bem_subIterGet_0();
case 190764838: return bem_toString_0();
case 976768273: return bem_fieldNamesGet_0();
case 451316734: return bem_new_0();
case 2022567405: return bem_tagGet_0();
case -1017732045: return bem_toAny_0();
case -204986197: return bem_print_0();
case 1286644729: return bem_nextGet_0();
case -193453355: return bem_iteratorGet_0();
case 395045729: return bem_hasNextGet_0();
case 1809869265: return bem_many_0();
case 45896654: return bem_instGetDirect_0();
case -705724140: return bem_subIterGetDirect_0();
case -1258486245: return bem_setArgsGetDirect_0();
case 590645844: return bem_getArgsGetDirect_0();
case -1852647932: return bem_serializeContents_0();
case -1087521398: return bem_propNamesGet_0();
case 445142236: return bem_getArgsGet_0();
case -477940854: return bem_hashGet_0();
case -733473578: return bem_propNamesGetDirect_0();
case 1283227000: return bem_setArgsGet_0();
case 1463816718: return bem_sourceFileNameGet_0();
case -1615839398: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 202406103: return bem_skip_1((BEC_2_4_3_MathInt) bevd_0);
case 1255352870: return bem_notEquals_1(bevd_0);
case 766884316: return bem_instSet_1(bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case 1588669902: return bem_subIterSetDirect_1(bevd_0);
case -1316500813: return bem_propNamesSetDirect_1(bevd_0);
case -974417776: return bem_undef_1(bevd_0);
case 1249232057: return bem_nextSet_1(bevd_0);
case 1555245362: return bem_subIterSet_1(bevd_0);
case 1352374403: return bem_setArgsSet_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 751902970: return bem_propNamesSet_1(bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case 408827018: return bem_instSetDirect_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
case -252330168: return bem_def_1(bevd_0);
case -1085546840: return bem_getArgsSet_1(bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case -1273015363: return bem_setArgsSetDirect_1(bevd_0);
case -1237007833: return bem_getArgsSetDirect_1(bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2111396893: return bem_new_2(bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(30, becc_BEC_2_6_23_SystemNamedPropertiesIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_6_23_SystemNamedPropertiesIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_23_SystemNamedPropertiesIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst = (BEC_2_6_23_SystemNamedPropertiesIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_23_SystemNamedPropertiesIterator.bece_BEC_2_6_23_SystemNamedPropertiesIterator_bevs_type;
}
}
}
