namespace be {
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor : BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
static BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static new BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;

public static new BET_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;

public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) {
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildTransport bem_transGet_0() {
return bevp_trans;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_transGetDirect_0() {
return bevp_trans;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_transSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGetDirect_0() {
return bevp_build;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildConstants bem_constGet_0() {
return bevp_const;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constGetDirect_0() {
return bevp_const;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_constSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {14, 15, 16, 17, 22, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 20, 25, 26, 32, 35, 38, 42, 46, 49, 52, 56, 60, 63, 66, 70, 74, 77, 80, 84};
/* BEGIN LINEINFO 
assign 1 14 17
assign 1 15 18
buildGet 0 15 18
assign 1 16 19
constantsGet 0 16 19
assign 1 17 20
ntypesGet 0 17 20
assign 1 22 25
nextDescendGet 0 22 25
return 1 22 26
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
return 1 0 74
return 1 0 77
assign 1 0 80
assign 1 0 84
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 501088997: return bem_sourceFileNameGet_0();
case -639297756: return bem_toAny_0();
case 281444821: return bem_fieldIteratorGet_0();
case 337956715: return bem_constGetDirect_0();
case -1486279572: return bem_serializeContents_0();
case -2023485577: return bem_ntypesGet_0();
case -1275325619: return bem_toString_0();
case -2017009146: return bem_new_0();
case 346243671: return bem_buildGet_0();
case -744679096: return bem_fieldNamesGet_0();
case -662650116: return bem_transGetDirect_0();
case -203313052: return bem_buildGetDirect_0();
case -1446962807: return bem_constGet_0();
case -1005119995: return bem_many_0();
case -1583672278: return bem_echo_0();
case 127149854: return bem_transGet_0();
case 611702865: return bem_copy_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case -1940708509: return bem_ntypesGetDirect_0();
case -1754478112: return bem_print_0();
case -678541085: return bem_classNameGet_0();
case -1475550710: return bem_create_0();
case 119461913: return bem_tagGet_0();
case -545556484: return bem_once_0();
case -225870373: return bem_serializeToString_0();
case 2045941275: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1682784492: return bem_end_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 917267977: return bem_ntypesSetDirect_1(bevd_0);
case -251646192: return bem_constSet_1(bevd_0);
case -1701452702: return bem_constSetDirect_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case 1256901554: return bem_buildSet_1(bevd_0);
case 511165170: return bem_buildSetDirect_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case -936766473: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1533144690: return bem_begin_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case 761666137: return bem_transSetDirect_1(bevd_0);
case -678431588: return bem_transSet_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1031858778: return bem_ntypesSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;
}
}
}
