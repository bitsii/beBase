namespace be {
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor : BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
static BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static new BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public virtual BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) {
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildTransport bem_transGet_0() {
return bevp_trans;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_5_BuildBuild bem_buildGet_0() {
return bevp_build;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildConstants bem_constGet_0() {
return bevp_const;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public virtual BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 16, 17, 18, 23, 23, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 16, 17, 22, 23, 29, 32, 36, 39, 43, 46, 50, 53};
/* BEGIN LINEINFO 
assign 1 15 14
assign 1 16 15
buildGet 0 16 15
assign 1 17 16
constantsGet 0 17 16
assign 1 18 17
ntypesGet 0 18 17
assign 1 23 22
nextDescendGet 0 23 22
return 1 23 23
return 1 0 29
assign 1 0 32
return 1 0 36
assign 1 0 39
return 1 0 43
assign 1 0 46
return 1 0 50
assign 1 0 53
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1862907585: return bem_transGet_0();
case -1026573604: return bem_buildGet_0();
case -1694731736: return bem_ntypesGet_0();
case 210264567: return bem_print_0();
case 2043795865: return bem_echo_0();
case 1165489654: return bem_sourceFileNameGet_0();
case -1233972717: return bem_create_0();
case 212191548: return bem_tagGet_0();
case -590451146: return bem_serializeToString_0();
case -315420442: return bem_once_0();
case -1533121038: return bem_new_0();
case 607966049: return bem_serializationIteratorGet_0();
case -827921680: return bem_copy_0();
case 1081968352: return bem_constGet_0();
case 466290922: return bem_iteratorGet_0();
case 247385301: return bem_toString_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -853598946: return bem_serializeContents_0();
case -1802544452: return bem_many_0();
case 460304834: return bem_fieldIteratorGet_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 1307328857: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1644787064: return bem_end_1(bevd_0);
case 172009000: return bem_otherType_1(bevd_0);
case 1070497437: return bem_transSet_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case -6357522: return bem_ntypesSet_1(bevd_0);
case -941597658: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case 1289711396: return bem_buildSet_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -256010896: return bem_constSet_1(bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1625639133: return bem_begin_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
}
}
