namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public class BEC_3_6_6_12_SystemThreadObjectLocker : BEC_2_6_6_SystemObject {
public BEC_3_6_6_12_SystemThreadObjectLocker() { }
static BEC_3_6_6_12_SystemThreadObjectLocker() { }
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x4C,0x6F,0x63,0x6B,0x65,0x72};
private static byte[] becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;

public static new BET_3_6_6_12_SystemThreadObjectLocker bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;

public BEC_3_6_6_4_SystemThreadLock bevp_lock;
public BEC_2_6_6_SystemObject bevp_obj;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) (new BEC_3_6_6_4_SystemThreadLock());
return this;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_new_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevl_e = null;
bem_new_0();
bevp_lock.bem_lock_0();
try /* Line: 951*/ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 953*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 956*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_oGet_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 962*/ {
bevl_r = bevp_obj;
bevp_lock.bem_unlock_0();
} /* Line: 964*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 967*/
return bevl_r;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getAndClear_0() {
BEC_2_6_6_SystemObject bevl_r = null;
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 974*/ {
bevl_r = bevp_obj;
bevp_obj = null;
bevp_lock.bem_unlock_0();
} /* Line: 977*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 980*/
return bevl_r;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_setIfClear_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_5_4_LogicBool bevl_res = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevp_lock.bem_lock_0();
bevl_res = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try /* Line: 988*/ {
if (bevp_obj == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 989*/ {
bevp_obj = beva__obj;
bevl_res = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 991*/
bevp_lock.bem_unlock_0();
} /* Line: 993*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 996*/
return bevl_res;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_oSet_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_2_6_6_SystemObject bevl_e = null;
bevp_lock.bem_lock_0();
try /* Line: 1003*/ {
bevp_obj = beva__obj;
bevp_lock.bem_unlock_0();
} /* Line: 1005*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_lock.bem_unlock_0();
throw new be.BECS_ThrowBack(bevl_e);
} /* Line: 1008*/
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectGet_0() {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_oGet_0();
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objectSet_1(BEC_2_6_6_SystemObject beva__obj) {
BEC_3_6_6_12_SystemThreadObjectLocker bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_3_6_6_12_SystemThreadObjectLocker) bem_oSet_1(beva__obj);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_3_6_6_4_SystemThreadLock bem_lockGet_0() {
return bevp_lock;
} /*method end*/
public BEC_3_6_6_4_SystemThreadLock bem_lockGetDirect_0() {
return bevp_lock;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_lockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lock = (BEC_3_6_6_4_SystemThreadLock) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_objGet_0() {
return bevp_obj;
} /*method end*/
public BEC_2_6_6_SystemObject bem_objGetDirect_0() {
return bevp_obj;
} /*method end*/
public virtual BEC_3_6_6_12_SystemThreadObjectLocker bem_objSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_obj = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_objSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_obj = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {941, 946, 950, 952, 953, 955, 956, 961, 963, 964, 966, 967, 969, 973, 975, 976, 977, 979, 980, 982, 986, 987, 989, 989, 990, 991, 993, 995, 996, 998, 1002, 1004, 1005, 1007, 1008, 1013, 1013, 1017, 1017, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 24, 25, 27, 28, 32, 33, 40, 42, 43, 47, 48, 50, 55, 57, 58, 59, 63, 64, 66, 72, 73, 75, 80, 81, 82, 84, 88, 89, 91, 95, 97, 98, 102, 103, 109, 110, 114, 115, 118, 121, 124, 128, 132, 135, 138, 142};
/* BEGIN LINEINFO 
assign 1 941 19
new 0 941 19
new 0 946 24
lock 0 950 25
assign 1 952 27
unlock 0 953 28
unlock 0 955 32
throw 1 956 33
lock 0 961 40
assign 1 963 42
unlock 0 964 43
unlock 0 966 47
throw 1 967 48
return 1 969 50
lock 0 973 55
assign 1 975 57
assign 1 976 58
unlock 0 977 59
unlock 0 979 63
throw 1 980 64
return 1 982 66
lock 0 986 72
assign 1 987 73
new 0 987 73
assign 1 989 75
undef 1 989 80
assign 1 990 81
assign 1 991 82
new 0 991 82
unlock 0 993 84
unlock 0 995 88
throw 1 996 89
return 1 998 91
lock 0 1002 95
assign 1 1004 97
unlock 0 1005 98
unlock 0 1007 102
throw 1 1008 103
assign 1 1013 109
oGet 0 1013 109
return 1 1013 110
assign 1 1017 114
oSet 1 1017 114
return 1 1017 115
return 1 0 118
return 1 0 121
assign 1 0 124
assign 1 0 128
return 1 0 132
return 1 0 135
assign 1 0 138
assign 1 0 142
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 501088997: return bem_sourceFileNameGet_0();
case 2124876785: return bem_lockGet_0();
case -639297756: return bem_toAny_0();
case 281444821: return bem_fieldIteratorGet_0();
case -1486279572: return bem_serializeContents_0();
case -1398266063: return bem_objectGet_0();
case -1275325619: return bem_toString_0();
case -2017009146: return bem_new_0();
case -1850062709: return bem_oGet_0();
case -744679096: return bem_fieldNamesGet_0();
case -1005119995: return bem_many_0();
case -1583672278: return bem_echo_0();
case 611702865: return bem_copy_0();
case -1638962758: return bem_lockGetDirect_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case -1754478112: return bem_print_0();
case 1786935340: return bem_objGetDirect_0();
case -678541085: return bem_classNameGet_0();
case -1475550710: return bem_create_0();
case 119461913: return bem_tagGet_0();
case -545556484: return bem_once_0();
case -1760634225: return bem_objGet_0();
case 1922445827: return bem_getAndClear_0();
case -225870373: return bem_serializeToString_0();
case 2045941275: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -847713218: return bem_objSetDirect_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -1698900309: return bem_new_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case -1827168340: return bem_lockSet_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case -916465787: return bem_setIfClear_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case 377885729: return bem_objSet_1(bevd_0);
case 1749631267: return bem_oSet_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1480999364: return bem_objectSet_1(bevd_0);
case 1470514536: return bem_lockSetDirect_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(26, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_3_6_6_12_SystemThreadObjectLocker_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_6_12_SystemThreadObjectLocker();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst = (BEC_3_6_6_12_SystemThreadObjectLocker) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_6_12_SystemThreadObjectLocker.bece_BEC_3_6_6_12_SystemThreadObjectLocker_bevs_type;
}
}
}
