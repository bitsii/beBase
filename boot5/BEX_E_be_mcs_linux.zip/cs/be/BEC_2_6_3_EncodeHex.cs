namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_3_EncodeHex : BEC_2_6_6_SystemObject {
public BEC_2_6_3_EncodeHex() { }
static BEC_2_6_3_EncodeHex() { }
private static byte[] becc_BEC_2_6_3_EncodeHex_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x65,0x78};
private static byte[] becc_BEC_2_6_3_EncodeHex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_6_3_EncodeHex_bels_0 = {0x49,0x6E,0x76,0x61,0x6C,0x69,0x64,0x20,0x68,0x65,0x78,0x20,0x73,0x74,0x72,0x69,0x6E,0x67,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_6_3_EncodeHex_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_6_3_EncodeHex_bels_0, 26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_5 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_6_3_EncodeHex_bevo_6 = (new BEC_2_4_3_MathInt(2));
public static new BEC_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_inst;

public static new BET_2_6_3_EncodeHex bece_BEC_2_6_3_EncodeHex_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_3_EncodeHex bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevl_ac = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_cur = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_0_tmpany_phold);
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_2_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_0;
bevt_1_tmpany_phold = bevl_ssz.bem_multiply_1(bevt_2_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
bevl_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 21 */ {
if (bevl_pos.bevi_int < bevl_ssz.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 21 */ {
beva_str.bem_getCode_2(bevl_pos, bevl_ac);
bevt_4_tmpany_phold = bevl_ac.bem_toHexString_1(bevl_cur);
bevl_r.bem_addValue_1(bevt_4_tmpany_phold);
bevl_pos.bevi_int++;
} /* Line: 21 */
 else  /* Line: 21 */ {
break;
} /* Line: 21 */
} /* Line: 21 */
return bevl_r;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_decode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevl_ssz = null;
BEC_2_4_6_TextString bevl_cur = null;
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pta = null;
BEC_2_4_6_TextString bevl_ptb = null;
BEC_2_4_3_MathInt bevl_pos = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevl_ssz = beva_str.bem_sizeGet_0();
bevt_1_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_1;
if (bevl_ssz.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 30 */ {
return beva_str;
} /* Line: 31 */
bevt_4_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_2;
bevt_3_tmpany_phold = bevl_ssz.bem_modulus_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_3;
if (bevt_3_tmpany_phold.bevi_int != bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 33 */ {
bevt_8_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_4;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevl_ssz);
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 34 */
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_cur = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_5;
bevt_10_tmpany_phold = bevl_ssz.bem_divide_1(bevt_11_tmpany_phold);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_6_3_EncodeHex_bevo_6;
bevt_12_tmpany_phold = bevl_ssz.bem_divide_1(bevt_13_tmpany_phold);
bevl_r.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_14_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_pta = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ptb = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_15_tmpany_phold);
bevl_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 43 */ {
bevt_16_tmpany_phold = bevl_tb.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevl_tb.bem_next_1(bevl_pta);
bevl_tb.bem_next_1(bevl_ptb);
bevt_18_tmpany_phold = bevl_pta.bem_add_1(bevl_ptb);
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_18_tmpany_phold);
bevl_r.bem_setCodeUnchecked_2(bevl_pos, bevt_17_tmpany_phold);
bevl_pos.bevi_int++;
} /* Line: 47 */
 else  /* Line: 43 */ {
break;
} /* Line: 43 */
} /* Line: 43 */
return bevl_r;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 18, 19, 20, 20, 20, 21, 21, 21, 22, 23, 23, 21, 25, 29, 30, 30, 30, 31, 33, 33, 33, 33, 33, 34, 34, 34, 34, 36, 36, 37, 37, 37, 38, 38, 38, 39, 40, 40, 41, 41, 42, 43, 44, 45, 46, 46, 46, 47, 49};
public static new int[] bevs_smnlec
 = new int[] {39, 40, 41, 42, 43, 44, 45, 46, 49, 54, 55, 56, 57, 58, 64, 93, 94, 95, 100, 101, 103, 104, 105, 106, 111, 112, 113, 114, 115, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 133, 135, 136, 137, 138, 139, 140, 146};
/* BEGIN LINEINFO 
assign 1 17 39
new 0 17 39
assign 1 18 40
new 0 18 40
assign 1 18 41
new 1 18 41
assign 1 19 42
sizeGet 0 19 42
assign 1 20 43
new 0 20 43
assign 1 20 44
multiply 1 20 44
assign 1 20 45
new 1 20 45
assign 1 21 46
new 0 21 46
assign 1 21 49
lesser 1 21 54
getCode 2 22 55
assign 1 23 56
toHexString 1 23 56
addValue 1 23 57
incrementValue 0 21 58
return 1 25 64
assign 1 29 93
sizeGet 0 29 93
assign 1 30 94
new 0 30 94
assign 1 30 95
lesser 1 30 100
return 1 31 101
assign 1 33 103
new 0 33 103
assign 1 33 104
modulus 1 33 104
assign 1 33 105
new 0 33 105
assign 1 33 106
notEquals 1 33 111
assign 1 34 112
new 0 34 112
assign 1 34 113
add 1 34 113
assign 1 34 114
new 1 34 114
throw 1 34 115
assign 1 36 117
new 0 36 117
assign 1 36 118
new 1 36 118
assign 1 37 119
new 0 37 119
assign 1 37 120
divide 1 37 120
assign 1 37 121
new 1 37 121
assign 1 38 122
new 0 38 122
assign 1 38 123
divide 1 38 123
sizeSet 1 38 124
assign 1 39 125
new 1 39 125
assign 1 40 126
new 0 40 126
assign 1 40 127
new 1 40 127
assign 1 41 128
new 0 41 128
assign 1 41 129
new 1 41 129
assign 1 42 130
new 0 42 130
assign 1 43 133
hasNextGet 0 43 133
next 1 44 135
next 1 45 136
assign 1 46 137
add 1 46 137
assign 1 46 138
hexNew 1 46 138
setCodeUnchecked 2 46 139
incrementValue 0 47 140
return 1 49 146
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1253246070: return bem_create_0();
case 1014225644: return bem_echo_0();
case -1882364243: return bem_many_0();
case -628560707: return bem_toAny_0();
case -2123848647: return bem_fieldNamesGet_0();
case 770834928: return bem_serializeContents_0();
case 1297175099: return bem_fieldIteratorGet_0();
case -753894116: return bem_new_0();
case -1074341902: return bem_print_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -1138072028: return bem_tagGet_0();
case 844225351: return bem_classNameGet_0();
case -2083934905: return bem_copy_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 80244442: return bem_toString_0();
case -2131387379: return bem_iteratorGet_0();
case -1625648722: return bem_once_0();
case -1194289304: return bem_serializeToString_0();
case -720093952: return bem_default_0();
case 1165329653: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case 110868148: return bem_decode_1((BEC_2_4_6_TextString) bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -941124201: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -636442813: return bem_def_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_6_3_EncodeHex_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_3_EncodeHex_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_3_EncodeHex();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst = (BEC_2_6_3_EncodeHex) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_type;
}
}
}
