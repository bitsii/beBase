namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public sealed class BEC_3_2_4_17_IOFileDirectoryIterator : BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }
static BEC_3_2_4_17_IOFileDirectoryIterator() { }

   
    public IEnumerator<string> bevi_dir;
    
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static new BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static new BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public BEC_2_6_6_SystemObject bevp_jsiter;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_current = null;
bevp_jsiter = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_4_6_TextString bevl_ps = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_9_4_ContainerList bevl_jsfiles = null;
BEC_2_4_6_TextString bevl_currlp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_12_tmpany_phold = null;
BEC_2_4_12_JsonUnmarshaller bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 629 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 630 */
 else  /* Line: 632 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 633 */
if (bevp_closed.bevi_bool) /* Line: 636 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 638 */
if (bevp_opened.bevi_bool) /* Line: 640 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 641 */

      bevi_dir = Directory.EnumerateFileSystemEntries(bevl_path.bems_toCsString(), "*", SearchOption.TopDirectoryOnly).GetEnumerator();
      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 694 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 697 */
 else  /* Line: 698 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 701 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 706 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 706 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 707 */ {
bem_open_0();
} /* Line: 707 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 712 */ {
return null;
} /* Line: 712 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 713 */ {
bem_open_0();
} /* Line: 713 */
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_4_6_TextString bevl_currlp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 723 */ {
return this;
} /* Line: 723 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 724 */ {
return this;
} /* Line: 724 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 725 */ {
return this;
} /* Line: 725 */

      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 759 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 761 */
 else  /* Line: 762 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 765 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() {

      bevi_dir.Dispose();
      bevi_dir = null;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() {
return bevp_dir;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGetDirect_0() {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() {
return bevp_opened;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGetDirect_0() {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() {
return bevp_closed;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGetDirect_0() {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGetDirect_0() {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_jsiterGet_0() {
return bevp_jsiter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_jsiterGetDirect_0() {
return bevp_jsiter;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_jsiterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_jsiter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_jsiterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_jsiter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {612, 613, 614, 615, 620, 621, 629, 629, 630, 630, 633, 633, 633, 638, 638, 638, 641, 641, 641, 694, 694, 696, 697, 700, 701, 706, 706, 707, 707, 707, 708, 708, 712, 713, 713, 713, 714, 715, 716, 723, 724, 724, 724, 725, 725, 725, 759, 759, 760, 761, 763, 764, 765, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {33, 34, 35, 36, 40, 41, 70, 75, 76, 77, 80, 81, 82, 85, 86, 87, 90, 91, 92, 99, 104, 105, 106, 109, 110, 119, 120, 122, 127, 128, 130, 135, 141, 143, 148, 149, 151, 152, 153, 168, 170, 175, 176, 178, 183, 184, 190, 195, 196, 197, 200, 201, 202, 213, 216, 219, 223, 227, 230, 233, 237, 241, 244, 247, 251, 255, 258, 261, 265, 269, 272, 275, 279};
/* BEGIN LINEINFO 
assign 1 612 33
new 0 612 33
assign 1 613 34
new 0 613 34
assign 1 614 35
assign 1 615 36
new 0 620 40
assign 1 621 41
assign 1 629 70
def 1 629 75
assign 1 630 76
pathGet 0 630 76
assign 1 630 77
toString 0 630 77
assign 1 633 80
new 0 633 80
assign 1 633 81
new 1 633 81
throw 1 633 82
assign 1 638 85
new 0 638 85
assign 1 638 86
new 1 638 86
throw 1 638 87
assign 1 641 90
new 0 641 90
assign 1 641 91
new 1 641 91
throw 1 641 92
assign 1 694 99
def 1 694 104
assign 1 696 105
new 0 696 105
assign 1 697 106
apNew 1 697 106
assign 1 700 109
new 0 700 109
assign 1 701 110
new 0 701 110
assign 1 706 119
new 0 706 119
return 1 706 120
assign 1 707 122
not 0 707 127
open 0 707 128
assign 1 708 130
def 1 708 135
return 1 708 135
return 1 712 141
assign 1 713 143
not 0 713 148
open 0 713 149
assign 1 714 151
advance 0 715 152
return 1 716 153
return 1 723 168
assign 1 724 170
not 0 724 175
return 1 724 176
assign 1 725 178
undef 1 725 183
return 1 725 184
assign 1 759 190
def 1 759 195
assign 1 760 196
new 0 760 196
assign 1 761 197
apNew 1 761 197
assign 1 763 200
new 0 763 200
assign 1 764 201
new 0 764 201
assign 1 765 202
return 1 0 213
return 1 0 216
assign 1 0 219
assign 1 0 223
return 1 0 227
return 1 0 230
assign 1 0 233
assign 1 0 237
return 1 0 241
return 1 0 244
assign 1 0 247
assign 1 0 251
return 1 0 255
return 1 0 258
assign 1 0 261
assign 1 0 265
return 1 0 269
return 1 0 272
assign 1 0 275
assign 1 0 279
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1799416909: return bem_serializationIteratorGet_0();
case -1567173561: return bem_currentGet_0();
case 1804773996: return bem_create_0();
case -73436994: return bem_new_0();
case 1254813232: return bem_toAny_0();
case 1029225044: return bem_closedGet_0();
case -1072030744: return bem_sourceFileNameGet_0();
case 653349672: return bem_copy_0();
case 548311719: return bem_closedGetDirect_0();
case -1778497682: return bem_serializeToString_0();
case -304902101: return bem_dirGet_0();
case 81327991: return bem_openedGetDirect_0();
case 959038598: return bem_echo_0();
case -2120499139: return bem_iteratorGet_0();
case -1081610686: return bem_close_0();
case 942482233: return bem_hasNextGet_0();
case 1562662552: return bem_many_0();
case -1041760951: return bem_open_0();
case 1947762383: return bem_dirGetDirect_0();
case 167710369: return bem_print_0();
case -213923149: return bem_currentGetDirect_0();
case -1308502950: return bem_advance_0();
case -297374401: return bem_hashGet_0();
case -1067704397: return bem_once_0();
case 39810102: return bem_tagGet_0();
case 1769468354: return bem_fieldNamesGet_0();
case -682526974: return bem_nextGet_0();
case -1628372783: return bem_classNameGet_0();
case -1071008216: return bem_serializeContents_0();
case 621276181: return bem_toString_0();
case -548611534: return bem_openedGet_0();
case -938212146: return bem_jsiterGetDirect_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case 1501267730: return bem_jsiterGet_0();
case -1960297657: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1246273862: return bem_dirSetDirect_1(bevd_0);
case -438924354: return bem_undefined_1(bevd_0);
case 50699634: return bem_openedSet_1(bevd_0);
case -695096252: return bem_closedSet_1(bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -746877753: return bem_openedSetDirect_1(bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1384306247: return bem_closedSetDirect_1(bevd_0);
case 1647019412: return bem_jsiterSetDirect_1(bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case 655132811: return bem_currentSet_1(bevd_0);
case -2073163841: return bem_jsiterSet_1(bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case -217980665: return bem_dirSet_1(bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1049172860: return bem_defined_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
case 1435688651: return bem_currentSetDirect_1(bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -414228749: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
}
