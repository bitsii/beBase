namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public sealed class BEC_3_2_4_17_IOFileDirectoryIterator : BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }
static BEC_3_2_4_17_IOFileDirectoryIterator() { }

   
    public IEnumerator<string> bevi_dir;
    
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static new BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static new BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_current = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 470 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 471 */
 else  /* Line: 473 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 474 */
if (bevp_closed.bevi_bool) /* Line: 477 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 479 */
if (bevp_opened.bevi_bool) /* Line: 481 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 482 */

      bevi_dir = Directory.EnumerateFileSystemEntries(bevl_path.bems_toCsString(), "*", SearchOption.TopDirectoryOnly).GetEnumerator();
      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 506 */
 else  /* Line: 507 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 510 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 515 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 515 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 516 */ {
bem_open_0();
} /* Line: 516 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 521 */ {
return null;
} /* Line: 521 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 522 */ {
bem_open_0();
} /* Line: 522 */
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 532 */ {
return this;
} /* Line: 532 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 533 */ {
return this;
} /* Line: 533 */
if (bevp_current == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 534 */ {
return this;
} /* Line: 534 */

      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 550 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 552 */
 else  /* Line: 553 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 556 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() {

      bevi_dir.Dispose();
      bevi_dir = null;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {453, 454, 455, 461, 462, 470, 470, 471, 471, 474, 474, 474, 479, 479, 479, 482, 482, 482, 503, 503, 505, 506, 509, 510, 515, 515, 516, 516, 516, 517, 517, 521, 522, 522, 522, 523, 524, 525, 532, 533, 533, 533, 534, 534, 534, 550, 550, 551, 552, 554, 555, 556, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {32, 33, 34, 38, 39, 54, 59, 60, 61, 64, 65, 66, 69, 70, 71, 74, 75, 76, 83, 88, 89, 90, 93, 94, 103, 104, 106, 111, 112, 114, 119, 125, 127, 132, 133, 135, 136, 137, 145, 147, 152, 153, 155, 160, 161, 167, 172, 173, 174, 177, 178, 179, 190, 193, 197, 200, 204, 207, 211, 214};
/* BEGIN LINEINFO 
assign 1 453 32
new 0 453 32
assign 1 454 33
new 0 454 33
assign 1 455 34
new 0 461 38
assign 1 462 39
assign 1 470 54
def 1 470 59
assign 1 471 60
pathGet 0 471 60
assign 1 471 61
toString 0 471 61
assign 1 474 64
new 0 474 64
assign 1 474 65
new 1 474 65
throw 1 474 66
assign 1 479 69
new 0 479 69
assign 1 479 70
new 1 479 70
throw 1 479 71
assign 1 482 74
new 0 482 74
assign 1 482 75
new 1 482 75
throw 1 482 76
assign 1 503 83
def 1 503 88
assign 1 505 89
new 0 505 89
assign 1 506 90
apNew 1 506 90
assign 1 509 93
new 0 509 93
assign 1 510 94
new 0 510 94
assign 1 515 103
new 0 515 103
return 1 515 104
assign 1 516 106
not 0 516 111
open 0 516 112
assign 1 517 114
def 1 517 119
return 1 517 119
return 1 521 125
assign 1 522 127
not 0 522 132
open 0 522 133
assign 1 523 135
advance 0 524 136
return 1 525 137
return 1 532 145
assign 1 533 147
not 0 533 152
return 1 533 153
assign 1 534 155
undef 1 534 160
return 1 534 161
assign 1 550 167
def 1 550 172
assign 1 551 173
new 0 551 173
assign 1 552 174
apNew 1 552 174
assign 1 554 177
new 0 554 177
assign 1 555 178
new 0 555 178
assign 1 556 179
return 1 0 190
assign 1 0 193
return 1 0 197
assign 1 0 200
return 1 0 204
assign 1 0 207
return 1 0 211
assign 1 0 214
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -354093047: return bem_serializationIteratorGet_0();
case -76505233: return bem_once_0();
case 1225116947: return bem_closedGet_0();
case -1036233638: return bem_new_0();
case -541758955: return bem_advance_0();
case -551298753: return bem_sourceFileNameGet_0();
case -1721645741: return bem_close_0();
case -1493103250: return bem_many_0();
case -362321661: return bem_deserializeClassNameGet_0();
case -386157741: return bem_serializeToString_0();
case 1028683886: return bem_toString_0();
case 1360947287: return bem_currentGet_0();
case -1361309742: return bem_hasNextGet_0();
case -1057001629: return bem_copy_0();
case -998358226: return bem_open_0();
case 1836947478: return bem_serializeContents_0();
case -454910570: return bem_create_0();
case -1973767507: return bem_openedGet_0();
case 1048772166: return bem_echo_0();
case -1874213289: return bem_tagGet_0();
case 654084467: return bem_iteratorGet_0();
case 901258413: return bem_nextGet_0();
case -1312519804: return bem_hashGet_0();
case -1963468660: return bem_fieldIteratorGet_0();
case -632642189: return bem_dirGet_0();
case 714392359: return bem_classNameGet_0();
case 863669946: return bem_toAny_0();
case -354590014: return bem_print_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1978731115: return bem_sameType_1(bevd_0);
case 729561267: return bem_copyTo_1(bevd_0);
case 264820615: return bem_openedSet_1(bevd_0);
case 604922157: return bem_equals_1(bevd_0);
case -2004799958: return bem_closedSet_1(bevd_0);
case 2095964872: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1673438491: return bem_currentSet_1(bevd_0);
case -965306462: return bem_undefined_1(bevd_0);
case -1374275511: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 824179568: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case -558198774: return bem_def_1(bevd_0);
case 740651176: return bem_dirSet_1(bevd_0);
case -999936361: return bem_defined_1(bevd_0);
case 1782921206: return bem_otherType_1(bevd_0);
case -403482348: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1301577712: return bem_sameClass_1(bevd_0);
case -1184340301: return bem_otherClass_1(bevd_0);
case -747350143: return bem_undef_1(bevd_0);
case 1672825312: return bem_notEquals_1(bevd_0);
case -504315826: return bem_sameObject_1(bevd_0);
case -1188536421: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -249962556: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -608983707: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 913536943: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1192068648: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1655666515: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 478589859: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2045713194: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
}
