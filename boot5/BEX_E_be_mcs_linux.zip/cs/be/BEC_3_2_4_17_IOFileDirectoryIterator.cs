namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public sealed class BEC_3_2_4_17_IOFileDirectoryIterator : BEC_2_6_6_SystemObject {
public BEC_3_2_4_17_IOFileDirectoryIterator() { }
static BEC_3_2_4_17_IOFileDirectoryIterator() { }

   
    public IEnumerator<string> bevi_dir;
    
   private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0 = {0x44,0x69,0x72,0x65,0x63,0x74,0x6F,0x72,0x79,0x20,0x6E,0x6F,0x74,0x20,0x64,0x65,0x66,0x69,0x6E,0x65,0x64,0x20,0x64,0x75,0x72,0x69,0x6E,0x67,0x20,0x6F,0x70,0x65,0x6E};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x69,0x6E,0x67,0x20,0x74,0x6F,0x20,0x72,0x65,0x2D,0x6F,0x70,0x65,0x6E,0x20,0x61,0x20,0x63,0x6C,0x6F,0x73,0x65,0x64,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static byte[] bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2 = {0x4F,0x6E,0x6C,0x79,0x20,0x6F,0x70,0x65,0x6E,0x20,0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x20,0x6F,0x6E,0x63,0x65};
public static new BEC_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;

public static new BET_3_2_4_17_IOFileDirectoryIterator bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;

public BEC_2_2_4_IOFile bevp_dir;
public BEC_2_5_4_LogicBool bevp_opened;
public BEC_2_5_4_LogicBool bevp_closed;
public BEC_2_2_4_IOFile bevp_current;
public BEC_2_6_6_SystemObject bevp_jsiter;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_current = null;
bevp_jsiter = null;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_new_1(BEC_2_2_4_IOFile beva__dir) {
bem_new_0();
bevp_dir = beva__dir;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_open_0() {
BEC_2_4_6_TextString bevl_path = null;
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_4_6_TextString bevl_ps = null;
BEC_2_4_6_TextString bevl_jspw = null;
BEC_2_9_4_ContainerList bevl_jsfiles = null;
BEC_2_4_6_TextString bevl_currlp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_12_tmpany_phold = null;
BEC_2_4_12_JsonUnmarshaller bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
if (bevp_dir == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 636 */ {
bevt_1_tmpany_phold = bevp_dir.bem_pathGet_0();
bevl_path = bevt_1_tmpany_phold.bem_toString_0();
} /* Line: 637 */
 else  /* Line: 639 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_0));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 640 */
if (bevp_closed.bevi_bool) /* Line: 643 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(64, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_1));
bevt_4_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_4_tmpany_phold);
} /* Line: 645 */
if (bevp_opened.bevi_bool) /* Line: 647 */ {
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_3_2_4_17_IOFileDirectoryIterator_bels_2));
bevt_6_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_7_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_6_tmpany_phold);
} /* Line: 648 */

      bevi_dir = Directory.EnumerateFileSystemEntries(bevl_path.bems_toCsString(), "*", SearchOption.TopDirectoryOnly).GetEnumerator();
      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 701 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 704 */
 else  /* Line: 705 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 708 */
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 713 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 713 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 714 */ {
bem_open_0();
} /* Line: 714 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_2_tmpany_phold;
} /*method end*/
public BEC_2_2_4_IOFile bem_nextGet_0() {
BEC_2_2_4_IOFile bevl_toRet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 719 */ {
return null;
} /* Line: 719 */
if (bevp_opened.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 720 */ {
bem_open_0();
} /* Line: 720 */
bevl_toRet = bevp_current;
bem_advance_0();
return bevl_toRet;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_advance_0() {
BEC_2_4_6_TextString bevl_newName = null;
BEC_2_4_6_TextString bevl_currlp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (bevp_closed.bevi_bool) /* Line: 730 */ {
return this;
} /* Line: 730 */
if (bevp_opened.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 731 */ {
return this;
} /* Line: 731 */
if (bevp_current == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 732 */ {
return this;
} /* Line: 732 */

      if (bevi_dir.MoveNext()) {
        bevl_newName = new BEC_2_4_6_TextString(bevi_dir.Current);
      }
      if (bevl_newName == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 766 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_apNew_1(bevl_newName);
} /* Line: 768 */
 else  /* Line: 769 */ {
bevp_opened = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_closed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_current = null;
} /* Line: 772 */
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_close_0() {

      bevi_dir.Dispose();
      bevi_dir = null;
      return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGet_0() {
return bevp_dir;
} /*method end*/
public BEC_2_2_4_IOFile bem_dirGetDirect_0() {
return bevp_dir;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_dirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_dir = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGet_0() {
return bevp_opened;
} /*method end*/
public BEC_2_5_4_LogicBool bem_openedGetDirect_0() {
return bevp_opened;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_openedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_opened = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGet_0() {
return bevp_closed;
} /*method end*/
public BEC_2_5_4_LogicBool bem_closedGetDirect_0() {
return bevp_closed;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_closedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closed = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGet_0() {
return bevp_current;
} /*method end*/
public BEC_2_2_4_IOFile bem_currentGetDirect_0() {
return bevp_current;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_currentSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_current = (BEC_2_2_4_IOFile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_jsiterGet_0() {
return bevp_jsiter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_jsiterGetDirect_0() {
return bevp_jsiter;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_jsiterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_jsiter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_17_IOFileDirectoryIterator bem_jsiterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_jsiter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {619, 620, 621, 622, 627, 628, 636, 636, 637, 637, 640, 640, 640, 645, 645, 645, 648, 648, 648, 701, 701, 703, 704, 707, 708, 713, 713, 714, 714, 714, 715, 715, 719, 720, 720, 720, 721, 722, 723, 730, 731, 731, 731, 732, 732, 732, 766, 766, 767, 768, 770, 771, 772, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {33, 34, 35, 36, 40, 41, 70, 75, 76, 77, 80, 81, 82, 85, 86, 87, 90, 91, 92, 99, 104, 105, 106, 109, 110, 119, 120, 122, 127, 128, 130, 135, 141, 143, 148, 149, 151, 152, 153, 168, 170, 175, 176, 178, 183, 184, 190, 195, 196, 197, 200, 201, 202, 213, 216, 219, 223, 227, 230, 233, 237, 241, 244, 247, 251, 255, 258, 261, 265, 269, 272, 275, 279};
/* BEGIN LINEINFO 
assign 1 619 33
new 0 619 33
assign 1 620 34
new 0 620 34
assign 1 621 35
assign 1 622 36
new 0 627 40
assign 1 628 41
assign 1 636 70
def 1 636 75
assign 1 637 76
pathGet 0 637 76
assign 1 637 77
toString 0 637 77
assign 1 640 80
new 0 640 80
assign 1 640 81
new 1 640 81
throw 1 640 82
assign 1 645 85
new 0 645 85
assign 1 645 86
new 1 645 86
throw 1 645 87
assign 1 648 90
new 0 648 90
assign 1 648 91
new 1 648 91
throw 1 648 92
assign 1 701 99
def 1 701 104
assign 1 703 105
new 0 703 105
assign 1 704 106
apNew 1 704 106
assign 1 707 109
new 0 707 109
assign 1 708 110
new 0 708 110
assign 1 713 119
new 0 713 119
return 1 713 120
assign 1 714 122
not 0 714 127
open 0 714 128
assign 1 715 130
def 1 715 135
return 1 715 135
return 1 719 141
assign 1 720 143
not 0 720 148
open 0 720 149
assign 1 721 151
advance 0 722 152
return 1 723 153
return 1 730 168
assign 1 731 170
not 0 731 175
return 1 731 176
assign 1 732 178
undef 1 732 183
return 1 732 184
assign 1 766 190
def 1 766 195
assign 1 767 196
new 0 767 196
assign 1 768 197
apNew 1 768 197
assign 1 770 200
new 0 770 200
assign 1 771 201
new 0 771 201
assign 1 772 202
return 1 0 213
return 1 0 216
assign 1 0 219
assign 1 0 223
return 1 0 227
return 1 0 230
assign 1 0 233
assign 1 0 237
return 1 0 241
return 1 0 244
assign 1 0 247
assign 1 0 251
return 1 0 255
return 1 0 258
assign 1 0 261
assign 1 0 265
return 1 0 269
return 1 0 272
assign 1 0 275
assign 1 0 279
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1929688279: return bem_classNameGet_0();
case 1681461651: return bem_close_0();
case -1058456741: return bem_print_0();
case 1740664569: return bem_openedGet_0();
case -1032171260: return bem_toString_0();
case 2098483713: return bem_copy_0();
case 973128765: return bem_dirGetDirect_0();
case 1701821410: return bem_dirGet_0();
case 846774941: return bem_closedGetDirect_0();
case 334648449: return bem_serializationIteratorGet_0();
case 329044611: return bem_fieldNamesGet_0();
case -1101624703: return bem_deserializeClassNameGet_0();
case 538389441: return bem_serializeToString_0();
case -1544067002: return bem_advance_0();
case 1594168038: return bem_jsiterGet_0();
case 390471173: return bem_currentGet_0();
case 2098994482: return bem_hashGet_0();
case 1163805126: return bem_new_0();
case 1764716287: return bem_once_0();
case 1946359914: return bem_closedGet_0();
case 688503232: return bem_open_0();
case -98046751: return bem_tagGet_0();
case -1509690672: return bem_iteratorGet_0();
case -776344640: return bem_currentGetDirect_0();
case 705622040: return bem_sourceFileNameGet_0();
case 281585293: return bem_toAny_0();
case 915705974: return bem_openedGetDirect_0();
case -1006908471: return bem_serializeContents_0();
case 1669654091: return bem_many_0();
case -248041477: return bem_jsiterGetDirect_0();
case -115978313: return bem_nextGet_0();
case 856020715: return bem_hasNextGet_0();
case 812544411: return bem_echo_0();
case 1945143392: return bem_fieldIteratorGet_0();
case -1610742202: return bem_create_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1446306055: return bem_otherClass_1(bevd_0);
case 1224467768: return bem_new_1((BEC_2_2_4_IOFile) bevd_0);
case -1685877365: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1376012155: return bem_currentSetDirect_1(bevd_0);
case 1867834674: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1524968669: return bem_sameClass_1(bevd_0);
case 1337150921: return bem_currentSet_1(bevd_0);
case 758440978: return bem_jsiterSetDirect_1(bevd_0);
case -1822839285: return bem_dirSetDirect_1(bevd_0);
case -451687160: return bem_closedSet_1(bevd_0);
case 1300185187: return bem_undefined_1(bevd_0);
case -813804643: return bem_closedSetDirect_1(bevd_0);
case 1863898392: return bem_equals_1(bevd_0);
case -1207491940: return bem_undef_1(bevd_0);
case 714503183: return bem_sameObject_1(bevd_0);
case -1949342250: return bem_jsiterSet_1(bevd_0);
case 220285540: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1538927011: return bem_copyTo_1(bevd_0);
case 1799020497: return bem_openedSet_1(bevd_0);
case 613414930: return bem_def_1(bevd_0);
case 1946354099: return bem_dirSet_1(bevd_0);
case 2108235391: return bem_defined_1(bevd_0);
case -833799554: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 99127990: return bem_otherType_1(bevd_0);
case -1776959106: return bem_notEquals_1(bevd_0);
case 1837978646: return bem_sameType_1(bevd_0);
case 884761847: return bem_openedSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -903966108: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1997741826: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 937271141: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -906378356: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -319646499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 395811446: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1670352859: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_2_4_17_IOFileDirectoryIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_17_IOFileDirectoryIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst = (BEC_3_2_4_17_IOFileDirectoryIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_17_IOFileDirectoryIterator.bece_BEC_3_2_4_17_IOFileDirectoryIterator_bevs_type;
}
}
}
