namespace be {

using System;
using System.Threading;
/* IO:File: source/base/Time.be */
public class BEC_2_4_5_TimeStamp : BEC_2_4_8_TimeInterval {
public BEC_2_4_5_TimeStamp() { }
static BEC_2_4_5_TimeStamp() { }
private static byte[] becc_BEC_2_4_5_TimeStamp_clname = {0x54,0x69,0x6D,0x65,0x3A,0x53,0x74,0x61,0x6D,0x70};
private static byte[] becc_BEC_2_4_5_TimeStamp_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x69,0x6D,0x65,0x2E,0x62,0x65};
public static new BEC_2_4_5_TimeStamp bece_BEC_2_4_5_TimeStamp_bevs_inst;

public static new BET_2_4_5_TimeStamp bece_BEC_2_4_5_TimeStamp_bevs_type;

public BEC_2_5_4_LogicBool bevp_localZone;
public override BEC_2_6_6_SystemObject bem_new_0() {
bem_now_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_5_TimeStamp bevl_cp = null;
bevl_cp = (BEC_2_4_5_TimeStamp) (new BEC_2_4_5_TimeStamp()).bem_new_2(bevp_secs, bevp_millis);
bevl_cp.bem_localZoneSet_1(bevp_localZone);
return this;
} /*method end*/
public virtual BEC_2_4_5_TimeStamp bem_localZoneSet_1(BEC_2_5_4_LogicBool beva__localZone) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_localZone == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 373 */ {
bevp_localZone = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 374 */
bevp_localZone = beva__localZone;
if (bevp_localZone.bevi_bool) /* Line: 379 */ {
} /* Line: 380 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_localZoneGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_localZone == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 389 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /* Line: 389 */
return bevp_localZone;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_yearGet_0() {
BEC_2_4_6_TextString bevl_rval = null;
return bevl_rval;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_monthGet_0() {
BEC_2_4_6_TextString bevl_rval = null;
return bevl_rval;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_dayGet_0() {
BEC_2_4_6_TextString bevl_rval = null;
return bevl_rval;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_hourGet_0() {
BEC_2_4_6_TextString bevl_rval = null;
return bevl_rval;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_minuteGet_0() {
BEC_2_4_6_TextString bevl_rval = null;
return bevl_rval;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_secondGet_0() {
BEC_2_4_6_TextString bevl_rval = null;
return bevl_rval;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_millisecondGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_millis.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_localZoneGetDirect_0() {
return bevp_localZone;
} /*method end*/
public BEC_2_4_5_TimeStamp bem_localZoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_localZone = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {364, 368, 369, 373, 373, 374, 377, 389, 389, 389, 389, 390, 410, 430, 450, 470, 490, 510, 514, 514, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 22, 23, 28, 33, 34, 36, 44, 49, 50, 51, 53, 57, 61, 65, 69, 73, 77, 81, 82, 85, 88};
/* BEGIN LINEINFO 
now 0 364 17
assign 1 368 22
new 2 368 22
localZoneSet 1 369 23
assign 1 373 28
undef 1 373 33
assign 1 374 34
new 0 374 34
assign 1 377 36
assign 1 389 44
undef 1 389 49
assign 1 389 50
new 0 389 50
return 1 389 51
return 1 390 53
return 1 410 57
return 1 430 61
return 1 450 65
return 1 470 69
return 1 490 73
return 1 510 77
assign 1 514 81
toString 0 514 81
return 1 514 82
return 1 0 85
assign 1 0 88
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1123278056: return bem_tagGet_0();
case 1071461198: return bem_echo_0();
case 1650245211: return bem_localZoneGet_0();
case 1942283510: return bem_sourceFileNameGet_0();
case -189145250: return bem_monthGet_0();
case 1985770494: return bem_millisecondGet_0();
case -10010145: return bem_copy_0();
case 96033137: return bem_serializeToString_0();
case -449079106: return bem_iteratorGet_0();
case -1086782351: return bem_print_0();
case -1156044149: return bem_secondInMinuteGet_0();
case 1723461992: return bem_localZoneGetDirect_0();
case 1593453371: return bem_secondGet_0();
case -2051518290: return bem_once_0();
case 1281502509: return bem_millisecondInSecondGet_0();
case 1306722771: return bem_now_0();
case -148774294: return bem_minutesGet_0();
case -2132005909: return bem_toShortString_0();
case -768332345: return bem_minuteGet_0();
case 1501024375: return bem_millisecondsGet_0();
case 577688465: return bem_secondsGet_0();
case -1980214899: return bem_toStringMinutes_0();
case 1757656781: return bem_dayGet_0();
case 1194804327: return bem_fieldNamesGet_0();
case -23567698: return bem_carryMillis_0();
case 1513233059: return bem_toString_0();
case 1746792402: return bem_secsGetDirect_0();
case -713163994: return bem_toAny_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case 1851908877: return bem_hashGet_0();
case -1901806022: return bem_millisGetDirect_0();
case 1577195459: return bem_serializationIteratorGet_0();
case -444508657: return bem_secsGet_0();
case -779183774: return bem_hourGet_0();
case -1266447496: return bem_classNameGet_0();
case -1178500856: return bem_yearGet_0();
case -1362850090: return bem_serializeContents_0();
case 611670694: return bem_fieldIteratorGet_0();
case 144584723: return bem_create_0();
case -611794492: return bem_millisGet_0();
case 990360647: return bem_new_0();
case 341575045: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 2109233297: return bem_millisecondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case 860945877: return bem_addMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -950813974: return bem_localZoneSetDirect_1(bevd_0);
case 1517575046: return bem_secondsSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 617251081: return bem_addDays_1((BEC_2_4_3_MathInt) bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1571246665: return bem_millisSet_1(bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case 1605224270: return bem_subtractMilliseconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case 888018773: return bem_subtract_1((BEC_2_4_8_TimeInterval) bevd_0);
case 566059539: return bem_subtractHours_1((BEC_2_4_3_MathInt) bevd_0);
case 1975319867: return bem_secsSetDirect_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
case -1302988160: return bem_subtractSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -1986564952: return bem_greater_1((BEC_2_4_8_TimeInterval) bevd_0);
case 494303470: return bem_addHours_1((BEC_2_4_3_MathInt) bevd_0);
case 2068985998: return bem_millisSetDirect_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case 907860648: return bem_secsSet_1(bevd_0);
case 947454039: return bem_offByHour_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1320706881: return bem_greaterEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case 593948905: return bem_lesserEquals_1((BEC_2_4_8_TimeInterval) bevd_0);
case -1403331313: return bem_addSeconds_1((BEC_2_4_3_MathInt) bevd_0);
case -655019399: return bem_def_1(bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case -124318134: return bem_lesser_1((BEC_2_4_8_TimeInterval) bevd_0);
case -288705871: return bem_subtractDays_1((BEC_2_4_3_MathInt) bevd_0);
case 375073126: return bem_add_1((BEC_2_4_8_TimeInterval) bevd_0);
case 1449340032: return bem_otherClass_1(bevd_0);
case 879996582: return bem_localZoneSet_1((BEC_2_5_4_LogicBool) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1639419044: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_4_5_TimeStamp_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_5_TimeStamp_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_5_TimeStamp();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_inst = (BEC_2_4_5_TimeStamp) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_5_TimeStamp.bece_BEC_2_4_5_TimeStamp_bevs_type;
}
}
}
