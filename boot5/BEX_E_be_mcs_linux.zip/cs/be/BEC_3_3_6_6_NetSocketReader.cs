namespace be {

using System;
using System.IO;
using System.Collections.Generic;
    
using System;
using System.Net;
using System.Net.Sockets;
/* IO:File: source/extended/EcPlat.be */
public class BEC_3_3_6_6_NetSocketReader : BEC_2_2_6_IOReader {
public BEC_3_3_6_6_NetSocketReader() { }
static BEC_3_3_6_6_NetSocketReader() { }
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_3_6_6_NetSocketReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static new BEC_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;

public static new BET_3_3_6_6_NetSocketReader bece_BEC_3_3_6_6_NetSocketReader_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1242864862: return bem_sourceFileNameGet_0();
case 347445468: return bem_deserializeClassNameGet_0();
case -1287291624: return bem_toString_0();
case -1718750264: return bem_tagGet_0();
case -1852737980: return bem_readBuffer_0();
case 1739040137: return bem_fieldIteratorGet_0();
case -398082834: return bem_blockSizeGet_0();
case -1888972082: return bem_readStringClose_0();
case -1497387944: return bem_many_0();
case 2040540024: return bem_isClosedGetDirect_0();
case 855089063: return bem_toAny_0();
case -1820718044: return bem_echo_0();
case 1388220454: return bem_once_0();
case 1115941233: return bem_hashGet_0();
case 876979386: return bem_iteratorGet_0();
case 127200919: return bem_blockSizeGetDirect_0();
case 262448459: return bem_fieldNamesGet_0();
case 1139687182: return bem_serializeToString_0();
case 1044385788: return bem_new_0();
case -380774728: return bem_serializationIteratorGet_0();
case -922157063: return bem_byteReaderGet_0();
case 1516511629: return bem_serializeContents_0();
case -1936404363: return bem_create_0();
case -1422208208: return bem_close_0();
case 1846641427: return bem_classNameGet_0();
case -635696696: return bem_readString_0();
case -1761992874: return bem_isClosedGet_0();
case 1349080119: return bem_extOpen_0();
case -485032950: return bem_print_0();
case -1754015182: return bem_readBufferLine_0();
case 1978340744: return bem_copy_0();
case 1221241897: return bem_vfileGetDirect_0();
case 1436246101: return bem_vfileGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 477404510: return bem_undefined_1(bevd_0);
case -1676267201: return bem_vfileSet_1(bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1259487456: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case -1906646653: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case 532909341: return bem_vfileSetDirect_1(bevd_0);
case -1148649030: return bem_isClosedSet_1(bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case -1092096998: return bem_blockSizeSetDirect_1(bevd_0);
case -917452910: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case 254587602: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case -847200836: return bem_def_1(bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -70829200: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case 326237128: return bem_blockSizeSet_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case -555622031: return bem_isClosedSetDirect_1(bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case -353009061: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1053087268: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1996466847: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 333212234: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_3_6_6_NetSocketReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_3_6_6_NetSocketReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_3_6_6_NetSocketReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst = (BEC_3_3_6_6_NetSocketReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_3_6_6_NetSocketReader.bece_BEC_3_3_6_6_NetSocketReader_bevs_type;
}
}
}
