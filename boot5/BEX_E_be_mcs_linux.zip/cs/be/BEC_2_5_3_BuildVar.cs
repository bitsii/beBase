namespace be {
/* IO:File: source/build/BuildTypes.be */
public sealed class BEC_2_5_3_BuildVar : BEC_2_6_6_SystemObject {
public BEC_2_5_3_BuildVar() { }
static BEC_2_5_3_BuildVar() { }
private static byte[] becc_BEC_2_5_3_BuildVar_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x61,0x72};
private static byte[] becc_BEC_2_5_3_BuildVar_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_0 = {0x20,0x6E,0x61,0x6D,0x65,0x3A,0x20};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_1 = {0x20,0x69,0x73,0x41,0x72,0x67};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_2 = {0x20,0x69,0x73,0x54,0x6D,0x70,0x56,0x61,0x72};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_3 = {0x20,0x6E,0x6F,0x74,0x44,0x65,0x63,0x6C,0x61,0x72,0x65,0x64};
private static byte[] bece_BEC_2_5_3_BuildVar_bels_4 = {0x20,0x69,0x73,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
public static new BEC_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_inst;

public static new BET_2_5_3_BuildVar bece_BEC_2_5_3_BuildVar_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_namepath;
public BEC_2_6_6_SystemObject bevp_refs;
public BEC_2_9_3_ContainerSet bevp_allCalls;
public BEC_2_4_6_TextString bevp_suffix;
public BEC_2_5_4_LogicBool bevp_isArg;
public BEC_2_5_4_LogicBool bevp_isAdded;
public BEC_2_5_4_LogicBool bevp_isTmpVar;
public BEC_2_5_4_LogicBool bevp_autoType;
public BEC_2_5_4_LogicBool bevp_isDeclared;
public BEC_2_5_4_LogicBool bevp_isProperty;
public BEC_2_4_3_MathInt bevp_numAssigns;
public BEC_2_5_4_LogicBool bevp_isTyped;
public BEC_2_4_3_MathInt bevp_vpos;
public BEC_2_5_4_LogicBool bevp_isSelf;
public BEC_2_5_4_LogicBool bevp_isThis;
public BEC_2_5_4_LogicBool bevp_implied;
public BEC_2_4_3_MathInt bevp_maxCpos;
public BEC_2_4_3_MathInt bevp_minCpos;
public BEC_2_4_6_TextString bevp_nativeName;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_4_MathInts bevt_0_ta_ph = null;
bevp_isArg = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isAdded = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isTmpVar = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_autoType = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isDeclared = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_isProperty = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_numAssigns = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_isTyped = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_vpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevp_isSelf = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_implied = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_maxCpos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bevt_0_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevp_minCpos = bevt_0_ta_ph.bem_maxGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_synNew_1(BEC_2_5_3_BuildVar beva_full) {
bevp_isArg = beva_full.bem_isArgGet_0();
bevp_name = beva_full.bem_nameGet_0();
bevp_isAdded = beva_full.bem_isAddedGet_0();
bevp_isTmpVar = beva_full.bem_isTmpVarGet_0();
bevp_isProperty = beva_full.bem_isPropertyGet_0();
bevp_numAssigns = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_namepath = beva_full.bem_namepathGet_0();
bevp_isTyped = beva_full.bem_isTypedGet_0();
bevp_vpos = beva_full.bem_vposGet_0();
bevp_isSelf = beva_full.bem_isSelfGet_0();
bevp_isThis = beva_full.bem_isThisGet_0();
bevp_implied = beva_full.bem_impliedGet_0();
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_addCall_1(BEC_2_5_4_BuildNode beva_call) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_allCalls == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 237*/ {
bevp_allCalls = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
} /* Line: 238*/
bevp_allCalls.bem_addValue_1(beva_call);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGet_0() {
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
if (bevp_maxCpos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 244*/ {
return bevp_maxCpos;
} /* Line: 244*/
bevt_0_ta_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
/* Line: 245*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 245*/ {
bevl_n = bevt_0_ta_loop.bem_nextGet_0();
bevt_6_ta_ph = bevl_n.bemd_0(-64275311);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(961291942);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(-1483853795, bevp_maxCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 246*/ {
bevt_7_ta_ph = bevl_n.bemd_0(-64275311);
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bemd_0(961291942);
} /* Line: 247*/
} /* Line: 246*/
 else /* Line: 245*/ {
break;
} /* Line: 245*/
} /* Line: 245*/
return bevp_maxCpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGet_0() {
BEC_2_4_3_MathInt bevl_bigun = null;
BEC_2_6_6_SystemObject bevl_n = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_2_4_4_MathInts bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevl_bigun = bevt_1_ta_ph.bem_maxGet_0();
if (bevp_minCpos.bevi_int < bevl_bigun.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 256*/ {
return bevp_minCpos;
} /* Line: 256*/
bevt_0_ta_loop = bevp_allCalls.bem_setIteratorGet_0();
while (true)
/* Line: 257*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 257*/ {
bevl_n = bevt_0_ta_loop.bem_nextGet_0();
bevt_6_ta_ph = bevl_n.bemd_0(-64275311);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_0(961291942);
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(2036819915, bevp_minCpos);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 258*/ {
bevt_7_ta_ph = bevl_n.bemd_0(-64275311);
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_7_ta_ph.bemd_0(961291942);
} /* Line: 259*/
} /* Line: 258*/
 else /* Line: 257*/ {
break;
} /* Line: 257*/
} /* Line: 257*/
return bevp_minCpos;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_ret = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevl_ret = bem_classNameGet_0();
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 267*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_3_BuildVar_bels_0));
bevt_1_ta_ph = bevl_ret.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = bevp_name.bem_toString_0();
bevl_ret = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
} /* Line: 268*/
if (bevp_isArg.bevi_bool)/* Line: 270*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_3_BuildVar_bels_1));
bevl_ret = bevl_ret.bem_add_1(bevt_4_ta_ph);
} /* Line: 271*/
if (bevp_isTmpVar.bevi_bool)/* Line: 273*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_3_BuildVar_bels_2));
bevl_ret = bevl_ret.bem_add_1(bevt_5_ta_ph);
} /* Line: 274*/
if (bevp_isDeclared.bevi_bool) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 276*/ {
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_3_BuildVar_bels_3));
bevl_ret = bevl_ret.bem_add_1(bevt_7_ta_ph);
} /* Line: 277*/
if (bevp_isProperty.bevi_bool)/* Line: 279*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_3_BuildVar_bels_4));
bevl_ret = bevl_ret.bem_add_1(bevt_8_ta_ph);
} /* Line: 280*/
return bevl_ret;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGet_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_namepathGetDirect_0() {
return bevp_namepath;
} /*method end*/
public BEC_2_5_3_BuildVar bem_namepathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_namepathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_namepath = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGet_0() {
return bevp_refs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_refsGetDirect_0() {
return bevp_refs;
} /*method end*/
public BEC_2_5_3_BuildVar bem_refsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_refs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_refsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_refs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGet_0() {
return bevp_allCalls;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_allCallsGetDirect_0() {
return bevp_allCalls;
} /*method end*/
public BEC_2_5_3_BuildVar bem_allCallsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_allCallsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_allCalls = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGet_0() {
return bevp_suffix;
} /*method end*/
public BEC_2_4_6_TextString bem_suffixGetDirect_0() {
return bevp_suffix;
} /*method end*/
public BEC_2_5_3_BuildVar bem_suffixSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_suffixSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_suffix = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGet_0() {
return bevp_isArg;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isArgGetDirect_0() {
return bevp_isArg;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isArgSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isArgSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isArg = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGet_0() {
return bevp_isAdded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAddedGetDirect_0() {
return bevp_isAdded;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isAddedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isAddedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isAdded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGet_0() {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTmpVarGetDirect_0() {
return bevp_isTmpVar;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTmpVarSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTmpVarSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTmpVar = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_autoTypeGet_0() {
return bevp_autoType;
} /*method end*/
public BEC_2_5_4_LogicBool bem_autoTypeGetDirect_0() {
return bevp_autoType;
} /*method end*/
public BEC_2_5_3_BuildVar bem_autoTypeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_autoType = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_autoTypeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_autoType = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGet_0() {
return bevp_isDeclared;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isDeclaredGetDirect_0() {
return bevp_isDeclared;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isDeclaredSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isDeclaredSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isDeclared = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGet_0() {
return bevp_isProperty;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isPropertyGetDirect_0() {
return bevp_isProperty;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isPropertySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isPropertySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isProperty = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGet_0() {
return bevp_numAssigns;
} /*method end*/
public BEC_2_4_3_MathInt bem_numAssignsGetDirect_0() {
return bevp_numAssigns;
} /*method end*/
public BEC_2_5_3_BuildVar bem_numAssignsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_numAssignsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numAssigns = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGet_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isTypedGetDirect_0() {
return bevp_isTyped;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTypedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isTypedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isTyped = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGet_0() {
return bevp_vpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_vposGetDirect_0() {
return bevp_vpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_vposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_vposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_vpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGet_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isSelfGetDirect_0() {
return bevp_isSelf;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSelfSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isSelfSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isSelf = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGet_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isThisGetDirect_0() {
return bevp_isThis;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isThisSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_isThisSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isThis = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_impliedGet_0() {
return bevp_implied;
} /*method end*/
public BEC_2_5_4_LogicBool bem_impliedGetDirect_0() {
return bevp_implied;
} /*method end*/
public BEC_2_5_3_BuildVar bem_impliedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_implied = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_impliedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_implied = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxCposGetDirect_0() {
return bevp_maxCpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_maxCposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_maxCposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_maxCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_minCposGetDirect_0() {
return bevp_minCpos;
} /*method end*/
public BEC_2_5_3_BuildVar bem_minCposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_minCposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_minCpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGet_0() {
return bevp_nativeName;
} /*method end*/
public BEC_2_4_6_TextString bem_nativeNameGetDirect_0() {
return bevp_nativeName;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nativeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_3_BuildVar bem_nativeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nativeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 215, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 237, 237, 238, 240, 244, 244, 244, 244, 245, 0, 245, 245, 246, 246, 246, 247, 247, 250, 254, 254, 256, 256, 256, 257, 0, 257, 257, 258, 258, 258, 259, 259, 262, 266, 267, 267, 268, 268, 268, 268, 271, 271, 274, 274, 276, 276, 277, 277, 280, 280, 282, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 73, 78, 79, 81, 94, 95, 100, 101, 103, 103, 106, 108, 109, 110, 111, 113, 114, 121, 134, 135, 136, 141, 142, 144, 144, 147, 149, 150, 151, 152, 154, 155, 162, 175, 176, 181, 182, 183, 184, 185, 188, 189, 192, 193, 195, 200, 201, 202, 205, 206, 208, 211, 214, 217, 221, 225, 228, 231, 235, 239, 242, 245, 249, 253, 256, 259, 263, 267, 270, 273, 277, 281, 284, 287, 291, 295, 298, 301, 305, 309, 312, 315, 319, 323, 326, 329, 333, 337, 340, 343, 347, 351, 354, 357, 361, 365, 368, 371, 375, 379, 382, 385, 389, 393, 396, 399, 403, 407, 410, 413, 417, 421, 424, 427, 431, 435, 438, 441, 445, 449, 452, 456, 460, 463, 467, 471, 474, 477, 481};
/* BEGIN LINEINFO 
assign 1 202 39
new 0 202 39
assign 1 203 40
new 0 203 40
assign 1 204 41
new 0 204 41
assign 1 205 42
new 0 205 42
assign 1 206 43
new 0 206 43
assign 1 207 44
new 0 207 44
assign 1 208 45
new 0 208 45
assign 1 209 46
new 0 209 46
assign 1 210 47
new 0 210 47
assign 1 211 48
new 0 211 48
assign 1 212 49
new 0 212 49
assign 1 213 50
new 0 213 50
assign 1 214 51
new 0 214 51
assign 1 215 52
new 0 215 52
assign 1 215 53
maxGet 0 215 53
assign 1 222 57
isArgGet 0 222 57
assign 1 223 58
nameGet 0 223 58
assign 1 224 59
isAddedGet 0 224 59
assign 1 225 60
isTmpVarGet 0 225 60
assign 1 226 61
isPropertyGet 0 226 61
assign 1 227 62
new 0 227 62
assign 1 228 63
namepathGet 0 228 63
assign 1 229 64
isTypedGet 0 229 64
assign 1 230 65
vposGet 0 230 65
assign 1 231 66
isSelfGet 0 231 66
assign 1 232 67
isThisGet 0 232 67
assign 1 233 68
impliedGet 0 233 68
assign 1 237 73
undef 1 237 78
assign 1 238 79
new 0 238 79
addValue 1 240 81
assign 1 244 94
new 0 244 94
assign 1 244 95
greater 1 244 100
return 1 244 101
assign 1 245 103
setIteratorGet 0 0 103
assign 1 245 106
hasNextGet 0 245 106
assign 1 245 108
nextGet 0 245 108
assign 1 246 109
heldGet 0 246 109
assign 1 246 110
cposGet 0 246 110
assign 1 246 111
greater 1 246 111
assign 1 247 113
heldGet 0 247 113
assign 1 247 114
cposGet 0 247 114
return 1 250 121
assign 1 254 134
new 0 254 134
assign 1 254 135
maxGet 0 254 135
assign 1 256 136
lesser 1 256 141
return 1 256 142
assign 1 257 144
setIteratorGet 0 0 144
assign 1 257 147
hasNextGet 0 257 147
assign 1 257 149
nextGet 0 257 149
assign 1 258 150
heldGet 0 258 150
assign 1 258 151
cposGet 0 258 151
assign 1 258 152
lesser 1 258 152
assign 1 259 154
heldGet 0 259 154
assign 1 259 155
cposGet 0 259 155
return 1 262 162
assign 1 266 175
classNameGet 0 266 175
assign 1 267 176
def 1 267 181
assign 1 268 182
new 0 268 182
assign 1 268 183
add 1 268 183
assign 1 268 184
toString 0 268 184
assign 1 268 185
add 1 268 185
assign 1 271 188
new 0 271 188
assign 1 271 189
add 1 271 189
assign 1 274 192
new 0 274 192
assign 1 274 193
add 1 274 193
assign 1 276 195
not 0 276 200
assign 1 277 201
new 0 277 201
assign 1 277 202
add 1 277 202
assign 1 280 205
new 0 280 205
assign 1 280 206
add 1 280 206
return 1 282 208
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
return 1 0 225
return 1 0 228
assign 1 0 231
assign 1 0 235
return 1 0 239
return 1 0 242
assign 1 0 245
assign 1 0 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
return 1 0 267
return 1 0 270
assign 1 0 273
assign 1 0 277
return 1 0 281
return 1 0 284
assign 1 0 287
assign 1 0 291
return 1 0 295
return 1 0 298
assign 1 0 301
assign 1 0 305
return 1 0 309
return 1 0 312
assign 1 0 315
assign 1 0 319
return 1 0 323
return 1 0 326
assign 1 0 329
assign 1 0 333
return 1 0 337
return 1 0 340
assign 1 0 343
assign 1 0 347
return 1 0 351
return 1 0 354
assign 1 0 357
assign 1 0 361
return 1 0 365
return 1 0 368
assign 1 0 371
assign 1 0 375
return 1 0 379
return 1 0 382
assign 1 0 385
assign 1 0 389
return 1 0 393
return 1 0 396
assign 1 0 399
assign 1 0 403
return 1 0 407
return 1 0 410
assign 1 0 413
assign 1 0 417
return 1 0 421
return 1 0 424
assign 1 0 427
assign 1 0 431
return 1 0 435
return 1 0 438
assign 1 0 441
assign 1 0 445
return 1 0 449
assign 1 0 452
assign 1 0 456
return 1 0 460
assign 1 0 463
assign 1 0 467
return 1 0 471
return 1 0 474
assign 1 0 477
assign 1 0 481
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -180800260: return bem_isDeclaredGet_0();
case -1293152750: return bem_suffixGet_0();
case -2105837707: return bem_maxCposGet_0();
case 1527025322: return bem_nameGet_0();
case -1387831588: return bem_print_0();
case -1188922735: return bem_echo_0();
case -981768514: return bem_minCposGet_0();
case -793241295: return bem_iteratorGet_0();
case -13508153: return bem_isArgGet_0();
case 1745688931: return bem_numAssignsGet_0();
case 1868188754: return bem_isTypedGet_0();
case 371157924: return bem_sourceFileNameGet_0();
case 2008673206: return bem_minCposGetDirect_0();
case 1561676621: return bem_isThisGetDirect_0();
case 725866279: return bem_isAddedGet_0();
case 1652521523: return bem_serializeContents_0();
case -1760538533: return bem_classNameGet_0();
case -291993755: return bem_refsGet_0();
case 7254011: return bem_fieldIteratorGet_0();
case -321491131: return bem_namepathGetDirect_0();
case -351728783: return bem_isTmpVarGetDirect_0();
case -967401154: return bem_impliedGetDirect_0();
case -921473949: return bem_fieldNamesGet_0();
case 1575049252: return bem_nativeNameGet_0();
case 503075461: return bem_autoTypeGetDirect_0();
case 895193825: return bem_once_0();
case 1696333798: return bem_isTypedGetDirect_0();
case -826382414: return bem_nativeNameGetDirect_0();
case 304677450: return bem_allCallsGetDirect_0();
case -467511392: return bem_toString_0();
case -1323898541: return bem_toAny_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -1477180092: return bem_isPropertyGetDirect_0();
case 1403688004: return bem_serializationIteratorGet_0();
case 527909107: return bem_isThisGet_0();
case 782632493: return bem_namepathGet_0();
case -447432319: return bem_many_0();
case 1597327951: return bem_create_0();
case -1363819567: return bem_new_0();
case -1324359858: return bem_impliedGet_0();
case 1537417022: return bem_isPropertyGet_0();
case 1853983439: return bem_autoTypeGet_0();
case 676017467: return bem_isTmpVarGet_0();
case -73616016: return bem_numAssignsGetDirect_0();
case -1813683359: return bem_isSelfGet_0();
case 1331552330: return bem_nameGetDirect_0();
case 1092105192: return bem_hashGet_0();
case 1319790445: return bem_refsGetDirect_0();
case -904392870: return bem_vposGetDirect_0();
case -105946774: return bem_serializeToString_0();
case -270133920: return bem_isAddedGetDirect_0();
case -2039790375: return bem_maxCposGetDirect_0();
case 1890854002: return bem_tagGet_0();
case 325064699: return bem_vposGet_0();
case -2110063855: return bem_isArgGetDirect_0();
case -598488712: return bem_suffixGetDirect_0();
case -66591364: return bem_isDeclaredGetDirect_0();
case 286644572: return bem_isSelfGetDirect_0();
case 648502193: return bem_allCallsGet_0();
case 1319388306: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1302681807: return bem_isTypedSet_1(bevd_0);
case 1063204125: return bem_suffixSetDirect_1(bevd_0);
case -1694390067: return bem_isTmpVarSetDirect_1(bevd_0);
case -1764820812: return bem_isSelfSet_1(bevd_0);
case -1959424074: return bem_isDeclaredSet_1(bevd_0);
case 1163991368: return bem_nativeNameSetDirect_1(bevd_0);
case -1346446723: return bem_isAddedSet_1(bevd_0);
case 1139081880: return bem_isTypedSetDirect_1(bevd_0);
case -1915653832: return bem_maxCposSet_1(bevd_0);
case 1194681658: return bem_autoTypeSetDirect_1(bevd_0);
case 537444310: return bem_synNew_1((BEC_2_5_3_BuildVar) bevd_0);
case -338398155: return bem_isThisSet_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -249868203: return bem_addCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case 556253518: return bem_namepathSet_1(bevd_0);
case 1203207138: return bem_impliedSet_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 589263434: return bem_numAssignsSet_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1658946285: return bem_nativeNameSet_1(bevd_0);
case 616505278: return bem_isDeclaredSetDirect_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case 223542336: return bem_minCposSet_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -281232665: return bem_nameSet_1(bevd_0);
case 597829332: return bem_vposSet_1(bevd_0);
case -1216785749: return bem_isAddedSetDirect_1(bevd_0);
case -1250946814: return bem_isArgSet_1(bevd_0);
case -244405125: return bem_namepathSetDirect_1(bevd_0);
case 123243706: return bem_isPropertySet_1(bevd_0);
case -658011031: return bem_isTmpVarSet_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -402438439: return bem_nameSetDirect_1(bevd_0);
case -1294336379: return bem_autoTypeSet_1(bevd_0);
case 1472826238: return bem_vposSetDirect_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case -1112528230: return bem_isThisSetDirect_1(bevd_0);
case -1429810201: return bem_numAssignsSetDirect_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case -1423185515: return bem_isPropertySetDirect_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -1575342143: return bem_allCallsSetDirect_1(bevd_0);
case 1997684063: return bem_impliedSetDirect_1(bevd_0);
case -1546906820: return bem_isSelfSetDirect_1(bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case 1220976603: return bem_allCallsSet_1(bevd_0);
case -1794362496: return bem_refsSet_1(bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case 1736601739: return bem_minCposSetDirect_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -424070913: return bem_refsSetDirect_1(bevd_0);
case -478969989: return bem_maxCposSetDirect_1(bevd_0);
case 775613261: return bem_isArgSetDirect_1(bevd_0);
case 2102454943: return bem_suffixSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_5_3_BuildVar_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(26, becc_BEC_2_5_3_BuildVar_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_3_BuildVar();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst = (BEC_2_5_3_BuildVar) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_3_BuildVar.bece_BEC_2_5_3_BuildVar_bevs_type;
}
}
}
