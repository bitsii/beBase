namespace be {
/* IO:File: source/build/CSEmitter.be */
public sealed class BEC_2_5_9_BuildCSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCSEmitter() { }
static BEC_2_5_9_BuildCSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_0 = {0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_1 = {0x2E,0x63,0x73};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_3 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_4 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_5 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_6 = {0x28,0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_6, 31));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_7 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_7, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_8 = {0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_9 = {0x62,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_10 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_11 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_12 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x65,0x61,0x6C,0x65,0x64,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_13 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x6F,0x76,0x65,0x72,0x72,0x69,0x64,0x65,0x20};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_14 = {0x62,0x61,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_15 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_15, 15));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_16 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_16, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_17 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_17, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_18 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_18, 18));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_19 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_19, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_20 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x4D,0x61,0x69,0x6E,0x28,0x73,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_20, 38));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_21 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_21, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_22 = {0x6C,0x6F,0x63,0x6B,0x20,0x28,0x74,0x79,0x70,0x65,0x6F,0x66,0x28};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_23 = {0x29,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_24 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_25 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_26 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_27 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_27, 10));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_28 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_29 = {0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_29, 1));
private static byte[] bece_BEC_2_5_9_BuildCSEmitter_bels_30 = {0x20,0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCSEmitter_bels_30, 3));
public static new BEC_2_5_9_BuildCSEmitter bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCSEmitter_bels_2));
base.bem_new_1(beva__build);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_0;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCSEmitter_bels_4));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCSEmitter_bels_5));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1713234403);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(582228008);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_1;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_2;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_8));
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, bevt_16_tmpany_phold);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_9));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_csyn.bem_isFinalGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
if (beva_msyn == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_3_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 40 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 40 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 40 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCSEmitter_bels_10));
return bevt_4_tmpany_phold;
} /* Line: 41 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCSEmitter_bels_11));
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
if (beva_msyn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_2_tmpany_phold = beva_msyn.bem_isFinalGet_0();
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 47 */
 else  /* Line: 47 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 47 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCSEmitter_bels_12));
return bevt_3_tmpany_phold;
} /* Line: 48 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCSEmitter_bels_13));
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_14));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_3;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_4;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_5;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_6;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_typeName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_7;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_8;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_9;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCSEmitter_bels_22));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCSEmitter_bels_23));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCSEmitter_bels_24));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCSEmitter_bels_25));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-20081513);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCSEmitter_bels_26));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_ms;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_0_tmpany_phold = bem_beginNs_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_10;
bevt_4_tmpany_phold = bem_libNs_1(beva_libName);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_11;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getNameSpace_1(beva_libName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCSEmitter_bevo_13;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 27, 27, 27, 28, 29, 29, 29, 29, 29, 29, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 36, 36, 40, 0, 40, 40, 40, 0, 0, 0, 0, 0, 41, 41, 43, 43, 47, 47, 47, 0, 0, 0, 48, 48, 50, 50, 54, 54, 58, 58, 58, 58, 58, 63, 64, 65, 65, 65, 66, 72, 72, 72, 72, 72, 72, 76, 76, 76, 76, 76, 77, 77, 77, 77, 77, 77, 78, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 80, 84, 84, 84, 88, 88, 88, 88, 88, 88, 88, 92, 92, 96, 96, 96, 100, 100, 100, 100, 104, 104};
public static new int[] bevs_smnlec
 = new int[] {55, 56, 57, 58, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 105, 106, 115, 117, 120, 125, 126, 128, 131, 135, 138, 141, 145, 146, 148, 149, 157, 162, 163, 165, 168, 172, 175, 176, 178, 179, 183, 184, 191, 192, 193, 194, 195, 201, 202, 203, 204, 205, 206, 215, 216, 217, 218, 219, 220, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 269, 270, 271, 280, 281, 282, 283, 284, 285, 286, 290, 291, 296, 297, 298, 304, 305, 306, 307, 311, 312};
/* BEGIN LINEINFO 
assign 1 17 55
new 0 17 55
assign 1 18 56
new 0 18 56
assign 1 19 57
new 0 19 57
new 1 23 58
assign 1 27 80
new 0 27 80
assign 1 27 81
toString 0 27 81
assign 1 27 82
add 1 27 82
incrementValue 0 28 83
assign 1 29 84
new 0 29 84
assign 1 29 85
addValue 1 29 85
assign 1 29 86
addValue 1 29 86
assign 1 29 87
new 0 29 87
assign 1 29 88
addValue 1 29 88
addValue 1 29 89
assign 1 31 90
containedGet 0 31 90
assign 1 31 91
firstGet 0 31 91
assign 1 31 92
containedGet 0 31 92
assign 1 31 93
firstGet 0 31 93
assign 1 31 94
new 0 31 94
assign 1 31 95
add 1 31 95
assign 1 31 96
new 0 31 96
assign 1 31 97
add 1 31 97
assign 1 31 98
new 0 31 98
assign 1 31 99
finalAssign 4 31 99
addValue 1 31 100
assign 1 36 105
new 0 36 105
return 1 36 106
assign 1 40 115
isFinalGet 0 40 115
assign 1 0 117
assign 1 40 120
def 1 40 125
assign 1 40 126
isFinalGet 0 40 126
assign 1 0 128
assign 1 0 131
assign 1 0 135
assign 1 0 138
assign 1 0 141
assign 1 41 145
new 0 41 145
return 1 41 146
assign 1 43 148
new 0 43 148
return 1 43 149
assign 1 47 157
def 1 47 162
assign 1 47 163
isFinalGet 0 47 163
assign 1 0 165
assign 1 0 168
assign 1 0 172
assign 1 48 175
new 0 48 175
return 1 48 176
assign 1 50 178
new 0 50 178
return 1 50 179
assign 1 54 183
new 0 54 183
return 1 54 184
assign 1 58 191
new 0 58 191
assign 1 58 192
add 1 58 192
assign 1 58 193
new 0 58 193
assign 1 58 194
add 1 58 194
return 1 58 195
getCode 2 63 201
assign 1 64 202
toHexString 1 64 202
assign 1 65 203
new 0 65 203
assign 1 65 204
once 0 65 204
addValue 1 65 205
addValue 1 66 206
assign 1 72 215
new 0 72 215
assign 1 72 216
add 1 72 216
assign 1 72 217
new 0 72 217
assign 1 72 218
add 1 72 218
assign 1 72 219
add 1 72 219
return 1 72 220
assign 1 76 242
new 0 76 242
assign 1 76 243
add 1 76 243
assign 1 76 244
new 0 76 244
assign 1 76 245
add 1 76 245
assign 1 76 246
add 1 76 246
assign 1 77 247
new 0 77 247
assign 1 77 248
addValue 1 77 248
assign 1 77 249
addValue 1 77 249
assign 1 77 250
new 0 77 250
assign 1 77 251
addValue 1 77 251
addValue 1 77 252
assign 1 78 253
new 0 78 253
assign 1 78 254
addValue 1 78 254
addValue 1 78 255
assign 1 79 256
new 0 79 256
assign 1 79 257
addValue 1 79 257
assign 1 79 258
outputPlatformGet 0 79 258
assign 1 79 259
nameGet 0 79 259
assign 1 79 260
addValue 1 79 260
assign 1 79 261
new 0 79 261
assign 1 79 262
addValue 1 79 262
addValue 1 79 263
return 1 80 264
assign 1 84 269
libNameGet 0 84 269
assign 1 84 270
beginNs 1 84 270
return 1 84 271
assign 1 88 280
new 0 88 280
assign 1 88 281
libNs 1 88 281
assign 1 88 282
add 1 88 282
assign 1 88 283
new 0 88 283
assign 1 88 284
add 1 88 284
assign 1 88 285
add 1 88 285
return 1 88 286
assign 1 92 290
getNameSpace 1 92 290
return 1 92 291
assign 1 96 296
new 0 96 296
assign 1 96 297
add 1 96 297
return 1 96 298
assign 1 100 304
new 0 100 304
assign 1 100 305
once 0 100 305
assign 1 100 306
add 1 100 306
return 1 100 307
assign 1 104 311
new 0 104 311
return 1 104 312
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1503484208: return bem_instanceNotEqualGet_0();
case -231629009: return bem_methodCallsGet_0();
case -1707168997: return bem_buildCreate_0();
case -2046784533: return bem_echo_0();
case -1877971222: return bem_trueValueGet_0();
case -2056440002: return bem_fullLibEmitNameGet_0();
case -537857901: return bem_iteratorGet_0();
case 1249959235: return bem_fileExtGet_0();
case -1521916035: return bem_boolNpGet_0();
case -1976511455: return bem_libEmitPathGet_0();
case -1470298977: return bem_qGet_0();
case 262158621: return bem_returnTypeGet_0();
case -1732022465: return bem_classCallsGet_0();
case 717158289: return bem_fieldIteratorGet_0();
case -684212702: return bem_invpGet_0();
case 1067577432: return bem_falseValueGet_0();
case -593331488: return bem_onceCountGet_0();
case -173186399: return bem_toAny_0();
case 982670532: return bem_useDynMethodsGet_0();
case 1265204951: return bem_nlGet_0();
case 675544141: return bem_buildInitial_0();
case -2036656062: return bem_lastMethodBodyLinesGet_0();
case 814639632: return bem_new_0();
case 242412997: return bem_superCallsGet_0();
case -1088042789: return bem_classEndGet_0();
case 1973131926: return bem_serializeToString_0();
case 34035866: return bem_classNameGet_0();
case -125946934: return bem_serializeContents_0();
case 1819860805: return bem_lineCountGet_0();
case -506929281: return bem_emitLangGet_0();
case -448175942: return bem_methodsGet_0();
case -167610447: return bem_mnodeGet_0();
case -2089907154: return bem_create_0();
case -268247078: return bem_maxSpillArgsLenGet_0();
case 567511740: return bem_onceDecsGet_0();
case 2035877017: return bem_spropDecGet_0();
case -711989776: return bem_maxDynArgsGet_0();
case -91555152: return bem_methodCatchGet_0();
case -65469198: return bem_instOfGet_0();
case 1066959966: return bem_synEmitPathGet_0();
case -2129255989: return bem_hashGet_0();
case -52063515: return bem_lastMethodsLinesGet_0();
case 648165913: return bem_print_0();
case -860519417: return bem_propertyDecsGet_0();
case -109602708: return bem_toString_0();
case -750932870: return bem_overrideMtdDecGet_0();
case 299265439: return bem_endNs_0();
case -1801022076: return bem_mainEndGet_0();
case -78785953: return bem_scvpGet_0();
case 1511689560: return bem_doEmit_0();
case 1597303537: return bem_ccCacheGet_0();
case -360332104: return bem_nativeCSlotsGet_0();
case 2142243846: return bem_runtimeInitGet_0();
case 586793704: return bem_lastCallGet_0();
case -851007084: return bem_lastMethodsSizeGet_0();
case -1462205898: return bem_coanyiantReturnsGet_0();
case 2093378029: return bem_stringNpGet_0();
case 477041164: return bem_classConfGet_0();
case 1688910336: return bem_mainStartGet_0();
case 1350896394: return bem_inFilePathedGet_0();
case 250550410: return bem_csynGet_0();
case -2049991627: return bem_once_0();
case 1905184732: return bem_lastMethodBodySizeGet_0();
case 1536433852: return bem_getClassOutput_0();
case -1556753014: return bem_buildGet_0();
case 790512409: return bem_smnlcsGet_0();
case -91772231: return bem_constGet_0();
case 99641680: return bem_sourceFileNameGet_0();
case 1414766518: return bem_cnodeGet_0();
case 2036051133: return bem_tagGet_0();
case -1407415064: return bem_buildClassInfo_0();
case -2081773815: return bem_dynMethodsGet_0();
case -759830880: return bem_intNpGet_0();
case -1723144094: return bem_parentConfGet_0();
case 72890251: return bem_objectCcGet_0();
case -263538214: return bem_propDecGet_0();
case 2101176954: return bem_saveSyns_0();
case 2025472028: return bem_nameToIdGet_0();
case 2082586952: return bem_mainInClassGet_0();
case 239879194: return bem_preClassGet_0();
case -1987363705: return bem_libEmitNameGet_0();
case -937763332: return bem_ccMethodsGet_0();
case 432735873: return bem_deserializeClassNameGet_0();
case -2106654919: return bem_transGet_0();
case 1688142120: return bem_classesInDepthOrderGet_0();
case -1398257774: return bem_boolCcGet_0();
case -1536037533: return bem_mainOutsideNsGet_0();
case -1653307562: return bem_serializationIteratorGet_0();
case 115915646: return bem_callNamesGet_0();
case -1645805502: return bem_beginNs_0();
case 1366168343: return bem_objectNpGet_0();
case 1652623656: return bem_boolTypeGet_0();
case 1412767150: return bem_floatNpGet_0();
case -1678256255: return bem_methodBodyGet_0();
case 529883642: return bem_classEmitsGet_0();
case 2048361265: return bem_many_0();
case -1067206556: return bem_nullValueGet_0();
case -53928550: return bem_smnlecsGet_0();
case 103198629: return bem_instanceEqualGet_0();
case -1925536545: return bem_baseMtdDecGet_0();
case -863950628: return bem_idToNameGet_0();
case 1761088319: return bem_initialDecGet_0();
case -326152805: return bem_copy_0();
case 127581635: return bem_getLibOutput_0();
case 2071176550: return bem_msynGet_0();
case 1434034732: return bem_afterCast_0();
case -1495779104: return bem_exceptDecGet_0();
case 561936341: return bem_randGet_0();
case -498367570: return bem_ntypesGet_0();
case -1651557160: return bem_superNameGet_0();
case -872390382: return bem_baseSmtdDecGet_0();
case -1016545624: return bem_emitLib_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1342987010: return bem_intNpSet_1(bevd_0);
case 345185281: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 15663479: return bem_onceDecsSet_1(bevd_0);
case -1179462483: return bem_nativeCSlotsSet_1(bevd_0);
case 1320850171: return bem_qSet_1(bevd_0);
case -1166370542: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 569199667: return bem_undefined_1(bevd_0);
case -152093488: return bem_ccMethodsSet_1(bevd_0);
case 1121176884: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1979054185: return bem_instanceNotEqualSet_1(bevd_0);
case 1897699399: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1102414111: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -691602395: return bem_onceCountSet_1(bevd_0);
case 1273545128: return bem_stringNpSet_1(bevd_0);
case -67423391: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1634298187: return bem_end_1(bevd_0);
case -1535387660: return bem_classConfSet_1(bevd_0);
case -20038017: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -569882115: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 971676873: return bem_randSet_1(bevd_0);
case 1402214618: return bem_superCallsSet_1(bevd_0);
case 20627805: return bem_libEmitPathSet_1(bevd_0);
case -692186155: return bem_trueValueSet_1(bevd_0);
case 291302174: return bem_nameToIdSet_1(bevd_0);
case 549239575: return bem_otherType_1(bevd_0);
case -1421894349: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1887120745: return bem_sameObject_1(bevd_0);
case 1290400575: return bem_undef_1(bevd_0);
case 262136334: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -291644992: return bem_lastMethodsSizeSet_1(bevd_0);
case -420585939: return bem_equals_1(bevd_0);
case -837309337: return bem_instanceEqualSet_1(bevd_0);
case -206409898: return bem_methodBodySet_1(bevd_0);
case -954152305: return bem_objectCcSet_1(bevd_0);
case 1001778547: return bem_callNamesSet_1(bevd_0);
case -323953622: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 237477492: return bem_invpSet_1(bevd_0);
case -1052976456: return bem_begin_1(bevd_0);
case 1637678954: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2068040715: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1038696049: return bem_transSet_1(bevd_0);
case -2096802344: return bem_smnlcsSet_1(bevd_0);
case 1093363744: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -24051681: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 38983543: return bem_idToNameSet_1(bevd_0);
case 1940516897: return bem_sameClass_1(bevd_0);
case 1249371582: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1371169171: return bem_preClassSet_1(bevd_0);
case -1241357762: return bem_dynMethodsSet_1(bevd_0);
case 586466215: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -258046467: return bem_floatNpSet_1(bevd_0);
case 181207960: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1340333252: return bem_ccCacheSet_1(bevd_0);
case 1977925330: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1442729113: return bem_cnodeSet_1(bevd_0);
case -1087214764: return bem_inFilePathedSet_1(bevd_0);
case -1980404261: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1114510022: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 755365358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1957594462: return bem_ntypesSet_1(bevd_0);
case 668704089: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 2124446865: return bem_objectNpSet_1(bevd_0);
case 2050633623: return bem_propertyDecsSet_1(bevd_0);
case -744292434: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 217239677: return bem_emitLangSet_1(bevd_0);
case -1840995531: return bem_classesInDepthOrderSet_1(bevd_0);
case -1242762805: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1725813495: return bem_buildSet_1(bevd_0);
case 209247596: return bem_methodCatchSet_1(bevd_0);
case 634346029: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1692946273: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1359485455: return bem_csynSet_1(bevd_0);
case 1523133504: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2142188146: return bem_lastMethodBodySizeSet_1(bevd_0);
case 902325492: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -241371051: return bem_scvpSet_1(bevd_0);
case -1455830815: return bem_smnlecsSet_1(bevd_0);
case -1220227899: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -853375001: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1587074662: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1996549809: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 630759147: return bem_returnTypeSet_1(bevd_0);
case 1646332760: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1453009437: return bem_exceptDecSet_1(bevd_0);
case -1752920764: return bem_methodsSet_1(bevd_0);
case 1250199733: return bem_fileExtSet_1(bevd_0);
case -1629045646: return bem_classEmitsSet_1(bevd_0);
case 1359155512: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -587630873: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 2020721234: return bem_boolNpSet_1(bevd_0);
case 1884868747: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1795432183: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 484096285: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 786369211: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1051082549: return bem_synEmitPathSet_1(bevd_0);
case 2141765988: return bem_lastMethodsLinesSet_1(bevd_0);
case -1039512526: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -169401475: return bem_otherClass_1(bevd_0);
case 1994260011: return bem_nlSet_1(bevd_0);
case -160591275: return bem_maxDynArgsSet_1(bevd_0);
case 478132461: return bem_fullLibEmitNameSet_1(bevd_0);
case -1854724553: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -908917157: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -15986989: return bem_lastCallSet_1(bevd_0);
case 1226495395: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1342415374: return bem_constSet_1(bevd_0);
case 991182700: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1611450524: return bem_instOfSet_1(bevd_0);
case -1369439027: return bem_notEquals_1(bevd_0);
case -2031862922: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 496157614: return bem_boolCcSet_1(bevd_0);
case -491345013: return bem_sameType_1(bevd_0);
case -1808237618: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 2126649322: return bem_mnodeSet_1(bevd_0);
case -143017218: return bem_copyTo_1(bevd_0);
case 1341260987: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1785998917: return bem_falseValueSet_1(bevd_0);
case -1091318965: return bem_defined_1(bevd_0);
case -815875225: return bem_classCallsSet_1(bevd_0);
case 161057711: return bem_libEmitNameSet_1(bevd_0);
case -774932373: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1201802784: return bem_nullValueSet_1(bevd_0);
case -1673221667: return bem_parentConfSet_1(bevd_0);
case -897961761: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -64660111: return bem_lineCountSet_1(bevd_0);
case -1528518624: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -645976199: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1393267925: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1492255674: return bem_def_1(bevd_0);
case -96286522: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1003410755: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 5463926: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 922062179: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -140353519: return bem_methodCallsSet_1(bevd_0);
case 1162113479: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 207708785: return bem_msynSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1008056884: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1549801515: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1792455468: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -888732535: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1279097513: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1151786117: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1823742306: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -529079079: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 55863465: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 466148991: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1682274963: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -50371904: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 967378502: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1422666964: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -18185071: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 951303004: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1770740990: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1294864810: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1208056759: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1111196990: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 251127387: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 126250000: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -777564197: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1604232586: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1492297133: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2128692013: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst = (BEC_2_5_9_BuildCSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCSEmitter.bece_BEC_2_5_9_BuildCSEmitter_bevs_inst;
}
}
}
