namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_3_6_4_10_SystemTestExtendable : BEC_2_6_6_SystemObject {
public BEC_3_6_4_10_SystemTestExtendable() { }
static BEC_3_6_4_10_SystemTestExtendable() { }
private static byte[] becc_BEC_3_6_4_10_SystemTestExtendable_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x65,0x73,0x74,0x3A,0x45,0x78,0x74,0x65,0x6E,0x64,0x61,0x62,0x6C,0x65};
private static byte[] becc_BEC_3_6_4_10_SystemTestExtendable_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_3_6_4_10_SystemTestExtendable bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst;
public BEC_2_6_6_SystemObject bevp_propa;
public BEC_2_6_6_SystemObject bevp_propb;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_3_6_4_10_SystemTestExtendable bem_acall_0() {
return this;
} /*method end*/
public virtual BEC_3_6_4_10_SystemTestExtendable bem_bcall_0() {
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_propaGet_0() {
return bevp_propa;
} /*method end*/
public virtual BEC_3_6_4_10_SystemTestExtendable bem_propaSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propa = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_propbGet_0() {
return bevp_propb;
} /*method end*/
public virtual BEC_3_6_4_10_SystemTestExtendable bem_propbSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_propb = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 24, 28, 31};
/* BEGIN LINEINFO 
return 1 0 21
assign 1 0 24
return 1 0 28
assign 1 0 31
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 814639632: return bem_new_0();
case 648165913: return bem_print_0();
case 1595648795: return bem_propaGet_0();
case -537857901: return bem_iteratorGet_0();
case 2036051133: return bem_tagGet_0();
case -125946934: return bem_serializeContents_0();
case -2049991627: return bem_once_0();
case 34035866: return bem_classNameGet_0();
case -693021416: return bem_propbGet_0();
case -2046784533: return bem_echo_0();
case -326152805: return bem_copy_0();
case 432735873: return bem_deserializeClassNameGet_0();
case -1653307562: return bem_serializationIteratorGet_0();
case 2048361265: return bem_many_0();
case 717158289: return bem_fieldIteratorGet_0();
case -1901083535: return bem_acall_0();
case -2089907154: return bem_create_0();
case -109602708: return bem_toString_0();
case -173186399: return bem_toAny_0();
case 1973131926: return bem_serializeToString_0();
case -336217802: return bem_bcall_0();
case 99641680: return bem_sourceFileNameGet_0();
case -2129255989: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -420585939: return bem_equals_1(bevd_0);
case -2031862922: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1887120745: return bem_sameObject_1(bevd_0);
case 569199667: return bem_undefined_1(bevd_0);
case -491345013: return bem_sameType_1(bevd_0);
case 755365358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1290400575: return bem_undef_1(bevd_0);
case -1393267925: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 549239575: return bem_otherType_1(bevd_0);
case -1091318965: return bem_defined_1(bevd_0);
case 1967888425: return bem_propbSet_1(bevd_0);
case -143017218: return bem_copyTo_1(bevd_0);
case 1940516897: return bem_sameClass_1(bevd_0);
case -1369439027: return bem_notEquals_1(bevd_0);
case 991182700: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1531228962: return bem_propaSet_1(bevd_0);
case -169401475: return bem_otherClass_1(bevd_0);
case 1492255674: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1008056884: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1151786117: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1422666964: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 466148991: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1823742306: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -50371904: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 967378502: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_3_6_4_10_SystemTestExtendable_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_3_6_4_10_SystemTestExtendable_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_4_10_SystemTestExtendable();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_4_10_SystemTestExtendable.bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst = (BEC_3_6_4_10_SystemTestExtendable) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_4_10_SystemTestExtendable.bece_BEC_3_6_4_10_SystemTestExtendable_bevs_inst;
}
}
}
