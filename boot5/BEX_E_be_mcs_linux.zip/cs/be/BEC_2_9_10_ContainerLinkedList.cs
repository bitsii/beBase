namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList : BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
static BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static new BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_10_4_ContainerLinkedListNode) (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 137 */ {
return (BEC_2_6_6_SystemObject) bevl_other;
} /* Line: 138 */
while (true)
 /* Line: 142 */ {
if (bevl_f == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 144 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 145 */
if (bevl_fnode == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_fnode = bevl_f;
} /* Line: 149 */
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 152 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(-930777185, null);
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_node.bemd_1(-1155796989, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 164 */
 else  /* Line: 165 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 167 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(-930777185, null);
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 173 */ {
beva_node.bemd_1(-930777185, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 176 */
 else  /* Line: 177 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 179 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) {
beva_node.bemd_0(1543150642);
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) {
beva_node.bemd_1(1269561767, beva_toIns);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_0;
if (beva_pos.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 192 */ {
bevt_2_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 193 */
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 196 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 196 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 198 */
 else  /* Line: 199 */ {
break;
} /* Line: 200 */
bevl_i.bevi_int++;
} /* Line: 202 */
 else  /* Line: 196 */ {
break;
} /* Line: 196 */
} /* Line: 196 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 204 */ {
return null;
} /* Line: 205 */
bevt_6_tmpany_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 213 */ {
bevt_1_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 213 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 215 */
 else  /* Line: 216 */ {
break;
} /* Line: 217 */
bevl_i.bevi_int++;
} /* Line: 219 */
 else  /* Line: 213 */ {
break;
} /* Line: 213 */
} /* Line: 213 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 222 */
bevt_5_tmpany_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 228 */ {
return null;
} /* Line: 228 */
bevt_1_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_secondGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_3_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 233 */
 else  /* Line: 233 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 233 */ {
bevt_5_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_heldGet_0();
return bevt_4_tmpany_phold;
} /* Line: 234 */
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_thirdGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_4_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 240 */ {
bevt_7_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_nextGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 240 */ {
bevt_10_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_nextGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_heldGet_0();
return bevt_8_tmpany_phold;
} /* Line: 241 */
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 247 */ {
return null;
} /* Line: 247 */
bevt_1_tmpany_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_pos.bemd_1(-438440103, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 252 */ {
return bevp_firstNode;
} /* Line: 253 */
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 256 */ {
bevt_2_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 256 */ {
bevt_3_tmpany_phold = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 258 */
 else  /* Line: 259 */ {
break;
} /* Line: 260 */
bevl_i.bevi_int++;
} /* Line: 262 */
 else  /* Line: 256 */ {
break;
} /* Line: 256 */
} /* Line: 256 */
bevt_4_tmpany_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 264 */ {
return null;
} /* Line: 265 */
bevt_5_tmpany_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_held == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 276 */ {
bevt_2_tmpany_phold = beva_held.bemd_1(-1146451068, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 276 */
 else  /* Line: 276 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 276 */ {
bem_addAll_1(beva_held);
} /* Line: 277 */
 else  /* Line: 278 */ {
bem_addValueWhole_1(beva_held);
} /* Line: 279 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 284 */ {
while (true)
 /* Line: 285 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(463055371);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 285 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(-694819228);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 286 */
 else  /* Line: 285 */ {
break;
} /* Line: 285 */
} /* Line: 285 */
} /* Line: 285 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 292 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(876979386);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 293 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lengthGet_0() {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 304 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 304 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 306 */
 else  /* Line: 304 */ {
break;
} /* Line: 304 */
} /* Line: 304 */
return bevl_cnt;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_lengthGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 316 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 317 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_toNodeList_0() {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 326 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 326 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_2_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 328 */
bevl_cnt.bevi_int++;
} /* Line: 330 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
return bevl_toret;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_toList_0() {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 339 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 339 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 340 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-1883461653);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 341 */
bevl_cnt.bevi_int++;
} /* Line: 343 */
 else  /* Line: 339 */ {
break;
} /* Line: 339 */
} /* Line: 339 */
return bevl_toret;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_maxGet_0();
bevt_0_tmpany_phold = bem_subList_2(beva_start, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 366 */ {
return bevl_res;
} /* Line: 367 */
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 370 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-393670001);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 371 */ {
return bevl_res;
} /* Line: 372 */
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 375 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 376 */
bevl_i.bevi_int++;
} /* Line: 370 */
 else  /* Line: 370 */ {
break;
} /* Line: 370 */
} /* Line: 370 */
return bevl_res;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_reverse_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 419 */ {
if (bevl_current == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 419 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpany_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpany_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 424 */
 else  /* Line: 419 */ {
break;
} /* Line: 419 */
} /* Line: 419 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() {
return bevp_firstNode;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGetDirect_0() {
return bevp_firstNode;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() {
return bevp_lastNode;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGetDirect_0() {
return bevp_lastNode;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {129, 129, 134, 135, 136, 137, 137, 138, 142, 142, 143, 144, 144, 145, 148, 148, 149, 151, 152, 154, 155, 156, 160, 161, 161, 162, 163, 164, 166, 167, 172, 173, 173, 174, 175, 176, 178, 179, 184, 188, 192, 192, 192, 193, 193, 195, 196, 196, 197, 197, 198, 202, 204, 204, 205, 207, 207, 211, 211, 212, 213, 213, 214, 214, 215, 219, 221, 221, 222, 222, 224, 224, 228, 228, 228, 229, 229, 233, 233, 233, 233, 233, 0, 0, 0, 234, 234, 234, 236, 240, 240, 240, 240, 240, 0, 0, 0, 240, 240, 240, 240, 0, 0, 0, 241, 241, 241, 241, 243, 247, 247, 247, 248, 248, 252, 252, 253, 255, 256, 256, 257, 258, 262, 264, 265, 267, 267, 271, 272, 276, 276, 276, 0, 0, 0, 277, 279, 284, 284, 285, 286, 286, 292, 292, 293, 293, 298, 299, 303, 304, 304, 305, 306, 308, 312, 312, 316, 316, 317, 317, 319, 319, 323, 324, 325, 326, 326, 327, 327, 328, 328, 330, 332, 336, 337, 338, 339, 339, 340, 340, 341, 341, 341, 343, 345, 349, 349, 353, 353, 357, 357, 361, 361, 361, 361, 365, 366, 366, 367, 369, 370, 370, 370, 371, 371, 372, 374, 375, 375, 376, 370, 379, 417, 418, 419, 419, 420, 421, 421, 422, 423, 424, 426, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 34, 35, 36, 37, 42, 43, 47, 52, 53, 54, 59, 60, 62, 67, 68, 70, 71, 77, 78, 79, 83, 84, 89, 90, 91, 92, 95, 96, 102, 103, 108, 109, 110, 111, 114, 115, 120, 124, 137, 138, 143, 144, 145, 147, 148, 151, 153, 158, 159, 164, 170, 175, 176, 178, 179, 190, 191, 192, 193, 196, 198, 203, 204, 209, 215, 220, 221, 222, 224, 225, 230, 235, 236, 238, 239, 248, 253, 254, 255, 260, 261, 264, 268, 271, 272, 273, 275, 289, 294, 295, 296, 301, 302, 305, 309, 312, 313, 314, 319, 320, 323, 327, 330, 331, 332, 333, 335, 340, 345, 346, 348, 349, 360, 361, 363, 365, 366, 369, 371, 373, 378, 384, 386, 388, 389, 393, 394, 401, 406, 407, 409, 412, 416, 419, 422, 430, 435, 438, 440, 441, 453, 458, 459, 460, 466, 467, 474, 475, 478, 480, 481, 487, 491, 492, 498, 503, 504, 505, 507, 508, 518, 519, 520, 521, 524, 526, 531, 532, 533, 535, 541, 552, 553, 554, 555, 558, 560, 565, 566, 567, 568, 570, 576, 580, 581, 585, 586, 590, 591, 597, 598, 599, 600, 612, 613, 618, 619, 621, 622, 625, 630, 631, 632, 634, 636, 637, 642, 643, 645, 651, 659, 660, 663, 668, 669, 670, 671, 672, 673, 674, 680, 684, 687, 690, 694, 698, 701, 704, 708};
/* BEGIN LINEINFO 
assign 1 129 21
new 2 129 21
return 1 129 22
assign 1 134 34
create 0 134 34
assign 1 135 35
linkedListIteratorGet 0 135 35
assign 1 136 36
nextNodeGet 0 136 36
assign 1 137 37
undef 1 137 42
return 1 138 43
assign 1 142 47
def 1 142 52
assign 1 143 53
copy 0 143 53
assign 1 144 54
def 1 144 59
nextSet 1 145 60
assign 1 148 62
undef 1 148 67
assign 1 149 68
assign 1 151 70
assign 1 152 71
nextNodeGet 0 152 71
firstNodeSet 1 154 77
lastNodeSet 1 155 78
return 1 156 79
nextSet 1 160 83
assign 1 161 84
def 1 161 89
priorSet 1 162 90
nextSet 1 163 91
assign 1 164 92
assign 1 166 95
assign 1 167 96
nextSet 1 172 102
assign 1 173 103
def 1 173 108
nextSet 1 174 109
priorSet 1 175 110
assign 1 176 111
assign 1 178 114
assign 1 179 115
delete 0 184 120
insertBefore 1 188 124
assign 1 192 137
new 0 192 137
assign 1 192 138
equals 1 192 143
assign 1 193 144
heldGet 0 193 144
return 1 193 145
assign 1 195 147
new 0 195 147
assign 1 196 148
linkedListIteratorGet 0 196 148
assign 1 196 151
hasNextGet 0 196 151
assign 1 197 153
lesser 1 197 158
nextGet 0 198 159
incrementValue 0 202 164
assign 1 204 170
notEquals 1 204 175
return 1 205 176
assign 1 207 178
nextGet 0 207 178
return 1 207 179
assign 1 211 190
new 0 211 190
assign 1 211 191
add 1 211 191
assign 1 212 192
new 0 212 192
assign 1 213 193
linkedListIteratorGet 0 213 193
assign 1 213 196
hasNextGet 0 213 196
assign 1 214 198
lesser 1 214 203
nextGet 0 215 204
incrementValue 0 219 209
assign 1 221 215
notEquals 1 221 220
assign 1 222 221
new 0 222 221
return 1 222 222
assign 1 224 224
currentSet 1 224 224
return 1 224 225
assign 1 228 230
undef 1 228 235
return 1 228 236
assign 1 229 238
heldGet 0 229 238
return 1 229 239
assign 1 233 248
def 1 233 253
assign 1 233 254
nextGet 0 233 254
assign 1 233 255
def 1 233 260
assign 1 0 261
assign 1 0 264
assign 1 0 268
assign 1 234 271
nextGet 0 234 271
assign 1 234 272
heldGet 0 234 272
return 1 234 273
return 1 236 275
assign 1 240 289
def 1 240 294
assign 1 240 295
nextGet 0 240 295
assign 1 240 296
def 1 240 301
assign 1 0 302
assign 1 0 305
assign 1 0 309
assign 1 240 312
nextGet 0 240 312
assign 1 240 313
nextGet 0 240 313
assign 1 240 314
def 1 240 319
assign 1 0 320
assign 1 0 323
assign 1 0 327
assign 1 241 330
nextGet 0 241 330
assign 1 241 331
nextGet 0 241 331
assign 1 241 332
heldGet 0 241 332
return 1 241 333
return 1 243 335
assign 1 247 340
undef 1 247 345
return 1 247 346
assign 1 248 348
heldGet 0 248 348
return 1 248 349
assign 1 252 360
new 0 252 360
assign 1 252 361
equals 1 252 361
return 1 253 363
assign 1 255 365
new 0 255 365
assign 1 256 366
linkedListIteratorGet 0 256 366
assign 1 256 369
hasNextGet 0 256 369
assign 1 257 371
lesser 1 257 371
nextGet 0 258 373
incrementValue 0 262 378
assign 1 264 384
notEquals 1 264 384
return 1 265 386
assign 1 267 388
nextNodeGet 0 267 388
return 1 267 389
assign 1 271 393
newNode 1 271 393
appendNode 1 272 394
assign 1 276 401
def 1 276 406
assign 1 276 407
sameType 1 276 407
assign 1 0 409
assign 1 0 412
assign 1 0 416
addAll 1 277 419
addValueWhole 1 279 422
assign 1 284 430
def 1 284 435
assign 1 285 438
hasNextGet 0 285 438
assign 1 286 440
nextGet 0 286 440
addValueWhole 1 286 441
assign 1 292 453
def 1 292 458
assign 1 293 459
iteratorGet 0 293 459
iterateAdd 1 293 460
assign 1 298 466
newNode 1 298 466
prependNode 1 299 467
assign 1 303 474
new 0 303 474
assign 1 304 475
linkedListIteratorGet 0 304 475
assign 1 304 478
hasNextGet 0 304 478
nextGet 0 305 480
incrementValue 0 306 481
return 1 308 487
assign 1 312 491
lengthGet 0 312 491
return 1 312 492
assign 1 316 498
undef 1 316 503
assign 1 317 504
new 0 317 504
return 1 317 505
assign 1 319 507
new 0 319 507
return 1 319 508
assign 1 323 518
lengthGet 0 323 518
assign 1 324 519
new 1 324 519
assign 1 325 520
new 0 325 520
assign 1 326 521
linkedListIteratorGet 0 326 521
assign 1 326 524
hasNextGet 0 326 524
assign 1 327 526
lesser 1 327 531
assign 1 328 532
nextNodeGet 0 328 532
put 2 328 533
incrementValue 0 330 535
return 1 332 541
assign 1 336 552
lengthGet 0 336 552
assign 1 337 553
new 1 337 553
assign 1 338 554
new 0 338 554
assign 1 339 555
linkedListIteratorGet 0 339 555
assign 1 339 558
hasNextGet 0 339 558
assign 1 340 560
lesser 1 340 565
assign 1 341 566
nextNodeGet 0 341 566
assign 1 341 567
heldGet 0 341 567
put 2 341 568
incrementValue 0 343 570
return 1 345 576
assign 1 349 580
new 1 349 580
return 1 349 581
assign 1 353 585
new 1 353 585
return 1 353 586
assign 1 357 590
iteratorGet 0 357 590
return 1 357 591
assign 1 361 597
new 0 361 597
assign 1 361 598
maxGet 0 361 598
assign 1 361 599
subList 2 361 599
return 1 361 600
assign 1 365 612
create 0 365 612
assign 1 366 613
lesserEquals 1 366 618
return 1 367 619
assign 1 369 621
linkedListIteratorGet 0 369 621
assign 1 370 622
new 0 370 622
assign 1 370 625
lesser 1 370 630
assign 1 371 631
hasNextGet 0 371 631
assign 1 371 632
not 0 371 632
return 1 372 634
assign 1 374 636
nextGet 0 374 636
assign 1 375 637
greaterEquals 1 375 642
addValue 1 376 643
incrementValue 0 370 645
return 1 379 651
assign 1 417 659
assign 1 418 660
assign 1 419 663
def 1 419 668
assign 1 420 669
nextGet 0 420 669
assign 1 421 670
priorGet 0 421 670
nextSet 1 421 671
priorSet 1 422 672
assign 1 423 673
assign 1 424 674
assign 1 426 680
return 1 0 684
return 1 0 687
assign 1 0 690
assign 1 0 694
return 1 0 698
return 1 0 701
assign 1 0 704
assign 1 0 708
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1242864862: return bem_sourceFileNameGet_0();
case 1388220454: return bem_once_0();
case 1978340744: return bem_copy_0();
case -890418358: return bem_toList_0();
case -485032950: return bem_print_0();
case 426467685: return bem_reverse_0();
case 1139687182: return bem_serializeToString_0();
case -1936404363: return bem_create_0();
case 1115941233: return bem_hashGet_0();
case 347445468: return bem_deserializeClassNameGet_0();
case -1398827814: return bem_linkedListIteratorGet_0();
case -380774728: return bem_serializationIteratorGet_0();
case 1044385788: return bem_new_0();
case 876979386: return bem_iteratorGet_0();
case 262448459: return bem_fieldNamesGet_0();
case 1846641427: return bem_classNameGet_0();
case -1740849547: return bem_lastNodeGetDirect_0();
case -1624971764: return bem_lastNodeGet_0();
case -1718750264: return bem_tagGet_0();
case -779516368: return bem_firstNodeGetDirect_0();
case 895662367: return bem_firstNodeGet_0();
case -1287291624: return bem_toString_0();
case -1820718044: return bem_echo_0();
case -891127208: return bem_secondGet_0();
case 327132257: return bem_thirdGet_0();
case 1516511629: return bem_serializeContents_0();
case -1524745657: return bem_lengthGet_0();
case 860480151: return bem_sizeGet_0();
case -1497387944: return bem_many_0();
case 95635585: return bem_isEmptyGet_0();
case 913307545: return bem_toNodeList_0();
case 1048307819: return bem_firstGet_0();
case 1739040137: return bem_fieldIteratorGet_0();
case 855089063: return bem_toAny_0();
case 650227248: return bem_lastGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 477404510: return bem_undefined_1(bevd_0);
case 1882699238: return bem_addAll_1(bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case 1800266545: return bem_newNode_1(bevd_0);
case -1358600074: return bem_deleteNode_1(bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case -847200836: return bem_def_1(bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 749295197: return bem_prependNode_1(bevd_0);
case 822754754: return bem_lastNodeSet_1(bevd_0);
case 636511805: return bem_iterateAdd_1(bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1522863159: return bem_addValueWhole_1(bevd_0);
case -2119959723: return bem_firstNodeSetDirect_1(bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case 2065354175: return bem_prepend_1(bevd_0);
case -213795980: return bem_appendNode_1(bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case 308794437: return bem_lastNodeSetDirect_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case -33045067: return bem_firstNodeSet_1(bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case -1977071910: return bem_addValue_1(bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case -372698846: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case -440519128: return bem_getNode_1(bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case 178386925: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -422036668: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 360013839: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -1708323477: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_10_ContainerLinkedList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
}
