namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_10_ContainerLinkedList : BEC_2_6_6_SystemObject {
public BEC_2_9_10_ContainerLinkedList() { }
static BEC_2_9_10_ContainerLinkedList() { }
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_10_ContainerLinkedList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_10_ContainerLinkedList_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;

public static new BET_2_9_10_ContainerLinkedList bece_BEC_2_9_10_ContainerLinkedList_bevs_type;

public BEC_3_9_10_4_ContainerLinkedListNode bevp_firstNode;
public BEC_3_9_10_4_ContainerLinkedListNode bevp_lastNode;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_newNode_1(BEC_2_6_6_SystemObject beva_toHold) {
BEC_3_9_10_4_ContainerLinkedListNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_10_4_ContainerLinkedListNode) (new BEC_3_9_10_4_ContainerLinkedListNode()).bem_new_2(beva_toHold, this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_10_ContainerLinkedList bevl_other = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_f = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_fnode = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevl_other = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
bevl_iter = bem_linkedListIteratorGet_0();
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
if (bevl_f == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 137 */ {
return (BEC_2_6_6_SystemObject) bevl_other;
} /* Line: 138 */
while (true)
 /* Line: 142 */ {
if (bevl_f == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 142 */ {
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_f.bem_copy_0();
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 144 */ {
bevl_last.bem_nextSet_1(bevl_f);
} /* Line: 145 */
if (bevl_fnode == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_fnode = bevl_f;
} /* Line: 149 */
bevl_last = bevl_f;
bevl_f = (BEC_3_9_10_4_ContainerLinkedListNode) bevl_iter.bem_nextNodeGet_0();
} /* Line: 152 */
 else  /* Line: 142 */ {
break;
} /* Line: 142 */
} /* Line: 142 */
bevl_other.bem_firstNodeSet_1(bevl_fnode);
bevl_other.bem_lastNodeSet_1(bevl_last);
return (BEC_2_6_6_SystemObject) bevl_other;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_appendNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(705258073, null);
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_node.bemd_1(-1964949611, bevp_lastNode);
bevp_lastNode.bem_nextSet_1(beva_node);
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 164 */
 else  /* Line: 165 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 167 */
beva_node.bemd_1(-1551917268, this);
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_prependNode_1(BEC_2_6_6_SystemObject beva_node) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
beva_node.bemd_1(705258073, null);
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 174 */ {
beva_node.bemd_1(705258073, bevp_firstNode);
bevp_firstNode.bem_priorSet_1(beva_node);
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 177 */
 else  /* Line: 178 */ {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) beva_node;
} /* Line: 180 */
beva_node.bemd_1(-1551917268, this);
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_deleteNode_1(BEC_2_6_6_SystemObject beva_node) {
beva_node.bemd_0(-1154476723);
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_insertBeforeNode_2(BEC_2_6_6_SystemObject beva_toIns, BEC_2_6_6_SystemObject beva_node) {
beva_node.bemd_1(-892116432, beva_toIns);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_0;
if (beva_pos.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevt_2_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_2_tmpany_phold;
} /* Line: 195 */
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 198 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 198 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 200 */
 else  /* Line: 201 */ {
break;
} /* Line: 202 */
bevl_i.bevi_int++;
} /* Line: 204 */
 else  /* Line: 198 */ {
break;
} /* Line: 198 */
} /* Line: 198 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 206 */ {
return null;
} /* Line: 207 */
bevt_6_tmpany_phold = bevl_iter.bem_nextGet_0();
return bevt_6_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_2(BEC_2_4_3_MathInt beva_pos, BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_9_10_ContainerLinkedList_bevo_1;
beva_pos = beva_pos.bem_add_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 215 */ {
bevt_1_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 215 */ {
if (bevl_i.bevi_int < beva_pos.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 216 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 217 */
 else  /* Line: 218 */ {
break;
} /* Line: 219 */
bevl_i.bevi_int++;
} /* Line: 221 */
 else  /* Line: 215 */ {
break;
} /* Line: 215 */
} /* Line: 215 */
if (bevl_i.bevi_int != beva_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 224 */
bevt_5_tmpany_phold = bevl_iter.bem_currentSet_1(beva_value);
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 230 */ {
return null;
} /* Line: 230 */
bevt_1_tmpany_phold = bevp_firstNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_secondGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_5_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_3_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 235 */ {
bevt_5_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_heldGet_0();
return bevt_4_tmpany_phold;
} /* Line: 236 */
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_thirdGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_6_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_9_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_10_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_4_tmpany_phold = bevp_firstNode.bem_nextGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_7_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_nextGet_0();
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 242 */
 else  /* Line: 242 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 242 */ {
bevt_10_tmpany_phold = bevp_firstNode.bem_nextGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_nextGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_heldGet_0();
return bevt_8_tmpany_phold;
} /* Line: 243 */
return null;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_lastNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 249 */ {
return null;
} /* Line: 249 */
bevt_1_tmpany_phold = bevp_lastNode.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_getNode_1(BEC_2_6_6_SystemObject beva_pos) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = beva_pos.bemd_1(-1255083521, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 254 */ {
return bevp_firstNode;
} /* Line: 255 */
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_iter = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 258 */ {
bevt_2_tmpany_phold = bevl_iter.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 258 */ {
bevt_3_tmpany_phold = bevl_i.bem_lesser_1((BEC_2_4_3_MathInt) beva_pos );
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 259 */ {
bevl_iter.bem_nextGet_0();
} /* Line: 260 */
 else  /* Line: 261 */ {
break;
} /* Line: 262 */
bevl_i.bevi_int++;
} /* Line: 264 */
 else  /* Line: 258 */ {
break;
} /* Line: 258 */
} /* Line: 258 */
bevt_4_tmpany_phold = bevl_i.bem_notEquals_1(beva_pos);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 266 */ {
return null;
} /* Line: 267 */
bevt_5_tmpany_phold = bevl_iter.bem_nextNodeGet_0();
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_appendNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addValue_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_held == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 278 */ {
bevt_2_tmpany_phold = beva_held.bemd_1(-1176093254, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 278 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 278 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 278 */
 else  /* Line: 278 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 278 */ {
bem_addAll_1(beva_held);
} /* Line: 279 */
 else  /* Line: 280 */ {
bem_addValueWhole_1(beva_held);
} /* Line: 281 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 286 */ {
while (true)
 /* Line: 287 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 287 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(-682526974);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 288 */
 else  /* Line: 287 */ {
break;
} /* Line: 287 */
} /* Line: 287 */
} /* Line: 287 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 294 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-2120499139);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 295 */
return this;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_prepend_1(BEC_2_6_6_SystemObject beva_held) {
BEC_2_6_6_SystemObject bevl_nn = null;
bevl_nn = bem_newNode_1(beva_held);
bem_prependNode_1(bevl_nn);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_lengthGet_0() {
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 306 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 306 */ {
bevl_i.bem_nextGet_0();
bevl_cnt.bevi_int++;
} /* Line: 308 */
 else  /* Line: 306 */ {
break;
} /* Line: 306 */
} /* Line: 306 */
return bevl_cnt;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_lengthGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_firstNode == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 319 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_toNodeList_0() {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 328 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 328 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevt_2_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 330 */
bevl_cnt.bevi_int++;
} /* Line: 332 */
 else  /* Line: 328 */ {
break;
} /* Line: 328 */
} /* Line: 328 */
return bevl_toret;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_toList_0() {
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_9_4_ContainerList bevl_toret = null;
BEC_2_4_3_MathInt bevl_cnt = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_len = bem_lengthGet_0();
bevl_toret = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevl_len);
bevl_cnt = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = bem_linkedListIteratorGet_0();
while (true)
 /* Line: 341 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 341 */ {
if (bevl_cnt.bevi_int < bevl_len.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 342 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextNodeGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(1603673665);
bevl_toret.bem_put_2(bevl_cnt, bevt_2_tmpany_phold);
} /* Line: 343 */
bevl_cnt.bevi_int++;
} /* Line: 345 */
 else  /* Line: 341 */ {
break;
} /* Line: 341 */
} /* Line: 341 */
return bevl_toret;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_10_8_ContainerLinkedListIterator bem_linkedListIteratorGet_0() {
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_3_9_10_8_ContainerLinkedListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_subList_1(BEC_2_4_3_MathInt beva_start) {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_4_MathInts bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_4_MathInts) BEC_2_4_4_MathInts.bece_BEC_2_4_4_MathInts_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_maxGet_0();
bevt_0_tmpany_phold = bem_subList_2(beva_start, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_subList_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_9_10_ContainerLinkedList bevl_res = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_iter = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_res = (BEC_2_9_10_ContainerLinkedList) bem_create_0();
if (beva_end.bevi_int <= beva_start.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 368 */ {
return bevl_res;
} /* Line: 369 */
bevl_iter = bem_linkedListIteratorGet_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 372 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevt_3_tmpany_phold = bevl_iter.bem_hasNextGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(-458902099);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 373 */ {
return bevl_res;
} /* Line: 374 */
bevl_x = bevl_iter.bem_nextGet_0();
if (bevl_i.bevi_int >= beva_start.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 377 */ {
bevl_res.bem_addValue_1(bevl_x);
} /* Line: 378 */
bevl_i.bevi_int++;
} /* Line: 372 */
 else  /* Line: 372 */ {
break;
} /* Line: 372 */
} /* Line: 372 */
return bevl_res;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_reverse_0() {
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_nextLast = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_1_tmpany_phold = null;
bevl_current = bevp_firstNode;
bevp_lastNode = bevl_current;
while (true)
 /* Line: 421 */ {
if (bevl_current == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevl_next = bevl_current.bem_nextGet_0();
bevt_1_tmpany_phold = bevl_current.bem_priorGet_0();
bevl_current.bem_nextSet_1(bevt_1_tmpany_phold);
bevl_current.bem_priorSet_1(bevl_next);
bevl_nextLast = bevl_current;
bevl_current = bevl_next;
} /* Line: 426 */
 else  /* Line: 421 */ {
break;
} /* Line: 421 */
} /* Line: 421 */
bevp_firstNode = bevl_nextLast;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGet_0() {
return bevp_firstNode;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_firstNodeGetDirect_0() {
return bevp_firstNode;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_firstNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_firstNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_firstNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGet_0() {
return bevp_lastNode;
} /*method end*/
public BEC_3_9_10_4_ContainerLinkedListNode bem_lastNodeGetDirect_0() {
return bevp_lastNode;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_lastNodeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_lastNodeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lastNode = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {129, 129, 134, 135, 136, 137, 137, 138, 142, 142, 143, 144, 144, 145, 148, 148, 149, 151, 152, 154, 155, 156, 160, 161, 161, 162, 163, 164, 166, 167, 169, 173, 174, 174, 175, 176, 177, 179, 180, 182, 186, 190, 194, 194, 194, 195, 195, 197, 198, 198, 199, 199, 200, 204, 206, 206, 207, 209, 209, 213, 213, 214, 215, 215, 216, 216, 217, 221, 223, 223, 224, 224, 226, 226, 230, 230, 230, 231, 231, 235, 235, 235, 235, 235, 0, 0, 0, 236, 236, 236, 238, 242, 242, 242, 242, 242, 0, 0, 0, 242, 242, 242, 242, 0, 0, 0, 243, 243, 243, 243, 245, 249, 249, 249, 250, 250, 254, 254, 255, 257, 258, 258, 259, 260, 264, 266, 267, 269, 269, 273, 274, 278, 278, 278, 0, 0, 0, 279, 281, 286, 286, 287, 288, 288, 294, 294, 295, 295, 300, 301, 305, 306, 306, 307, 308, 310, 314, 314, 318, 318, 319, 319, 321, 321, 325, 326, 327, 328, 328, 329, 329, 330, 330, 332, 334, 338, 339, 340, 341, 341, 342, 342, 343, 343, 343, 345, 347, 351, 351, 355, 355, 359, 359, 363, 363, 363, 363, 367, 368, 368, 369, 371, 372, 372, 372, 373, 373, 374, 376, 377, 377, 378, 372, 381, 419, 420, 421, 421, 422, 423, 423, 424, 425, 426, 428, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 34, 35, 36, 37, 42, 43, 47, 52, 53, 54, 59, 60, 62, 67, 68, 70, 71, 77, 78, 79, 83, 84, 89, 90, 91, 92, 95, 96, 98, 103, 104, 109, 110, 111, 112, 115, 116, 118, 122, 126, 139, 140, 145, 146, 147, 149, 150, 153, 155, 160, 161, 166, 172, 177, 178, 180, 181, 192, 193, 194, 195, 198, 200, 205, 206, 211, 217, 222, 223, 224, 226, 227, 232, 237, 238, 240, 241, 250, 255, 256, 257, 262, 263, 266, 270, 273, 274, 275, 277, 291, 296, 297, 298, 303, 304, 307, 311, 314, 315, 316, 321, 322, 325, 329, 332, 333, 334, 335, 337, 342, 347, 348, 350, 351, 362, 363, 365, 367, 368, 371, 373, 375, 380, 386, 388, 390, 391, 395, 396, 403, 408, 409, 411, 414, 418, 421, 424, 432, 437, 440, 442, 443, 455, 460, 461, 462, 468, 469, 476, 477, 480, 482, 483, 489, 493, 494, 500, 505, 506, 507, 509, 510, 520, 521, 522, 523, 526, 528, 533, 534, 535, 537, 543, 554, 555, 556, 557, 560, 562, 567, 568, 569, 570, 572, 578, 582, 583, 587, 588, 592, 593, 599, 600, 601, 602, 614, 615, 620, 621, 623, 624, 627, 632, 633, 634, 636, 638, 639, 644, 645, 647, 653, 661, 662, 665, 670, 671, 672, 673, 674, 675, 676, 682, 686, 689, 692, 696, 700, 703, 706, 710};
/* BEGIN LINEINFO 
assign 1 129 21
new 2 129 21
return 1 129 22
assign 1 134 34
create 0 134 34
assign 1 135 35
linkedListIteratorGet 0 135 35
assign 1 136 36
nextNodeGet 0 136 36
assign 1 137 37
undef 1 137 42
return 1 138 43
assign 1 142 47
def 1 142 52
assign 1 143 53
copy 0 143 53
assign 1 144 54
def 1 144 59
nextSet 1 145 60
assign 1 148 62
undef 1 148 67
assign 1 149 68
assign 1 151 70
assign 1 152 71
nextNodeGet 0 152 71
firstNodeSet 1 154 77
lastNodeSet 1 155 78
return 1 156 79
nextSet 1 160 83
assign 1 161 84
def 1 161 89
priorSet 1 162 90
nextSet 1 163 91
assign 1 164 92
assign 1 166 95
assign 1 167 96
mylistSet 1 169 98
nextSet 1 173 103
assign 1 174 104
def 1 174 109
nextSet 1 175 110
priorSet 1 176 111
assign 1 177 112
assign 1 179 115
assign 1 180 116
mylistSet 1 182 118
delete 0 186 122
insertBefore 1 190 126
assign 1 194 139
new 0 194 139
assign 1 194 140
equals 1 194 145
assign 1 195 146
heldGet 0 195 146
return 1 195 147
assign 1 197 149
new 0 197 149
assign 1 198 150
linkedListIteratorGet 0 198 150
assign 1 198 153
hasNextGet 0 198 153
assign 1 199 155
lesser 1 199 160
nextGet 0 200 161
incrementValue 0 204 166
assign 1 206 172
notEquals 1 206 177
return 1 207 178
assign 1 209 180
nextGet 0 209 180
return 1 209 181
assign 1 213 192
new 0 213 192
assign 1 213 193
add 1 213 193
assign 1 214 194
new 0 214 194
assign 1 215 195
linkedListIteratorGet 0 215 195
assign 1 215 198
hasNextGet 0 215 198
assign 1 216 200
lesser 1 216 205
nextGet 0 217 206
incrementValue 0 221 211
assign 1 223 217
notEquals 1 223 222
assign 1 224 223
new 0 224 223
return 1 224 224
assign 1 226 226
currentSet 1 226 226
return 1 226 227
assign 1 230 232
undef 1 230 237
return 1 230 238
assign 1 231 240
heldGet 0 231 240
return 1 231 241
assign 1 235 250
def 1 235 255
assign 1 235 256
nextGet 0 235 256
assign 1 235 257
def 1 235 262
assign 1 0 263
assign 1 0 266
assign 1 0 270
assign 1 236 273
nextGet 0 236 273
assign 1 236 274
heldGet 0 236 274
return 1 236 275
return 1 238 277
assign 1 242 291
def 1 242 296
assign 1 242 297
nextGet 0 242 297
assign 1 242 298
def 1 242 303
assign 1 0 304
assign 1 0 307
assign 1 0 311
assign 1 242 314
nextGet 0 242 314
assign 1 242 315
nextGet 0 242 315
assign 1 242 316
def 1 242 321
assign 1 0 322
assign 1 0 325
assign 1 0 329
assign 1 243 332
nextGet 0 243 332
assign 1 243 333
nextGet 0 243 333
assign 1 243 334
heldGet 0 243 334
return 1 243 335
return 1 245 337
assign 1 249 342
undef 1 249 347
return 1 249 348
assign 1 250 350
heldGet 0 250 350
return 1 250 351
assign 1 254 362
new 0 254 362
assign 1 254 363
equals 1 254 363
return 1 255 365
assign 1 257 367
new 0 257 367
assign 1 258 368
linkedListIteratorGet 0 258 368
assign 1 258 371
hasNextGet 0 258 371
assign 1 259 373
lesser 1 259 373
nextGet 0 260 375
incrementValue 0 264 380
assign 1 266 386
notEquals 1 266 386
return 1 267 388
assign 1 269 390
nextNodeGet 0 269 390
return 1 269 391
assign 1 273 395
newNode 1 273 395
appendNode 1 274 396
assign 1 278 403
def 1 278 408
assign 1 278 409
sameType 1 278 409
assign 1 0 411
assign 1 0 414
assign 1 0 418
addAll 1 279 421
addValueWhole 1 281 424
assign 1 286 432
def 1 286 437
assign 1 287 440
hasNextGet 0 287 440
assign 1 288 442
nextGet 0 288 442
addValueWhole 1 288 443
assign 1 294 455
def 1 294 460
assign 1 295 461
iteratorGet 0 295 461
iterateAdd 1 295 462
assign 1 300 468
newNode 1 300 468
prependNode 1 301 469
assign 1 305 476
new 0 305 476
assign 1 306 477
linkedListIteratorGet 0 306 477
assign 1 306 480
hasNextGet 0 306 480
nextGet 0 307 482
incrementValue 0 308 483
return 1 310 489
assign 1 314 493
lengthGet 0 314 493
return 1 314 494
assign 1 318 500
undef 1 318 505
assign 1 319 506
new 0 319 506
return 1 319 507
assign 1 321 509
new 0 321 509
return 1 321 510
assign 1 325 520
lengthGet 0 325 520
assign 1 326 521
new 1 326 521
assign 1 327 522
new 0 327 522
assign 1 328 523
linkedListIteratorGet 0 328 523
assign 1 328 526
hasNextGet 0 328 526
assign 1 329 528
lesser 1 329 533
assign 1 330 534
nextNodeGet 0 330 534
put 2 330 535
incrementValue 0 332 537
return 1 334 543
assign 1 338 554
lengthGet 0 338 554
assign 1 339 555
new 1 339 555
assign 1 340 556
new 0 340 556
assign 1 341 557
linkedListIteratorGet 0 341 557
assign 1 341 560
hasNextGet 0 341 560
assign 1 342 562
lesser 1 342 567
assign 1 343 568
nextNodeGet 0 343 568
assign 1 343 569
heldGet 0 343 569
put 2 343 570
incrementValue 0 345 572
return 1 347 578
assign 1 351 582
new 1 351 582
return 1 351 583
assign 1 355 587
new 1 355 587
return 1 355 588
assign 1 359 592
iteratorGet 0 359 592
return 1 359 593
assign 1 363 599
new 0 363 599
assign 1 363 600
maxGet 0 363 600
assign 1 363 601
subList 2 363 601
return 1 363 602
assign 1 367 614
create 0 367 614
assign 1 368 615
lesserEquals 1 368 620
return 1 369 621
assign 1 371 623
linkedListIteratorGet 0 371 623
assign 1 372 624
new 0 372 624
assign 1 372 627
lesser 1 372 632
assign 1 373 633
hasNextGet 0 373 633
assign 1 373 634
not 0 373 634
return 1 374 636
assign 1 376 638
nextGet 0 376 638
assign 1 377 639
greaterEquals 1 377 644
addValue 1 378 645
incrementValue 0 372 647
return 1 381 653
assign 1 419 661
assign 1 420 662
assign 1 421 665
def 1 421 670
assign 1 422 671
nextGet 0 422 671
assign 1 423 672
priorGet 0 423 672
nextSet 1 423 673
priorSet 1 424 674
assign 1 425 675
assign 1 426 676
assign 1 428 682
return 1 0 686
return 1 0 689
assign 1 0 692
assign 1 0 696
return 1 0 700
return 1 0 703
assign 1 0 706
assign 1 0 710
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 338214363: return bem_isEmptyGet_0();
case 335887401: return bem_reverse_0();
case -497738959: return bem_secondGet_0();
case 397353354: return bem_linkedListIteratorGet_0();
case 1804773996: return bem_create_0();
case -1071008216: return bem_serializeContents_0();
case -292208502: return bem_firstGet_0();
case -905773947: return bem_lengthGet_0();
case 621276181: return bem_toString_0();
case -2120499139: return bem_iteratorGet_0();
case -733443081: return bem_lastGet_0();
case -297374401: return bem_hashGet_0();
case 1254813232: return bem_toAny_0();
case -203737559: return bem_firstNodeGetDirect_0();
case 2052749447: return bem_toList_0();
case 1562662552: return bem_many_0();
case -374584993: return bem_toNodeList_0();
case 959038598: return bem_echo_0();
case -73436994: return bem_new_0();
case -1778497682: return bem_serializeToString_0();
case 39810102: return bem_tagGet_0();
case -1960297657: return bem_fieldIteratorGet_0();
case 167710369: return bem_print_0();
case 1769468354: return bem_fieldNamesGet_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case -1628372783: return bem_classNameGet_0();
case -1799416909: return bem_serializationIteratorGet_0();
case 830405516: return bem_lastNodeGetDirect_0();
case -1072030744: return bem_sourceFileNameGet_0();
case 653349672: return bem_copy_0();
case -1067704397: return bem_once_0();
case -692661161: return bem_sizeGet_0();
case 1653262441: return bem_thirdGet_0();
case -1662481366: return bem_firstNodeGet_0();
case 787718161: return bem_lastNodeGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1279255185: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case 111877942: return bem_getNode_1(bevd_0);
case 1347835144: return bem_addAll_1(bevd_0);
case -438924354: return bem_undefined_1(bevd_0);
case -978745787: return bem_appendNode_1(bevd_0);
case 856000892: return bem_prependNode_1(bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1019219032: return bem_iterateAdd_1(bevd_0);
case -906630911: return bem_newNode_1(bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case -1325106607: return bem_lastNodeSetDirect_1(bevd_0);
case 1255934648: return bem_subList_1((BEC_2_4_3_MathInt) bevd_0);
case 1452664106: return bem_lastNodeSet_1(bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1232445169: return bem_firstNodeSetDirect_1(bevd_0);
case -1049172860: return bem_defined_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case -1934797929: return bem_addValueWhole_1(bevd_0);
case -290823144: return bem_deleteNode_1(bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case 963251405: return bem_firstNodeSet_1(bevd_0);
case -1110681556: return bem_addValue_1(bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case 1080020358: return bem_prepend_1(bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1613887137: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case -975699924: return bem_subList_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1551616834: return bem_insertBeforeNode_2(bevd_0, bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_10_ContainerLinkedList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_10_ContainerLinkedList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_10_ContainerLinkedList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst = (BEC_2_9_10_ContainerLinkedList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_10_ContainerLinkedList.bece_BEC_2_9_10_ContainerLinkedList_bevs_type;
}
}
}
