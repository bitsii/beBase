namespace be {
/* IO:File: source/base/Functions.be */
public class BEC_2_6_10_SystemInvocation : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemInvocation() { }
static BEC_2_6_10_SystemInvocation() { }
private static byte[] becc_BEC_2_6_10_SystemInvocation_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_10_SystemInvocation_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_inst;

public static new BET_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_args;
public virtual BEC_2_6_10_SystemInvocation bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_9_4_ContainerList beva__args) {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_args = beva__args;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_invoke_0() {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-249962556, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(-249962556, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public virtual BEC_2_6_10_SystemInvocation bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_target = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_6_10_SystemInvocation bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_argsGet_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_10_SystemInvocation bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {55, 56, 57, 62, 63, 67, 68, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 18, 23, 24, 28, 29, 32, 35, 39, 42, 46, 49};
/* BEGIN LINEINFO 
assign 1 55 16
assign 1 56 17
assign 1 57 18
assign 1 62 23
invoke 2 62 23
return 1 63 24
assign 1 67 28
invoke 2 67 28
return 1 68 29
return 1 0 32
assign 1 0 35
return 1 0 39
assign 1 0 42
return 1 0 46
assign 1 0 49
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1048772166: return bem_echo_0();
case 714392359: return bem_classNameGet_0();
case -1874213289: return bem_tagGet_0();
case 1028683886: return bem_toString_0();
case 749034165: return bem_argsGet_0();
case -354093047: return bem_serializationIteratorGet_0();
case -1162588923: return bem_invoke_0();
case -1312519804: return bem_hashGet_0();
case -551298753: return bem_sourceFileNameGet_0();
case -1036233638: return bem_new_0();
case -386157741: return bem_serializeToString_0();
case 1668871631: return bem_callNameGet_0();
case -76505233: return bem_once_0();
case -1963468660: return bem_fieldIteratorGet_0();
case 1836947478: return bem_serializeContents_0();
case 402561175: return bem_targetGet_0();
case 1315945784: return bem_main_0();
case -1057001629: return bem_copy_0();
case -454910570: return bem_create_0();
case -1493103250: return bem_many_0();
case 654084467: return bem_iteratorGet_0();
case 863669946: return bem_toAny_0();
case -362321661: return bem_deserializeClassNameGet_0();
case -354590014: return bem_print_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -403482348: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1184340301: return bem_otherClass_1(bevd_0);
case 1301577712: return bem_sameClass_1(bevd_0);
case 88500505: return bem_argsSet_1(bevd_0);
case -747350143: return bem_undef_1(bevd_0);
case 2095964872: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1978731115: return bem_sameType_1(bevd_0);
case 902798731: return bem_targetSet_1(bevd_0);
case 604922157: return bem_equals_1(bevd_0);
case 729561267: return bem_copyTo_1(bevd_0);
case -558198774: return bem_def_1(bevd_0);
case -965306462: return bem_undefined_1(bevd_0);
case 1672825312: return bem_notEquals_1(bevd_0);
case -1188536421: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -999936361: return bem_defined_1(bevd_0);
case 1223805967: return bem_callNameSet_1(bevd_0);
case -504315826: return bem_sameObject_1(bevd_0);
case 1782921206: return bem_otherType_1(bevd_0);
case -1374275511: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -249962556: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -608983707: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 913536943: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1192068648: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1655666515: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 478589859: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2045713194: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -89108408: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_4_ContainerList) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemInvocation_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_10_SystemInvocation_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemInvocation();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst = (BEC_2_6_10_SystemInvocation) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_type;
}
}
}
