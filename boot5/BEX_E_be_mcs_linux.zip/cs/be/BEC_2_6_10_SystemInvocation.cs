namespace be {
/* IO:File: source/base/Functions.be */
public class BEC_2_6_10_SystemInvocation : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemInvocation() { }
static BEC_2_6_10_SystemInvocation() { }
private static byte[] becc_BEC_2_6_10_SystemInvocation_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_6_10_SystemInvocation_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_inst;

public static new BET_2_6_10_SystemInvocation bece_BEC_2_6_10_SystemInvocation_bevs_type;

public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_args;
public virtual BEC_2_6_10_SystemInvocation bem_new_3(BEC_2_6_6_SystemObject beva__target, BEC_2_4_6_TextString beva__callName, BEC_2_9_4_ContainerList beva__args) {
bevp_target = beva__target;
bevp_callName = beva__callName;
bevp_args = beva__args;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_invoke_0() {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(878556511, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_main_0() {
BEC_2_6_6_SystemObject bevl_result = null;
bevl_result = bevp_target.bemd_2(878556511, bevp_callName, bevp_args);
return bevl_result;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_targetGet_0() {
return bevp_target;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGetDirect_0() {
return bevp_target;
} /*method end*/
public virtual BEC_2_6_10_SystemInvocation bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_targetSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public BEC_2_6_6_SystemObject bem_callNameGetDirect_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_6_10_SystemInvocation bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_6_6_SystemObject bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public virtual BEC_2_6_10_SystemInvocation bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemInvocation bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {57, 58, 59, 64, 65, 69, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 17, 18, 23, 24, 28, 29, 32, 35, 38, 42, 46, 49, 52, 56, 60, 63, 66, 70};
/* BEGIN LINEINFO 
assign 1 57 16
assign 1 58 17
assign 1 59 18
assign 1 64 23
invoke 2 64 23
return 1 65 24
assign 1 69 28
invoke 2 69 28
return 1 70 29
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
return 1 0 46
return 1 0 49
assign 1 0 52
assign 1 0 56
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1312807182: return bem_targetGetDirect_0();
case -1387831588: return bem_print_0();
case -838611489: return bem_targetGet_0();
case -1188922735: return bem_echo_0();
case -793241295: return bem_iteratorGet_0();
case 67257257: return bem_main_0();
case 371157924: return bem_sourceFileNameGet_0();
case 1652521523: return bem_serializeContents_0();
case 1714239982: return bem_argsGet_0();
case -1760538533: return bem_classNameGet_0();
case 1080993533: return bem_argsGetDirect_0();
case 7254011: return bem_fieldIteratorGet_0();
case -921473949: return bem_fieldNamesGet_0();
case 895193825: return bem_once_0();
case -467511392: return bem_toString_0();
case -1323898541: return bem_toAny_0();
case -39165288: return bem_deserializeClassNameGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -447432319: return bem_many_0();
case 1597327951: return bem_create_0();
case -1756823865: return bem_invoke_0();
case -1363819567: return bem_new_0();
case 1092105192: return bem_hashGet_0();
case -105946774: return bem_serializeToString_0();
case -1279431079: return bem_callNameGet_0();
case 1890854002: return bem_tagGet_0();
case -1393385259: return bem_callNameGetDirect_0();
case 1319388306: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 733231662: return bem_argsSet_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case 1375735896: return bem_targetSetDirect_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case 326893439: return bem_callNameSet_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 417243206: return bem_callNameSetDirect_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case -474612391: return bem_argsSetDirect_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case -1886511705: return bem_targetSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 637486332: return bem_new_3(bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_4_ContainerList) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemInvocation_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_10_SystemInvocation_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemInvocation();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst = (BEC_2_6_10_SystemInvocation) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemInvocation.bece_BEC_2_6_10_SystemInvocation_bevs_type;
}
}
}
