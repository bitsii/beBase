namespace be {
/* IO:File: source/base/Tokenize.be */
public class BEC_2_4_4_TextGlob : BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
static BEC_2_4_4_TextGlob() { }
private static byte[] becc_BEC_2_4_4_TextGlob_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_BEC_2_4_4_TextGlob_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_0 = {0x2A,0x3F};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_1 = {0x2A};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_1, 1));
private static byte[] bece_BEC_2_4_4_TextGlob_bels_2 = {0x3F};
private static BEC_2_4_6_TextString bece_BEC_2_4_4_TextGlob_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_4_TextGlob_bels_2, 1));
public static new BEC_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_inst;
public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public virtual BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) {
bem_globSet_1(beva__glob);
return this;
} /*method end*/
public virtual BEC_2_4_4_TextGlob bem_globSet_1(BEC_2_4_6_TextString beva__glob) {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_4_TextGlob_bels_0));
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_tok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_tmpany_phold.bemd_0(-1781874844);
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_tmpany_phold = bem_caseMatch_4(bevl_node, beva_input, bevt_2_tmpany_phold, null);
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
if (beva_node == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_2_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 125 */ {
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_3_tmpany_phold;
} /* Line: 126 */
 else  /* Line: 127 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_4_tmpany_phold;
} /* Line: 128 */
} /* Line: 125 */
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_tmpany_phold = bece_BEC_2_4_4_TextGlob_bevo_0;
bevt_5_tmpany_phold = bevl_val.bem_equals_1(bevt_6_tmpany_phold);
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_7_tmpany_phold = bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_tmpany_phold;
} /* Line: 133 */
bevt_9_tmpany_phold = bece_BEC_2_4_4_TextGlob_bevo_1;
bevt_8_tmpany_phold = bevl_val.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 135 */ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_13_tmpany_phold = beva_node.bem_nextGet_0();
bevt_12_tmpany_phold = bem_caseMatch_4(bevt_13_tmpany_phold, beva_input, beva_pos, null);
return bevt_12_tmpany_phold;
} /* Line: 137 */
 else  /* Line: 137 */ {
bevt_14_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_14_tmpany_phold;
} /* Line: 137 */
} /* Line: 137 */
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 140 */ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 141 */ {
bevt_18_tmpany_phold = beva_node.bem_nextGet_0();
bevt_20_tmpany_phold = bevl_val.bem_sizeGet_0();
bevt_19_tmpany_phold = beva_pos.bem_add_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bem_caseMatch_4(bevt_18_tmpany_phold, beva_input, bevt_19_tmpany_phold, null);
return bevt_17_tmpany_phold;
} /* Line: 142 */
 else  /* Line: 143 */ {
if (beva_lpos == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 144 */ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 145 */
} /* Line: 144 */
} /* Line: 141 */
bevt_22_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_22_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (BEC_2_9_6_ContainerSingle) (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
 /* Line: 156 */ {
bevt_1_tmpany_phold = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevl_ok = bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool) /* Line: 158 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 158 */
bevt_4_tmpany_phold = bevl_lpos.bem_firstGet_0();
if (bevt_4_tmpany_phold == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 159 */ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 161 */
 else  /* Line: 162 */ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 163 */
} /* Line: 159 */
 else  /* Line: 156 */ {
break;
} /* Line: 156 */
} /* Line: 156 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_globGet_0() {
return bevp_glob;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() {
return bevp_splits;
} /*method end*/
public virtual BEC_2_4_4_TextGlob bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {101, 105, 105, 105, 106, 108, 109, 119, 119, 120, 120, 120, 124, 124, 125, 125, 125, 126, 126, 128, 128, 131, 132, 132, 133, 133, 135, 135, 136, 137, 137, 137, 137, 137, 137, 137, 137, 139, 140, 140, 141, 141, 142, 142, 142, 142, 142, 144, 144, 145, 149, 149, 153, 154, 156, 156, 156, 157, 158, 158, 159, 159, 159, 160, 161, 163, 166, 166, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 25, 26, 27, 28, 29, 30, 38, 39, 40, 41, 42, 70, 75, 76, 77, 82, 83, 84, 87, 88, 91, 92, 93, 95, 96, 98, 99, 101, 102, 103, 108, 109, 110, 111, 114, 115, 118, 119, 124, 125, 130, 131, 132, 133, 134, 135, 138, 143, 144, 148, 149, 161, 162, 165, 166, 171, 172, 174, 175, 177, 178, 183, 184, 185, 188, 195, 196, 199, 202, 205};
/* BEGIN LINEINFO 
globSet 1 101 17
assign 1 105 25
new 0 105 25
assign 1 105 26
new 0 105 26
assign 1 105 27
new 2 105 27
assign 1 106 28
tokenize 1 106 28
assign 1 108 29
assign 1 109 30
assign 1 119 38
iteratorGet 0 119 38
assign 1 119 39
nextNodeGet 0 119 39
assign 1 120 40
new 0 120 40
assign 1 120 41
caseMatch 4 120 41
return 1 120 42
assign 1 124 70
undef 1 124 75
assign 1 125 76
sizeGet 0 125 76
assign 1 125 77
equals 1 125 82
assign 1 126 83
new 0 126 83
return 1 126 84
assign 1 128 87
new 0 128 87
return 1 128 88
assign 1 131 91
heldGet 0 131 91
assign 1 132 92
new 0 132 92
assign 1 132 93
equals 1 132 93
assign 1 133 95
starMatch 3 133 95
return 1 133 96
assign 1 135 98
new 0 135 98
assign 1 135 99
equals 1 135 99
assign 1 136 101
increment 0 136 101
assign 1 137 102
sizeGet 0 137 102
assign 1 137 103
lesserEquals 1 137 108
assign 1 137 109
nextGet 0 137 109
assign 1 137 110
caseMatch 4 137 110
return 1 137 111
assign 1 137 114
new 0 137 114
return 1 137 115
assign 1 139 118
find 2 139 118
assign 1 140 119
def 1 140 124
assign 1 141 125
equals 1 141 130
assign 1 142 131
nextGet 0 142 131
assign 1 142 132
sizeGet 0 142 132
assign 1 142 133
add 1 142 133
assign 1 142 134
caseMatch 4 142 134
return 1 142 135
assign 1 144 138
def 1 144 143
firstSet 1 145 144
assign 1 149 148
new 0 149 148
return 1 149 149
assign 1 153 161
nextGet 0 153 161
assign 1 154 162
new 0 154 162
assign 1 156 165
sizeGet 0 156 165
assign 1 156 166
lesserEquals 1 156 171
assign 1 157 172
caseMatch 4 157 172
assign 1 158 174
new 0 158 174
return 1 158 175
assign 1 159 177
firstGet 0 159 177
assign 1 159 178
def 1 159 183
assign 1 160 184
firstGet 0 160 184
firstSet 1 161 185
assign 1 163 188
increment 0 163 188
assign 1 166 195
new 0 166 195
return 1 166 196
return 1 0 199
return 1 0 202
assign 1 0 205
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1829615340: return bem_fieldIteratorGet_0();
case 386499474: return bem_deserializeClassNameGet_0();
case -1710921376: return bem_iteratorGet_0();
case -289190594: return bem_new_0();
case 1110687349: return bem_serializationIteratorGet_0();
case 1606100185: return bem_toAny_0();
case 1323527258: return bem_copy_0();
case -1380336737: return bem_globGet_0();
case 154399642: return bem_hashGet_0();
case 468841666: return bem_sourceFileNameGet_0();
case 1743423799: return bem_splitsGet_0();
case -285521200: return bem_create_0();
case 628114265: return bem_many_0();
case -86198663: return bem_print_0();
case -457712006: return bem_classNameGet_0();
case -1679072038: return bem_toString_0();
case -2143843780: return bem_tagGet_0();
case 402795231: return bem_once_0();
case -1896702956: return bem_serializeContents_0();
case 820088259: return bem_echo_0();
case -693169976: return bem_serializeToString_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 2033308650: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 405603043: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759835639: return bem_defined_1(bevd_0);
case 1958076839: return bem_undefined_1(bevd_0);
case 2086659962: return bem_sameObject_1(bevd_0);
case 1519077869: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1253393632: return bem_def_1(bevd_0);
case -1211467604: return bem_copyTo_1(bevd_0);
case 365385951: return bem_equals_1(bevd_0);
case -890870507: return bem_splitsSet_1(bevd_0);
case 938569326: return bem_notEquals_1(bevd_0);
case 549311145: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case -641584584: return bem_sameClass_1(bevd_0);
case 1941835232: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case -1706185549: return bem_otherType_1(bevd_0);
case 713999383: return bem_undef_1(bevd_0);
case -861317881: return bem_otherClass_1(bevd_0);
case 343567700: return bem_sameType_1(bevd_0);
case -1770369050: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 823180387: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1125341844: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389614349: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1812156494: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1790570920: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2109777534: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1447567526: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1299212473: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callCase) {
case 779803082: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callCase, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callCase) {
case 726273275: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return base.bemd_4(callCase, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_TextGlob_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_4_TextGlob_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_4_TextGlob();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst = (BEC_2_4_4_TextGlob) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst;
}
}
}
