namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerStack : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerStack() { }
static BEC_2_9_5_ContainerStack() { }
private static byte[] becc_BEC_2_9_5_ContainerStack_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x53,0x74,0x61,0x63,0x6B};
private static byte[] becc_BEC_2_9_5_ContainerStack_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_inst;

public static new BET_2_9_5_ContainerStack bece_BEC_2_9_5_ContainerStack_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_holder;
public BEC_2_4_3_MathInt bevp_size;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_push_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 39 */ {
if (bevp_holder == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
} /* Line: 41 */
 else  /* Line: 42 */ {
bevp_top = bevp_holder;
bevp_holder = null;
} /* Line: 44 */
} /* Line: 40 */
 else  /* Line: 39 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_4_tmpany_phold = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 49 */
 else  /* Line: 50 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 51 */
} /* Line: 39 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_pop_0() {
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_6_6_SystemObject bevl_item = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 58 */ {
return bevp_top;
} /* Line: 59 */
bevl_last = bevp_top;
bevp_top = bevp_top.bem_priorGet_0();
if (bevp_top == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 63 */ {
bevp_holder = bevl_last;
} /* Line: 64 */
if (bevl_last == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 66 */ {
return null;
} /* Line: 67 */
bevl_item = bevl_last.bem_heldGet_0();
bevl_last.bem_heldSet_1(null);
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_peek_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 76 */ {
return bevp_top;
} /* Line: 77 */
bevt_1_tmpany_phold = bevp_top.bem_heldGet_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_addValue_1(BEC_2_6_6_SystemObject beva_item) {
bem_push_1(beva_item);
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_pop_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_1(BEC_2_5_4_LogicBool beva_pop) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_pop.bevi_bool) /* Line: 95 */ {
bevt_0_tmpany_phold = bem_pop_0();
return bevt_0_tmpany_phold;
} /* Line: 96 */
bevt_1_tmpany_phold = bem_peek_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_put_1(BEC_2_6_6_SystemObject beva_item) {
bem_push_1(beva_item);
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_topGet_0() {
return bevp_top;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGetDirect_0() {
return bevp_top;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_topSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_holderGet_0() {
return bevp_holder;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_holderGetDirect_0() {
return bevp_holder;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_holderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_holderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_holder = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_5_ContainerStack bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerStack bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {33, 39, 39, 40, 40, 41, 43, 44, 46, 46, 46, 47, 47, 48, 48, 49, 51, 53, 54, 58, 58, 59, 61, 62, 63, 63, 64, 66, 66, 67, 69, 70, 71, 72, 76, 76, 77, 79, 79, 83, 83, 87, 91, 91, 96, 96, 98, 98, 102, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {16, 26, 31, 32, 37, 38, 41, 42, 46, 47, 52, 53, 54, 55, 56, 57, 60, 63, 64, 73, 78, 79, 81, 82, 83, 88, 89, 91, 96, 97, 99, 100, 101, 102, 107, 112, 113, 115, 116, 120, 125, 128, 133, 134, 140, 141, 143, 144, 147, 151, 154, 157, 161, 165, 168, 171, 175, 179, 182, 185, 189};
/* BEGIN LINEINFO 
assign 1 33 16
new 0 33 16
assign 1 39 26
undef 1 39 31
assign 1 40 32
undef 1 40 37
assign 1 41 38
new 0 41 38
assign 1 43 41
assign 1 44 42
assign 1 46 46
nextGet 0 46 46
assign 1 46 47
undef 1 46 52
assign 1 47 53
new 0 47 53
nextSet 1 47 54
assign 1 48 55
nextGet 0 48 55
priorSet 1 48 56
assign 1 49 57
nextGet 0 49 57
assign 1 51 60
nextGet 0 51 60
heldSet 1 53 63
assign 1 54 64
increment 0 54 64
assign 1 58 73
undef 1 58 78
return 1 59 79
assign 1 61 81
assign 1 62 82
priorGet 0 62 82
assign 1 63 83
undef 1 63 88
assign 1 64 89
assign 1 66 91
undef 1 66 96
return 1 67 97
assign 1 69 99
heldGet 0 69 99
heldSet 1 70 100
assign 1 71 101
decrement 0 71 101
return 1 72 102
assign 1 76 107
undef 1 76 112
return 1 77 113
assign 1 79 115
heldGet 0 79 115
return 1 79 116
assign 1 83 120
undef 1 83 125
return 1 83 125
push 1 87 128
assign 1 91 133
pop 0 91 133
return 1 91 134
assign 1 96 140
pop 0 96 140
return 1 96 141
assign 1 98 143
peek 0 98 143
return 1 98 144
push 1 102 147
return 1 0 151
return 1 0 154
assign 1 0 157
assign 1 0 161
return 1 0 165
return 1 0 168
assign 1 0 171
assign 1 0 175
return 1 0 179
return 1 0 182
assign 1 0 185
assign 1 0 189
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1799416909: return bem_serializationIteratorGet_0();
case 1804773996: return bem_create_0();
case 1349882287: return bem_topGetDirect_0();
case 1337461108: return bem_get_0();
case -356117684: return bem_topGet_0();
case -354956919: return bem_peek_0();
case -73436994: return bem_new_0();
case 1254813232: return bem_toAny_0();
case -1072030744: return bem_sourceFileNameGet_0();
case 653349672: return bem_copy_0();
case -1778497682: return bem_serializeToString_0();
case -692661161: return bem_sizeGet_0();
case -1934629923: return bem_holderGet_0();
case 959038598: return bem_echo_0();
case -1999267335: return bem_holderGetDirect_0();
case -331008546: return bem_sizeGetDirect_0();
case -2120499139: return bem_iteratorGet_0();
case 1562662552: return bem_many_0();
case 338214363: return bem_isEmptyGet_0();
case 167710369: return bem_print_0();
case -228020907: return bem_pop_0();
case -297374401: return bem_hashGet_0();
case -1067704397: return bem_once_0();
case 39810102: return bem_tagGet_0();
case 1769468354: return bem_fieldNamesGet_0();
case -1628372783: return bem_classNameGet_0();
case -1071008216: return bem_serializeContents_0();
case 621276181: return bem_toString_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case -1960297657: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1049172860: return bem_defined_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case -1662340131: return bem_topSetDirect_1(bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1110681556: return bem_addValue_1(bevd_0);
case -438924354: return bem_undefined_1(bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case 931894465: return bem_topSet_1(bevd_0);
case 652756: return bem_put_1(bevd_0);
case -799142511: return bem_holderSet_1(bevd_0);
case 195727727: return bem_holderSetDirect_1(bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1114492821: return bem_push_1(bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case 1806671244: return bem_sizeSetDirect_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case 1279255185: return bem_get_1((BEC_2_5_4_LogicBool) bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case 766327446: return bem_sizeSet_1(bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerStack_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerStack_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ContainerStack();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst = (BEC_2_9_5_ContainerStack) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_5_ContainerStack.bece_BEC_2_9_5_ContainerStack_bevs_type;
}
}
}
