namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_2_9_4_ContainerList : BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }
static BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_1 = (new BEC_2_4_3_MathInt(16));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_7 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_9 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_15 = (new BEC_2_4_3_MathInt(2));
public static new BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;

public static new BET_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_type;

public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bem_new_2(bevt_0_tmpany_phold, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_leni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 176 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 176 */ {
if (beva_capi == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 176 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 176 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 176 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 176 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 177 */
if (bevp_length == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 179 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 182 */ {
return this;
} /* Line: 183 */
} /* Line: 182 */

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_2_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_2_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bece_BEC_2_9_4_ContainerList_bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 219 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_length.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_4;
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_5;
bevt_1_tmpany_phold = bevp_length.bem_subtract_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 251 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 252 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 254 */ {
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_7;
bevt_5_tmpany_phold = beva_posi.bem_add_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
} /* Line: 255 */

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 271 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 271 */
 else  /* Line: 271 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 271 */ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 277 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 287 */ {
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_10;
bevl_j = beva_pos.bem_add_1(bevt_2_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) beva_pos.bem_copy_0();
while (true)
 /* Line: 290 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_4_tmpany_phold = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 290 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
bem_put_2(bevl_fl, null);
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_11;
bevt_5_tmpany_phold = bevp_length.bem_subtract_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 296 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 310 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 310 */ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 310 */
 else  /* Line: 310 */ {
break;
} /* Line: 310 */
} /* Line: 310 */
bevp_length = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_n = (BEC_2_9_4_ContainerList) bem_create_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 318 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_1_tmpany_phold = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 318 */
 else  /* Line: 318 */ {
break;
} /* Line: 318 */
} /* Line: 318 */
return (BEC_2_6_6_SystemObject) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_tmpany_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpany_phold = bevp_length.bem_add_1(bevt_4_tmpany_phold);
bevl_yi = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_loop = bem_iteratorGet_0();
while (true)
 /* Line: 330 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(395045729);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_c = bevt_0_tmpany_loop.bemd_0(1286644729);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 331 */
 else  /* Line: 330 */ {
break;
} /* Line: 330 */
} /* Line: 330 */
bevt_1_tmpany_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 333 */ {
bevt_6_tmpany_phold = bevt_1_tmpany_loop.bemd_0(395045729);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 333 */ {
bevl_c = bevt_1_tmpany_loop.bemd_0(1286644729);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 334 */
 else  /* Line: 333 */ {
break;
} /* Line: 333 */
} /* Line: 333 */
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_tmpany_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
while (true)
 /* Line: 348 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevl_c = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
bevl_j = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
while (true)
 /* Line: 350 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevt_3_tmpany_phold = bem_get_1(bevl_j);
bevt_4_tmpany_phold = bem_get_1(bevl_c);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-1940488323, bevt_4_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 351 */ {
bevl_c = (BEC_2_4_3_MathInt) bevl_j.bem_copy_0();
} /* Line: 352 */
bevl_j.bevi_int++;
} /* Line: 350 */
 else  /* Line: 350 */ {
break;
} /* Line: 350 */
} /* Line: 350 */
bevl_hold = bem_get_1(bevl_i);
bevt_5_tmpany_phold = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_tmpany_phold);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 348 */
 else  /* Line: 348 */ {
break;
} /* Line: 348 */
} /* Line: 348 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_si = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 367 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 367 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 368 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 368 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 368 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 368 */
 else  /* Line: 368 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 368 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpany_phold = bevl_so.bemd_1(-1940488323, bevl_fo);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 371 */ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 373 */
 else  /* Line: 374 */ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 376 */
} /* Line: 371 */
 else  /* Line: 368 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 378 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 381 */
 else  /* Line: 368 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 385 */
} /* Line: 368 */
} /* Line: 368 */
bevl_i.bevi_int++;
} /* Line: 387 */
 else  /* Line: 367 */ {
break;
} /* Line: 367 */
} /* Line: 367 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bem_mergeSort_2(bevt_1_tmpany_phold, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_2_tmpany_phold = bem_create_1(bevt_3_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevt_2_tmpany_phold;
} /* Line: 398 */
 else  /* Line: 397 */ {
bevt_5_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 399 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_tmpany_phold = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 402 */
 else  /* Line: 403 */ {
bevt_9_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpany_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_2_9_4_ContainerList) bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_2_9_4_ContainerList) bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 411 */
} /* Line: 397 */
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 417 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 423 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 445 */
while (true)
 /* Line: 448 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 448 */ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 459 */
 else  /* Line: 448 */ {
break;
} /* Line: 448 */
} /* Line: 448 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 465 */ {
while (true)
 /* Line: 466 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(395045729);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 466 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(1286644729);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 467 */
 else  /* Line: 466 */ {
break;
} /* Line: 466 */
} /* Line: 466 */
} /* Line: 466 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 473 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-193453355);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 474 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 479 */ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 490 */
 else  /* Line: 491 */ {
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevp_length.bem_copy_0();
bem_put_2(bevt_1_tmpany_phold, beva_val);
} /* Line: 493 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 498 */ {
bevt_2_tmpany_phold = beva_val.bemd_1(110774735, this);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 498 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 498 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 498 */
 else  /* Line: 498 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 498 */ {
bem_addAll_1(beva_val);
} /* Line: 499 */
 else  /* Line: 500 */ {
bem_addValueWhole_1(beva_val);
} /* Line: 501 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 507 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 507 */ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 509 */ {
bevt_3_tmpany_phold = beva_value.bemd_1(449026795, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 509 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 509 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 509 */
 else  /* Line: 509 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 509 */ {
return bevl_i;
} /* Line: 510 */
bevl_i.bevi_int++;
} /* Line: 507 */
 else  /* Line: 507 */ {
break;
} /* Line: 507 */
} /* Line: 507 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_find_1(beva_value);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 517 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 518 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_sortedFind_2(beva_value, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 537 */ {
bevt_3_tmpany_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_divide_1(bevt_4_tmpany_phold);
bevl_mid = bevt_2_tmpany_phold.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_tmpany_phold = beva_value.bemd_1(449026795, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 540 */ {
return bevl_mid;
} /* Line: 541 */
 else  /* Line: 540 */ {
bevt_6_tmpany_phold = beva_value.bemd_1(-709253161, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 542 */ {
bevl_low = bevl_mid;
} /* Line: 544 */
 else  /* Line: 540 */ {
bevt_7_tmpany_phold = beva_value.bemd_1(-1940488323, bevl_aval);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 545 */ {
bevl_high = bevl_mid;
} /* Line: 547 */
} /* Line: 540 */
} /* Line: 540 */
if (bevl_lastMid == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 550 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 550 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 550 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 550 */
 else  /* Line: 550 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 550 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 551 */ {
bevt_11_tmpany_phold = bem_get_1(bevl_low);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(-1940488323, beva_value);
if (((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 551 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 551 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 551 */
 else  /* Line: 551 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 551 */ {
return bevl_low;
} /* Line: 552 */
return null;
} /* Line: 554 */
bevl_lastMid = bevl_mid;
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 557 */ {
return null;
} /* Line: 558 */
} /* Line: 557 */
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGetDirect_0() {
return bevp_length;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_length = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGetDirect_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_capacity = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGetDirect_0() {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {168, 168, 168, 168, 168, 172, 176, 176, 0, 176, 176, 0, 0, 177, 177, 177, 179, 179, 182, 182, 183, 207, 208, 209, 214, 218, 218, 218, 219, 219, 221, 221, 231, 231, 235, 235, 239, 239, 243, 243, 243, 247, 247, 247, 247, 251, 251, 251, 252, 252, 252, 254, 254, 255, 255, 255, 271, 271, 271, 271, 271, 0, 0, 0, 283, 287, 287, 288, 288, 289, 289, 290, 290, 290, 291, 291, 292, 290, 294, 295, 295, 295, 296, 296, 298, 298, 302, 302, 306, 306, 310, 310, 310, 311, 310, 313, 317, 318, 318, 318, 319, 319, 318, 321, 324, 324, 326, 326, 329, 329, 329, 329, 330, 0, 330, 330, 331, 333, 0, 333, 333, 334, 336, 340, 340, 344, 344, 348, 348, 348, 349, 350, 350, 350, 351, 351, 351, 352, 350, 355, 356, 356, 357, 348, 362, 363, 364, 365, 366, 367, 367, 368, 368, 368, 368, 0, 0, 0, 369, 370, 371, 372, 373, 375, 376, 378, 378, 379, 380, 381, 382, 382, 383, 384, 385, 387, 392, 392, 392, 396, 397, 397, 397, 398, 398, 398, 399, 399, 399, 400, 400, 401, 401, 401, 402, 404, 404, 405, 406, 407, 408, 409, 410, 411, 416, 417, 417, 417, 423, 423, 424, 445, 448, 448, 459, 461, 465, 465, 466, 467, 467, 473, 473, 474, 474, 479, 479, 490, 493, 493, 498, 498, 498, 0, 0, 0, 499, 501, 507, 507, 507, 508, 509, 509, 509, 0, 0, 0, 510, 507, 513, 517, 517, 517, 518, 518, 520, 520, 526, 526, 526, 533, 534, 538, 538, 538, 538, 539, 540, 541, 542, 544, 545, 547, 550, 550, 550, 550, 0, 0, 0, 551, 551, 0, 0, 0, 552, 554, 556, 557, 558, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {61, 62, 63, 64, 65, 69, 80, 85, 86, 89, 94, 95, 98, 102, 103, 104, 106, 111, 112, 117, 118, 123, 124, 125, 129, 136, 137, 142, 143, 144, 146, 147, 157, 158, 162, 163, 168, 169, 174, 175, 176, 182, 183, 184, 185, 195, 196, 201, 202, 203, 204, 206, 211, 212, 213, 214, 226, 227, 232, 233, 238, 239, 242, 246, 252, 267, 272, 273, 274, 275, 276, 277, 280, 285, 286, 287, 288, 289, 295, 296, 297, 298, 299, 300, 302, 303, 307, 308, 312, 313, 318, 321, 326, 327, 328, 334, 342, 343, 346, 351, 352, 353, 354, 360, 364, 365, 369, 370, 382, 383, 384, 385, 386, 386, 389, 391, 392, 398, 398, 401, 403, 404, 410, 414, 415, 419, 420, 434, 437, 442, 443, 444, 447, 452, 453, 454, 455, 457, 459, 465, 466, 467, 468, 469, 492, 493, 494, 495, 496, 499, 504, 505, 510, 511, 516, 517, 520, 524, 527, 528, 529, 531, 532, 535, 536, 540, 545, 546, 547, 548, 551, 556, 557, 558, 559, 563, 574, 575, 576, 596, 597, 598, 603, 604, 605, 606, 609, 610, 615, 616, 617, 618, 619, 620, 621, 624, 625, 626, 627, 628, 629, 630, 631, 632, 640, 642, 643, 644, 652, 657, 658, 661, 665, 670, 673, 679, 686, 691, 694, 696, 697, 709, 714, 715, 716, 723, 728, 731, 734, 735, 743, 748, 749, 751, 754, 758, 761, 764, 775, 778, 783, 784, 785, 790, 791, 793, 796, 800, 803, 805, 811, 818, 819, 824, 825, 826, 828, 829, 834, 835, 836, 857, 858, 861, 862, 863, 864, 865, 866, 868, 871, 873, 876, 878, 882, 887, 888, 893, 894, 897, 901, 905, 906, 908, 911, 915, 918, 920, 922, 923, 925, 930, 933, 936, 940, 943, 946, 950, 953, 956, 960};
/* BEGIN LINEINFO 
assign 1 168 61
new 0 168 61
assign 1 168 62
once 0 168 62
assign 1 168 63
new 0 168 63
assign 1 168 64
once 0 168 64
new 2 168 65
new 2 172 69
assign 1 176 80
undef 1 176 85
assign 1 0 86
assign 1 176 89
undef 1 176 94
assign 1 0 95
assign 1 0 98
assign 1 177 102
new 0 177 102
assign 1 177 103
new 1 177 103
throw 1 177 104
assign 1 179 106
def 1 179 111
assign 1 182 112
equals 1 182 117
return 1 183 118
assign 1 207 123
copy 0 207 123
assign 1 208 124
copy 0 208 124
assign 1 209 125
new 0 209 125
return 1 214 129
assign 1 218 136
new 0 218 136
assign 1 218 137
equals 1 218 142
assign 1 219 143
new 0 219 143
return 1 219 144
assign 1 221 146
new 0 221 146
return 1 221 147
assign 1 231 157
toString 0 231 157
return 1 231 158
assign 1 235 162
new 1 235 162
new 1 235 163
assign 1 239 168
iteratorGet 0 239 168
return 1 239 169
assign 1 243 174
new 0 243 174
assign 1 243 175
get 1 243 175
return 1 243 176
assign 1 247 182
new 0 247 182
assign 1 247 183
subtract 1 247 183
assign 1 247 184
get 1 247 184
return 1 247 185
assign 1 251 195
new 0 251 195
assign 1 251 196
lesser 1 251 201
assign 1 252 202
new 0 252 202
assign 1 252 203
new 1 252 203
throw 1 252 204
assign 1 254 206
greaterEquals 1 254 211
assign 1 255 212
new 0 255 212
assign 1 255 213
add 1 255 213
lengthSet 1 255 214
assign 1 271 226
new 0 271 226
assign 1 271 227
greaterEquals 1 271 232
assign 1 271 233
lesser 1 271 238
assign 1 0 239
assign 1 0 242
assign 1 0 246
return 1 283 252
assign 1 287 267
lesser 1 287 272
assign 1 288 273
new 0 288 273
assign 1 288 274
subtract 1 288 274
assign 1 289 275
new 0 289 275
assign 1 289 276
add 1 289 276
assign 1 290 277
copy 0 290 277
assign 1 290 280
lesser 1 290 285
assign 1 291 286
get 1 291 286
put 2 291 287
incrementValue 0 292 288
incrementValue 0 290 289
put 2 294 295
assign 1 295 296
new 0 295 296
assign 1 295 297
subtract 1 295 297
lengthSet 1 295 298
assign 1 296 299
new 0 296 299
return 1 296 300
assign 1 298 302
new 0 298 302
return 1 298 303
assign 1 302 307
new 1 302 307
return 1 302 308
assign 1 306 312
new 1 306 312
return 1 306 313
assign 1 310 318
new 0 310 318
assign 1 310 321
lesser 1 310 326
put 2 311 327
incrementValue 0 310 328
assign 1 313 334
new 0 313 334
assign 1 317 342
create 0 317 342
assign 1 318 343
new 0 318 343
assign 1 318 346
lesser 1 318 351
assign 1 319 352
get 1 319 352
put 2 319 353
incrementValue 0 318 354
return 1 321 360
assign 1 324 364
new 1 324 364
return 1 324 365
assign 1 326 369
new 1 326 369
return 1 326 370
assign 1 329 382
new 0 329 382
assign 1 329 383
lengthGet 0 329 383
assign 1 329 384
add 1 329 384
assign 1 329 385
new 2 329 385
assign 1 330 386
iteratorGet 0 0 386
assign 1 330 389
hasNextGet 0 330 389
assign 1 330 391
nextGet 0 330 391
addValueWhole 1 331 392
assign 1 333 398
iteratorGet 0 0 398
assign 1 333 401
hasNextGet 0 333 401
assign 1 333 403
nextGet 0 333 403
addValueWhole 1 334 404
return 1 336 410
assign 1 340 414
mergeSort 0 340 414
return 1 340 415
assign 1 344 419
new 0 344 419
sortValue 2 344 420
assign 1 348 434
copy 0 348 434
assign 1 348 437
lesser 1 348 442
assign 1 349 443
copy 0 349 443
assign 1 350 444
copy 0 350 444
assign 1 350 447
lesser 1 350 452
assign 1 351 453
get 1 351 453
assign 1 351 454
get 1 351 454
assign 1 351 455
lesser 1 351 455
assign 1 352 457
copy 0 352 457
incrementValue 0 350 459
assign 1 355 465
get 1 355 465
assign 1 356 466
get 1 356 466
put 2 356 467
put 2 357 468
incrementValue 0 348 469
assign 1 362 492
new 0 362 492
assign 1 363 493
new 0 363 493
assign 1 364 494
new 0 364 494
assign 1 365 495
lengthGet 0 365 495
assign 1 366 496
lengthGet 0 366 496
assign 1 367 499
lesser 1 367 504
assign 1 368 505
lesser 1 368 510
assign 1 368 511
lesser 1 368 516
assign 1 0 517
assign 1 0 520
assign 1 0 524
assign 1 369 527
get 1 369 527
assign 1 370 528
get 1 370 528
assign 1 371 529
lesser 1 371 529
incrementValue 0 372 531
put 2 373 532
incrementValue 0 375 535
put 2 376 536
assign 1 378 540
lesser 1 378 545
assign 1 379 546
get 1 379 546
incrementValue 0 380 547
put 2 381 548
assign 1 382 551
lesser 1 382 556
assign 1 383 557
get 1 383 557
incrementValue 0 384 558
put 2 385 559
incrementValue 0 387 563
assign 1 392 574
new 0 392 574
assign 1 392 575
mergeSort 2 392 575
return 1 392 576
assign 1 396 596
subtract 1 396 596
assign 1 397 597
new 0 397 597
assign 1 397 598
equals 1 397 603
assign 1 398 604
new 0 398 604
assign 1 398 605
create 1 398 605
return 1 398 606
assign 1 399 609
new 0 399 609
assign 1 399 610
equals 1 399 615
assign 1 400 616
new 0 400 616
assign 1 400 617
create 1 400 617
assign 1 401 618
new 0 401 618
assign 1 401 619
get 1 401 619
put 2 401 620
return 1 402 621
assign 1 404 624
new 0 404 624
assign 1 404 625
divide 1 404 625
assign 1 405 626
subtract 1 405 626
assign 1 406 627
add 1 406 627
assign 1 407 628
mergeSort 2 407 628
assign 1 408 629
mergeSort 2 408 629
assign 1 409 630
create 1 409 630
mergeIn 2 410 631
return 1 411 632
assign 1 416 640
new 0 416 640
assign 1 417 642
new 0 417 642
assign 1 417 643
new 1 417 643
throw 1 417 644
assign 1 423 652
greater 1 423 657
assign 1 424 658
multiply 1 424 658
assign 1 445 661
assign 1 448 665
lesser 1 448 670
incrementValue 0 459 673
setValue 1 461 679
assign 1 465 686
def 1 465 691
assign 1 466 694
hasNextGet 0 466 694
assign 1 467 696
nextGet 0 467 696
addValueWhole 1 467 697
assign 1 473 709
def 1 473 714
assign 1 474 715
iteratorGet 0 474 715
iterateAdd 1 474 716
assign 1 479 723
lesser 1 479 728
incrementValue 0 490 731
assign 1 493 734
copy 0 493 734
put 2 493 735
assign 1 498 743
def 1 498 748
assign 1 498 749
sameType 1 498 749
assign 1 0 751
assign 1 0 754
assign 1 0 758
addAll 1 499 761
addValueWhole 1 501 764
assign 1 507 775
new 0 507 775
assign 1 507 778
lesser 1 507 783
assign 1 508 784
get 1 508 784
assign 1 509 785
def 1 509 790
assign 1 509 791
equals 1 509 791
assign 1 0 793
assign 1 0 796
assign 1 0 800
return 1 510 803
incrementValue 0 507 805
return 1 513 811
assign 1 517 818
find 1 517 818
assign 1 517 819
def 1 517 824
assign 1 518 825
new 0 518 825
return 1 518 826
assign 1 520 828
new 0 520 828
return 1 520 829
assign 1 526 834
new 0 526 834
assign 1 526 835
sortedFind 2 526 835
return 1 526 836
assign 1 533 857
assign 1 534 858
new 0 534 858
assign 1 538 861
subtract 1 538 861
assign 1 538 862
new 0 538 862
assign 1 538 863
divide 1 538 863
assign 1 538 864
add 1 538 864
assign 1 539 865
get 1 539 865
assign 1 540 866
equals 1 540 866
return 1 541 868
assign 1 542 871
greater 1 542 871
assign 1 544 873
assign 1 545 876
lesser 1 545 876
assign 1 547 878
assign 1 550 882
def 1 550 887
assign 1 550 888
equals 1 550 893
assign 1 0 894
assign 1 0 897
assign 1 0 901
assign 1 551 905
get 1 551 905
assign 1 551 906
lesser 1 551 906
assign 1 0 908
assign 1 0 911
assign 1 0 915
return 1 552 918
return 1 554 920
assign 1 556 922
assign 1 557 923
new 0 557 923
return 1 558 925
return 1 0 930
return 1 0 933
assign 1 0 936
return 1 0 940
return 1 0 943
assign 1 0 946
return 1 0 950
return 1 0 953
assign 1 0 956
assign 1 0 960
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 271653184: return bem_lengthGet_0();
case 1965014374: return bem_sortValue_0();
case -607720919: return bem_lengthGetDirect_0();
case -1197657605: return bem_multiplierGetDirect_0();
case -1043543071: return bem_create_0();
case -1765404298: return bem_anyraySet_0();
case 1809869265: return bem_many_0();
case -1200514874: return bem_once_0();
case 2022567405: return bem_tagGet_0();
case 1331103198: return bem_arrayIteratorGet_0();
case -1699329532: return bem_capacityGet_0();
case 795649196: return bem_serializationIteratorGet_0();
case 190764838: return bem_toString_0();
case 951607569: return bem_isEmptyGet_0();
case -1751770558: return bem_mergeSort_0();
case 438383862: return bem_lastGet_0();
case -1048585343: return bem_copy_0();
case -2083809207: return bem_clear_0();
case 357236059: return bem_multiplierGet_0();
case -193453355: return bem_iteratorGet_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -1800587860: return bem_serializeToString_0();
case 789212644: return bem_anyrayGet_0();
case 1463816718: return bem_sourceFileNameGet_0();
case 451316734: return bem_new_0();
case -1021558772: return bem_fieldIteratorGet_0();
case -1440276159: return bem_firstGet_0();
case -477940854: return bem_hashGet_0();
case 976768273: return bem_fieldNamesGet_0();
case -2011984947: return bem_classNameGet_0();
case -1615839398: return bem_echo_0();
case -1169168081: return bem_sizeGet_0();
case 1676099975: return bem_sort_0();
case 497538979: return bem_capacityGetDirect_0();
case -204986197: return bem_print_0();
case -1017732045: return bem_toAny_0();
case -1852647932: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 642024068: return bem_capacitySetDirect_1(bevd_0);
case 1676289220: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case -1982914370: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1924203162: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 1670296534: return bem_addValueWhole_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case 478721017: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case -974417776: return bem_undef_1(bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case 1524541780: return bem_addValue_1(bevd_0);
case 1317898590: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case -1933968740: return bem_multiplierSetDirect_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
case 1255352870: return bem_notEquals_1(bevd_0);
case 998697941: return bem_sortedFind_1(bevd_0);
case 1383199380: return bem_lengthSetDirect_1(bevd_0);
case -451161373: return bem_multiplierSet_1(bevd_0);
case 69759293: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case -711439582: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -252330168: return bem_def_1(bevd_0);
case -350335857: return bem_find_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case -1885956875: return bem_iterateAdd_1(bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1835850262: return bem_addAll_1(bevd_0);
case -1535130404: return bem_has_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1748490289: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2111396893: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1375015186: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1389203504: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -122665749: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1465903392: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_type;
}
}
}
