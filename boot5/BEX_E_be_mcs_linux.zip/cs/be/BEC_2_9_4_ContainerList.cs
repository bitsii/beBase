namespace be {

using System;
    /* IO:File: source/base/List.be */
public sealed class BEC_2_9_4_ContainerList : BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerList() { }
static BEC_2_9_4_ContainerList() { }

   
    public BEC_2_6_6_SystemObject[] bevi_list;
    
   
   
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   public BEC_2_9_4_ContainerList(BEC_2_6_6_SystemObject[] bevi_list, int len) {
        this.bevi_list = bevi_list;
        this.bevp_length = new BEC_2_4_3_MathInt(len);
        this.bevp_capacity = new BEC_2_4_3_MathInt(bevi_list.Length);
        this.bevp_multiplier = new BEC_2_4_3_MathInt(2);
    }
    
   private static byte[] becc_BEC_2_9_4_ContainerList_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4C,0x69,0x73,0x74};
private static byte[] becc_BEC_2_9_4_ContainerList_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_1 = (new BEC_2_4_3_MathInt(16));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_0 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x20,0x74,0x6F,0x20,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x20,0x61,0x6E,0x20,0x61,0x72,0x72,0x61,0x79,0x20,0x77,0x69,0x74,0x68,0x20,0x61,0x20,0x6E,0x75,0x6C,0x6C,0x20,0x6C,0x65,0x6E,0x67,0x74,0x68,0x20,0x6F,0x72,0x20,0x63,0x61,0x70,0x61,0x63,0x69,0x74,0x79};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_2 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_1 = {0x41,0x74,0x74,0x65,0x6D,0x70,0x74,0x65,0x64,0x20,0x70,0x75,0x74,0x20,0x77,0x69,0x74,0x68,0x20,0x69,0x6E,0x64,0x65,0x78,0x20,0x6C,0x65,0x73,0x73,0x20,0x74,0x68,0x61,0x6E,0x20,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_7 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_9 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_10 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_11 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_12 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_13 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_14 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_9_4_ContainerList_bels_2 = {0x4E,0x6F,0x74,0x20,0x53,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64};
private static BEC_2_4_3_MathInt bece_BEC_2_9_4_ContainerList_bevo_15 = (new BEC_2_4_3_MathInt(2));
public static new BEC_2_9_4_ContainerList bece_BEC_2_9_4_ContainerList_bevs_inst;
public BEC_2_4_3_MathInt bevp_length;
public BEC_2_4_3_MathInt bevp_capacity;
public BEC_2_4_3_MathInt bevp_multiplier;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bem_new_2(bevt_0_tmpany_phold, bevt_2_tmpany_phold);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_1(BEC_2_4_3_MathInt beva_leni) {
bem_new_2(beva_leni, beva_leni);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_new_2(BEC_2_4_3_MathInt beva_leni, BEC_2_4_3_MathInt beva_capi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
if (beva_leni == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 153 */ {
if (beva_capi == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 153 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 153 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 153 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(61, bece_BEC_2_9_4_ContainerList_bels_0));
bevt_3_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_4_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_3_tmpany_phold);
} /* Line: 154 */
if (bevp_length == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 156 */ {
if (bevp_length.bevi_int == beva_leni.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 159 */ {
return this;
} /* Line: 160 */
} /* Line: 159 */

      bevi_list = new BEC_2_6_6_SystemObject[beva_capi.bevi_int];
      bevp_length = (BEC_2_4_3_MathInt) beva_leni.bem_copy_0();
bevp_capacity = (BEC_2_4_3_MathInt) beva_capi.bem_copy_0();
bevp_multiplier = bece_BEC_2_9_4_ContainerList_bevo_2;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_3;
if (bevp_length.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 188 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyrayGet_0() {
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_anyraySet_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_length.bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(beva_snw);
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_iteratorGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_firstGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_4;
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_lastGet_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_5;
bevt_1_tmpany_phold = bevp_length.bem_subtract_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_get_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_put_2(BEC_2_4_3_MathInt beva_posi, BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_6;
if (beva_posi.bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 220 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_9_4_ContainerList_bels_1));
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 221 */
if (beva_posi.bevi_int >= bevp_length.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 223 */ {
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_7;
bevt_5_tmpany_phold = beva_posi.bem_add_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
} /* Line: 224 */

      this.bevi_list[beva_posi.bevi_int] = beva_val;
      return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_3_MathInt beva_posi) {
BEC_2_6_6_SystemObject bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_8;
if (beva_posi.bevi_int >= bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 235 */ {
if (beva_posi.bevi_int < bevp_length.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 235 */
 else  /* Line: 235 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 235 */ {

      bevl_val = this.bevi_list[beva_posi.bevi_int];
      } /* Line: 236 */
return bevl_val;
} /*method end*/
public BEC_2_6_6_SystemObject bem_delete_1(BEC_2_4_3_MathInt beva_pos) {
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
if (beva_pos.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 246 */ {
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_9;
bevl_fl = bevp_length.bem_subtract_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_10;
bevl_j = beva_pos.bem_add_1(bevt_2_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) beva_pos.bem_copy_0();
while (true)
 /* Line: 249 */ {
if (bevl_i.bevi_int < bevl_fl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevt_4_tmpany_phold = bem_get_1(bevl_j);
bem_put_2(bevl_i, bevt_4_tmpany_phold);
bevl_j.bevi_int++;
bevl_i.bevi_int++;
} /* Line: 249 */
 else  /* Line: 249 */ {
break;
} /* Line: 249 */
} /* Line: 249 */
bem_put_2(bevl_fl, null);
bevt_6_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_11;
bevt_5_tmpany_phold = bevp_length.bem_subtract_1(bevt_6_tmpany_phold);
bem_lengthSet_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /* Line: 255 */
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_8_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_9_4_8_ContainerListIterator bem_arrayIteratorGet_0() {
BEC_3_9_4_8_ContainerListIterator bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_3_9_4_8_ContainerListIterator) (new BEC_3_9_4_8_ContainerListIterator()).bem_new_1(this);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_clear_0() {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 269 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 269 */ {
bem_put_2(bevl_i, null);
bevl_i.bevi_int++;
} /* Line: 269 */
 else  /* Line: 269 */ {
break;
} /* Line: 269 */
} /* Line: 269 */
bevp_length = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_9_4_ContainerList bevl_n = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_n = (BEC_2_9_4_ContainerList) bem_create_0();
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 277 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 277 */ {
bevt_1_tmpany_phold = bem_get_1(bevl_i);
bevl_n.bem_put_2(bevl_i, bevt_1_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 277 */
 else  /* Line: 277 */ {
break;
} /* Line: 277 */
} /* Line: 277 */
return (BEC_2_6_6_SystemObject) bevl_n;
} /*method end*/
public BEC_2_6_6_SystemObject bem_create_1(BEC_2_4_3_MathInt beva_len) {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva_len);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevp_length);
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_add_1(BEC_2_9_4_ContainerList beva_xi) {
BEC_2_9_4_ContainerList bevl_yi = null;
BEC_2_6_6_SystemObject bevl_c = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_4_tmpany_phold = beva_xi.bem_lengthGet_0();
bevt_3_tmpany_phold = bevp_length.bem_add_1(bevt_4_tmpany_phold);
bevl_yi = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_loop = bem_iteratorGet_0();
while (true)
 /* Line: 289 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(2013906518);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 289 */ {
bevl_c = bevt_0_tmpany_loop.bemd_0(1440809036);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 290 */
 else  /* Line: 289 */ {
break;
} /* Line: 289 */
} /* Line: 289 */
bevt_1_tmpany_loop = beva_xi.bem_iteratorGet_0();
while (true)
 /* Line: 292 */ {
bevt_6_tmpany_phold = bevt_1_tmpany_loop.bemd_0(2013906518);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 292 */ {
bevl_c = bevt_1_tmpany_loop.bemd_0(1440809036);
bevl_yi.bem_addValueWhole_1(bevl_c);
} /* Line: 293 */
 else  /* Line: 292 */ {
break;
} /* Line: 292 */
} /* Line: 292 */
return (BEC_2_9_4_ContainerList) bevl_yi;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sort_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bem_mergeSort_0();
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_sortValue_2(bevt_0_tmpany_phold, bevp_length);
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_sortValue_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_6_6_SystemObject bevl_hold = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) beva_start.bem_copy_0();
while (true)
 /* Line: 307 */ {
if (bevl_i.bevi_int < beva_end.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 307 */ {
bevl_c = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
bevl_j = (BEC_2_4_3_MathInt) bevl_i.bem_copy_0();
while (true)
 /* Line: 309 */ {
if (bevl_j.bevi_int < beva_end.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevt_3_tmpany_phold = bem_get_1(bevl_j);
bevt_4_tmpany_phold = bem_get_1(bevl_c);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_1(-584996098, bevt_4_tmpany_phold);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 310 */ {
bevl_c = (BEC_2_4_3_MathInt) bevl_j.bem_copy_0();
} /* Line: 311 */
bevl_j.bevi_int++;
} /* Line: 309 */
 else  /* Line: 309 */ {
break;
} /* Line: 309 */
} /* Line: 309 */
bevl_hold = bem_get_1(bevl_i);
bevt_5_tmpany_phold = bem_get_1(bevl_c);
bem_put_2(bevl_i, bevt_5_tmpany_phold);
bem_put_2(bevl_c, bevl_hold);
bevl_i.bevi_int++;
} /* Line: 307 */
 else  /* Line: 307 */ {
break;
} /* Line: 307 */
} /* Line: 307 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeIn_2(BEC_2_9_4_ContainerList beva_first, BEC_2_9_4_ContainerList beva_second) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_fi = null;
BEC_2_4_3_MathInt bevl_si = null;
BEC_2_4_3_MathInt bevl_fl = null;
BEC_2_4_3_MathInt bevl_sl = null;
BEC_2_6_6_SystemObject bevl_fo = null;
BEC_2_6_6_SystemObject bevl_so = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_si = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_fl = beva_first.bem_lengthGet_0();
bevl_sl = beva_second.bem_lengthGet_0();
while (true)
 /* Line: 326 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 326 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 327 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 327 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 327 */
 else  /* Line: 327 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 327 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_so = beva_second.bem_get_1(bevl_si);
bevt_4_tmpany_phold = bevl_so.bemd_1(-584996098, bevl_fo);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 330 */ {
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 332 */
 else  /* Line: 333 */ {
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 335 */
} /* Line: 330 */
 else  /* Line: 327 */ {
if (bevl_si.bevi_int < bevl_sl.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 337 */ {
bevl_so = beva_second.bem_get_1(bevl_si);
bevl_si.bevi_int++;
bem_put_2(bevl_i, bevl_so);
} /* Line: 340 */
 else  /* Line: 327 */ {
if (bevl_fi.bevi_int < bevl_fl.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 341 */ {
bevl_fo = beva_first.bem_get_1(bevl_fi);
bevl_fi.bevi_int++;
bem_put_2(bevl_i, bevl_fo);
} /* Line: 344 */
} /* Line: 327 */
} /* Line: 327 */
bevl_i.bevi_int++;
} /* Line: 346 */
 else  /* Line: 326 */ {
break;
} /* Line: 326 */
} /* Line: 326 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_0() {
BEC_2_9_4_ContainerList bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_0_tmpany_phold = (BEC_2_9_4_ContainerList) bem_mergeSort_2(bevt_1_tmpany_phold, bevp_length);
return (BEC_2_9_4_ContainerList) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_9_4_ContainerList bem_mergeSort_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) {
BEC_2_4_3_MathInt bevl_mlen = null;
BEC_2_9_4_ContainerList bevl_ra = null;
BEC_2_4_3_MathInt bevl_shalf = null;
BEC_2_4_3_MathInt bevl_fhalf = null;
BEC_2_4_3_MathInt bevl_fend = null;
BEC_2_9_4_ContainerList bevl_fa = null;
BEC_2_9_4_ContainerList bevl_sa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
bevl_mlen = beva_end.bem_subtract_1(beva_start);
bevt_1_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_12;
if (bevl_mlen.bevi_int == bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 356 */ {
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_2_tmpany_phold = bem_create_1(bevt_3_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevt_2_tmpany_phold;
} /* Line: 357 */
 else  /* Line: 356 */ {
bevt_5_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_13;
if (bevl_mlen.bevi_int == bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 358 */ {
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_8_tmpany_phold = bem_get_1(beva_start);
bevl_ra.bem_put_2(bevt_7_tmpany_phold, bevt_8_tmpany_phold);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 361 */
 else  /* Line: 362 */ {
bevt_9_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_14;
bevl_shalf = bevl_mlen.bem_divide_1(bevt_9_tmpany_phold);
bevl_fhalf = bevl_mlen.bem_subtract_1(bevl_shalf);
bevl_fend = beva_start.bem_add_1(bevl_fhalf);
bevl_fa = (BEC_2_9_4_ContainerList) bem_mergeSort_2(beva_start, bevl_fend);
bevl_sa = (BEC_2_9_4_ContainerList) bem_mergeSort_2(bevl_fend, beva_end);
bevl_ra = (BEC_2_9_4_ContainerList) bem_create_1(bevl_mlen);
bevl_ra.bem_mergeIn_2(bevl_fa, bevl_sa);
return (BEC_2_9_4_ContainerList) bevl_ra;
} /* Line: 370 */
} /* Line: 356 */
} /*method end*/
public BEC_2_9_4_ContainerList bem_capacitySet_1(BEC_2_4_3_MathInt beva_newcap) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 375 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_9_4_ContainerList_bels_2));
bevt_1_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_2_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_1_tmpany_phold);
} /* Line: 376 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_lengthSet_1(BEC_2_4_3_MathInt beva_newlen) {
BEC_2_4_3_MathInt bevl_newcap = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (beva_newlen.bevi_int > bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevl_newcap = beva_newlen.bem_multiply_1(bevp_multiplier);

         Array.Resize(ref bevi_list, bevl_newcap.bevi_int);
         bevp_capacity = bevl_newcap;
} /* Line: 399 */
while (true)
 /* Line: 402 */ {
if (bevp_length.bevi_int < beva_newlen.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 402 */ {

         this.bevi_list[this.bevp_length.bevi_int] = null;
         bevp_length.bevi_int++;
} /* Line: 408 */
 else  /* Line: 402 */ {
break;
} /* Line: 402 */
} /* Line: 402 */
bevp_length.bevi_int = beva_newlen.bevi_int;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_iterateAdd_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 414 */ {
while (true)
 /* Line: 415 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(2013906518);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 415 */ {
bevt_2_tmpany_phold = beva_val.bemd_0(1440809036);
bem_addValueWhole_1(bevt_2_tmpany_phold);
} /* Line: 416 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
} /* Line: 415 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addAll_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
if (beva_val == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 422 */ {
bevt_1_tmpany_phold = beva_val.bemd_0(-1710921376);
bem_iterateAdd_1(bevt_1_tmpany_phold);
} /* Line: 423 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValueWhole_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_length.bevi_int < bevp_capacity.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 428 */ {

       this.bevi_list[this.bevp_length.bevi_int] = beva_val;
       bevp_length.bevi_int++;
} /* Line: 434 */
 else  /* Line: 435 */ {
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevp_length.bem_copy_0();
bem_put_2(bevt_1_tmpany_phold, beva_val);
} /* Line: 437 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_addValue_1(BEC_2_6_6_SystemObject beva_val) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
if (beva_val == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 442 */ {
bevt_2_tmpany_phold = beva_val.bemd_1(343567700, this);
if (bevt_2_tmpany_phold != null && bevt_2_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 442 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 442 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 442 */
 else  /* Line: 442 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 442 */ {
bem_addAll_1(beva_val);
} /* Line: 443 */
 else  /* Line: 444 */ {
bem_addValueWhole_1(beva_val);
} /* Line: 445 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_find_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 451 */ {
if (bevl_i.bevi_int < bevp_length.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 451 */ {
bevl_aval = bem_get_1(bevl_i);
if (bevl_aval == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 453 */ {
bevt_3_tmpany_phold = beva_value.bemd_1(365385951, bevl_aval);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 453 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 453 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 453 */
 else  /* Line: 453 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 453 */ {
return bevl_i;
} /* Line: 454 */
bevl_i.bevi_int++;
} /* Line: 451 */
 else  /* Line: 451 */ {
break;
} /* Line: 451 */
} /* Line: 451 */
return null;
} /*method end*/
public BEC_2_5_4_LogicBool bem_has_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bem_find_1(beva_value);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 461 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 462 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_1(BEC_2_6_6_SystemObject beva_value) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_0_tmpany_phold = bem_sortedFind_2(beva_value, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_sortedFind_2(BEC_2_6_6_SystemObject beva_value, BEC_2_5_4_LogicBool beva_returnNoMatch) {
BEC_2_4_3_MathInt bevl_high = null;
BEC_2_4_3_MathInt bevl_low = null;
BEC_2_4_3_MathInt bevl_lastMid = null;
BEC_2_4_3_MathInt bevl_mid = null;
BEC_2_6_6_SystemObject bevl_aval = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
bevl_high = bevp_length;
bevl_low = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 481 */ {
bevt_3_tmpany_phold = bevl_high.bem_subtract_1(bevl_low);
bevt_4_tmpany_phold = bece_BEC_2_9_4_ContainerList_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_divide_1(bevt_4_tmpany_phold);
bevl_mid = bevt_2_tmpany_phold.bem_add_1(bevl_low);
bevl_aval = bem_get_1(bevl_mid);
bevt_5_tmpany_phold = beva_value.bemd_1(365385951, bevl_aval);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 484 */ {
return bevl_mid;
} /* Line: 485 */
 else  /* Line: 484 */ {
bevt_6_tmpany_phold = beva_value.bemd_1(-1596903881, bevl_aval);
if (bevt_6_tmpany_phold != null && bevt_6_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevl_low = bevl_mid;
} /* Line: 488 */
 else  /* Line: 484 */ {
bevt_7_tmpany_phold = beva_value.bemd_1(-584996098, bevl_aval);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevl_high = bevl_mid;
} /* Line: 491 */
} /* Line: 484 */
} /* Line: 484 */
if (bevl_lastMid == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 494 */ {
if (bevl_lastMid.bevi_int == bevl_mid.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 494 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 494 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 494 */
 else  /* Line: 494 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 494 */ {
if (beva_returnNoMatch.bevi_bool) /* Line: 495 */ {
bevt_11_tmpany_phold = bem_get_1(bevl_low);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_1(-584996098, beva_value);
if (bevt_10_tmpany_phold != null && bevt_10_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_10_tmpany_phold).bevi_bool) /* Line: 495 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 495 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 495 */
 else  /* Line: 495 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 495 */ {
return bevl_low;
} /* Line: 496 */
return null;
} /* Line: 498 */
bevl_lastMid = bevl_mid;
bevt_12_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 501 */ {
return null;
} /* Line: 502 */
} /* Line: 501 */
} /*method end*/
public BEC_2_4_3_MathInt bem_lengthGet_0() {
return bevp_length;
} /*method end*/
public BEC_2_4_3_MathInt bem_capacityGet_0() {
return bevp_capacity;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplierGet_0() {
return bevp_multiplier;
} /*method end*/
public BEC_2_9_4_ContainerList bem_multiplierSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_multiplier = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {145, 145, 145, 145, 145, 149, 153, 153, 0, 153, 153, 0, 0, 154, 154, 154, 156, 156, 159, 159, 160, 176, 177, 178, 183, 187, 187, 187, 188, 188, 190, 190, 200, 200, 204, 204, 208, 208, 212, 212, 212, 216, 216, 216, 216, 220, 220, 220, 221, 221, 221, 223, 223, 224, 224, 224, 235, 235, 235, 235, 235, 0, 0, 0, 242, 246, 246, 247, 247, 248, 248, 249, 249, 249, 250, 250, 251, 249, 253, 254, 254, 254, 255, 255, 257, 257, 261, 261, 265, 265, 269, 269, 269, 270, 269, 272, 276, 277, 277, 277, 278, 278, 277, 280, 283, 283, 285, 285, 288, 288, 288, 288, 289, 0, 289, 289, 290, 292, 0, 292, 292, 293, 295, 299, 299, 303, 303, 307, 307, 307, 308, 309, 309, 309, 310, 310, 310, 311, 309, 314, 315, 315, 316, 307, 321, 322, 323, 324, 325, 326, 326, 327, 327, 327, 327, 0, 0, 0, 328, 329, 330, 331, 332, 334, 335, 337, 337, 338, 339, 340, 341, 341, 342, 343, 344, 346, 351, 351, 351, 355, 356, 356, 356, 357, 357, 357, 358, 358, 358, 359, 359, 360, 360, 360, 361, 363, 363, 364, 365, 366, 367, 368, 369, 370, 375, 376, 376, 376, 382, 382, 383, 399, 402, 402, 408, 410, 414, 414, 415, 416, 416, 422, 422, 423, 423, 428, 428, 434, 437, 437, 442, 442, 442, 0, 0, 0, 443, 445, 451, 451, 451, 452, 453, 453, 453, 0, 0, 0, 454, 451, 457, 461, 461, 461, 462, 462, 464, 464, 470, 470, 470, 477, 478, 482, 482, 482, 482, 483, 484, 485, 486, 488, 489, 491, 494, 494, 494, 494, 0, 0, 0, 495, 495, 0, 0, 0, 496, 498, 500, 501, 502, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {58, 59, 60, 61, 62, 66, 77, 82, 83, 86, 91, 92, 95, 99, 100, 101, 103, 108, 109, 114, 115, 120, 121, 122, 126, 133, 134, 139, 140, 141, 143, 144, 154, 155, 159, 160, 165, 166, 171, 172, 173, 179, 180, 181, 182, 192, 193, 198, 199, 200, 201, 203, 208, 209, 210, 211, 223, 224, 229, 230, 235, 236, 239, 243, 249, 264, 269, 270, 271, 272, 273, 274, 277, 282, 283, 284, 285, 286, 292, 293, 294, 295, 296, 297, 299, 300, 304, 305, 309, 310, 315, 318, 323, 324, 325, 331, 339, 340, 343, 348, 349, 350, 351, 357, 361, 362, 366, 367, 379, 380, 381, 382, 383, 383, 386, 388, 389, 395, 395, 398, 400, 401, 407, 411, 412, 416, 417, 431, 434, 439, 440, 441, 444, 449, 450, 451, 452, 454, 456, 462, 463, 464, 465, 466, 489, 490, 491, 492, 493, 496, 501, 502, 507, 508, 513, 514, 517, 521, 524, 525, 526, 528, 529, 532, 533, 537, 542, 543, 544, 545, 548, 553, 554, 555, 556, 560, 571, 572, 573, 593, 594, 595, 600, 601, 602, 603, 606, 607, 612, 613, 614, 615, 616, 617, 618, 621, 622, 623, 624, 625, 626, 627, 628, 629, 637, 639, 640, 641, 649, 654, 655, 658, 662, 667, 670, 676, 683, 688, 691, 693, 694, 706, 711, 712, 713, 720, 725, 728, 731, 732, 740, 745, 746, 748, 751, 755, 758, 761, 772, 775, 780, 781, 782, 787, 788, 790, 793, 797, 800, 802, 808, 815, 816, 821, 822, 823, 825, 826, 831, 832, 833, 854, 855, 858, 859, 860, 861, 862, 863, 865, 868, 870, 873, 875, 879, 884, 885, 890, 891, 894, 898, 902, 903, 905, 908, 912, 915, 917, 919, 920, 922, 927, 930, 933, 936};
/* BEGIN LINEINFO 
assign 1 145 58
new 0 145 58
assign 1 145 59
once 0 145 59
assign 1 145 60
new 0 145 60
assign 1 145 61
once 0 145 61
new 2 145 62
new 2 149 66
assign 1 153 77
undef 1 153 82
assign 1 0 83
assign 1 153 86
undef 1 153 91
assign 1 0 92
assign 1 0 95
assign 1 154 99
new 0 154 99
assign 1 154 100
new 1 154 100
throw 1 154 101
assign 1 156 103
def 1 156 108
assign 1 159 109
equals 1 159 114
return 1 160 115
assign 1 176 120
copy 0 176 120
assign 1 177 121
copy 0 177 121
assign 1 178 122
new 0 178 122
return 1 183 126
assign 1 187 133
new 0 187 133
assign 1 187 134
equals 1 187 139
assign 1 188 140
new 0 188 140
return 1 188 141
assign 1 190 143
new 0 190 143
return 1 190 144
assign 1 200 154
toString 0 200 154
return 1 200 155
assign 1 204 159
new 1 204 159
new 1 204 160
assign 1 208 165
iteratorGet 0 208 165
return 1 208 166
assign 1 212 171
new 0 212 171
assign 1 212 172
get 1 212 172
return 1 212 173
assign 1 216 179
new 0 216 179
assign 1 216 180
subtract 1 216 180
assign 1 216 181
get 1 216 181
return 1 216 182
assign 1 220 192
new 0 220 192
assign 1 220 193
lesser 1 220 198
assign 1 221 199
new 0 221 199
assign 1 221 200
new 1 221 200
throw 1 221 201
assign 1 223 203
greaterEquals 1 223 208
assign 1 224 209
new 0 224 209
assign 1 224 210
add 1 224 210
lengthSet 1 224 211
assign 1 235 223
new 0 235 223
assign 1 235 224
greaterEquals 1 235 229
assign 1 235 230
lesser 1 235 235
assign 1 0 236
assign 1 0 239
assign 1 0 243
return 1 242 249
assign 1 246 264
lesser 1 246 269
assign 1 247 270
new 0 247 270
assign 1 247 271
subtract 1 247 271
assign 1 248 272
new 0 248 272
assign 1 248 273
add 1 248 273
assign 1 249 274
copy 0 249 274
assign 1 249 277
lesser 1 249 282
assign 1 250 283
get 1 250 283
put 2 250 284
incrementValue 0 251 285
incrementValue 0 249 286
put 2 253 292
assign 1 254 293
new 0 254 293
assign 1 254 294
subtract 1 254 294
lengthSet 1 254 295
assign 1 255 296
new 0 255 296
return 1 255 297
assign 1 257 299
new 0 257 299
return 1 257 300
assign 1 261 304
new 1 261 304
return 1 261 305
assign 1 265 309
new 1 265 309
return 1 265 310
assign 1 269 315
new 0 269 315
assign 1 269 318
lesser 1 269 323
put 2 270 324
incrementValue 0 269 325
assign 1 272 331
new 0 272 331
assign 1 276 339
create 0 276 339
assign 1 277 340
new 0 277 340
assign 1 277 343
lesser 1 277 348
assign 1 278 349
get 1 278 349
put 2 278 350
incrementValue 0 277 351
return 1 280 357
assign 1 283 361
new 1 283 361
return 1 283 362
assign 1 285 366
new 1 285 366
return 1 285 367
assign 1 288 379
new 0 288 379
assign 1 288 380
lengthGet 0 288 380
assign 1 288 381
add 1 288 381
assign 1 288 382
new 2 288 382
assign 1 289 383
iteratorGet 0 0 383
assign 1 289 386
hasNextGet 0 289 386
assign 1 289 388
nextGet 0 289 388
addValueWhole 1 290 389
assign 1 292 395
iteratorGet 0 0 395
assign 1 292 398
hasNextGet 0 292 398
assign 1 292 400
nextGet 0 292 400
addValueWhole 1 293 401
return 1 295 407
assign 1 299 411
mergeSort 0 299 411
return 1 299 412
assign 1 303 416
new 0 303 416
sortValue 2 303 417
assign 1 307 431
copy 0 307 431
assign 1 307 434
lesser 1 307 439
assign 1 308 440
copy 0 308 440
assign 1 309 441
copy 0 309 441
assign 1 309 444
lesser 1 309 449
assign 1 310 450
get 1 310 450
assign 1 310 451
get 1 310 451
assign 1 310 452
lesser 1 310 452
assign 1 311 454
copy 0 311 454
incrementValue 0 309 456
assign 1 314 462
get 1 314 462
assign 1 315 463
get 1 315 463
put 2 315 464
put 2 316 465
incrementValue 0 307 466
assign 1 321 489
new 0 321 489
assign 1 322 490
new 0 322 490
assign 1 323 491
new 0 323 491
assign 1 324 492
lengthGet 0 324 492
assign 1 325 493
lengthGet 0 325 493
assign 1 326 496
lesser 1 326 501
assign 1 327 502
lesser 1 327 507
assign 1 327 508
lesser 1 327 513
assign 1 0 514
assign 1 0 517
assign 1 0 521
assign 1 328 524
get 1 328 524
assign 1 329 525
get 1 329 525
assign 1 330 526
lesser 1 330 526
incrementValue 0 331 528
put 2 332 529
incrementValue 0 334 532
put 2 335 533
assign 1 337 537
lesser 1 337 542
assign 1 338 543
get 1 338 543
incrementValue 0 339 544
put 2 340 545
assign 1 341 548
lesser 1 341 553
assign 1 342 554
get 1 342 554
incrementValue 0 343 555
put 2 344 556
incrementValue 0 346 560
assign 1 351 571
new 0 351 571
assign 1 351 572
mergeSort 2 351 572
return 1 351 573
assign 1 355 593
subtract 1 355 593
assign 1 356 594
new 0 356 594
assign 1 356 595
equals 1 356 600
assign 1 357 601
new 0 357 601
assign 1 357 602
create 1 357 602
return 1 357 603
assign 1 358 606
new 0 358 606
assign 1 358 607
equals 1 358 612
assign 1 359 613
new 0 359 613
assign 1 359 614
create 1 359 614
assign 1 360 615
new 0 360 615
assign 1 360 616
get 1 360 616
put 2 360 617
return 1 361 618
assign 1 363 621
new 0 363 621
assign 1 363 622
divide 1 363 622
assign 1 364 623
subtract 1 364 623
assign 1 365 624
add 1 365 624
assign 1 366 625
mergeSort 2 366 625
assign 1 367 626
mergeSort 2 367 626
assign 1 368 627
create 1 368 627
mergeIn 2 369 628
return 1 370 629
assign 1 375 637
new 0 375 637
assign 1 376 639
new 0 376 639
assign 1 376 640
new 1 376 640
throw 1 376 641
assign 1 382 649
greater 1 382 654
assign 1 383 655
multiply 1 383 655
assign 1 399 658
assign 1 402 662
lesser 1 402 667
incrementValue 0 408 670
setValue 1 410 676
assign 1 414 683
def 1 414 688
assign 1 415 691
hasNextGet 0 415 691
assign 1 416 693
nextGet 0 416 693
addValueWhole 1 416 694
assign 1 422 706
def 1 422 711
assign 1 423 712
iteratorGet 0 423 712
iterateAdd 1 423 713
assign 1 428 720
lesser 1 428 725
incrementValue 0 434 728
assign 1 437 731
copy 0 437 731
put 2 437 732
assign 1 442 740
def 1 442 745
assign 1 442 746
sameType 1 442 746
assign 1 0 748
assign 1 0 751
assign 1 0 755
addAll 1 443 758
addValueWhole 1 445 761
assign 1 451 772
new 0 451 772
assign 1 451 775
lesser 1 451 780
assign 1 452 781
get 1 452 781
assign 1 453 782
def 1 453 787
assign 1 453 788
equals 1 453 788
assign 1 0 790
assign 1 0 793
assign 1 0 797
return 1 454 800
incrementValue 0 451 802
return 1 457 808
assign 1 461 815
find 1 461 815
assign 1 461 816
def 1 461 821
assign 1 462 822
new 0 462 822
return 1 462 823
assign 1 464 825
new 0 464 825
return 1 464 826
assign 1 470 831
new 0 470 831
assign 1 470 832
sortedFind 2 470 832
return 1 470 833
assign 1 477 854
assign 1 478 855
new 0 478 855
assign 1 482 858
subtract 1 482 858
assign 1 482 859
new 0 482 859
assign 1 482 860
divide 1 482 860
assign 1 482 861
add 1 482 861
assign 1 483 862
get 1 483 862
assign 1 484 863
equals 1 484 863
return 1 485 865
assign 1 486 868
greater 1 486 868
assign 1 488 870
assign 1 489 873
lesser 1 489 873
assign 1 491 875
assign 1 494 879
def 1 494 884
assign 1 494 885
equals 1 494 890
assign 1 0 891
assign 1 0 894
assign 1 0 898
assign 1 495 902
get 1 495 902
assign 1 495 903
lesser 1 495 903
assign 1 0 905
assign 1 0 908
assign 1 0 912
return 1 496 915
return 1 498 917
assign 1 500 919
assign 1 501 920
new 0 501 920
return 1 502 922
return 1 0 927
return 1 0 930
return 1 0 933
assign 1 0 936
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case -696390158: return bem_capacityGet_0();
case -289190594: return bem_new_0();
case 628114265: return bem_many_0();
case -86198663: return bem_print_0();
case 1606100185: return bem_toAny_0();
case -693169976: return bem_serializeToString_0();
case 468841666: return bem_sourceFileNameGet_0();
case -2143843780: return bem_tagGet_0();
case -457712006: return bem_classNameGet_0();
case 10194441: return bem_clear_0();
case 639073446: return bem_isEmptyGet_0();
case 1523629244: return bem_anyrayGet_0();
case 386499474: return bem_deserializeClassNameGet_0();
case 1110687349: return bem_serializationIteratorGet_0();
case -1284870462: return bem_firstGet_0();
case 781381957: return bem_sortValue_0();
case 820088259: return bem_echo_0();
case -1949106809: return bem_sort_0();
case 154399642: return bem_hashGet_0();
case 380511802: return bem_anyraySet_0();
case -1896702956: return bem_serializeContents_0();
case 402795231: return bem_once_0();
case 1323527258: return bem_copy_0();
case -388275022: return bem_sizeGet_0();
case -817531957: return bem_arrayIteratorGet_0();
case 287808885: return bem_mergeSort_0();
case 2005979069: return bem_lastGet_0();
case -1710921376: return bem_iteratorGet_0();
case -1756988093: return bem_lengthGet_0();
case -285521200: return bem_create_0();
case -1679072038: return bem_toString_0();
case 1829615340: return bem_fieldIteratorGet_0();
case 109846201: return bem_multiplierGet_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 2033308650: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1641155487: return bem_addValueWhole_1(bevd_0);
case 405603043: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759835639: return bem_defined_1(bevd_0);
case -1134002561: return bem_get_1((BEC_2_4_3_MathInt) bevd_0);
case -1110543178: return bem_multiplierSet_1(bevd_0);
case 1958076839: return bem_undefined_1(bevd_0);
case -1579329003: return bem_addValue_1(bevd_0);
case -832964798: return bem_iterateAdd_1(bevd_0);
case 2086659962: return bem_sameObject_1(bevd_0);
case 1519077869: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -1318089914: return bem_add_1((BEC_2_9_4_ContainerList) bevd_0);
case 1253393632: return bem_def_1(bevd_0);
case -1211467604: return bem_copyTo_1(bevd_0);
case -867821369: return bem_delete_1((BEC_2_4_3_MathInt) bevd_0);
case 365385951: return bem_equals_1(bevd_0);
case 2069301731: return bem_has_1(bevd_0);
case -181674326: return bem_sortedFind_1(bevd_0);
case 938569326: return bem_notEquals_1(bevd_0);
case -1624410791: return bem_capacitySet_1((BEC_2_4_3_MathInt) bevd_0);
case -641584584: return bem_sameClass_1(bevd_0);
case -1706185549: return bem_otherType_1(bevd_0);
case -1548733555: return bem_create_1((BEC_2_4_3_MathInt) bevd_0);
case -842795072: return bem_addAll_1(bevd_0);
case 713999383: return bem_undef_1(bevd_0);
case 696413636: return bem_find_1(bevd_0);
case -861317881: return bem_otherClass_1(bevd_0);
case 343567700: return bem_sameType_1(bevd_0);
case -550390334: return bem_lengthSet_1((BEC_2_4_3_MathInt) bevd_0);
case -1770369050: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 823180387: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -2109777534: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -586869174: return bem_new_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -451482527: return bem_sortedFind_2(bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1710398407: return bem_mergeSort_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1389614349: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1125341844: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1064357370: return bem_put_2((BEC_2_4_3_MathInt) bevd_0, bevd_1);
case 832677796: return bem_sortValue_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1447567526: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1790570920: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1812156494: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1299212473: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -143848621: return bem_mergeIn_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerList_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_9_4_ContainerList_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerList();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst = (BEC_2_9_4_ContainerList) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerList.bece_BEC_2_9_4_ContainerList_bevs_inst;
}
}
}
