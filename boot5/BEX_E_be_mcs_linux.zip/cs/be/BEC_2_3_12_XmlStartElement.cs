namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_12_XmlStartElement : BEC_2_3_3_XmlTag {
public BEC_2_3_12_XmlStartElement() { }
static BEC_2_3_12_XmlStartElement() { }
private static byte[] becc_BEC_2_3_12_XmlStartElement_clname = {0x58,0x6D,0x6C,0x3A,0x53,0x74,0x61,0x72,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_3_12_XmlStartElement_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_0 = {0x3C};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_1 = {0x20};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_2 = {0x3D};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_3 = {0x2F,0x3E};
private static byte[] bece_BEC_2_3_12_XmlStartElement_bels_4 = {0x3E};
public static new BEC_2_3_12_XmlStartElement bece_BEC_2_3_12_XmlStartElement_bevs_inst;

public static new BET_2_3_12_XmlStartElement bece_BEC_2_3_12_XmlStartElement_bevs_type;

public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_4_LogicBool bevp_isClosed;
public BEC_2_4_6_TextString bevp_attName;
public BEC_2_9_3_ContainerMap bevp_attributes;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_addAttributeName_1(BEC_2_4_6_TextString beva_pname) {
bevp_attName = beva_pname;
return this;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_addAttributeValue_1(BEC_2_4_6_TextString beva_pval) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_attributes == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 43*/ {
bevp_attributes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
} /* Line: 44*/
bevp_attributes.bem_put_2(bevp_attName, beva_pval);
bevp_attName = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_q = null;
BEC_2_6_6_SystemObject bevl_entry = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_7_TextStrings bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
bevl_accum = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_0));
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevl_accum.bem_addValue_1(bevt_2_ta_ph);
bevt_1_ta_ph.bem_addValue_1(bevp_name);
if (bevp_attributes == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 53*/ {
bevt_4_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_q = bevt_4_ta_ph.bem_quoteGet_0();
bevt_0_ta_loop = bevp_attributes.bem_mapIteratorGet_0();
while (true)
/* Line: 55*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_5_ta_ph.bevi_bool)/* Line: 55*/ {
bevl_entry = bevt_0_ta_loop.bem_nextGet_0();
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_1));
bevt_10_ta_ph = (BEC_2_4_6_TextString) bevl_accum.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevl_entry.bemd_0(-107478848);
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevt_10_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_2));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevt_9_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevl_q);
bevt_14_ta_ph = bevl_entry.bemd_0(-931610053);
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_6_ta_ph.bem_addValue_1(bevl_q);
} /* Line: 56*/
 else /* Line: 55*/ {
break;
} /* Line: 55*/
} /* Line: 55*/
} /* Line: 55*/
if (bevp_isClosed.bevi_bool)/* Line: 59*/ {
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_3_12_XmlStartElement_bels_3));
bevl_accum.bem_addValue_1(bevt_15_ta_ph);
} /* Line: 60*/
 else /* Line: 61*/ {
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_3_12_XmlStartElement_bels_4));
bevl_accum.bem_addValue_1(bevt_16_ta_ph);
} /* Line: 62*/
bevt_17_ta_ph = bevl_accum.bem_extractString_0();
return bevt_17_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isClosedGet_0() {
return bevp_isClosed;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isClosedGetDirect_0() {
return bevp_isClosed;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_isClosedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_isClosedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isClosed = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_attNameGet_0() {
return bevp_attName;
} /*method end*/
public BEC_2_4_6_TextString bem_attNameGetDirect_0() {
return bevp_attName;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_attNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_attName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_attNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_attName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_attributesGet_0() {
return bevp_attributes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_attributesGetDirect_0() {
return bevp_attributes;
} /*method end*/
public virtual BEC_2_3_12_XmlStartElement bem_attributesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_attributes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_3_12_XmlStartElement bem_attributesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_attributes = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {38, 43, 43, 44, 46, 47, 51, 52, 52, 52, 53, 53, 54, 54, 55, 0, 55, 55, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 60, 60, 62, 62, 64, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 30, 35, 36, 38, 39, 64, 65, 66, 67, 68, 73, 74, 75, 76, 76, 79, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 99, 100, 103, 104, 106, 107, 110, 113, 116, 120, 124, 127, 130, 134, 138, 141, 144, 148, 152, 155, 158, 162};
/* BEGIN LINEINFO 
assign 1 38 25
assign 1 43 30
undef 1 43 35
assign 1 44 36
new 0 44 36
put 2 46 38
assign 1 47 39
assign 1 51 64
new 0 51 64
assign 1 52 65
new 0 52 65
assign 1 52 66
addValue 1 52 66
addValue 1 52 67
assign 1 53 68
def 1 53 73
assign 1 54 74
new 0 54 74
assign 1 54 75
quoteGet 0 54 75
assign 1 55 76
mapIteratorGet 0 0 76
assign 1 55 79
hasNextGet 0 55 79
assign 1 55 81
nextGet 0 55 81
assign 1 56 82
new 0 56 82
assign 1 56 83
addValue 1 56 83
assign 1 56 84
keyGet 0 56 84
assign 1 56 85
addValue 1 56 85
assign 1 56 86
new 0 56 86
assign 1 56 87
addValue 1 56 87
assign 1 56 88
addValue 1 56 88
assign 1 56 89
valueGet 0 56 89
assign 1 56 90
addValue 1 56 90
addValue 1 56 91
assign 1 60 99
new 0 60 99
addValue 1 60 100
assign 1 62 103
new 0 62 103
addValue 1 62 104
assign 1 64 106
extractString 0 64 106
return 1 64 107
return 1 0 110
return 1 0 113
assign 1 0 116
assign 1 0 120
return 1 0 124
return 1 0 127
assign 1 0 130
assign 1 0 134
return 1 0 138
return 1 0 141
assign 1 0 144
assign 1 0 148
return 1 0 152
return 1 0 155
assign 1 0 158
assign 1 0 162
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1931705863: return bem_sourceFileNameGet_0();
case -549283499: return bem_attNameGet_0();
case -893093197: return bem_toString_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case 954703233: return bem_create_0();
case 708276900: return bem_nameGetDirect_0();
case 1586815430: return bem_fieldIteratorGet_0();
case -1558569735: return bem_attNameGetDirect_0();
case 1834246217: return bem_classNameGet_0();
case -193582610: return bem_tagGet_0();
case -975498393: return bem_fieldNamesGet_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case -125356968: return bem_isClosedGetDirect_0();
case -859622766: return bem_attributesGetDirect_0();
case 1437514936: return bem_nameGet_0();
case -1737120568: return bem_attributesGet_0();
case -1653939165: return bem_iteratorGet_0();
case -1805795806: return bem_isClosedGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 177409367: return bem_otherType_1(bevd_0);
case -71399638: return bem_addAttributeValue_1((BEC_2_4_6_TextString) bevd_0);
case 1224708572: return bem_isClosedSet_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 1679378772: return bem_attNameSetDirect_1(bevd_0);
case -234688409: return bem_addAttributeName_1((BEC_2_4_6_TextString) bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -375564770: return bem_nameSetDirect_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 745540954: return bem_attributesSetDirect_1(bevd_0);
case 714792787: return bem_isClosedSetDirect_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -82215628: return bem_attNameSet_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 1122223586: return bem_nameSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -525445094: return bem_attributesSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_3_12_XmlStartElement_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_12_XmlStartElement_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_12_XmlStartElement();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_inst = (BEC_2_3_12_XmlStartElement) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_3_12_XmlStartElement.bece_BEC_2_3_12_XmlStartElement_bevs_type;
}
}
}
