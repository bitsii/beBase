namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_6_BuildMtdSyn : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildMtdSyn() { }
static BEC_2_5_6_BuildMtdSyn() { }
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x74,0x64,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildMtdSyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_0 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_2 = {0x6F,0x72,0x67,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_3 = {0x6E,0x75,0x6D,0x61,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_4 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_5 = {0x6C,0x61,0x73,0x74,0x44,0x65,0x66};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_6 = {0x69,0x73,0x46,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_7 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_8 = {0x69,0x73,0x47,0x65,0x6E,0x41,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_9 = {0x72,0x73,0x79,0x6E};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_10 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_6_BuildMtdSyn_bels_11 = {0x61,0x72,0x67,0x54,0x79,0x70,0x65};
public static new BEC_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;

public static new BET_2_5_6_BuildMtdSyn bece_BEC_2_5_6_BuildMtdSyn_bevs_type;

public BEC_2_4_3_MathInt bevp_hpos;
public BEC_2_4_3_MathInt bevp_mtdx;
public BEC_2_4_3_MathInt bevp_numargs;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_4_6_TextString bevp_orgName;
public BEC_2_5_4_LogicBool bevp_isGenAccessor;
public BEC_2_9_4_ContainerList bevp_argSyns;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_5_4_LogicBool bevp_lastDef;
public BEC_2_5_4_LogicBool bevp_isOverride;
public BEC_2_5_4_LogicBool bevp_isFinal;
public BEC_2_4_6_TextString bevp_propertyName;
public BEC_2_5_6_BuildVarSyn bevp_rsyn;
public BEC_2_5_6_BuildMtdSyn bem_new_2(BEC_2_6_6_SystemObject beva_snode, BEC_2_6_6_SystemObject beva__origin) {
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_args = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_6_BuildVarSyn bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
bevl_s = beva_snode.bemd_0(1295480597);
bevp_numargs = (BEC_2_4_3_MathInt) bevl_s.bemd_0(1874137815);
bevp_name = (BEC_2_4_6_TextString) bevl_s.bemd_0(1437514936);
bevp_orgName = (BEC_2_4_6_TextString) bevl_s.bemd_0(354190023);
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(-996645970);
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bevp_numargs.bem_add_1(bevt_1_ta_ph);
bevp_argSyns = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_lastDef = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_isOverride = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_isFinal = (BEC_2_5_4_LogicBool) bevl_s.bemd_0(132875239);
bevt_3_ta_ph = bevl_s.bemd_0(607290372);
if (bevt_3_ta_ph == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 430*/ {
bevt_4_ta_ph = bevl_s.bemd_0(607290372);
bevp_propertyName = (BEC_2_4_6_TextString) bevt_4_ta_ph.bemd_0(1437514936);
} /* Line: 431*/
bevt_6_ta_ph = bevl_s.bemd_0(-2083116175);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 433*/ {
bevt_7_ta_ph = bevl_s.bemd_0(-2083116175);
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_7_ta_ph );
} /* Line: 434*/
bevt_9_ta_ph = beva_snode.bemd_0(1337693140);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1604065800);
bevl_args = bevt_8_ta_ph.bemd_0(1337693140);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 439*/ {
bevt_11_ta_ph = bevp_argSyns.bem_lengthGet_0();
bevt_10_ta_ph = bevl_i.bemd_1(119748808, bevt_11_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_10_ta_ph).bevi_bool)/* Line: 439*/ {
bevt_14_ta_ph = bevl_args.bemd_1(517117201, bevl_i);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(1295480597);
bevt_12_ta_ph = (BEC_2_5_6_BuildVarSyn) (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1((BEC_2_5_3_BuildVar) bevt_13_ta_ph );
bevp_argSyns.bem_put_2((BEC_2_4_3_MathInt) bevl_i , bevt_12_ta_ph);
bevl_i = bevl_i.bemd_0(639017651);
} /* Line: 439*/
 else /* Line: 439*/ {
break;
} /* Line: 439*/
} /* Line: 439*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_arg = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_5_4_LogicBool bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_6_6_SystemObject bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_5_4_LogicBool bevt_46_ta_ph = null;
BEC_2_5_4_LogicBool bevt_47_ta_ph = null;
BEC_2_6_6_SystemObject bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_1_ta_ph.bem_newlineGet_0();
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_0));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_nl);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevl_nl);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevp_name);
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_nl);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_2));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_16_ta_ph);
bevt_7_ta_ph = bevt_8_ta_ph.bem_add_1(bevl_nl);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevp_orgName);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevl_nl);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_3));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_17_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevl_nl);
bevt_18_ta_ph = bevp_numargs.bem_toString_0();
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_18_ta_ph);
bevl_toRet = bevt_2_ta_ph.bem_add_1(bevl_nl);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildMtdSyn_bels_4));
bevt_21_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_22_ta_ph);
bevt_20_ta_ph = bevt_21_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_23_ta_ph = bevp_origin.bem_toString_0();
bevt_19_ta_ph = bevt_20_ta_ph.bemd_1(1007780901, bevt_23_ta_ph);
bevl_toRet = bevt_19_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_5));
bevt_26_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_27_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_28_ta_ph = bevp_lastDef.bem_toString_0();
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(1007780901, bevt_28_ta_ph);
bevl_toRet = bevt_24_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_6));
bevt_31_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_32_ta_ph);
bevt_30_ta_ph = bevt_31_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_33_ta_ph = bevp_isFinal.bem_toString_0();
bevt_29_ta_ph = bevt_30_ta_ph.bemd_1(1007780901, bevt_33_ta_ph);
bevl_toRet = bevt_29_ta_ph.bemd_1(1007780901, bevl_nl);
if (bevp_propertyName == null) {
bevt_34_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_34_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_34_ta_ph.bevi_bool)/* Line: 451*/ {
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_6_BuildMtdSyn_bels_7));
bevt_37_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_38_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_35_ta_ph = bevt_36_ta_ph.bemd_1(1007780901, bevp_propertyName);
bevl_toRet = bevt_35_ta_ph.bemd_1(1007780901, bevl_nl);
} /* Line: 452*/
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_6_BuildMtdSyn_bels_8));
bevt_41_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_42_ta_ph);
bevt_40_ta_ph = bevt_41_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_43_ta_ph = bevp_isGenAccessor.bem_toString_0();
bevt_39_ta_ph = bevt_40_ta_ph.bemd_1(1007780901, bevt_43_ta_ph);
bevl_toRet = bevt_39_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_6_BuildMtdSyn_bels_9));
bevt_44_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_45_ta_ph);
bevl_toRet = bevt_44_ta_ph.bemd_1(1007780901, bevl_nl);
if (bevp_rsyn == null) {
bevt_46_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_46_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_46_ta_ph.bevi_bool)/* Line: 456*/ {
bevt_47_ta_ph = bevp_rsyn.bem_isTypedGet_0();
if (bevt_47_ta_ph.bevi_bool)/* Line: 456*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 456*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 456*/
 else /* Line: 456*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 456*/ {
bevt_50_ta_ph = bevp_rsyn.bem_namepathGet_0();
bevt_49_ta_ph = bevt_50_ta_ph.bem_toString_0();
bevt_48_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_49_ta_ph);
bevl_toRet = bevt_48_ta_ph.bemd_1(1007780901, bevl_nl);
} /* Line: 457*/
 else /* Line: 458*/ {
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_51_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_52_ta_ph);
bevl_toRet = bevt_51_ta_ph.bemd_1(1007780901, bevl_nl);
} /* Line: 459*/
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 461*/ {
bevt_54_ta_ph = bevp_argSyns.bem_lengthGet_0();
bevt_53_ta_ph = bevl_i.bemd_1(119748808, bevt_54_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_53_ta_ph).bevi_bool)/* Line: 461*/ {
bevl_arg = bevp_argSyns.bem_get_1((BEC_2_4_3_MathInt) bevl_i );
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildMtdSyn_bels_11));
bevt_55_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_56_ta_ph);
bevl_toRet = bevt_55_ta_ph.bemd_1(1007780901, bevl_nl);
bevt_57_ta_ph = bevl_arg.bemd_0(-1442766961);
if (((BEC_2_5_4_LogicBool) bevt_57_ta_ph).bevi_bool)/* Line: 465*/ {
bevt_60_ta_ph = bevl_arg.bemd_0(-477657043);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(-893093197);
bevt_58_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_59_ta_ph);
bevl_toRet = bevt_58_ta_ph.bemd_1(1007780901, bevl_nl);
} /* Line: 466*/
 else /* Line: 467*/ {
bevt_62_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildMtdSyn_bels_10));
bevt_61_ta_ph = bevl_toRet.bemd_1(1007780901, bevt_62_ta_ph);
bevl_toRet = bevt_61_ta_ph.bemd_1(1007780901, bevl_nl);
} /* Line: 468*/
bevl_i = bevl_i.bemd_0(639017651);
} /* Line: 461*/
 else /* Line: 461*/ {
break;
} /* Line: 461*/
} /* Line: 461*/
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_getEmitReturnType_2(BEC_2_5_8_BuildClassSyn beva_csyn, BEC_2_5_5_BuildBuild beva_build) {
BEC_2_5_4_LogicBool bevl_covariantReturns = null;
BEC_2_5_10_BuildEmitCommon bevl_ec = null;
BEC_2_5_8_BuildClassSyn bevl_cs = null;
BEC_2_5_6_BuildMtdSyn bevl_ms = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_3_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_7_ta_ph = null;
BEC_2_5_6_BuildVarSyn bevt_8_ta_ph = null;
bevl_covariantReturns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_ec = beva_build.bem_emitCommonGet_0();
if (bevl_ec == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 477*/ {
bevl_covariantReturns = (BEC_2_5_4_LogicBool) bevl_ec.bem_covariantReturnsGet_0();
} /* Line: 478*/
if (bevp_rsyn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 480*/ {
if (bevl_covariantReturns.bevi_bool)/* Line: 481*/ {
bevt_2_ta_ph = bevp_rsyn.bem_isSelfGet_0();
if (bevt_2_ta_ph.bevi_bool)/* Line: 482*/ {
bevt_3_ta_ph = beva_csyn.bem_namepathGet_0();
return bevt_3_ta_ph;
} /* Line: 483*/
 else /* Line: 484*/ {
bevt_4_ta_ph = bevp_rsyn.bem_namepathGet_0();
return bevt_4_ta_ph;
} /* Line: 485*/
} /* Line: 482*/
 else /* Line: 487*/ {
bevt_5_ta_ph = bevp_rsyn.bem_isSelfGet_0();
if (bevt_5_ta_ph.bevi_bool)/* Line: 488*/ {
return bevp_declaration;
} /* Line: 489*/
 else /* Line: 490*/ {
bevl_cs = beva_build.bem_getSynNp_1(bevp_declaration);
bevt_6_ta_ph = bevl_cs.bem_mtdMapGet_0();
bevl_ms = (BEC_2_5_6_BuildMtdSyn) bevt_6_ta_ph.bem_get_1(bevp_name);
bevt_8_ta_ph = bevl_ms.bem_rsynGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_namepathGet_0();
return bevt_7_ta_ph;
} /* Line: 493*/
} /* Line: 488*/
} /* Line: 481*/
return null;
} /*method end*/
public BEC_2_4_3_MathInt bem_hposGet_0() {
return bevp_hpos;
} /*method end*/
public BEC_2_4_3_MathInt bem_hposGetDirect_0() {
return bevp_hpos;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_hposSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_hposSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_hpos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxGet_0() {
return bevp_mtdx;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxGetDirect_0() {
return bevp_mtdx;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_mtdxSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_mtdxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mtdx = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGet_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_4_3_MathInt bem_numargsGetDirect_0() {
return bevp_numargs;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_numargsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_numargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_numargs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGet_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_4_6_TextString bem_orgNameGetDirect_0() {
return bevp_orgName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_orgNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_orgNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_orgName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGet_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isGenAccessorGetDirect_0() {
return bevp_isGenAccessor;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isGenAccessorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isGenAccessor = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argSynsGet_0() {
return bevp_argSyns;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argSynsGetDirect_0() {
return bevp_argSyns;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_argSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_argSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_argSyns = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGetDirect_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_originSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() {
return bevp_declaration;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGetDirect_0() {
return bevp_declaration;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_declarationSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lastDefGet_0() {
return bevp_lastDef;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lastDefGetDirect_0() {
return bevp_lastDef;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_lastDefSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_lastDefSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lastDef = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOverrideGet_0() {
return bevp_isOverride;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isOverrideGetDirect_0() {
return bevp_isOverride;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isOverrideSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isOverrideSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isOverride = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGet_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isFinalGetDirect_0() {
return bevp_isFinal;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isFinalSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_isFinalSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_isFinal = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_propertyNameGet_0() {
return bevp_propertyName;
} /*method end*/
public BEC_2_4_6_TextString bem_propertyNameGetDirect_0() {
return bevp_propertyName;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_propertyNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_propertyNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_propertyName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_rsynGet_0() {
return bevp_rsyn;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_rsynGetDirect_0() {
return bevp_rsyn;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_rsynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_rsynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_rsyn = (BEC_2_5_6_BuildVarSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {413, 419, 420, 421, 422, 423, 423, 423, 425, 427, 428, 429, 430, 430, 430, 431, 431, 433, 433, 433, 434, 434, 438, 438, 438, 439, 439, 439, 440, 440, 440, 440, 439, 446, 446, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 447, 448, 448, 448, 448, 448, 448, 449, 449, 449, 449, 449, 449, 450, 450, 450, 450, 450, 450, 451, 451, 452, 452, 452, 452, 452, 454, 454, 454, 454, 454, 454, 455, 455, 455, 456, 456, 456, 0, 0, 0, 457, 457, 457, 457, 459, 459, 459, 461, 461, 461, 462, 464, 464, 464, 465, 466, 466, 466, 466, 468, 468, 468, 461, 471, 475, 476, 477, 477, 478, 480, 480, 482, 483, 483, 485, 485, 488, 489, 491, 492, 492, 493, 493, 493, 497, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 75, 76, 77, 79, 80, 85, 86, 87, 89, 90, 91, 92, 95, 96, 98, 99, 100, 101, 102, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 221, 222, 223, 224, 225, 226, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 242, 243, 245, 248, 252, 255, 256, 257, 258, 261, 262, 263, 265, 268, 269, 271, 272, 273, 274, 275, 277, 278, 279, 280, 283, 284, 285, 287, 293, 309, 310, 311, 316, 317, 319, 324, 326, 328, 329, 332, 333, 337, 339, 342, 343, 344, 345, 346, 347, 351, 354, 357, 360, 364, 368, 371, 374, 378, 382, 385, 388, 392, 396, 399, 402, 406, 410, 413, 416, 420, 424, 427, 430, 434, 438, 441, 444, 448, 452, 455, 458, 462, 466, 469, 472, 476, 480, 483, 486, 490, 494, 497, 500, 504, 508, 511, 514, 518, 522, 525, 528, 532, 536, 539, 542, 546};
/* BEGIN LINEINFO 
assign 1 413 57
heldGet 0 413 57
assign 1 419 58
numargsGet 0 419 58
assign 1 420 59
nameGet 0 420 59
assign 1 421 60
orgNameGet 0 421 60
assign 1 422 61
isGenAccessorGet 0 422 61
assign 1 423 62
new 0 423 62
assign 1 423 63
add 1 423 63
assign 1 423 64
new 1 423 64
assign 1 425 65
assign 1 427 66
new 0 427 66
assign 1 428 67
new 0 428 67
assign 1 429 68
isFinalGet 0 429 68
assign 1 430 69
propertyGet 0 430 69
assign 1 430 70
def 1 430 75
assign 1 431 76
propertyGet 0 431 76
assign 1 431 77
nameGet 0 431 77
assign 1 433 79
rtypeGet 0 433 79
assign 1 433 80
def 1 433 85
assign 1 434 86
rtypeGet 0 434 86
assign 1 434 87
anyNew 1 434 87
assign 1 438 89
containedGet 0 438 89
assign 1 438 90
firstGet 0 438 90
assign 1 438 91
containedGet 0 438 91
assign 1 439 92
new 0 439 92
assign 1 439 95
lengthGet 0 439 95
assign 1 439 96
lesser 1 439 96
assign 1 440 98
get 1 440 98
assign 1 440 99
heldGet 0 440 99
assign 1 440 100
anyNew 1 440 100
put 2 440 101
assign 1 439 102
increment 0 439 102
assign 1 446 178
new 0 446 178
assign 1 446 179
newlineGet 0 446 179
assign 1 447 180
new 0 447 180
assign 1 447 181
add 1 447 181
assign 1 447 182
new 0 447 182
assign 1 447 183
add 1 447 183
assign 1 447 184
add 1 447 184
assign 1 447 185
add 1 447 185
assign 1 447 186
add 1 447 186
assign 1 447 187
new 0 447 187
assign 1 447 188
add 1 447 188
assign 1 447 189
add 1 447 189
assign 1 447 190
add 1 447 190
assign 1 447 191
add 1 447 191
assign 1 447 192
new 0 447 192
assign 1 447 193
add 1 447 193
assign 1 447 194
add 1 447 194
assign 1 447 195
toString 0 447 195
assign 1 447 196
add 1 447 196
assign 1 447 197
add 1 447 197
assign 1 448 198
new 0 448 198
assign 1 448 199
add 1 448 199
assign 1 448 200
add 1 448 200
assign 1 448 201
toString 0 448 201
assign 1 448 202
add 1 448 202
assign 1 448 203
add 1 448 203
assign 1 449 204
new 0 449 204
assign 1 449 205
add 1 449 205
assign 1 449 206
add 1 449 206
assign 1 449 207
toString 0 449 207
assign 1 449 208
add 1 449 208
assign 1 449 209
add 1 449 209
assign 1 450 210
new 0 450 210
assign 1 450 211
add 1 450 211
assign 1 450 212
add 1 450 212
assign 1 450 213
toString 0 450 213
assign 1 450 214
add 1 450 214
assign 1 450 215
add 1 450 215
assign 1 451 216
def 1 451 221
assign 1 452 222
new 0 452 222
assign 1 452 223
add 1 452 223
assign 1 452 224
add 1 452 224
assign 1 452 225
add 1 452 225
assign 1 452 226
add 1 452 226
assign 1 454 228
new 0 454 228
assign 1 454 229
add 1 454 229
assign 1 454 230
add 1 454 230
assign 1 454 231
toString 0 454 231
assign 1 454 232
add 1 454 232
assign 1 454 233
add 1 454 233
assign 1 455 234
new 0 455 234
assign 1 455 235
add 1 455 235
assign 1 455 236
add 1 455 236
assign 1 456 237
def 1 456 242
assign 1 456 243
isTypedGet 0 456 243
assign 1 0 245
assign 1 0 248
assign 1 0 252
assign 1 457 255
namepathGet 0 457 255
assign 1 457 256
toString 0 457 256
assign 1 457 257
add 1 457 257
assign 1 457 258
add 1 457 258
assign 1 459 261
new 0 459 261
assign 1 459 262
add 1 459 262
assign 1 459 263
add 1 459 263
assign 1 461 265
new 0 461 265
assign 1 461 268
lengthGet 0 461 268
assign 1 461 269
lesser 1 461 269
assign 1 462 271
get 1 462 271
assign 1 464 272
new 0 464 272
assign 1 464 273
add 1 464 273
assign 1 464 274
add 1 464 274
assign 1 465 275
isTypedGet 0 465 275
assign 1 466 277
namepathGet 0 466 277
assign 1 466 278
toString 0 466 278
assign 1 466 279
add 1 466 279
assign 1 466 280
add 1 466 280
assign 1 468 283
new 0 468 283
assign 1 468 284
add 1 468 284
assign 1 468 285
add 1 468 285
assign 1 461 287
increment 0 461 287
return 1 471 293
assign 1 475 309
new 0 475 309
assign 1 476 310
emitCommonGet 0 476 310
assign 1 477 311
def 1 477 316
assign 1 478 317
covariantReturnsGet 0 478 317
assign 1 480 319
def 1 480 324
assign 1 482 326
isSelfGet 0 482 326
assign 1 483 328
namepathGet 0 483 328
return 1 483 329
assign 1 485 332
namepathGet 0 485 332
return 1 485 333
assign 1 488 337
isSelfGet 0 488 337
return 1 489 339
assign 1 491 342
getSynNp 1 491 342
assign 1 492 343
mtdMapGet 0 492 343
assign 1 492 344
get 1 492 344
assign 1 493 345
rsynGet 0 493 345
assign 1 493 346
namepathGet 0 493 346
return 1 493 347
return 1 497 351
return 1 0 354
return 1 0 357
assign 1 0 360
assign 1 0 364
return 1 0 368
return 1 0 371
assign 1 0 374
assign 1 0 378
return 1 0 382
return 1 0 385
assign 1 0 388
assign 1 0 392
return 1 0 396
return 1 0 399
assign 1 0 402
assign 1 0 406
return 1 0 410
return 1 0 413
assign 1 0 416
assign 1 0 420
return 1 0 424
return 1 0 427
assign 1 0 430
assign 1 0 434
return 1 0 438
return 1 0 441
assign 1 0 444
assign 1 0 448
return 1 0 452
return 1 0 455
assign 1 0 458
assign 1 0 462
return 1 0 466
return 1 0 469
assign 1 0 472
assign 1 0 476
return 1 0 480
return 1 0 483
assign 1 0 486
assign 1 0 490
return 1 0 494
return 1 0 497
assign 1 0 500
assign 1 0 504
return 1 0 508
return 1 0 511
assign 1 0 514
assign 1 0 518
return 1 0 522
return 1 0 525
assign 1 0 528
assign 1 0 532
return 1 0 536
return 1 0 539
assign 1 0 542
assign 1 0 546
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -979560696: return bem_isOverrideGet_0();
case -306519519: return bem_originGet_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 1352847619: return bem_numargsGetDirect_0();
case -1867298773: return bem_propertyNameGetDirect_0();
case 1490984682: return bem_rsynGet_0();
case 695105372: return bem_mtdxGetDirect_0();
case 1385711873: return bem_declarationGetDirect_0();
case -1076915155: return bem_serializeToString_0();
case 623427500: return bem_mtdxGet_0();
case 1834246217: return bem_classNameGet_0();
case 1568546408: return bem_isFinalGetDirect_0();
case 946360922: return bem_serializationIteratorGet_0();
case 354190023: return bem_orgNameGet_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case 708276900: return bem_nameGetDirect_0();
case -220474227: return bem_propertyNameGet_0();
case 1646363444: return bem_orgNameGetDirect_0();
case 141483779: return bem_lastDefGet_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 33210593: return bem_rsynGetDirect_0();
case 1874137815: return bem_numargsGet_0();
case -823181020: return bem_hposGetDirect_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case 132875239: return bem_isFinalGet_0();
case -996645970: return bem_isGenAccessorGet_0();
case 2081363871: return bem_copy_0();
case 784385738: return bem_declarationGet_0();
case -975498393: return bem_fieldNamesGet_0();
case 247108096: return bem_argSynsGetDirect_0();
case -1240361950: return bem_lastDefGetDirect_0();
case -610815253: return bem_isGenAccessorGetDirect_0();
case 954703233: return bem_create_0();
case -674003069: return bem_hposGet_0();
case -893093197: return bem_toString_0();
case -250349353: return bem_argSynsGet_0();
case 1437514936: return bem_nameGet_0();
case -1511976652: return bem_isOverrideGetDirect_0();
case 1385648890: return bem_originGetDirect_0();
case -40905183: return bem_echo_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1907922049: return bem_propertyNameSetDirect_1(bevd_0);
case -256404490: return bem_mtdxSet_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -632586837: return bem_orgNameSetDirect_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -1622242013: return bem_isOverrideSetDirect_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -1139568418: return bem_isFinalSetDirect_1(bevd_0);
case 380030451: return bem_declarationSet_1(bevd_0);
case -936437813: return bem_isOverrideSet_1(bevd_0);
case 265692731: return bem_numargsSetDirect_1(bevd_0);
case 137800965: return bem_orgNameSet_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -2069384904: return bem_rsynSet_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 91784145: return bem_argSynsSetDirect_1(bevd_0);
case 1017945681: return bem_originSetDirect_1(bevd_0);
case -336487962: return bem_numargsSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -375564770: return bem_nameSetDirect_1(bevd_0);
case 1122223586: return bem_nameSet_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -1204002553: return bem_argSynsSet_1(bevd_0);
case -157630972: return bem_hposSetDirect_1(bevd_0);
case -657685760: return bem_lastDefSetDirect_1(bevd_0);
case -484149632: return bem_rsynSetDirect_1(bevd_0);
case -2036468099: return bem_propertyNameSet_1(bevd_0);
case -439370053: return bem_isGenAccessorSetDirect_1(bevd_0);
case -48080773: return bem_originSet_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -1940110991: return bem_lastDefSet_1(bevd_0);
case 102688656: return bem_mtdxSetDirect_1(bevd_0);
case 1499672216: return bem_isFinalSet_1(bevd_0);
case -1660525791: return bem_declarationSetDirect_1(bevd_0);
case -401220259: return bem_isGenAccessorSet_1(bevd_0);
case 1026130346: return bem_hposSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1211180379: return bem_getEmitReturnType_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_5_BuildBuild) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1912872286: return bem_new_2(bevd_0, bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildMtdSyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildMtdSyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildMtdSyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst = (BEC_2_5_6_BuildMtdSyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_6_BuildMtdSyn.bece_BEC_2_5_6_BuildMtdSyn_bevs_type;
}
}
}
