namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_10_JsonMarshaller : BEC_2_6_6_SystemObject {
public BEC_2_4_10_JsonMarshaller() { }
static BEC_2_4_10_JsonMarshaller() { }
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x4D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_1 = {0x31,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_1 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_2 = {0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_2 = (new BEC_2_4_3_MathInt(4));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_3 = {0x37};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_4 = {0x33,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_5 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_7 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_6 = {0x5C,0x75};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_9 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_10 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_11 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_12 = (new BEC_2_4_3_MathInt(87));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_13 = (new BEC_2_4_3_MathInt(13));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_7 = {0x31,0x30,0x30,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_8 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_9 = {0x66,0x66,0x63,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_10 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_11 = {0x30,0x30,0x33,0x66,0x66};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_12 = {0x5C,0x75};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_14 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_15 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_16 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_17 = (new BEC_2_4_3_MathInt(87));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_13 = {0x5C,0x75};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_18 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_19 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_20 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_21 = (new BEC_2_4_3_MathInt(87));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_14 = {0x5B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_15 = {0x2C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_16 = {0x5D};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_17 = {0x7B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_18 = {0x2C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_19 = {0x3A};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_20 = {0x7D};
public static new BEC_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_inst;

public static new BET_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_9_4_ContainerList bevp_arr;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_boo;
public BEC_2_4_6_TextString bevp_q;
public BEC_2_4_17_TextMultiByteIterator bevp_mbi;
public BEC_2_4_6_TextString bevp_txtpt;
public BEC_2_4_6_TextString bevp_escaped;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevp_str = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_arr = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_tmpany_phold);
bevp_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_int = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_boo = (BEC_2_5_4_LogicBool) (new BEC_2_5_4_LogicBool()).bem_new_0();
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_q = bevt_1_tmpany_phold.bem_quoteGet_0();
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_0();
bevp_txtpt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_escaped = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_marshall_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_4_6_TextString bevl_bb = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevp_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 311 */ {
bem_new_0();
} /* Line: 312 */
bevl_bb = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_marshallWriteInst_2(beva_inst, bevl_bb);
bevt_1_tmpany_phold = bevl_bb.bem_toString_0();
return bevt_1_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWrite_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_str == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 320 */ {
bem_new_0();
} /* Line: 321 */
bem_marshallWriteInst_2(beva_inst, beva_writer);
return this;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWriteInst_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
if (beva_inst == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 327 */ {
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_0));
beva_writer.bemd_1(1011429241, bevt_1_tmpany_phold);
} /* Line: 328 */
 else  /* Line: 327 */ {
bevt_2_tmpany_phold = beva_inst.bemd_1(-1672211684, bevp_str);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 329 */ {
bem_marshallWriteString_2((BEC_2_4_6_TextString) beva_inst , beva_writer);
} /* Line: 330 */
 else  /* Line: 327 */ {
bevt_3_tmpany_phold = beva_inst.bemd_1(-1672211684, bevp_arr);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 331 */ {
bem_marshallWriteList_2(beva_inst, beva_writer);
} /* Line: 332 */
 else  /* Line: 327 */ {
bevt_4_tmpany_phold = beva_inst.bemd_1(-1672211684, bevp_map);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 333 */ {
bem_marshallWriteMap_2(beva_inst, beva_writer);
} /* Line: 334 */
 else  /* Line: 327 */ {
bevt_5_tmpany_phold = beva_inst.bemd_1(-1672211684, bevp_int);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 335 */ {
bevt_6_tmpany_phold = beva_inst.bemd_0(80244442);
beva_writer.bemd_1(1011429241, bevt_6_tmpany_phold);
} /* Line: 336 */
 else  /* Line: 327 */ {
bevt_7_tmpany_phold = beva_inst.bemd_1(-1672211684, bevp_boo);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 337 */ {
bevt_8_tmpany_phold = beva_inst.bemd_0(80244442);
beva_writer.bemd_1(1011429241, bevt_8_tmpany_phold);
} /* Line: 338 */
 else  /* Line: 339 */ {
bevt_9_tmpany_phold = beva_inst.bemd_0(80244442);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_9_tmpany_phold , beva_writer);
} /* Line: 340 */
} /* Line: 327 */
} /* Line: 327 */
} /* Line: 327 */
} /* Line: 327 */
} /* Line: 327 */
return this;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_jsonEscapePoint_2(BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_txt) {
BEC_2_4_3_MathInt bevl_rcap = null;
BEC_2_4_3_MathInt bevl_txtsznow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_u = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_7_JsonEscapes bevl_esc = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_first = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_35_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_txtsznow = beva_txt.bem_sizeGet_0();
bevl_size = beva_txtpt.bem_sizeGet_0();
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_u = beva_txtpt.bem_getInt_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_0;
if (bevl_size.bevi_int == bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 353 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_1));
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_5_tmpany_phold);
bevl_value = bevl_u.bem_and_1(bevt_4_tmpany_phold);
} /* Line: 354 */
 else  /* Line: 352 */ {
bevt_7_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_1;
if (bevl_size.bevi_int == bevt_7_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_2));
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_9_tmpany_phold);
bevl_value = bevl_u.bem_and_1(bevt_8_tmpany_phold);
} /* Line: 358 */
 else  /* Line: 352 */ {
bevt_11_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_2;
if (bevl_size.bevi_int == bevt_11_tmpany_phold.bevi_int) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 361 */ {
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_3));
bevt_12_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_13_tmpany_phold);
bevl_value = bevl_u.bem_and_1(bevt_12_tmpany_phold);
} /* Line: 362 */
} /* Line: 352 */
} /* Line: 352 */
bevt_15_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_3;
if (bevl_size.bevi_int > bevt_15_tmpany_phold.bevi_int) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 364 */ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 365 */ {
if (bevl_i.bevi_int < bevl_size.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 366 */ {
beva_txtpt.bem_getInt_2(bevl_i, bevl_u);
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_17_tmpany_phold = bevl_value.bem_shiftLeft_1(bevt_18_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_4));
bevt_20_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_21_tmpany_phold);
bevt_19_tmpany_phold = bevl_u.bem_and_1(bevt_20_tmpany_phold);
bevl_value = bevt_17_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 365 */
 else  /* Line: 365 */ {
break;
} /* Line: 365 */
} /* Line: 365 */
} /* Line: 365 */
bevt_23_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_4;
if (bevl_size.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 372 */ {
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 373 */
 else  /* Line: 372 */ {
bevt_25_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_5;
if (bevl_size.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 374 */ {
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 375 */
 else  /* Line: 376 */ {
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_28_tmpany_phold);
if (bevl_value.bevi_int < bevt_27_tmpany_phold.bevi_int) {
bevt_26_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_26_tmpany_phold.bevi_bool) /* Line: 377 */ {
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
} /* Line: 378 */
 else  /* Line: 379 */ {
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
} /* Line: 380 */
} /* Line: 377 */
} /* Line: 372 */
bevt_31_tmpany_phold = beva_txt.bem_capacityGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_subtract_1(bevl_txtsznow);
if (bevt_30_tmpany_phold.bevi_int < bevl_rcap.bevi_int) {
bevt_29_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_29_tmpany_phold.bevi_bool) /* Line: 384 */ {
bevt_32_tmpany_phold = bevl_txtsznow.bem_add_1(bevl_rcap);
beva_txt.bem_capacitySet_1(bevt_32_tmpany_phold);
} /* Line: 385 */
bevt_34_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_6;
if (bevl_rcap.bevi_int == bevt_34_tmpany_phold.bevi_int) {
bevt_33_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_33_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_33_tmpany_phold.bevi_bool) /* Line: 388 */ {
bevl_esc = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevt_35_tmpany_phold = bevl_esc.bem_toEscapesGet_0();
bevl_escval = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_get_1(beva_txtpt);
if (bevl_escval == null) {
bevt_36_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_36_tmpany_phold.bevi_bool) /* Line: 392 */ {
beva_txt.bem_addValue_1(bevl_escval);
} /* Line: 393 */
 else  /* Line: 394 */ {
beva_txt.bem_addValue_1(beva_txtpt);
} /* Line: 396 */
} /* Line: 392 */
 else  /* Line: 388 */ {
bevt_38_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_7;
if (bevl_rcap.bevi_int > bevt_38_tmpany_phold.bevi_int) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 398 */ {
bevt_40_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_8;
if (bevl_rcap.bevi_int == bevt_40_tmpany_phold.bevi_int) {
bevt_39_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_39_tmpany_phold.bevi_bool) /* Line: 399 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) beva_txt.bem_addValue_1(bevt_42_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_9;
bevt_45_tmpany_phold = (BEC_2_4_3_MathInt) bevt_46_tmpany_phold.bem_once_0();
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_10;
bevt_47_tmpany_phold = (BEC_2_4_3_MathInt) bevt_48_tmpany_phold.bem_once_0();
bevt_50_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_11;
bevt_49_tmpany_phold = (BEC_2_4_3_MathInt) bevt_50_tmpany_phold.bem_once_0();
bevt_52_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_12;
bevt_51_tmpany_phold = (BEC_2_4_3_MathInt) bevt_52_tmpany_phold.bem_once_0();
bevt_43_tmpany_phold = bevl_value.bem_toString_4(bevt_44_tmpany_phold, bevt_47_tmpany_phold, bevt_49_tmpany_phold, bevt_51_tmpany_phold);
bevt_41_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
} /* Line: 400 */
 else  /* Line: 399 */ {
bevt_54_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_13;
if (bevl_rcap.bevi_int == bevt_54_tmpany_phold.bevi_int) {
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpany_phold.bevi_bool) /* Line: 401 */ {
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_7));
bevt_55_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_56_tmpany_phold);
bevl_value.bem_subtractValue_1(bevt_55_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_8));
bevt_57_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_58_tmpany_phold);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_9));
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_tmpany_phold);
bevt_60_tmpany_phold = bevl_value.bem_and_1(bevt_61_tmpany_phold);
bevt_63_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bem_shiftRight_1(bevt_63_tmpany_phold);
bevl_first = bevt_57_tmpany_phold.bem_or_1(bevt_59_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_10));
bevt_64_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_tmpany_phold);
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_11));
bevt_67_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_tmpany_phold);
bevt_66_tmpany_phold = bevl_value.bem_and_1(bevt_67_tmpany_phold);
bevl_last = bevt_64_tmpany_phold.bem_or_1(bevt_66_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_12));
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) beva_txt.bem_addValue_1(bevt_70_tmpany_phold);
bevt_74_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_14;
bevt_73_tmpany_phold = (BEC_2_4_3_MathInt) bevt_74_tmpany_phold.bem_once_0();
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_73_tmpany_phold);
bevt_76_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_15;
bevt_75_tmpany_phold = (BEC_2_4_3_MathInt) bevt_76_tmpany_phold.bem_once_0();
bevt_78_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_16;
bevt_77_tmpany_phold = (BEC_2_4_3_MathInt) bevt_78_tmpany_phold.bem_once_0();
bevt_80_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_17;
bevt_79_tmpany_phold = (BEC_2_4_3_MathInt) bevt_80_tmpany_phold.bem_once_0();
bevt_71_tmpany_phold = bevl_first.bem_toString_4(bevt_72_tmpany_phold, bevt_75_tmpany_phold, bevt_77_tmpany_phold, bevt_79_tmpany_phold);
bevt_69_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_13));
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) beva_txt.bem_addValue_1(bevt_82_tmpany_phold);
bevt_86_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_18;
bevt_85_tmpany_phold = (BEC_2_4_3_MathInt) bevt_86_tmpany_phold.bem_once_0();
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_85_tmpany_phold);
bevt_88_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_19;
bevt_87_tmpany_phold = (BEC_2_4_3_MathInt) bevt_88_tmpany_phold.bem_once_0();
bevt_90_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_20;
bevt_89_tmpany_phold = (BEC_2_4_3_MathInt) bevt_90_tmpany_phold.bem_once_0();
bevt_92_tmpany_phold = bece_BEC_2_4_10_JsonMarshaller_bevo_21;
bevt_91_tmpany_phold = (BEC_2_4_3_MathInt) bevt_92_tmpany_phold.bem_once_0();
bevt_83_tmpany_phold = bevl_last.bem_toString_4(bevt_84_tmpany_phold, bevt_87_tmpany_phold, bevt_89_tmpany_phold, bevt_91_tmpany_phold);
bevt_81_tmpany_phold.bem_addValue_1(bevt_83_tmpany_phold);
} /* Line: 406 */
} /* Line: 399 */
} /* Line: 399 */
} /* Line: 388 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_jsonEscape_1(BEC_2_6_6_SystemObject beva_toEscape) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_tmpany_phold = null;
bevp_escaped.bem_clear_0();
bevt_1_tmpany_phold = (BEC_2_4_17_TextMultiByteIterator) bevp_mbi.bem_new_1((BEC_2_4_6_TextString) beva_toEscape );
bevt_0_tmpany_phold = bem_jsonEscape_3(bevt_1_tmpany_phold, bevp_txtpt, bevp_escaped);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_jsonEscape_3(BEC_2_4_17_TextMultiByteIterator beva_mbi, BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_escaped) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
while (true)
 /* Line: 417 */ {
bevt_0_tmpany_phold = beva_mbi.bem_hasNextGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 417 */ {
beva_mbi.bem_next_1(beva_txtpt);
bem_jsonEscapePoint_2(beva_txtpt, beva_escaped);
} /* Line: 419 */
 else  /* Line: 417 */ {
break;
} /* Line: 417 */
} /* Line: 417 */
return beva_escaped;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWriteString_2(BEC_2_4_6_TextString beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
beva_writer.bemd_1(1011429241, bevp_q);
bevt_0_tmpany_phold = bem_jsonEscape_1(beva_inst);
beva_writer.bemd_1(1011429241, bevt_0_tmpany_phold);
beva_writer.bemd_1(1011429241, bevp_q);
return this;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWriteList_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_instin = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_14));
beva_writer.bemd_1(1011429241, bevt_1_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = beva_inst.bemd_0(-2131387379);
while (true)
 /* Line: 433 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-816433081);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 433 */ {
bevl_instin = bevt_0_tmpany_loop.bemd_0(-1186092044);
if (bevl_first.bevi_bool) /* Line: 434 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 435 */
 else  /* Line: 436 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_15));
beva_writer.bemd_1(1011429241, bevt_3_tmpany_phold);
} /* Line: 437 */
bem_marshallWriteInst_2(bevl_instin, beva_writer);
} /* Line: 439 */
 else  /* Line: 433 */ {
break;
} /* Line: 433 */
} /* Line: 433 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_16));
beva_writer.bemd_1(1011429241, bevt_4_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWriteMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_17));
beva_writer.bemd_1(1011429241, bevt_1_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = beva_inst.bemd_0(-2131387379);
while (true)
 /* Line: 447 */ {
bevt_2_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-816433081);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 447 */ {
bevl_kv = bevt_0_tmpany_loop.bemd_0(-1186092044);
if (bevl_first.bevi_bool) /* Line: 449 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 450 */
 else  /* Line: 451 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_18));
beva_writer.bemd_1(1011429241, bevt_3_tmpany_phold);
} /* Line: 452 */
bevt_4_tmpany_phold = bevl_kv.bemd_0(-788058669);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_4_tmpany_phold , beva_writer);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_19));
beva_writer.bemd_1(1011429241, bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bevl_kv.bemd_0(2012519740);
bem_marshallWriteInst_2(bevt_6_tmpany_phold, beva_writer);
} /* Line: 456 */
 else  /* Line: 447 */ {
break;
} /* Line: 447 */
} /* Line: 447 */
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_20));
beva_writer.bemd_1(1011429241, bevt_7_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGetDirect_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_arrGet_0() {
return bevp_arr;
} /*method end*/
public BEC_2_9_4_ContainerList bem_arrGetDirect_0() {
return bevp_arr;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_arrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_arrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_mapGet_0() {
return bevp_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGetDirect_0() {
return bevp_map;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGetDirect_0() {
return bevp_int;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_booGet_0() {
return bevp_boo;
} /*method end*/
public BEC_2_5_4_LogicBool bem_booGetDirect_0() {
return bevp_boo;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_booSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_booSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_qGet_0() {
return bevp_q;
} /*method end*/
public BEC_2_4_6_TextString bem_qGetDirect_0() {
return bevp_q;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_qSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_q = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_qSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_q = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_17_TextMultiByteIterator bem_mbiGet_0() {
return bevp_mbi;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiGetDirect_0() {
return bevp_mbi;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_mbiSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mbiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_txtptGet_0() {
return bevp_txtpt;
} /*method end*/
public BEC_2_4_6_TextString bem_txtptGetDirect_0() {
return bevp_txtpt;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_txtptSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_txtptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_escapedGet_0() {
return bevp_escaped;
} /*method end*/
public BEC_2_4_6_TextString bem_escapedGetDirect_0() {
return bevp_escaped;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_escapedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_escapedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {292, 294, 294, 296, 298, 300, 302, 302, 304, 305, 306, 311, 311, 312, 314, 315, 316, 316, 320, 320, 321, 323, 327, 327, 328, 328, 329, 330, 331, 332, 333, 334, 335, 336, 336, 337, 338, 338, 340, 340, 345, 346, 348, 351, 351, 351, 352, 352, 352, 354, 354, 354, 356, 356, 356, 358, 358, 358, 360, 360, 360, 362, 362, 362, 364, 364, 364, 365, 365, 365, 367, 369, 369, 369, 369, 369, 369, 365, 372, 372, 372, 373, 374, 374, 374, 375, 377, 377, 377, 377, 378, 380, 384, 384, 384, 384, 385, 385, 388, 388, 388, 390, 391, 391, 392, 392, 393, 396, 398, 398, 398, 399, 399, 399, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 400, 401, 401, 401, 402, 402, 402, 403, 403, 403, 403, 403, 403, 403, 403, 404, 404, 404, 404, 404, 404, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 406, 406, 406, 406, 406, 406, 406, 406, 406, 406, 406, 406, 406, 412, 413, 413, 413, 417, 418, 419, 421, 425, 426, 426, 427, 431, 431, 432, 433, 0, 433, 433, 435, 437, 437, 439, 441, 441, 445, 445, 446, 447, 0, 447, 447, 450, 452, 452, 454, 454, 455, 455, 456, 456, 458, 458, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 84, 89, 90, 92, 93, 94, 95, 99, 104, 105, 107, 121, 126, 127, 128, 131, 133, 136, 138, 141, 143, 146, 148, 149, 152, 154, 155, 158, 159, 272, 273, 274, 275, 276, 277, 278, 279, 284, 285, 286, 287, 290, 291, 296, 297, 298, 299, 302, 303, 308, 309, 310, 311, 315, 316, 321, 322, 325, 330, 331, 332, 333, 334, 335, 336, 337, 338, 345, 346, 351, 352, 355, 356, 361, 362, 365, 366, 367, 372, 373, 376, 380, 381, 382, 387, 388, 389, 391, 392, 397, 398, 399, 400, 401, 406, 407, 410, 414, 415, 420, 421, 422, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 443, 444, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 502, 503, 504, 505, 511, 513, 514, 520, 524, 525, 526, 527, 538, 539, 540, 541, 541, 544, 546, 548, 551, 552, 554, 560, 561, 575, 576, 577, 578, 578, 581, 583, 585, 588, 589, 591, 592, 593, 594, 595, 596, 602, 603, 607, 610, 613, 617, 621, 624, 627, 631, 635, 638, 641, 645, 649, 652, 655, 659, 663, 666, 669, 673, 677, 680, 683, 687, 691, 694, 697, 701, 705, 708, 711, 715, 719, 722, 725, 729};
/* BEGIN LINEINFO 
assign 1 292 67
new 0 292 67
assign 1 294 68
new 0 294 68
assign 1 294 69
new 1 294 69
assign 1 296 70
new 0 296 70
assign 1 298 71
new 0 298 71
assign 1 300 72
new 0 300 72
assign 1 302 73
new 0 302 73
assign 1 302 74
quoteGet 0 302 74
assign 1 304 75
new 0 304 75
assign 1 305 76
new 0 305 76
assign 1 306 77
new 0 306 77
assign 1 311 84
undef 1 311 89
new 0 312 90
assign 1 314 92
new 0 314 92
marshallWriteInst 2 315 93
assign 1 316 94
toString 0 316 94
return 1 316 95
assign 1 320 99
undef 1 320 104
new 0 321 105
marshallWriteInst 2 323 107
assign 1 327 121
undef 1 327 126
assign 1 328 127
new 0 328 127
write 1 328 128
assign 1 329 131
sameType 1 329 131
marshallWriteString 2 330 133
assign 1 331 136
sameType 1 331 136
marshallWriteList 2 332 138
assign 1 333 141
sameType 1 333 141
marshallWriteMap 2 334 143
assign 1 335 146
sameType 1 335 146
assign 1 336 148
toString 0 336 148
write 1 336 149
assign 1 337 152
sameType 1 337 152
assign 1 338 154
toString 0 338 154
write 1 338 155
assign 1 340 158
toString 0 340 158
marshallWriteString 2 340 159
assign 1 345 272
new 0 345 272
assign 1 346 273
sizeGet 0 346 273
assign 1 348 274
sizeGet 0 348 274
assign 1 351 275
new 0 351 275
assign 1 351 276
new 0 351 276
assign 1 351 277
getInt 2 351 277
assign 1 352 278
new 0 352 278
assign 1 352 279
equals 1 352 284
assign 1 354 285
new 0 354 285
assign 1 354 286
hexNew 1 354 286
assign 1 354 287
and 1 354 287
assign 1 356 290
new 0 356 290
assign 1 356 291
equals 1 356 296
assign 1 358 297
new 0 358 297
assign 1 358 298
hexNew 1 358 298
assign 1 358 299
and 1 358 299
assign 1 360 302
new 0 360 302
assign 1 360 303
equals 1 360 308
assign 1 362 309
new 0 362 309
assign 1 362 310
hexNew 1 362 310
assign 1 362 311
and 1 362 311
assign 1 364 315
new 0 364 315
assign 1 364 316
greater 1 364 321
assign 1 365 322
new 0 365 322
assign 1 365 325
lesser 1 365 330
getInt 2 367 331
assign 1 369 332
new 0 369 332
assign 1 369 333
shiftLeft 1 369 333
assign 1 369 334
new 0 369 334
assign 1 369 335
hexNew 1 369 335
assign 1 369 336
and 1 369 336
assign 1 369 337
add 1 369 337
incrementValue 0 365 338
assign 1 372 345
new 0 372 345
assign 1 372 346
equals 1 372 351
assign 1 373 352
new 0 373 352
assign 1 374 355
new 0 374 355
assign 1 374 356
equals 1 374 361
assign 1 375 362
new 0 375 362
assign 1 377 365
new 0 377 365
assign 1 377 366
hexNew 1 377 366
assign 1 377 367
lesser 1 377 372
assign 1 378 373
new 0 378 373
assign 1 380 376
new 0 380 376
assign 1 384 380
capacityGet 0 384 380
assign 1 384 381
subtract 1 384 381
assign 1 384 382
lesser 1 384 387
assign 1 385 388
add 1 385 388
capacitySet 1 385 389
assign 1 388 391
new 0 388 391
assign 1 388 392
equals 1 388 397
assign 1 390 398
new 0 390 398
assign 1 391 399
toEscapesGet 0 391 399
assign 1 391 400
get 1 391 400
assign 1 392 401
def 1 392 406
addValue 1 393 407
addValue 1 396 410
assign 1 398 414
new 0 398 414
assign 1 398 415
greater 1 398 420
assign 1 399 421
new 0 399 421
assign 1 399 422
equals 1 399 427
assign 1 400 428
new 0 400 428
assign 1 400 429
addValue 1 400 429
assign 1 400 430
new 0 400 430
assign 1 400 431
once 0 400 431
assign 1 400 432
new 1 400 432
assign 1 400 433
new 0 400 433
assign 1 400 434
once 0 400 434
assign 1 400 435
new 0 400 435
assign 1 400 436
once 0 400 436
assign 1 400 437
new 0 400 437
assign 1 400 438
once 0 400 438
assign 1 400 439
toString 4 400 439
addValue 1 400 440
assign 1 401 443
new 0 401 443
assign 1 401 444
equals 1 401 449
assign 1 402 450
new 0 402 450
assign 1 402 451
hexNew 1 402 451
subtractValue 1 402 452
assign 1 403 453
new 0 403 453
assign 1 403 454
hexNew 1 403 454
assign 1 403 455
new 0 403 455
assign 1 403 456
hexNew 1 403 456
assign 1 403 457
and 1 403 457
assign 1 403 458
new 0 403 458
assign 1 403 459
shiftRight 1 403 459
assign 1 403 460
or 1 403 460
assign 1 404 461
new 0 404 461
assign 1 404 462
hexNew 1 404 462
assign 1 404 463
new 0 404 463
assign 1 404 464
hexNew 1 404 464
assign 1 404 465
and 1 404 465
assign 1 404 466
or 1 404 466
assign 1 405 467
new 0 405 467
assign 1 405 468
addValue 1 405 468
assign 1 405 469
new 0 405 469
assign 1 405 470
once 0 405 470
assign 1 405 471
new 1 405 471
assign 1 405 472
new 0 405 472
assign 1 405 473
once 0 405 473
assign 1 405 474
new 0 405 474
assign 1 405 475
once 0 405 475
assign 1 405 476
new 0 405 476
assign 1 405 477
once 0 405 477
assign 1 405 478
toString 4 405 478
addValue 1 405 479
assign 1 406 480
new 0 406 480
assign 1 406 481
addValue 1 406 481
assign 1 406 482
new 0 406 482
assign 1 406 483
once 0 406 483
assign 1 406 484
new 1 406 484
assign 1 406 485
new 0 406 485
assign 1 406 486
once 0 406 486
assign 1 406 487
new 0 406 487
assign 1 406 488
once 0 406 488
assign 1 406 489
new 0 406 489
assign 1 406 490
once 0 406 490
assign 1 406 491
toString 4 406 491
addValue 1 406 492
clear 0 412 502
assign 1 413 503
new 1 413 503
assign 1 413 504
jsonEscape 3 413 504
return 1 413 505
assign 1 417 511
hasNextGet 0 417 511
next 1 418 513
jsonEscapePoint 2 419 514
return 1 421 520
write 1 425 524
assign 1 426 525
jsonEscape 1 426 525
write 1 426 526
write 1 427 527
assign 1 431 538
new 0 431 538
write 1 431 539
assign 1 432 540
new 0 432 540
assign 1 433 541
iteratorGet 0 0 541
assign 1 433 544
hasNextGet 0 433 544
assign 1 433 546
nextGet 0 433 546
assign 1 435 548
new 0 435 548
assign 1 437 551
new 0 437 551
write 1 437 552
marshallWriteInst 2 439 554
assign 1 441 560
new 0 441 560
write 1 441 561
assign 1 445 575
new 0 445 575
write 1 445 576
assign 1 446 577
new 0 446 577
assign 1 447 578
iteratorGet 0 0 578
assign 1 447 581
hasNextGet 0 447 581
assign 1 447 583
nextGet 0 447 583
assign 1 450 585
new 0 450 585
assign 1 452 588
new 0 452 588
write 1 452 589
assign 1 454 591
keyGet 0 454 591
marshallWriteString 2 454 592
assign 1 455 593
new 0 455 593
write 1 455 594
assign 1 456 595
valueGet 0 456 595
marshallWriteInst 2 456 596
assign 1 458 602
new 0 458 602
write 1 458 603
return 1 0 607
return 1 0 610
assign 1 0 613
assign 1 0 617
return 1 0 621
return 1 0 624
assign 1 0 627
assign 1 0 631
return 1 0 635
return 1 0 638
assign 1 0 641
assign 1 0 645
return 1 0 649
return 1 0 652
assign 1 0 655
assign 1 0 659
return 1 0 663
return 1 0 666
assign 1 0 669
assign 1 0 673
return 1 0 677
return 1 0 680
assign 1 0 683
assign 1 0 687
return 1 0 691
return 1 0 694
assign 1 0 697
assign 1 0 701
return 1 0 705
return 1 0 708
assign 1 0 711
assign 1 0 715
return 1 0 719
return 1 0 722
assign 1 0 725
assign 1 0 729
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 98820264: return bem_intGetDirect_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case -2083934905: return bem_copy_0();
case -1138072028: return bem_tagGet_0();
case 80244442: return bem_toString_0();
case -1891943937: return bem_mbiGetDirect_0();
case -1074341902: return bem_print_0();
case -1625648722: return bem_once_0();
case -258429791: return bem_booGet_0();
case 1297175099: return bem_fieldIteratorGet_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -1882364243: return bem_many_0();
case 844225351: return bem_classNameGet_0();
case -929145394: return bem_escapedGetDirect_0();
case 1595496424: return bem_escapedGet_0();
case -1253246070: return bem_create_0();
case -94597227: return bem_strGetDirect_0();
case -1391349949: return bem_qGetDirect_0();
case -753894116: return bem_new_0();
case -2123848647: return bem_fieldNamesGet_0();
case 670702241: return bem_arrGetDirect_0();
case 1014225644: return bem_echo_0();
case -628560707: return bem_toAny_0();
case 607596663: return bem_mapGet_0();
case 1355257833: return bem_intGet_0();
case 244310079: return bem_mapGetDirect_0();
case 770834928: return bem_serializeContents_0();
case 927986356: return bem_strGet_0();
case 1165329653: return bem_hashGet_0();
case -1194289304: return bem_serializeToString_0();
case -454066024: return bem_booGetDirect_0();
case -1101809929: return bem_txtptGetDirect_0();
case 27187475: return bem_mbiGet_0();
case -174697001: return bem_txtptGet_0();
case -2131387379: return bem_iteratorGet_0();
case 426203430: return bem_qGet_0();
case 1265824069: return bem_arrGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -814915956: return bem_mapSet_1(bevd_0);
case 649360048: return bem_mbiSetDirect_1(bevd_0);
case -1018139450: return bem_mbiSet_1(bevd_0);
case -1485969609: return bem_txtptSet_1(bevd_0);
case -1972283404: return bem_booSet_1(bevd_0);
case 780098994: return bem_booSetDirect_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case 1155445296: return bem_txtptSetDirect_1(bevd_0);
case 1414757302: return bem_strSetDirect_1(bevd_0);
case 1408969798: return bem_qSet_1(bevd_0);
case 1510636819: return bem_mapSetDirect_1(bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case 1843204698: return bem_marshall_1(bevd_0);
case 1777130713: return bem_escapedSet_1(bevd_0);
case 860369942: return bem_intSetDirect_1(bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case -126661352: return bem_arrSetDirect_1(bevd_0);
case 298213638: return bem_escapedSetDirect_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case 604239381: return bem_strSet_1(bevd_0);
case 1794277425: return bem_intSet_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case -353646228: return bem_arrSet_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -636442813: return bem_def_1(bevd_0);
case -1785323864: return bem_jsonEscape_1(bevd_0);
case 756888870: return bem_qSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -121946741: return bem_marshallWriteMap_2(bevd_0, bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -160885310: return bem_marshallWriteString_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 946363532: return bem_jsonEscapePoint_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 551543050: return bem_marshallWriteList_2(bevd_0, bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1378848180: return bem_marshallWriteInst_2(bevd_0, bevd_1);
case -1678156911: return bem_marshallWrite_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -90948503: return bem_jsonEscape_3((BEC_2_4_17_TextMultiByteIterator) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_JsonMarshaller_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_10_JsonMarshaller_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_10_JsonMarshaller();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst = (BEC_2_4_10_JsonMarshaller) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_type;
}
}
}
