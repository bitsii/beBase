namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_10_JsonMarshaller : BEC_2_6_6_SystemObject {
public BEC_2_4_10_JsonMarshaller() { }
static BEC_2_4_10_JsonMarshaller() { }
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x4D,0x61,0x72,0x73,0x68,0x61,0x6C,0x6C,0x65,0x72};
private static byte[] becc_BEC_2_4_10_JsonMarshaller_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_1 = {0x31,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_1 = (new BEC_2_4_3_MathInt(3));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_2 = {0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_2 = (new BEC_2_4_3_MathInt(4));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_3 = {0x37};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_3 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_4 = {0x33,0x46};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_4 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_5 = (new BEC_2_4_3_MathInt(1));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_5 = {0x31,0x30,0x30,0x30,0x30};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_6 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_7 = (new BEC_2_4_3_MathInt(3));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_8 = (new BEC_2_4_3_MathInt(7));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_6 = {0x5C,0x75};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_9 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_10 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_11 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_12 = (new BEC_2_4_3_MathInt(87));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_13 = (new BEC_2_4_3_MathInt(13));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_7 = {0x44,0x38,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_8 = {0x66,0x66,0x63,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_9 = {0x44,0x43,0x30,0x30};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_10 = {0x30,0x30,0x33,0x66,0x66};
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_14 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_15 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_16 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_17 = (new BEC_2_4_3_MathInt(87));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_18 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_19 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_20 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_10_JsonMarshaller_bevo_21 = (new BEC_2_4_3_MathInt(87));
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_11 = {0x5B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_12 = {0x2C};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_13 = {0x5D};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_14 = {0x7B};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_15 = {0x3A};
private static byte[] bece_BEC_2_4_10_JsonMarshaller_bels_16 = {0x7D};
public static new BEC_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_inst;

public static new BET_2_4_10_JsonMarshaller bece_BEC_2_4_10_JsonMarshaller_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_9_4_ContainerList bevp_arr;
public BEC_2_9_3_ContainerMap bevp_map;
public BEC_2_4_3_MathInt bevp_int;
public BEC_2_5_4_LogicBool bevp_boo;
public BEC_2_4_6_TextString bevp_q;
public BEC_2_4_17_TextMultiByteIterator bevp_mbi;
public BEC_2_4_6_TextString bevp_txtpt;
public BEC_2_4_6_TextString bevp_escaped;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevp_str = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_arr = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_0_ta_ph);
bevp_map = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_int = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevp_boo = (BEC_2_5_4_LogicBool) (new BEC_2_5_4_LogicBool()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_q = bevt_1_ta_ph.bem_quoteGet_0();
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) (new BEC_2_4_17_TextMultiByteIterator()).bem_new_0();
bevp_txtpt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_escaped = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_marshall_1(BEC_2_6_6_SystemObject beva_inst) {
BEC_2_4_6_TextString bevl_bb = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 310*/ {
bem_new_0();
} /* Line: 311*/
bevl_bb = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bem_marshallWriteInst_2(beva_inst, bevl_bb);
bevt_1_ta_ph = bevl_bb.bem_toString_0();
return bevt_1_ta_ph;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWrite_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_str == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 319*/ {
bem_new_0();
} /* Line: 320*/
bem_marshallWriteInst_2(beva_inst, beva_writer);
return this;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWriteInst_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
if (beva_inst == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_0));
beva_writer.bemd_1(-1751182431, bevt_1_ta_ph);
} /* Line: 327*/
 else /* Line: 326*/ {
bevt_2_ta_ph = beva_inst.bemd_1(-8419053, bevp_str);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 328*/ {
bem_marshallWriteString_2((BEC_2_4_6_TextString) beva_inst , beva_writer);
} /* Line: 329*/
 else /* Line: 326*/ {
bevt_3_ta_ph = beva_inst.bemd_1(-8419053, bevp_arr);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 330*/ {
bem_marshallWriteList_2(beva_inst, beva_writer);
} /* Line: 331*/
 else /* Line: 326*/ {
bevt_4_ta_ph = beva_inst.bemd_1(-8419053, bevp_map);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 332*/ {
bem_marshallWriteMap_2(beva_inst, beva_writer);
} /* Line: 333*/
 else /* Line: 326*/ {
bevt_5_ta_ph = beva_inst.bemd_1(-8419053, bevp_int);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 334*/ {
bevt_6_ta_ph = beva_inst.bemd_0(-1275325619);
beva_writer.bemd_1(-1751182431, bevt_6_ta_ph);
} /* Line: 335*/
 else /* Line: 326*/ {
bevt_7_ta_ph = beva_inst.bemd_1(-8419053, bevp_boo);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 336*/ {
bevt_8_ta_ph = beva_inst.bemd_0(-1275325619);
beva_writer.bemd_1(-1751182431, bevt_8_ta_ph);
} /* Line: 337*/
 else /* Line: 338*/ {
bevt_9_ta_ph = beva_inst.bemd_0(-1275325619);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_9_ta_ph , beva_writer);
} /* Line: 339*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
} /* Line: 326*/
return this;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_jsonEscapePoint_2(BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_txt) {
BEC_2_4_3_MathInt bevl_rcap = null;
BEC_2_4_3_MathInt bevl_txtsznow = null;
BEC_2_4_3_MathInt bevl_size = null;
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_u = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_7_JsonEscapes bevl_esc = null;
BEC_2_4_6_TextString bevl_escval = null;
BEC_2_4_3_MathInt bevl_first = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_3_MathInt bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_5_4_LogicBool bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_4_3_MathInt bevt_32_ta_ph = null;
BEC_2_5_4_LogicBool bevt_33_ta_ph = null;
BEC_2_4_3_MathInt bevt_34_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_35_ta_ph = null;
BEC_2_5_4_LogicBool bevt_36_ta_ph = null;
BEC_2_5_4_LogicBool bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_4_3_MathInt bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_3_MathInt bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_4_3_MathInt bevt_48_ta_ph = null;
BEC_2_4_3_MathInt bevt_49_ta_ph = null;
BEC_2_4_3_MathInt bevt_50_ta_ph = null;
BEC_2_4_3_MathInt bevt_51_ta_ph = null;
BEC_2_4_3_MathInt bevt_52_ta_ph = null;
BEC_2_5_4_LogicBool bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_3_MathInt bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_3_MathInt bevt_59_ta_ph = null;
BEC_2_4_3_MathInt bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_3_MathInt bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_3_MathInt bevt_73_ta_ph = null;
BEC_2_4_3_MathInt bevt_74_ta_ph = null;
BEC_2_4_3_MathInt bevt_75_ta_ph = null;
BEC_2_4_3_MathInt bevt_76_ta_ph = null;
BEC_2_4_3_MathInt bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_4_3_MathInt bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_3_MathInt bevt_85_ta_ph = null;
BEC_2_4_3_MathInt bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_3_MathInt bevt_88_ta_ph = null;
BEC_2_4_3_MathInt bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_4_3_MathInt bevt_92_ta_ph = null;
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_txtsznow = beva_txt.bem_sizeGet_0();
bevl_size = beva_txtpt.bem_sizeGet_0();
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_u = beva_txtpt.bem_getInt_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevt_3_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_0;
if (bevl_size.bevi_int == bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 352*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_1));
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_5_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_4_ta_ph);
} /* Line: 353*/
 else /* Line: 351*/ {
bevt_7_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_1;
if (bevl_size.bevi_int == bevt_7_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 356*/ {
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_2));
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_9_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_8_ta_ph);
} /* Line: 357*/
 else /* Line: 351*/ {
bevt_11_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_2;
if (bevl_size.bevi_int == bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 360*/ {
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_3));
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_13_ta_ph);
bevl_value = bevl_u.bem_and_1(bevt_12_ta_ph);
} /* Line: 361*/
} /* Line: 351*/
} /* Line: 351*/
bevt_15_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_3;
if (bevl_size.bevi_int > bevt_15_ta_ph.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 363*/ {
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 364*/ {
if (bevl_i.bevi_int < bevl_size.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 365*/ {
beva_txtpt.bem_getInt_2(bevl_i, bevl_u);
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevt_17_ta_ph = bevl_value.bem_shiftLeft_1(bevt_18_ta_ph);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_4));
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_21_ta_ph);
bevt_19_ta_ph = bevl_u.bem_and_1(bevt_20_ta_ph);
bevl_value = bevt_17_ta_ph.bem_add_1(bevt_19_ta_ph);
bevl_i.bevi_int++;
} /* Line: 364*/
 else /* Line: 364*/ {
break;
} /* Line: 364*/
} /* Line: 364*/
} /* Line: 364*/
bevt_23_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_4;
if (bevl_size.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 371*/ {
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
} /* Line: 372*/
 else /* Line: 371*/ {
bevt_25_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_5;
if (bevl_size.bevi_int == bevt_25_ta_ph.bevi_int) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 373*/ {
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
} /* Line: 374*/
 else /* Line: 375*/ {
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_27_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_28_ta_ph);
if (bevl_value.bevi_int < bevt_27_ta_ph.bevi_int) {
bevt_26_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_26_ta_ph.bevi_bool)/* Line: 376*/ {
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
} /* Line: 377*/
 else /* Line: 378*/ {
bevl_rcap = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
} /* Line: 379*/
} /* Line: 376*/
} /* Line: 371*/
bevt_31_ta_ph = beva_txt.bem_capacityGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_subtract_1(bevl_txtsznow);
if (bevt_30_ta_ph.bevi_int < bevl_rcap.bevi_int) {
bevt_29_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_29_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_29_ta_ph.bevi_bool)/* Line: 383*/ {
bevt_32_ta_ph = bevl_txtsznow.bem_add_1(bevl_rcap);
beva_txt.bem_capacitySet_1(bevt_32_ta_ph);
} /* Line: 384*/
bevt_34_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_6;
if (bevl_rcap.bevi_int == bevt_34_ta_ph.bevi_int) {
bevt_33_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_33_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_33_ta_ph.bevi_bool)/* Line: 387*/ {
bevl_esc = (BEC_2_4_7_JsonEscapes) BEC_2_4_7_JsonEscapes.bece_BEC_2_4_7_JsonEscapes_bevs_inst;
bevt_35_ta_ph = bevl_esc.bem_toEscapesGet_0();
bevl_escval = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_get_1(beva_txtpt);
if (bevl_escval == null) {
bevt_36_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_36_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_36_ta_ph.bevi_bool)/* Line: 391*/ {
beva_txt.bem_addValue_1(bevl_escval);
} /* Line: 392*/
 else /* Line: 393*/ {
beva_txt.bem_addValue_1(beva_txtpt);
} /* Line: 395*/
} /* Line: 391*/
 else /* Line: 387*/ {
bevt_38_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_7;
if (bevl_rcap.bevi_int > bevt_38_ta_ph.bevi_int) {
bevt_37_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_37_ta_ph.bevi_bool)/* Line: 397*/ {
bevt_40_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_8;
if (bevl_rcap.bevi_int == bevt_40_ta_ph.bevi_int) {
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 398*/ {
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_41_ta_ph = (BEC_2_4_6_TextString) beva_txt.bem_addValue_1(bevt_42_ta_ph);
bevt_46_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_9;
bevt_45_ta_ph = (BEC_2_4_3_MathInt) bevt_46_ta_ph.bem_once_0();
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_45_ta_ph);
bevt_48_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_10;
bevt_47_ta_ph = (BEC_2_4_3_MathInt) bevt_48_ta_ph.bem_once_0();
bevt_50_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_11;
bevt_49_ta_ph = (BEC_2_4_3_MathInt) bevt_50_ta_ph.bem_once_0();
bevt_52_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_12;
bevt_51_ta_ph = (BEC_2_4_3_MathInt) bevt_52_ta_ph.bem_once_0();
bevt_43_ta_ph = bevl_value.bem_toString_4(bevt_44_ta_ph, bevt_47_ta_ph, bevt_49_ta_ph, bevt_51_ta_ph);
bevt_41_ta_ph.bem_addValue_1(bevt_43_ta_ph);
} /* Line: 399*/
 else /* Line: 398*/ {
bevt_54_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_13;
if (bevl_rcap.bevi_int == bevt_54_ta_ph.bevi_int) {
bevt_53_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_53_ta_ph.bevi_bool)/* Line: 400*/ {
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_5));
bevt_55_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_56_ta_ph);
bevl_value.bem_subtractValue_1(bevt_55_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_7));
bevt_57_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_58_ta_ph);
bevt_62_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_8));
bevt_61_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_62_ta_ph);
bevt_60_ta_ph = bevl_value.bem_and_1(bevt_61_ta_ph);
bevt_63_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_59_ta_ph = bevt_60_ta_ph.bem_shiftRight_1(bevt_63_ta_ph);
bevl_first = bevt_57_ta_ph.bem_or_1(bevt_59_ta_ph);
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_4_10_JsonMarshaller_bels_9));
bevt_64_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_65_ta_ph);
bevt_68_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_4_10_JsonMarshaller_bels_10));
bevt_67_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_hexNew_1(bevt_68_ta_ph);
bevt_66_ta_ph = bevl_value.bem_and_1(bevt_67_ta_ph);
bevl_last = bevt_64_ta_ph.bem_or_1(bevt_66_ta_ph);
bevt_70_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_69_ta_ph = (BEC_2_4_6_TextString) beva_txt.bem_addValue_1(bevt_70_ta_ph);
bevt_74_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_14;
bevt_73_ta_ph = (BEC_2_4_3_MathInt) bevt_74_ta_ph.bem_once_0();
bevt_72_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_73_ta_ph);
bevt_76_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_15;
bevt_75_ta_ph = (BEC_2_4_3_MathInt) bevt_76_ta_ph.bem_once_0();
bevt_78_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_16;
bevt_77_ta_ph = (BEC_2_4_3_MathInt) bevt_78_ta_ph.bem_once_0();
bevt_80_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_17;
bevt_79_ta_ph = (BEC_2_4_3_MathInt) bevt_80_ta_ph.bem_once_0();
bevt_71_ta_ph = bevl_first.bem_toString_4(bevt_72_ta_ph, bevt_75_ta_ph, bevt_77_ta_ph, bevt_79_ta_ph);
bevt_69_ta_ph.bem_addValue_1(bevt_71_ta_ph);
bevt_82_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_4_10_JsonMarshaller_bels_6));
bevt_81_ta_ph = (BEC_2_4_6_TextString) beva_txt.bem_addValue_1(bevt_82_ta_ph);
bevt_86_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_18;
bevt_85_ta_ph = (BEC_2_4_3_MathInt) bevt_86_ta_ph.bem_once_0();
bevt_84_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_85_ta_ph);
bevt_88_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_19;
bevt_87_ta_ph = (BEC_2_4_3_MathInt) bevt_88_ta_ph.bem_once_0();
bevt_90_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_20;
bevt_89_ta_ph = (BEC_2_4_3_MathInt) bevt_90_ta_ph.bem_once_0();
bevt_92_ta_ph = bece_BEC_2_4_10_JsonMarshaller_bevo_21;
bevt_91_ta_ph = (BEC_2_4_3_MathInt) bevt_92_ta_ph.bem_once_0();
bevt_83_ta_ph = bevl_last.bem_toString_4(bevt_84_ta_ph, bevt_87_ta_ph, bevt_89_ta_ph, bevt_91_ta_ph);
bevt_81_ta_ph.bem_addValue_1(bevt_83_ta_ph);
} /* Line: 405*/
} /* Line: 398*/
} /* Line: 398*/
} /* Line: 387*/
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_jsonEscape_1(BEC_2_6_6_SystemObject beva_toEscape) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevp_escaped.bem_clear_0();
bevt_1_ta_ph = (BEC_2_4_17_TextMultiByteIterator) bevp_mbi.bem_new_1((BEC_2_4_6_TextString) beva_toEscape );
bevt_0_ta_ph = bem_jsonEscape_3(bevt_1_ta_ph, bevp_txtpt, bevp_escaped);
return bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_jsonEscape_3(BEC_2_4_17_TextMultiByteIterator beva_mbi, BEC_2_4_6_TextString beva_txtpt, BEC_2_4_6_TextString beva_escaped) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
while (true)
/* Line: 416*/ {
bevt_0_ta_ph = beva_mbi.bem_hasNextGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 416*/ {
beva_mbi.bem_next_1(beva_txtpt);
bem_jsonEscapePoint_2(beva_txtpt, beva_escaped);
} /* Line: 418*/
 else /* Line: 416*/ {
break;
} /* Line: 416*/
} /* Line: 416*/
return beva_escaped;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWriteString_2(BEC_2_4_6_TextString beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_writer.bemd_1(-1751182431, bevp_q);
bevt_0_ta_ph = bem_jsonEscape_1(beva_inst);
beva_writer.bemd_1(-1751182431, bevt_0_ta_ph);
beva_writer.bemd_1(-1751182431, bevp_q);
return this;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWriteList_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_instin = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_11));
beva_writer.bemd_1(-1751182431, bevt_1_ta_ph);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(2045941275);
while (true)
/* Line: 432*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 432*/ {
bevl_instin = bevt_0_ta_loop.bemd_0(450495808);
if (bevl_first.bevi_bool)/* Line: 433*/ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 434*/
 else /* Line: 435*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(-1751182431, bevt_3_ta_ph);
} /* Line: 436*/
bem_marshallWriteInst_2(bevl_instin, beva_writer);
} /* Line: 438*/
 else /* Line: 432*/ {
break;
} /* Line: 432*/
} /* Line: 432*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_13));
beva_writer.bemd_1(-1751182431, bevt_4_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_marshallWriteMap_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_writer) {
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_6_6_SystemObject bevl_kv = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_14));
beva_writer.bemd_1(-1751182431, bevt_1_ta_ph);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = beva_inst.bemd_0(2045941275);
while (true)
/* Line: 446*/ {
bevt_2_ta_ph = bevt_0_ta_loop.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 446*/ {
bevl_kv = bevt_0_ta_loop.bemd_0(450495808);
if (bevl_first.bevi_bool)/* Line: 448*/ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 449*/
 else /* Line: 450*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_12));
beva_writer.bemd_1(-1751182431, bevt_3_ta_ph);
} /* Line: 451*/
bevt_4_ta_ph = bevl_kv.bemd_0(1960015313);
bem_marshallWriteString_2((BEC_2_4_6_TextString) bevt_4_ta_ph , beva_writer);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_15));
beva_writer.bemd_1(-1751182431, bevt_5_ta_ph);
bevt_6_ta_ph = bevl_kv.bemd_0(-1859192480);
bem_marshallWriteInst_2(bevt_6_ta_ph, beva_writer);
} /* Line: 455*/
 else /* Line: 446*/ {
break;
} /* Line: 446*/
} /* Line: 446*/
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_10_JsonMarshaller_bels_16));
beva_writer.bemd_1(-1751182431, bevt_7_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGetDirect_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_arrGet_0() {
return bevp_arr;
} /*method end*/
public BEC_2_9_4_ContainerList bem_arrGetDirect_0() {
return bevp_arr;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_arrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_arrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_arr = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_mapGet_0() {
return bevp_map;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_mapGetDirect_0() {
return bevp_map;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_mapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_map = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_intGet_0() {
return bevp_int;
} /*method end*/
public BEC_2_4_3_MathInt bem_intGetDirect_0() {
return bevp_int;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_intSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_intSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_int = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_booGet_0() {
return bevp_boo;
} /*method end*/
public BEC_2_5_4_LogicBool bem_booGetDirect_0() {
return bevp_boo;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_booSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_booSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_boo = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_qGet_0() {
return bevp_q;
} /*method end*/
public BEC_2_4_6_TextString bem_qGetDirect_0() {
return bevp_q;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_qSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_q = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_qSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_q = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_17_TextMultiByteIterator bem_mbiGet_0() {
return bevp_mbi;
} /*method end*/
public BEC_2_4_17_TextMultiByteIterator bem_mbiGetDirect_0() {
return bevp_mbi;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_mbiSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_mbiSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mbi = (BEC_2_4_17_TextMultiByteIterator) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_txtptGet_0() {
return bevp_txtpt;
} /*method end*/
public BEC_2_4_6_TextString bem_txtptGetDirect_0() {
return bevp_txtpt;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_txtptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_txtptSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_txtpt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_escapedGet_0() {
return bevp_escaped;
} /*method end*/
public BEC_2_4_6_TextString bem_escapedGetDirect_0() {
return bevp_escaped;
} /*method end*/
public virtual BEC_2_4_10_JsonMarshaller bem_escapedSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_10_JsonMarshaller bem_escapedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_escaped = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {291, 293, 293, 295, 297, 299, 301, 301, 303, 304, 305, 310, 310, 311, 313, 314, 315, 315, 319, 319, 320, 322, 326, 326, 327, 327, 328, 329, 330, 331, 332, 333, 334, 335, 335, 336, 337, 337, 339, 339, 344, 345, 347, 350, 350, 350, 351, 351, 351, 353, 353, 353, 355, 355, 355, 357, 357, 357, 359, 359, 359, 361, 361, 361, 363, 363, 363, 364, 364, 364, 366, 368, 368, 368, 368, 368, 368, 364, 371, 371, 371, 372, 373, 373, 373, 374, 376, 376, 376, 376, 377, 379, 383, 383, 383, 383, 384, 384, 387, 387, 387, 389, 390, 390, 391, 391, 392, 395, 397, 397, 397, 398, 398, 398, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 399, 400, 400, 400, 401, 401, 401, 402, 402, 402, 402, 402, 402, 402, 402, 403, 403, 403, 403, 403, 403, 404, 404, 404, 404, 404, 404, 404, 404, 404, 404, 404, 404, 404, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 405, 411, 412, 412, 412, 416, 417, 418, 420, 424, 425, 425, 426, 430, 430, 431, 432, 0, 432, 432, 434, 436, 436, 438, 440, 440, 444, 444, 445, 446, 0, 446, 446, 449, 451, 451, 453, 453, 454, 454, 455, 455, 457, 457, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 80, 85, 86, 88, 89, 90, 91, 95, 100, 101, 103, 117, 122, 123, 124, 127, 129, 132, 134, 137, 139, 142, 144, 145, 148, 150, 151, 154, 155, 268, 269, 270, 271, 272, 273, 274, 275, 280, 281, 282, 283, 286, 287, 292, 293, 294, 295, 298, 299, 304, 305, 306, 307, 311, 312, 317, 318, 321, 326, 327, 328, 329, 330, 331, 332, 333, 334, 341, 342, 347, 348, 351, 352, 357, 358, 361, 362, 363, 368, 369, 372, 376, 377, 378, 383, 384, 385, 387, 388, 393, 394, 395, 396, 397, 402, 403, 406, 410, 411, 416, 417, 418, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 439, 440, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 498, 499, 500, 501, 507, 509, 510, 516, 520, 521, 522, 523, 534, 535, 536, 537, 537, 540, 542, 544, 547, 548, 550, 556, 557, 571, 572, 573, 574, 574, 577, 579, 581, 584, 585, 587, 588, 589, 590, 591, 592, 598, 599, 603, 606, 609, 613, 617, 620, 623, 627, 631, 634, 637, 641, 645, 648, 651, 655, 659, 662, 665, 669, 673, 676, 679, 683, 687, 690, 693, 697, 701, 704, 707, 711, 715, 718, 721, 725};
/* BEGIN LINEINFO 
assign 1 291 63
new 0 291 63
assign 1 293 64
new 0 293 64
assign 1 293 65
new 1 293 65
assign 1 295 66
new 0 295 66
assign 1 297 67
new 0 297 67
assign 1 299 68
new 0 299 68
assign 1 301 69
new 0 301 69
assign 1 301 70
quoteGet 0 301 70
assign 1 303 71
new 0 303 71
assign 1 304 72
new 0 304 72
assign 1 305 73
new 0 305 73
assign 1 310 80
undef 1 310 85
new 0 311 86
assign 1 313 88
new 0 313 88
marshallWriteInst 2 314 89
assign 1 315 90
toString 0 315 90
return 1 315 91
assign 1 319 95
undef 1 319 100
new 0 320 101
marshallWriteInst 2 322 103
assign 1 326 117
undef 1 326 122
assign 1 327 123
new 0 327 123
write 1 327 124
assign 1 328 127
sameType 1 328 127
marshallWriteString 2 329 129
assign 1 330 132
sameType 1 330 132
marshallWriteList 2 331 134
assign 1 332 137
sameType 1 332 137
marshallWriteMap 2 333 139
assign 1 334 142
sameType 1 334 142
assign 1 335 144
toString 0 335 144
write 1 335 145
assign 1 336 148
sameType 1 336 148
assign 1 337 150
toString 0 337 150
write 1 337 151
assign 1 339 154
toString 0 339 154
marshallWriteString 2 339 155
assign 1 344 268
new 0 344 268
assign 1 345 269
sizeGet 0 345 269
assign 1 347 270
sizeGet 0 347 270
assign 1 350 271
new 0 350 271
assign 1 350 272
new 0 350 272
assign 1 350 273
getInt 2 350 273
assign 1 351 274
new 0 351 274
assign 1 351 275
equals 1 351 280
assign 1 353 281
new 0 353 281
assign 1 353 282
hexNew 1 353 282
assign 1 353 283
and 1 353 283
assign 1 355 286
new 0 355 286
assign 1 355 287
equals 1 355 292
assign 1 357 293
new 0 357 293
assign 1 357 294
hexNew 1 357 294
assign 1 357 295
and 1 357 295
assign 1 359 298
new 0 359 298
assign 1 359 299
equals 1 359 304
assign 1 361 305
new 0 361 305
assign 1 361 306
hexNew 1 361 306
assign 1 361 307
and 1 361 307
assign 1 363 311
new 0 363 311
assign 1 363 312
greater 1 363 317
assign 1 364 318
new 0 364 318
assign 1 364 321
lesser 1 364 326
getInt 2 366 327
assign 1 368 328
new 0 368 328
assign 1 368 329
shiftLeft 1 368 329
assign 1 368 330
new 0 368 330
assign 1 368 331
hexNew 1 368 331
assign 1 368 332
and 1 368 332
assign 1 368 333
add 1 368 333
incrementValue 0 364 334
assign 1 371 341
new 0 371 341
assign 1 371 342
equals 1 371 347
assign 1 372 348
new 0 372 348
assign 1 373 351
new 0 373 351
assign 1 373 352
equals 1 373 357
assign 1 374 358
new 0 374 358
assign 1 376 361
new 0 376 361
assign 1 376 362
hexNew 1 376 362
assign 1 376 363
lesser 1 376 368
assign 1 377 369
new 0 377 369
assign 1 379 372
new 0 379 372
assign 1 383 376
capacityGet 0 383 376
assign 1 383 377
subtract 1 383 377
assign 1 383 378
lesser 1 383 383
assign 1 384 384
add 1 384 384
capacitySet 1 384 385
assign 1 387 387
new 0 387 387
assign 1 387 388
equals 1 387 393
assign 1 389 394
new 0 389 394
assign 1 390 395
toEscapesGet 0 390 395
assign 1 390 396
get 1 390 396
assign 1 391 397
def 1 391 402
addValue 1 392 403
addValue 1 395 406
assign 1 397 410
new 0 397 410
assign 1 397 411
greater 1 397 416
assign 1 398 417
new 0 398 417
assign 1 398 418
equals 1 398 423
assign 1 399 424
new 0 399 424
assign 1 399 425
addValue 1 399 425
assign 1 399 426
new 0 399 426
assign 1 399 427
once 0 399 427
assign 1 399 428
new 1 399 428
assign 1 399 429
new 0 399 429
assign 1 399 430
once 0 399 430
assign 1 399 431
new 0 399 431
assign 1 399 432
once 0 399 432
assign 1 399 433
new 0 399 433
assign 1 399 434
once 0 399 434
assign 1 399 435
toString 4 399 435
addValue 1 399 436
assign 1 400 439
new 0 400 439
assign 1 400 440
equals 1 400 445
assign 1 401 446
new 0 401 446
assign 1 401 447
hexNew 1 401 447
subtractValue 1 401 448
assign 1 402 449
new 0 402 449
assign 1 402 450
hexNew 1 402 450
assign 1 402 451
new 0 402 451
assign 1 402 452
hexNew 1 402 452
assign 1 402 453
and 1 402 453
assign 1 402 454
new 0 402 454
assign 1 402 455
shiftRight 1 402 455
assign 1 402 456
or 1 402 456
assign 1 403 457
new 0 403 457
assign 1 403 458
hexNew 1 403 458
assign 1 403 459
new 0 403 459
assign 1 403 460
hexNew 1 403 460
assign 1 403 461
and 1 403 461
assign 1 403 462
or 1 403 462
assign 1 404 463
new 0 404 463
assign 1 404 464
addValue 1 404 464
assign 1 404 465
new 0 404 465
assign 1 404 466
once 0 404 466
assign 1 404 467
new 1 404 467
assign 1 404 468
new 0 404 468
assign 1 404 469
once 0 404 469
assign 1 404 470
new 0 404 470
assign 1 404 471
once 0 404 471
assign 1 404 472
new 0 404 472
assign 1 404 473
once 0 404 473
assign 1 404 474
toString 4 404 474
addValue 1 404 475
assign 1 405 476
new 0 405 476
assign 1 405 477
addValue 1 405 477
assign 1 405 478
new 0 405 478
assign 1 405 479
once 0 405 479
assign 1 405 480
new 1 405 480
assign 1 405 481
new 0 405 481
assign 1 405 482
once 0 405 482
assign 1 405 483
new 0 405 483
assign 1 405 484
once 0 405 484
assign 1 405 485
new 0 405 485
assign 1 405 486
once 0 405 486
assign 1 405 487
toString 4 405 487
addValue 1 405 488
clear 0 411 498
assign 1 412 499
new 1 412 499
assign 1 412 500
jsonEscape 3 412 500
return 1 412 501
assign 1 416 507
hasNextGet 0 416 507
next 1 417 509
jsonEscapePoint 2 418 510
return 1 420 516
write 1 424 520
assign 1 425 521
jsonEscape 1 425 521
write 1 425 522
write 1 426 523
assign 1 430 534
new 0 430 534
write 1 430 535
assign 1 431 536
new 0 431 536
assign 1 432 537
iteratorGet 0 0 537
assign 1 432 540
hasNextGet 0 432 540
assign 1 432 542
nextGet 0 432 542
assign 1 434 544
new 0 434 544
assign 1 436 547
new 0 436 547
write 1 436 548
marshallWriteInst 2 438 550
assign 1 440 556
new 0 440 556
write 1 440 557
assign 1 444 571
new 0 444 571
write 1 444 572
assign 1 445 573
new 0 445 573
assign 1 446 574
iteratorGet 0 0 574
assign 1 446 577
hasNextGet 0 446 577
assign 1 446 579
nextGet 0 446 579
assign 1 449 581
new 0 449 581
assign 1 451 584
new 0 451 584
write 1 451 585
assign 1 453 587
keyGet 0 453 587
marshallWriteString 2 453 588
assign 1 454 589
new 0 454 589
write 1 454 590
assign 1 455 591
valueGet 0 455 591
marshallWriteInst 2 455 592
assign 1 457 598
new 0 457 598
write 1 457 599
return 1 0 603
return 1 0 606
assign 1 0 609
assign 1 0 613
return 1 0 617
return 1 0 620
assign 1 0 623
assign 1 0 627
return 1 0 631
return 1 0 634
assign 1 0 637
assign 1 0 641
return 1 0 645
return 1 0 648
assign 1 0 651
assign 1 0 655
return 1 0 659
return 1 0 662
assign 1 0 665
assign 1 0 669
return 1 0 673
return 1 0 676
assign 1 0 679
assign 1 0 683
return 1 0 687
return 1 0 690
assign 1 0 693
assign 1 0 697
return 1 0 701
return 1 0 704
assign 1 0 707
assign 1 0 711
return 1 0 715
return 1 0 718
assign 1 0 721
assign 1 0 725
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1234154716: return bem_mbiGetDirect_0();
case 501088997: return bem_sourceFileNameGet_0();
case 1807886411: return bem_escapedGetDirect_0();
case 1196171179: return bem_hashGet_0();
case 1482628730: return bem_mapGet_0();
case -1754478112: return bem_print_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case 266686481: return bem_mapGetDirect_0();
case 281444821: return bem_fieldIteratorGet_0();
case -1244530073: return bem_escapedGet_0();
case -1486279572: return bem_serializeContents_0();
case -622336882: return bem_arrGetDirect_0();
case -43867056: return bem_mbiGet_0();
case -1475550710: return bem_create_0();
case -545556484: return bem_once_0();
case -433255577: return bem_qGetDirect_0();
case -695132453: return bem_intGet_0();
case 640277607: return bem_txtptGetDirect_0();
case -2017009146: return bem_new_0();
case -1315998022: return bem_strGetDirect_0();
case -639297756: return bem_toAny_0();
case -1005119995: return bem_many_0();
case 1182578865: return bem_intGetDirect_0();
case 119461913: return bem_tagGet_0();
case -610446974: return bem_arrGet_0();
case 1554027836: return bem_txtptGet_0();
case 1766317415: return bem_booGetDirect_0();
case -1275325619: return bem_toString_0();
case 92516634: return bem_booGet_0();
case -225870373: return bem_serializeToString_0();
case -1583672278: return bem_echo_0();
case -930069099: return bem_strGet_0();
case 611702865: return bem_copy_0();
case -744679096: return bem_fieldNamesGet_0();
case -678541085: return bem_classNameGet_0();
case -1236990070: return bem_qGet_0();
case 2045941275: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 897486280: return bem_txtptSet_1(bevd_0);
case -648256442: return bem_jsonEscape_1(bevd_0);
case 107935681: return bem_intSetDirect_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case -90645783: return bem_mapSet_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case -1508909718: return bem_mapSetDirect_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 699343283: return bem_marshall_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1859607836: return bem_booSetDirect_1(bevd_0);
case -1448552911: return bem_booSet_1(bevd_0);
case 1352588950: return bem_strSet_1(bevd_0);
case 2013184466: return bem_txtptSetDirect_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case 1292409785: return bem_arrSetDirect_1(bevd_0);
case -402958230: return bem_intSet_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case -1311877384: return bem_mbiSetDirect_1(bevd_0);
case -1680792218: return bem_arrSet_1(bevd_0);
case 37191140: return bem_mbiSet_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1474888853: return bem_escapedSetDirect_1(bevd_0);
case -422026942: return bem_strSetDirect_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case 1466837990: return bem_escapedSet_1(bevd_0);
case -1313150604: return bem_qSet_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -30102741: return bem_qSetDirect_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1648471778: return bem_marshallWriteList_2(bevd_0, bevd_1);
case -2137640216: return bem_marshallWrite_2(bevd_0, bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -728741196: return bem_marshallWriteInst_2(bevd_0, bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1660961305: return bem_marshallWriteMap_2(bevd_0, bevd_1);
case 285309339: return bem_marshallWriteString_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 266768334: return bem_jsonEscapePoint_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1378792113: return bem_jsonEscape_3((BEC_2_4_17_TextMultiByteIterator) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_4_10_JsonMarshaller_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_10_JsonMarshaller_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_10_JsonMarshaller();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst = (BEC_2_4_10_JsonMarshaller) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_10_JsonMarshaller.bece_BEC_2_4_10_JsonMarshaller_bevs_type;
}
}
}
