namespace be {
/* IO:File: source/build/Pass4.be */
public sealed class BEC_3_5_5_5_BuildVisitPass4 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass4() { }
static BEC_3_5_5_5_BuildVisitPass4() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass4_bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static new BEC_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_6_TextString bevl_nps = null;
BEC_2_5_4_BuildNode bevl_nxn = null;
BEC_2_5_4_BuildNode bevl_nxnn = null;
BEC_2_5_4_BuildNode bevl_first = null;
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 21 */ {
bevt_5_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_5_tmpany_phold.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 21 */ {
if (bevl_nnode == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 21 */
 else  /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 21 */ {
bevt_9_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 21 */
 else  /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 21 */ {
if (bevl_nps == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 22 */ {
bevl_nps = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 23 */
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevl_nps.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_17_tmpany_phold = bevl_nxn.bem_typenameGet_0();
bevt_18_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_17_tmpany_phold.bevi_int != bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 27 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_3_5_5_5_BuildVisitPass4_bels_0));
bevt_19_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_20_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 28 */
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 31 */ {
beva_node.bem_delete_0();
} /* Line: 32 */
 else  /* Line: 33 */ {
bevl_first = beva_node;
} /* Line: 34 */
bevl_nnode.bem_delete_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 38 */
 else  /* Line: 21 */ {
break;
} /* Line: 21 */
} /* Line: 21 */
if (bevl_first == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_23_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_tmpany_phold);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_26_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_26_tmpany_phold.bevi_int == bevt_27_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 43 */
 else  /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 43 */ {
bevt_28_tmpany_phold = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_tmpany_phold);
beva_node.bem_delete_0();
} /* Line: 45 */
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_tmpany_phold = bevl_first.bem_nextDescendGet_0();
return bevt_29_tmpany_phold;
} /* Line: 49 */
bevt_30_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 20, 21, 21, 21, 21, 21, 21, 0, 0, 0, 21, 21, 21, 21, 0, 0, 0, 22, 22, 23, 25, 25, 25, 25, 26, 27, 27, 0, 27, 27, 27, 27, 0, 0, 28, 28, 28, 30, 31, 31, 32, 34, 36, 37, 38, 40, 40, 41, 41, 42, 43, 43, 43, 43, 43, 43, 0, 0, 0, 44, 44, 45, 47, 48, 49, 49, 51, 51};
public static new int[] bevs_smnlec
 = new int[] {11, 52, 55, 56, 57, 62, 63, 68, 69, 72, 76, 79, 80, 81, 86, 87, 90, 94, 97, 102, 103, 105, 106, 107, 108, 109, 110, 115, 116, 119, 120, 121, 126, 127, 130, 134, 135, 136, 138, 139, 144, 145, 148, 150, 151, 152, 158, 163, 164, 165, 166, 167, 172, 173, 174, 175, 180, 181, 184, 188, 191, 192, 193, 195, 196, 197, 198, 200, 201};
/* BEGIN LINEINFO 
begin 1 16 11
assign 1 20 52
nextPeerGet 0 20 52
assign 1 21 55
typenameGet 0 21 55
assign 1 21 56
IDGet 0 21 56
assign 1 21 57
equals 1 21 62
assign 1 21 63
def 1 21 68
assign 1 0 69
assign 1 0 72
assign 1 0 76
assign 1 21 79
typenameGet 0 21 79
assign 1 21 80
COLONGet 0 21 80
assign 1 21 81
equals 1 21 86
assign 1 0 87
assign 1 0 90
assign 1 0 94
assign 1 22 97
undef 1 22 102
assign 1 23 103
new 0 23 103
assign 1 25 105
heldGet 0 25 105
assign 1 25 106
add 1 25 106
assign 1 25 107
heldGet 0 25 107
assign 1 25 108
add 1 25 108
assign 1 26 109
nextPeerGet 0 26 109
assign 1 27 110
undef 1 27 115
assign 1 0 116
assign 1 27 119
typenameGet 0 27 119
assign 1 27 120
IDGet 0 27 120
assign 1 27 121
notEquals 1 27 126
assign 1 0 127
assign 1 0 130
assign 1 28 134
new 0 28 134
assign 1 28 135
new 2 28 135
throw 1 28 136
assign 1 30 138
nextPeerGet 0 30 138
assign 1 31 139
def 1 31 144
delete 0 32 145
assign 1 34 148
delete 0 36 150
assign 1 37 151
assign 1 38 152
assign 1 40 158
def 1 40 163
assign 1 41 164
NAMEPATHGet 0 41 164
typenameSet 1 41 165
assign 1 42 166
new 0 42 166
assign 1 43 167
def 1 43 172
assign 1 43 173
typenameGet 0 43 173
assign 1 43 174
IDGet 0 43 174
assign 1 43 175
equals 1 43 180
assign 1 0 181
assign 1 0 184
assign 1 0 188
assign 1 44 191
heldGet 0 44 191
assign 1 44 192
add 1 44 192
delete 0 45 193
fromString 1 47 195
heldSet 1 48 196
assign 1 49 197
nextDescendGet 0 49 197
return 1 49 198
assign 1 51 200
nextDescendGet 0 51 200
return 1 51 201
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 814639632: return bem_new_0();
case 648165913: return bem_print_0();
case -537857901: return bem_iteratorGet_0();
case 2036051133: return bem_tagGet_0();
case -125946934: return bem_serializeContents_0();
case -2049991627: return bem_once_0();
case 34035866: return bem_classNameGet_0();
case -2046784533: return bem_echo_0();
case -326152805: return bem_copy_0();
case -498367570: return bem_ntypesGet_0();
case 432735873: return bem_deserializeClassNameGet_0();
case -91772231: return bem_constGet_0();
case -1653307562: return bem_serializationIteratorGet_0();
case 2048361265: return bem_many_0();
case 717158289: return bem_fieldIteratorGet_0();
case -2089907154: return bem_create_0();
case -109602708: return bem_toString_0();
case -173186399: return bem_toAny_0();
case 1973131926: return bem_serializeToString_0();
case 99641680: return bem_sourceFileNameGet_0();
case -1556753014: return bem_buildGet_0();
case -2129255989: return bem_hashGet_0();
case -2106654919: return bem_transGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1091318965: return bem_defined_1(bevd_0);
case -1587074662: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 991182700: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1342415374: return bem_constSet_1(bevd_0);
case -1393267925: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 549239575: return bem_otherType_1(bevd_0);
case 755365358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -143017218: return bem_copyTo_1(bevd_0);
case -420585939: return bem_equals_1(bevd_0);
case -169401475: return bem_otherClass_1(bevd_0);
case 569199667: return bem_undefined_1(bevd_0);
case 1492255674: return bem_def_1(bevd_0);
case -1957594462: return bem_ntypesSet_1(bevd_0);
case -1038696049: return bem_transSet_1(bevd_0);
case 1940516897: return bem_sameClass_1(bevd_0);
case -1369439027: return bem_notEquals_1(bevd_0);
case -1052976456: return bem_begin_1(bevd_0);
case -2031862922: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -491345013: return bem_sameType_1(bevd_0);
case -1634298187: return bem_end_1(bevd_0);
case -1725813495: return bem_buildSet_1(bevd_0);
case -1887120745: return bem_sameObject_1(bevd_0);
case 1290400575: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1008056884: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1151786117: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1422666964: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 466148991: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1823742306: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -50371904: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 967378502: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass4_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass4_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass4();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst = (BEC_3_5_5_5_BuildVisitPass4) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;
}
}
}
