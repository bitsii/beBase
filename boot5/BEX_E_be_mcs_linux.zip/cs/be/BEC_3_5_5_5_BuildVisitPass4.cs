namespace be {
/* IO:File: source/build/Pass4.be */
public sealed class BEC_3_5_5_5_BuildVisitPass4 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass4() { }
static BEC_3_5_5_5_BuildVisitPass4() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x34};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass4_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x34,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass4_bels_0 = {0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x6E,0x61,0x6D,0x65,0x70,0x61,0x74,0x68};
public static new BEC_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass4 bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;

public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_5_4_BuildNode bevl_nnode = null;
BEC_2_4_6_TextString bevl_nps = null;
BEC_2_5_4_BuildNode bevl_nxn = null;
BEC_2_5_4_BuildNode bevl_nxnn = null;
BEC_2_5_4_BuildNode bevl_first = null;
BEC_2_5_8_BuildNamePath bevl_np = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
while (true)
 /* Line: 21 */ {
bevt_5_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_6_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_5_tmpany_phold.bevi_int == bevt_6_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 21 */ {
if (bevl_nnode == null) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 21 */
 else  /* Line: 21 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 21 */ {
bevt_9_tmpany_phold = bevl_nnode.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 21 */
 else  /* Line: 21 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 21 */ {
if (bevl_nps == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 22 */ {
bevl_nps = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 23 */
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevl_nps.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_nnode.bem_heldGet_0();
bevl_nps = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevl_nxn = bevl_nnode.bem_nextPeerGet_0();
if (bevl_nxn == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_17_tmpany_phold = bevl_nxn.bem_typenameGet_0();
bevt_18_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_17_tmpany_phold.bevi_int != bevt_18_tmpany_phold.bevi_int) {
bevt_16_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 27 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 27 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 27 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_3_5_5_5_BuildVisitPass4_bels_0));
bevt_19_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_20_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_19_tmpany_phold);
} /* Line: 28 */
bevl_nxnn = bevl_nxn.bem_nextPeerGet_0();
if (bevl_first == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 31 */ {
beva_node.bem_delete_0();
} /* Line: 32 */
 else  /* Line: 33 */ {
bevl_first = beva_node;
} /* Line: 34 */
bevl_nnode.bem_delete_0();
beva_node = bevl_nxn;
bevl_nnode = bevl_nxnn;
} /* Line: 38 */
 else  /* Line: 21 */ {
break;
} /* Line: 21 */
} /* Line: 21 */
if (bevl_first == null) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 40 */ {
bevt_23_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_first.bem_typenameSet_1(bevt_23_tmpany_phold);
bevl_np = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
if (beva_node == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_26_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_27_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_26_tmpany_phold.bevi_int == bevt_27_tmpany_phold.bevi_int) {
bevt_25_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_25_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_25_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 43 */
 else  /* Line: 43 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 43 */ {
bevt_28_tmpany_phold = beva_node.bem_heldGet_0();
bevl_nps = bevl_nps.bem_add_1(bevt_28_tmpany_phold);
beva_node.bem_delete_0();
} /* Line: 45 */
bevl_np.bem_fromString_1(bevl_nps);
bevl_first.bem_heldSet_1(bevl_np);
bevt_29_tmpany_phold = bevl_first.bem_nextDescendGet_0();
return bevt_29_tmpany_phold;
} /* Line: 49 */
bevt_30_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_30_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 20, 21, 21, 21, 21, 21, 21, 0, 0, 0, 21, 21, 21, 21, 0, 0, 0, 22, 22, 23, 25, 25, 25, 25, 26, 27, 27, 0, 27, 27, 27, 27, 0, 0, 28, 28, 28, 30, 31, 31, 32, 34, 36, 37, 38, 40, 40, 41, 41, 42, 43, 43, 43, 43, 43, 43, 0, 0, 0, 44, 44, 45, 47, 48, 49, 49, 51, 51};
public static new int[] bevs_smnlec
 = new int[] {14, 55, 58, 59, 60, 65, 66, 71, 72, 75, 79, 82, 83, 84, 89, 90, 93, 97, 100, 105, 106, 108, 109, 110, 111, 112, 113, 118, 119, 122, 123, 124, 129, 130, 133, 137, 138, 139, 141, 142, 147, 148, 151, 153, 154, 155, 161, 166, 167, 168, 169, 170, 175, 176, 177, 178, 183, 184, 187, 191, 194, 195, 196, 198, 199, 200, 201, 203, 204};
/* BEGIN LINEINFO 
begin 1 16 14
assign 1 20 55
nextPeerGet 0 20 55
assign 1 21 58
typenameGet 0 21 58
assign 1 21 59
IDGet 0 21 59
assign 1 21 60
equals 1 21 65
assign 1 21 66
def 1 21 71
assign 1 0 72
assign 1 0 75
assign 1 0 79
assign 1 21 82
typenameGet 0 21 82
assign 1 21 83
COLONGet 0 21 83
assign 1 21 84
equals 1 21 89
assign 1 0 90
assign 1 0 93
assign 1 0 97
assign 1 22 100
undef 1 22 105
assign 1 23 106
new 0 23 106
assign 1 25 108
heldGet 0 25 108
assign 1 25 109
add 1 25 109
assign 1 25 110
heldGet 0 25 110
assign 1 25 111
add 1 25 111
assign 1 26 112
nextPeerGet 0 26 112
assign 1 27 113
undef 1 27 118
assign 1 0 119
assign 1 27 122
typenameGet 0 27 122
assign 1 27 123
IDGet 0 27 123
assign 1 27 124
notEquals 1 27 129
assign 1 0 130
assign 1 0 133
assign 1 28 137
new 0 28 137
assign 1 28 138
new 2 28 138
throw 1 28 139
assign 1 30 141
nextPeerGet 0 30 141
assign 1 31 142
def 1 31 147
delete 0 32 148
assign 1 34 151
delete 0 36 153
assign 1 37 154
assign 1 38 155
assign 1 40 161
def 1 40 166
assign 1 41 167
NAMEPATHGet 0 41 167
typenameSet 1 41 168
assign 1 42 169
new 0 42 169
assign 1 43 170
def 1 43 175
assign 1 43 176
typenameGet 0 43 176
assign 1 43 177
IDGet 0 43 177
assign 1 43 178
equals 1 43 183
assign 1 0 184
assign 1 0 187
assign 1 0 191
assign 1 44 194
heldGet 0 44 194
assign 1 44 195
add 1 44 195
delete 0 45 196
fromString 1 47 198
heldSet 1 48 199
assign 1 49 200
nextDescendGet 0 49 200
return 1 49 201
assign 1 51 203
nextDescendGet 0 51 203
return 1 51 204
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1615839398: return bem_echo_0();
case 1614289356: return bem_buildGet_0();
case -1043543071: return bem_create_0();
case -1048585343: return bem_copy_0();
case -1800587860: return bem_serializeToString_0();
case 976768273: return bem_fieldNamesGet_0();
case 595030513: return bem_constGet_0();
case -2011984947: return bem_classNameGet_0();
case -193453355: return bem_iteratorGet_0();
case -477940854: return bem_hashGet_0();
case 1463816718: return bem_sourceFileNameGet_0();
case -1021558772: return bem_fieldIteratorGet_0();
case -1852647932: return bem_serializeContents_0();
case -135711625: return bem_ntypesGet_0();
case 190764838: return bem_toString_0();
case 795649196: return bem_serializationIteratorGet_0();
case 329087045: return bem_ntypesGetDirect_0();
case -204986197: return bem_print_0();
case 1853128990: return bem_transGetDirect_0();
case -1017732045: return bem_toAny_0();
case 1809869265: return bem_many_0();
case -24242301: return bem_buildGetDirect_0();
case 2022567405: return bem_tagGet_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -1200514874: return bem_once_0();
case 451316734: return bem_new_0();
case -352655218: return bem_constGetDirect_0();
case -427896902: return bem_transGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -538180832: return bem_buildSet_1(bevd_0);
case 897468448: return bem_end_1(bevd_0);
case -974417776: return bem_undef_1(bevd_0);
case -637875306: return bem_ntypesSetDirect_1(bevd_0);
case 1255352870: return bem_notEquals_1(bevd_0);
case 1585240367: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case -1896627249: return bem_buildSetDirect_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case 499229377: return bem_constSetDirect_1(bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 186986287: return bem_transSet_1(bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case -1722540916: return bem_constSet_1(bevd_0);
case 1177011462: return bem_transSetDirect_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -506913260: return bem_ntypesSet_1(bevd_0);
case 934483249: return bem_begin_1(bevd_0);
case -252330168: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass4_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass4_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass4();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst = (BEC_3_5_5_5_BuildVisitPass4) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass4.bece_BEC_3_5_5_5_BuildVisitPass4_bevs_type;
}
}
}
