namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator : BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
static BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;

public static new BET_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_emptyGet_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_containerGet_0() {
return bevp_str;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return bevp_str;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) {
bem_new_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) {
bevp_str = beva__str;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1267 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 1268 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1278 */ {
bevt_3_tmpany_phold = beva_buf.bem_capacityGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1279 */ {
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 1280 */
bevt_7_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_1;
if (bevt_7_tmpany_phold.bevi_int != bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1282 */ {
bevt_9_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_2;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_9_tmpany_phold.bevi_int = bevt_10_tmpany_phold.bevi_int;
} /* Line: 1283 */
bevt_12_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_13_tmpany_phold = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevp_pos.bevi_int++;
} /* Line: 1289 */
return beva_buf;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1295 */ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1297 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_3;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1303 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1303 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1303 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1303 */
 else  /* Line: 1303 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1303 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1306 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_4;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1312 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1312 */
 else  /* Line: 1312 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1312 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1315 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vcopyGet_0() {
return bevp_vcopy;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1243, 1243, 1243, 1247, 1251, 1255, 1260, 1261, 1262, 1267, 1267, 1267, 1268, 1268, 1270, 1270, 1274, 1274, 1274, 1274, 1278, 1278, 1278, 1279, 1279, 1279, 1279, 1280, 1280, 1282, 1282, 1282, 1282, 1283, 1283, 1283, 1283, 1285, 1285, 1285, 1289, 1291, 1295, 1295, 1295, 1296, 1297, 1299, 1303, 1303, 1303, 1303, 1303, 1303, 0, 0, 0, 1304, 1305, 1306, 1308, 1312, 1312, 1312, 1312, 1312, 1312, 0, 0, 0, 1313, 1314, 1315, 1321, 1325, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 28, 32, 35, 38, 42, 43, 44, 52, 53, 58, 59, 60, 62, 63, 69, 70, 71, 72, 91, 92, 97, 98, 99, 100, 105, 106, 107, 109, 110, 111, 116, 117, 118, 119, 120, 122, 123, 124, 125, 127, 132, 133, 138, 139, 140, 142, 150, 151, 156, 157, 158, 163, 164, 167, 171, 174, 175, 176, 178, 186, 187, 192, 193, 194, 199, 200, 203, 207, 210, 211, 212, 217, 220, 223, 226, 230, 233, 237, 240};
/* BEGIN LINEINFO 
assign 1 1243 26
new 0 1243 26
assign 1 1243 27
emptyGet 0 1243 27
new 1 1243 28
return 1 1247 32
return 1 1251 35
new 1 1255 38
assign 1 1260 42
assign 1 1261 43
new 0 1261 43
assign 1 1262 44
new 0 1262 44
assign 1 1267 52
sizeGet 0 1267 52
assign 1 1267 53
greater 1 1267 58
assign 1 1268 59
new 0 1268 59
return 1 1268 60
assign 1 1270 62
new 0 1270 62
return 1 1270 63
assign 1 1274 69
new 0 1274 69
assign 1 1274 70
new 1 1274 70
assign 1 1274 71
next 1 1274 71
return 1 1274 72
assign 1 1278 91
sizeGet 0 1278 91
assign 1 1278 92
greater 1 1278 97
assign 1 1279 98
capacityGet 0 1279 98
assign 1 1279 99
new 0 1279 99
assign 1 1279 100
lesser 1 1279 105
assign 1 1280 106
new 0 1280 106
capacitySet 1 1280 107
assign 1 1282 109
sizeGet 0 1282 109
assign 1 1282 110
new 0 1282 110
assign 1 1282 111
notEquals 1 1282 116
assign 1 1283 117
sizeGet 0 1283 117
assign 1 1283 118
new 0 1283 118
assign 1 1283 119
once 0 1283 119
setValue 1 1283 120
assign 1 1285 122
new 0 1285 122
assign 1 1285 123
getInt 2 1285 123
setIntUnchecked 2 1285 124
incrementValue 0 1289 125
return 1 1291 127
assign 1 1295 132
sizeGet 0 1295 132
assign 1 1295 133
greater 1 1295 138
getInt 2 1296 139
incrementValue 0 1297 140
return 1 1299 142
assign 1 1303 150
new 0 1303 150
assign 1 1303 151
greater 1 1303 156
assign 1 1303 157
sizeGet 0 1303 157
assign 1 1303 158
greaterEquals 1 1303 163
assign 1 0 164
assign 1 0 167
assign 1 0 171
decrementValue 0 1304 174
getInt 2 1305 175
incrementValue 0 1306 176
return 1 1308 178
assign 1 1312 186
new 0 1312 186
assign 1 1312 187
greater 1 1312 192
assign 1 1312 193
sizeGet 0 1312 193
assign 1 1312 194
greaterEquals 1 1312 199
assign 1 0 200
assign 1 0 203
assign 1 0 207
decrementValue 0 1313 210
setIntUnchecked 2 1314 211
incrementValue 0 1315 212
return 1 1321 217
return 1 1325 220
return 1 0 223
assign 1 0 226
return 1 0 230
assign 1 0 233
return 1 0 237
assign 1 0 240
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 655034069: return bem_hasNextGet_0();
case 1595614817: return bem_strGet_0();
case 645227528: return bem_copy_0();
case 1805899516: return bem_many_0();
case -414566530: return bem_fieldIteratorGet_0();
case -1353189684: return bem_nextGet_0();
case 1501620573: return bem_deserializeClassNameGet_0();
case -439307572: return bem_hashGet_0();
case 1991051685: return bem_print_0();
case 679443271: return bem_posGet_0();
case 840040982: return bem_byteIteratorIteratorGet_0();
case -2067310143: return bem_create_0();
case -1791312022: return bem_serializationIteratorGet_0();
case 1163377727: return bem_toAny_0();
case 1754190679: return bem_classNameGet_0();
case 1193477558: return bem_new_0();
case -1466347886: return bem_serializeContents_0();
case 793830133: return bem_tagGet_0();
case -637230318: return bem_serializeToString_0();
case 956121033: return bem_sourceFileNameGet_0();
case -213541934: return bem_echo_0();
case -1889481920: return bem_once_0();
case 153829440: return bem_iteratorGet_0();
case 491585243: return bem_toString_0();
case 280144602: return bem_containerGet_0();
case 1975539344: return bem_vcopyGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -640546150: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -505152552: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1603994454: return bem_sameType_1(bevd_0);
case 279657909: return bem_equals_1(bevd_0);
case 1267197459: return bem_otherType_1(bevd_0);
case -96529364: return bem_vcopySet_1(bevd_0);
case 1963771415: return bem_undef_1(bevd_0);
case 100980215: return bem_otherClass_1(bevd_0);
case 1114375968: return bem_sameClass_1(bevd_0);
case -1504728618: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 97215820: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1314037522: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2087355822: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case -287855524: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -704128729: return bem_copyTo_1(bevd_0);
case 385893729: return bem_undefined_1(bevd_0);
case 1979194181: return bem_notEquals_1(bevd_0);
case 1596320235: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -50655885: return bem_posSet_1(bevd_0);
case -1871751942: return bem_def_1(bevd_0);
case 578085643: return bem_strSet_1(bevd_0);
case -1192171297: return bem_defined_1(bevd_0);
case 1979729498: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case 417172649: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1596177832: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1919067749: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1086524794: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1313996982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1153243887: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 966288160: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -962439482: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_TextByteIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_type;
}
}
}
