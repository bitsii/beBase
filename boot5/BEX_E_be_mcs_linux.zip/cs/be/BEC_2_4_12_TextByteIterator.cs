namespace be {

using System.IO;
using System;
    /* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator : BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
static BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;
public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_emptyGet_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_containerGet_0() {
return bevp_str;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
return bevp_str;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) {
bem_new_1(beva_str);
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) {
bevp_str = beva__str;
bevp_pos = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_hasNextGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1274 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 1275 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_nextGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1285 */ {
bevt_3_tmpany_phold = beva_buf.bem_capacityGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1286 */ {
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 1287 */
bevt_7_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_1;
if (bevt_7_tmpany_phold.bevi_int != bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1289 */ {
bevt_9_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_2;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_9_tmpany_phold.bevi_int = bevt_10_tmpany_phold.bevi_int;
} /* Line: 1290 */
bevt_12_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_13_tmpany_phold = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevp_pos.bevi_int++;
} /* Line: 1296 */
return beva_buf;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1302 */ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1304 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_3;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1310 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1310 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1310 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1310 */
 else  /* Line: 1310 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1310 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1313 */
return beva_into;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_4;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1319 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1319 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1319 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1319 */
 else  /* Line: 1319 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1319 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1322 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_iteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_posGet_0() {
return bevp_pos;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_vcopyGet_0() {
return bevp_vcopy;
} /*method end*/
public virtual BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {1250, 1250, 1250, 1254, 1258, 1262, 1267, 1268, 1269, 1274, 1274, 1274, 1275, 1275, 1277, 1277, 1281, 1281, 1281, 1281, 1285, 1285, 1285, 1286, 1286, 1286, 1286, 1287, 1287, 1289, 1289, 1289, 1289, 1290, 1290, 1290, 1290, 1292, 1292, 1292, 1296, 1298, 1302, 1302, 1302, 1303, 1304, 1306, 1310, 1310, 1310, 1310, 1310, 1310, 0, 0, 0, 1311, 1312, 1313, 1315, 1319, 1319, 1319, 1319, 1319, 1319, 0, 0, 0, 1320, 1321, 1322, 1328, 1332, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {23, 24, 25, 29, 32, 35, 39, 40, 41, 49, 50, 55, 56, 57, 59, 60, 66, 67, 68, 69, 88, 89, 94, 95, 96, 97, 102, 103, 104, 106, 107, 108, 113, 114, 115, 116, 117, 119, 120, 121, 122, 124, 129, 130, 135, 136, 137, 139, 147, 148, 153, 154, 155, 160, 161, 164, 168, 171, 172, 173, 175, 183, 184, 189, 190, 191, 196, 197, 200, 204, 207, 208, 209, 214, 217, 220, 223, 227, 230, 234, 237};
/* BEGIN LINEINFO 
assign 1 1250 23
new 0 1250 23
assign 1 1250 24
emptyGet 0 1250 24
new 1 1250 25
return 1 1254 29
return 1 1258 32
new 1 1262 35
assign 1 1267 39
assign 1 1268 40
new 0 1268 40
assign 1 1269 41
new 0 1269 41
assign 1 1274 49
sizeGet 0 1274 49
assign 1 1274 50
greater 1 1274 55
assign 1 1275 56
new 0 1275 56
return 1 1275 57
assign 1 1277 59
new 0 1277 59
return 1 1277 60
assign 1 1281 66
new 0 1281 66
assign 1 1281 67
new 1 1281 67
assign 1 1281 68
next 1 1281 68
return 1 1281 69
assign 1 1285 88
sizeGet 0 1285 88
assign 1 1285 89
greater 1 1285 94
assign 1 1286 95
capacityGet 0 1286 95
assign 1 1286 96
new 0 1286 96
assign 1 1286 97
lesser 1 1286 102
assign 1 1287 103
new 0 1287 103
capacitySet 1 1287 104
assign 1 1289 106
sizeGet 0 1289 106
assign 1 1289 107
new 0 1289 107
assign 1 1289 108
notEquals 1 1289 113
assign 1 1290 114
sizeGet 0 1290 114
assign 1 1290 115
new 0 1290 115
assign 1 1290 116
once 0 1290 116
setValue 1 1290 117
assign 1 1292 119
new 0 1292 119
assign 1 1292 120
getInt 2 1292 120
setIntUnchecked 2 1292 121
incrementValue 0 1296 122
return 1 1298 124
assign 1 1302 129
sizeGet 0 1302 129
assign 1 1302 130
greater 1 1302 135
getInt 2 1303 136
incrementValue 0 1304 137
return 1 1306 139
assign 1 1310 147
new 0 1310 147
assign 1 1310 148
greater 1 1310 153
assign 1 1310 154
sizeGet 0 1310 154
assign 1 1310 155
greaterEquals 1 1310 160
assign 1 0 161
assign 1 0 164
assign 1 0 168
decrementValue 0 1311 171
getInt 2 1312 172
incrementValue 0 1313 173
return 1 1315 175
assign 1 1319 183
new 0 1319 183
assign 1 1319 184
greater 1 1319 189
assign 1 1319 190
sizeGet 0 1319 190
assign 1 1319 191
greaterEquals 1 1319 196
assign 1 0 197
assign 1 0 200
assign 1 0 204
decrementValue 0 1320 207
setIntUnchecked 2 1321 208
incrementValue 0 1322 209
return 1 1328 214
return 1 1332 217
return 1 0 220
assign 1 0 223
return 1 0 227
assign 1 0 230
return 1 0 234
assign 1 0 237
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 460304834: return bem_fieldIteratorGet_0();
case -896397486: return bem_hasNextGet_0();
case 607966049: return bem_serializationIteratorGet_0();
case -1887743737: return bem_nextGet_0();
case -1533121038: return bem_new_0();
case 1750235236: return bem_posGet_0();
case -853598946: return bem_serializeContents_0();
case -1233972717: return bem_create_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 1307328857: return bem_toAny_0();
case -827921680: return bem_copy_0();
case 1165489654: return bem_sourceFileNameGet_0();
case -122775537: return bem_containerGet_0();
case 466290922: return bem_iteratorGet_0();
case -711691351: return bem_deserializeClassNameGet_0();
case 1828895957: return bem_byteIteratorIteratorGet_0();
case -590451146: return bem_serializeToString_0();
case -1400076579: return bem_strGet_0();
case -1802544452: return bem_many_0();
case -1801684996: return bem_vcopyGet_0();
case 247385301: return bem_toString_0();
case 210264567: return bem_print_0();
case 2043795865: return bem_echo_0();
case 212191548: return bem_tagGet_0();
case -315420442: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 172009000: return bem_otherType_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -726071522: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case 1241843161: return bem_vcopySet_1(bevd_0);
case -1093669483: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case -879845111: return bem_posSet_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case -2140515558: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case -1287998003: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case -258973210: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1540014117: return bem_strSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_12_TextByteIterator();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
}
}
