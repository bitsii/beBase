namespace be {

using System;
    /* IO:File: source/base/Object.be */
public class BEC_2_6_8_SystemVariadic : BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemVariadic() { }
static BEC_2_6_8_SystemVariadic() { }
private static byte[] becc_BEC_2_6_8_SystemVariadic_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x56,0x61,0x72,0x69,0x61,0x64,0x69,0x63};
private static byte[] becc_BEC_2_6_8_SystemVariadic_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2E,0x62,0x65};
public static new BEC_2_6_8_SystemVariadic bece_BEC_2_6_8_SystemVariadic_bevs_inst;

public static new BET_2_6_8_SystemVariadic bece_BEC_2_6_8_SystemVariadic_bevs_type;

public sealed override BEC_2_6_6_SystemObject bem_forwardCall_2(BEC_2_4_6_TextString beva_name, BEC_2_9_4_ContainerList beva_args) {
BEC_2_9_4_ContainerList bevl_varargs = null;
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = bem_can_2(beva_name, bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 918*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_varargs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_varargs.bem_put_2(bevt_3_ta_ph, beva_args);
bevl_result = bem_invoke_2(beva_name, bevl_varargs);
} /* Line: 921*/
return bevl_result;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {918, 918, 919, 919, 920, 920, 921, 923};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 24, 25, 26, 27, 28, 30};
/* BEGIN LINEINFO 
assign 1 918 21
new 0 918 21
assign 1 918 22
can 2 918 22
assign 1 919 24
new 0 919 24
assign 1 919 25
new 1 919 25
assign 1 920 26
new 0 920 26
put 2 920 27
assign 1 921 28
invoke 2 921 28
return 1 923 30
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1363819567: return bem_new_0();
case -467511392: return bem_toString_0();
case -793241295: return bem_iteratorGet_0();
case 1890854002: return bem_tagGet_0();
case -447432319: return bem_many_0();
case -105946774: return bem_serializeToString_0();
case -1760538533: return bem_classNameGet_0();
case -1323898541: return bem_toAny_0();
case -1188922735: return bem_echo_0();
case 1092105192: return bem_hashGet_0();
case 1652521523: return bem_serializeContents_0();
case 1319388306: return bem_copy_0();
case -921473949: return bem_fieldNamesGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case 1597327951: return bem_create_0();
case 7254011: return bem_fieldIteratorGet_0();
case 895193825: return bem_once_0();
case -1387831588: return bem_print_0();
case 371157924: return bem_sourceFileNameGet_0();
case -39165288: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1488511778: return bem_otherType_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemVariadic_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemVariadic_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_8_SystemVariadic();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_inst = (BEC_2_6_8_SystemVariadic) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_8_SystemVariadic.bece_BEC_2_6_8_SystemVariadic_bevs_type;
}
}
}
