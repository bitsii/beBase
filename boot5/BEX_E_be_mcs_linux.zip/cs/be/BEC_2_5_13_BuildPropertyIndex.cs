namespace be {
/* IO:File: source/build/EmitData.be */
public sealed class BEC_2_5_13_BuildPropertyIndex : BEC_2_6_6_SystemObject {
public BEC_2_5_13_BuildPropertyIndex() { }
static BEC_2_5_13_BuildPropertyIndex() { }
private static byte[] becc_BEC_2_5_13_BuildPropertyIndex_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x72,0x6F,0x70,0x65,0x72,0x74,0x79,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_BEC_2_5_13_BuildPropertyIndex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static new BEC_2_5_13_BuildPropertyIndex bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst;

public static new BET_2_5_13_BuildPropertyIndex bece_BEC_2_5_13_BuildPropertyIndex_bevs_type;

public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildPtySyn bevp_psyn;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_13_BuildPropertyIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildPtySyn beva__psyn) {
bevp_syn = beva__syn;
bevp_psyn = beva__psyn;
bevp_origin = bevp_psyn.bem_originGet_0();
bevp_name = bevp_psyn.bem_nameGet_0();
return this;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_origin.bem_toString_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_4_tmpany_phold = bem_sameClass_1(beva_x);
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 87 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 87 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 87 */ {
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /* Line: 87 */
bevt_7_tmpany_phold = beva_x.bemd_0(-506173631);
bevt_6_tmpany_phold = bevp_origin.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_9_tmpany_phold = beva_x.bemd_0(-1266568377);
bevt_8_tmpany_phold = bevp_name.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
 else  /* Line: 88 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 88 */ {
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 89 */
bevt_11_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGetDirect_0() {
return bevp_syn;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_synSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_psynGet_0() {
return bevp_psyn;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_psynGetDirect_0() {
return bevp_psyn;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_psynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_psyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_psynSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_psyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGetDirect_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_originSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGetDirect_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_13_BuildPropertyIndex bem_nameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {75, 76, 77, 78, 83, 83, 83, 83, 87, 87, 0, 87, 87, 87, 0, 0, 87, 87, 88, 88, 88, 88, 0, 0, 0, 89, 89, 91, 91, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 18, 19, 20, 27, 28, 29, 30, 45, 50, 51, 54, 55, 60, 61, 64, 68, 69, 71, 72, 74, 75, 77, 80, 84, 87, 88, 90, 91, 94, 97, 100, 104, 108, 111, 114, 118, 122, 125, 128, 132, 136, 139, 142, 146};
/* BEGIN LINEINFO 
assign 1 75 17
assign 1 76 18
assign 1 77 19
originGet 0 77 19
assign 1 78 20
nameGet 0 78 20
assign 1 83 27
toString 0 83 27
assign 1 83 28
add 1 83 28
assign 1 83 29
hashGet 0 83 29
return 1 83 30
assign 1 87 45
undef 1 87 50
assign 1 0 51
assign 1 87 54
sameClass 1 87 54
assign 1 87 55
not 0 87 60
assign 1 0 61
assign 1 0 64
assign 1 87 68
new 0 87 68
return 1 87 69
assign 1 88 71
originGet 0 88 71
assign 1 88 72
equals 1 88 72
assign 1 88 74
nameGet 0 88 74
assign 1 88 75
equals 1 88 75
assign 1 0 77
assign 1 0 80
assign 1 0 84
assign 1 89 87
new 0 89 87
return 1 89 88
assign 1 91 90
new 0 91 90
return 1 91 91
return 1 0 94
return 1 0 97
assign 1 0 100
assign 1 0 104
return 1 0 108
return 1 0 111
assign 1 0 114
assign 1 0 118
return 1 0 122
return 1 0 125
assign 1 0 128
assign 1 0 132
return 1 0 136
return 1 0 139
assign 1 0 142
assign 1 0 146
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2049921022: return bem_serializeContents_0();
case 1610207827: return bem_serializeToString_0();
case 330207183: return bem_once_0();
case 722156191: return bem_create_0();
case 1989082937: return bem_originGetDirect_0();
case -627661593: return bem_serializationIteratorGet_0();
case -512259678: return bem_many_0();
case -808549585: return bem_classNameGet_0();
case 1280430641: return bem_deserializeClassNameGet_0();
case -796966532: return bem_print_0();
case -2127113784: return bem_sourceFileNameGet_0();
case 361089340: return bem_nameGetDirect_0();
case -506173631: return bem_originGet_0();
case -374298812: return bem_iteratorGet_0();
case 701763907: return bem_new_0();
case -1612673222: return bem_echo_0();
case 561389448: return bem_copy_0();
case -196471174: return bem_toAny_0();
case -751296258: return bem_toString_0();
case -1505814666: return bem_synGet_0();
case -1266568377: return bem_nameGet_0();
case 70409796: return bem_fieldIteratorGet_0();
case -555212086: return bem_psynGetDirect_0();
case -2037366749: return bem_psynGet_0();
case 441719677: return bem_hashGet_0();
case 1797387357: return bem_synGetDirect_0();
case 73901351: return bem_fieldNamesGet_0();
case -1391094119: return bem_tagGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 803653343: return bem_otherClass_1(bevd_0);
case 320818251: return bem_synSet_1(bevd_0);
case 230128579: return bem_originSetDirect_1(bevd_0);
case 680756917: return bem_defined_1(bevd_0);
case -191286971: return bem_def_1(bevd_0);
case 522911521: return bem_nameSetDirect_1(bevd_0);
case 1649757588: return bem_sameObject_1(bevd_0);
case -466786371: return bem_psynSet_1(bevd_0);
case -1934236484: return bem_sameType_1(bevd_0);
case 1645946581: return bem_notEquals_1(bevd_0);
case -444555333: return bem_originSet_1(bevd_0);
case -1380437617: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1110748051: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1587984688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -750020170: return bem_nameSet_1(bevd_0);
case -976067654: return bem_synSetDirect_1(bevd_0);
case -1197345309: return bem_otherType_1(bevd_0);
case 1685458284: return bem_psynSetDirect_1(bevd_0);
case -1668696125: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 788956945: return bem_undefined_1(bevd_0);
case -1272706644: return bem_copyTo_1(bevd_0);
case 1320952802: return bem_sameClass_1(bevd_0);
case 463890253: return bem_undef_1(bevd_0);
case 725850689: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 235947300: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2053867671: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1365336246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1806210068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2137630710: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1094925459: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1242672538: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 228296778: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildPtySyn) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_5_13_BuildPropertyIndex_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_13_BuildPropertyIndex_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_13_BuildPropertyIndex();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_13_BuildPropertyIndex.bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst = (BEC_2_5_13_BuildPropertyIndex) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_13_BuildPropertyIndex.bece_BEC_2_5_13_BuildPropertyIndex_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_13_BuildPropertyIndex.bece_BEC_2_5_13_BuildPropertyIndex_bevs_type;
}
}
}
