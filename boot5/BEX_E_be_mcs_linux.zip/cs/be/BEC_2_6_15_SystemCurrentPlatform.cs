namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 565 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 566 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                bem_setName_1(bevl_platformName);
} /* Line: 589 */
} /* Line: 566 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-1803541240, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {566, 566, 589, 595, 596, 600, 601, 602};
public static new int[] bevs_smnlec
 = new int[] {24, 29, 32, 38, 39, 44, 45, 46};
/* BEGIN LINEINFO 
assign 1 566 24
undef 1 566 29
setName 1 589 32
assign 1 595 38
buildProfile 0 596 39
buildProfile 0 600 44
assign 1 601 45
new 0 601 45
newlineSet 1 602 46
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1398921000: return bem_properNameGetDirect_0();
case -1785240001: return bem_isNixGetDirect_0();
case -1610742202: return bem_create_0();
case 88607008: return bem_buildProfile_0();
case 329044611: return bem_fieldNamesGet_0();
case 812544411: return bem_echo_0();
case -1392934237: return bem_nullFileGetDirect_0();
case 705622040: return bem_sourceFileNameGet_0();
case 538389441: return bem_serializeToString_0();
case 334648449: return bem_serializationIteratorGet_0();
case -2018625055: return bem_newlineGetDirect_0();
case -1032171260: return bem_toString_0();
case -1002145468: return bem_separatorGet_0();
case -1006908471: return bem_serializeContents_0();
case -1509690672: return bem_iteratorGet_0();
case 1929688279: return bem_classNameGet_0();
case -573094479: return bem_default_0();
case 2098994482: return bem_hashGet_0();
case 1764716287: return bem_once_0();
case -15833891: return bem_otherSeparatorGetDirect_0();
case 1669654091: return bem_many_0();
case 281585293: return bem_toAny_0();
case 1176956503: return bem_isWinGetDirect_0();
case -1101624703: return bem_deserializeClassNameGet_0();
case 338184512: return bem_nameGetDirect_0();
case 2098483713: return bem_copy_0();
case -1174925923: return bem_properNameGet_0();
case 1742185123: return bem_nullFileGet_0();
case 1163805126: return bem_new_0();
case -64622528: return bem_nameGet_0();
case 1469211738: return bem_scriptExtGetDirect_0();
case -1058456741: return bem_print_0();
case 363124745: return bem_isNixGet_0();
case -928621747: return bem_scriptExtGet_0();
case -98046751: return bem_tagGet_0();
case 549588551: return bem_separatorGetDirect_0();
case 1581514958: return bem_isWinGet_0();
case -1200865790: return bem_otherSeparatorGet_0();
case 1517255590: return bem_newlineGet_0();
case 1945143392: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -552618200: return bem_isWinSet_1(bevd_0);
case -1446306055: return bem_otherClass_1(bevd_0);
case 1224467768: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1231186391: return bem_properNameSetDirect_1(bevd_0);
case -910748938: return bem_nameSet_1(bevd_0);
case -1685877365: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1867834674: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 422747206: return bem_isWinSetDirect_1(bevd_0);
case -1524968669: return bem_sameClass_1(bevd_0);
case 621867969: return bem_isNixSet_1(bevd_0);
case 1300185187: return bem_undefined_1(bevd_0);
case -1803541240: return bem_newlineSet_1(bevd_0);
case 1863898392: return bem_equals_1(bevd_0);
case -1207491940: return bem_undef_1(bevd_0);
case 714503183: return bem_sameObject_1(bevd_0);
case 1866386185: return bem_otherSeparatorSetDirect_1(bevd_0);
case 220285540: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1538927011: return bem_copyTo_1(bevd_0);
case 613414930: return bem_def_1(bevd_0);
case 1659997139: return bem_newlineSetDirect_1(bevd_0);
case -1207750017: return bem_scriptExtSet_1(bevd_0);
case 144236239: return bem_separatorSet_1(bevd_0);
case -1799696087: return bem_isNixSetDirect_1(bevd_0);
case 2108235391: return bem_defined_1(bevd_0);
case -833799554: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 99127990: return bem_otherType_1(bevd_0);
case -2030024538: return bem_separatorSetDirect_1(bevd_0);
case -476652102: return bem_properNameSet_1(bevd_0);
case -1776959106: return bem_notEquals_1(bevd_0);
case 1837978646: return bem_sameType_1(bevd_0);
case -1350275429: return bem_nullFileSet_1(bevd_0);
case -1655565442: return bem_nullFileSetDirect_1(bevd_0);
case -896314276: return bem_scriptExtSetDirect_1(bevd_0);
case 1664856070: return bem_nameSetDirect_1(bevd_0);
case -1071316890: return bem_otherSeparatorSet_1(bevd_0);
case 2135267306: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -903966108: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1997741826: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 937271141: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -906378356: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -319646499: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 395811446: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1670352859: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
