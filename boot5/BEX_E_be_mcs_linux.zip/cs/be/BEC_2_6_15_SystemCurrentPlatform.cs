namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 566 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 567 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                bem_setName_1(bevl_platformName);
} /* Line: 585 */
} /* Line: 567 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(2004694593, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {567, 567, 585, 591, 592, 596, 597, 598};
public static new int[] bevs_smnlec
 = new int[] {21, 26, 29, 35, 36, 41, 42, 43};
/* BEGIN LINEINFO 
assign 1 567 21
undef 1 567 26
setName 1 585 29
assign 1 591 35
buildProfile 0 592 36
buildProfile 0 596 41
assign 1 597 42
new 0 597 42
newlineSet 1 598 43
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 415457465: return bem_isWinGet_0();
case -1246807392: return bem_isNixGet_0();
case 837017905: return bem_newlineGet_0();
case -585577712: return bem_nameGet_0();
case 210264567: return bem_print_0();
case 2043795865: return bem_echo_0();
case 1165489654: return bem_sourceFileNameGet_0();
case -1233972717: return bem_create_0();
case -457338511: return bem_buildProfile_0();
case 212191548: return bem_tagGet_0();
case -590451146: return bem_serializeToString_0();
case -493602221: return bem_separatorGet_0();
case -1569136637: return bem_default_0();
case -315420442: return bem_once_0();
case -1533121038: return bem_new_0();
case 607966049: return bem_serializationIteratorGet_0();
case 1856867090: return bem_nullFileGet_0();
case -827921680: return bem_copy_0();
case 466290922: return bem_iteratorGet_0();
case 247385301: return bem_toString_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -853598946: return bem_serializeContents_0();
case -1802544452: return bem_many_0();
case 460304834: return bem_fieldIteratorGet_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 2069256607: return bem_otherSeparatorGet_0();
case 1307328857: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -170563302: return bem_equals_1(bevd_0);
case -2121242222: return bem_isWinSet_1(bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case -1287998003: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case 2004694593: return bem_newlineSet_1(bevd_0);
case -1817072358: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case 1901802535: return bem_isNixSet_1(bevd_0);
case 1673152110: return bem_nameSet_1(bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case 1324596315: return bem_otherSeparatorSet_1(bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case -49501406: return bem_separatorSet_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 895818184: return bem_nullFileSet_1(bevd_0);
case 172009000: return bem_otherType_1(bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
}
}
