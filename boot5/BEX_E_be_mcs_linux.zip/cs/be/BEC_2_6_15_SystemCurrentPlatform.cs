namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 566 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 567 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                bem_setName_1(bevl_platformName);
} /* Line: 585 */
} /* Line: 567 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-988301239, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {567, 567, 585, 591, 592, 596, 597, 598};
public static new int[] bevs_smnlec
 = new int[] {24, 29, 32, 38, 39, 44, 45, 46};
/* BEGIN LINEINFO 
assign 1 567 24
undef 1 567 29
setName 1 585 32
assign 1 591 38
buildProfile 0 592 39
buildProfile 0 596 44
assign 1 597 45
new 0 597 45
newlineSet 1 598 46
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -825084265: return bem_hashGet_0();
case -1137777420: return bem_newlineGetDirect_0();
case 292121075: return bem_newlineGet_0();
case 911313117: return bem_tagGet_0();
case 301240201: return bem_nullFileGet_0();
case -1485517163: return bem_copy_0();
case -1325811464: return bem_separatorGet_0();
case 359395256: return bem_otherSeparatorGetDirect_0();
case 1279906777: return bem_serializeToString_0();
case -768719948: return bem_default_0();
case 343375430: return bem_create_0();
case -118700211: return bem_isNixGetDirect_0();
case -1846550974: return bem_serializeContents_0();
case 131226213: return bem_toString_0();
case -928163909: return bem_fieldIteratorGet_0();
case -1578959441: return bem_nameGet_0();
case 421749162: return bem_iteratorGet_0();
case -2051799514: return bem_new_0();
case -1574932366: return bem_print_0();
case -506841498: return bem_separatorGetDirect_0();
case -948115800: return bem_nullFileGetDirect_0();
case 1253953314: return bem_serializationIteratorGet_0();
case 1131385505: return bem_toAny_0();
case -1031399474: return bem_echo_0();
case -255010795: return bem_isWinGetDirect_0();
case 1970758688: return bem_fieldNamesGet_0();
case 75942308: return bem_isNixGet_0();
case -683035719: return bem_nameGetDirect_0();
case 1868148136: return bem_isWinGet_0();
case -691269362: return bem_otherSeparatorGet_0();
case 444338064: return bem_buildProfile_0();
case 2061421621: return bem_many_0();
case -957769093: return bem_deserializeClassNameGet_0();
case 916294969: return bem_sourceFileNameGet_0();
case 2063546474: return bem_classNameGet_0();
case 431618869: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -630005848: return bem_isNixSetDirect_1(bevd_0);
case -1181240679: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1874820931: return bem_otherSeparatorSetDirect_1(bevd_0);
case -594447159: return bem_isNixSet_1(bevd_0);
case -1551421646: return bem_copyTo_1(bevd_0);
case -1786953640: return bem_newlineSetDirect_1(bevd_0);
case 1383324451: return bem_sameObject_1(bevd_0);
case 1889683305: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -394926495: return bem_otherSeparatorSet_1(bevd_0);
case -1809169317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1768644351: return bem_sameClass_1(bevd_0);
case -2018944701: return bem_def_1(bevd_0);
case -628476976: return bem_otherClass_1(bevd_0);
case 192530319: return bem_otherType_1(bevd_0);
case -666985325: return bem_nameSet_1(bevd_0);
case -1831727202: return bem_nameSetDirect_1(bevd_0);
case -1655018142: return bem_sameType_1(bevd_0);
case -1065536512: return bem_equals_1(bevd_0);
case 1044863323: return bem_defined_1(bevd_0);
case 747155616: return bem_notEquals_1(bevd_0);
case -436556280: return bem_undef_1(bevd_0);
case 1594270255: return bem_nullFileSet_1(bevd_0);
case -720239840: return bem_nullFileSetDirect_1(bevd_0);
case -483787638: return bem_isWinSet_1(bevd_0);
case 1147111468: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1017587433: return bem_isWinSetDirect_1(bevd_0);
case 2007044781: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -1192291041: return bem_separatorSet_1(bevd_0);
case 1928047187: return bem_undefined_1(bevd_0);
case -988301239: return bem_newlineSet_1(bevd_0);
case -58656156: return bem_separatorSetDirect_1(bevd_0);
case 1555616281: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1990600260: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1260241587: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -598891548: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1655882914: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1041029455: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -214435591: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -40143354: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
