namespace be {

using System;
// for threading
using System.Threading;
    /* IO:File: source/base/ExtSystem.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
/* Line: 267*/ {
if (bevp_name == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 268*/ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                /* Line: 283*/ {
} /* Line: 284*/
/* Line: 291*/ {
} /* Line: 292*/
bem_setName_1(bevl_platformName);
} /* Line: 298*/
} /* Line: 268*/
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(1862516154, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {268, 268, 298, 304, 305, 309, 310, 311};
public static new int[] bevs_smnlec
 = new int[] {23, 28, 35, 41, 42, 47, 48, 49};
/* BEGIN LINEINFO 
assign 1 268 23
undef 1 268 28
setName 1 298 35
assign 1 304 41
buildProfile 0 305 42
buildProfile 0 309 47
assign 1 310 48
new 0 310 48
newlineSet 1 311 49
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1931705863: return bem_sourceFileNameGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -2118708930: return bem_new_0();
case 1262410674: return bem_nullFileGetDirect_0();
case -963230268: return bem_properNameGet_0();
case -829143300: return bem_newlineGetDirect_0();
case -40905183: return bem_echo_0();
case 271468176: return bem_separatorGet_0();
case 2081363871: return bem_copy_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1834246217: return bem_classNameGet_0();
case 1153595261: return bem_separatorGetDirect_0();
case 1673575436: return bem_otherSeparatorGetDirect_0();
case 1303360016: return bem_otherSeparatorGet_0();
case -84091751: return bem_isNixGet_0();
case -893093197: return bem_toString_0();
case -1563238662: return bem_scriptExtGet_0();
case 1156217229: return bem_isWinGet_0();
case 954703233: return bem_create_0();
case -644221652: return bem_properNameGetDirect_0();
case -193582610: return bem_tagGet_0();
case 1153344161: return bem_serializeContents_0();
case 1314357064: return bem_buildProfile_0();
case -1076915155: return bem_serializeToString_0();
case 1974505938: return bem_hashGet_0();
case 421177749: return bem_print_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case -1653939165: return bem_iteratorGet_0();
case 356175325: return bem_scriptExtGetDirect_0();
case -975498393: return bem_fieldNamesGet_0();
case -487191921: return bem_default_0();
case 708276900: return bem_nameGetDirect_0();
case 1437514936: return bem_nameGet_0();
case 573696882: return bem_isNixGetDirect_0();
case 1187317145: return bem_nullFileGet_0();
case 234082358: return bem_newlineGet_0();
case -1657157988: return bem_isWinGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 177409367: return bem_otherType_1(bevd_0);
case -1128236438: return bem_scriptExtSet_1(bevd_0);
case -1733703364: return bem_nullFileSetDirect_1(bevd_0);
case 444024787: return bem_properNameSetDirect_1(bevd_0);
case -1413222961: return bem_nullFileSet_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 1862516154: return bem_newlineSet_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -410919302: return bem_properNameSet_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 931950033: return bem_newlineSetDirect_1(bevd_0);
case -375564770: return bem_nameSetDirect_1(bevd_0);
case -1723186037: return bem_isNixSetDirect_1(bevd_0);
case 584496470: return bem_separatorSet_1(bevd_0);
case -1605500141: return bem_otherSeparatorSetDirect_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 1350643834: return bem_scriptExtSetDirect_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 59504167: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 1098483927: return bem_separatorSetDirect_1(bevd_0);
case -647298623: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case -1441143043: return bem_isWinSet_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1982758379: return bem_isWinSetDirect_1(bevd_0);
case 1122223586: return bem_nameSet_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 1516792038: return bem_isNixSet_1(bevd_0);
case 202759638: return bem_otherSeparatorSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
