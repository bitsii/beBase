namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public sealed class BEC_2_6_15_SystemCurrentPlatform : BEC_2_6_8_SystemPlatform {
public BEC_2_6_15_SystemCurrentPlatform() { }
static BEC_2_6_15_SystemCurrentPlatform() { }
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x43,0x75,0x72,0x72,0x65,0x6E,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] becc_BEC_2_6_15_SystemCurrentPlatform_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;

public static new BET_2_6_15_SystemCurrentPlatform bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_default_0() {
BEC_2_4_6_TextString bevl_platformName = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
 /* Line: 551 */ {
if (bevp_name == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 552 */ {

                    bevl_platformName = new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes(be.BECS_Runtime.platformName));
                bem_setName_1(bevl_platformName);
} /* Line: 575 */
} /* Line: 552 */
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_setName_1(BEC_2_4_6_TextString beva__name) {
bevp_name = beva__name;
bem_buildProfile_0();
return this;
} /*method end*/
public override BEC_2_6_8_SystemPlatform bem_buildProfile_0() {
BEC_2_6_6_SystemObject bevl_strings = null;
base.bem_buildProfile_0();
bevl_strings = BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_strings.bemd_1(-1769178168, bevp_newline);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {552, 552, 575, 581, 582, 586, 587, 588};
public static new int[] bevs_smnlec
 = new int[] {24, 29, 32, 38, 39, 44, 45, 46};
/* BEGIN LINEINFO 
assign 1 552 24
undef 1 552 29
setName 1 575 32
assign 1 581 38
buildProfile 0 582 39
buildProfile 0 586 44
assign 1 587 45
new 0 587 45
newlineSet 1 588 46
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 330207183: return bem_once_0();
case 1610207827: return bem_serializeToString_0();
case 184516821: return bem_isWinGetDirect_0();
case -512259678: return bem_many_0();
case 722156191: return bem_create_0();
case -1266568377: return bem_nameGet_0();
case 256606907: return bem_isNixGetDirect_0();
case 441719677: return bem_hashGet_0();
case -751296258: return bem_toString_0();
case 701763907: return bem_new_0();
case -796966532: return bem_print_0();
case -196471174: return bem_toAny_0();
case 561389448: return bem_copy_0();
case -559998219: return bem_buildProfile_0();
case 636959691: return bem_separatorGetDirect_0();
case -1032609302: return bem_otherSeparatorGetDirect_0();
case 1478963429: return bem_newlineGetDirect_0();
case 1280430641: return bem_deserializeClassNameGet_0();
case 1032358579: return bem_nullFileGetDirect_0();
case 2062168244: return bem_isWinGet_0();
case -2127113784: return bem_sourceFileNameGet_0();
case 361089340: return bem_nameGetDirect_0();
case 1463485759: return bem_otherSeparatorGet_0();
case 70409796: return bem_fieldIteratorGet_0();
case -1612673222: return bem_echo_0();
case -335249223: return bem_isNixGet_0();
case -447720903: return bem_default_0();
case -808549585: return bem_classNameGet_0();
case -627661593: return bem_serializationIteratorGet_0();
case 625685156: return bem_newlineGet_0();
case 73901351: return bem_fieldNamesGet_0();
case -1391094119: return bem_tagGet_0();
case 1065866476: return bem_nullFileGet_0();
case -1683056627: return bem_separatorGet_0();
case -374298812: return bem_iteratorGet_0();
case 2049921022: return bem_serializeContents_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 803653343: return bem_otherClass_1(bevd_0);
case 680756917: return bem_defined_1(bevd_0);
case -191286971: return bem_def_1(bevd_0);
case 653263085: return bem_newlineSetDirect_1(bevd_0);
case 522911521: return bem_nameSetDirect_1(bevd_0);
case -574317807: return bem_separatorSetDirect_1(bevd_0);
case 1649757588: return bem_sameObject_1(bevd_0);
case 720939420: return bem_nullFileSet_1(bevd_0);
case -1934236484: return bem_sameType_1(bevd_0);
case 936204520: return bem_setName_1((BEC_2_4_6_TextString) bevd_0);
case 1645946581: return bem_notEquals_1(bevd_0);
case -2022825519: return bem_otherSeparatorSet_1(bevd_0);
case 1189352435: return bem_isWinSetDirect_1(bevd_0);
case -1033781605: return bem_otherSeparatorSetDirect_1(bevd_0);
case -1380437617: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1110748051: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1770747478: return bem_isNixSet_1(bevd_0);
case -1996996349: return bem_nullFileSetDirect_1(bevd_0);
case 1587984688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1769178168: return bem_newlineSet_1(bevd_0);
case -750020170: return bem_nameSet_1(bevd_0);
case -1197345309: return bem_otherType_1(bevd_0);
case -1668696125: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 592373585: return bem_isNixSetDirect_1(bevd_0);
case -668758346: return bem_isWinSet_1(bevd_0);
case 1381682421: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 788956945: return bem_undefined_1(bevd_0);
case -1272706644: return bem_copyTo_1(bevd_0);
case 1320952802: return bem_sameClass_1(bevd_0);
case 463890253: return bem_undef_1(bevd_0);
case -429289931: return bem_separatorSet_1(bevd_0);
case 725850689: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1094925459: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1806210068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2137630710: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 235947300: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1242672538: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2053867671: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1365336246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_15_SystemCurrentPlatform_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_15_SystemCurrentPlatform_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_15_SystemCurrentPlatform();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst = (BEC_2_6_15_SystemCurrentPlatform) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_type;
}
}
}
