namespace be {
/* IO:File: source/build/Constants.be */
public sealed class BEC_2_5_9_BuildConstants : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildConstants() { }
static BEC_2_5_9_BuildConstants() { }
private static byte[] becc_BEC_2_5_9_BuildConstants_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_5_9_BuildConstants_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_0 = {0x62,0x72,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_1 = {0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_2 = {0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_3 = {0x70,0x61,0x72,0x65,0x6E,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_4 = {0x4E,0x4F,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_5 = {0x4F,0x4E,0x43,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_6 = {0x4D,0x41,0x4E,0x59};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_7 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_8 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_9 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_10 = {0x44,0x49,0x56,0x49,0x44,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_11 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_12 = {0x41,0x44,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_13 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_14 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_15 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_16 = {0x4C,0x45,0x53,0x53,0x45,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_17 = {0x4C,0x45,0x53,0x53,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_18 = {0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_19 = {0x4E,0x4F,0x54,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_20 = {0x41,0x4E,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_21 = {0x4F,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_22 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x41,0x4E,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_23 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x4F,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_24 = {0x49,0x4E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_25 = {0x47,0x45,0x54,0x5F,0x4D,0x45,0x54,0x48,0x4F,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_26 = {0x41,0x44,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_27 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_28 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_29 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_30 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_31 = {0x44,0x49,0x56,0x49,0x44,0x45,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_32 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_33 = {0x41,0x4E,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_34 = {0x4F,0x52,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_35 = {0x41,0x53,0x53,0x49,0x47,0x4E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_36 = {0x20};
private static BEC_2_6_6_SystemObject bece_BEC_2_5_9_BuildConstants_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildConstants_bels_36, 1));
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_37 = {0x2F};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_38 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_39 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_40 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_41 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_42 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_43 = {0x3A};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_44 = {0x2C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_45 = {0x2B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_46 = {};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_47 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_48 = {0x40};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_49 = {0x23};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_50 = {0x7E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_51 = {0x75,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_52 = {0x61,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_53 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_54 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_55 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_56 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_57 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_58 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_59 = {0x61,0x75,0x74,0x6F};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_60 = {0x69,0x66};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_61 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_62 = {0x65,0x6C,0x73,0x65,0x49,0x66};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_63 = {0x65,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_64 = {0x66,0x69,0x6E,0x61,0x6C,0x6C,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_65 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_66 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_67 = {0x77,0x68,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_68 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_69 = {0x66,0x6F,0x72};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_70 = {0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_71 = {0x65,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_72 = {0x69,0x66,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_73 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_74 = {0x62,0x72,0x65,0x61,0x6B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_75 = {0x63,0x6F,0x6E,0x74,0x69,0x6E,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_76 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_77 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_78 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_79 = {0x74,0x72,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_80 = {0x63,0x61,0x74,0x63,0x68};
public static new BEC_2_5_9_BuildConstants bece_BEC_2_5_9_BuildConstants_bevs_inst;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public BEC_2_4_3_MathInt bevp_maxargs;
public BEC_2_4_3_MathInt bevp_extraSlots;
public BEC_2_4_3_MathInt bevp_mtdxPad;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_9_3_ContainerMap bevp_unwindTo;
public BEC_2_9_3_ContainerMap bevp_unwindOk;
public BEC_2_9_3_ContainerMap bevp_oper;
public BEC_2_9_3_ContainerMap bevp_operNames;
public BEC_2_9_3_ContainerMap bevp_conTypes;
public BEC_2_9_3_ContainerMap bevp_parensReq;
public BEC_2_9_3_ContainerMap bevp_anchorTypes;
public BEC_2_5_9_BuildConstants bem_new_1(BEC_2_6_6_SystemObject beva_build) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_114_tmpany_phold = null;
BEC_2_4_6_TextString bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_4_6_TextString bevt_135_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_147_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_149_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_150_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_153_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_159_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_160_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_162_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_163_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_167_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_168_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_171_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_172_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_173_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_174_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_176_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_177_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_178_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_179_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_180_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_182_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_183_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_186_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_188_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_189_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_190_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_192_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_197_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_198_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_199_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_200_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_201_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_202_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_203_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_204_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpany_phold = null;
bevp_maxargs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevp_extraSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_mtdxPad = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(26));
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
bevp_unwindTo = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_unwindOk = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_oper = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_operNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_conTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parensReq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_0));
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindTo.bem_put_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_1));
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_2));
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_3));
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_6_tmpany_phold, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_11_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_10_tmpany_phold, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevt_13_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_16_tmpany_phold, bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_18_tmpany_phold, bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_20_tmpany_phold, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_23_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_22_tmpany_phold, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_25_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_29_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_28_tmpany_phold, bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_31_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_35_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_37_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_39_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_38_tmpany_phold, bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_41_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_40_tmpany_phold, bevt_41_tmpany_phold);
bevt_42_tmpany_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_43_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_42_tmpany_phold, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevt_45_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevt_47_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevt_48_tmpany_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_49_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_51_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevt_53_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
bevt_54_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevt_55_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_54_tmpany_phold, bevt_55_tmpany_phold);
bevt_56_tmpany_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_57_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_56_tmpany_phold, bevt_57_tmpany_phold);
bevt_58_tmpany_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_59_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_58_tmpany_phold, bevt_59_tmpany_phold);
bevt_60_tmpany_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_60_tmpany_phold, bevt_61_tmpany_phold);
bevt_62_tmpany_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_63_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
bevt_64_tmpany_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_65_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_64_tmpany_phold, bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_67_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_66_tmpany_phold, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_69_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_68_tmpany_phold, bevt_69_tmpany_phold);
bevt_70_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_71_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_oper.bem_put_2(bevt_70_tmpany_phold, bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_4));
bevp_operNames.bem_put_2(bevt_72_tmpany_phold, bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_5));
bevp_operNames.bem_put_2(bevt_74_tmpany_phold, bevt_75_tmpany_phold);
bevt_76_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_6));
bevp_operNames.bem_put_2(bevt_76_tmpany_phold, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_7));
bevp_operNames.bem_put_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
bevt_80_tmpany_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_8));
bevp_operNames.bem_put_2(bevt_80_tmpany_phold, bevt_81_tmpany_phold);
bevt_82_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_9));
bevp_operNames.bem_put_2(bevt_82_tmpany_phold, bevt_83_tmpany_phold);
bevt_84_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_10));
bevp_operNames.bem_put_2(bevt_84_tmpany_phold, bevt_85_tmpany_phold);
bevt_86_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_11));
bevp_operNames.bem_put_2(bevt_86_tmpany_phold, bevt_87_tmpany_phold);
bevt_88_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_12));
bevp_operNames.bem_put_2(bevt_88_tmpany_phold, bevt_89_tmpany_phold);
bevt_90_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_13));
bevp_operNames.bem_put_2(bevt_90_tmpany_phold, bevt_91_tmpany_phold);
bevt_92_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_14));
bevp_operNames.bem_put_2(bevt_92_tmpany_phold, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_15));
bevp_operNames.bem_put_2(bevt_94_tmpany_phold, bevt_95_tmpany_phold);
bevt_96_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_16));
bevp_operNames.bem_put_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildConstants_bels_17));
bevp_operNames.bem_put_2(bevt_98_tmpany_phold, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_18));
bevp_operNames.bem_put_2(bevt_100_tmpany_phold, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_19));
bevp_operNames.bem_put_2(bevt_102_tmpany_phold, bevt_103_tmpany_phold);
bevt_104_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_20));
bevp_operNames.bem_put_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevt_106_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_21));
bevp_operNames.bem_put_2(bevt_106_tmpany_phold, bevt_107_tmpany_phold);
bevt_108_tmpany_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildConstants_bels_22));
bevp_operNames.bem_put_2(bevt_108_tmpany_phold, bevt_109_tmpany_phold);
bevt_110_tmpany_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_111_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_23));
bevp_operNames.bem_put_2(bevt_110_tmpany_phold, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_24));
bevp_operNames.bem_put_2(bevt_112_tmpany_phold, bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevt_115_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_25));
bevp_operNames.bem_put_2(bevt_114_tmpany_phold, bevt_115_tmpany_phold);
bevt_116_tmpany_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_26));
bevp_operNames.bem_put_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
bevt_118_tmpany_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_119_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_27));
bevp_operNames.bem_put_2(bevt_118_tmpany_phold, bevt_119_tmpany_phold);
bevt_120_tmpany_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_121_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildConstants_bels_28));
bevp_operNames.bem_put_2(bevt_120_tmpany_phold, bevt_121_tmpany_phold);
bevt_122_tmpany_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_123_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildConstants_bels_29));
bevp_operNames.bem_put_2(bevt_122_tmpany_phold, bevt_123_tmpany_phold);
bevt_124_tmpany_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_30));
bevp_operNames.bem_put_2(bevt_124_tmpany_phold, bevt_125_tmpany_phold);
bevt_126_tmpany_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_127_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildConstants_bels_31));
bevp_operNames.bem_put_2(bevt_126_tmpany_phold, bevt_127_tmpany_phold);
bevt_128_tmpany_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_129_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildConstants_bels_32));
bevp_operNames.bem_put_2(bevt_128_tmpany_phold, bevt_129_tmpany_phold);
bevt_130_tmpany_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_131_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_33));
bevp_operNames.bem_put_2(bevt_130_tmpany_phold, bevt_131_tmpany_phold);
bevt_132_tmpany_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_133_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_34));
bevp_operNames.bem_put_2(bevt_132_tmpany_phold, bevt_133_tmpany_phold);
bevt_134_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_135_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_35));
bevp_operNames.bem_put_2(bevt_134_tmpany_phold, bevt_135_tmpany_phold);
bevt_136_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_137_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_136_tmpany_phold, bevt_137_tmpany_phold);
bevt_138_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_139_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_138_tmpany_phold, bevt_139_tmpany_phold);
bevt_140_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_141_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_140_tmpany_phold, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_143_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_142_tmpany_phold, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_145_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_144_tmpany_phold, bevt_145_tmpany_phold);
bevt_146_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevt_147_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_146_tmpany_phold, bevt_147_tmpany_phold);
bevt_148_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_149_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_148_tmpany_phold, bevt_149_tmpany_phold);
bevt_150_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_151_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_150_tmpany_phold, bevt_151_tmpany_phold);
bevt_152_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_153_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_152_tmpany_phold, bevt_153_tmpany_phold);
bevt_154_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_155_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_154_tmpany_phold, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_157_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_156_tmpany_phold, bevt_157_tmpany_phold);
bevt_158_tmpany_phold = bevp_ntypes.bem_FINALLYGet_0();
bevt_159_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_158_tmpany_phold, bevt_159_tmpany_phold);
bevt_160_tmpany_phold = bevp_ntypes.bem_TRYGet_0();
bevt_161_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_160_tmpany_phold, bevt_161_tmpany_phold);
bevt_162_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_163_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_162_tmpany_phold, bevt_163_tmpany_phold);
bevt_164_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_165_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_164_tmpany_phold, bevt_165_tmpany_phold);
bevt_166_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_167_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_166_tmpany_phold, bevt_167_tmpany_phold);
bevt_168_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_169_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_168_tmpany_phold, bevt_169_tmpany_phold);
bevt_170_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_171_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_170_tmpany_phold, bevt_171_tmpany_phold);
bevt_172_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_173_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_172_tmpany_phold, bevt_173_tmpany_phold);
bevt_174_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
bevt_175_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_174_tmpany_phold, bevt_175_tmpany_phold);
bevt_176_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_177_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_176_tmpany_phold, bevt_177_tmpany_phold);
bevt_178_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_179_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_178_tmpany_phold, bevt_179_tmpany_phold);
bevt_180_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_181_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_180_tmpany_phold, bevt_181_tmpany_phold);
bevt_182_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_183_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_182_tmpany_phold, bevt_183_tmpany_phold);
bevt_184_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_185_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_184_tmpany_phold, bevt_185_tmpany_phold);
bevt_186_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevt_187_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_186_tmpany_phold, bevt_187_tmpany_phold);
bevt_188_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_189_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_188_tmpany_phold, bevt_189_tmpany_phold);
bevt_190_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_191_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_190_tmpany_phold, bevt_191_tmpany_phold);
bevt_192_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_193_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_192_tmpany_phold, bevt_193_tmpany_phold);
bevt_194_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_195_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_194_tmpany_phold, bevt_195_tmpany_phold);
bevt_196_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_197_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_196_tmpany_phold, bevt_197_tmpany_phold);
bevt_198_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_199_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_198_tmpany_phold, bevt_199_tmpany_phold);
bevt_200_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_201_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_200_tmpany_phold, bevt_201_tmpany_phold);
bevt_202_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_203_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_202_tmpany_phold, bevt_203_tmpany_phold);
bevt_204_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_205_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_204_tmpany_phold, bevt_205_tmpany_phold);
bem_prepare_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_prepare_0() {
BEC_2_6_6_SystemObject bevl_space = null;
BEC_2_6_6_SystemObject bevl_ntok = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
bevp_matchMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_space = bece_BEC_2_5_9_BuildConstants_bevo_0;
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_37));
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_twtok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2((BEC_2_4_6_TextString) bevl_ntok , bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_1_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_38));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_2_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_2_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_39));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_3_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_3_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_40));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_4_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_4_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_41));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_5_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_5_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_42));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_6_tmpany_phold = bevp_ntypes.bem_SEMIGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_6_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_43));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_7_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_7_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_44));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_8_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_8_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_45));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_9_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_9_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildConstants_bels_46));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_10_tmpany_phold = bevp_ntypes.bem_ATYPEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_10_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_47));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_11_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_11_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_48));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_12_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_12_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_49));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_13_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_13_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_50));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_14_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(92));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_15_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_16_tmpany_phold = bevp_ntypes.bem_FSLASHGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_17_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_18_tmpany_phold = bevp_ntypes.bem_STRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(39));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_19_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_20_tmpany_phold = bevp_ntypes.bem_WSTRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_21_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_22_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(93));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_23_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_24_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(37));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_25_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_26_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(61));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_27_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_28_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(62));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_29_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_30_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(60));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_31_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_32_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(33));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_33_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_34_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(38));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_35_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_36_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(124));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_37_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_38_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_39_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_40_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(46));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_41_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_42_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_43_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_44_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_45_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_46_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_ntok = bevt_47_tmpany_phold.bem_newlineGet_0();
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_48_tmpany_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_48_tmpany_phold);
bevp_rwords = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_51));
bevt_50_tmpany_phold = bevp_ntypes.bem_USEGet_0();
bevp_rwords.bem_put_2(bevt_49_tmpany_phold, bevt_50_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_52));
bevt_52_tmpany_phold = bevp_ntypes.bem_ASGet_0();
bevp_rwords.bem_put_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_53));
bevt_54_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevp_rwords.bem_put_2(bevt_53_tmpany_phold, bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_54));
bevt_56_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevp_rwords.bem_put_2(bevt_55_tmpany_phold, bevt_56_tmpany_phold);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_55));
bevt_58_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_57_tmpany_phold, bevt_58_tmpany_phold);
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_56));
bevt_60_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_59_tmpany_phold, bevt_60_tmpany_phold);
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_57));
bevt_62_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_61_tmpany_phold, bevt_62_tmpany_phold);
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_58));
bevt_64_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_63_tmpany_phold, bevt_64_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_59));
bevt_66_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_65_tmpany_phold, bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_60));
bevt_68_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_67_tmpany_phold, bevt_68_tmpany_phold);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_61));
bevt_70_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_69_tmpany_phold, bevt_70_tmpany_phold);
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_62));
bevt_72_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevp_rwords.bem_put_2(bevt_71_tmpany_phold, bevt_72_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_63));
bevt_74_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevp_rwords.bem_put_2(bevt_73_tmpany_phold, bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_64));
bevt_76_tmpany_phold = bevp_ntypes.bem_FINALLYGet_0();
bevp_rwords.bem_put_2(bevt_75_tmpany_phold, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_65));
bevt_78_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevp_rwords.bem_put_2(bevt_77_tmpany_phold, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_66));
bevt_80_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevp_rwords.bem_put_2(bevt_79_tmpany_phold, bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_67));
bevt_82_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_68));
bevt_84_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_69));
bevt_86_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevp_rwords.bem_put_2(bevt_85_tmpany_phold, bevt_86_tmpany_phold);
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_70));
bevt_88_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevp_rwords.bem_put_2(bevt_87_tmpany_phold, bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_71));
bevt_90_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevp_rwords.bem_put_2(bevt_89_tmpany_phold, bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_72));
bevt_92_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_91_tmpany_phold, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_73));
bevt_94_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_93_tmpany_phold, bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_74));
bevt_96_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevp_rwords.bem_put_2(bevt_95_tmpany_phold, bevt_96_tmpany_phold);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_75));
bevt_98_tmpany_phold = bevp_ntypes.bem_CONTINUEGet_0();
bevp_rwords.bem_put_2(bevt_97_tmpany_phold, bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_76));
bevt_100_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
bevp_rwords.bem_put_2(bevt_99_tmpany_phold, bevt_100_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_77));
bevt_102_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevp_rwords.bem_put_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_78));
bevt_104_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevp_rwords.bem_put_2(bevt_103_tmpany_phold, bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_79));
bevt_106_tmpany_phold = bevp_ntypes.bem_TRYGet_0();
bevp_rwords.bem_put_2(bevt_105_tmpany_phold, bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_80));
bevt_108_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevp_rwords.bem_put_2(bevt_107_tmpany_phold, bevt_108_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxargsGet_0() {
return bevp_maxargs;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_maxargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_maxargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_extraSlotsGet_0() {
return bevp_extraSlots;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_extraSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extraSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxPadGet_0() {
return bevp_mtdxPad;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_mtdxPadSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdxPad = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindToGet_0() {
return bevp_unwindTo;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindTo = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindOkGet_0() {
return bevp_unwindOk;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindOkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindOk = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operGet_0() {
return bevp_oper;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oper = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operNamesGet_0() {
return bevp_operNames;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_operNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_conTypesGet_0() {
return bevp_conTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_conTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_conTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_parensReqGet_0() {
return bevp_parensReq;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_parensReqSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parensReq = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anchorTypesGet_0() {
return bevp_anchorTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_anchorTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 22, 23, 24, 25, 26, 27, 28, 29, 30, 34, 34, 34, 36, 36, 36, 37, 37, 37, 38, 38, 38, 40, 40, 40, 41, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 51, 51, 51, 52, 52, 52, 53, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 58, 58, 58, 59, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 65, 65, 65, 66, 66, 66, 67, 67, 67, 68, 68, 68, 69, 69, 69, 70, 70, 70, 71, 71, 71, 73, 73, 73, 74, 74, 74, 75, 75, 75, 76, 76, 76, 77, 77, 77, 78, 78, 78, 79, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83, 83, 84, 84, 84, 85, 85, 85, 86, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 89, 90, 90, 90, 91, 91, 91, 92, 92, 92, 93, 93, 93, 94, 94, 94, 95, 95, 95, 96, 96, 96, 97, 97, 97, 98, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 102, 102, 102, 103, 103, 103, 104, 104, 104, 106, 106, 106, 107, 107, 107, 108, 108, 108, 109, 109, 109, 110, 110, 110, 111, 111, 111, 112, 112, 112, 113, 113, 113, 114, 114, 114, 115, 115, 115, 116, 116, 116, 117, 117, 117, 118, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 127, 127, 127, 128, 128, 128, 129, 129, 129, 130, 130, 130, 131, 131, 131, 132, 132, 132, 133, 133, 133, 134, 134, 134, 135, 135, 135, 137, 137, 137, 138, 138, 138, 139, 139, 139, 140, 140, 140, 141, 141, 141, 142, 142, 142, 144, 150, 151, 153, 154, 154, 155, 155, 157, 158, 159, 159, 161, 162, 163, 163, 165, 166, 167, 167, 169, 170, 171, 171, 173, 174, 175, 175, 177, 178, 179, 179, 181, 182, 183, 183, 185, 186, 187, 187, 189, 190, 191, 191, 193, 194, 195, 195, 197, 198, 199, 199, 201, 202, 203, 203, 205, 206, 207, 207, 211, 211, 213, 214, 214, 216, 216, 218, 219, 219, 221, 221, 223, 224, 224, 226, 226, 228, 229, 229, 231, 231, 233, 234, 234, 236, 236, 238, 239, 239, 241, 241, 243, 244, 244, 246, 246, 248, 249, 249, 251, 251, 253, 254, 254, 256, 256, 258, 259, 259, 261, 261, 263, 264, 264, 266, 266, 268, 269, 269, 271, 271, 273, 274, 274, 276, 276, 278, 279, 279, 281, 281, 283, 284, 284, 286, 286, 288, 289, 289, 291, 291, 293, 294, 294, 297, 298, 298, 298, 299, 299, 299, 300, 300, 300, 301, 301, 301, 302, 302, 302, 303, 303, 303, 304, 304, 304, 305, 305, 305, 306, 306, 306, 307, 307, 307, 308, 308, 308, 309, 309, 309, 310, 310, 310, 311, 311, 311, 312, 312, 312, 313, 313, 313, 314, 314, 314, 315, 315, 315, 316, 316, 316, 317, 317, 317, 318, 318, 318, 319, 319, 319, 320, 320, 320, 321, 321, 321, 322, 322, 322, 323, 323, 323, 324, 324, 324, 325, 325, 325, 326, 326, 326, 327, 327, 327, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 985, 988, 992, 995, 999, 1002, 1006, 1009, 1013, 1016, 1020, 1023, 1027, 1030, 1034, 1037, 1041, 1044, 1048, 1051, 1055, 1058, 1062, 1065, 1069, 1072, 1076, 1079};
/* BEGIN LINEINFO 
assign 1 18 312
new 0 18 312
assign 1 19 313
new 0 19 313
assign 1 22 314
new 0 22 314
assign 1 23 315
new 0 23 315
assign 1 24 316
new 0 24 316
assign 1 25 317
new 0 25 317
assign 1 26 318
new 0 26 318
assign 1 27 319
new 0 27 319
assign 1 28 320
new 0 28 320
assign 1 29 321
new 0 29 321
assign 1 30 322
new 0 30 322
assign 1 34 323
new 0 34 323
assign 1 34 324
new 0 34 324
put 2 34 325
assign 1 36 326
new 0 36 326
assign 1 36 327
new 0 36 327
put 2 36 328
assign 1 37 329
new 0 37 329
assign 1 37 330
new 0 37 330
put 2 37 331
assign 1 38 332
new 0 38 332
assign 1 38 333
new 0 38 333
put 2 38 334
assign 1 40 335
NOTGet 0 40 335
assign 1 40 336
new 0 40 336
put 2 40 337
assign 1 41 338
ONCEGet 0 41 338
assign 1 41 339
new 0 41 339
put 2 41 340
assign 1 42 341
MANYGet 0 42 341
assign 1 42 342
new 0 42 342
put 2 42 343
assign 1 43 344
INCREMENTGet 0 43 344
assign 1 43 345
new 0 43 345
put 2 43 346
assign 1 44 347
DECREMENTGet 0 44 347
assign 1 44 348
new 0 44 348
put 2 44 349
assign 1 45 350
INCREMENT_ASSIGNGet 0 45 350
assign 1 45 351
new 0 45 351
put 2 45 352
assign 1 46 353
DECREMENT_ASSIGNGet 0 46 353
assign 1 46 354
new 0 46 354
put 2 46 355
assign 1 47 356
MULTIPLYGet 0 47 356
assign 1 47 357
new 0 47 357
put 2 47 358
assign 1 48 359
DIVIDEGet 0 48 359
assign 1 48 360
new 0 48 360
put 2 48 361
assign 1 49 362
MODULUSGet 0 49 362
assign 1 49 363
new 0 49 363
put 2 49 364
assign 1 50 365
ADDGet 0 50 365
assign 1 50 366
new 0 50 366
put 2 50 367
assign 1 51 368
SUBTRACTGet 0 51 368
assign 1 51 369
new 0 51 369
put 2 51 370
assign 1 52 371
GREATERGet 0 52 371
assign 1 52 372
new 0 52 372
put 2 52 373
assign 1 53 374
GREATER_EQUALSGet 0 53 374
assign 1 53 375
new 0 53 375
put 2 53 376
assign 1 54 377
LESSERGet 0 54 377
assign 1 54 378
new 0 54 378
put 2 54 379
assign 1 55 380
LESSER_EQUALSGet 0 55 380
assign 1 55 381
new 0 55 381
put 2 55 382
assign 1 56 383
EQUALSGet 0 56 383
assign 1 56 384
new 0 56 384
put 2 56 385
assign 1 57 386
NOT_EQUALSGet 0 57 386
assign 1 57 387
new 0 57 387
put 2 57 388
assign 1 58 389
ANDGet 0 58 389
assign 1 58 390
new 0 58 390
put 2 58 391
assign 1 59 392
ORGet 0 59 392
assign 1 59 393
new 0 59 393
put 2 59 394
assign 1 60 395
LOGICAL_ANDGet 0 60 395
assign 1 60 396
new 0 60 396
put 2 60 397
assign 1 61 398
LOGICAL_ORGet 0 61 398
assign 1 61 399
new 0 61 399
put 2 61 400
assign 1 62 401
INGet 0 62 401
assign 1 62 402
new 0 62 402
put 2 62 403
assign 1 63 404
GET_METHODGet 0 63 404
assign 1 63 405
new 0 63 405
put 2 63 406
assign 1 64 407
ADD_ASSIGNGet 0 64 407
assign 1 64 408
new 0 64 408
put 2 64 409
assign 1 65 410
SUBTRACT_ASSIGNGet 0 65 410
assign 1 65 411
new 0 65 411
put 2 65 412
assign 1 66 413
MULTIPLY_ASSIGNGet 0 66 413
assign 1 66 414
new 0 66 414
put 2 66 415
assign 1 67 416
DIVIDE_ASSIGNGet 0 67 416
assign 1 67 417
new 0 67 417
put 2 67 418
assign 1 68 419
MODULUS_ASSIGNGet 0 68 419
assign 1 68 420
new 0 68 420
put 2 68 421
assign 1 69 422
AND_ASSIGNGet 0 69 422
assign 1 69 423
new 0 69 423
put 2 69 424
assign 1 70 425
OR_ASSIGNGet 0 70 425
assign 1 70 426
new 0 70 426
put 2 70 427
assign 1 71 428
ASSIGNGet 0 71 428
assign 1 71 429
new 0 71 429
put 2 71 430
assign 1 73 431
NOTGet 0 73 431
assign 1 73 432
new 0 73 432
put 2 73 433
assign 1 74 434
ONCEGet 0 74 434
assign 1 74 435
new 0 74 435
put 2 74 436
assign 1 75 437
MANYGet 0 75 437
assign 1 75 438
new 0 75 438
put 2 75 439
assign 1 76 440
INCREMENTGet 0 76 440
assign 1 76 441
new 0 76 441
put 2 76 442
assign 1 77 443
DECREMENTGet 0 77 443
assign 1 77 444
new 0 77 444
put 2 77 445
assign 1 78 446
MULTIPLYGet 0 78 446
assign 1 78 447
new 0 78 447
put 2 78 448
assign 1 79 449
DIVIDEGet 0 79 449
assign 1 79 450
new 0 79 450
put 2 79 451
assign 1 80 452
MODULUSGet 0 80 452
assign 1 80 453
new 0 80 453
put 2 80 454
assign 1 81 455
ADDGet 0 81 455
assign 1 81 456
new 0 81 456
put 2 81 457
assign 1 82 458
SUBTRACTGet 0 82 458
assign 1 82 459
new 0 82 459
put 2 82 460
assign 1 83 461
GREATERGet 0 83 461
assign 1 83 462
new 0 83 462
put 2 83 463
assign 1 84 464
GREATER_EQUALSGet 0 84 464
assign 1 84 465
new 0 84 465
put 2 84 466
assign 1 85 467
LESSERGet 0 85 467
assign 1 85 468
new 0 85 468
put 2 85 469
assign 1 86 470
LESSER_EQUALSGet 0 86 470
assign 1 86 471
new 0 86 471
put 2 86 472
assign 1 87 473
EQUALSGet 0 87 473
assign 1 87 474
new 0 87 474
put 2 87 475
assign 1 88 476
NOT_EQUALSGet 0 88 476
assign 1 88 477
new 0 88 477
put 2 88 478
assign 1 89 479
ANDGet 0 89 479
assign 1 89 480
new 0 89 480
put 2 89 481
assign 1 90 482
ORGet 0 90 482
assign 1 90 483
new 0 90 483
put 2 90 484
assign 1 91 485
LOGICAL_ANDGet 0 91 485
assign 1 91 486
new 0 91 486
put 2 91 487
assign 1 92 488
LOGICAL_ORGet 0 92 488
assign 1 92 489
new 0 92 489
put 2 92 490
assign 1 93 491
INGet 0 93 491
assign 1 93 492
new 0 93 492
put 2 93 493
assign 1 94 494
GET_METHODGet 0 94 494
assign 1 94 495
new 0 94 495
put 2 94 496
assign 1 95 497
ADD_ASSIGNGet 0 95 497
assign 1 95 498
new 0 95 498
put 2 95 499
assign 1 96 500
SUBTRACT_ASSIGNGet 0 96 500
assign 1 96 501
new 0 96 501
put 2 96 502
assign 1 97 503
INCREMENT_ASSIGNGet 0 97 503
assign 1 97 504
new 0 97 504
put 2 97 505
assign 1 98 506
DECREMENT_ASSIGNGet 0 98 506
assign 1 98 507
new 0 98 507
put 2 98 508
assign 1 99 509
MULTIPLY_ASSIGNGet 0 99 509
assign 1 99 510
new 0 99 510
put 2 99 511
assign 1 100 512
DIVIDE_ASSIGNGet 0 100 512
assign 1 100 513
new 0 100 513
put 2 100 514
assign 1 101 515
MODULUS_ASSIGNGet 0 101 515
assign 1 101 516
new 0 101 516
put 2 101 517
assign 1 102 518
AND_ASSIGNGet 0 102 518
assign 1 102 519
new 0 102 519
put 2 102 520
assign 1 103 521
OR_ASSIGNGet 0 103 521
assign 1 103 522
new 0 103 522
put 2 103 523
assign 1 104 524
ASSIGNGet 0 104 524
assign 1 104 525
new 0 104 525
put 2 104 526
assign 1 106 527
IFGet 0 106 527
assign 1 106 528
new 0 106 528
put 2 106 529
assign 1 107 530
ELIFGet 0 107 530
assign 1 107 531
new 0 107 531
put 2 107 532
assign 1 108 533
WHILEGet 0 108 533
assign 1 108 534
new 0 108 534
put 2 108 535
assign 1 109 536
FORGet 0 109 536
assign 1 109 537
new 0 109 537
put 2 109 538
assign 1 110 539
FOREACHGet 0 110 539
assign 1 110 540
new 0 110 540
put 2 110 541
assign 1 111 542
EMITGet 0 111 542
assign 1 111 543
new 0 111 543
put 2 111 544
assign 1 112 545
IFEMITGet 0 112 545
assign 1 112 546
new 0 112 546
put 2 112 547
assign 1 113 548
METHODGet 0 113 548
assign 1 113 549
new 0 113 549
put 2 113 550
assign 1 114 551
CLASSGet 0 114 551
assign 1 114 552
new 0 114 552
put 2 114 553
assign 1 115 554
EXPRGet 0 115 554
assign 1 115 555
new 0 115 555
put 2 115 556
assign 1 116 557
ELSEGet 0 116 557
assign 1 116 558
new 0 116 558
put 2 116 559
assign 1 117 560
FINALLYGet 0 117 560
assign 1 117 561
new 0 117 561
put 2 117 562
assign 1 118 563
TRYGet 0 118 563
assign 1 118 564
new 0 118 564
put 2 118 565
assign 1 119 566
LOOPGet 0 119 566
assign 1 119 567
new 0 119 567
put 2 119 568
assign 1 120 569
PROPERTIESGet 0 120 569
assign 1 120 570
new 0 120 570
put 2 120 571
assign 1 121 572
CATCHGet 0 121 572
assign 1 121 573
new 0 121 573
put 2 121 574
assign 1 122 575
TRANSUNITGet 0 122 575
assign 1 122 576
new 0 122 576
put 2 122 577
assign 1 123 578
BRACESGet 0 123 578
assign 1 123 579
new 0 123 579
put 2 123 580
assign 1 124 581
PARENSGet 0 124 581
assign 1 124 582
new 0 124 582
put 2 124 583
assign 1 125 584
IDXGet 0 125 584
assign 1 125 585
new 0 125 585
put 2 125 586
assign 1 127 587
IFGet 0 127 587
assign 1 127 588
new 0 127 588
put 2 127 589
assign 1 128 590
ELIFGet 0 128 590
assign 1 128 591
new 0 128 591
put 2 128 592
assign 1 129 593
WHILEGet 0 129 593
assign 1 129 594
new 0 129 594
put 2 129 595
assign 1 130 596
FORGet 0 130 596
assign 1 130 597
new 0 130 597
put 2 130 598
assign 1 131 599
FOREACHGet 0 131 599
assign 1 131 600
new 0 131 600
put 2 131 601
assign 1 132 602
EMITGet 0 132 602
assign 1 132 603
new 0 132 603
put 2 132 604
assign 1 133 605
IFEMITGet 0 133 605
assign 1 133 606
new 0 133 606
put 2 133 607
assign 1 134 608
METHODGet 0 134 608
assign 1 134 609
new 0 134 609
put 2 134 610
assign 1 135 611
CATCHGet 0 135 611
assign 1 135 612
new 0 135 612
put 2 135 613
assign 1 137 614
IFGet 0 137 614
assign 1 137 615
new 0 137 615
put 2 137 616
assign 1 138 617
ELIFGet 0 138 617
assign 1 138 618
new 0 138 618
put 2 138 619
assign 1 139 620
WHILEGet 0 139 620
assign 1 139 621
new 0 139 621
put 2 139 622
assign 1 140 623
FORGet 0 140 623
assign 1 140 624
new 0 140 624
put 2 140 625
assign 1 141 626
FOREACHGet 0 141 626
assign 1 141 627
new 0 141 627
put 2 141 628
assign 1 142 629
EXPRGet 0 142 629
assign 1 142 630
new 0 142 630
put 2 142 631
prepare 0 144 632
assign 1 150 747
new 0 150 747
assign 1 151 748
new 0 151 748
assign 1 153 749
new 0 153 749
assign 1 154 750
new 0 154 750
assign 1 154 751
new 2 154 751
assign 1 155 752
DIVIDEGet 0 155 752
put 2 155 753
assign 1 157 754
new 0 157 754
addToken 1 158 755
assign 1 159 756
BRACESGet 0 159 756
put 2 159 757
assign 1 161 758
new 0 161 758
addToken 1 162 759
assign 1 163 760
RBRACESGet 0 163 760
put 2 163 761
assign 1 165 762
new 0 165 762
addToken 1 166 763
assign 1 167 764
PARENSGet 0 167 764
put 2 167 765
assign 1 169 766
new 0 169 766
addToken 1 170 767
assign 1 171 768
RPARENSGet 0 171 768
put 2 171 769
assign 1 173 770
new 0 173 770
addToken 1 174 771
assign 1 175 772
SEMIGet 0 175 772
put 2 175 773
assign 1 177 774
new 0 177 774
addToken 1 178 775
assign 1 179 776
COLONGet 0 179 776
put 2 179 777
assign 1 181 778
new 0 181 778
addToken 1 182 779
assign 1 183 780
COMMAGet 0 183 780
put 2 183 781
assign 1 185 782
new 0 185 782
addToken 1 186 783
assign 1 187 784
ADDGet 0 187 784
put 2 187 785
assign 1 189 786
new 0 189 786
addToken 1 190 787
assign 1 191 788
ATYPEGet 0 191 788
put 2 191 789
assign 1 193 790
new 0 193 790
addToken 1 194 791
assign 1 195 792
SUBTRACTGet 0 195 792
put 2 195 793
assign 1 197 794
new 0 197 794
addToken 1 198 795
assign 1 199 796
ONCEGet 0 199 796
put 2 199 797
assign 1 201 798
new 0 201 798
addToken 1 202 799
assign 1 203 800
MANYGet 0 203 800
put 2 203 801
assign 1 205 802
new 0 205 802
addToken 1 206 803
assign 1 207 804
GET_METHODGet 0 207 804
put 2 207 805
assign 1 211 806
new 0 211 806
assign 1 211 807
codeNew 1 211 807
addToken 1 213 808
assign 1 214 809
FSLASHGet 0 214 809
put 2 214 810
assign 1 216 811
new 0 216 811
assign 1 216 812
codeNew 1 216 812
addToken 1 218 813
assign 1 219 814
STRQGet 0 219 814
put 2 219 815
assign 1 221 816
new 0 221 816
assign 1 221 817
codeNew 1 221 817
addToken 1 223 818
assign 1 224 819
WSTRQGet 0 224 819
put 2 224 820
assign 1 226 821
new 0 226 821
assign 1 226 822
codeNew 1 226 822
addToken 1 228 823
assign 1 229 824
IDXGet 0 229 824
put 2 229 825
assign 1 231 826
new 0 231 826
assign 1 231 827
codeNew 1 231 827
addToken 1 233 828
assign 1 234 829
RIDXGet 0 234 829
put 2 234 830
assign 1 236 831
new 0 236 831
assign 1 236 832
codeNew 1 236 832
addToken 1 238 833
assign 1 239 834
MODULUSGet 0 239 834
put 2 239 835
assign 1 241 836
new 0 241 836
assign 1 241 837
codeNew 1 241 837
addToken 1 243 838
assign 1 244 839
ASSIGNGet 0 244 839
put 2 244 840
assign 1 246 841
new 0 246 841
assign 1 246 842
codeNew 1 246 842
addToken 1 248 843
assign 1 249 844
GREATERGet 0 249 844
put 2 249 845
assign 1 251 846
new 0 251 846
assign 1 251 847
codeNew 1 251 847
addToken 1 253 848
assign 1 254 849
LESSERGet 0 254 849
put 2 254 850
assign 1 256 851
new 0 256 851
assign 1 256 852
codeNew 1 256 852
addToken 1 258 853
assign 1 259 854
NOTGet 0 259 854
put 2 259 855
assign 1 261 856
new 0 261 856
assign 1 261 857
codeNew 1 261 857
addToken 1 263 858
assign 1 264 859
ANDGet 0 264 859
put 2 264 860
assign 1 266 861
new 0 266 861
assign 1 266 862
codeNew 1 266 862
addToken 1 268 863
assign 1 269 864
ORGet 0 269 864
put 2 269 865
assign 1 271 866
new 0 271 866
assign 1 271 867
codeNew 1 271 867
addToken 1 273 868
assign 1 274 869
MULTIPLYGet 0 274 869
put 2 274 870
assign 1 276 871
new 0 276 871
assign 1 276 872
codeNew 1 276 872
addToken 1 278 873
assign 1 279 874
DOTGet 0 279 874
put 2 279 875
assign 1 281 876
new 0 281 876
assign 1 281 877
codeNew 1 281 877
addToken 1 283 878
assign 1 284 879
SPACEGet 0 284 879
put 2 284 880
assign 1 286 881
new 0 286 881
assign 1 286 882
codeNew 1 286 882
addToken 1 288 883
assign 1 289 884
SPACEGet 0 289 884
put 2 289 885
assign 1 291 886
new 0 291 886
assign 1 291 887
newlineGet 0 291 887
addToken 1 293 888
assign 1 294 889
NEWLINEGet 0 294 889
put 2 294 890
assign 1 297 891
new 0 297 891
assign 1 298 892
new 0 298 892
assign 1 298 893
USEGet 0 298 893
put 2 298 894
assign 1 299 895
new 0 299 895
assign 1 299 896
ASGet 0 299 896
put 2 299 897
assign 1 300 898
new 0 300 898
assign 1 300 899
CLASSGet 0 300 899
put 2 300 900
assign 1 301 901
new 0 301 901
assign 1 301 902
METHODGet 0 301 902
put 2 301 903
assign 1 302 904
new 0 302 904
assign 1 302 905
DEFMODGet 0 302 905
put 2 302 906
assign 1 303 907
new 0 303 907
assign 1 303 908
DEFMODGet 0 303 908
put 2 303 909
assign 1 304 910
new 0 304 910
assign 1 304 911
DEFMODGet 0 304 911
put 2 304 912
assign 1 305 913
new 0 305 913
assign 1 305 914
VARGet 0 305 914
put 2 305 915
assign 1 306 916
new 0 306 916
assign 1 306 917
VARGet 0 306 917
put 2 306 918
assign 1 307 919
new 0 307 919
assign 1 307 920
IFGet 0 307 920
put 2 307 921
assign 1 308 922
new 0 308 922
assign 1 308 923
IFGet 0 308 923
put 2 308 924
assign 1 309 925
new 0 309 925
assign 1 309 926
ELIFGet 0 309 926
put 2 309 927
assign 1 310 928
new 0 310 928
assign 1 310 929
ELSEGet 0 310 929
put 2 310 930
assign 1 311 931
new 0 311 931
assign 1 311 932
FINALLYGet 0 311 932
put 2 311 933
assign 1 312 934
new 0 312 934
assign 1 312 935
LOOPGet 0 312 935
put 2 312 936
assign 1 313 937
new 0 313 937
assign 1 313 938
PROPERTIESGet 0 313 938
put 2 313 939
assign 1 314 940
new 0 314 940
assign 1 314 941
WHILEGet 0 314 941
put 2 314 942
assign 1 315 943
new 0 315 943
assign 1 315 944
WHILEGet 0 315 944
put 2 315 945
assign 1 316 946
new 0 316 946
assign 1 316 947
FORGet 0 316 947
put 2 316 948
assign 1 317 949
new 0 317 949
assign 1 317 950
INGet 0 317 950
put 2 317 951
assign 1 318 952
new 0 318 952
assign 1 318 953
EMITGet 0 318 953
put 2 318 954
assign 1 319 955
new 0 319 955
assign 1 319 956
IFEMITGet 0 319 956
put 2 319 957
assign 1 320 958
new 0 320 958
assign 1 320 959
IFEMITGet 0 320 959
put 2 320 960
assign 1 321 961
new 0 321 961
assign 1 321 962
BREAKGet 0 321 962
put 2 321 963
assign 1 322 964
new 0 322 964
assign 1 322 965
CONTINUEGet 0 322 965
put 2 322 966
assign 1 323 967
new 0 323 967
assign 1 323 968
NULLGet 0 323 968
put 2 323 969
assign 1 324 970
new 0 324 970
assign 1 324 971
TRUEGet 0 324 971
put 2 324 972
assign 1 325 973
new 0 325 973
assign 1 325 974
FALSEGet 0 325 974
put 2 325 975
assign 1 326 976
new 0 326 976
assign 1 326 977
TRYGet 0 326 977
put 2 326 978
assign 1 327 979
new 0 327 979
assign 1 327 980
CATCHGet 0 327 980
put 2 327 981
return 1 0 985
assign 1 0 988
return 1 0 992
assign 1 0 995
return 1 0 999
assign 1 0 1002
return 1 0 1006
assign 1 0 1009
return 1 0 1013
assign 1 0 1016
return 1 0 1020
assign 1 0 1023
return 1 0 1027
assign 1 0 1030
return 1 0 1034
assign 1 0 1037
return 1 0 1041
assign 1 0 1044
return 1 0 1048
assign 1 0 1051
return 1 0 1055
assign 1 0 1058
return 1 0 1062
assign 1 0 1065
return 1 0 1069
assign 1 0 1072
return 1 0 1076
assign 1 0 1079
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case -1360537729: return bem_ntypesGet_0();
case -289190594: return bem_new_0();
case 628114265: return bem_many_0();
case -86198663: return bem_print_0();
case 1892086655: return bem_prepare_0();
case 1730642738: return bem_operNamesGet_0();
case -1293980224: return bem_extraSlotsGet_0();
case 1606100185: return bem_toAny_0();
case -693169976: return bem_serializeToString_0();
case 468841666: return bem_sourceFileNameGet_0();
case -2143843780: return bem_tagGet_0();
case -457712006: return bem_classNameGet_0();
case 1229624261: return bem_conTypesGet_0();
case 386499474: return bem_deserializeClassNameGet_0();
case 1110687349: return bem_serializationIteratorGet_0();
case -2048144313: return bem_maxargsGet_0();
case 820088259: return bem_echo_0();
case -2138369143: return bem_twtokGet_0();
case 154399642: return bem_hashGet_0();
case -1896702956: return bem_serializeContents_0();
case 402795231: return bem_once_0();
case -1284956673: return bem_anchorTypesGet_0();
case 1890026129: return bem_operGet_0();
case 1323527258: return bem_copy_0();
case 366574284: return bem_parensReqGet_0();
case -1710921376: return bem_iteratorGet_0();
case -285521200: return bem_create_0();
case 1227115373: return bem_rwordsGet_0();
case -548588060: return bem_unwindOkGet_0();
case -1679072038: return bem_toString_0();
case 1829615340: return bem_fieldIteratorGet_0();
case 1615664272: return bem_mtdxPadGet_0();
case 347826324: return bem_matchMapGet_0();
case -1539786378: return bem_unwindToGet_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 823180387: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1759835639: return bem_defined_1(bevd_0);
case 713999383: return bem_undef_1(bevd_0);
case 1958076839: return bem_undefined_1(bevd_0);
case 271041503: return bem_rwordsSet_1(bevd_0);
case 1253393632: return bem_def_1(bevd_0);
case -1342272618: return bem_operNamesSet_1(bevd_0);
case -579123672: return bem_conTypesSet_1(bevd_0);
case 365385951: return bem_equals_1(bevd_0);
case 2086659962: return bem_sameObject_1(bevd_0);
case -2135952065: return bem_extraSlotsSet_1(bevd_0);
case 993809703: return bem_unwindToSet_1(bevd_0);
case 198891290: return bem_mtdxPadSet_1(bevd_0);
case -1770369050: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 184736412: return bem_twtokSet_1(bevd_0);
case -724471517: return bem_ntypesSet_1(bevd_0);
case -1706185549: return bem_otherType_1(bevd_0);
case -641584584: return bem_sameClass_1(bevd_0);
case 1812205322: return bem_operSet_1(bevd_0);
case 343567700: return bem_sameType_1(bevd_0);
case 938569326: return bem_notEquals_1(bevd_0);
case 1395652654: return bem_unwindOkSet_1(bevd_0);
case -861317881: return bem_otherClass_1(bevd_0);
case 1519077869: return bem_new_1(bevd_0);
case -1753298074: return bem_anchorTypesSet_1(bevd_0);
case 405603043: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1211467604: return bem_copyTo_1(bevd_0);
case -2079057210: return bem_matchMapSet_1(bevd_0);
case 2033308650: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1232743666: return bem_parensReqSet_1(bevd_0);
case -153229853: return bem_maxargsSet_1(bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1125341844: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389614349: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1812156494: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1790570920: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2109777534: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1447567526: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1299212473: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildConstants_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildConstants_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildConstants();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_inst = (BEC_2_5_9_BuildConstants) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_inst;
}
}
}
