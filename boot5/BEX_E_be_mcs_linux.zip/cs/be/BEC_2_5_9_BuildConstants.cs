namespace be {
/* IO:File: source/build/Constants.be */
public sealed class BEC_2_5_9_BuildConstants : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildConstants() { }
static BEC_2_5_9_BuildConstants() { }
private static byte[] becc_BEC_2_5_9_BuildConstants_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_5_9_BuildConstants_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x6F,0x6E,0x73,0x74,0x61,0x6E,0x74,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_0 = {0x62,0x72,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_1 = {0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_2 = {0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_3 = {0x70,0x61,0x72,0x65,0x6E,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_4 = {0x4E,0x4F,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_5 = {0x4F,0x4E,0x43,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_6 = {0x4D,0x41,0x4E,0x59};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_7 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_8 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_9 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_10 = {0x44,0x49,0x56,0x49,0x44,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_11 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_12 = {0x41,0x44,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_13 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_14 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_15 = {0x47,0x52,0x45,0x41,0x54,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_16 = {0x4C,0x45,0x53,0x53,0x45,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_17 = {0x4C,0x45,0x53,0x53,0x45,0x52,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_18 = {0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_19 = {0x4E,0x4F,0x54,0x5F,0x45,0x51,0x55,0x41,0x4C,0x53};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_20 = {0x41,0x4E,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_21 = {0x4F,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_22 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x41,0x4E,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_23 = {0x4C,0x4F,0x47,0x49,0x43,0x41,0x4C,0x5F,0x4F,0x52};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_24 = {0x49,0x4E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_25 = {0x47,0x45,0x54,0x5F,0x4D,0x45,0x54,0x48,0x4F,0x44};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_26 = {0x41,0x44,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_27 = {0x53,0x55,0x42,0x54,0x52,0x41,0x43,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_28 = {0x49,0x4E,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_29 = {0x44,0x45,0x43,0x52,0x45,0x4D,0x45,0x4E,0x54,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_30 = {0x4D,0x55,0x4C,0x54,0x49,0x50,0x4C,0x59,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_31 = {0x44,0x49,0x56,0x49,0x44,0x45,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_32 = {0x4D,0x4F,0x44,0x55,0x4C,0x55,0x53,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_33 = {0x41,0x4E,0x44,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_34 = {0x4F,0x52,0x5F,0x56,0x41,0x4C,0x55,0x45};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_35 = {0x41,0x53,0x53,0x49,0x47,0x4E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_36 = {0x20};
private static BEC_2_6_6_SystemObject bece_BEC_2_5_9_BuildConstants_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildConstants_bels_36, 1));
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_37 = {0x2F};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_38 = {0x7B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_39 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_40 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_41 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_42 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_43 = {0x3A};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_44 = {0x2C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_45 = {0x2B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_46 = {};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_47 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_48 = {0x40};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_49 = {0x23};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_50 = {0x7E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_51 = {0x75,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_52 = {0x61,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_53 = {0x63,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_54 = {0x6D,0x65,0x74,0x68,0x6F,0x64};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_55 = {0x66,0x69,0x6E,0x61,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_56 = {0x6C,0x6F,0x63,0x61,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_57 = {0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_58 = {0x61,0x6E,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_59 = {0x61,0x75,0x74,0x6F};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_60 = {0x69,0x66};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_61 = {0x75,0x6E,0x6C,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_62 = {0x65,0x6C,0x73,0x65,0x49,0x66};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_63 = {0x65,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_64 = {0x66,0x69,0x6E,0x61,0x6C,0x6C,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_65 = {0x6C,0x6F,0x6F,0x70};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_66 = {0x66,0x69,0x65,0x6C,0x64,0x73};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_67 = {0x77,0x68,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_68 = {0x75,0x6E,0x74,0x69,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_69 = {0x66,0x6F,0x72};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_70 = {0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_71 = {0x65,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_72 = {0x69,0x66,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_73 = {0x69,0x66,0x4E,0x6F,0x74,0x45,0x6D,0x69,0x74};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_74 = {0x62,0x72,0x65,0x61,0x6B};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_75 = {0x63,0x6F,0x6E,0x74,0x69,0x6E,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_76 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_77 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_78 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_79 = {0x74,0x72,0x79};
private static byte[] bece_BEC_2_5_9_BuildConstants_bels_80 = {0x63,0x61,0x74,0x63,0x68};
public static new BEC_2_5_9_BuildConstants bece_BEC_2_5_9_BuildConstants_bevs_inst;

public static new BET_2_5_9_BuildConstants bece_BEC_2_5_9_BuildConstants_bevs_type;

public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_9_3_ContainerMap bevp_matchMap;
public BEC_2_9_3_ContainerMap bevp_rwords;
public BEC_2_4_3_MathInt bevp_maxargs;
public BEC_2_4_3_MathInt bevp_extraSlots;
public BEC_2_4_3_MathInt bevp_mtdxPad;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_9_3_ContainerMap bevp_unwindTo;
public BEC_2_9_3_ContainerMap bevp_unwindOk;
public BEC_2_9_3_ContainerMap bevp_oper;
public BEC_2_9_3_ContainerMap bevp_operNames;
public BEC_2_9_3_ContainerMap bevp_conTypes;
public BEC_2_9_3_ContainerMap bevp_parensReq;
public BEC_2_9_3_ContainerMap bevp_anchorTypes;
public BEC_2_5_9_BuildConstants bem_new_1(BEC_2_6_6_SystemObject beva_build) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_112_tmpany_phold = null;
BEC_2_4_6_TextString bevt_113_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_114_tmpany_phold = null;
BEC_2_4_6_TextString bevt_115_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_118_tmpany_phold = null;
BEC_2_4_6_TextString bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_126_tmpany_phold = null;
BEC_2_4_6_TextString bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_4_6_TextString bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_132_tmpany_phold = null;
BEC_2_4_6_TextString bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_4_6_TextString bevt_135_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_136_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_137_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_138_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_146_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_147_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_148_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_149_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_150_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_153_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_159_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_160_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_161_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_162_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_163_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_166_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_167_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_168_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_171_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_172_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_173_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_174_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_175_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_176_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_177_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_178_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_179_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_180_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_181_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_182_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_183_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_184_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_185_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_186_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_187_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_188_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_189_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_190_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_191_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_192_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_193_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_194_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_195_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_196_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_197_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_198_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_199_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_200_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_201_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_202_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_203_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_204_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_205_tmpany_phold = null;
bevp_maxargs = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevp_extraSlots = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_mtdxPad = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(26));
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
bevp_unwindTo = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_unwindOk = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_oper = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_operNames = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_conTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_parensReq = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_0));
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindTo.bem_put_2(bevt_0_tmpany_phold, bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_1));
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_2));
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_4_tmpany_phold, bevt_5_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_3));
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_unwindOk.bem_put_2(bevt_6_tmpany_phold, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevt_9_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_8_tmpany_phold, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_11_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_10_tmpany_phold, bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevt_13_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_14_tmpany_phold, bevt_15_tmpany_phold);
bevt_16_tmpany_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_16_tmpany_phold, bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_18_tmpany_phold, bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_oper.bem_put_2(bevt_20_tmpany_phold, bevt_21_tmpany_phold);
bevt_22_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_23_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_22_tmpany_phold, bevt_23_tmpany_phold);
bevt_24_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_25_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_oper.bem_put_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_29_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_28_tmpany_phold, bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_31_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_oper.bem_put_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_32_tmpany_phold, bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_35_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_36_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_37_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_36_tmpany_phold, bevt_37_tmpany_phold);
bevt_38_tmpany_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_39_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_oper.bem_put_2(bevt_38_tmpany_phold, bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_41_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_40_tmpany_phold, bevt_41_tmpany_phold);
bevt_42_tmpany_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_43_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_oper.bem_put_2(bevt_42_tmpany_phold, bevt_43_tmpany_phold);
bevt_44_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevt_45_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevt_47_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_46_tmpany_phold, bevt_47_tmpany_phold);
bevt_48_tmpany_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_49_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_oper.bem_put_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_50_tmpany_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_51_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_oper.bem_put_2(bevt_50_tmpany_phold, bevt_51_tmpany_phold);
bevt_52_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevt_53_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
bevt_54_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevt_55_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(7));
bevp_oper.bem_put_2(bevt_54_tmpany_phold, bevt_55_tmpany_phold);
bevt_56_tmpany_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_57_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_56_tmpany_phold, bevt_57_tmpany_phold);
bevt_58_tmpany_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_59_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_58_tmpany_phold, bevt_59_tmpany_phold);
bevt_60_tmpany_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_61_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_60_tmpany_phold, bevt_61_tmpany_phold);
bevt_62_tmpany_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_63_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_62_tmpany_phold, bevt_63_tmpany_phold);
bevt_64_tmpany_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_65_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_64_tmpany_phold, bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_67_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_66_tmpany_phold, bevt_67_tmpany_phold);
bevt_68_tmpany_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_69_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_oper.bem_put_2(bevt_68_tmpany_phold, bevt_69_tmpany_phold);
bevt_70_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_71_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_oper.bem_put_2(bevt_70_tmpany_phold, bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_4));
bevp_operNames.bem_put_2(bevt_72_tmpany_phold, bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_5));
bevp_operNames.bem_put_2(bevt_74_tmpany_phold, bevt_75_tmpany_phold);
bevt_76_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_6));
bevp_operNames.bem_put_2(bevt_76_tmpany_phold, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevp_ntypes.bem_INCREMENTGet_0();
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_7));
bevp_operNames.bem_put_2(bevt_78_tmpany_phold, bevt_79_tmpany_phold);
bevt_80_tmpany_phold = bevp_ntypes.bem_DECREMENTGet_0();
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_8));
bevp_operNames.bem_put_2(bevt_80_tmpany_phold, bevt_81_tmpany_phold);
bevt_82_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_9));
bevp_operNames.bem_put_2(bevt_82_tmpany_phold, bevt_83_tmpany_phold);
bevt_84_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_10));
bevp_operNames.bem_put_2(bevt_84_tmpany_phold, bevt_85_tmpany_phold);
bevt_86_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_11));
bevp_operNames.bem_put_2(bevt_86_tmpany_phold, bevt_87_tmpany_phold);
bevt_88_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_12));
bevp_operNames.bem_put_2(bevt_88_tmpany_phold, bevt_89_tmpany_phold);
bevt_90_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_13));
bevp_operNames.bem_put_2(bevt_90_tmpany_phold, bevt_91_tmpany_phold);
bevt_92_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_14));
bevp_operNames.bem_put_2(bevt_92_tmpany_phold, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = bevp_ntypes.bem_GREATER_EQUALSGet_0();
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_15));
bevp_operNames.bem_put_2(bevt_94_tmpany_phold, bevt_95_tmpany_phold);
bevt_96_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_16));
bevp_operNames.bem_put_2(bevt_96_tmpany_phold, bevt_97_tmpany_phold);
bevt_98_tmpany_phold = bevp_ntypes.bem_LESSER_EQUALSGet_0();
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildConstants_bels_17));
bevp_operNames.bem_put_2(bevt_98_tmpany_phold, bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_ntypes.bem_EQUALSGet_0();
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_18));
bevp_operNames.bem_put_2(bevt_100_tmpany_phold, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = bevp_ntypes.bem_NOT_EQUALSGet_0();
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_19));
bevp_operNames.bem_put_2(bevt_102_tmpany_phold, bevt_103_tmpany_phold);
bevt_104_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_20));
bevp_operNames.bem_put_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevt_106_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_21));
bevp_operNames.bem_put_2(bevt_106_tmpany_phold, bevt_107_tmpany_phold);
bevt_108_tmpany_phold = bevp_ntypes.bem_LOGICAL_ANDGet_0();
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildConstants_bels_22));
bevp_operNames.bem_put_2(bevt_108_tmpany_phold, bevt_109_tmpany_phold);
bevt_110_tmpany_phold = bevp_ntypes.bem_LOGICAL_ORGet_0();
bevt_111_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_23));
bevp_operNames.bem_put_2(bevt_110_tmpany_phold, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevt_113_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_24));
bevp_operNames.bem_put_2(bevt_112_tmpany_phold, bevt_113_tmpany_phold);
bevt_114_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevt_115_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildConstants_bels_25));
bevp_operNames.bem_put_2(bevt_114_tmpany_phold, bevt_115_tmpany_phold);
bevt_116_tmpany_phold = bevp_ntypes.bem_ADD_ASSIGNGet_0();
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_26));
bevp_operNames.bem_put_2(bevt_116_tmpany_phold, bevt_117_tmpany_phold);
bevt_118_tmpany_phold = bevp_ntypes.bem_SUBTRACT_ASSIGNGet_0();
bevt_119_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_27));
bevp_operNames.bem_put_2(bevt_118_tmpany_phold, bevt_119_tmpany_phold);
bevt_120_tmpany_phold = bevp_ntypes.bem_INCREMENT_ASSIGNGet_0();
bevt_121_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildConstants_bels_28));
bevp_operNames.bem_put_2(bevt_120_tmpany_phold, bevt_121_tmpany_phold);
bevt_122_tmpany_phold = bevp_ntypes.bem_DECREMENT_ASSIGNGet_0();
bevt_123_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildConstants_bels_29));
bevp_operNames.bem_put_2(bevt_122_tmpany_phold, bevt_123_tmpany_phold);
bevt_124_tmpany_phold = bevp_ntypes.bem_MULTIPLY_ASSIGNGet_0();
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildConstants_bels_30));
bevp_operNames.bem_put_2(bevt_124_tmpany_phold, bevt_125_tmpany_phold);
bevt_126_tmpany_phold = bevp_ntypes.bem_DIVIDE_ASSIGNGet_0();
bevt_127_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildConstants_bels_31));
bevp_operNames.bem_put_2(bevt_126_tmpany_phold, bevt_127_tmpany_phold);
bevt_128_tmpany_phold = bevp_ntypes.bem_MODULUS_ASSIGNGet_0();
bevt_129_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildConstants_bels_32));
bevp_operNames.bem_put_2(bevt_128_tmpany_phold, bevt_129_tmpany_phold);
bevt_130_tmpany_phold = bevp_ntypes.bem_AND_ASSIGNGet_0();
bevt_131_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_33));
bevp_operNames.bem_put_2(bevt_130_tmpany_phold, bevt_131_tmpany_phold);
bevt_132_tmpany_phold = bevp_ntypes.bem_OR_ASSIGNGet_0();
bevt_133_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_34));
bevp_operNames.bem_put_2(bevt_132_tmpany_phold, bevt_133_tmpany_phold);
bevt_134_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevt_135_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_35));
bevp_operNames.bem_put_2(bevt_134_tmpany_phold, bevt_135_tmpany_phold);
bevt_136_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_137_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_136_tmpany_phold, bevt_137_tmpany_phold);
bevt_138_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_139_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_138_tmpany_phold, bevt_139_tmpany_phold);
bevt_140_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_141_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_140_tmpany_phold, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_143_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_142_tmpany_phold, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_145_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_144_tmpany_phold, bevt_145_tmpany_phold);
bevt_146_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevt_147_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_146_tmpany_phold, bevt_147_tmpany_phold);
bevt_148_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_149_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_148_tmpany_phold, bevt_149_tmpany_phold);
bevt_150_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_151_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_150_tmpany_phold, bevt_151_tmpany_phold);
bevt_152_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevt_153_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_152_tmpany_phold, bevt_153_tmpany_phold);
bevt_154_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_155_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_154_tmpany_phold, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_157_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_156_tmpany_phold, bevt_157_tmpany_phold);
bevt_158_tmpany_phold = bevp_ntypes.bem_FINALLYGet_0();
bevt_159_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_158_tmpany_phold, bevt_159_tmpany_phold);
bevt_160_tmpany_phold = bevp_ntypes.bem_TRYGet_0();
bevt_161_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_160_tmpany_phold, bevt_161_tmpany_phold);
bevt_162_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevt_163_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_162_tmpany_phold, bevt_163_tmpany_phold);
bevt_164_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevt_165_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_164_tmpany_phold, bevt_165_tmpany_phold);
bevt_166_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_167_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_166_tmpany_phold, bevt_167_tmpany_phold);
bevt_168_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevt_169_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_168_tmpany_phold, bevt_169_tmpany_phold);
bevt_170_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_171_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_170_tmpany_phold, bevt_171_tmpany_phold);
bevt_172_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_173_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_172_tmpany_phold, bevt_173_tmpany_phold);
bevt_174_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
bevt_175_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_conTypes.bem_put_2(bevt_174_tmpany_phold, bevt_175_tmpany_phold);
bevt_176_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_177_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_176_tmpany_phold, bevt_177_tmpany_phold);
bevt_178_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_179_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_178_tmpany_phold, bevt_179_tmpany_phold);
bevt_180_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_181_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_180_tmpany_phold, bevt_181_tmpany_phold);
bevt_182_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_183_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_182_tmpany_phold, bevt_183_tmpany_phold);
bevt_184_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_185_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_184_tmpany_phold, bevt_185_tmpany_phold);
bevt_186_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevt_187_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_186_tmpany_phold, bevt_187_tmpany_phold);
bevt_188_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevt_189_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_188_tmpany_phold, bevt_189_tmpany_phold);
bevt_190_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_191_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_190_tmpany_phold, bevt_191_tmpany_phold);
bevt_192_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevt_193_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_parensReq.bem_put_2(bevt_192_tmpany_phold, bevt_193_tmpany_phold);
bevt_194_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevt_195_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_194_tmpany_phold, bevt_195_tmpany_phold);
bevt_196_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_197_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_196_tmpany_phold, bevt_197_tmpany_phold);
bevt_198_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevt_199_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_198_tmpany_phold, bevt_199_tmpany_phold);
bevt_200_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevt_201_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_200_tmpany_phold, bevt_201_tmpany_phold);
bevt_202_tmpany_phold = bevp_ntypes.bem_FOREACHGet_0();
bevt_203_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_202_tmpany_phold, bevt_203_tmpany_phold);
bevt_204_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
bevt_205_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_anchorTypes.bem_put_2(bevt_204_tmpany_phold, bevt_205_tmpany_phold);
bem_prepare_0();
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_prepare_0() {
BEC_2_6_6_SystemObject bevl_space = null;
BEC_2_6_6_SystemObject bevl_ntok = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_40_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_41_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_46_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_47_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_48_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_4_6_TextString bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
bevp_matchMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevl_space = bece_BEC_2_5_9_BuildConstants_bevo_0;
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_37));
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_twtok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_2((BEC_2_4_6_TextString) bevl_ntok , bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_ntypes.bem_DIVIDEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_1_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_38));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_2_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_2_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_39));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_3_tmpany_phold = bevp_ntypes.bem_RBRACESGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_3_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_40));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_4_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_4_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_41));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_5_tmpany_phold = bevp_ntypes.bem_RPARENSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_5_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_42));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_6_tmpany_phold = bevp_ntypes.bem_SEMIGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_6_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_43));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_7_tmpany_phold = bevp_ntypes.bem_COLONGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_7_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_44));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_8_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_8_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_45));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_9_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_9_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildConstants_bels_46));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_10_tmpany_phold = bevp_ntypes.bem_ATYPEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_10_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_47));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_11_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_11_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_48));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_12_tmpany_phold = bevp_ntypes.bem_ONCEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_12_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_49));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_13_tmpany_phold = bevp_ntypes.bem_MANYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_13_tmpany_phold);
bevl_ntok = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildConstants_bels_50));
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_14_tmpany_phold = bevp_ntypes.bem_GET_METHODGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(92));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_15_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_16_tmpany_phold = bevp_ntypes.bem_FSLASHGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(34));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_17_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_18_tmpany_phold = bevp_ntypes.bem_STRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(39));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_19_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_20_tmpany_phold = bevp_ntypes.bem_WSTRQGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_21_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_22_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(93));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_23_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_24_tmpany_phold = bevp_ntypes.bem_RIDXGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(37));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_25_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_26_tmpany_phold = bevp_ntypes.bem_MODULUSGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(61));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_27_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_28_tmpany_phold = bevp_ntypes.bem_ASSIGNGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(62));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_29_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_30_tmpany_phold = bevp_ntypes.bem_GREATERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(60));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_31_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_32_tmpany_phold = bevp_ntypes.bem_LESSERGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(33));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_33_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_34_tmpany_phold = bevp_ntypes.bem_NOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(38));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_35_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_36_tmpany_phold = bevp_ntypes.bem_ANDGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(124));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_37_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_38_tmpany_phold = bevp_ntypes.bem_ORGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_39_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_40_tmpany_phold = bevp_ntypes.bem_MULTIPLYGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(46));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_41_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_42_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_42_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_43_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_44_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevl_ntok = (new BEC_2_4_6_TextString()).bem_codeNew_1(bevt_45_tmpany_phold);
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_46_tmpany_phold = bevp_ntypes.bem_SPACEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_ntok = bevt_47_tmpany_phold.bem_crGet_0();
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_48_tmpany_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_ntok = bevt_49_tmpany_phold.bem_lfGet_0();
bevp_twtok.bem_addToken_1((BEC_2_4_6_TextString) bevl_ntok );
bevt_50_tmpany_phold = bevp_ntypes.bem_NEWLINEGet_0();
bevp_matchMap.bem_put_2(bevl_ntok, bevt_50_tmpany_phold);
bevp_rwords = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_51));
bevt_52_tmpany_phold = bevp_ntypes.bem_USEGet_0();
bevp_rwords.bem_put_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_52));
bevt_54_tmpany_phold = bevp_ntypes.bem_ASGet_0();
bevp_rwords.bem_put_2(bevt_53_tmpany_phold, bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_53));
bevt_56_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
bevp_rwords.bem_put_2(bevt_55_tmpany_phold, bevt_56_tmpany_phold);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_54));
bevt_58_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevp_rwords.bem_put_2(bevt_57_tmpany_phold, bevt_58_tmpany_phold);
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_55));
bevt_60_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_59_tmpany_phold, bevt_60_tmpany_phold);
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_56));
bevt_62_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_61_tmpany_phold, bevt_62_tmpany_phold);
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_57));
bevt_64_tmpany_phold = bevp_ntypes.bem_DEFMODGet_0();
bevp_rwords.bem_put_2(bevt_63_tmpany_phold, bevt_64_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_58));
bevt_66_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_65_tmpany_phold, bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_59));
bevt_68_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevp_rwords.bem_put_2(bevt_67_tmpany_phold, bevt_68_tmpany_phold);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_60));
bevt_70_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_69_tmpany_phold, bevt_70_tmpany_phold);
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_61));
bevt_72_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevp_rwords.bem_put_2(bevt_71_tmpany_phold, bevt_72_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_62));
bevt_74_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevp_rwords.bem_put_2(bevt_73_tmpany_phold, bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_63));
bevt_76_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevp_rwords.bem_put_2(bevt_75_tmpany_phold, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildConstants_bels_64));
bevt_78_tmpany_phold = bevp_ntypes.bem_FINALLYGet_0();
bevp_rwords.bem_put_2(bevt_77_tmpany_phold, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_65));
bevt_80_tmpany_phold = bevp_ntypes.bem_LOOPGet_0();
bevp_rwords.bem_put_2(bevt_79_tmpany_phold, bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_66));
bevt_82_tmpany_phold = bevp_ntypes.bem_PROPERTIESGet_0();
bevp_rwords.bem_put_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_67));
bevt_84_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_68));
bevt_86_tmpany_phold = bevp_ntypes.bem_WHILEGet_0();
bevp_rwords.bem_put_2(bevt_85_tmpany_phold, bevt_86_tmpany_phold);
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_69));
bevt_88_tmpany_phold = bevp_ntypes.bem_FORGet_0();
bevp_rwords.bem_put_2(bevt_87_tmpany_phold, bevt_88_tmpany_phold);
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildConstants_bels_70));
bevt_90_tmpany_phold = bevp_ntypes.bem_INGet_0();
bevp_rwords.bem_put_2(bevt_89_tmpany_phold, bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_71));
bevt_92_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
bevp_rwords.bem_put_2(bevt_91_tmpany_phold, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildConstants_bels_72));
bevt_94_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_93_tmpany_phold, bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildConstants_bels_73));
bevt_96_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
bevp_rwords.bem_put_2(bevt_95_tmpany_phold, bevt_96_tmpany_phold);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_74));
bevt_98_tmpany_phold = bevp_ntypes.bem_BREAKGet_0();
bevp_rwords.bem_put_2(bevt_97_tmpany_phold, bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildConstants_bels_75));
bevt_100_tmpany_phold = bevp_ntypes.bem_CONTINUEGet_0();
bevp_rwords.bem_put_2(bevt_99_tmpany_phold, bevt_100_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_76));
bevt_102_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
bevp_rwords.bem_put_2(bevt_101_tmpany_phold, bevt_102_tmpany_phold);
bevt_103_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildConstants_bels_77));
bevt_104_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
bevp_rwords.bem_put_2(bevt_103_tmpany_phold, bevt_104_tmpany_phold);
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_78));
bevt_106_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
bevp_rwords.bem_put_2(bevt_105_tmpany_phold, bevt_106_tmpany_phold);
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildConstants_bels_79));
bevt_108_tmpany_phold = bevp_ntypes.bem_TRYGet_0();
bevp_rwords.bem_put_2(bevt_107_tmpany_phold, bevt_108_tmpany_phold);
bevt_109_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildConstants_bels_80));
bevt_110_tmpany_phold = bevp_ntypes.bem_CATCHGet_0();
bevp_rwords.bem_put_2(bevt_109_tmpany_phold, bevt_110_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGet_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_matchMapGetDirect_0() {
return bevp_matchMap;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_matchMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_matchMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_matchMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGet_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_rwordsGetDirect_0() {
return bevp_rwords;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_rwordsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_rwordsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_rwords = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxargsGet_0() {
return bevp_maxargs;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxargsGetDirect_0() {
return bevp_maxargs;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_maxargsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_maxargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_maxargsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_maxargs = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_extraSlotsGet_0() {
return bevp_extraSlots;
} /*method end*/
public BEC_2_4_3_MathInt bem_extraSlotsGetDirect_0() {
return bevp_extraSlots;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_extraSlotsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extraSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_extraSlotsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extraSlots = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxPadGet_0() {
return bevp_mtdxPad;
} /*method end*/
public BEC_2_4_3_MathInt bem_mtdxPadGetDirect_0() {
return bevp_mtdxPad;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_mtdxPadSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdxPad = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_mtdxPadSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdxPad = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindToGet_0() {
return bevp_unwindTo;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindToGetDirect_0() {
return bevp_unwindTo;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindTo = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindTo = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindOkGet_0() {
return bevp_unwindOk;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_unwindOkGetDirect_0() {
return bevp_unwindOk;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindOkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindOk = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_unwindOkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unwindOk = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operGet_0() {
return bevp_oper;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operGetDirect_0() {
return bevp_oper;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oper = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_oper = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operNamesGet_0() {
return bevp_operNames;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_operNamesGetDirect_0() {
return bevp_operNames;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operNamesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_operNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_operNamesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_operNames = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_conTypesGet_0() {
return bevp_conTypes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_conTypesGetDirect_0() {
return bevp_conTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_conTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_conTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_conTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_conTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_parensReqGet_0() {
return bevp_parensReq;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_parensReqGetDirect_0() {
return bevp_parensReq;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_parensReqSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parensReq = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_parensReqSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parensReq = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anchorTypesGet_0() {
return bevp_anchorTypes;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_anchorTypesGetDirect_0() {
return bevp_anchorTypes;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_anchorTypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_anchorTypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_anchorTypes = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 21, 22, 23, 24, 25, 26, 27, 28, 29, 33, 33, 33, 35, 35, 35, 36, 36, 36, 37, 37, 37, 39, 39, 39, 40, 40, 40, 41, 41, 41, 42, 42, 42, 43, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 49, 50, 50, 50, 51, 51, 51, 52, 52, 52, 53, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 57, 58, 58, 58, 59, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 63, 64, 64, 64, 65, 65, 65, 66, 66, 66, 67, 67, 67, 68, 68, 68, 69, 69, 69, 70, 70, 70, 72, 72, 72, 73, 73, 73, 74, 74, 74, 75, 75, 75, 76, 76, 76, 77, 77, 77, 78, 78, 78, 79, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83, 83, 84, 84, 84, 85, 85, 85, 86, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 89, 90, 90, 90, 91, 91, 91, 92, 92, 92, 93, 93, 93, 94, 94, 94, 95, 95, 95, 96, 96, 96, 97, 97, 97, 98, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 102, 102, 102, 103, 103, 103, 105, 105, 105, 106, 106, 106, 107, 107, 107, 108, 108, 108, 109, 109, 109, 110, 110, 110, 111, 111, 111, 112, 112, 112, 113, 113, 113, 114, 114, 114, 115, 115, 115, 116, 116, 116, 117, 117, 117, 118, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 126, 126, 126, 127, 127, 127, 128, 128, 128, 129, 129, 129, 130, 130, 130, 131, 131, 131, 132, 132, 132, 133, 133, 133, 134, 134, 134, 136, 136, 136, 137, 137, 137, 138, 138, 138, 139, 139, 139, 140, 140, 140, 141, 141, 141, 143, 149, 150, 152, 153, 153, 154, 154, 156, 157, 158, 158, 160, 161, 162, 162, 164, 165, 166, 166, 168, 169, 170, 170, 172, 173, 174, 174, 176, 177, 178, 178, 180, 181, 182, 182, 184, 185, 186, 186, 188, 189, 190, 190, 192, 193, 194, 194, 196, 197, 198, 198, 200, 201, 202, 202, 204, 205, 206, 206, 210, 210, 212, 213, 213, 215, 215, 217, 218, 218, 220, 220, 222, 223, 223, 225, 225, 227, 228, 228, 230, 230, 232, 233, 233, 235, 235, 237, 238, 238, 240, 240, 242, 243, 243, 245, 245, 247, 248, 248, 250, 250, 252, 253, 253, 255, 255, 257, 258, 258, 260, 260, 262, 263, 263, 265, 265, 267, 268, 268, 270, 270, 272, 273, 273, 275, 275, 277, 278, 278, 280, 280, 282, 283, 283, 285, 285, 287, 288, 288, 290, 290, 292, 293, 293, 295, 295, 297, 298, 298, 301, 302, 302, 302, 303, 303, 303, 304, 304, 304, 305, 305, 305, 306, 306, 306, 307, 307, 307, 308, 308, 308, 309, 309, 309, 310, 310, 310, 311, 311, 311, 312, 312, 312, 313, 313, 313, 314, 314, 314, 315, 315, 315, 316, 316, 316, 317, 317, 317, 318, 318, 318, 319, 319, 319, 320, 320, 320, 321, 321, 321, 322, 322, 322, 323, 323, 323, 324, 324, 324, 325, 325, 325, 326, 326, 326, 327, 327, 327, 328, 328, 328, 329, 329, 329, 330, 330, 330, 331, 331, 331, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 995, 998, 1001, 1005, 1009, 1012, 1015, 1019, 1023, 1026, 1029, 1033, 1037, 1040, 1043, 1047, 1051, 1054, 1057, 1061, 1065, 1068, 1071, 1075, 1079, 1082, 1085, 1089, 1093, 1096, 1099, 1103, 1107, 1110, 1113, 1117, 1121, 1124, 1127, 1131, 1135, 1138, 1141, 1145, 1149, 1152, 1155, 1159, 1163, 1166, 1169, 1173, 1177, 1180, 1183, 1187};
/* BEGIN LINEINFO 
assign 1 17 315
new 0 17 315
assign 1 18 316
new 0 18 316
assign 1 21 317
new 0 21 317
assign 1 22 318
new 0 22 318
assign 1 23 319
new 0 23 319
assign 1 24 320
new 0 24 320
assign 1 25 321
new 0 25 321
assign 1 26 322
new 0 26 322
assign 1 27 323
new 0 27 323
assign 1 28 324
new 0 28 324
assign 1 29 325
new 0 29 325
assign 1 33 326
new 0 33 326
assign 1 33 327
new 0 33 327
put 2 33 328
assign 1 35 329
new 0 35 329
assign 1 35 330
new 0 35 330
put 2 35 331
assign 1 36 332
new 0 36 332
assign 1 36 333
new 0 36 333
put 2 36 334
assign 1 37 335
new 0 37 335
assign 1 37 336
new 0 37 336
put 2 37 337
assign 1 39 338
NOTGet 0 39 338
assign 1 39 339
new 0 39 339
put 2 39 340
assign 1 40 341
ONCEGet 0 40 341
assign 1 40 342
new 0 40 342
put 2 40 343
assign 1 41 344
MANYGet 0 41 344
assign 1 41 345
new 0 41 345
put 2 41 346
assign 1 42 347
INCREMENTGet 0 42 347
assign 1 42 348
new 0 42 348
put 2 42 349
assign 1 43 350
DECREMENTGet 0 43 350
assign 1 43 351
new 0 43 351
put 2 43 352
assign 1 44 353
INCREMENT_ASSIGNGet 0 44 353
assign 1 44 354
new 0 44 354
put 2 44 355
assign 1 45 356
DECREMENT_ASSIGNGet 0 45 356
assign 1 45 357
new 0 45 357
put 2 45 358
assign 1 46 359
MULTIPLYGet 0 46 359
assign 1 46 360
new 0 46 360
put 2 46 361
assign 1 47 362
DIVIDEGet 0 47 362
assign 1 47 363
new 0 47 363
put 2 47 364
assign 1 48 365
MODULUSGet 0 48 365
assign 1 48 366
new 0 48 366
put 2 48 367
assign 1 49 368
ADDGet 0 49 368
assign 1 49 369
new 0 49 369
put 2 49 370
assign 1 50 371
SUBTRACTGet 0 50 371
assign 1 50 372
new 0 50 372
put 2 50 373
assign 1 51 374
GREATERGet 0 51 374
assign 1 51 375
new 0 51 375
put 2 51 376
assign 1 52 377
GREATER_EQUALSGet 0 52 377
assign 1 52 378
new 0 52 378
put 2 52 379
assign 1 53 380
LESSERGet 0 53 380
assign 1 53 381
new 0 53 381
put 2 53 382
assign 1 54 383
LESSER_EQUALSGet 0 54 383
assign 1 54 384
new 0 54 384
put 2 54 385
assign 1 55 386
EQUALSGet 0 55 386
assign 1 55 387
new 0 55 387
put 2 55 388
assign 1 56 389
NOT_EQUALSGet 0 56 389
assign 1 56 390
new 0 56 390
put 2 56 391
assign 1 57 392
ANDGet 0 57 392
assign 1 57 393
new 0 57 393
put 2 57 394
assign 1 58 395
ORGet 0 58 395
assign 1 58 396
new 0 58 396
put 2 58 397
assign 1 59 398
LOGICAL_ANDGet 0 59 398
assign 1 59 399
new 0 59 399
put 2 59 400
assign 1 60 401
LOGICAL_ORGet 0 60 401
assign 1 60 402
new 0 60 402
put 2 60 403
assign 1 61 404
INGet 0 61 404
assign 1 61 405
new 0 61 405
put 2 61 406
assign 1 62 407
GET_METHODGet 0 62 407
assign 1 62 408
new 0 62 408
put 2 62 409
assign 1 63 410
ADD_ASSIGNGet 0 63 410
assign 1 63 411
new 0 63 411
put 2 63 412
assign 1 64 413
SUBTRACT_ASSIGNGet 0 64 413
assign 1 64 414
new 0 64 414
put 2 64 415
assign 1 65 416
MULTIPLY_ASSIGNGet 0 65 416
assign 1 65 417
new 0 65 417
put 2 65 418
assign 1 66 419
DIVIDE_ASSIGNGet 0 66 419
assign 1 66 420
new 0 66 420
put 2 66 421
assign 1 67 422
MODULUS_ASSIGNGet 0 67 422
assign 1 67 423
new 0 67 423
put 2 67 424
assign 1 68 425
AND_ASSIGNGet 0 68 425
assign 1 68 426
new 0 68 426
put 2 68 427
assign 1 69 428
OR_ASSIGNGet 0 69 428
assign 1 69 429
new 0 69 429
put 2 69 430
assign 1 70 431
ASSIGNGet 0 70 431
assign 1 70 432
new 0 70 432
put 2 70 433
assign 1 72 434
NOTGet 0 72 434
assign 1 72 435
new 0 72 435
put 2 72 436
assign 1 73 437
ONCEGet 0 73 437
assign 1 73 438
new 0 73 438
put 2 73 439
assign 1 74 440
MANYGet 0 74 440
assign 1 74 441
new 0 74 441
put 2 74 442
assign 1 75 443
INCREMENTGet 0 75 443
assign 1 75 444
new 0 75 444
put 2 75 445
assign 1 76 446
DECREMENTGet 0 76 446
assign 1 76 447
new 0 76 447
put 2 76 448
assign 1 77 449
MULTIPLYGet 0 77 449
assign 1 77 450
new 0 77 450
put 2 77 451
assign 1 78 452
DIVIDEGet 0 78 452
assign 1 78 453
new 0 78 453
put 2 78 454
assign 1 79 455
MODULUSGet 0 79 455
assign 1 79 456
new 0 79 456
put 2 79 457
assign 1 80 458
ADDGet 0 80 458
assign 1 80 459
new 0 80 459
put 2 80 460
assign 1 81 461
SUBTRACTGet 0 81 461
assign 1 81 462
new 0 81 462
put 2 81 463
assign 1 82 464
GREATERGet 0 82 464
assign 1 82 465
new 0 82 465
put 2 82 466
assign 1 83 467
GREATER_EQUALSGet 0 83 467
assign 1 83 468
new 0 83 468
put 2 83 469
assign 1 84 470
LESSERGet 0 84 470
assign 1 84 471
new 0 84 471
put 2 84 472
assign 1 85 473
LESSER_EQUALSGet 0 85 473
assign 1 85 474
new 0 85 474
put 2 85 475
assign 1 86 476
EQUALSGet 0 86 476
assign 1 86 477
new 0 86 477
put 2 86 478
assign 1 87 479
NOT_EQUALSGet 0 87 479
assign 1 87 480
new 0 87 480
put 2 87 481
assign 1 88 482
ANDGet 0 88 482
assign 1 88 483
new 0 88 483
put 2 88 484
assign 1 89 485
ORGet 0 89 485
assign 1 89 486
new 0 89 486
put 2 89 487
assign 1 90 488
LOGICAL_ANDGet 0 90 488
assign 1 90 489
new 0 90 489
put 2 90 490
assign 1 91 491
LOGICAL_ORGet 0 91 491
assign 1 91 492
new 0 91 492
put 2 91 493
assign 1 92 494
INGet 0 92 494
assign 1 92 495
new 0 92 495
put 2 92 496
assign 1 93 497
GET_METHODGet 0 93 497
assign 1 93 498
new 0 93 498
put 2 93 499
assign 1 94 500
ADD_ASSIGNGet 0 94 500
assign 1 94 501
new 0 94 501
put 2 94 502
assign 1 95 503
SUBTRACT_ASSIGNGet 0 95 503
assign 1 95 504
new 0 95 504
put 2 95 505
assign 1 96 506
INCREMENT_ASSIGNGet 0 96 506
assign 1 96 507
new 0 96 507
put 2 96 508
assign 1 97 509
DECREMENT_ASSIGNGet 0 97 509
assign 1 97 510
new 0 97 510
put 2 97 511
assign 1 98 512
MULTIPLY_ASSIGNGet 0 98 512
assign 1 98 513
new 0 98 513
put 2 98 514
assign 1 99 515
DIVIDE_ASSIGNGet 0 99 515
assign 1 99 516
new 0 99 516
put 2 99 517
assign 1 100 518
MODULUS_ASSIGNGet 0 100 518
assign 1 100 519
new 0 100 519
put 2 100 520
assign 1 101 521
AND_ASSIGNGet 0 101 521
assign 1 101 522
new 0 101 522
put 2 101 523
assign 1 102 524
OR_ASSIGNGet 0 102 524
assign 1 102 525
new 0 102 525
put 2 102 526
assign 1 103 527
ASSIGNGet 0 103 527
assign 1 103 528
new 0 103 528
put 2 103 529
assign 1 105 530
IFGet 0 105 530
assign 1 105 531
new 0 105 531
put 2 105 532
assign 1 106 533
ELIFGet 0 106 533
assign 1 106 534
new 0 106 534
put 2 106 535
assign 1 107 536
WHILEGet 0 107 536
assign 1 107 537
new 0 107 537
put 2 107 538
assign 1 108 539
FORGet 0 108 539
assign 1 108 540
new 0 108 540
put 2 108 541
assign 1 109 542
FOREACHGet 0 109 542
assign 1 109 543
new 0 109 543
put 2 109 544
assign 1 110 545
EMITGet 0 110 545
assign 1 110 546
new 0 110 546
put 2 110 547
assign 1 111 548
IFEMITGet 0 111 548
assign 1 111 549
new 0 111 549
put 2 111 550
assign 1 112 551
METHODGet 0 112 551
assign 1 112 552
new 0 112 552
put 2 112 553
assign 1 113 554
CLASSGet 0 113 554
assign 1 113 555
new 0 113 555
put 2 113 556
assign 1 114 557
EXPRGet 0 114 557
assign 1 114 558
new 0 114 558
put 2 114 559
assign 1 115 560
ELSEGet 0 115 560
assign 1 115 561
new 0 115 561
put 2 115 562
assign 1 116 563
FINALLYGet 0 116 563
assign 1 116 564
new 0 116 564
put 2 116 565
assign 1 117 566
TRYGet 0 117 566
assign 1 117 567
new 0 117 567
put 2 117 568
assign 1 118 569
LOOPGet 0 118 569
assign 1 118 570
new 0 118 570
put 2 118 571
assign 1 119 572
PROPERTIESGet 0 119 572
assign 1 119 573
new 0 119 573
put 2 119 574
assign 1 120 575
CATCHGet 0 120 575
assign 1 120 576
new 0 120 576
put 2 120 577
assign 1 121 578
TRANSUNITGet 0 121 578
assign 1 121 579
new 0 121 579
put 2 121 580
assign 1 122 581
BRACESGet 0 122 581
assign 1 122 582
new 0 122 582
put 2 122 583
assign 1 123 584
PARENSGet 0 123 584
assign 1 123 585
new 0 123 585
put 2 123 586
assign 1 124 587
IDXGet 0 124 587
assign 1 124 588
new 0 124 588
put 2 124 589
assign 1 126 590
IFGet 0 126 590
assign 1 126 591
new 0 126 591
put 2 126 592
assign 1 127 593
ELIFGet 0 127 593
assign 1 127 594
new 0 127 594
put 2 127 595
assign 1 128 596
WHILEGet 0 128 596
assign 1 128 597
new 0 128 597
put 2 128 598
assign 1 129 599
FORGet 0 129 599
assign 1 129 600
new 0 129 600
put 2 129 601
assign 1 130 602
FOREACHGet 0 130 602
assign 1 130 603
new 0 130 603
put 2 130 604
assign 1 131 605
EMITGet 0 131 605
assign 1 131 606
new 0 131 606
put 2 131 607
assign 1 132 608
IFEMITGet 0 132 608
assign 1 132 609
new 0 132 609
put 2 132 610
assign 1 133 611
METHODGet 0 133 611
assign 1 133 612
new 0 133 612
put 2 133 613
assign 1 134 614
CATCHGet 0 134 614
assign 1 134 615
new 0 134 615
put 2 134 616
assign 1 136 617
IFGet 0 136 617
assign 1 136 618
new 0 136 618
put 2 136 619
assign 1 137 620
ELIFGet 0 137 620
assign 1 137 621
new 0 137 621
put 2 137 622
assign 1 138 623
WHILEGet 0 138 623
assign 1 138 624
new 0 138 624
put 2 138 625
assign 1 139 626
FORGet 0 139 626
assign 1 139 627
new 0 139 627
put 2 139 628
assign 1 140 629
FOREACHGet 0 140 629
assign 1 140 630
new 0 140 630
put 2 140 631
assign 1 141 632
EXPRGet 0 141 632
assign 1 141 633
new 0 141 633
put 2 141 634
prepare 0 143 635
assign 1 149 752
new 0 149 752
assign 1 150 753
new 0 150 753
assign 1 152 754
new 0 152 754
assign 1 153 755
new 0 153 755
assign 1 153 756
new 2 153 756
assign 1 154 757
DIVIDEGet 0 154 757
put 2 154 758
assign 1 156 759
new 0 156 759
addToken 1 157 760
assign 1 158 761
BRACESGet 0 158 761
put 2 158 762
assign 1 160 763
new 0 160 763
addToken 1 161 764
assign 1 162 765
RBRACESGet 0 162 765
put 2 162 766
assign 1 164 767
new 0 164 767
addToken 1 165 768
assign 1 166 769
PARENSGet 0 166 769
put 2 166 770
assign 1 168 771
new 0 168 771
addToken 1 169 772
assign 1 170 773
RPARENSGet 0 170 773
put 2 170 774
assign 1 172 775
new 0 172 775
addToken 1 173 776
assign 1 174 777
SEMIGet 0 174 777
put 2 174 778
assign 1 176 779
new 0 176 779
addToken 1 177 780
assign 1 178 781
COLONGet 0 178 781
put 2 178 782
assign 1 180 783
new 0 180 783
addToken 1 181 784
assign 1 182 785
COMMAGet 0 182 785
put 2 182 786
assign 1 184 787
new 0 184 787
addToken 1 185 788
assign 1 186 789
ADDGet 0 186 789
put 2 186 790
assign 1 188 791
new 0 188 791
addToken 1 189 792
assign 1 190 793
ATYPEGet 0 190 793
put 2 190 794
assign 1 192 795
new 0 192 795
addToken 1 193 796
assign 1 194 797
SUBTRACTGet 0 194 797
put 2 194 798
assign 1 196 799
new 0 196 799
addToken 1 197 800
assign 1 198 801
ONCEGet 0 198 801
put 2 198 802
assign 1 200 803
new 0 200 803
addToken 1 201 804
assign 1 202 805
MANYGet 0 202 805
put 2 202 806
assign 1 204 807
new 0 204 807
addToken 1 205 808
assign 1 206 809
GET_METHODGet 0 206 809
put 2 206 810
assign 1 210 811
new 0 210 811
assign 1 210 812
codeNew 1 210 812
addToken 1 212 813
assign 1 213 814
FSLASHGet 0 213 814
put 2 213 815
assign 1 215 816
new 0 215 816
assign 1 215 817
codeNew 1 215 817
addToken 1 217 818
assign 1 218 819
STRQGet 0 218 819
put 2 218 820
assign 1 220 821
new 0 220 821
assign 1 220 822
codeNew 1 220 822
addToken 1 222 823
assign 1 223 824
WSTRQGet 0 223 824
put 2 223 825
assign 1 225 826
new 0 225 826
assign 1 225 827
codeNew 1 225 827
addToken 1 227 828
assign 1 228 829
IDXGet 0 228 829
put 2 228 830
assign 1 230 831
new 0 230 831
assign 1 230 832
codeNew 1 230 832
addToken 1 232 833
assign 1 233 834
RIDXGet 0 233 834
put 2 233 835
assign 1 235 836
new 0 235 836
assign 1 235 837
codeNew 1 235 837
addToken 1 237 838
assign 1 238 839
MODULUSGet 0 238 839
put 2 238 840
assign 1 240 841
new 0 240 841
assign 1 240 842
codeNew 1 240 842
addToken 1 242 843
assign 1 243 844
ASSIGNGet 0 243 844
put 2 243 845
assign 1 245 846
new 0 245 846
assign 1 245 847
codeNew 1 245 847
addToken 1 247 848
assign 1 248 849
GREATERGet 0 248 849
put 2 248 850
assign 1 250 851
new 0 250 851
assign 1 250 852
codeNew 1 250 852
addToken 1 252 853
assign 1 253 854
LESSERGet 0 253 854
put 2 253 855
assign 1 255 856
new 0 255 856
assign 1 255 857
codeNew 1 255 857
addToken 1 257 858
assign 1 258 859
NOTGet 0 258 859
put 2 258 860
assign 1 260 861
new 0 260 861
assign 1 260 862
codeNew 1 260 862
addToken 1 262 863
assign 1 263 864
ANDGet 0 263 864
put 2 263 865
assign 1 265 866
new 0 265 866
assign 1 265 867
codeNew 1 265 867
addToken 1 267 868
assign 1 268 869
ORGet 0 268 869
put 2 268 870
assign 1 270 871
new 0 270 871
assign 1 270 872
codeNew 1 270 872
addToken 1 272 873
assign 1 273 874
MULTIPLYGet 0 273 874
put 2 273 875
assign 1 275 876
new 0 275 876
assign 1 275 877
codeNew 1 275 877
addToken 1 277 878
assign 1 278 879
DOTGet 0 278 879
put 2 278 880
assign 1 280 881
new 0 280 881
assign 1 280 882
codeNew 1 280 882
addToken 1 282 883
assign 1 283 884
SPACEGet 0 283 884
put 2 283 885
assign 1 285 886
new 0 285 886
assign 1 285 887
codeNew 1 285 887
addToken 1 287 888
assign 1 288 889
SPACEGet 0 288 889
put 2 288 890
assign 1 290 891
new 0 290 891
assign 1 290 892
crGet 0 290 892
addToken 1 292 893
assign 1 293 894
NEWLINEGet 0 293 894
put 2 293 895
assign 1 295 896
new 0 295 896
assign 1 295 897
lfGet 0 295 897
addToken 1 297 898
assign 1 298 899
NEWLINEGet 0 298 899
put 2 298 900
assign 1 301 901
new 0 301 901
assign 1 302 902
new 0 302 902
assign 1 302 903
USEGet 0 302 903
put 2 302 904
assign 1 303 905
new 0 303 905
assign 1 303 906
ASGet 0 303 906
put 2 303 907
assign 1 304 908
new 0 304 908
assign 1 304 909
CLASSGet 0 304 909
put 2 304 910
assign 1 305 911
new 0 305 911
assign 1 305 912
METHODGet 0 305 912
put 2 305 913
assign 1 306 914
new 0 306 914
assign 1 306 915
DEFMODGet 0 306 915
put 2 306 916
assign 1 307 917
new 0 307 917
assign 1 307 918
DEFMODGet 0 307 918
put 2 307 919
assign 1 308 920
new 0 308 920
assign 1 308 921
DEFMODGet 0 308 921
put 2 308 922
assign 1 309 923
new 0 309 923
assign 1 309 924
VARGet 0 309 924
put 2 309 925
assign 1 310 926
new 0 310 926
assign 1 310 927
VARGet 0 310 927
put 2 310 928
assign 1 311 929
new 0 311 929
assign 1 311 930
IFGet 0 311 930
put 2 311 931
assign 1 312 932
new 0 312 932
assign 1 312 933
IFGet 0 312 933
put 2 312 934
assign 1 313 935
new 0 313 935
assign 1 313 936
ELIFGet 0 313 936
put 2 313 937
assign 1 314 938
new 0 314 938
assign 1 314 939
ELSEGet 0 314 939
put 2 314 940
assign 1 315 941
new 0 315 941
assign 1 315 942
FINALLYGet 0 315 942
put 2 315 943
assign 1 316 944
new 0 316 944
assign 1 316 945
LOOPGet 0 316 945
put 2 316 946
assign 1 317 947
new 0 317 947
assign 1 317 948
PROPERTIESGet 0 317 948
put 2 317 949
assign 1 318 950
new 0 318 950
assign 1 318 951
WHILEGet 0 318 951
put 2 318 952
assign 1 319 953
new 0 319 953
assign 1 319 954
WHILEGet 0 319 954
put 2 319 955
assign 1 320 956
new 0 320 956
assign 1 320 957
FORGet 0 320 957
put 2 320 958
assign 1 321 959
new 0 321 959
assign 1 321 960
INGet 0 321 960
put 2 321 961
assign 1 322 962
new 0 322 962
assign 1 322 963
EMITGet 0 322 963
put 2 322 964
assign 1 323 965
new 0 323 965
assign 1 323 966
IFEMITGet 0 323 966
put 2 323 967
assign 1 324 968
new 0 324 968
assign 1 324 969
IFEMITGet 0 324 969
put 2 324 970
assign 1 325 971
new 0 325 971
assign 1 325 972
BREAKGet 0 325 972
put 2 325 973
assign 1 326 974
new 0 326 974
assign 1 326 975
CONTINUEGet 0 326 975
put 2 326 976
assign 1 327 977
new 0 327 977
assign 1 327 978
NULLGet 0 327 978
put 2 327 979
assign 1 328 980
new 0 328 980
assign 1 328 981
TRUEGet 0 328 981
put 2 328 982
assign 1 329 983
new 0 329 983
assign 1 329 984
FALSEGet 0 329 984
put 2 329 985
assign 1 330 986
new 0 330 986
assign 1 330 987
TRYGet 0 330 987
put 2 330 988
assign 1 331 989
new 0 331 989
assign 1 331 990
CATCHGet 0 331 990
put 2 331 991
return 1 0 995
return 1 0 998
assign 1 0 1001
assign 1 0 1005
return 1 0 1009
return 1 0 1012
assign 1 0 1015
assign 1 0 1019
return 1 0 1023
return 1 0 1026
assign 1 0 1029
assign 1 0 1033
return 1 0 1037
return 1 0 1040
assign 1 0 1043
assign 1 0 1047
return 1 0 1051
return 1 0 1054
assign 1 0 1057
assign 1 0 1061
return 1 0 1065
return 1 0 1068
assign 1 0 1071
assign 1 0 1075
return 1 0 1079
return 1 0 1082
assign 1 0 1085
assign 1 0 1089
return 1 0 1093
return 1 0 1096
assign 1 0 1099
assign 1 0 1103
return 1 0 1107
return 1 0 1110
assign 1 0 1113
assign 1 0 1117
return 1 0 1121
return 1 0 1124
assign 1 0 1127
assign 1 0 1131
return 1 0 1135
return 1 0 1138
assign 1 0 1141
assign 1 0 1145
return 1 0 1149
return 1 0 1152
assign 1 0 1155
assign 1 0 1159
return 1 0 1163
return 1 0 1166
assign 1 0 1169
assign 1 0 1173
return 1 0 1177
return 1 0 1180
assign 1 0 1183
assign 1 0 1187
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1993157878: return bem_ntypesGetDirect_0();
case -1123278056: return bem_tagGet_0();
case -1709666828: return bem_unwindOkGet_0();
case 1071461198: return bem_echo_0();
case 1942283510: return bem_sourceFileNameGet_0();
case -426367037: return bem_unwindToGet_0();
case -10010145: return bem_copy_0();
case 96033137: return bem_serializeToString_0();
case -32405487: return bem_conTypesGet_0();
case -449079106: return bem_iteratorGet_0();
case -1086782351: return bem_print_0();
case -273815529: return bem_rwordsGetDirect_0();
case 865382202: return bem_matchMapGetDirect_0();
case -1347182982: return bem_parensReqGet_0();
case -2094049544: return bem_operNamesGet_0();
case -2051518290: return bem_once_0();
case 669359214: return bem_twtokGet_0();
case -1336323150: return bem_conTypesGetDirect_0();
case -1721457210: return bem_extraSlotsGet_0();
case -906271964: return bem_mtdxPadGetDirect_0();
case -31752856: return bem_prepare_0();
case 805334013: return bem_operNamesGetDirect_0();
case 1493253182: return bem_parensReqGetDirect_0();
case 580077444: return bem_unwindOkGetDirect_0();
case -1424964926: return bem_anchorTypesGetDirect_0();
case -1444553751: return bem_maxargsGet_0();
case 24882547: return bem_matchMapGet_0();
case 1194804327: return bem_fieldNamesGet_0();
case 637319591: return bem_mtdxPadGet_0();
case -993475516: return bem_operGet_0();
case -638409038: return bem_maxargsGetDirect_0();
case 1513233059: return bem_toString_0();
case -671121460: return bem_rwordsGet_0();
case -713163994: return bem_toAny_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case 1851908877: return bem_hashGet_0();
case 1571965189: return bem_extraSlotsGetDirect_0();
case 1577195459: return bem_serializationIteratorGet_0();
case 306552665: return bem_operGetDirect_0();
case -1266447496: return bem_classNameGet_0();
case 1683507372: return bem_unwindToGetDirect_0();
case -1362850090: return bem_serializeContents_0();
case 611670694: return bem_fieldIteratorGet_0();
case 144584723: return bem_create_0();
case 722737178: return bem_twtokGetDirect_0();
case 990360647: return bem_new_0();
case 1193197051: return bem_ntypesGet_0();
case -196290645: return bem_anchorTypesGet_0();
case 341575045: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1449340032: return bem_otherClass_1(bevd_0);
case -1582374660: return bem_operSet_1(bevd_0);
case -10580086: return bem_operNamesSetDirect_1(bevd_0);
case 1655992563: return bem_rwordsSetDirect_1(bevd_0);
case -1071001840: return bem_new_1(bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1981410934: return bem_matchMapSetDirect_1(bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -450313600: return bem_operSetDirect_1(bevd_0);
case -1940126441: return bem_unwindToSetDirect_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case -538279248: return bem_extraSlotsSet_1(bevd_0);
case 794015147: return bem_extraSlotsSetDirect_1(bevd_0);
case 546190358: return bem_conTypesSetDirect_1(bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case -334859553: return bem_rwordsSet_1(bevd_0);
case 1498170969: return bem_mtdxPadSet_1(bevd_0);
case 2078731690: return bem_twtokSet_1(bevd_0);
case -972655277: return bem_anchorTypesSet_1(bevd_0);
case -655019399: return bem_def_1(bevd_0);
case 100896943: return bem_matchMapSet_1(bevd_0);
case 1502986976: return bem_anchorTypesSetDirect_1(bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case -52861081: return bem_twtokSetDirect_1(bevd_0);
case -2117637071: return bem_maxargsSetDirect_1(bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -917035625: return bem_unwindOkSet_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case -187300612: return bem_ntypesSet_1(bevd_0);
case -1320662597: return bem_unwindOkSetDirect_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case 171896441: return bem_unwindToSet_1(bevd_0);
case 895323866: return bem_parensReqSetDirect_1(bevd_0);
case -251570910: return bem_operNamesSet_1(bevd_0);
case -1656017496: return bem_maxargsSet_1(bevd_0);
case 237076933: return bem_conTypesSet_1(bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case -1744479301: return bem_ntypesSetDirect_1(bevd_0);
case -329368588: return bem_mtdxPadSetDirect_1(bevd_0);
case 132739403: return bem_parensReqSet_1(bevd_0);
case -390319261: return bem_equals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildConstants_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildConstants_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildConstants();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_inst = (BEC_2_5_9_BuildConstants) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildConstants.bece_BEC_2_5_9_BuildConstants_bevs_type;
}
}
}
