namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_3_6_10_7_SystemSerializerSession : BEC_2_6_6_SystemObject {
public BEC_3_6_10_7_SystemSerializerSession() { }
static BEC_3_6_10_7_SystemSerializerSession() { }
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x3A,0x53,0x65,0x73,0x73,0x69,0x6F,0x6E};
private static byte[] becc_BEC_3_6_10_7_SystemSerializerSession_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static new BEC_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;

public static new BET_3_6_10_7_SystemSerializerSession bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;

public BEC_2_9_3_ContainerMap bevp_classTagMap;
public BEC_2_4_3_MathInt bevp_classTagCount;
public BEC_2_4_3_MathInt bevp_serialCount;
public BEC_2_9_11_ContainerIdentityMap bevp_unique;
public BEC_2_6_6_SystemObject bevp_instWriter;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_classTagCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_serialCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) (new BEC_2_9_11_ContainerIdentityMap()).bem_new_0();
return this;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_new_1(BEC_2_6_6_SystemObject beva__instWriter) {
bem_new_0();
bevp_instWriter = beva__instWriter;
return this;
} /*method end*/
public virtual BEC_2_9_3_ContainerMap bem_classTagMapGet_0() {
return bevp_classTagMap;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_classTagMapGetDirect_0() {
return bevp_classTagMap;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagMapSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classTagMap = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_classTagCountGet_0() {
return bevp_classTagCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_classTagCountGetDirect_0() {
return bevp_classTagCount;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_classTagCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classTagCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_serialCountGet_0() {
return bevp_serialCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_serialCountGetDirect_0() {
return bevp_serialCount;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_serialCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_serialCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_serialCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_11_ContainerIdentityMap bem_uniqueGet_0() {
return bevp_unique;
} /*method end*/
public BEC_2_9_11_ContainerIdentityMap bem_uniqueGetDirect_0() {
return bevp_unique;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_uniqueSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_uniqueSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unique = (BEC_2_9_11_ContainerIdentityMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_instWriterGet_0() {
return bevp_instWriter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_instWriterGetDirect_0() {
return bevp_instWriter;
} /*method end*/
public virtual BEC_3_6_10_7_SystemSerializerSession bem_instWriterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instWriter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_10_7_SystemSerializerSession bem_instWriterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_instWriter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {30, 31, 32, 33, 39, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 20, 21, 25, 26, 30, 33, 36, 40, 44, 47, 50, 54, 58, 61, 64, 68, 72, 75, 78, 82, 86, 89, 92, 96};
/* BEGIN LINEINFO 
assign 1 30 18
new 0 30 18
assign 1 31 19
new 0 31 19
assign 1 32 20
new 0 32 20
assign 1 33 21
new 0 33 21
new 0 39 25
assign 1 40 26
return 1 0 30
return 1 0 33
assign 1 0 36
assign 1 0 40
return 1 0 44
return 1 0 47
assign 1 0 50
assign 1 0 54
return 1 0 58
return 1 0 61
assign 1 0 64
assign 1 0 68
return 1 0 72
return 1 0 75
assign 1 0 78
assign 1 0 82
return 1 0 86
return 1 0 89
assign 1 0 92
assign 1 0 96
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -825084265: return bem_hashGet_0();
case -1031399474: return bem_echo_0();
case 1970758688: return bem_fieldNamesGet_0();
case 916294969: return bem_sourceFileNameGet_0();
case -47911806: return bem_classTagCountGetDirect_0();
case 1131385505: return bem_toAny_0();
case 1279906777: return bem_serializeToString_0();
case 131226213: return bem_toString_0();
case 84108411: return bem_uniqueGetDirect_0();
case 431618869: return bem_once_0();
case 1938842604: return bem_classTagMapGet_0();
case -303848176: return bem_serialCountGetDirect_0();
case -1147687234: return bem_uniqueGet_0();
case 2113863727: return bem_serialCountGet_0();
case -928163909: return bem_fieldIteratorGet_0();
case 1253953314: return bem_serializationIteratorGet_0();
case 343375430: return bem_create_0();
case -957769093: return bem_deserializeClassNameGet_0();
case 1467637849: return bem_instWriterGet_0();
case 911313117: return bem_tagGet_0();
case -819754696: return bem_classTagMapGetDirect_0();
case 421749162: return bem_iteratorGet_0();
case 2063546474: return bem_classNameGet_0();
case 2061421621: return bem_many_0();
case -2051799514: return bem_new_0();
case -1485517163: return bem_copy_0();
case -1846550974: return bem_serializeContents_0();
case -1574932366: return bem_print_0();
case 640324663: return bem_instWriterGetDirect_0();
case -92330186: return bem_classTagCountGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 747155616: return bem_notEquals_1(bevd_0);
case 353231525: return bem_instWriterSetDirect_1(bevd_0);
case -1583403080: return bem_serialCountSetDirect_1(bevd_0);
case 1889683305: return bem_new_1(bevd_0);
case -723361641: return bem_uniqueSetDirect_1(bevd_0);
case -1551421646: return bem_copyTo_1(bevd_0);
case 192530319: return bem_otherType_1(bevd_0);
case -628476976: return bem_otherClass_1(bevd_0);
case -436556280: return bem_undef_1(bevd_0);
case 1555616281: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1655018142: return bem_sameType_1(bevd_0);
case -599118179: return bem_classTagCountSet_1(bevd_0);
case 1971072901: return bem_classTagMapSetDirect_1(bevd_0);
case -130335974: return bem_uniqueSet_1(bevd_0);
case -1181240679: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1352976047: return bem_serialCountSet_1(bevd_0);
case -130359318: return bem_classTagCountSetDirect_1(bevd_0);
case 1768644351: return bem_sameClass_1(bevd_0);
case -1065536512: return bem_equals_1(bevd_0);
case 1383324451: return bem_sameObject_1(bevd_0);
case -1809169317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1147111468: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1792169456: return bem_classTagMapSet_1(bevd_0);
case 1928047187: return bem_undefined_1(bevd_0);
case 1044863323: return bem_defined_1(bevd_0);
case -2018944701: return bem_def_1(bevd_0);
case -684188349: return bem_instWriterSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1990600260: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1260241587: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -598891548: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1655882914: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1041029455: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -214435591: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -40143354: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(25, becc_BEC_3_6_10_7_SystemSerializerSession_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_3_6_10_7_SystemSerializerSession_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_6_10_7_SystemSerializerSession();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst = (BEC_3_6_10_7_SystemSerializerSession) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_6_10_7_SystemSerializerSession.bece_BEC_3_6_10_7_SystemSerializerSession_bevs_type;
}
}
}
