namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_8_7_TemplateReplace : BEC_2_6_6_SystemObject {
public BEC_2_8_7_TemplateReplace() { }
static BEC_2_8_7_TemplateReplace() { }
private static byte[] becc_BEC_2_8_7_TemplateReplace_clname = {0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x3A,0x52,0x65,0x70,0x6C,0x61,0x63,0x65};
private static byte[] becc_BEC_2_8_7_TemplateReplace_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_0 = {0x3C,0x3F,0x74,0x74};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_1 = {0x3F,0x3E};
private static byte[] bece_BEC_2_8_7_TemplateReplace_bels_2 = {0x20};
public static new BEC_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_inst;

public static new BET_2_8_7_TemplateReplace bece_BEC_2_8_7_TemplateReplace_bevs_type;

public BEC_2_9_10_ContainerLinkedList bevp_steps;
public BEC_2_4_3_MathInt bevp_size;
public BEC_2_5_4_LogicBool bevp_append;
public BEC_2_8_6_TemplateRunner bevp_runner;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_append = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_load_1(BEC_2_4_6_TextString beva_template) {
bem_load_2(beva_template, null);
return this;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_load_2(BEC_2_4_6_TextString beva_template, BEC_2_8_6_TemplateRunner beva__runner) {
BEC_2_4_6_TextString bevl_blStart = null;
BEC_2_4_6_TextString bevl_blEnd = null;
BEC_2_5_4_LogicBool bevl_onStart = null;
BEC_2_5_4_LogicBool bevl_nextIsCall = null;
BEC_2_4_6_TextString bevl_delim = null;
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_3_MathInt bevl_last = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_ds = null;
BEC_2_4_6_TextString bevl_payload = null;
BEC_2_9_10_ContainerLinkedList bevl_payloads = null;
BEC_2_7_8_ReplaceCallStep bevl_rcs = null;
BEC_2_4_6_TextString bevl_paypart = null;
BEC_2_7_7_ReplaceRunStep bevl_rs = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_7_10_ReplaceStringStep bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_7_10_ReplaceStringStep bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevp_runner = beva__runner;
bevp_size = beva_template.bem_sizeGet_0();
bevl_blStart = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_8_7_TemplateReplace_bels_0));
bevl_blEnd = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_8_7_TemplateReplace_bels_1));
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blStart;
bevl_splits = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_last = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
bevl_ds = bevl_delim.bem_sizeGet_0();
while (true)
 /* Line: 83 */ {
if (bevl_i == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 83 */ {
if (bevl_i.bevi_int > bevl_last.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 84 */ {
if (bevl_nextIsCall.bevi_bool) /* Line: 85 */ {
bevt_3_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevl_i);
bevl_payload = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_strip_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_8_7_TemplateReplace_bels_2));
bevl_payloads = bevl_payload.bem_split_1(bevt_4_tmpany_phold);
if (bevp_runner == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevl_rcs = (BEC_2_7_8_ReplaceCallStep) (new BEC_2_7_8_ReplaceCallStep()).bem_new_1(bevl_payloads);
bevl_splits.bem_addValue_1(bevl_rcs);
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 92 */
 else  /* Line: 93 */ {
bevt_0_tmpany_loop = bevl_payloads.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 95 */ {
bevt_6_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_6_tmpany_phold).bevi_bool) /* Line: 95 */ {
bevl_paypart = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_rs = (BEC_2_7_7_ReplaceRunStep) (new BEC_2_7_7_ReplaceRunStep()).bem_new_2(this, bevl_paypart);
bevl_splits.bem_addValue_1(bevl_rs);
} /* Line: 97 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 99 */
} /* Line: 88 */
 else  /* Line: 101 */ {
bevt_8_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevl_i);
bevt_7_tmpany_phold = (BEC_2_7_10_ReplaceStringStep) (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_8_tmpany_phold);
bevl_splits.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 102 */
} /* Line: 85 */
bevl_last = bevl_i.bem_add_1(bevl_ds);
if (bevl_onStart.bevi_bool) /* Line: 106 */ {
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_delim = bevl_blEnd;
bevl_ds = bevl_delim.bem_sizeGet_0();
bevl_nextIsCall = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
} /* Line: 110 */
 else  /* Line: 111 */ {
bevl_onStart = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_delim = bevl_blStart;
bevl_ds = bevl_delim.bem_sizeGet_0();
} /* Line: 114 */
bevl_i = beva_template.bem_find_2(bevl_delim, bevl_last);
} /* Line: 116 */
 else  /* Line: 83 */ {
break;
} /* Line: 83 */
} /* Line: 83 */
if (bevl_last.bevi_int < bevp_size.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 118 */ {
bevt_11_tmpany_phold = beva_template.bem_substring_2(bevl_last, bevp_size);
bevt_10_tmpany_phold = (BEC_2_7_10_ReplaceStringStep) (new BEC_2_7_10_ReplaceStringStep()).bem_new_1(bevt_11_tmpany_phold);
bevl_splits.bem_addValue_1(bevt_10_tmpany_phold);
} /* Line: 119 */
bevp_steps = bevl_splits;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_accept_2(BEC_2_6_6_SystemObject beva_inst, BEC_2_6_6_SystemObject beva_out) {
BEC_2_6_6_SystemObject bevl_iter = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_iter = bevp_steps.bem_iteratorGet_0();
while (true)
 /* Line: 126 */ {
bevt_0_tmpany_phold = bevl_iter.bemd_0(395045729);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevl_s = bevl_iter.bemd_0(1286644729);
if (bevp_append.bevi_bool) /* Line: 128 */ {
bevt_1_tmpany_phold = bevl_s.bemd_1(-34343588, beva_inst);
beva_out.bemd_1(-31836502, bevt_1_tmpany_phold);
} /* Line: 129 */
} /* Line: 128 */
 else  /* Line: 126 */ {
break;
} /* Line: 126 */
} /* Line: 126 */
return beva_out;
} /*method end*/
public virtual BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() {
return bevp_steps;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGetDirect_0() {
return bevp_steps;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_stepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_stepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_steps = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_appendGet_0() {
return bevp_append;
} /*method end*/
public BEC_2_5_4_LogicBool bem_appendGetDirect_0() {
return bevp_append;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_appendSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_appendSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_append = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_8_6_TemplateRunner bem_runnerGet_0() {
return bevp_runner;
} /*method end*/
public BEC_2_8_6_TemplateRunner bem_runnerGetDirect_0() {
return bevp_runner;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_runnerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_runnerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runner = (BEC_2_8_6_TemplateRunner) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {59, 66, 70, 71, 73, 74, 75, 76, 78, 79, 80, 81, 82, 83, 83, 84, 84, 86, 86, 87, 87, 88, 88, 90, 91, 92, 95, 0, 95, 95, 96, 97, 99, 102, 102, 102, 105, 107, 108, 109, 110, 112, 113, 114, 116, 118, 118, 119, 119, 119, 121, 125, 126, 127, 129, 129, 132, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {20, 24, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 67, 72, 73, 78, 80, 81, 82, 83, 84, 89, 90, 91, 92, 95, 95, 98, 100, 101, 102, 108, 112, 113, 114, 117, 119, 120, 121, 122, 125, 126, 127, 129, 135, 140, 141, 142, 143, 145, 153, 156, 158, 160, 161, 168, 171, 174, 177, 181, 185, 188, 191, 195, 199, 202, 205, 209, 213, 216, 219, 223};
/* BEGIN LINEINFO 
assign 1 59 20
new 0 59 20
load 2 66 24
assign 1 70 54
assign 1 71 55
sizeGet 0 71 55
assign 1 73 56
new 0 73 56
assign 1 74 57
new 0 74 57
assign 1 75 58
new 0 75 58
assign 1 76 59
new 0 76 59
assign 1 78 60
assign 1 79 61
new 0 79 61
assign 1 80 62
new 0 80 62
assign 1 81 63
find 2 81 63
assign 1 82 64
sizeGet 0 82 64
assign 1 83 67
def 1 83 72
assign 1 84 73
greater 1 84 78
assign 1 86 80
substring 2 86 80
assign 1 86 81
strip 0 86 81
assign 1 87 82
new 0 87 82
assign 1 87 83
split 1 87 83
assign 1 88 84
undef 1 88 89
assign 1 90 90
new 1 90 90
addValue 1 91 91
assign 1 92 92
new 0 92 92
assign 1 95 95
linkedListIteratorGet 0 0 95
assign 1 95 98
hasNextGet 0 95 98
assign 1 95 100
nextGet 0 95 100
assign 1 96 101
new 2 96 101
addValue 1 97 102
assign 1 99 108
new 0 99 108
assign 1 102 112
substring 2 102 112
assign 1 102 113
new 1 102 113
addValue 1 102 114
assign 1 105 117
add 1 105 117
assign 1 107 119
new 0 107 119
assign 1 108 120
assign 1 109 121
sizeGet 0 109 121
assign 1 110 122
new 0 110 122
assign 1 112 125
new 0 112 125
assign 1 113 126
assign 1 114 127
sizeGet 0 114 127
assign 1 116 129
find 2 116 129
assign 1 118 135
lesser 1 118 140
assign 1 119 141
substring 2 119 141
assign 1 119 142
new 1 119 142
addValue 1 119 143
assign 1 121 145
assign 1 125 153
iteratorGet 0 125 153
assign 1 126 156
hasNextGet 0 126 156
assign 1 127 158
nextGet 0 127 158
assign 1 129 160
handle 1 129 160
write 1 129 161
return 1 132 168
return 1 0 171
return 1 0 174
assign 1 0 177
assign 1 0 181
return 1 0 185
return 1 0 188
assign 1 0 191
assign 1 0 195
return 1 0 199
return 1 0 202
assign 1 0 205
assign 1 0 209
return 1 0 213
return 1 0 216
assign 1 0 219
assign 1 0 223
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 427546453: return bem_appendGet_0();
case -1528760183: return bem_appendGetDirect_0();
case -1615839398: return bem_echo_0();
case -1043543071: return bem_create_0();
case -1048585343: return bem_copy_0();
case -1800587860: return bem_serializeToString_0();
case 976768273: return bem_fieldNamesGet_0();
case -2011984947: return bem_classNameGet_0();
case 1273358520: return bem_sizeGetDirect_0();
case -193453355: return bem_iteratorGet_0();
case -629972183: return bem_runnerGet_0();
case -477940854: return bem_hashGet_0();
case 1463816718: return bem_sourceFileNameGet_0();
case -1021558772: return bem_fieldIteratorGet_0();
case -1852647932: return bem_serializeContents_0();
case -246834477: return bem_runnerGetDirect_0();
case 190764838: return bem_toString_0();
case 795649196: return bem_serializationIteratorGet_0();
case -1169168081: return bem_sizeGet_0();
case -204986197: return bem_print_0();
case -1017732045: return bem_toAny_0();
case 1809869265: return bem_many_0();
case 2022567405: return bem_tagGet_0();
case 947248908: return bem_stepsGet_0();
case -980346590: return bem_stepsGetDirect_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -1200514874: return bem_once_0();
case 451316734: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 460476795: return bem_runnerSetDirect_1(bevd_0);
case 845269687: return bem_runnerSet_1(bevd_0);
case -974417776: return bem_undef_1(bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case 1255352870: return bem_notEquals_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -458022194: return bem_stepsSetDirect_1(bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case 433553075: return bem_sizeSetDirect_1(bevd_0);
case 1104932541: return bem_load_1((BEC_2_4_6_TextString) bevd_0);
case -1707652013: return bem_appendSet_1(bevd_0);
case 616552912: return bem_sizeSet_1(bevd_0);
case 185795652: return bem_appendSetDirect_1(bevd_0);
case -252330168: return bem_def_1(bevd_0);
case -757929155: return bem_stepsSet_1(bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1346336130: return bem_load_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_8_6_TemplateRunner) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -140053705: return bem_accept_2(bevd_0, bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_8_7_TemplateReplace_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_8_7_TemplateReplace_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_8_7_TemplateReplace();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst = (BEC_2_8_7_TemplateReplace) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_8_7_TemplateReplace.bece_BEC_2_8_7_TemplateReplace_bevs_type;
}
}
}
