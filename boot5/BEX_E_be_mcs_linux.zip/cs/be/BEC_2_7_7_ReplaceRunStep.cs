namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_7_7_ReplaceRunStep : BEC_2_6_6_SystemObject {
public BEC_2_7_7_ReplaceRunStep() { }
static BEC_2_7_7_ReplaceRunStep() { }
private static byte[] becc_BEC_2_7_7_ReplaceRunStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x52,0x75,0x6E,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_7_ReplaceRunStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_7_7_ReplaceRunStep bece_BEC_2_7_7_ReplaceRunStep_bevs_inst;

public static new BET_2_7_7_ReplaceRunStep bece_BEC_2_7_7_ReplaceRunStep_bevs_type;

public BEC_2_8_7_TemplateReplace bevp_replace;
public BEC_2_4_6_TextString bevp_str;
public virtual BEC_2_7_7_ReplaceRunStep bem_new_2(BEC_2_8_7_TemplateReplace beva__replace, BEC_2_4_6_TextString beva__str) {
bevp_replace = beva__replace;
bevp_str = beva__str;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) {
BEC_2_4_6_TextString bevl_toSwap = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_0_ta_ph = beva_r.bemd_0(1615180851);
bevl_toSwap = (BEC_2_4_6_TextString) bevt_0_ta_ph.bemd_1(-783899545, bevp_str);
if (bevl_toSwap == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 156*/ {
return bevl_toSwap;
} /* Line: 157*/
return bevp_str;
} /*method end*/
public virtual BEC_2_8_7_TemplateReplace bem_replaceGet_0() {
return bevp_replace;
} /*method end*/
public BEC_2_8_7_TemplateReplace bem_replaceGetDirect_0() {
return bevp_replace;
} /*method end*/
public virtual BEC_2_7_7_ReplaceRunStep bem_replaceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_replaceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_replace = (BEC_2_8_7_TemplateReplace) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_strGet_0() {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGetDirect_0() {
return bevp_str;
} /*method end*/
public virtual BEC_2_7_7_ReplaceRunStep bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_7_ReplaceRunStep bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {148, 149, 155, 155, 156, 156, 157, 159, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {15, 16, 23, 24, 25, 30, 31, 33, 36, 39, 42, 46, 50, 53, 56, 60};
/* BEGIN LINEINFO 
assign 1 148 15
assign 1 149 16
assign 1 155 23
swapGet 0 155 23
assign 1 155 24
get 1 155 24
assign 1 156 25
def 1 156 30
return 1 157 31
return 1 159 33
return 1 0 36
return 1 0 39
assign 1 0 42
assign 1 0 46
return 1 0 50
return 1 0 53
assign 1 0 56
assign 1 0 60
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 501088997: return bem_sourceFileNameGet_0();
case -930069099: return bem_strGet_0();
case -639297756: return bem_toAny_0();
case 281444821: return bem_fieldIteratorGet_0();
case -1486279572: return bem_serializeContents_0();
case 1672883231: return bem_replaceGet_0();
case 1996155598: return bem_replaceGetDirect_0();
case -1275325619: return bem_toString_0();
case -2017009146: return bem_new_0();
case -744679096: return bem_fieldNamesGet_0();
case -1005119995: return bem_many_0();
case -1583672278: return bem_echo_0();
case 611702865: return bem_copy_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case -1754478112: return bem_print_0();
case -678541085: return bem_classNameGet_0();
case -1475550710: return bem_create_0();
case -1315998022: return bem_strGetDirect_0();
case 119461913: return bem_tagGet_0();
case -545556484: return bem_once_0();
case -225870373: return bem_serializeToString_0();
case 2045941275: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 509474695: return bem_sameObject_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1352588950: return bem_strSet_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -819924841: return bem_replaceSet_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case 709892963: return bem_replaceSetDirect_1(bevd_0);
case 1289144653: return bem_handle_1(bevd_0);
case -422026942: return bem_strSetDirect_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 411862155: return bem_new_2((BEC_2_8_7_TemplateReplace) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_7_7_ReplaceRunStep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_7_ReplaceRunStep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_7_7_ReplaceRunStep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_inst = (BEC_2_7_7_ReplaceRunStep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_7_7_ReplaceRunStep.bece_BEC_2_7_7_ReplaceRunStep_bevs_type;
}
}
}
