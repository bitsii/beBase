namespace be {

using System;
using System.Security.Cryptography;
// for threading
using System.Threading;
    /* IO:File: source/base/System.be */
public class BEC_2_6_10_SystemThinThread : BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemThinThread() { }
static BEC_2_6_10_SystemThinThread() { }

   volatile public Thread bevi_thread;
   public static void bems_run(object sysThreadInst) {
     BEC_2_6_10_SystemThinThread st = (BEC_2_6_10_SystemThinThread) sysThreadInst;
     st.bem_main_0();
   }
   private static byte[] becc_BEC_2_6_10_SystemThinThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x69,0x6E,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_10_SystemThinThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static new BEC_2_6_10_SystemThinThread bece_BEC_2_6_10_SystemThinThread_bevs_inst;

public static new BET_2_6_10_SystemThinThread bece_BEC_2_6_10_SystemThinThread_bevs_type;

public BEC_2_6_6_SystemObject bevp_toRun;
public virtual BEC_2_6_10_SystemThinThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) {
bevp_toRun = beva__toRun;
return this;
} /*method end*/
public virtual BEC_2_6_10_SystemThinThread bem_start_0() {

     bevi_thread = new Thread(BEC_2_6_10_SystemThinThread.bems_run);
     bevi_thread.Start(this);
     return this;
} /*method end*/
public virtual BEC_2_6_10_SystemThinThread bem_main_0() {
BEC_2_6_6_SystemObject bevl_e = null;
try  /* Line: 742 */ {
bevp_toRun.bemd_0(447745953);
} /* Line: 743 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 744 */
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_wait_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;

     bevi_thread.Join();
     bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_toRunGet_0() {
return bevp_toRun;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toRunGetDirect_0() {
return bevp_toRun;
} /*method end*/
public virtual BEC_2_6_10_SystemThinThread bem_toRunSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toRun = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemThinThread bem_toRunSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toRun = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {714, 743, 768, 768, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 37, 48, 49, 52, 55, 58, 62};
/* BEGIN LINEINFO 
assign 1 714 25
main 0 743 37
assign 1 768 48
new 0 768 48
return 1 768 49
return 1 0 52
return 1 0 55
assign 1 0 58
assign 1 0 62
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1799416909: return bem_serializationIteratorGet_0();
case 1804773996: return bem_create_0();
case 2038595215: return bem_toRunGetDirect_0();
case -73436994: return bem_new_0();
case 1254813232: return bem_toAny_0();
case -1072030744: return bem_sourceFileNameGet_0();
case 653349672: return bem_copy_0();
case 1076854321: return bem_start_0();
case -1778497682: return bem_serializeToString_0();
case 959038598: return bem_echo_0();
case 1642669681: return bem_wait_0();
case -2120499139: return bem_iteratorGet_0();
case 1562662552: return bem_many_0();
case 447745953: return bem_main_0();
case 167710369: return bem_print_0();
case -297374401: return bem_hashGet_0();
case -1067704397: return bem_once_0();
case 39810102: return bem_tagGet_0();
case 1769468354: return bem_fieldNamesGet_0();
case -1628372783: return bem_classNameGet_0();
case -1071008216: return bem_serializeContents_0();
case 621276181: return bem_toString_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case 37056580: return bem_toRunGet_0();
case -1960297657: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1049172860: return bem_defined_1(bevd_0);
case 364080193: return bem_toRunSet_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -438924354: return bem_undefined_1(bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case -414228749: return bem_new_1(bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case -1181994752: return bem_toRunSetDirect_1(bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemThinThread_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_10_SystemThinThread_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_10_SystemThinThread();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_inst = (BEC_2_6_10_SystemThinThread) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_10_SystemThinThread.bece_BEC_2_6_10_SystemThinThread_bevs_type;
}
}
}
