namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_13_SystemIncorrectType : BEC_2_6_9_SystemException {
public BEC_2_6_13_SystemIncorrectType() { }
static BEC_2_6_13_SystemIncorrectType() { }
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x54,0x79,0x70,0x65};
private static byte[] becc_BEC_2_6_13_SystemIncorrectType_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_13_SystemIncorrectType bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;
public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
bevp_description = beva_descr;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {372};
public static new int[] bevs_smnlec
 = new int[] {10};
/* BEGIN LINEINFO 
assign 1 372 10
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -404584101: return bem_translateEmittedException_0();
case 814639632: return bem_new_0();
case -460827997: return bem_framesTextGet_0();
case 648165913: return bem_print_0();
case -537857901: return bem_iteratorGet_0();
case -1763269267: return bem_descriptionGet_0();
case 2036051133: return bem_tagGet_0();
case -125946934: return bem_serializeContents_0();
case 1681305365: return bem_getFrameText_0();
case -2049991627: return bem_once_0();
case 34035866: return bem_classNameGet_0();
case -1254107566: return bem_klassNameGet_0();
case -2046784533: return bem_echo_0();
case -326152805: return bem_copy_0();
case 432735873: return bem_deserializeClassNameGet_0();
case -1653307562: return bem_serializationIteratorGet_0();
case -1697553814: return bem_vvGet_0();
case 2048361265: return bem_many_0();
case -972248673: return bem_methodNameGet_0();
case 1553096058: return bem_fileNameGet_0();
case 1066346368: return bem_framesGet_0();
case 717158289: return bem_fieldIteratorGet_0();
case -2089907154: return bem_create_0();
case -506929281: return bem_emitLangGet_0();
case -109602708: return bem_toString_0();
case -173186399: return bem_toAny_0();
case 1973131926: return bem_serializeToString_0();
case 679289972: return bem_lineNumberGet_0();
case 546868524: return bem_langGet_0();
case 99641680: return bem_sourceFileNameGet_0();
case -2070760487: return bem_translateEmittedExceptionInner_0();
case 16029145: return bem_translatedGet_0();
case -2129255989: return bem_hashGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -18264962: return bem_descriptionSet_1(bevd_0);
case 210234291: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1089940950: return bem_framesTextSet_1(bevd_0);
case -1664284831: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1768401992: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -855223161: return bem_framesSet_1(bevd_0);
case 1516713087: return bem_klassNameSet_1(bevd_0);
case 991182700: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1617589742: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -143017218: return bem_copyTo_1(bevd_0);
case -1887120745: return bem_sameObject_1(bevd_0);
case 1940516897: return bem_sameClass_1(bevd_0);
case -41860790: return bem_translatedSet_1(bevd_0);
case 755365358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1393267925: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1458742727: return bem_vvSet_1(bevd_0);
case 217239677: return bem_emitLangSet_1(bevd_0);
case -464134510: return bem_lineNumberSet_1(bevd_0);
case -420585939: return bem_equals_1(bevd_0);
case 726236938: return bem_langSet_1(bevd_0);
case -123114149: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -169401475: return bem_otherClass_1(bevd_0);
case 384838206: return bem_methodNameSet_1(bevd_0);
case -2031862922: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1626959730: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1369439027: return bem_notEquals_1(bevd_0);
case -1091318965: return bem_defined_1(bevd_0);
case 549239575: return bem_otherType_1(bevd_0);
case -1472778246: return bem_fileNameSet_1(bevd_0);
case 1492255674: return bem_def_1(bevd_0);
case 5463926: return bem_new_1(bevd_0);
case 1290400575: return bem_undef_1(bevd_0);
case 569199667: return bem_undefined_1(bevd_0);
case -491345013: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1008056884: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1151786117: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1422666964: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 466148991: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1823742306: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -50371904: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 967378502: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -813632818: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_6_13_SystemIncorrectType_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_13_SystemIncorrectType_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_13_SystemIncorrectType();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst = (BEC_2_6_13_SystemIncorrectType) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_13_SystemIncorrectType.bece_BEC_2_6_13_SystemIncorrectType_bevs_inst;
}
}
}
