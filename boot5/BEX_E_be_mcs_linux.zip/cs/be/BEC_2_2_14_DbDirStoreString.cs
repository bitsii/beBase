namespace be {
/* IO:File: source/extended/Serialize.be */
public class BEC_2_2_14_DbDirStoreString : BEC_2_2_8_DbDirStore {
public BEC_2_2_14_DbDirStoreString() { }
static BEC_2_2_14_DbDirStoreString() { }
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clname = {0x44,0x62,0x3A,0x44,0x69,0x72,0x53,0x74,0x6F,0x72,0x65,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] becc_BEC_2_2_14_DbDirStoreString_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x65,0x72,0x69,0x61,0x6C,0x69,0x7A,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_14_DbDirStoreString_bels_0 = {};
private static BEC_2_4_6_TextString bece_BEC_2_2_14_DbDirStoreString_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_14_DbDirStoreString_bels_0, 0));
private static BEC_2_4_6_TextString bece_BEC_2_2_14_DbDirStoreString_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_14_DbDirStoreString_bels_0, 0));
public static new BEC_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_inst;

public static new BET_2_2_14_DbDirStoreString bece_BEC_2_2_14_DbDirStoreString_bevs_type;

public override BEC_2_2_8_DbDirStore bem_put_2(BEC_2_4_6_TextString beva_id, BEC_2_6_6_SystemObject beva_object) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
if (beva_id == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevt_3_tmpany_phold = bece_BEC_2_2_14_DbDirStoreString_bevo_0;
bevt_2_tmpany_phold = beva_id.bem_notEquals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 329 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 329 */
 else  /* Line: 329 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 329 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 331 */ {
bevt_5_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = beva_object.bemd_0(1884049010);
bevt_5_tmpany_phold.bem_contentsSet_1((BEC_2_4_6_TextString) bevt_6_tmpany_phold );
} /* Line: 332 */
} /* Line: 331 */
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_get_1(BEC_2_4_6_TextString beva_id) {
BEC_3_2_4_4_IOFilePath bevl_p = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
if (beva_id == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 338 */ {
bevt_4_tmpany_phold = bece_BEC_2_2_14_DbDirStoreString_bevo_1;
bevt_3_tmpany_phold = beva_id.bem_notEquals_1(bevt_4_tmpany_phold);
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 338 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 338 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 338 */
 else  /* Line: 338 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 338 */ {
bevl_p = bem_getPath_1(beva_id);
if (bevl_p == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 340 */ {
bevt_7_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_existsGet_0();
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 340 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 340 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 340 */
 else  /* Line: 340 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 340 */ {
bevt_9_tmpany_phold = bevl_p.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_contentsGet_0();
return bevt_8_tmpany_phold;
} /* Line: 341 */
} /* Line: 340 */
return null;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {329, 329, 329, 329, 0, 0, 0, 330, 331, 331, 332, 332, 332, 338, 338, 338, 338, 0, 0, 0, 339, 340, 340, 340, 340, 0, 0, 0, 341, 341, 341, 344};
public static new int[] bevs_smnlec
 = new int[] {24, 29, 30, 31, 33, 36, 40, 43, 44, 49, 50, 51, 52, 69, 74, 75, 76, 78, 81, 85, 88, 89, 94, 95, 96, 98, 101, 105, 108, 109, 110, 113};
/* BEGIN LINEINFO 
assign 1 329 24
def 1 329 29
assign 1 329 30
new 0 329 30
assign 1 329 31
notEquals 1 329 31
assign 1 0 33
assign 1 0 36
assign 1 0 40
assign 1 330 43
getPath 1 330 43
assign 1 331 44
def 1 331 49
assign 1 332 50
fileGet 0 332 50
assign 1 332 51
toString 0 332 51
contentsSet 1 332 52
assign 1 338 69
def 1 338 74
assign 1 338 75
new 0 338 75
assign 1 338 76
notEquals 1 338 76
assign 1 0 78
assign 1 0 81
assign 1 0 85
assign 1 339 88
getPath 1 339 88
assign 1 340 89
def 1 340 94
assign 1 340 95
fileGet 0 340 95
assign 1 340 96
existsGet 0 340 96
assign 1 0 98
assign 1 0 101
assign 1 0 105
assign 1 341 108
fileGet 0 341 108
assign 1 341 109
contentsGet 0 341 109
return 1 341 110
return 1 344 113
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1747771860: return bem_classNameGet_0();
case -2039257540: return bem_tagGet_0();
case 115869406: return bem_storageDirGetDirect_0();
case 1212163572: return bem_serGet_0();
case -1975328143: return bem_once_0();
case -1442113467: return bem_create_0();
case 767177150: return bem_fieldNamesGet_0();
case 1505927918: return bem_serializeContents_0();
case -304660926: return bem_sourceFileNameGet_0();
case 377122149: return bem_keyEncoderGetDirect_0();
case 1023342206: return bem_storageDirGet_0();
case -448869219: return bem_print_0();
case 583026473: return bem_toAny_0();
case 1091579640: return bem_new_0();
case -39836047: return bem_serGetDirect_0();
case -1616792218: return bem_deserializeClassNameGet_0();
case 1062973207: return bem_serializationIteratorGet_0();
case 1287866350: return bem_copy_0();
case 546322415: return bem_echo_0();
case -470506305: return bem_serializeToString_0();
case 1017833055: return bem_many_0();
case -275053926: return bem_fieldIteratorGet_0();
case 1023092059: return bem_keyEncoderGet_0();
case -497450892: return bem_hashGet_0();
case 1884049010: return bem_toString_0();
case -926676223: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1989662813: return bem_delete_1((BEC_2_4_6_TextString) bevd_0);
case 1573015874: return bem_keyEncoderSetDirect_1(bevd_0);
case 646938840: return bem_getStoreId_1((BEC_2_4_6_TextString) bevd_0);
case -2049888779: return bem_keyEncoderSet_1(bevd_0);
case 1789669676: return bem_getPath_1((BEC_2_4_6_TextString) bevd_0);
case 1538418813: return bem_serSetDirect_1(bevd_0);
case -1132198926: return bem_sameType_1(bevd_0);
case -13945303: return bem_defined_1(bevd_0);
case 1401965255: return bem_get_1((BEC_2_4_6_TextString) bevd_0);
case -1680819360: return bem_undefined_1(bevd_0);
case 1011958071: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2047213073: return bem_equals_1(bevd_0);
case -1507083548: return bem_otherClass_1(bevd_0);
case 2096446482: return bem_serSet_1(bevd_0);
case 198645452: return bem_has_1((BEC_2_4_6_TextString) bevd_0);
case 205081622: return bem_sameObject_1(bevd_0);
case 605625079: return bem_storageDirSet_1(bevd_0);
case -778156991: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 745295406: return bem_sameClass_1(bevd_0);
case 38080717: return bem_undef_1(bevd_0);
case -396792969: return bem_otherType_1(bevd_0);
case -1396938224: return bem_notEquals_1(bevd_0);
case -1916951160: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1241848293: return bem_pathNew_1((BEC_3_2_4_4_IOFilePath) bevd_0);
case 1103345063: return bem_storageDirSetDirect_1(bevd_0);
case 13577034: return bem_def_1(bevd_0);
case -149148452: return bem_copyTo_1(bevd_0);
case -1732969657: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -942274895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 62716626: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1611590654: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1937006126: return bem_put_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case -927828157: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 513618976: return bem_new_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
case 276198978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -931383679: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1041543114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1047719554: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_2_2_14_DbDirStoreString_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(28, becc_BEC_2_2_14_DbDirStoreString_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_14_DbDirStoreString();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst = (BEC_2_2_14_DbDirStoreString) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_14_DbDirStoreString.bece_BEC_2_2_14_DbDirStoreString_bevs_type;
}
}
}
