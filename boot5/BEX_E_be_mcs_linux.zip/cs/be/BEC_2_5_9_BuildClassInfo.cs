namespace be {
/* IO:File: source/build/CEmitter.be */
public sealed class BEC_2_5_9_BuildClassInfo : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildClassInfo() { }
static BEC_2_5_9_BuildClassInfo() { }
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_0, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_1, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_2 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_2, 1));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_4, 6));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_5 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_5, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_6 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_6, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_7 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_8 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_8, 11));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_9 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_9, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_10 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_10, 6));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_11 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_12, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_13 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_13, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_14 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_14, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_15 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_15, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_16 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_16, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_17 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_18 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_18, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_19 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_19, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_20 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_20, 17));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_21 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_21, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_22 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_22, 12));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_23 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_23, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_24 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_24, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_25 = {0x42,0x45,0x58,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_25, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_26 = {0x42,0x45,0x4B,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_26, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_27 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_27, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_28 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_28, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_29 = {0x2E,0x6D,0x61,0x6B,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_29, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_30 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_31 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_31, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_32 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_32, 4));
public static new BEC_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_inst;

public static new BET_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_15_BuildCompilerProfile bevp_cpro;
public BEC_2_5_8_BuildNamePath bevp_npar;
public BEC_2_6_6_SystemObject bevp_nparSteps;
public BEC_2_4_6_TextString bevp_clName;
public BEC_2_4_6_TextString bevp_clBase;
public BEC_2_4_6_TextString bevp_midName;
public BEC_2_4_6_TextString bevp_incBlock;
public BEC_2_4_6_TextString bevp_mtdName;
public BEC_2_4_6_TextString bevp_cldefName;
public BEC_2_4_6_TextString bevp_shClassName;
public BEC_2_4_6_TextString bevp_shFileName;
public BEC_2_4_6_TextString bevp_cldefBuild;
public BEC_2_4_6_TextString bevp_libnameInit;
public BEC_2_4_6_TextString bevp_libnameInitDone;
public BEC_2_4_6_TextString bevp_libnameData;
public BEC_2_4_6_TextString bevp_libnameDataDone;
public BEC_2_4_6_TextString bevp_libnameDataClear;
public BEC_2_4_6_TextString bevp_libNotNullInit;
public BEC_2_4_6_TextString bevp_libNotNullInitDone;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_cuBase;
public BEC_3_2_4_4_IOFilePath bevp_nsDir;
public BEC_2_4_6_TextString bevp_xbase;
public BEC_2_4_6_TextString bevp_lbase;
public BEC_2_4_6_TextString bevp_nbase;
public BEC_2_4_6_TextString bevp_kbase;
public BEC_3_2_4_4_IOFilePath bevp_cuinitH;
public BEC_2_4_6_TextString bevp_namesIncH;
public BEC_3_2_4_4_IOFilePath bevp_cuinit;
public BEC_3_2_4_4_IOFilePath bevp_namesO;
public BEC_3_2_4_4_IOFilePath bevp_unitShlib;
public BEC_3_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_3_2_4_4_IOFilePath bevp_unitExe;
public BEC_3_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classExeO;
public BEC_3_2_4_4_IOFilePath bevp_makeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrcH;
public BEC_3_2_4_4_IOFilePath bevp_classIncH;
public BEC_3_2_4_4_IOFilePath bevp_classO;
public BEC_3_2_4_4_IOFilePath bevp_synSrc;
public BEC_2_5_9_BuildClassInfo bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_new_5(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) {
BEC_2_4_6_TextString bevl_cext = null;
BEC_2_4_6_TextString bevl_oext = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_tmpany_phold = bevp_emitter.bemd_0(-1307828136);
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_phold.bemd_0(1310468814);
bevp_npar = (BEC_2_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_tmpany_phold = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lastGet_0();
bevp_midName = (BEC_2_4_6_TextString) bevp_emitter.bemd_2(-1697309167, beva__libName, beva__np);
bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_0;
bevp_incBlock = bevt_2_tmpany_phold.bem_add_1(bevp_midName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevp_midName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_2;
bevp_mtdName = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_3;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_midName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_4;
bevp_cldefName = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_5;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_midName);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_6;
bevp_shClassName = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_7;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_midName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_8;
bevp_shFileName = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_9;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevp_midName);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_10;
bevp_cldefBuild = bevt_15_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_11;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevp_midName);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_12;
bevp_libnameInit = bevt_18_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_13;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevp_midName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_14;
bevp_libnameInitDone = bevt_21_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_15;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevp_midName);
bevt_26_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_16;
bevp_libnameData = bevt_24_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_17;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevp_midName);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_18;
bevp_libnameDataDone = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_19;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevp_midName);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_20;
bevp_libnameDataClear = bevt_30_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_21;
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevp_midName);
bevt_35_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_22;
bevp_libNotNullInit = bevt_33_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_23;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_midName);
bevt_38_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_24;
bevp_libNotNullInitDone = bevt_36_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_copy_0();
bevt_39_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_25;
bevp_xbase = bevt_39_tmpany_phold.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_26;
bevp_kbase = bevt_40_tmpany_phold.bem_add_1(bevp_clBase);
bevt_41_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_27;
bevt_42_tmpany_phold = bevp_nbase.bem_add_1(bevt_43_tmpany_phold);
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_41_tmpany_phold.bem_addStep_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_28;
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_46_tmpany_phold = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_45_tmpany_phold.bem_addStep_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_48_tmpany_phold = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_47_tmpany_phold.bem_addStep_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_51_tmpany_phold = bevp_cpro.bem_libExtGet_0();
bevt_50_tmpany_phold = bevp_lbase.bem_add_1(bevt_51_tmpany_phold);
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_49_tmpany_phold.bem_addStep_1(bevt_50_tmpany_phold);
bevt_52_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_54_tmpany_phold = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_tmpany_phold = bevp_lbase.bem_add_1(bevt_54_tmpany_phold);
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_52_tmpany_phold.bem_addStep_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_57_tmpany_phold = bevp_cpro.bem_exeExtGet_0();
bevt_56_tmpany_phold = beva__exeName.bem_add_1(bevt_57_tmpany_phold);
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_55_tmpany_phold.bem_addStep_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_59_tmpany_phold = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_58_tmpany_phold.bem_addStep_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_61_tmpany_phold = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_60_tmpany_phold.bem_addStep_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_64_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_29;
bevt_63_tmpany_phold = bevp_xbase.bem_add_1(bevt_64_tmpany_phold);
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_62_tmpany_phold.bem_addStep_1(bevt_63_tmpany_phold);
bevt_65_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_66_tmpany_phold = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_65_tmpany_phold.bem_addStep_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_69_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_30;
bevt_68_tmpany_phold = bevp_kbase.bem_add_1(bevt_69_tmpany_phold);
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_67_tmpany_phold.bem_addStep_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_nsDir.bem_copy_0();
bevt_72_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_31;
bevt_71_tmpany_phold = bevp_kbase.bem_add_1(bevt_72_tmpany_phold);
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_70_tmpany_phold.bem_addStep_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_74_tmpany_phold = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_73_tmpany_phold.bem_addStep_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_77_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_32;
bevt_76_tmpany_phold = bevp_kbase.bem_add_1(bevt_77_tmpany_phold);
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_75_tmpany_phold.bem_addStep_1(bevt_76_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirDo_1(BEC_2_4_6_TextString beva__libName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(153829440);
while (true)
 /* Line: 111 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(655034069);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 111 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(-1353189684);
bevp_nsDir.bem_addStep_1(bevt_1_tmpany_phold);
} /* Line: 112 */
 else  /* Line: 111 */ {
break;
} /* Line: 111 */
} /* Line: 111 */
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGet_0() {
return bevp_cpro;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGet_0() {
return bevp_npar;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGet_0() {
return bevp_nparSteps;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nparSteps = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGet_0() {
return bevp_clName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGet_0() {
return bevp_clBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGet_0() {
return bevp_midName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGet_0() {
return bevp_incBlock;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGet_0() {
return bevp_mtdName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGet_0() {
return bevp_cldefName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGet_0() {
return bevp_shClassName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGet_0() {
return bevp_shFileName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGet_0() {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGet_0() {
return bevp_libnameInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGet_0() {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGet_0() {
return bevp_libnameData;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGet_0() {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGet_0() {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGet_0() {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGet_0() {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGet_0() {
return bevp_cuBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGet_0() {
return bevp_nsDir;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGet_0() {
return bevp_xbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGet_0() {
return bevp_lbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGet_0() {
return bevp_nbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGet_0() {
return bevp_kbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGet_0() {
return bevp_cuinitH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGet_0() {
return bevp_namesIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGet_0() {
return bevp_cuinit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGet_0() {
return bevp_namesO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGet_0() {
return bevp_unitShlib;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGet_0() {
return bevp_unitExeLink;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGet_0() {
return bevp_unitExe;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGet_0() {
return bevp_classExeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGet_0() {
return bevp_classExeO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGet_0() {
return bevp_makeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGet_0() {
return bevp_classSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGet_0() {
return bevp_classSrcH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGet_0() {
return bevp_classIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGet_0() {
return bevp_classO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGet_0() {
return bevp_synSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {21, 28, 29, 30, 30, 31, 32, 33, 35, 35, 37, 39, 40, 41, 44, 44, 46, 46, 46, 46, 48, 48, 48, 48, 50, 50, 50, 50, 52, 52, 52, 52, 54, 54, 54, 54, 56, 56, 56, 56, 58, 58, 58, 58, 60, 60, 60, 60, 62, 62, 62, 62, 64, 64, 64, 64, 66, 66, 66, 66, 67, 67, 67, 67, 69, 71, 72, 75, 75, 76, 77, 78, 78, 80, 80, 80, 80, 81, 81, 82, 82, 82, 83, 83, 83, 87, 87, 87, 87, 88, 88, 88, 88, 89, 89, 89, 89, 91, 91, 91, 92, 92, 92, 93, 93, 93, 93, 95, 95, 95, 96, 96, 96, 96, 97, 97, 97, 97, 98, 98, 98, 99, 99, 99, 99, 109, 110, 111, 111, 112, 112, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {123, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 337, 338, 339, 342, 344, 345, 354, 357, 361, 364, 368, 371, 375, 378, 382, 385, 389, 392, 396, 399, 403, 406, 410, 413, 417, 420, 424, 427, 431, 434, 438, 441, 445, 448, 452, 455, 459, 462, 466, 469, 473, 476, 480, 483, 487, 490, 494, 497, 501, 504, 508, 511, 515, 518, 522, 525, 529, 532, 536, 539, 543, 546, 550, 553, 557, 560, 564, 567, 571, 574, 578, 581, 585, 588, 592, 595, 599, 602, 606, 609, 613, 616, 620, 623, 627, 630, 634, 637, 641, 644, 648, 651, 655, 658};
/* BEGIN LINEINFO 
new 5 21 123
assign 1 28 207
assign 1 29 208
assign 1 30 209
buildGet 0 30 209
assign 1 30 210
compilerProfileGet 0 30 210
assign 1 31 211
parentGet 0 31 211
assign 1 32 212
stepsGet 0 32 212
assign 1 33 213
toString 0 33 213
assign 1 35 214
stepsGet 0 35 214
assign 1 35 215
lastGet 0 35 215
assign 1 37 216
midNameDo 2 37 216
nsDirDo 1 39 217
assign 1 40 218
cextGet 0 40 218
assign 1 41 219
oextGet 0 41 219
assign 1 44 220
new 0 44 220
assign 1 44 221
add 1 44 221
assign 1 46 222
new 0 46 222
assign 1 46 223
add 1 46 223
assign 1 46 224
new 0 46 224
assign 1 46 225
add 1 46 225
assign 1 48 226
new 0 48 226
assign 1 48 227
add 1 48 227
assign 1 48 228
new 0 48 228
assign 1 48 229
add 1 48 229
assign 1 50 230
new 0 50 230
assign 1 50 231
add 1 50 231
assign 1 50 232
new 0 50 232
assign 1 50 233
add 1 50 233
assign 1 52 234
new 0 52 234
assign 1 52 235
add 1 52 235
assign 1 52 236
new 0 52 236
assign 1 52 237
add 1 52 237
assign 1 54 238
new 0 54 238
assign 1 54 239
add 1 54 239
assign 1 54 240
new 0 54 240
assign 1 54 241
add 1 54 241
assign 1 56 242
new 0 56 242
assign 1 56 243
add 1 56 243
assign 1 56 244
new 0 56 244
assign 1 56 245
add 1 56 245
assign 1 58 246
new 0 58 246
assign 1 58 247
add 1 58 247
assign 1 58 248
new 0 58 248
assign 1 58 249
add 1 58 249
assign 1 60 250
new 0 60 250
assign 1 60 251
add 1 60 251
assign 1 60 252
new 0 60 252
assign 1 60 253
add 1 60 253
assign 1 62 254
new 0 62 254
assign 1 62 255
add 1 62 255
assign 1 62 256
new 0 62 256
assign 1 62 257
add 1 62 257
assign 1 64 258
new 0 64 258
assign 1 64 259
add 1 64 259
assign 1 64 260
new 0 64 260
assign 1 64 261
add 1 64 261
assign 1 66 262
new 0 66 262
assign 1 66 263
add 1 66 263
assign 1 66 264
new 0 66 264
assign 1 66 265
add 1 66 265
assign 1 67 266
new 0 67 266
assign 1 67 267
add 1 67 267
assign 1 67 268
new 0 67 268
assign 1 67 269
add 1 67 269
assign 1 69 270
assign 1 71 271
add 1 71 271
assign 1 72 272
copy 0 72 272
assign 1 75 273
new 0 75 273
assign 1 75 274
add 1 75 274
assign 1 76 275
assign 1 77 276
assign 1 78 277
new 0 78 277
assign 1 78 278
add 1 78 278
assign 1 80 279
copy 0 80 279
assign 1 80 280
new 0 80 280
assign 1 80 281
add 1 80 281
assign 1 80 282
addStep 1 80 282
assign 1 81 283
new 0 81 283
assign 1 81 284
add 1 81 284
assign 1 82 285
copy 0 82 285
assign 1 82 286
add 1 82 286
assign 1 82 287
addStep 1 82 287
assign 1 83 288
copy 0 83 288
assign 1 83 289
add 1 83 289
assign 1 83 290
addStep 1 83 290
assign 1 87 291
copy 0 87 291
assign 1 87 292
libExtGet 0 87 292
assign 1 87 293
add 1 87 293
assign 1 87 294
addStep 1 87 294
assign 1 88 295
copy 0 88 295
assign 1 88 296
exeLibExtGet 0 88 296
assign 1 88 297
add 1 88 297
assign 1 88 298
addStep 1 88 298
assign 1 89 299
copy 0 89 299
assign 1 89 300
exeExtGet 0 89 300
assign 1 89 301
add 1 89 301
assign 1 89 302
addStep 1 89 302
assign 1 91 303
copy 0 91 303
assign 1 91 304
add 1 91 304
assign 1 91 305
addStep 1 91 305
assign 1 92 306
copy 0 92 306
assign 1 92 307
add 1 92 307
assign 1 92 308
addStep 1 92 308
assign 1 93 309
copy 0 93 309
assign 1 93 310
new 0 93 310
assign 1 93 311
add 1 93 311
assign 1 93 312
addStep 1 93 312
assign 1 95 313
copy 0 95 313
assign 1 95 314
add 1 95 314
assign 1 95 315
addStep 1 95 315
assign 1 96 316
copy 0 96 316
assign 1 96 317
new 0 96 317
assign 1 96 318
add 1 96 318
assign 1 96 319
addStep 1 96 319
assign 1 97 320
copy 0 97 320
assign 1 97 321
new 0 97 321
assign 1 97 322
add 1 97 322
assign 1 97 323
addStep 1 97 323
assign 1 98 324
copy 0 98 324
assign 1 98 325
add 1 98 325
assign 1 98 326
addStep 1 98 326
assign 1 99 327
copy 0 99 327
assign 1 99 328
new 0 99 328
assign 1 99 329
add 1 99 329
assign 1 99 330
addStep 1 99 330
assign 1 109 337
new 0 109 337
addStep 1 110 338
assign 1 111 339
iteratorGet 0 111 339
assign 1 111 342
hasNextGet 0 111 342
assign 1 112 344
nextGet 0 112 344
addStep 1 112 345
return 1 0 354
assign 1 0 357
return 1 0 361
assign 1 0 364
return 1 0 368
assign 1 0 371
return 1 0 375
assign 1 0 378
return 1 0 382
assign 1 0 385
return 1 0 389
assign 1 0 392
return 1 0 396
assign 1 0 399
return 1 0 403
assign 1 0 406
return 1 0 410
assign 1 0 413
return 1 0 417
assign 1 0 420
return 1 0 424
assign 1 0 427
return 1 0 431
assign 1 0 434
return 1 0 438
assign 1 0 441
return 1 0 445
assign 1 0 448
return 1 0 452
assign 1 0 455
return 1 0 459
assign 1 0 462
return 1 0 466
assign 1 0 469
return 1 0 473
assign 1 0 476
return 1 0 480
assign 1 0 483
return 1 0 487
assign 1 0 490
return 1 0 494
assign 1 0 497
return 1 0 501
assign 1 0 504
return 1 0 508
assign 1 0 511
return 1 0 515
assign 1 0 518
return 1 0 522
assign 1 0 525
return 1 0 529
assign 1 0 532
return 1 0 536
assign 1 0 539
return 1 0 543
assign 1 0 546
return 1 0 550
assign 1 0 553
return 1 0 557
assign 1 0 560
return 1 0 564
assign 1 0 567
return 1 0 571
assign 1 0 574
return 1 0 578
assign 1 0 581
return 1 0 585
assign 1 0 588
return 1 0 592
assign 1 0 595
return 1 0 599
assign 1 0 602
return 1 0 606
assign 1 0 609
return 1 0 613
assign 1 0 616
return 1 0 620
assign 1 0 623
return 1 0 627
assign 1 0 630
return 1 0 634
assign 1 0 637
return 1 0 641
assign 1 0 644
return 1 0 648
assign 1 0 651
return 1 0 655
assign 1 0 658
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -714583401: return bem_emitterGet_0();
case -213541934: return bem_echo_0();
case -637230318: return bem_serializeToString_0();
case 793830133: return bem_tagGet_0();
case -249191767: return bem_classOGet_0();
case 1126884719: return bem_classSrcHGet_0();
case -1850735998: return bem_libnameDataGet_0();
case -1776757235: return bem_unitShlibGet_0();
case 1754190679: return bem_classNameGet_0();
case 1160163932: return bem_classExeOGet_0();
case 74589976: return bem_npGet_0();
case -2067310143: return bem_create_0();
case -1275596540: return bem_incBlockGet_0();
case 962442690: return bem_cldefNameGet_0();
case 491585243: return bem_toString_0();
case 1193477558: return bem_new_0();
case 645227528: return bem_copy_0();
case -1813673554: return bem_shFileNameGet_0();
case -1588425493: return bem_mtdNameGet_0();
case -817479462: return bem_emitPathGet_0();
case 2070193811: return bem_namesOGet_0();
case -1657527329: return bem_libnameInitGet_0();
case 956121033: return bem_sourceFileNameGet_0();
case -1466347886: return bem_serializeContents_0();
case 50529068: return bem_libNotNullInitDoneGet_0();
case 1282559515: return bem_classExeSrcGet_0();
case 244787655: return bem_classSrcGet_0();
case 2048340457: return bem_clNameGet_0();
case -1367995376: return bem_nparStepsGet_0();
case 857695024: return bem_nsDirGet_0();
case 756116744: return bem_namesIncHGet_0();
case -872347359: return bem_synSrcGet_0();
case -1548866904: return bem_shClassNameGet_0();
case -414566530: return bem_fieldIteratorGet_0();
case -1581280424: return bem_midNameGet_0();
case -1104646349: return bem_unitExeLinkGet_0();
case 1536333431: return bem_libnameDataDoneGet_0();
case 796986463: return bem_cproGet_0();
case -2093362216: return bem_cuBaseGet_0();
case -1107931565: return bem_makeSrcGet_0();
case 479550774: return bem_basePathGet_0();
case 1140931576: return bem_cldefBuildGet_0();
case -1889481920: return bem_once_0();
case -878746922: return bem_nbaseGet_0();
case 1163377727: return bem_toAny_0();
case -1791312022: return bem_serializationIteratorGet_0();
case 153829440: return bem_iteratorGet_0();
case -2013339426: return bem_libnameDataClearGet_0();
case -1189878968: return bem_clBaseGet_0();
case 398833579: return bem_nparGet_0();
case -79631743: return bem_xbaseGet_0();
case -1009817617: return bem_cuinitHGet_0();
case -439307572: return bem_hashGet_0();
case 1991051685: return bem_print_0();
case 840046609: return bem_libNotNullInitGet_0();
case 512612659: return bem_libnameInitDoneGet_0();
case 1501620573: return bem_deserializeClassNameGet_0();
case 1805899516: return bem_many_0();
case -1629866659: return bem_lbaseGet_0();
case 278788838: return bem_cuinitGet_0();
case 1380001241: return bem_classIncHGet_0();
case -340372908: return bem_kbaseGet_0();
case -835430144: return bem_unitExeGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1514941722: return bem_basePathSet_1(bevd_0);
case 1114375968: return bem_sameClass_1(bevd_0);
case 1356973534: return bem_clNameSet_1(bevd_0);
case 497061562: return bem_unitShlibSet_1(bevd_0);
case -651107547: return bem_clBaseSet_1(bevd_0);
case 643626045: return bem_shClassNameSet_1(bevd_0);
case -1133859902: return bem_mtdNameSet_1(bevd_0);
case 972885741: return bem_classSrcSet_1(bevd_0);
case 1951290590: return bem_unitExeSet_1(bevd_0);
case -864346840: return bem_classExeOSet_1(bevd_0);
case -1871751942: return bem_def_1(bevd_0);
case -260737184: return bem_nparStepsSet_1(bevd_0);
case -889107637: return bem_libnameDataClearSet_1(bevd_0);
case 385893729: return bem_undefined_1(bevd_0);
case 636648474: return bem_libnameDataSet_1(bevd_0);
case 824570327: return bem_synSrcSet_1(bevd_0);
case 1769484912: return bem_npSet_1(bevd_0);
case -704128729: return bem_copyTo_1(bevd_0);
case 1738731593: return bem_kbaseSet_1(bevd_0);
case 279657909: return bem_equals_1(bevd_0);
case -1607314732: return bem_libnameDataDoneSet_1(bevd_0);
case -1807249273: return bem_xbaseSet_1(bevd_0);
case 1979194181: return bem_notEquals_1(bevd_0);
case -921487598: return bem_nparSet_1(bevd_0);
case 1603994454: return bem_sameType_1(bevd_0);
case -505152552: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -287855524: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1314037522: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1963771415: return bem_undef_1(bevd_0);
case -1742950960: return bem_classSrcHSet_1(bevd_0);
case -1062800776: return bem_nsDirDo_1((BEC_2_4_6_TextString) bevd_0);
case 1845037163: return bem_emitterSet_1(bevd_0);
case -1505169719: return bem_classIncHSet_1(bevd_0);
case -1764284350: return bem_classOSet_1(bevd_0);
case 521238336: return bem_shFileNameSet_1(bevd_0);
case 100980215: return bem_otherClass_1(bevd_0);
case -142603752: return bem_classExeSrcSet_1(bevd_0);
case 1879903937: return bem_cproSet_1(bevd_0);
case -1192171297: return bem_defined_1(bevd_0);
case -49589828: return bem_nbaseSet_1(bevd_0);
case 1596320235: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 762902741: return bem_unitExeLinkSet_1(bevd_0);
case 1518497987: return bem_libNotNullInitDoneSet_1(bevd_0);
case -250481058: return bem_makeSrcSet_1(bevd_0);
case 1491157261: return bem_libNotNullInitSet_1(bevd_0);
case -89803536: return bem_cldefBuildSet_1(bevd_0);
case 743060436: return bem_emitPathSet_1(bevd_0);
case 1751207557: return bem_cuBaseSet_1(bevd_0);
case 469849664: return bem_libnameInitSet_1(bevd_0);
case 1932241217: return bem_namesOSet_1(bevd_0);
case -1502516986: return bem_nsDirSet_1(bevd_0);
case -767300526: return bem_cldefNameSet_1(bevd_0);
case -1644534224: return bem_libnameInitDoneSet_1(bevd_0);
case -1702268197: return bem_namesIncHSet_1(bevd_0);
case 646464640: return bem_midNameSet_1(bevd_0);
case 1045826130: return bem_lbaseSet_1(bevd_0);
case 417172649: return bem_sameObject_1(bevd_0);
case 641125554: return bem_incBlockSet_1(bevd_0);
case 1267197459: return bem_otherType_1(bevd_0);
case 2115662845: return bem_cuinitHSet_1(bevd_0);
case 881916073: return bem_cuinitSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1596177832: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1919067749: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1086524794: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1313996982: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1153243887: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 966288160: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -962439482: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 941513539: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 647104975: return bem_new_5((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildClassInfo_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildClassInfo_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildClassInfo();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst = (BEC_2_5_9_BuildClassInfo) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_type;
}
}
}
