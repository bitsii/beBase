namespace be {
/* IO:File: source/build/CEmitter.be */
public sealed class BEC_2_5_9_BuildClassInfo : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildClassInfo() { }
static BEC_2_5_9_BuildClassInfo() { }
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x6C,0x61,0x73,0x73,0x49,0x6E,0x66,0x6F};
private static byte[] becc_BEC_2_5_9_BuildClassInfo_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_0 = {0x42,0x45,0x4B,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_0, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_1 = {0x42,0x45,0x4B,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_1, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_2 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_2, 1));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_3 = {0x42,0x45,0x55,0x56,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_4 = {0x5F,0x63,0x6C,0x44,0x65,0x66};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_4, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_5 = {0x5F,0x73,0x68,0x43,0x6C,0x61,0x73,0x73,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_5, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_6 = {0x5F,0x73,0x68,0x46,0x69,0x6C,0x65,0x4E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_6, 11));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_7 = {0x42,0x45,0x55,0x46,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_4, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_8 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_8, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_9 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_9, 16));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_10 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_10, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_11 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_11, 16));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_12 = {0x5F,0x6C,0x69,0x62,0x6E,0x61,0x6D,0x65,0x44,0x61,0x74,0x61,0x43,0x6C,0x65,0x61,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_12, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_7, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_13 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_13, 12));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_3, 5));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_14 = {0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x6F,0x6E,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_14, 16));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_15 = {0x42,0x45,0x58,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_15, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_16 = {0x42,0x45,0x4B,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_16, 4));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_17 = {0x2E,0x68};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_18 = {0x2E,0x6D,0x61,0x6B,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_18, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_17, 2));
private static byte[] bece_BEC_2_5_9_BuildClassInfo_bels_19 = {0x2E,0x73,0x79,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildClassInfo_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildClassInfo_bels_19, 4));
public static new BEC_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_inst;

public static new BET_2_5_9_BuildClassInfo bece_BEC_2_5_9_BuildClassInfo_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_np;
public BEC_2_6_6_SystemObject bevp_emitter;
public BEC_2_5_15_BuildCompilerProfile bevp_cpro;
public BEC_2_5_8_BuildNamePath bevp_npar;
public BEC_2_6_6_SystemObject bevp_nparSteps;
public BEC_2_4_6_TextString bevp_clName;
public BEC_2_4_6_TextString bevp_clBase;
public BEC_2_4_6_TextString bevp_midName;
public BEC_2_4_6_TextString bevp_incBlock;
public BEC_2_4_6_TextString bevp_mtdName;
public BEC_2_4_6_TextString bevp_cldefName;
public BEC_2_4_6_TextString bevp_shClassName;
public BEC_2_4_6_TextString bevp_shFileName;
public BEC_2_4_6_TextString bevp_cldefBuild;
public BEC_2_4_6_TextString bevp_libnameInit;
public BEC_2_4_6_TextString bevp_libnameInitDone;
public BEC_2_4_6_TextString bevp_libnameData;
public BEC_2_4_6_TextString bevp_libnameDataDone;
public BEC_2_4_6_TextString bevp_libnameDataClear;
public BEC_2_4_6_TextString bevp_libNotNullInit;
public BEC_2_4_6_TextString bevp_libNotNullInitDone;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_3_2_4_4_IOFilePath bevp_basePath;
public BEC_3_2_4_4_IOFilePath bevp_cuBase;
public BEC_3_2_4_4_IOFilePath bevp_nsDir;
public BEC_2_4_6_TextString bevp_xbase;
public BEC_2_4_6_TextString bevp_lbase;
public BEC_2_4_6_TextString bevp_nbase;
public BEC_2_4_6_TextString bevp_kbase;
public BEC_3_2_4_4_IOFilePath bevp_cuinitH;
public BEC_2_4_6_TextString bevp_namesIncH;
public BEC_3_2_4_4_IOFilePath bevp_cuinit;
public BEC_3_2_4_4_IOFilePath bevp_namesO;
public BEC_3_2_4_4_IOFilePath bevp_unitShlib;
public BEC_3_2_4_4_IOFilePath bevp_unitExeLink;
public BEC_3_2_4_4_IOFilePath bevp_unitExe;
public BEC_3_2_4_4_IOFilePath bevp_classExeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classExeO;
public BEC_3_2_4_4_IOFilePath bevp_makeSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrc;
public BEC_3_2_4_4_IOFilePath bevp_classSrcH;
public BEC_3_2_4_4_IOFilePath bevp_classIncH;
public BEC_3_2_4_4_IOFilePath bevp_classO;
public BEC_3_2_4_4_IOFilePath bevp_synSrc;
public BEC_2_5_9_BuildClassInfo bem_new_4(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName) {
bem_new_5(beva__np, beva__emitter, beva__emitPath, beva__libName, beva__libName);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_new_5(BEC_2_5_8_BuildNamePath beva__np, BEC_2_6_6_SystemObject beva__emitter, BEC_3_2_4_4_IOFilePath beva__emitPath, BEC_2_4_6_TextString beva__libName, BEC_2_4_6_TextString beva__exeName) {
BEC_2_4_6_TextString bevl_cext = null;
BEC_2_4_6_TextString bevl_oext = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
bevp_np = beva__np;
bevp_emitter = beva__emitter;
bevt_0_tmpany_phold = bevp_emitter.bemd_0(-1298453047);
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_phold.bemd_0(-833041079);
bevp_npar = (BEC_2_5_8_BuildNamePath) bevp_np.bem_parentGet_0();
bevp_nparSteps = bevp_npar.bem_stepsGet_0();
bevp_clName = bevp_np.bem_toString_0();
bevt_1_tmpany_phold = bevp_np.bem_stepsGet_0();
bevp_clBase = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_lastGet_0();
bevp_midName = (BEC_2_4_6_TextString) bevp_emitter.bemd_2(924665952, beva__libName, beva__np);
bem_nsDirDo_1(beva__libName);
bevl_cext = bevp_cpro.bem_cextGet_0();
bevl_oext = bevp_cpro.bem_oextGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_0;
bevp_incBlock = bevt_2_tmpany_phold.bem_add_1(bevp_midName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevp_midName);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_2;
bevp_mtdName = bevt_3_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_3;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevp_midName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_4;
bevp_cldefName = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_5;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_midName);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_6;
bevp_shClassName = bevt_9_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_7;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevp_midName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_8;
bevp_shFileName = bevt_12_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_9;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevp_midName);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_10;
bevp_cldefBuild = bevt_15_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_11;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevp_midName);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_12;
bevp_libnameInit = bevt_18_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_13;
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevp_midName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_14;
bevp_libnameInitDone = bevt_21_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_15;
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevp_midName);
bevt_26_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_16;
bevp_libnameData = bevt_24_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_17;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevp_midName);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_18;
bevp_libnameDataDone = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_19;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevp_midName);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_20;
bevp_libnameDataClear = bevt_30_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_21;
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevp_midName);
bevt_35_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_22;
bevp_libNotNullInit = bevt_33_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_23;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_midName);
bevt_38_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_24;
bevp_libNotNullInitDone = bevt_36_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevp_emitPath = beva__emitPath;
bevp_basePath = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_add_1(bevp_nsDir);
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) beva__emitPath.bem_copy_0();
bevt_39_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_25;
bevp_xbase = bevt_39_tmpany_phold.bem_add_1(beva__libName);
bevp_lbase = beva__libName;
bevp_nbase = bevp_clBase;
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_26;
bevp_kbase = bevt_40_tmpany_phold.bem_add_1(bevp_clBase);
bevt_41_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_27;
bevt_42_tmpany_phold = bevp_nbase.bem_add_1(bevt_43_tmpany_phold);
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_41_tmpany_phold.bem_addStep_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_28;
bevp_namesIncH = bevp_nbase.bem_add_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_46_tmpany_phold = bevp_nbase.bem_add_1(bevl_cext);
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_45_tmpany_phold.bem_addStep_1(bevt_46_tmpany_phold);
bevt_47_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_48_tmpany_phold = bevp_nbase.bem_add_1(bevl_oext);
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_47_tmpany_phold.bem_addStep_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_51_tmpany_phold = bevp_cpro.bem_libExtGet_0();
bevt_50_tmpany_phold = bevp_lbase.bem_add_1(bevt_51_tmpany_phold);
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_49_tmpany_phold.bem_addStep_1(bevt_50_tmpany_phold);
bevt_52_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_54_tmpany_phold = bevp_cpro.bem_exeLibExtGet_0();
bevt_53_tmpany_phold = bevp_lbase.bem_add_1(bevt_54_tmpany_phold);
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_52_tmpany_phold.bem_addStep_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_cuBase.bem_copy_0();
bevt_57_tmpany_phold = bevp_cpro.bem_exeExtGet_0();
bevt_56_tmpany_phold = beva__exeName.bem_add_1(bevt_57_tmpany_phold);
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_55_tmpany_phold.bem_addStep_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_59_tmpany_phold = bevp_xbase.bem_add_1(bevl_cext);
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_58_tmpany_phold.bem_addStep_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_61_tmpany_phold = bevp_xbase.bem_add_1(bevl_oext);
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_60_tmpany_phold.bem_addStep_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_64_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_29;
bevt_63_tmpany_phold = bevp_xbase.bem_add_1(bevt_64_tmpany_phold);
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_62_tmpany_phold.bem_addStep_1(bevt_63_tmpany_phold);
bevt_65_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_66_tmpany_phold = bevp_kbase.bem_add_1(bevl_cext);
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_65_tmpany_phold.bem_addStep_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_69_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_30;
bevt_68_tmpany_phold = bevp_kbase.bem_add_1(bevt_69_tmpany_phold);
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_67_tmpany_phold.bem_addStep_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_nsDir.bem_copy_0();
bevt_72_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_31;
bevt_71_tmpany_phold = bevp_kbase.bem_add_1(bevt_72_tmpany_phold);
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_70_tmpany_phold.bem_addStep_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_74_tmpany_phold = bevp_kbase.bem_add_1(bevl_oext);
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_73_tmpany_phold.bem_addStep_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_basePath.bem_copy_0();
bevt_77_tmpany_phold = bece_BEC_2_5_9_BuildClassInfo_bevo_32;
bevt_76_tmpany_phold = bevp_kbase.bem_add_1(bevt_77_tmpany_phold);
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_75_tmpany_phold.bem_addStep_1(bevt_76_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirDo_1(BEC_2_4_6_TextString beva__libName) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_0();
bevp_nsDir.bem_addStep_1(beva__libName);
bevl_i = bevp_nparSteps.bemd_0(-449079106);
while (true)
 /* Line: 110 */ {
bevt_0_tmpany_phold = bevl_i.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 110 */ {
bevt_1_tmpany_phold = bevl_i.bemd_0(-1738265524);
bevp_nsDir.bem_addStep_1(bevt_1_tmpany_phold);
} /* Line: 111 */
 else  /* Line: 110 */ {
break;
} /* Line: 110 */
} /* Line: 110 */
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGet_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_npGetDirect_0() {
return bevp_np;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_npSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_np = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGetDirect_0() {
return bevp_emitter;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGet_0() {
return bevp_cpro;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_cproGetDirect_0() {
return bevp_cpro;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cproSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cpro = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGet_0() {
return bevp_npar;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_nparGetDirect_0() {
return bevp_npar;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_npar = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGet_0() {
return bevp_nparSteps;
} /*method end*/
public BEC_2_6_6_SystemObject bem_nparStepsGetDirect_0() {
return bevp_nparSteps;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nparSteps = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nparStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nparSteps = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGet_0() {
return bevp_clName;
} /*method end*/
public BEC_2_4_6_TextString bem_clNameGetDirect_0() {
return bevp_clName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_clName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGet_0() {
return bevp_clBase;
} /*method end*/
public BEC_2_4_6_TextString bem_clBaseGetDirect_0() {
return bevp_clBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_clBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_clBase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGet_0() {
return bevp_midName;
} /*method end*/
public BEC_2_4_6_TextString bem_midNameGetDirect_0() {
return bevp_midName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_midNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_midName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGet_0() {
return bevp_incBlock;
} /*method end*/
public BEC_2_4_6_TextString bem_incBlockGetDirect_0() {
return bevp_incBlock;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_incBlockSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_incBlock = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGet_0() {
return bevp_mtdName;
} /*method end*/
public BEC_2_4_6_TextString bem_mtdNameGetDirect_0() {
return bevp_mtdName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_mtdNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mtdName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGet_0() {
return bevp_cldefName;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefNameGetDirect_0() {
return bevp_cldefName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cldefName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGet_0() {
return bevp_shClassName;
} /*method end*/
public BEC_2_4_6_TextString bem_shClassNameGetDirect_0() {
return bevp_shClassName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shClassNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shClassName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGet_0() {
return bevp_shFileName;
} /*method end*/
public BEC_2_4_6_TextString bem_shFileNameGetDirect_0() {
return bevp_shFileName;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_shFileNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shFileName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGet_0() {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_4_6_TextString bem_cldefBuildGetDirect_0() {
return bevp_cldefBuild;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cldefBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cldefBuild = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGet_0() {
return bevp_libnameInit;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitGetDirect_0() {
return bevp_libnameInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGet_0() {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameInitDoneGetDirect_0() {
return bevp_libnameInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGet_0() {
return bevp_libnameData;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataGetDirect_0() {
return bevp_libnameData;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameData = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGet_0() {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataDoneGetDirect_0() {
return bevp_libnameDataDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameDataDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGet_0() {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_4_6_TextString bem_libnameDataClearGetDirect_0() {
return bevp_libnameDataClear;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libnameDataClearSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libnameDataClear = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGet_0() {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitGetDirect_0() {
return bevp_libNotNullInit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libNotNullInit = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGet_0() {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_4_6_TextString bem_libNotNullInitDoneGetDirect_0() {
return bevp_libNotNullInitDone;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_libNotNullInitDoneSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libNotNullInitDone = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGet_0() {
return bevp_basePath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_basePathGetDirect_0() {
return bevp_basePath;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_basePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_basePath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGet_0() {
return bevp_cuBase;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuBaseGetDirect_0() {
return bevp_cuBase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuBaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuBase = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGet_0() {
return bevp_nsDir;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_nsDirGetDirect_0() {
return bevp_nsDir;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nsDirSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nsDir = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGet_0() {
return bevp_xbase;
} /*method end*/
public BEC_2_4_6_TextString bem_xbaseGetDirect_0() {
return bevp_xbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_xbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_xbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGet_0() {
return bevp_lbase;
} /*method end*/
public BEC_2_4_6_TextString bem_lbaseGetDirect_0() {
return bevp_lbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_lbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGet_0() {
return bevp_nbase;
} /*method end*/
public BEC_2_4_6_TextString bem_nbaseGetDirect_0() {
return bevp_nbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_nbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGet_0() {
return bevp_kbase;
} /*method end*/
public BEC_2_4_6_TextString bem_kbaseGetDirect_0() {
return bevp_kbase;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_kbaseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_kbase = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGet_0() {
return bevp_cuinitH;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitHGetDirect_0() {
return bevp_cuinitH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuinitH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGet_0() {
return bevp_namesIncH;
} /*method end*/
public BEC_2_4_6_TextString bem_namesIncHGetDirect_0() {
return bevp_namesIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namesIncH = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGet_0() {
return bevp_cuinit;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_cuinitGetDirect_0() {
return bevp_cuinit;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_cuinitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_cuinit = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGet_0() {
return bevp_namesO;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_namesOGetDirect_0() {
return bevp_namesO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_namesOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_namesO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGet_0() {
return bevp_unitShlib;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitShlibGetDirect_0() {
return bevp_unitShlib;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitShlibSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitShlib = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGet_0() {
return bevp_unitExeLink;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeLinkGetDirect_0() {
return bevp_unitExeLink;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeLinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitExeLink = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGet_0() {
return bevp_unitExe;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_unitExeGetDirect_0() {
return bevp_unitExe;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_unitExeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_unitExe = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGet_0() {
return bevp_classExeSrc;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeSrcGetDirect_0() {
return bevp_classExeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classExeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGet_0() {
return bevp_classExeO;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classExeOGetDirect_0() {
return bevp_classExeO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classExeOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classExeO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGet_0() {
return bevp_makeSrc;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_makeSrcGetDirect_0() {
return bevp_makeSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_makeSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGet_0() {
return bevp_classSrc;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcGetDirect_0() {
return bevp_classSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGet_0() {
return bevp_classSrcH;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classSrcHGetDirect_0() {
return bevp_classSrcH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classSrcHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classSrcH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGet_0() {
return bevp_classIncH;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classIncHGetDirect_0() {
return bevp_classIncH;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classIncHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classIncH = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGet_0() {
return bevp_classO;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_classOGetDirect_0() {
return bevp_classO;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_classOSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classO = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGet_0() {
return bevp_synSrc;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_synSrcGetDirect_0() {
return bevp_synSrc;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildClassInfo bem_synSrcSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_synSrc = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 27, 28, 29, 29, 30, 31, 32, 34, 34, 36, 38, 39, 40, 43, 43, 45, 45, 45, 45, 47, 47, 47, 47, 49, 49, 49, 49, 51, 51, 51, 51, 53, 53, 53, 53, 55, 55, 55, 55, 57, 57, 57, 57, 59, 59, 59, 59, 61, 61, 61, 61, 63, 63, 63, 63, 65, 65, 65, 65, 66, 66, 66, 66, 68, 70, 71, 74, 74, 75, 76, 77, 77, 79, 79, 79, 79, 80, 80, 81, 81, 81, 82, 82, 82, 86, 86, 86, 86, 87, 87, 87, 87, 88, 88, 88, 88, 90, 90, 90, 91, 91, 91, 92, 92, 92, 92, 94, 94, 94, 95, 95, 95, 95, 96, 96, 96, 96, 97, 97, 97, 98, 98, 98, 98, 108, 109, 110, 110, 111, 111, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {110, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 324, 325, 326, 329, 331, 332, 341, 344, 347, 351, 355, 358, 361, 365, 369, 372, 375, 379, 383, 386, 389, 393, 397, 400, 403, 407, 411, 414, 417, 421, 425, 428, 431, 435, 439, 442, 445, 449, 453, 456, 459, 463, 467, 470, 473, 477, 481, 484, 487, 491, 495, 498, 501, 505, 509, 512, 515, 519, 523, 526, 529, 533, 537, 540, 543, 547, 551, 554, 557, 561, 565, 568, 571, 575, 579, 582, 585, 589, 593, 596, 599, 603, 607, 610, 613, 617, 621, 624, 627, 631, 635, 638, 641, 645, 649, 652, 655, 659, 663, 666, 669, 673, 677, 680, 683, 687, 691, 694, 697, 701, 705, 708, 711, 715, 719, 722, 725, 729, 733, 736, 739, 743, 747, 750, 753, 757, 761, 764, 767, 771, 775, 778, 781, 785, 789, 792, 795, 799, 803, 806, 809, 813, 817, 820, 823, 827, 831, 834, 837, 841, 845, 848, 851, 855, 859, 862, 865, 869, 873, 876, 879, 883, 887, 890, 893, 897, 901, 904, 907, 911, 915, 918, 921, 925, 929, 932, 935, 939, 943, 946, 949, 953};
/* BEGIN LINEINFO 
new 5 20 110
assign 1 27 194
assign 1 28 195
assign 1 29 196
buildGet 0 29 196
assign 1 29 197
compilerProfileGet 0 29 197
assign 1 30 198
parentGet 0 30 198
assign 1 31 199
stepsGet 0 31 199
assign 1 32 200
toString 0 32 200
assign 1 34 201
stepsGet 0 34 201
assign 1 34 202
lastGet 0 34 202
assign 1 36 203
midNameDo 2 36 203
nsDirDo 1 38 204
assign 1 39 205
cextGet 0 39 205
assign 1 40 206
oextGet 0 40 206
assign 1 43 207
new 0 43 207
assign 1 43 208
add 1 43 208
assign 1 45 209
new 0 45 209
assign 1 45 210
add 1 45 210
assign 1 45 211
new 0 45 211
assign 1 45 212
add 1 45 212
assign 1 47 213
new 0 47 213
assign 1 47 214
add 1 47 214
assign 1 47 215
new 0 47 215
assign 1 47 216
add 1 47 216
assign 1 49 217
new 0 49 217
assign 1 49 218
add 1 49 218
assign 1 49 219
new 0 49 219
assign 1 49 220
add 1 49 220
assign 1 51 221
new 0 51 221
assign 1 51 222
add 1 51 222
assign 1 51 223
new 0 51 223
assign 1 51 224
add 1 51 224
assign 1 53 225
new 0 53 225
assign 1 53 226
add 1 53 226
assign 1 53 227
new 0 53 227
assign 1 53 228
add 1 53 228
assign 1 55 229
new 0 55 229
assign 1 55 230
add 1 55 230
assign 1 55 231
new 0 55 231
assign 1 55 232
add 1 55 232
assign 1 57 233
new 0 57 233
assign 1 57 234
add 1 57 234
assign 1 57 235
new 0 57 235
assign 1 57 236
add 1 57 236
assign 1 59 237
new 0 59 237
assign 1 59 238
add 1 59 238
assign 1 59 239
new 0 59 239
assign 1 59 240
add 1 59 240
assign 1 61 241
new 0 61 241
assign 1 61 242
add 1 61 242
assign 1 61 243
new 0 61 243
assign 1 61 244
add 1 61 244
assign 1 63 245
new 0 63 245
assign 1 63 246
add 1 63 246
assign 1 63 247
new 0 63 247
assign 1 63 248
add 1 63 248
assign 1 65 249
new 0 65 249
assign 1 65 250
add 1 65 250
assign 1 65 251
new 0 65 251
assign 1 65 252
add 1 65 252
assign 1 66 253
new 0 66 253
assign 1 66 254
add 1 66 254
assign 1 66 255
new 0 66 255
assign 1 66 256
add 1 66 256
assign 1 68 257
assign 1 70 258
add 1 70 258
assign 1 71 259
copy 0 71 259
assign 1 74 260
new 0 74 260
assign 1 74 261
add 1 74 261
assign 1 75 262
assign 1 76 263
assign 1 77 264
new 0 77 264
assign 1 77 265
add 1 77 265
assign 1 79 266
copy 0 79 266
assign 1 79 267
new 0 79 267
assign 1 79 268
add 1 79 268
assign 1 79 269
addStep 1 79 269
assign 1 80 270
new 0 80 270
assign 1 80 271
add 1 80 271
assign 1 81 272
copy 0 81 272
assign 1 81 273
add 1 81 273
assign 1 81 274
addStep 1 81 274
assign 1 82 275
copy 0 82 275
assign 1 82 276
add 1 82 276
assign 1 82 277
addStep 1 82 277
assign 1 86 278
copy 0 86 278
assign 1 86 279
libExtGet 0 86 279
assign 1 86 280
add 1 86 280
assign 1 86 281
addStep 1 86 281
assign 1 87 282
copy 0 87 282
assign 1 87 283
exeLibExtGet 0 87 283
assign 1 87 284
add 1 87 284
assign 1 87 285
addStep 1 87 285
assign 1 88 286
copy 0 88 286
assign 1 88 287
exeExtGet 0 88 287
assign 1 88 288
add 1 88 288
assign 1 88 289
addStep 1 88 289
assign 1 90 290
copy 0 90 290
assign 1 90 291
add 1 90 291
assign 1 90 292
addStep 1 90 292
assign 1 91 293
copy 0 91 293
assign 1 91 294
add 1 91 294
assign 1 91 295
addStep 1 91 295
assign 1 92 296
copy 0 92 296
assign 1 92 297
new 0 92 297
assign 1 92 298
add 1 92 298
assign 1 92 299
addStep 1 92 299
assign 1 94 300
copy 0 94 300
assign 1 94 301
add 1 94 301
assign 1 94 302
addStep 1 94 302
assign 1 95 303
copy 0 95 303
assign 1 95 304
new 0 95 304
assign 1 95 305
add 1 95 305
assign 1 95 306
addStep 1 95 306
assign 1 96 307
copy 0 96 307
assign 1 96 308
new 0 96 308
assign 1 96 309
add 1 96 309
assign 1 96 310
addStep 1 96 310
assign 1 97 311
copy 0 97 311
assign 1 97 312
add 1 97 312
assign 1 97 313
addStep 1 97 313
assign 1 98 314
copy 0 98 314
assign 1 98 315
new 0 98 315
assign 1 98 316
add 1 98 316
assign 1 98 317
addStep 1 98 317
assign 1 108 324
new 0 108 324
addStep 1 109 325
assign 1 110 326
iteratorGet 0 110 326
assign 1 110 329
hasNextGet 0 110 329
assign 1 111 331
nextGet 0 111 331
addStep 1 111 332
return 1 0 341
return 1 0 344
assign 1 0 347
assign 1 0 351
return 1 0 355
return 1 0 358
assign 1 0 361
assign 1 0 365
return 1 0 369
return 1 0 372
assign 1 0 375
assign 1 0 379
return 1 0 383
return 1 0 386
assign 1 0 389
assign 1 0 393
return 1 0 397
return 1 0 400
assign 1 0 403
assign 1 0 407
return 1 0 411
return 1 0 414
assign 1 0 417
assign 1 0 421
return 1 0 425
return 1 0 428
assign 1 0 431
assign 1 0 435
return 1 0 439
return 1 0 442
assign 1 0 445
assign 1 0 449
return 1 0 453
return 1 0 456
assign 1 0 459
assign 1 0 463
return 1 0 467
return 1 0 470
assign 1 0 473
assign 1 0 477
return 1 0 481
return 1 0 484
assign 1 0 487
assign 1 0 491
return 1 0 495
return 1 0 498
assign 1 0 501
assign 1 0 505
return 1 0 509
return 1 0 512
assign 1 0 515
assign 1 0 519
return 1 0 523
return 1 0 526
assign 1 0 529
assign 1 0 533
return 1 0 537
return 1 0 540
assign 1 0 543
assign 1 0 547
return 1 0 551
return 1 0 554
assign 1 0 557
assign 1 0 561
return 1 0 565
return 1 0 568
assign 1 0 571
assign 1 0 575
return 1 0 579
return 1 0 582
assign 1 0 585
assign 1 0 589
return 1 0 593
return 1 0 596
assign 1 0 599
assign 1 0 603
return 1 0 607
return 1 0 610
assign 1 0 613
assign 1 0 617
return 1 0 621
return 1 0 624
assign 1 0 627
assign 1 0 631
return 1 0 635
return 1 0 638
assign 1 0 641
assign 1 0 645
return 1 0 649
return 1 0 652
assign 1 0 655
assign 1 0 659
return 1 0 663
return 1 0 666
assign 1 0 669
assign 1 0 673
return 1 0 677
return 1 0 680
assign 1 0 683
assign 1 0 687
return 1 0 691
return 1 0 694
assign 1 0 697
assign 1 0 701
return 1 0 705
return 1 0 708
assign 1 0 711
assign 1 0 715
return 1 0 719
return 1 0 722
assign 1 0 725
assign 1 0 729
return 1 0 733
return 1 0 736
assign 1 0 739
assign 1 0 743
return 1 0 747
return 1 0 750
assign 1 0 753
assign 1 0 757
return 1 0 761
return 1 0 764
assign 1 0 767
assign 1 0 771
return 1 0 775
return 1 0 778
assign 1 0 781
assign 1 0 785
return 1 0 789
return 1 0 792
assign 1 0 795
assign 1 0 799
return 1 0 803
return 1 0 806
assign 1 0 809
assign 1 0 813
return 1 0 817
return 1 0 820
assign 1 0 823
assign 1 0 827
return 1 0 831
return 1 0 834
assign 1 0 837
assign 1 0 841
return 1 0 845
return 1 0 848
assign 1 0 851
assign 1 0 855
return 1 0 859
return 1 0 862
assign 1 0 865
assign 1 0 869
return 1 0 873
return 1 0 876
assign 1 0 879
assign 1 0 883
return 1 0 887
return 1 0 890
assign 1 0 893
assign 1 0 897
return 1 0 901
return 1 0 904
assign 1 0 907
assign 1 0 911
return 1 0 915
return 1 0 918
assign 1 0 921
assign 1 0 925
return 1 0 929
return 1 0 932
assign 1 0 935
assign 1 0 939
return 1 0 943
return 1 0 946
assign 1 0 949
assign 1 0 953
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 285866632: return bem_nparGet_0();
case -1016641200: return bem_kbaseGet_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case 888344814: return bem_unitExeLinkGet_0();
case -266206789: return bem_synSrcGetDirect_0();
case -1068453084: return bem_cuBaseGetDirect_0();
case 341575045: return bem_many_0();
case 1071461198: return bem_echo_0();
case -1123278056: return bem_tagGet_0();
case -158683433: return bem_unitShlibGetDirect_0();
case -1444358681: return bem_libnameDataClearGetDirect_0();
case -364770149: return bem_classSrcHGetDirect_0();
case 527186103: return bem_clNameGet_0();
case 1915935961: return bem_shFileNameGetDirect_0();
case -375231851: return bem_libnameDataClearGet_0();
case -1699016030: return bem_classExeSrcGet_0();
case 473138146: return bem_libnameInitDoneGet_0();
case -134718292: return bem_namesIncHGetDirect_0();
case 990360647: return bem_new_0();
case 123697623: return bem_nsDirGetDirect_0();
case 360302884: return bem_clNameGetDirect_0();
case 1288349278: return bem_shFileNameGet_0();
case -84965494: return bem_namesOGetDirect_0();
case -1641318205: return bem_classExeSrcGetDirect_0();
case -1086782351: return bem_print_0();
case -929467204: return bem_nsDirGet_0();
case -633561195: return bem_unitExeLinkGetDirect_0();
case -964821425: return bem_cuinitGetDirect_0();
case 1313709716: return bem_unitShlibGet_0();
case -538659707: return bem_classExeOGetDirect_0();
case 129948736: return bem_cldefBuildGetDirect_0();
case 1889025359: return bem_incBlockGetDirect_0();
case -681110006: return bem_libNotNullInitGetDirect_0();
case -1692873372: return bem_classIncHGetDirect_0();
case 1577195459: return bem_serializationIteratorGet_0();
case -1586763650: return bem_cuinitHGetDirect_0();
case 1513233059: return bem_toString_0();
case -2082449718: return bem_cldefNameGet_0();
case 1575329161: return bem_classSrcGetDirect_0();
case -994713498: return bem_libnameInitDoneGetDirect_0();
case -1147439637: return bem_classExeOGet_0();
case -343761106: return bem_libnameDataGetDirect_0();
case -713163994: return bem_toAny_0();
case -35223042: return bem_emitPathGetDirect_0();
case 1194804327: return bem_fieldNamesGet_0();
case 1653298584: return bem_classOGetDirect_0();
case 1540540946: return bem_cldefBuildGet_0();
case 1437535594: return bem_xbaseGet_0();
case 1688676399: return bem_npGet_0();
case -1576352839: return bem_kbaseGetDirect_0();
case -510399607: return bem_midNameGet_0();
case -1911131223: return bem_classIncHGet_0();
case 1240371900: return bem_shClassNameGetDirect_0();
case -1370068523: return bem_cuBaseGet_0();
case 31400971: return bem_emitterGet_0();
case -1673328549: return bem_shClassNameGet_0();
case 2085522281: return bem_classOGet_0();
case -1858034253: return bem_libNotNullInitDoneGet_0();
case -1505247774: return bem_clBaseGet_0();
case 152152759: return bem_basePathGetDirect_0();
case -1040416467: return bem_clBaseGetDirect_0();
case 90701907: return bem_nbaseGetDirect_0();
case 1534639831: return bem_libNotNullInitGet_0();
case 1456993129: return bem_libnameDataGet_0();
case -1976990650: return bem_lbaseGetDirect_0();
case -1620799156: return bem_libnameInitGet_0();
case -492195897: return bem_classSrcHGet_0();
case -449079106: return bem_iteratorGet_0();
case -1533729572: return bem_nparStepsGetDirect_0();
case 611670694: return bem_fieldIteratorGet_0();
case 1609405241: return bem_cuinitGet_0();
case 1737514203: return bem_cldefNameGetDirect_0();
case -1362850090: return bem_serializeContents_0();
case 1774405343: return bem_makeSrcGet_0();
case 1942283510: return bem_sourceFileNameGet_0();
case -1715604549: return bem_mtdNameGetDirect_0();
case 2103008792: return bem_cproGet_0();
case -10010145: return bem_copy_0();
case 31251049: return bem_makeSrcGetDirect_0();
case -399988475: return bem_nbaseGet_0();
case -387967885: return bem_libnameDataDoneGet_0();
case -1040888004: return bem_unitExeGet_0();
case 1126581121: return bem_midNameGetDirect_0();
case -651095534: return bem_namesIncHGet_0();
case -1937041023: return bem_libNotNullInitDoneGetDirect_0();
case 144584723: return bem_create_0();
case -1902779705: return bem_incBlockGet_0();
case -982332215: return bem_libnameInitGetDirect_0();
case 1581054005: return bem_mtdNameGet_0();
case 646214487: return bem_xbaseGetDirect_0();
case -970750781: return bem_libnameDataDoneGetDirect_0();
case -1326602846: return bem_emitPathGet_0();
case 1851908877: return bem_hashGet_0();
case -2051518290: return bem_once_0();
case -415921105: return bem_nparGetDirect_0();
case -410494364: return bem_cuinitHGet_0();
case -569635335: return bem_namesOGet_0();
case -1266447496: return bem_classNameGet_0();
case 576813624: return bem_unitExeGetDirect_0();
case 1780726089: return bem_npGetDirect_0();
case 1652184746: return bem_nparStepsGet_0();
case -1886101130: return bem_cproGetDirect_0();
case 1757421300: return bem_synSrcGet_0();
case -991578035: return bem_emitterGetDirect_0();
case 65653069: return bem_classSrcGet_0();
case 1666799738: return bem_basePathGet_0();
case 301256761: return bem_lbaseGet_0();
case 96033137: return bem_serializeToString_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1449340032: return bem_otherClass_1(bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case -2023427987: return bem_lbaseSet_1(bevd_0);
case -1449675750: return bem_basePathSet_1(bevd_0);
case 1486499789: return bem_lbaseSetDirect_1(bevd_0);
case -549379462: return bem_namesOSetDirect_1(bevd_0);
case -1153085180: return bem_classExeOSet_1(bevd_0);
case 1672187278: return bem_clNameSetDirect_1(bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1441807617: return bem_shClassNameSet_1(bevd_0);
case 1192610507: return bem_makeSrcSet_1(bevd_0);
case -1881610134: return bem_classExeSrcSetDirect_1(bevd_0);
case -1237296435: return bem_cuinitSetDirect_1(bevd_0);
case -695216264: return bem_kbaseSet_1(bevd_0);
case -770080208: return bem_unitExeSet_1(bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case -1983796426: return bem_npSetDirect_1(bevd_0);
case 1133360036: return bem_libNotNullInitDoneSetDirect_1(bevd_0);
case -683186668: return bem_cldefNameSetDirect_1(bevd_0);
case 328959405: return bem_libNotNullInitSetDirect_1(bevd_0);
case 176714656: return bem_kbaseSetDirect_1(bevd_0);
case 532215381: return bem_cproSet_1(bevd_0);
case -442415696: return bem_synSrcSet_1(bevd_0);
case 239729498: return bem_libNotNullInitDoneSet_1(bevd_0);
case 190936547: return bem_libnameInitSetDirect_1(bevd_0);
case -385197473: return bem_nparStepsSet_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case 2001786567: return bem_libnameInitDoneSetDirect_1(bevd_0);
case -1112423769: return bem_classSrcSetDirect_1(bevd_0);
case 1983565651: return bem_classSrcHSet_1(bevd_0);
case -2087094670: return bem_incBlockSet_1(bevd_0);
case -1381822859: return bem_clBaseSet_1(bevd_0);
case 1023410520: return bem_mtdNameSetDirect_1(bevd_0);
case -1261998011: return bem_classExeSrcSet_1(bevd_0);
case 974711346: return bem_classSrcHSetDirect_1(bevd_0);
case -821112811: return bem_nparSetDirect_1(bevd_0);
case -1463858412: return bem_incBlockSetDirect_1(bevd_0);
case -1279938436: return bem_libnameDataDoneSet_1(bevd_0);
case 1903011622: return bem_nbaseSetDirect_1(bevd_0);
case -345064712: return bem_midNameSetDirect_1(bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 803088953: return bem_libnameDataSet_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
case 642212451: return bem_nsDirSet_1(bevd_0);
case 1451843840: return bem_emitPathSet_1(bevd_0);
case 1477490881: return bem_unitExeSetDirect_1(bevd_0);
case -1554552566: return bem_libnameDataSetDirect_1(bevd_0);
case -299439565: return bem_cuinitHSet_1(bevd_0);
case -20683777: return bem_unitExeLinkSetDirect_1(bevd_0);
case 1929928986: return bem_libnameDataClearSetDirect_1(bevd_0);
case 1882009919: return bem_libnameDataClearSet_1(bevd_0);
case -1892228713: return bem_namesIncHSet_1(bevd_0);
case 2024674968: return bem_cuBaseSetDirect_1(bevd_0);
case -734779651: return bem_nsDirSetDirect_1(bevd_0);
case -2023502432: return bem_cuinitSet_1(bevd_0);
case 355095248: return bem_unitExeLinkSet_1(bevd_0);
case 240052766: return bem_xbaseSet_1(bevd_0);
case -1808458840: return bem_namesIncHSetDirect_1(bevd_0);
case -1604892458: return bem_classSrcSet_1(bevd_0);
case 1956651723: return bem_nsDirDo_1((BEC_2_4_6_TextString) bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case 1041054051: return bem_npSet_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case 541978987: return bem_makeSrcSetDirect_1(bevd_0);
case 844121831: return bem_cldefBuildSetDirect_1(bevd_0);
case -1063660220: return bem_nbaseSet_1(bevd_0);
case -481963350: return bem_unitShlibSetDirect_1(bevd_0);
case 1136885133: return bem_classExeOSetDirect_1(bevd_0);
case 636610731: return bem_libNotNullInitSet_1(bevd_0);
case -522370432: return bem_emitPathSetDirect_1(bevd_0);
case 1022344638: return bem_cuBaseSet_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case 1059052090: return bem_libnameDataDoneSetDirect_1(bevd_0);
case -1758602242: return bem_cproSetDirect_1(bevd_0);
case -243503617: return bem_mtdNameSet_1(bevd_0);
case -389018870: return bem_nparSet_1(bevd_0);
case 1712057478: return bem_namesOSet_1(bevd_0);
case 87329138: return bem_synSrcSetDirect_1(bevd_0);
case -2020242710: return bem_unitShlibSet_1(bevd_0);
case 1703302021: return bem_libnameInitSet_1(bevd_0);
case 537704247: return bem_basePathSetDirect_1(bevd_0);
case -2012317017: return bem_nparStepsSetDirect_1(bevd_0);
case -1818795263: return bem_classOSet_1(bevd_0);
case 1232911758: return bem_midNameSet_1(bevd_0);
case 1650658144: return bem_clNameSet_1(bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case -1586586655: return bem_shClassNameSetDirect_1(bevd_0);
case -1747359164: return bem_classOSetDirect_1(bevd_0);
case -766405547: return bem_cuinitHSetDirect_1(bevd_0);
case 1200143600: return bem_shFileNameSet_1(bevd_0);
case -102962346: return bem_classIncHSet_1(bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case -1817506149: return bem_xbaseSetDirect_1(bevd_0);
case 1104993399: return bem_clBaseSetDirect_1(bevd_0);
case 73851273: return bem_libnameInitDoneSet_1(bevd_0);
case -655019399: return bem_def_1(bevd_0);
case 978417778: return bem_cldefNameSet_1(bevd_0);
case -177951621: return bem_emitterSetDirect_1(bevd_0);
case 1867136807: return bem_emitterSet_1(bevd_0);
case -215674007: return bem_classIncHSetDirect_1(bevd_0);
case 1312810350: return bem_cldefBuildSet_1(bevd_0);
case -1048037: return bem_shFileNameSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1125032479: return bem_new_4((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1466228078: return bem_new_5((BEC_2_5_8_BuildNamePath) bevd_0, bevd_1, (BEC_3_2_4_4_IOFilePath) bevd_2, (BEC_2_4_6_TextString) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildClassInfo_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildClassInfo_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildClassInfo();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst = (BEC_2_5_9_BuildClassInfo) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildClassInfo.bece_BEC_2_5_9_BuildClassInfo_bevs_type;
}
}
}
