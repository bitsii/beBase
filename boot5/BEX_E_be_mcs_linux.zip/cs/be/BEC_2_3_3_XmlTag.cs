namespace be {
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_3_XmlTag : BEC_2_6_6_SystemObject {
public BEC_2_3_3_XmlTag() { }
static BEC_2_3_3_XmlTag() { }
private static byte[] becc_BEC_2_3_3_XmlTag_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67};
private static byte[] becc_BEC_2_3_3_XmlTag_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static new BEC_2_3_3_XmlTag bece_BEC_2_3_3_XmlTag_bevs_inst;
public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callCase) {
switch (callCase) {
case 1829615340: return bem_fieldIteratorGet_0();
case 386499474: return bem_deserializeClassNameGet_0();
case -1710921376: return bem_iteratorGet_0();
case -289190594: return bem_new_0();
case 1110687349: return bem_serializationIteratorGet_0();
case 1606100185: return bem_toAny_0();
case 1323527258: return bem_copy_0();
case 154399642: return bem_hashGet_0();
case 468841666: return bem_sourceFileNameGet_0();
case -285521200: return bem_create_0();
case 628114265: return bem_many_0();
case -86198663: return bem_print_0();
case -457712006: return bem_classNameGet_0();
case -1679072038: return bem_toString_0();
case -2143843780: return bem_tagGet_0();
case 402795231: return bem_once_0();
case -1896702956: return bem_serializeContents_0();
case 820088259: return bem_echo_0();
case -693169976: return bem_serializeToString_0();
}
return base.bemd_0(callCase);
}
public override BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) {
switch (callCase) {
case 2033308650: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 405603043: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1759835639: return bem_defined_1(bevd_0);
case 1958076839: return bem_undefined_1(bevd_0);
case 2086659962: return bem_sameObject_1(bevd_0);
case 1253393632: return bem_def_1(bevd_0);
case -1211467604: return bem_copyTo_1(bevd_0);
case 365385951: return bem_equals_1(bevd_0);
case 938569326: return bem_notEquals_1(bevd_0);
case -641584584: return bem_sameClass_1(bevd_0);
case -1706185549: return bem_otherType_1(bevd_0);
case 713999383: return bem_undef_1(bevd_0);
case -861317881: return bem_otherClass_1(bevd_0);
case 343567700: return bem_sameType_1(bevd_0);
case -1770369050: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 823180387: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callCase, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callCase) {
case -1125341844: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1389614349: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1812156494: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1790570920: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2109777534: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1447567526: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1299212473: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callCase, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(7, becc_BEC_2_3_3_XmlTag_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_3_XmlTag_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_3_3_XmlTag();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_3_3_XmlTag.bece_BEC_2_3_3_XmlTag_bevs_inst = (BEC_2_3_3_XmlTag) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_3_3_XmlTag.bece_BEC_2_3_3_XmlTag_bevs_inst;
}
}
}
