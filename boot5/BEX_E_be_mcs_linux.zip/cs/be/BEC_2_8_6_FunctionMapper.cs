namespace be {
/* IO:File: source/base/Functions.be */
public sealed class BEC_2_8_6_FunctionMapper : BEC_2_6_6_SystemObject {
public BEC_2_8_6_FunctionMapper() { }
static BEC_2_8_6_FunctionMapper() { }
private static byte[] becc_BEC_2_8_6_FunctionMapper_clname = {0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x3A,0x4D,0x61,0x70,0x70,0x65,0x72};
private static byte[] becc_BEC_2_8_6_FunctionMapper_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x46,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_8_6_FunctionMapper bece_BEC_2_8_6_FunctionMapper_bevs_inst;

public static new BET_2_8_6_FunctionMapper bece_BEC_2_8_6_FunctionMapper_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_default_0() {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_mapCopy_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemMethod beva_action) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = beva_input.bemd_0(-1057001629);
bevt_0_tmpany_phold = bem_map_2(bevt_1_tmpany_phold, beva_action);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_map_2(BEC_2_6_6_SystemObject beva_input, BEC_2_6_6_SystemObject beva_action) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_input.bemd_0(654084467);
bem_mapIterator_2(bevt_0_tmpany_phold, (BEC_2_6_6_SystemMethod) beva_action );
return beva_input;
} /*method end*/
public BEC_2_8_6_FunctionMapper bem_mapIterator_2(BEC_2_6_6_SystemObject beva_iter, BEC_2_6_6_SystemMethod beva_action) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject[] bevd_x = new BEC_2_6_6_SystemObject[2];
while (true)
 /* Line: 24 */ {
bevt_0_tmpany_phold = beva_iter.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 24 */ {
bevt_2_tmpany_phold = beva_iter.bemd_0(901258413);
bevd_x[0] = bevt_2_tmpany_phold;
bevt_1_tmpany_phold = beva_action.bems_forwardCallCp(new BEC_2_4_6_TextString(System.Text.Encoding.UTF8.GetBytes("apply")), new BEC_2_9_4_ContainerList(bevd_x, 1));
beva_iter.bemd_1(1673438491, bevt_1_tmpany_phold);
} /* Line: 25 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15, 15, 15, 19, 19, 20, 24, 25, 25, 25};
public static new int[] bevs_smnlec
 = new int[] {21, 22, 23, 27, 28, 29, 38, 40, 41, 43};
/* BEGIN LINEINFO 
assign 1 15 21
copy 0 15 21
assign 1 15 22
map 2 15 22
return 1 15 23
assign 1 19 27
iteratorGet 0 19 27
mapIterator 2 19 28
return 1 20 29
assign 1 24 38
hasNextGet 0 24 38
assign 1 25 40
nextGet 0 25 40
assign 1 25 41
apply 1 25 41
currentSet 1 25 43
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1048772166: return bem_echo_0();
case 714392359: return bem_classNameGet_0();
case -1874213289: return bem_tagGet_0();
case 1028683886: return bem_toString_0();
case -354093047: return bem_serializationIteratorGet_0();
case -1312519804: return bem_hashGet_0();
case -551298753: return bem_sourceFileNameGet_0();
case -1036233638: return bem_new_0();
case -386157741: return bem_serializeToString_0();
case -76505233: return bem_once_0();
case -1963468660: return bem_fieldIteratorGet_0();
case 1836947478: return bem_serializeContents_0();
case -1057001629: return bem_copy_0();
case -925549027: return bem_default_0();
case -454910570: return bem_create_0();
case -1493103250: return bem_many_0();
case 654084467: return bem_iteratorGet_0();
case 863669946: return bem_toAny_0();
case -362321661: return bem_deserializeClassNameGet_0();
case -354590014: return bem_print_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1978731115: return bem_sameType_1(bevd_0);
case 729561267: return bem_copyTo_1(bevd_0);
case 604922157: return bem_equals_1(bevd_0);
case 2095964872: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -965306462: return bem_undefined_1(bevd_0);
case -1374275511: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -558198774: return bem_def_1(bevd_0);
case -999936361: return bem_defined_1(bevd_0);
case 1782921206: return bem_otherType_1(bevd_0);
case -403482348: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1301577712: return bem_sameClass_1(bevd_0);
case -1184340301: return bem_otherClass_1(bevd_0);
case -747350143: return bem_undef_1(bevd_0);
case 1672825312: return bem_notEquals_1(bevd_0);
case -504315826: return bem_sameObject_1(bevd_0);
case -1188536421: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -249962556: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -608983707: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 913536943: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1020737806: return bem_mapIterator_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case -1192068648: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1655666515: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 478589859: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 280762673: return bem_map_2(bevd_0, bevd_1);
case -400987355: return bem_mapCopy_2(bevd_0, (BEC_2_6_6_SystemMethod) bevd_1);
case -2045713194: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_8_6_FunctionMapper_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_8_6_FunctionMapper_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_8_6_FunctionMapper();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst = (BEC_2_8_6_FunctionMapper) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_8_6_FunctionMapper.bece_BEC_2_8_6_FunctionMapper_bevs_type;
}
}
}
