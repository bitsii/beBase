namespace be {

using System.Security.Cryptography;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_EncodeHtml : BEC_2_6_6_SystemObject {
public BEC_2_6_4_EncodeHtml() { }
static BEC_2_6_4_EncodeHtml() { }
private static byte[] becc_BEC_2_6_4_EncodeHtml_clname = {0x45,0x6E,0x63,0x6F,0x64,0x65,0x3A,0x48,0x74,0x6D,0x6C};
private static byte[] becc_BEC_2_6_4_EncodeHtml_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_0 = {0x22};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_1 = {0x3C};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_2 = {0x3E};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_3 = {0x26};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_4 = {0x26,0x23};
private static byte[] bece_BEC_2_6_4_EncodeHtml_bels_5 = {0x3B};
public static new BEC_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_inst;

public static new BET_2_6_4_EncodeHtml bece_BEC_2_6_4_EncodeHtml_bevs_type;

public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public virtual BEC_2_6_4_EncodeHtml bem_default_0() {
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_encode_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevl_r = null;
BEC_2_4_12_TextByteIterator bevl_tb = null;
BEC_2_4_6_TextString bevl_pt = null;
BEC_2_4_3_MathInt bevl_ac = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
bevt_5_ta_ph = beva_str.bem_sizeGet_0();
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_4_ta_ph = bevt_5_ta_ph.bem_multiply_1(bevt_6_ta_ph);
bevl_r = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_4_ta_ph);
bevl_tb = (BEC_2_4_12_TextByteIterator) (new BEC_2_4_12_TextByteIterator()).bem_new_1(beva_str);
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevl_pt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_7_ta_ph);
while (true)
/* Line: 185*/ {
bevt_8_ta_ph = bevl_tb.bem_hasNextGet_0();
if (bevt_8_ta_ph.bevi_bool)/* Line: 185*/ {
bevl_tb.bem_next_1(bevl_pt);
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevl_ac = bevl_pt.bem_getCode_1(bevt_9_ta_ph);
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(127));
if (bevl_ac.bevi_int > bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_0));
bevt_12_ta_ph = bevl_pt.bem_equals_1(bevt_13_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 188*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 188*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_1));
bevt_14_ta_ph = bevl_pt.bem_equals_1(bevt_15_ta_ph);
if (bevt_14_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 188*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 188*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_2));
bevt_16_ta_ph = bevl_pt.bem_equals_1(bevt_17_ta_ph);
if (bevt_16_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 188*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 188*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_3));
bevt_18_ta_ph = bevl_pt.bem_equals_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 188*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 188*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 188*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 188*/ {
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_6_4_EncodeHtml_bels_4));
bevl_r.bem_addValue_1(bevt_20_ta_ph);
bevt_21_ta_ph = bevl_ac.bem_toString_0();
bevl_r.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_6_4_EncodeHtml_bels_5));
bevl_r.bem_addValue_1(bevt_22_ta_ph);
} /* Line: 191*/
 else /* Line: 192*/ {
bevl_r.bem_addValue_1(bevl_pt);
} /* Line: 193*/
} /* Line: 188*/
 else /* Line: 185*/ {
break;
} /* Line: 185*/
} /* Line: 185*/
return bevl_r;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {182, 182, 182, 182, 183, 184, 184, 185, 186, 187, 187, 188, 188, 188, 0, 188, 188, 0, 0, 0, 188, 188, 0, 0, 0, 188, 188, 0, 0, 0, 188, 188, 0, 0, 189, 189, 190, 190, 191, 191, 193, 196};
public static new int[] bevs_smnlec
 = new int[] {54, 55, 56, 57, 58, 59, 60, 63, 65, 66, 67, 68, 69, 74, 75, 78, 79, 81, 84, 88, 91, 92, 94, 97, 101, 104, 105, 107, 110, 114, 117, 118, 120, 123, 127, 128, 129, 130, 131, 132, 135, 142};
/* BEGIN LINEINFO 
assign 1 182 54
sizeGet 0 182 54
assign 1 182 55
new 0 182 55
assign 1 182 56
multiply 1 182 56
assign 1 182 57
new 1 182 57
assign 1 183 58
new 1 183 58
assign 1 184 59
new 0 184 59
assign 1 184 60
new 1 184 60
assign 1 185 63
hasNextGet 0 185 63
next 1 186 65
assign 1 187 66
new 0 187 66
assign 1 187 67
getCode 1 187 67
assign 1 188 68
new 0 188 68
assign 1 188 69
greater 1 188 74
assign 1 0 75
assign 1 188 78
new 0 188 78
assign 1 188 79
equals 1 188 79
assign 1 0 81
assign 1 0 84
assign 1 0 88
assign 1 188 91
new 0 188 91
assign 1 188 92
equals 1 188 92
assign 1 0 94
assign 1 0 97
assign 1 0 101
assign 1 188 104
new 0 188 104
assign 1 188 105
equals 1 188 105
assign 1 0 107
assign 1 0 110
assign 1 0 114
assign 1 188 117
new 0 188 117
assign 1 188 118
equals 1 188 118
assign 1 0 120
assign 1 0 123
assign 1 189 127
new 0 189 127
addValue 1 189 128
assign 1 190 129
toString 0 190 129
addValue 1 190 130
assign 1 191 131
new 0 191 131
addValue 1 191 132
addValue 1 193 135
return 1 196 142
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1363819567: return bem_new_0();
case -467511392: return bem_toString_0();
case -793241295: return bem_iteratorGet_0();
case 1890854002: return bem_tagGet_0();
case -447432319: return bem_many_0();
case -105946774: return bem_serializeToString_0();
case -1760538533: return bem_classNameGet_0();
case -1323898541: return bem_toAny_0();
case -1188922735: return bem_echo_0();
case 1092105192: return bem_hashGet_0();
case 1948584685: return bem_default_0();
case 1652521523: return bem_serializeContents_0();
case 1319388306: return bem_copy_0();
case -921473949: return bem_fieldNamesGet_0();
case 1403688004: return bem_serializationIteratorGet_0();
case 1597327951: return bem_create_0();
case 7254011: return bem_fieldIteratorGet_0();
case 895193825: return bem_once_0();
case -1387831588: return bem_print_0();
case 371157924: return bem_sourceFileNameGet_0();
case -39165288: return bem_deserializeClassNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1488511778: return bem_otherType_1(bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 977835882: return bem_encode_1((BEC_2_4_6_TextString) bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_EncodeHtml_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_4_EncodeHtml_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_4_EncodeHtml();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst = (BEC_2_6_4_EncodeHtml) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_4_EncodeHtml.bece_BEC_2_6_4_EncodeHtml_bevs_type;
}
}
}
