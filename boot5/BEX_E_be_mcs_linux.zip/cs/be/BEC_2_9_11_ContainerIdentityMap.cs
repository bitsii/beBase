namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap : BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
static BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static new BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {91, 91, 95, 96, 97, 98, 99, 100};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 91 14
new 0 91 14
new 1 91 15
assign 1 95 19
new 1 95 19
assign 1 96 20
assign 1 97 21
new 0 97 21
assign 1 98 22
new 0 98 22
assign 1 99 23
new 0 99 23
assign 1 100 24
new 0 100 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -967672502: return bem_baseNodeGet_0();
case -2131387379: return bem_iteratorGet_0();
case -785231243: return bem_mapIteratorGet_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 781030887: return bem_multiGetDirect_0();
case -1882364243: return bem_many_0();
case 1297175099: return bem_fieldIteratorGet_0();
case 1165329653: return bem_hashGet_0();
case -1164902231: return bem_isEmptyGet_0();
case 1519740625: return bem_innerPutAddedGet_0();
case -1074341902: return bem_print_0();
case -1034411091: return bem_sizeGetDirect_0();
case -1235952586: return bem_keyIteratorGet_0();
case 798593031: return bem_innerPutAddedGetDirect_0();
case -2083934905: return bem_copy_0();
case -1398419675: return bem_multiGet_0();
case 168756811: return bem_relGet_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case -2109059715: return bem_valuesGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case 565117810: return bem_baseNodeGetDirect_0();
case -1138072028: return bem_tagGet_0();
case -619467435: return bem_relGetDirect_0();
case 1209971481: return bem_clear_0();
case -569478669: return bem_setIteratorGet_0();
case 1887352186: return bem_valueIteratorGet_0();
case 573936803: return bem_notEmptyGet_0();
case 80244442: return bem_toString_0();
case -322456328: return bem_sizeGet_0();
case -1127594721: return bem_slotsGetDirect_0();
case -64132803: return bem_nodeIteratorGet_0();
case -559108228: return bem_nodesGet_0();
case -1625648722: return bem_once_0();
case -628560707: return bem_toAny_0();
case -1604175473: return bem_slotsGet_0();
case -2123848647: return bem_fieldNamesGet_0();
case 1014225644: return bem_echo_0();
case 844225351: return bem_classNameGet_0();
case -1903489242: return bem_keysGet_0();
case 1922950621: return bem_keyValueIteratorGet_0();
case 770834928: return bem_serializeContents_0();
case -1194289304: return bem_serializeToString_0();
case -1167288194: return bem_moduGetDirect_0();
case 777919321: return bem_moduGet_0();
case -753894116: return bem_new_0();
case -1253246070: return bem_create_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1153843257: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1117785928: return bem_sizeSetDirect_1(bevd_0);
case -1139182906: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 1899981599: return bem_get_1(bevd_0);
case -706478188: return bem_slotsSetDirect_1(bevd_0);
case -1349992970: return bem_moduSet_1(bevd_0);
case 567942210: return bem_sizeSet_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1151650127: return bem_put_1(bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case -1711649936: return bem_relSet_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case -337498040: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -1219892063: return bem_delete_1(bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case -314005025: return bem_innerPutAddedSetDirect_1(bevd_0);
case 448676954: return bem_slotsSet_1(bevd_0);
case 47615491: return bem_addValue_1(bevd_0);
case -570623763: return bem_relSetDirect_1(bevd_0);
case -1962516194: return bem_baseNodeSet_1(bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case 492612924: return bem_moduSetDirect_1(bevd_0);
case 19258994: return bem_innerPutAddedSet_1(bevd_0);
case 1869433896: return bem_has_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case 33562291: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -264203778: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 322534726: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case 2087479036: return bem_multiSet_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case -181028507: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1638208541: return bem_baseNodeSetDirect_1(bevd_0);
case 181643935: return bem_multiSetDirect_1(bevd_0);
case -636442813: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 234485977: return bem_put_2(bevd_0, bevd_1);
case -1018604002: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1608547899: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentityMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
}
