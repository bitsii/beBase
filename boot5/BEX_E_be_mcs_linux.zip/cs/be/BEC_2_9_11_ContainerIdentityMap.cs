namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap : BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
static BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static new BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {90, 90, 94, 95, 96, 97, 98, 99};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 90 14
new 0 90 14
new 1 90 15
assign 1 94 19
new 1 94 19
assign 1 95 20
assign 1 96 21
new 0 96 21
assign 1 97 22
new 0 97 22
assign 1 98 23
new 0 98 23
assign 1 99 24
new 0 99 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1194804327: return bem_fieldNamesGet_0();
case 1877759012: return bem_slotsGet_0();
case 1251306010: return bem_isEmptyGet_0();
case -1024614239: return bem_relGet_0();
case 22366868: return bem_valuesGet_0();
case 1513233059: return bem_toString_0();
case -1720051500: return bem_nodeIteratorGet_0();
case -61826381: return bem_multiGetDirect_0();
case -687953287: return bem_valueIteratorGet_0();
case 144584723: return bem_create_0();
case -1123278056: return bem_tagGet_0();
case -57165231: return bem_clear_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case 1577195459: return bem_serializationIteratorGet_0();
case -713163994: return bem_toAny_0();
case -1362850090: return bem_serializeContents_0();
case -2051518290: return bem_once_0();
case 242342757: return bem_moduGetDirect_0();
case -449079106: return bem_iteratorGet_0();
case -250255744: return bem_keysGet_0();
case 611670694: return bem_fieldIteratorGet_0();
case 1942283510: return bem_sourceFileNameGet_0();
case -621794161: return bem_notEmptyGet_0();
case 96033137: return bem_serializeToString_0();
case 341575045: return bem_many_0();
case -1085716364: return bem_keyIteratorGet_0();
case 1238433540: return bem_keyValueIteratorGet_0();
case -1023134804: return bem_multiGet_0();
case 1555441174: return bem_relGetDirect_0();
case 992673906: return bem_innerPutAddedGetDirect_0();
case -1266447496: return bem_classNameGet_0();
case 1492125029: return bem_mapIteratorGet_0();
case 1484632917: return bem_setIteratorGet_0();
case -582321708: return bem_baseNodeGetDirect_0();
case 1851908877: return bem_hashGet_0();
case 1926750841: return bem_nodesGet_0();
case -10010145: return bem_copy_0();
case -285200704: return bem_moduGet_0();
case -1411065278: return bem_sizeGetDirect_0();
case 1071461198: return bem_echo_0();
case 990360647: return bem_new_0();
case -1702306638: return bem_slotsGetDirect_0();
case 87976308: return bem_sizeGet_0();
case -753697550: return bem_innerPutAddedGet_0();
case -1086782351: return bem_print_0();
case 488732422: return bem_baseNodeGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 451458083: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -1980040928: return bem_slotsSetDirect_1(bevd_0);
case -1071001840: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 479707204: return bem_has_1(bevd_0);
case 1600658510: return bem_get_1(bevd_0);
case -497162746: return bem_multiSetDirect_1(bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case 1236321762: return bem_delete_1(bevd_0);
case 375073126: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1148170887: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 238519826: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -655019399: return bem_def_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 402418404: return bem_relSet_1(bevd_0);
case -989818108: return bem_addValue_1(bevd_0);
case -103368477: return bem_sizeSetDirect_1(bevd_0);
case 1890586788: return bem_moduSet_1(bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1567241080: return bem_sizeSet_1(bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case 2142393567: return bem_multiSet_1(bevd_0);
case 921788055: return bem_moduSetDirect_1(bevd_0);
case 635614392: return bem_baseNodeSet_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case -850389082: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1644980393: return bem_put_1(bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case -505127479: return bem_baseNodeSetDirect_1(bevd_0);
case -2110835993: return bem_relSetDirect_1(bevd_0);
case 1449340032: return bem_otherClass_1(bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -654327648: return bem_slotsSet_1(bevd_0);
case -626829313: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case 815410900: return bem_innerPutAddedSet_1(bevd_0);
case -1921064140: return bem_innerPutAddedSetDirect_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -468578755: return bem_put_2(bevd_0, bevd_1);
case 792791084: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -336267119: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentityMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
}
