namespace be {
/* IO:File: source/base/Map.be */
public class BEC_2_9_11_ContainerIdentityMap : BEC_2_9_3_ContainerMap {
public BEC_2_9_11_ContainerIdentityMap() { }
static BEC_2_9_11_ContainerIdentityMap() { }
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x49,0x64,0x65,0x6E,0x74,0x69,0x74,0x79,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_11_ContainerIdentityMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static new BEC_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;

public static new BET_2_9_11_ContainerIdentityMap bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_9_3_ContainerSet bem_new_1(BEC_2_4_3_MathInt beva__modu) {
bevp_slots = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_17_ContainerSetIdentityRelations.bece_BEC_3_9_3_17_ContainerSetIdentityRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {91, 91, 95, 96, 97, 98, 99, 100};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 19, 20, 21, 22, 23, 24};
/* BEGIN LINEINFO 
assign 1 91 14
new 0 91 14
new 1 91 15
assign 1 95 19
new 1 95 19
assign 1 96 20
assign 1 97 21
new 0 97 21
assign 1 98 22
new 0 98 22
assign 1 99 23
new 0 99 23
assign 1 100 24
new 0 100 24
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1189966673: return bem_toAny_0();
case 1095191709: return bem_sizeGet_0();
case 462856424: return bem_innerPutAddedGet_0();
case 1045959947: return bem_deserializeClassNameGet_0();
case -212029696: return bem_many_0();
case -1089927200: return bem_baseNodeGet_0();
case 1344341494: return bem_keyIteratorGet_0();
case -1554789119: return bem_iteratorGet_0();
case -1942895200: return bem_nodeIteratorGet_0();
case 1039721337: return bem_fieldIteratorGet_0();
case -177474376: return bem_serializeToString_0();
case 1278413277: return bem_clear_0();
case 1491485620: return bem_slotsGet_0();
case -423405216: return bem_sizeGetDirect_0();
case 266181284: return bem_tagGet_0();
case -1948098255: return bem_classNameGet_0();
case 858307084: return bem_innerPutAddedGetDirect_0();
case 1657059163: return bem_fieldNamesGet_0();
case -1123644296: return bem_setIteratorGet_0();
case -985853461: return bem_notEmptyGet_0();
case 2110316685: return bem_serializeContents_0();
case 1307700692: return bem_slotsGetDirect_0();
case -182692547: return bem_moduGetDirect_0();
case 1329517290: return bem_once_0();
case -174321978: return bem_serializationIteratorGet_0();
case -359696649: return bem_valueIteratorGet_0();
case -1982517647: return bem_keysGet_0();
case -798647698: return bem_multiGetDirect_0();
case 1569781551: return bem_mapIteratorGet_0();
case 254210050: return bem_copy_0();
case -1068965057: return bem_keyValueIteratorGet_0();
case -500058573: return bem_multiGet_0();
case -1934041312: return bem_baseNodeGetDirect_0();
case -1519514970: return bem_print_0();
case -1641539908: return bem_toString_0();
case -1963952686: return bem_hashGet_0();
case -1886421584: return bem_new_0();
case -1841512138: return bem_sourceFileNameGet_0();
case -753040386: return bem_isEmptyGet_0();
case -495454733: return bem_nodesGet_0();
case -1063147421: return bem_create_0();
case -291078438: return bem_moduGet_0();
case -882755564: return bem_valuesGet_0();
case -753700116: return bem_relGet_0();
case -557851017: return bem_relGetDirect_0();
case 900120920: return bem_echo_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1588527748: return bem_sizeSetDirect_1(bevd_0);
case -1038314311: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1751970442: return bem_undef_1(bevd_0);
case -6499220: return bem_baseNodeSetDirect_1(bevd_0);
case -2101355929: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -985468058: return bem_undefined_1(bevd_0);
case 17112028: return bem_sameClass_1(bevd_0);
case -1837267423: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -686021029: return bem_get_1(bevd_0);
case 1733222638: return bem_defined_1(bevd_0);
case -1026877873: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1089018485: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 239759479: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case 1581368506: return bem_otherClass_1(bevd_0);
case 506068861: return bem_equals_1(bevd_0);
case 1688875848: return bem_sameType_1(bevd_0);
case 117805705: return bem_baseNodeSet_1(bevd_0);
case 1380835473: return bem_addValue_1(bevd_0);
case -871693528: return bem_moduSetDirect_1(bevd_0);
case 670434524: return bem_copyTo_1(bevd_0);
case 2113529564: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 1337665439: return bem_otherType_1(bevd_0);
case -228107424: return bem_slotsSet_1(bevd_0);
case -883563951: return bem_multiSetDirect_1(bevd_0);
case 450107248: return bem_has_1(bevd_0);
case -1720441649: return bem_innerPutAddedSet_1(bevd_0);
case 263889716: return bem_relSetDirect_1(bevd_0);
case 729329792: return bem_relSet_1(bevd_0);
case 2030044162: return bem_sizeSet_1(bevd_0);
case -1880059142: return bem_multiSet_1(bevd_0);
case 1794882951: return bem_sameObject_1(bevd_0);
case -1306292496: return bem_slotsSetDirect_1(bevd_0);
case 789094035: return bem_def_1(bevd_0);
case 1815502422: return bem_put_1(bevd_0);
case 1650882780: return bem_innerPutAddedSetDirect_1(bevd_0);
case 1925203550: return bem_moduSet_1(bevd_0);
case 2085694240: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case 911117738: return bem_notEquals_1(bevd_0);
case 921876651: return bem_delete_1(bevd_0);
case -120618989: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1231527728: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1745179387: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -719350484: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1673554568: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1566202298: return bem_put_2(bevd_0, bevd_1);
case 1172756878: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1834730412: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 35608937: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 925887327: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 35788340: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2070718562: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1144551737: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_9_11_ContainerIdentityMap_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_11_ContainerIdentityMap_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_11_ContainerIdentityMap();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst = (BEC_2_9_11_ContainerIdentityMap) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_11_ContainerIdentityMap.bece_BEC_2_9_11_ContainerIdentityMap_bevs_type;
}
}
}
