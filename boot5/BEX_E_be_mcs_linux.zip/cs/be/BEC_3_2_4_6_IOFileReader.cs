namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public class BEC_3_2_4_6_IOFileReader : BEC_2_2_6_IOReader {
public BEC_3_2_4_6_IOFileReader() { }
static BEC_3_2_4_6_IOFileReader() { }
private static byte[] becc_BEC_3_2_4_6_IOFileReader_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x52,0x65,0x61,0x64,0x65,0x72};
private static byte[] becc_BEC_3_2_4_6_IOFileReader_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_2_4_6_IOFileReader_bels_0 = {0x46,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileReader_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileReader_bels_0, 5));
private static byte[] bece_BEC_3_2_4_6_IOFileReader_bels_1 = {0x20,0x63,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x6F,0x70,0x65,0x6E,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x72,0x65,0x61,0x64,0x2E};
private static BEC_2_4_6_TextString bece_BEC_3_2_4_6_IOFileReader_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_2_4_6_IOFileReader_bels_1, 30));
public static new BEC_3_2_4_6_IOFileReader bece_BEC_3_2_4_6_IOFileReader_bevs_inst;

public static new BET_3_2_4_6_IOFileReader bece_BEC_3_2_4_6_IOFileReader_bevs_type;

public BEC_3_2_4_4_IOFilePath bevp_path;
public virtual BEC_3_2_4_6_IOFileReader bem_new_1(BEC_2_6_6_SystemObject beva_fpath) {
BEC_3_2_4_4_IOFilePath bevt_0_tmpany_phold = null;
bem_new_0();
bevp_blockSize = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1024));
bevt_0_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1((BEC_2_4_6_TextString) beva_fpath );
bem_pathSet_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileReader bem_open_0() {
BEC_2_4_6_TextString bevl_fhpatha = null;
BEC_2_5_4_LogicBool bevl__isClosed = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevl_fhpatha = bevp_path.bem_toString_0();

      if (this.bevi_is == null) {
        string bevls_spath = System.Text.Encoding.UTF8.GetString(bevp_path.bevp_path.bevi_bytes, 0, bevp_path.bevp_path.bevp_size.bevi_int);
        this.bevi_is = new FileStream(bevls_spath, FileMode.Open);
      }
      bevp_isClosed = be.BECS_Runtime.boolFalse;
      if (bevp_isClosed == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
if (bevp_isClosed.bevi_bool) /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 137 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 137 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 137 */ {
bevt_5_tmpany_phold = bece_BEC_3_2_4_6_IOFileReader_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_fhpatha);
bevt_6_tmpany_phold = bece_BEC_3_2_4_6_IOFileReader_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_3_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_2_tmpany_phold);
} /* Line: 138 */
return this;
} /*method end*/
public virtual BEC_3_2_4_4_IOFilePath bem_pathGet_0() {
return bevp_path;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_pathGetDirect_0() {
return bevp_path;
} /*method end*/
public virtual BEC_3_2_4_6_IOFileReader bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileReader bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_path = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {64, 65, 69, 69, 84, 137, 137, 0, 0, 0, 138, 138, 138, 138, 138, 138, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 38, 45, 50, 51, 55, 58, 62, 63, 64, 65, 66, 67, 72, 75, 78, 82};
/* BEGIN LINEINFO 
new 0 64 22
assign 1 65 23
new 0 65 23
assign 1 69 24
new 1 69 24
pathSet 1 69 25
assign 1 84 38
toString 0 84 38
assign 1 137 45
undef 1 137 50
assign 1 0 51
assign 1 0 55
assign 1 0 58
assign 1 138 62
new 0 138 62
assign 1 138 63
add 1 138 63
assign 1 138 64
new 0 138 64
assign 1 138 65
add 1 138 65
assign 1 138 66
new 1 138 66
throw 1 138 67
return 1 0 72
return 1 0 75
assign 1 0 78
assign 1 0 82
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -165625945: return bem_pathGetDirect_0();
case -976337999: return bem_readStringClose_0();
case -1894400140: return bem_vfileGet_0();
case -1074341902: return bem_print_0();
case 1814874037: return bem_vfileGetDirect_0();
case 314240746: return bem_byteReaderGet_0();
case 80244442: return bem_toString_0();
case -1194289304: return bem_serializeToString_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 1014225644: return bem_echo_0();
case -1882364243: return bem_many_0();
case -628560707: return bem_toAny_0();
case 125261444: return bem_isClosedGetDirect_0();
case -753894116: return bem_new_0();
case -2123848647: return bem_fieldNamesGet_0();
case -1138072028: return bem_tagGet_0();
case -227497789: return bem_extOpen_0();
case -1635021304: return bem_pathGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -874569202: return bem_readBuffer_0();
case -2131387379: return bem_iteratorGet_0();
case 844225351: return bem_classNameGet_0();
case 551004241: return bem_blockSizeGet_0();
case 958448888: return bem_readString_0();
case 1297175099: return bem_fieldIteratorGet_0();
case -103166746: return bem_open_0();
case 107194370: return bem_readBufferLine_0();
case -1625648722: return bem_once_0();
case 671700618: return bem_isClosedGet_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 770834928: return bem_serializeContents_0();
case -1253246070: return bem_create_0();
case -2083934905: return bem_copy_0();
case 1856301037: return bem_blockSizeGetDirect_0();
case 1165329653: return bem_hashGet_0();
case -1592861100: return bem_close_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 91485939: return bem_vfileSet_1(bevd_0);
case -1888547132: return bem_byteReader_1((BEC_2_4_3_MathInt) bevd_0);
case 1368940703: return bem_readBufferLine_1((BEC_2_4_6_TextString) bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case 58720577: return bem_copyData_1((BEC_2_2_6_IOWriter) bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case 1168485697: return bem_readBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case 1161211726: return bem_readString_1((BEC_2_4_6_TextString) bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case -1532696431: return bem_readIntoBuffer_1((BEC_2_4_6_TextString) bevd_0);
case -433994667: return bem_isClosedSetDirect_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case 1765093907: return bem_blockSizeSetDirect_1(bevd_0);
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case 322534726: return bem_new_1(bevd_0);
case -1059877213: return bem_pathSetDirect_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case 542901142: return bem_pathSet_1(bevd_0);
case 716258883: return bem_isClosedSet_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -490559136: return bem_vfileSetDirect_1(bevd_0);
case -1583975165: return bem_blockSizeSet_1(bevd_0);
case -636442813: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1939366950: return bem_readIntoBuffer_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1129874615: return bem_readIntoBuffer_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1085068052: return bem_copyData_3((BEC_2_2_6_IOWriter) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_3_2_4_6_IOFileReader_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_3_2_4_6_IOFileReader_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_2_4_6_IOFileReader();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_2_4_6_IOFileReader.bece_BEC_3_2_4_6_IOFileReader_bevs_inst = (BEC_3_2_4_6_IOFileReader) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_2_4_6_IOFileReader.bece_BEC_3_2_4_6_IOFileReader_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_2_4_6_IOFileReader.bece_BEC_3_2_4_6_IOFileReader_bevs_type;
}
}
}
