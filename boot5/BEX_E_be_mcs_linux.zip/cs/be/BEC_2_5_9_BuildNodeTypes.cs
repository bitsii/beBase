namespace be {
/* IO:File: source/build/NodeTypes.be */
public sealed class BEC_2_5_9_BuildNodeTypes : BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildNodeTypes() { }
static BEC_2_5_9_BuildNodeTypes() { }
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;

public static new BET_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_TRANSUNIT;
public BEC_2_4_3_MathInt bevp_VAR;
public BEC_2_4_3_MathInt bevp_NULL;
public BEC_2_4_3_MathInt bevp_CALL;
public BEC_2_4_3_MathInt bevp_NAMEPATH;
public BEC_2_4_3_MathInt bevp_CLASS;
public BEC_2_4_3_MathInt bevp_EMIT;
public BEC_2_4_3_MathInt bevp_IFEMIT;
public BEC_2_4_3_MathInt bevp_TRUE;
public BEC_2_4_3_MathInt bevp_FALSE;
public BEC_2_4_3_MathInt bevp_BRACES;
public BEC_2_4_3_MathInt bevp_RBRACES;
public BEC_2_4_3_MathInt bevp_RPARENS;
public BEC_2_4_3_MathInt bevp_LOOP;
public BEC_2_4_3_MathInt bevp_PROPERTIES;
public BEC_2_4_3_MathInt bevp_ELSE;
public BEC_2_4_3_MathInt bevp_FINALLY;
public BEC_2_4_3_MathInt bevp_TRY;
public BEC_2_4_3_MathInt bevp_CATCH;
public BEC_2_4_3_MathInt bevp_IF;
public BEC_2_4_3_MathInt bevp_SPACE;
public BEC_2_4_3_MathInt bevp_METHOD;
public BEC_2_4_3_MathInt bevp_DEFMOD;
public BEC_2_4_3_MathInt bevp_PARENS;
public BEC_2_4_3_MathInt bevp_FLOATL;
public BEC_2_4_3_MathInt bevp_INTL;
public BEC_2_4_3_MathInt bevp_DIVIDE;
public BEC_2_4_3_MathInt bevp_DIVIDE_ASSIGN;
public BEC_2_4_3_MathInt bevp_MULTIPLY;
public BEC_2_4_3_MathInt bevp_MULTIPLY_ASSIGN;
public BEC_2_4_3_MathInt bevp_STRQ;
public BEC_2_4_3_MathInt bevp_WSTRQ;
public BEC_2_4_3_MathInt bevp_STRINGL;
public BEC_2_4_3_MathInt bevp_WSTRINGL;
public BEC_2_4_3_MathInt bevp_NEWLINE;
public BEC_2_4_3_MathInt bevp_ASSIGN;
public BEC_2_4_3_MathInt bevp_EQUALS;
public BEC_2_4_3_MathInt bevp_NOT;
public BEC_2_4_3_MathInt bevp_NOT_EQUALS;
public BEC_2_4_3_MathInt bevp_OR;
public BEC_2_4_3_MathInt bevp_AND;
public BEC_2_4_3_MathInt bevp_OR_ASSIGN;
public BEC_2_4_3_MathInt bevp_AND_ASSIGN;
public BEC_2_4_3_MathInt bevp_LOGICAL_OR;
public BEC_2_4_3_MathInt bevp_LOGICAL_AND;
public BEC_2_4_3_MathInt bevp_GREATER;
public BEC_2_4_3_MathInt bevp_GREATER_EQUALS;
public BEC_2_4_3_MathInt bevp_LESSER;
public BEC_2_4_3_MathInt bevp_LESSER_EQUALS;
public BEC_2_4_3_MathInt bevp_ADD;
public BEC_2_4_3_MathInt bevp_INCREMENT;
public BEC_2_4_3_MathInt bevp_ADD_ASSIGN;
public BEC_2_4_3_MathInt bevp_INCREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_SUBTRACT;
public BEC_2_4_3_MathInt bevp_DECREMENT;
public BEC_2_4_3_MathInt bevp_SUBTRACT_ASSIGN;
public BEC_2_4_3_MathInt bevp_DECREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_ID;
public BEC_2_4_3_MathInt bevp_COLON;
public BEC_2_4_3_MathInt bevp_WHILE;
public BEC_2_4_3_MathInt bevp_FOREACH;
public BEC_2_4_3_MathInt bevp_BLOCK;
public BEC_2_4_3_MathInt bevp_USE;
public BEC_2_4_3_MathInt bevp_AS;
public BEC_2_4_3_MathInt bevp_SEMI;
public BEC_2_4_3_MathInt bevp_EXPR;
public BEC_2_4_3_MathInt bevp_COMMA;
public BEC_2_4_3_MathInt bevp_ACCESSOR;
public BEC_2_4_3_MathInt bevp_DOT;
public BEC_2_4_3_MathInt bevp_BREAK;
public BEC_2_4_3_MathInt bevp_IDX;
public BEC_2_4_3_MathInt bevp_IDXACC;
public BEC_2_4_3_MathInt bevp_RIDX;
public BEC_2_4_3_MathInt bevp_TOKEN;
public BEC_2_4_3_MathInt bevp_MODULUS;
public BEC_2_4_3_MathInt bevp_MODULUS_ASSIGN;
public BEC_2_4_3_MathInt bevp_ELIF;
public BEC_2_4_3_MathInt bevp_FOR;
public BEC_2_4_3_MathInt bevp_IN;
public BEC_2_4_3_MathInt bevp_CONTINUE;
public BEC_2_4_3_MathInt bevp_ATYPE;
public BEC_2_4_3_MathInt bevp_FSLASH;
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_default_0() {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevp_VAR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevp_NULL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(3));
bevp_CALL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevp_NAMEPATH = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(5));
bevp_CLASS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(6));
bevp_EMIT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(8));
bevp_IFEMIT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(9));
bevp_TRUE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevp_FALSE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(11));
bevp_BRACES = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(12));
bevp_RBRACES = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(13));
bevp_RPARENS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(14));
bevp_LOOP = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(15));
bevp_PROPERTIES = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(23));
bevp_ELSE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevp_FINALLY = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(93));
bevp_TRY = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(17));
bevp_CATCH = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(18));
bevp_IF = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(19));
bevp_SPACE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(20));
bevp_METHOD = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(21));
bevp_DEFMOD = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(74));
bevp_PARENS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(22));
bevp_FLOATL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(25));
bevp_INTL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(26));
bevp_DIVIDE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(27));
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(86));
bevp_MULTIPLY = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(28));
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(87));
bevp_STRQ = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(29));
bevp_WSTRQ = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(30));
bevp_STRINGL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(31));
bevp_WSTRINGL = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(33));
bevp_NEWLINE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(32));
bevp_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(35));
bevp_EQUALS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(36));
bevp_NOT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(37));
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(38));
bevp_OR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(39));
bevp_AND = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(40));
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(92));
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(91));
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(89));
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(90));
bevp_GREATER = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(41));
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(42));
bevp_LESSER = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(43));
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(44));
bevp_ADD = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(45));
bevp_INCREMENT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(46));
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(84));
bevp_SUBTRACT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevp_DECREMENT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(49));
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(83));
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(85));
bevp_ID = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(50));
bevp_COLON = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(51));
bevp_WHILE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(52));
bevp_FOREACH = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(53));
bevp_BLOCK = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(72));
bevp_USE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(54));
bevp_AS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevp_SEMI = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(56));
bevp_EXPR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(57));
bevp_COMMA = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
bevp_ACCESSOR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(59));
bevp_DOT = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(60));
bevp_BREAK = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(61));
bevp_IDX = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(62));
bevp_IDXACC = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(73));
bevp_RIDX = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(63));
bevp_TOKEN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
bevp_MODULUS = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(88));
bevp_ELIF = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(66));
bevp_FOR = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(67));
bevp_IN = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(68));
bevp_CONTINUE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(69));
bevp_ATYPE = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(71));
bevp_FSLASH = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(80));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRANSUNITGet_0() {
return bevp_TRANSUNIT;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRANSUNITGetDirect_0() {
return bevp_TRANSUNIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_VARGet_0() {
return bevp_VAR;
} /*method end*/
public BEC_2_4_3_MathInt bem_VARGetDirect_0() {
return bevp_VAR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_VARSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_VARSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NULLGet_0() {
return bevp_NULL;
} /*method end*/
public BEC_2_4_3_MathInt bem_NULLGetDirect_0() {
return bevp_NULL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NULLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NULLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CALLGet_0() {
return bevp_CALL;
} /*method end*/
public BEC_2_4_3_MathInt bem_CALLGetDirect_0() {
return bevp_CALL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CALLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CALLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NAMEPATHGet_0() {
return bevp_NAMEPATH;
} /*method end*/
public BEC_2_4_3_MathInt bem_NAMEPATHGetDirect_0() {
return bevp_NAMEPATH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CLASSGet_0() {
return bevp_CLASS;
} /*method end*/
public BEC_2_4_3_MathInt bem_CLASSGetDirect_0() {
return bevp_CLASS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CLASSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CLASSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EMITGet_0() {
return bevp_EMIT;
} /*method end*/
public BEC_2_4_3_MathInt bem_EMITGetDirect_0() {
return bevp_EMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EMITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFEMITGet_0() {
return bevp_IFEMIT;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFEMITGetDirect_0() {
return bevp_IFEMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFEMITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFEMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRUEGet_0() {
return bevp_TRUE;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRUEGetDirect_0() {
return bevp_TRUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRUESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FALSEGet_0() {
return bevp_FALSE;
} /*method end*/
public BEC_2_4_3_MathInt bem_FALSEGetDirect_0() {
return bevp_FALSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FALSESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FALSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BRACESGet_0() {
return bevp_BRACES;
} /*method end*/
public BEC_2_4_3_MathInt bem_BRACESGetDirect_0() {
return bevp_BRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BRACESSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RBRACESGet_0() {
return bevp_RBRACES;
} /*method end*/
public BEC_2_4_3_MathInt bem_RBRACESGetDirect_0() {
return bevp_RBRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RBRACESSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RBRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RPARENSGet_0() {
return bevp_RPARENS;
} /*method end*/
public BEC_2_4_3_MathInt bem_RPARENSGetDirect_0() {
return bevp_RPARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RPARENSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RPARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOOPGet_0() {
return bevp_LOOP;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOOPGetDirect_0() {
return bevp_LOOP;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOOPSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOOPSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PROPERTIESGet_0() {
return bevp_PROPERTIES;
} /*method end*/
public BEC_2_4_3_MathInt bem_PROPERTIESGetDirect_0() {
return bevp_PROPERTIES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PROPERTIESSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_PROPERTIES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PROPERTIESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_PROPERTIES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELSEGet_0() {
return bevp_ELSE;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELSEGetDirect_0() {
return bevp_ELSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELSESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FINALLYGet_0() {
return bevp_FINALLY;
} /*method end*/
public BEC_2_4_3_MathInt bem_FINALLYGetDirect_0() {
return bevp_FINALLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FINALLYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FINALLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRYGet_0() {
return bevp_TRY;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRYGetDirect_0() {
return bevp_TRY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CATCHGet_0() {
return bevp_CATCH;
} /*method end*/
public BEC_2_4_3_MathInt bem_CATCHGetDirect_0() {
return bevp_CATCH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CATCHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CATCHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFGet_0() {
return bevp_IF;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFGetDirect_0() {
return bevp_IF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SPACEGet_0() {
return bevp_SPACE;
} /*method end*/
public BEC_2_4_3_MathInt bem_SPACEGetDirect_0() {
return bevp_SPACE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SPACESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SPACESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_METHODGet_0() {
return bevp_METHOD;
} /*method end*/
public BEC_2_4_3_MathInt bem_METHODGetDirect_0() {
return bevp_METHOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_METHODSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_METHODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DEFMODGet_0() {
return bevp_DEFMOD;
} /*method end*/
public BEC_2_4_3_MathInt bem_DEFMODGetDirect_0() {
return bevp_DEFMOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DEFMODSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DEFMODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PARENSGet_0() {
return bevp_PARENS;
} /*method end*/
public BEC_2_4_3_MathInt bem_PARENSGetDirect_0() {
return bevp_PARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PARENSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FLOATLGet_0() {
return bevp_FLOATL;
} /*method end*/
public BEC_2_4_3_MathInt bem_FLOATLGetDirect_0() {
return bevp_FLOATL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FLOATLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FLOATLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INTLGet_0() {
return bevp_INTL;
} /*method end*/
public BEC_2_4_3_MathInt bem_INTLGetDirect_0() {
return bevp_INTL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INTLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INTLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDEGet_0() {
return bevp_DIVIDE;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDEGetDirect_0() {
return bevp_DIVIDE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGet_0() {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGetDirect_0() {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLYGet_0() {
return bevp_MULTIPLY;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLYGetDirect_0() {
return bevp_MULTIPLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGet_0() {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGetDirect_0() {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRQGet_0() {
return bevp_STRQ;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRQGetDirect_0() {
return bevp_STRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRQSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRQGet_0() {
return bevp_WSTRQ;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRQGetDirect_0() {
return bevp_WSTRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRQSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRINGLGet_0() {
return bevp_STRINGL;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRINGLGetDirect_0() {
return bevp_STRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRINGLGet_0() {
return bevp_WSTRINGL;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRINGLGetDirect_0() {
return bevp_WSTRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NEWLINEGet_0() {
return bevp_NEWLINE;
} /*method end*/
public BEC_2_4_3_MathInt bem_NEWLINEGetDirect_0() {
return bevp_NEWLINE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NEWLINESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NEWLINESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASSIGNGet_0() {
return bevp_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASSIGNGetDirect_0() {
return bevp_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EQUALSGet_0() {
return bevp_EQUALS;
} /*method end*/
public BEC_2_4_3_MathInt bem_EQUALSGetDirect_0() {
return bevp_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOTGet_0() {
return bevp_NOT;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOTGetDirect_0() {
return bevp_NOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOT_EQUALSGet_0() {
return bevp_NOT_EQUALS;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOT_EQUALSGetDirect_0() {
return bevp_NOT_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ORGet_0() {
return bevp_OR;
} /*method end*/
public BEC_2_4_3_MathInt bem_ORGetDirect_0() {
return bevp_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ANDGet_0() {
return bevp_AND;
} /*method end*/
public BEC_2_4_3_MathInt bem_ANDGetDirect_0() {
return bevp_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_OR_ASSIGNGet_0() {
return bevp_OR_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_OR_ASSIGNGetDirect_0() {
return bevp_OR_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_AND_ASSIGNGet_0() {
return bevp_AND_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_AND_ASSIGNGetDirect_0() {
return bevp_AND_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ORGet_0() {
return bevp_LOGICAL_OR;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ORGetDirect_0() {
return bevp_LOGICAL_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ANDGet_0() {
return bevp_LOGICAL_AND;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ANDGetDirect_0() {
return bevp_LOGICAL_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATERGet_0() {
return bevp_GREATER;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATERGetDirect_0() {
return bevp_GREATER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATERSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATER_EQUALSGet_0() {
return bevp_GREATER_EQUALS;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATER_EQUALSGetDirect_0() {
return bevp_GREATER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSERGet_0() {
return bevp_LESSER;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSERGetDirect_0() {
return bevp_LESSER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSERSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSER_EQUALSGet_0() {
return bevp_LESSER_EQUALS;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSER_EQUALSGetDirect_0() {
return bevp_LESSER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADDGet_0() {
return bevp_ADD;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADDGetDirect_0() {
return bevp_ADD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENTGet_0() {
return bevp_INCREMENT;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENTGetDirect_0() {
return bevp_INCREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADD_ASSIGNGet_0() {
return bevp_ADD_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADD_ASSIGNGetDirect_0() {
return bevp_ADD_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGet_0() {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGetDirect_0() {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACTGet_0() {
return bevp_SUBTRACT;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACTGetDirect_0() {
return bevp_SUBTRACT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENTGet_0() {
return bevp_DECREMENT;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENTGetDirect_0() {
return bevp_DECREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGet_0() {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGetDirect_0() {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGet_0() {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGetDirect_0() {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDGet_0() {
return bevp_ID;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDGetDirect_0() {
return bevp_ID;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COLONGet_0() {
return bevp_COLON;
} /*method end*/
public BEC_2_4_3_MathInt bem_COLONGetDirect_0() {
return bevp_COLON;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COLONSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COLONSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WHILEGet_0() {
return bevp_WHILE;
} /*method end*/
public BEC_2_4_3_MathInt bem_WHILEGetDirect_0() {
return bevp_WHILE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WHILESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WHILESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FOREACHGet_0() {
return bevp_FOREACH;
} /*method end*/
public BEC_2_4_3_MathInt bem_FOREACHGetDirect_0() {
return bevp_FOREACH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FOREACHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FOREACHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BLOCKGet_0() {
return bevp_BLOCK;
} /*method end*/
public BEC_2_4_3_MathInt bem_BLOCKGetDirect_0() {
return bevp_BLOCK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BLOCKSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BLOCKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_USEGet_0() {
return bevp_USE;
} /*method end*/
public BEC_2_4_3_MathInt bem_USEGetDirect_0() {
return bevp_USE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_USESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_USESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASGet_0() {
return bevp_AS;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASGetDirect_0() {
return bevp_AS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SEMIGet_0() {
return bevp_SEMI;
} /*method end*/
public BEC_2_4_3_MathInt bem_SEMIGetDirect_0() {
return bevp_SEMI;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SEMISet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SEMISetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EXPRGet_0() {
return bevp_EXPR;
} /*method end*/
public BEC_2_4_3_MathInt bem_EXPRGetDirect_0() {
return bevp_EXPR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EXPRSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EXPRSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COMMAGet_0() {
return bevp_COMMA;
} /*method end*/
public BEC_2_4_3_MathInt bem_COMMAGetDirect_0() {
return bevp_COMMA;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COMMASet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COMMASetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ACCESSORGet_0() {
return bevp_ACCESSOR;
} /*method end*/
public BEC_2_4_3_MathInt bem_ACCESSORGetDirect_0() {
return bevp_ACCESSOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ACCESSORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ACCESSORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DOTGet_0() {
return bevp_DOT;
} /*method end*/
public BEC_2_4_3_MathInt bem_DOTGetDirect_0() {
return bevp_DOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DOTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BREAKGet_0() {
return bevp_BREAK;
} /*method end*/
public BEC_2_4_3_MathInt bem_BREAKGetDirect_0() {
return bevp_BREAK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BREAKSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BREAKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXGet_0() {
return bevp_IDX;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXGetDirect_0() {
return bevp_IDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXACCGet_0() {
return bevp_IDXACC;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXACCGetDirect_0() {
return bevp_IDXACC;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXACCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXACCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RIDXGet_0() {
return bevp_RIDX;
} /*method end*/
public BEC_2_4_3_MathInt bem_RIDXGetDirect_0() {
return bevp_RIDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RIDXSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RIDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TOKENGet_0() {
return bevp_TOKEN;
} /*method end*/
public BEC_2_4_3_MathInt bem_TOKENGetDirect_0() {
return bevp_TOKEN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TOKENSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TOKENSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUSGet_0() {
return bevp_MODULUS;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUSGetDirect_0() {
return bevp_MODULUS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGet_0() {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGetDirect_0() {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELIFGet_0() {
return bevp_ELIF;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELIFGetDirect_0() {
return bevp_ELIF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELIFSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELIFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FORGet_0() {
return bevp_FOR;
} /*method end*/
public BEC_2_4_3_MathInt bem_FORGetDirect_0() {
return bevp_FOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INGet_0() {
return bevp_IN;
} /*method end*/
public BEC_2_4_3_MathInt bem_INGetDirect_0() {
return bevp_IN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CONTINUEGet_0() {
return bevp_CONTINUE;
} /*method end*/
public BEC_2_4_3_MathInt bem_CONTINUEGetDirect_0() {
return bevp_CONTINUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CONTINUESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CONTINUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ATYPEGet_0() {
return bevp_ATYPE;
} /*method end*/
public BEC_2_4_3_MathInt bem_ATYPEGetDirect_0() {
return bevp_ATYPE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ATYPESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ATYPESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FSLASHGet_0() {
return bevp_FSLASH;
} /*method end*/
public BEC_2_4_3_MathInt bem_FSLASHGetDirect_0() {
return bevp_FSLASH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FSLASHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FSLASHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 183, 186, 189, 193, 197, 200, 203, 207, 211, 214, 217, 221, 225, 228, 231, 235, 239, 242, 245, 249, 253, 256, 259, 263, 267, 270, 273, 277, 281, 284, 287, 291, 295, 298, 301, 305, 309, 312, 315, 319, 323, 326, 329, 333, 337, 340, 343, 347, 351, 354, 357, 361, 365, 368, 371, 375, 379, 382, 385, 389, 393, 396, 399, 403, 407, 410, 413, 417, 421, 424, 427, 431, 435, 438, 441, 445, 449, 452, 455, 459, 463, 466, 469, 473, 477, 480, 483, 487, 491, 494, 497, 501, 505, 508, 511, 515, 519, 522, 525, 529, 533, 536, 539, 543, 547, 550, 553, 557, 561, 564, 567, 571, 575, 578, 581, 585, 589, 592, 595, 599, 603, 606, 609, 613, 617, 620, 623, 627, 631, 634, 637, 641, 645, 648, 651, 655, 659, 662, 665, 669, 673, 676, 679, 683, 687, 690, 693, 697, 701, 704, 707, 711, 715, 718, 721, 725, 729, 732, 735, 739, 743, 746, 749, 753, 757, 760, 763, 767, 771, 774, 777, 781, 785, 788, 791, 795, 799, 802, 805, 809, 813, 816, 819, 823, 827, 830, 833, 837, 841, 844, 847, 851, 855, 858, 861, 865, 869, 872, 875, 879, 883, 886, 889, 893, 897, 900, 903, 907, 911, 914, 917, 921, 925, 928, 931, 935, 939, 942, 945, 949, 953, 956, 959, 963, 967, 970, 973, 977, 981, 984, 987, 991, 995, 998, 1001, 1005, 1009, 1012, 1015, 1019, 1023, 1026, 1029, 1033, 1037, 1040, 1043, 1047, 1051, 1054, 1057, 1061, 1065, 1068, 1071, 1075, 1079, 1082, 1085, 1089, 1093, 1096, 1099, 1103, 1107, 1110, 1113, 1117, 1121, 1124, 1127, 1131, 1135, 1138, 1141, 1145, 1149, 1152, 1155, 1159, 1163, 1166, 1169, 1173, 1177, 1180, 1183, 1187, 1191, 1194, 1197, 1201, 1205, 1208, 1211, 1215, 1219, 1222, 1225, 1229, 1233, 1236, 1239, 1243, 1247, 1250, 1253, 1257, 1261, 1264, 1267, 1271, 1275, 1278, 1281, 1285, 1289, 1292, 1295, 1299, 1303, 1306, 1309, 1313, 1317, 1320, 1323, 1327};
/* BEGIN LINEINFO 
assign 1 12 98
new 0 12 98
assign 1 13 99
new 0 13 99
assign 1 14 100
new 0 14 100
assign 1 15 101
new 0 15 101
assign 1 16 102
new 0 16 102
assign 1 17 103
new 0 17 103
assign 1 18 104
new 0 18 104
assign 1 19 105
new 0 19 105
assign 1 20 106
new 0 20 106
assign 1 21 107
new 0 21 107
assign 1 22 108
new 0 22 108
assign 1 23 109
new 0 23 109
assign 1 24 110
new 0 24 110
assign 1 25 111
new 0 25 111
assign 1 26 112
new 0 26 112
assign 1 27 113
new 0 27 113
assign 1 28 114
new 0 28 114
assign 1 29 115
new 0 29 115
assign 1 30 116
new 0 30 116
assign 1 31 117
new 0 31 117
assign 1 32 118
new 0 32 118
assign 1 33 119
new 0 33 119
assign 1 34 120
new 0 34 120
assign 1 35 121
new 0 35 121
assign 1 36 122
new 0 36 122
assign 1 37 123
new 0 37 123
assign 1 38 124
new 0 38 124
assign 1 39 125
new 0 39 125
assign 1 40 126
new 0 40 126
assign 1 41 127
new 0 41 127
assign 1 42 128
new 0 42 128
assign 1 43 129
new 0 43 129
assign 1 44 130
new 0 44 130
assign 1 45 131
new 0 45 131
assign 1 46 132
new 0 46 132
assign 1 47 133
new 0 47 133
assign 1 48 134
new 0 48 134
assign 1 49 135
new 0 49 135
assign 1 50 136
new 0 50 136
assign 1 51 137
new 0 51 137
assign 1 52 138
new 0 52 138
assign 1 53 139
new 0 53 139
assign 1 54 140
new 0 54 140
assign 1 55 141
new 0 55 141
assign 1 56 142
new 0 56 142
assign 1 57 143
new 0 57 143
assign 1 58 144
new 0 58 144
assign 1 59 145
new 0 59 145
assign 1 60 146
new 0 60 146
assign 1 61 147
new 0 61 147
assign 1 62 148
new 0 62 148
assign 1 63 149
new 0 63 149
assign 1 64 150
new 0 64 150
assign 1 65 151
new 0 65 151
assign 1 66 152
new 0 66 152
assign 1 67 153
new 0 67 153
assign 1 68 154
new 0 68 154
assign 1 69 155
new 0 69 155
assign 1 70 156
new 0 70 156
assign 1 71 157
new 0 71 157
assign 1 72 158
new 0 72 158
assign 1 73 159
new 0 73 159
assign 1 74 160
new 0 74 160
assign 1 75 161
new 0 75 161
assign 1 76 162
new 0 76 162
assign 1 77 163
new 0 77 163
assign 1 78 164
new 0 78 164
assign 1 79 165
new 0 79 165
assign 1 80 166
new 0 80 166
assign 1 81 167
new 0 81 167
assign 1 82 168
new 0 82 168
assign 1 83 169
new 0 83 169
assign 1 84 170
new 0 84 170
assign 1 85 171
new 0 85 171
assign 1 86 172
new 0 86 172
assign 1 87 173
new 0 87 173
assign 1 88 174
new 0 88 174
assign 1 89 175
new 0 89 175
assign 1 90 176
new 0 90 176
assign 1 91 177
new 0 91 177
assign 1 92 178
new 0 92 178
assign 1 93 179
new 0 93 179
return 1 0 183
return 1 0 186
assign 1 0 189
assign 1 0 193
return 1 0 197
return 1 0 200
assign 1 0 203
assign 1 0 207
return 1 0 211
return 1 0 214
assign 1 0 217
assign 1 0 221
return 1 0 225
return 1 0 228
assign 1 0 231
assign 1 0 235
return 1 0 239
return 1 0 242
assign 1 0 245
assign 1 0 249
return 1 0 253
return 1 0 256
assign 1 0 259
assign 1 0 263
return 1 0 267
return 1 0 270
assign 1 0 273
assign 1 0 277
return 1 0 281
return 1 0 284
assign 1 0 287
assign 1 0 291
return 1 0 295
return 1 0 298
assign 1 0 301
assign 1 0 305
return 1 0 309
return 1 0 312
assign 1 0 315
assign 1 0 319
return 1 0 323
return 1 0 326
assign 1 0 329
assign 1 0 333
return 1 0 337
return 1 0 340
assign 1 0 343
assign 1 0 347
return 1 0 351
return 1 0 354
assign 1 0 357
assign 1 0 361
return 1 0 365
return 1 0 368
assign 1 0 371
assign 1 0 375
return 1 0 379
return 1 0 382
assign 1 0 385
assign 1 0 389
return 1 0 393
return 1 0 396
assign 1 0 399
assign 1 0 403
return 1 0 407
return 1 0 410
assign 1 0 413
assign 1 0 417
return 1 0 421
return 1 0 424
assign 1 0 427
assign 1 0 431
return 1 0 435
return 1 0 438
assign 1 0 441
assign 1 0 445
return 1 0 449
return 1 0 452
assign 1 0 455
assign 1 0 459
return 1 0 463
return 1 0 466
assign 1 0 469
assign 1 0 473
return 1 0 477
return 1 0 480
assign 1 0 483
assign 1 0 487
return 1 0 491
return 1 0 494
assign 1 0 497
assign 1 0 501
return 1 0 505
return 1 0 508
assign 1 0 511
assign 1 0 515
return 1 0 519
return 1 0 522
assign 1 0 525
assign 1 0 529
return 1 0 533
return 1 0 536
assign 1 0 539
assign 1 0 543
return 1 0 547
return 1 0 550
assign 1 0 553
assign 1 0 557
return 1 0 561
return 1 0 564
assign 1 0 567
assign 1 0 571
return 1 0 575
return 1 0 578
assign 1 0 581
assign 1 0 585
return 1 0 589
return 1 0 592
assign 1 0 595
assign 1 0 599
return 1 0 603
return 1 0 606
assign 1 0 609
assign 1 0 613
return 1 0 617
return 1 0 620
assign 1 0 623
assign 1 0 627
return 1 0 631
return 1 0 634
assign 1 0 637
assign 1 0 641
return 1 0 645
return 1 0 648
assign 1 0 651
assign 1 0 655
return 1 0 659
return 1 0 662
assign 1 0 665
assign 1 0 669
return 1 0 673
return 1 0 676
assign 1 0 679
assign 1 0 683
return 1 0 687
return 1 0 690
assign 1 0 693
assign 1 0 697
return 1 0 701
return 1 0 704
assign 1 0 707
assign 1 0 711
return 1 0 715
return 1 0 718
assign 1 0 721
assign 1 0 725
return 1 0 729
return 1 0 732
assign 1 0 735
assign 1 0 739
return 1 0 743
return 1 0 746
assign 1 0 749
assign 1 0 753
return 1 0 757
return 1 0 760
assign 1 0 763
assign 1 0 767
return 1 0 771
return 1 0 774
assign 1 0 777
assign 1 0 781
return 1 0 785
return 1 0 788
assign 1 0 791
assign 1 0 795
return 1 0 799
return 1 0 802
assign 1 0 805
assign 1 0 809
return 1 0 813
return 1 0 816
assign 1 0 819
assign 1 0 823
return 1 0 827
return 1 0 830
assign 1 0 833
assign 1 0 837
return 1 0 841
return 1 0 844
assign 1 0 847
assign 1 0 851
return 1 0 855
return 1 0 858
assign 1 0 861
assign 1 0 865
return 1 0 869
return 1 0 872
assign 1 0 875
assign 1 0 879
return 1 0 883
return 1 0 886
assign 1 0 889
assign 1 0 893
return 1 0 897
return 1 0 900
assign 1 0 903
assign 1 0 907
return 1 0 911
return 1 0 914
assign 1 0 917
assign 1 0 921
return 1 0 925
return 1 0 928
assign 1 0 931
assign 1 0 935
return 1 0 939
return 1 0 942
assign 1 0 945
assign 1 0 949
return 1 0 953
return 1 0 956
assign 1 0 959
assign 1 0 963
return 1 0 967
return 1 0 970
assign 1 0 973
assign 1 0 977
return 1 0 981
return 1 0 984
assign 1 0 987
assign 1 0 991
return 1 0 995
return 1 0 998
assign 1 0 1001
assign 1 0 1005
return 1 0 1009
return 1 0 1012
assign 1 0 1015
assign 1 0 1019
return 1 0 1023
return 1 0 1026
assign 1 0 1029
assign 1 0 1033
return 1 0 1037
return 1 0 1040
assign 1 0 1043
assign 1 0 1047
return 1 0 1051
return 1 0 1054
assign 1 0 1057
assign 1 0 1061
return 1 0 1065
return 1 0 1068
assign 1 0 1071
assign 1 0 1075
return 1 0 1079
return 1 0 1082
assign 1 0 1085
assign 1 0 1089
return 1 0 1093
return 1 0 1096
assign 1 0 1099
assign 1 0 1103
return 1 0 1107
return 1 0 1110
assign 1 0 1113
assign 1 0 1117
return 1 0 1121
return 1 0 1124
assign 1 0 1127
assign 1 0 1131
return 1 0 1135
return 1 0 1138
assign 1 0 1141
assign 1 0 1145
return 1 0 1149
return 1 0 1152
assign 1 0 1155
assign 1 0 1159
return 1 0 1163
return 1 0 1166
assign 1 0 1169
assign 1 0 1173
return 1 0 1177
return 1 0 1180
assign 1 0 1183
assign 1 0 1187
return 1 0 1191
return 1 0 1194
assign 1 0 1197
assign 1 0 1201
return 1 0 1205
return 1 0 1208
assign 1 0 1211
assign 1 0 1215
return 1 0 1219
return 1 0 1222
assign 1 0 1225
assign 1 0 1229
return 1 0 1233
return 1 0 1236
assign 1 0 1239
assign 1 0 1243
return 1 0 1247
return 1 0 1250
assign 1 0 1253
assign 1 0 1257
return 1 0 1261
return 1 0 1264
assign 1 0 1267
assign 1 0 1271
return 1 0 1275
return 1 0 1278
assign 1 0 1281
assign 1 0 1285
return 1 0 1289
return 1 0 1292
assign 1 0 1295
assign 1 0 1299
return 1 0 1303
return 1 0 1306
assign 1 0 1309
assign 1 0 1313
return 1 0 1317
return 1 0 1320
assign 1 0 1323
assign 1 0 1327
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 2022374745: return bem_INCREMENT_ASSIGNGet_0();
case -759291903: return bem_BREAKGet_0();
case 693796915: return bem_IDXGetDirect_0();
case 1472763889: return bem_EQUALSGetDirect_0();
case -898793669: return bem_TRYGet_0();
case -1653939165: return bem_iteratorGet_0();
case -414881072: return bem_SUBTRACT_ASSIGNGetDirect_0();
case -5747527: return bem_ANDGetDirect_0();
case -893093197: return bem_toString_0();
case -1123772011: return bem_CALLGetDirect_0();
case 2103870775: return bem_ATYPEGet_0();
case -1870399585: return bem_MODULUS_ASSIGNGet_0();
case -626810493: return bem_VARGet_0();
case 1076351158: return bem_EXPRGet_0();
case 1153344161: return bem_serializeContents_0();
case 961121220: return bem_FORGetDirect_0();
case -685695065: return bem_FORGet_0();
case 931827515: return bem_DOTGet_0();
case 897733872: return bem_INCREMENTGet_0();
case -720282916: return bem_STRINGLGetDirect_0();
case 1526611145: return bem_INCREMENTGetDirect_0();
case 2081206499: return bem_CATCHGetDirect_0();
case 696714749: return bem_NULLGet_0();
case 633677587: return bem_ASSIGNGet_0();
case -1570207869: return bem_WHILEGetDirect_0();
case 1900741160: return bem_ASGetDirect_0();
case 1586815430: return bem_fieldIteratorGet_0();
case -608868070: return bem_PARENSGet_0();
case 1538884787: return bem_RIDXGet_0();
case -1890275171: return bem_METHODGet_0();
case 1571255506: return bem_SEMIGetDirect_0();
case 1843695385: return bem_ASGet_0();
case -1426334710: return bem_USEGet_0();
case -1385924527: return bem_NEWLINEGet_0();
case -1441328725: return bem_ACCESSORGet_0();
case -1987324827: return bem_ELIFGet_0();
case -935208170: return bem_LOGICAL_ORGetDirect_0();
case -212549100: return bem_FALSEGet_0();
case 448919056: return bem_BLOCKGetDirect_0();
case -447102274: return bem_IDGetDirect_0();
case -2118708930: return bem_new_0();
case -300611719: return bem_RPARENSGet_0();
case -1013767850: return bem_EMITGetDirect_0();
case 1901682633: return bem_ORGet_0();
case 1660669115: return bem_TRYGetDirect_0();
case -1282708661: return bem_EXPRGetDirect_0();
case -288769832: return bem_DECREMENTGet_0();
case -130124616: return bem_WSTRQGetDirect_0();
case 1942405614: return bem_NOT_EQUALSGet_0();
case 860179149: return bem_COLONGetDirect_0();
case -1659587320: return bem_COMMAGet_0();
case 1830868749: return bem_EMITGet_0();
case -1416969652: return bem_DECREMENT_ASSIGNGetDirect_0();
case -1656013182: return bem_TRANSUNITGetDirect_0();
case -1440209538: return bem_DEFMODGetDirect_0();
case -40905183: return bem_echo_0();
case 752116318: return bem_IDXACCGet_0();
case 1229190213: return bem_ELIFGetDirect_0();
case -1269719289: return bem_BRACESGetDirect_0();
case 1895832258: return bem_CALLGet_0();
case -1227195232: return bem_FOREACHGet_0();
case 883503547: return bem_COLONGet_0();
case -1075244951: return bem_LOGICAL_ORGet_0();
case 1256251346: return bem_ASSIGNGetDirect_0();
case 95437045: return bem_NAMEPATHGet_0();
case -413918880: return bem_ADD_ASSIGNGetDirect_0();
case 1957471807: return bem_LESSERGet_0();
case 865398331: return bem_NOTGet_0();
case 1300411030: return bem_ADDGet_0();
case 1834246217: return bem_classNameGet_0();
case -631151746: return bem_NOTGetDirect_0();
case 195585679: return bem_OR_ASSIGNGetDirect_0();
case -1521058443: return bem_GREATERGet_0();
case -764915490: return bem_IFEMITGet_0();
case 1159855595: return bem_CLASSGet_0();
case 1988751379: return bem_DIVIDE_ASSIGNGet_0();
case 1347975926: return bem_FOREACHGetDirect_0();
case 968767778: return bem_STRINGLGet_0();
case 662994084: return bem_WSTRINGLGetDirect_0();
case 752845308: return bem_ADD_ASSIGNGet_0();
case 1293903869: return bem_NEWLINEGetDirect_0();
case 1886539178: return bem_FLOATLGetDirect_0();
case 973839836: return bem_LOOPGetDirect_0();
case -1590506130: return bem_FLOATLGet_0();
case -1076915155: return bem_serializeToString_0();
case 2127743510: return bem_CLASSGetDirect_0();
case 993399261: return bem_EQUALSGet_0();
case 2081363871: return bem_copy_0();
case -1808276714: return bem_MODULUSGetDirect_0();
case -574515749: return bem_RBRACESGetDirect_0();
case 1172560781: return bem_INGetDirect_0();
case -1979989708: return bem_IDXACCGetDirect_0();
case 428391090: return bem_INGet_0();
case -486747184: return bem_ANDGet_0();
case 914414469: return bem_VARGetDirect_0();
case -445367626: return bem_IDGet_0();
case 1193571212: return bem_FALSEGetDirect_0();
case -1908662967: return bem_RBRACESGet_0();
case 628175229: return bem_COMMAGetDirect_0();
case 1931705863: return bem_sourceFileNameGet_0();
case 1535965254: return bem_LOGICAL_ANDGet_0();
case 1000854259: return bem_PROPERTIESGetDirect_0();
case -1494269844: return bem_DEFMODGet_0();
case 938157925: return bem_INTLGetDirect_0();
case 459686303: return bem_MODULUS_ASSIGNGetDirect_0();
case -1537610130: return bem_TOKENGet_0();
case 972276696: return bem_WHILEGet_0();
case 1176372895: return bem_PROPERTIESGet_0();
case -823131351: return bem_TOKENGetDirect_0();
case 1272165454: return bem_MULTIPLY_ASSIGNGet_0();
case -460446348: return bem_DIVIDEGet_0();
case -487347954: return bem_DECREMENT_ASSIGNGet_0();
case 1932863138: return bem_AND_ASSIGNGet_0();
case 1078741885: return bem_SUBTRACTGetDirect_0();
case -1424165940: return bem_FSLASHGet_0();
case -1605732088: return bem_GREATERGetDirect_0();
case -1718372918: return bem_IFGet_0();
case 954703233: return bem_create_0();
case 987108371: return bem_SUBTRACTGet_0();
case 1460298558: return bem_DIVIDEGetDirect_0();
case 1577720538: return bem_TRUEGetDirect_0();
case 403178689: return bem_INTLGet_0();
case -1930424262: return bem_AND_ASSIGNGetDirect_0();
case -2127634794: return bem_GREATER_EQUALSGetDirect_0();
case 421177749: return bem_print_0();
case 2060757676: return bem_ADDGetDirect_0();
case 1110293561: return bem_CONTINUEGetDirect_0();
case 1287094143: return bem_FINALLYGetDirect_0();
case 528702842: return bem_RPARENSGetDirect_0();
case -487191921: return bem_default_0();
case -971783125: return bem_BLOCKGet_0();
case 586164621: return bem_IDXGet_0();
case -1153161673: return bem_MULTIPLYGet_0();
case -364157036: return bem_WSTRQGet_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case -1930396305: return bem_IFEMITGetDirect_0();
case 1443437978: return bem_BRACESGet_0();
case 259161809: return bem_ELSEGet_0();
case -1614891431: return bem_RIDXGetDirect_0();
case -494431048: return bem_ATYPEGetDirect_0();
case -1055671290: return bem_LOOPGet_0();
case 1450367489: return bem_ACCESSORGetDirect_0();
case 1529596293: return bem_NAMEPATHGetDirect_0();
case -214117490: return bem_LESSER_EQUALSGet_0();
case 1974505938: return bem_hashGet_0();
case -778950653: return bem_ORGetDirect_0();
case 1796520233: return bem_SPACEGetDirect_0();
case -527427285: return bem_DECREMENTGetDirect_0();
case 991127030: return bem_METHODGetDirect_0();
case 946360922: return bem_serializationIteratorGet_0();
case -820639898: return bem_LOGICAL_ANDGetDirect_0();
case -193582610: return bem_tagGet_0();
case 1593193424: return bem_MULTIPLY_ASSIGNGetDirect_0();
case -336361451: return bem_CONTINUEGet_0();
case -975498393: return bem_fieldNamesGet_0();
case 14221099: return bem_MODULUSGet_0();
case 1068117068: return bem_LESSER_EQUALSGetDirect_0();
case -1107016986: return bem_WSTRINGLGet_0();
case -366680985: return bem_NULLGetDirect_0();
case 1512588898: return bem_TRANSUNITGet_0();
case -765461059: return bem_IFGetDirect_0();
case 366546563: return bem_STRQGetDirect_0();
case 1093592836: return bem_SEMIGet_0();
case 942321106: return bem_DOTGetDirect_0();
case -1539468671: return bem_DIVIDE_ASSIGNGetDirect_0();
case -19324528: return bem_PARENSGetDirect_0();
case -1259752295: return bem_MULTIPLYGetDirect_0();
case 1581098457: return bem_USEGetDirect_0();
case 2029807325: return bem_STRQGet_0();
case 194158263: return bem_GREATER_EQUALSGet_0();
case 2013884654: return bem_TRUEGet_0();
case -1289280658: return bem_CATCHGet_0();
case -1594941783: return bem_NOT_EQUALSGetDirect_0();
case 803154136: return bem_LESSERGetDirect_0();
case 652639133: return bem_BREAKGetDirect_0();
case -1531554437: return bem_FINALLYGet_0();
case 798454313: return bem_INCREMENT_ASSIGNGetDirect_0();
case -1123602922: return bem_SPACEGet_0();
case -1477995272: return bem_SUBTRACT_ASSIGNGet_0();
case -1716532230: return bem_FSLASHGetDirect_0();
case -1460024437: return bem_ELSEGetDirect_0();
case -1282407714: return bem_OR_ASSIGNGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1562179330: return bem_CATCHSetDirect_1(bevd_0);
case 299113334: return bem_NEWLINESetDirect_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 963650938: return bem_IDXSetDirect_1(bevd_0);
case -629380229: return bem_SPACESetDirect_1(bevd_0);
case 1481349361: return bem_INTLSetDirect_1(bevd_0);
case -931193905: return bem_FALSESetDirect_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -691612728: return bem_WSTRQSet_1(bevd_0);
case -1647408372: return bem_EXPRSetDirect_1(bevd_0);
case -715471006: return bem_STRQSetDirect_1(bevd_0);
case 1297287124: return bem_ADDSet_1(bevd_0);
case -762848464: return bem_LOOPSetDirect_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1205251359: return bem_LOGICAL_ANDSetDirect_1(bevd_0);
case 1708791603: return bem_NULLSet_1(bevd_0);
case 1432705927: return bem_LESSERSetDirect_1(bevd_0);
case 1820694299: return bem_ELSESetDirect_1(bevd_0);
case 1818003284: return bem_BLOCKSet_1(bevd_0);
case 1861448424: return bem_TRANSUNITSetDirect_1(bevd_0);
case 1688265281: return bem_DEFMODSet_1(bevd_0);
case -1396640184: return bem_OR_ASSIGNSetDirect_1(bevd_0);
case 455696533: return bem_NOTSet_1(bevd_0);
case -1551608505: return bem_FOREACHSet_1(bevd_0);
case 204974842: return bem_LOGICAL_ORSet_1(bevd_0);
case -934177692: return bem_STRQSet_1(bevd_0);
case -461809683: return bem_FSLASHSet_1(bevd_0);
case 572041763: return bem_CONTINUESetDirect_1(bevd_0);
case -203774078: return bem_DOTSetDirect_1(bevd_0);
case -399347109: return bem_ANDSetDirect_1(bevd_0);
case -2007360863: return bem_TRYSet_1(bevd_0);
case -1550274093: return bem_LOGICAL_ANDSet_1(bevd_0);
case -866569624: return bem_BREAKSetDirect_1(bevd_0);
case -2058651970: return bem_BRACESSet_1(bevd_0);
case -2132479115: return bem_EMITSet_1(bevd_0);
case 2023261285: return bem_FORSet_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case -583907405: return bem_RIDXSet_1(bevd_0);
case 1941199380: return bem_IDSetDirect_1(bevd_0);
case -1909215193: return bem_IFSetDirect_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -928712044: return bem_IFEMITSet_1(bevd_0);
case -175622956: return bem_RBRACESSetDirect_1(bevd_0);
case 1727401: return bem_ACCESSORSet_1(bevd_0);
case 539532216: return bem_NEWLINESet_1(bevd_0);
case 1507152795: return bem_USESet_1(bevd_0);
case -1923799705: return bem_BREAKSet_1(bevd_0);
case 8210801: return bem_INCREMENT_ASSIGNSet_1(bevd_0);
case 785929702: return bem_PARENSSet_1(bevd_0);
case -1855307971: return bem_TRUESet_1(bevd_0);
case 467795817: return bem_TRYSetDirect_1(bevd_0);
case 233584188: return bem_FALSESet_1(bevd_0);
case -243816276: return bem_RPARENSSetDirect_1(bevd_0);
case 1109753795: return bem_IFSet_1(bevd_0);
case -1384532875: return bem_WHILESet_1(bevd_0);
case 1990726821: return bem_IDSet_1(bevd_0);
case 1181434408: return bem_INSet_1(bevd_0);
case -1192767784: return bem_ATYPESet_1(bevd_0);
case 368343453: return bem_NOTSetDirect_1(bevd_0);
case -641199981: return bem_IDXSet_1(bevd_0);
case -574521935: return bem_ELIFSetDirect_1(bevd_0);
case -589111: return bem_FINALLYSetDirect_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 934722868: return bem_WSTRQSetDirect_1(bevd_0);
case 408186126: return bem_ORSet_1(bevd_0);
case -1746948982: return bem_CATCHSet_1(bevd_0);
case -1091430173: return bem_GREATER_EQUALSSet_1(bevd_0);
case 1011290819: return bem_PARENSSetDirect_1(bevd_0);
case -1429014132: return bem_FLOATLSetDirect_1(bevd_0);
case 1459701050: return bem_FINALLYSet_1(bevd_0);
case 1353815108: return bem_ORSetDirect_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case 701074432: return bem_MODULUS_ASSIGNSetDirect_1(bevd_0);
case -394734279: return bem_SUBTRACT_ASSIGNSetDirect_1(bevd_0);
case -1804707936: return bem_INCREMENTSet_1(bevd_0);
case -949630926: return bem_LOOPSet_1(bevd_0);
case 667687230: return bem_ADD_ASSIGNSet_1(bevd_0);
case -345042332: return bem_ASSet_1(bevd_0);
case -697571535: return bem_WSTRINGLSet_1(bevd_0);
case -1278793446: return bem_DECREMENT_ASSIGNSetDirect_1(bevd_0);
case 309212971: return bem_INTLSet_1(bevd_0);
case -925330967: return bem_LOGICAL_ORSetDirect_1(bevd_0);
case 1478855682: return bem_NOT_EQUALSSetDirect_1(bevd_0);
case -1270163601: return bem_NAMEPATHSetDirect_1(bevd_0);
case -923781757: return bem_SPACESet_1(bevd_0);
case -448868975: return bem_MULTIPLYSet_1(bevd_0);
case -1887109186: return bem_MODULUSSetDirect_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case 1231991731: return bem_DEFMODSetDirect_1(bevd_0);
case -2145997330: return bem_ADDSetDirect_1(bevd_0);
case 547444207: return bem_TOKENSetDirect_1(bevd_0);
case 1455118909: return bem_ASSetDirect_1(bevd_0);
case -1841470894: return bem_NAMEPATHSet_1(bevd_0);
case 2124519020: return bem_EQUALSSetDirect_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -537467265: return bem_RIDXSetDirect_1(bevd_0);
case 279422269: return bem_FLOATLSet_1(bevd_0);
case 1422994760: return bem_IDXACCSetDirect_1(bevd_0);
case -895922925: return bem_VARSetDirect_1(bevd_0);
case 329083177: return bem_STRINGLSetDirect_1(bevd_0);
case -1946663192: return bem_ASSIGNSet_1(bevd_0);
case -1486838765: return bem_SEMISetDirect_1(bevd_0);
case -773386913: return bem_MULTIPLY_ASSIGNSet_1(bevd_0);
case -1172876659: return bem_ELSESet_1(bevd_0);
case -515771288: return bem_EXPRSet_1(bevd_0);
case 816150795: return bem_USESetDirect_1(bevd_0);
case -880924985: return bem_BLOCKSetDirect_1(bevd_0);
case -801815368: return bem_OR_ASSIGNSet_1(bevd_0);
case 2055430166: return bem_FORSetDirect_1(bevd_0);
case -1798430462: return bem_RPARENSSet_1(bevd_0);
case -891132208: return bem_DECREMENTSet_1(bevd_0);
case 1913957487: return bem_CLASSSet_1(bevd_0);
case 284897922: return bem_SUBTRACTSet_1(bevd_0);
case 536509394: return bem_FOREACHSetDirect_1(bevd_0);
case 51152959: return bem_CALLSet_1(bevd_0);
case -1269196625: return bem_MODULUS_ASSIGNSet_1(bevd_0);
case 649855646: return bem_TRANSUNITSet_1(bevd_0);
case -2013189178: return bem_INCREMENT_ASSIGNSetDirect_1(bevd_0);
case 1512308850: return bem_STRINGLSet_1(bevd_0);
case -1521206315: return bem_INSetDirect_1(bevd_0);
case 1742983287: return bem_EMITSetDirect_1(bevd_0);
case -221856742: return bem_CONTINUESet_1(bevd_0);
case 807001650: return bem_PROPERTIESSet_1(bevd_0);
case -889141439: return bem_EQUALSSet_1(bevd_0);
case -1877997679: return bem_METHODSetDirect_1(bevd_0);
case 549389142: return bem_MODULUSSet_1(bevd_0);
case -1171029182: return bem_MULTIPLYSetDirect_1(bevd_0);
case -762775766: return bem_COMMASetDirect_1(bevd_0);
case -1704883012: return bem_GREATERSet_1(bevd_0);
case -399734523: return bem_DECREMENTSetDirect_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 81491699: return bem_VARSet_1(bevd_0);
case 1189461920: return bem_CLASSSetDirect_1(bevd_0);
case 489558475: return bem_DOTSet_1(bevd_0);
case 194757004: return bem_ATYPESetDirect_1(bevd_0);
case -1851040986: return bem_TOKENSet_1(bevd_0);
case 268114421: return bem_ACCESSORSetDirect_1(bevd_0);
case -655601953: return bem_NULLSetDirect_1(bevd_0);
case -1083087593: return bem_BRACESSetDirect_1(bevd_0);
case 387452464: return bem_COLONSet_1(bevd_0);
case -1290065616: return bem_ELIFSet_1(bevd_0);
case 1412754138: return bem_IDXACCSet_1(bevd_0);
case 1497883545: return bem_DIVIDESetDirect_1(bevd_0);
case 1016935411: return bem_WHILESetDirect_1(bevd_0);
case 938080935: return bem_GREATER_EQUALSSetDirect_1(bevd_0);
case -1528862947: return bem_WSTRINGLSetDirect_1(bevd_0);
case 226533023: return bem_SUBTRACTSetDirect_1(bevd_0);
case -677889359: return bem_SUBTRACT_ASSIGNSet_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -2029012233: return bem_DIVIDE_ASSIGNSet_1(bevd_0);
case -16923240: return bem_LESSER_EQUALSSetDirect_1(bevd_0);
case 513320631: return bem_CALLSetDirect_1(bevd_0);
case 635974920: return bem_DIVIDE_ASSIGNSetDirect_1(bevd_0);
case -1477422685: return bem_COLONSetDirect_1(bevd_0);
case -625718009: return bem_DECREMENT_ASSIGNSet_1(bevd_0);
case -1962349833: return bem_ANDSet_1(bevd_0);
case -1768882966: return bem_IFEMITSetDirect_1(bevd_0);
case 178959762: return bem_INCREMENTSetDirect_1(bevd_0);
case 1117209363: return bem_FSLASHSetDirect_1(bevd_0);
case 907198210: return bem_ADD_ASSIGNSetDirect_1(bevd_0);
case -2027687119: return bem_LESSERSet_1(bevd_0);
case 1951900064: return bem_DIVIDESet_1(bevd_0);
case 1913547675: return bem_ASSIGNSetDirect_1(bevd_0);
case 1261108784: return bem_METHODSet_1(bevd_0);
case 2093195538: return bem_LESSER_EQUALSSet_1(bevd_0);
case -636077814: return bem_AND_ASSIGNSet_1(bevd_0);
case -573170354: return bem_PROPERTIESSetDirect_1(bevd_0);
case -6087964: return bem_AND_ASSIGNSetDirect_1(bevd_0);
case -1693236157: return bem_RBRACESSet_1(bevd_0);
case 1035499282: return bem_TRUESetDirect_1(bevd_0);
case 449436672: return bem_MULTIPLY_ASSIGNSetDirect_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case 2077587873: return bem_SEMISet_1(bevd_0);
case -1637863590: return bem_NOT_EQUALSSet_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -2117940714: return bem_GREATERSetDirect_1(bevd_0);
case 1476076095: return bem_COMMASet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildNodeTypes_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildNodeTypes_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildNodeTypes();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst = (BEC_2_5_9_BuildNodeTypes) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_type;
}
}
}
