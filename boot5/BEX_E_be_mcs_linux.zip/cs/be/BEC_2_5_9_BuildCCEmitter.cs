namespace be {
/* IO:File: source/build/CCEmitter.be */
public sealed class BEC_2_5_9_BuildCCEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
static BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x62,0x65,0x76,0x65,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x63,0x63,0x4E,0x6F,0x52,0x74,0x74,0x69};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x2A,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x63,0x63,0x53,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x66,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x66,0x29,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x30,0x78};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x5D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x66,0x6F,0x72,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x69,0x20,0x3D,0x20,0x30,0x3B,0x20,0x69,0x20,0x3C,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x20,0x69,0x2B,0x2B,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x67,0x5F,0x6C,0x65,0x20,0x3D,0x20,0x2A,0x28,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B,0x69,0x5D,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x62,0x65,0x76,0x67,0x5F,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x5D,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x7D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x42,0x45,0x44,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x42,0x45,0x48,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x63,0x63,0x42,0x67,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x2C,0x20,0x67,0x63,0x5F,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_159 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
public static new BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static new BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_6_TextString bevp_onceDecRefs;
public BEC_2_4_3_MathInt bevp_onceDecRefsCount;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
base.bem_new_1(beva__build);
bevp_invp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
if (bevp_parentConf == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 43*/ {
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevt_1_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_2_ta_ph);
bevl_extends = bem_extend_1(bevt_1_ta_ph);
} /* Line: 44*/
 else /* Line: 45*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_ta_ph);
} /* Line: 46*/
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_7_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevl_extends);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
if (bevp_parentConf == null) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 50*/ {
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_14_ta_ph);
bevt_16_ta_ph = bevp_build.bem_libNameGet_0();
bevt_15_ta_ph = bevp_parentConf.bem_relEmitName_1(bevt_16_ta_ph);
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_ta_ph.bem_addValue_1(bevt_17_ta_ph);
} /* Line: 55*/
 else /* Line: 56*/ {
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_19_ta_ph);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_20_ta_ph);
} /* Line: 61*/
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_22_ta_ph);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevp_heow.bem_write_1(bevt_23_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_24_ta_ph);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_25_ta_ph);
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevt_31_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_31_ta_ph);
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_28_ta_ph = bevt_29_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_34_ta_ph);
bevp_heow.bem_write_1(bevt_26_ta_ph);
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevp_heow.bem_write_1(bevt_35_ta_ph);
bevt_36_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_36_ta_ph);
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_37_ta_ph);
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_38_ta_ph);
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_41_ta_ph);
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
bevt_45_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_43_ta_ph = bevt_44_ta_ph.bem_add_1(bevt_45_ta_ph);
bevt_46_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevt_42_ta_ph = bevt_43_ta_ph.bem_add_1(bevt_46_ta_ph);
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_50_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevt_50_ta_ph);
bevt_51_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_47_ta_ph = bevt_48_ta_ph.bem_add_1(bevt_51_ta_ph);
bevp_deow.bem_write_1(bevt_47_ta_ph);
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_52_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_7_ta_ph = bem_overrideMtdDecGet_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_ta_ph);
bevt_9_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_ta_ph);
bevt_22_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_0(782632493);
bevt_20_ta_ph = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_ta_ph );
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_relEmitName_1(bevt_23_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) bevt_17_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_15_ta_ph = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_15_ta_ph.bem_addValue_1(bevp_nl);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_25_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_26_ta_ph);
bevt_25_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevp_heow.bem_write_1(bevt_0_ta_ph);
return bevl_end;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_ta_ph = bevp_build.bem_libNameGet_0();
bevt_6_ta_ph = beva_returnType.bem_relEmitName_1(bevt_7_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(beva_mtdName);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_0_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_15_ta_ph);
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevt_14_ta_ph.bem_addValue_1(beva_exceptDec);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_20_ta_ph = (BEC_2_4_6_TextString) bevp_classHeadBody.bem_addValue_1(bevt_21_ta_ph);
bevt_23_ta_ph = bevp_build.bem_libNameGet_0();
bevt_22_ta_ph = beva_returnType.bem_relEmitName_1(bevt_23_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_addValue_1(bevt_22_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_18_ta_ph = (BEC_2_4_6_TextString) bevt_19_ta_ph.bem_addValue_1(bevt_24_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevt_18_ta_ph.bem_addValue_1(beva_mtdName);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_17_ta_ph.bem_addValue_1(bevt_25_ta_ph);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevp_classHeadBody.bem_addValue_1(bevt_26_ta_ph);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_node.bem_typenameGet_0();
bevt_2_ta_ph = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_ta_ph.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 140*/ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 141*/
 else /* Line: 140*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(1527025322);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(596540473, bevt_6_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 142*/ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
} /* Line: 143*/
 else /* Line: 140*/ {
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1527025322);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_7_ta_ph = bevt_8_ta_ph.bemd_1(596540473, bevt_10_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 144*/ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
} /* Line: 145*/
 else /* Line: 146*/ {
bevt_11_ta_ph = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_ta_ph );
} /* Line: 147*/
} /* Line: 140*/
} /* Line: 140*/
return bevl_tcall;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1527025322);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(596540473, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 153*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevl_tcall = bevt_4_ta_ph.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 155*/
bevt_5_ta_ph = base.bem_formCallTarg_1(beva_node);
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_5_4_BuildNode bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = beva_node.bem_secondGet_0();
bevt_4_ta_ph = bem_formTarg_1(bevt_5_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevt_2_ta_ph = beva_node.bem_heldGet_0();
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(1310040486);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-1243270878, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 165*/ {
bevt_5_ta_ph = beva_node.bem_heldGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bemd_0(-601719988);
bevp_classHeaders.bem_addValue_1(bevt_4_ta_ph);
} /* Line: 166*/
 else /* Line: 167*/ {
base.bem_handleClassEmit_1(beva_node);
} /* Line: 168*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevt_8_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevl_clh = bevt_4_ta_ph.bem_add_1(bevt_10_ta_ph);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_ta_ph = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevt_15_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_18_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevt_14_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevt_13_ta_ph.bem_addValue_1(bevt_19_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevl_bein);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_11_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_24_ta_ph = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_25_ta_ph);
bevt_26_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_ta_ph = (BEC_2_4_6_TextString) bevt_24_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_22_ta_ph = (BEC_2_4_6_TextString) bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_28_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_21_ta_ph = (BEC_2_4_6_TextString) bevt_22_ta_ph.bem_addValue_1(bevt_28_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_32_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_32_ta_ph);
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_56));
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_33_ta_ph);
bevt_21_ta_ph.bem_addValue_1(bevt_29_ta_ph);
return bevl_initialDec;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_8_ContainerNodeList bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_57));
bevt_1_ta_ph = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_ta_ph.bem_add_1(bevt_1_ta_ph);
bevp_methodCatch.bevi_int++;
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevl_catchVar);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
bevt_2_ta_ph.bem_addValue_1(bevp_nl);
bevt_11_ta_ph = beva_node.bem_containedGet_0();
bevt_10_ta_ph = bevt_11_ta_ph.bem_firstGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(1815203708);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(1171374908);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(bevl_catchVar);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_7_ta_ph = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_ta_ph , bevt_12_ta_ph, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_ta_ph);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_11_BuildClassConfig bevt_8_ta_ph = null;
BEC_2_5_8_BuildNamePath bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_v.bem_isTypedGet_0();
if (bevt_1_ta_ph.bevi_bool) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 199*/ {
bevt_4_ta_ph = bevp_build.bem_libNameGet_0();
bevt_3_ta_ph = bevp_objectCc.bem_relEmitName_1(bevt_4_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_3_ta_ph);
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_2_ta_ph.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 200*/
 else /* Line: 201*/ {
bevt_9_ta_ph = beva_v.bem_namepathGet_0();
bevt_8_ta_ph = bem_getClassConfig_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_7_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_6_ta_ph.bem_addValue_1(bevt_11_ta_ph);
} /* Line: 202*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_0_ta_ph = beva_type.bem_equals_1(bevt_1_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 207*/ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
} /* Line: 208*/
 else /* Line: 209*/ {
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 210*/ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
} /* Line: 211*/
 else /* Line: 212*/ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_65));
} /* Line: 213*/
} /* Line: 210*/
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_66));
bevt_7_ta_ph = bevl_ccall.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = bevp_build.bem_libNameGet_0();
bevt_9_ta_ph = beva_cc.bem_relEmitName_1(bevt_10_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_afterCast_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
bevt_8_ta_ph = bem_overrideMtdDecGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(beva_bemBase);
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevt_3_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) bevt_2_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_ta_ph = (BEC_2_4_6_TextString) bevt_1_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_0_ta_ph.bem_addValue_1(bevp_nl);
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_18_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) bevt_18_ta_ph.bem_addValue_1(beva_len);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_16_ta_ph = (BEC_2_4_6_TextString) bevt_17_ta_ph.bem_addValue_1(bevt_20_ta_ph);
bevt_15_ta_ph = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_addValue_1(beva_belsBase);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevt_15_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_22_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_23_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
if (beva_isOnce.bevi_bool)/* Line: 232*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-152499016);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /* Line: 233*/
bevt_12_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_11_ta_ph = bevt_12_ta_ph.bem_has_1(bevt_13_ta_ph);
if (bevt_11_ta_ph.bevi_bool)/* Line: 235*/ {
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_21_ta_ph = bevp_build.bem_libNameGet_0();
bevt_20_ta_ph = beva_newcc.bem_relEmitName_1(bevt_21_ta_ph);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(45, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = bevp_build.bem_libNameGet_0();
bevt_23_ta_ph = beva_newcc.bem_relEmitName_1(bevt_24_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_23_ta_ph);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_15_ta_ph = bevt_16_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = beva_node.bem_heldGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bemd_0(-152499016);
bevt_14_ta_ph = bevt_15_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_14_ta_ph.bem_add_1(bevt_28_ta_ph);
} /* Line: 236*/
 else /* Line: 237*/ {
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_36_ta_ph = bevp_build.bem_libNameGet_0();
bevt_35_ta_ph = beva_newcc.bem_relEmitName_1(bevt_36_ta_ph);
bevt_33_ta_ph = bevt_34_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_libNameGet_0();
bevt_38_ta_ph = beva_newcc.bem_relEmitName_1(bevt_39_ta_ph);
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_38_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_40_ta_ph);
bevt_42_ta_ph = beva_node.bem_heldGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bemd_0(-152499016);
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_41_ta_ph);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_29_ta_ph.bem_add_1(bevt_43_ta_ph);
} /* Line: 238*/
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
if (beva_isOnce.bevi_bool)/* Line: 244*/ {
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_6_ta_ph = bevp_build.bem_libNameGet_0();
bevt_5_ta_ph = beva_newcc.bem_relEmitName_1(bevt_6_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = beva_node.bem_heldGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-152499016);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_10_ta_ph);
return bevt_0_ta_ph;
} /* Line: 245*/
bevt_12_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_11_ta_ph = bevt_12_ta_ph.bem_has_1(bevt_13_ta_ph);
if (bevt_11_ta_ph.bevi_bool)/* Line: 247*/ {
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_21_ta_ph = bevp_build.bem_libNameGet_0();
bevt_20_ta_ph = beva_newcc.bem_relEmitName_1(bevt_21_ta_ph);
bevt_18_ta_ph = bevt_19_ta_ph.bem_add_1(bevt_20_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(45, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_17_ta_ph = bevt_18_ta_ph.bem_add_1(bevt_22_ta_ph);
bevt_24_ta_ph = bevp_build.bem_libNameGet_0();
bevt_23_ta_ph = beva_newcc.bem_relEmitName_1(bevt_24_ta_ph);
bevt_16_ta_ph = bevt_17_ta_ph.bem_add_1(bevt_23_ta_ph);
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_15_ta_ph = bevt_16_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = beva_node.bem_heldGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bemd_0(-152499016);
bevt_14_ta_ph = bevt_15_ta_ph.bem_add_1(bevt_26_ta_ph);
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_newCall = bevt_14_ta_ph.bem_add_1(bevt_28_ta_ph);
} /* Line: 248*/
 else /* Line: 249*/ {
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_36_ta_ph = bevp_build.bem_libNameGet_0();
bevt_35_ta_ph = beva_newcc.bem_relEmitName_1(bevt_36_ta_ph);
bevt_33_ta_ph = bevt_34_ta_ph.bem_add_1(bevt_35_ta_ph);
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevt_37_ta_ph);
bevt_39_ta_ph = bevp_build.bem_libNameGet_0();
bevt_38_ta_ph = beva_newcc.bem_relEmitName_1(bevt_39_ta_ph);
bevt_31_ta_ph = bevt_32_ta_ph.bem_add_1(bevt_38_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_30_ta_ph = bevt_31_ta_ph.bem_add_1(bevt_40_ta_ph);
bevt_42_ta_ph = beva_node.bem_heldGet_0();
bevt_41_ta_ph = bevt_42_ta_ph.bemd_0(-152499016);
bevt_29_ta_ph = bevt_30_ta_ph.bem_add_1(bevt_41_ta_ph);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_newCall = bevt_29_ta_ph.bem_add_1(bevt_43_ta_ph);
} /* Line: 250*/
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
if (beva_isOnce.bevi_bool)/* Line: 256*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_73));
bevt_8_ta_ph = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = beva_newcc.bem_relEmitName_1(bevt_8_ta_ph);
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_7_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(beva_belsName);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_10_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(beva_lisz);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_11_ta_ph);
return bevt_0_ta_ph;
} /* Line: 257*/
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevt_13_ta_ph = bevt_14_ta_ph.bem_add_1(beva_lisz);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_15_ta_ph);
bevl_litArgs = bevt_12_ta_ph.bem_add_1(beva_belsName);
bevt_17_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_16_ta_ph = bevt_17_ta_ph.bem_has_1(bevt_18_ta_ph);
if (bevt_16_ta_ph.bevi_bool)/* Line: 261*/ {
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_26_ta_ph = bevp_build.bem_libNameGet_0();
bevt_25_ta_ph = beva_newcc.bem_relEmitName_1(bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_add_1(bevt_25_ta_ph);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(45, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_27_ta_ph);
bevt_29_ta_ph = bevp_build.bem_libNameGet_0();
bevt_28_ta_ph = beva_newcc.bem_relEmitName_1(bevt_29_ta_ph);
bevt_21_ta_ph = bevt_22_ta_ph.bem_add_1(bevt_28_ta_ph);
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_20_ta_ph = bevt_21_ta_ph.bem_add_1(bevt_30_ta_ph);
bevt_19_ta_ph = bevt_20_ta_ph.bem_add_1(bevl_litArgs);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_19_ta_ph.bem_add_1(bevt_31_ta_ph);
} /* Line: 262*/
 else /* Line: 263*/ {
bevt_37_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_39_ta_ph = bevp_build.bem_libNameGet_0();
bevt_38_ta_ph = beva_newcc.bem_relEmitName_1(bevt_39_ta_ph);
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevt_38_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_77));
bevt_35_ta_ph = bevt_36_ta_ph.bem_add_1(bevt_40_ta_ph);
bevt_42_ta_ph = bevp_build.bem_libNameGet_0();
bevt_41_ta_ph = beva_newcc.bem_relEmitName_1(bevt_42_ta_ph);
bevt_34_ta_ph = bevt_35_ta_ph.bem_add_1(bevt_41_ta_ph);
bevt_43_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_33_ta_ph = bevt_34_ta_ph.bem_add_1(bevt_43_ta_ph);
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevl_litArgs);
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_76));
bevl_newCall = bevt_32_ta_ph.bem_add_1(bevt_44_ta_ph);
} /* Line: 264*/
return bevl_newCall;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
bevp_onceDecRefsCount.bevi_int++;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_notEmpty_1(bevp_onceDecRefs);
if (bevt_0_ta_ph.bevi_bool)/* Line: 271*/ {
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevp_onceDecRefs.bem_addValue_1(bevt_2_ta_ph);
} /* Line: 272*/
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevp_onceDecRefs.bem_addValue_1(bevt_4_ta_ph);
bevt_3_ta_ph.bem_addValue_1(beva_anyName);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_21));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_typeName);
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_8_ta_ph);
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
beva_sdec.bem_addValue_1(bevt_0_ta_ph);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_1_ta_ph = beva_typeName.bem_add_1(bevt_2_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_anyName);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainInClassGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_parent);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_preClassOutput_0() {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_5_ta_ph = null;
BEC_2_2_4_IOFile bevt_6_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
bevp_setOutputTime = null;
bevt_1_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 322*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 322*/ {
bevt_5_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_existsGet_0();
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 322*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 322*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 322*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 322*/ {
return this;
} /* Line: 323*/
 else /* Line: 324*/ {
bevt_7_ta_ph = bevp_classConf.bem_classPathGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_fileGet_0();
bevl_outts = bevt_6_ta_ph.bem_lastUpdatedGet_0();
bevt_9_ta_ph = bevp_inClass.bem_fromFileGet_0();
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(836814386);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bemd_0(-1976479209);
bevt_10_ta_ph = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_ta_ph.bevi_bool)/* Line: 327*/ {
return this;
} /* Line: 330*/
bevp_setOutputTime = bevl_outts;
} /* Line: 333*/
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_1_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (bevt_0_ta_ph.bevi_bool)/* Line: 338*/ {
bevt_1_ta_ph = bem_getLibOutput_0();
return bevt_1_ta_ph;
} /* Line: 339*/
bevt_2_ta_ph = base.bem_getClassOutput_0();
return bevt_2_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 345*/ {
bevl_clns = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_1_ta_ph = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 348*/
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_2_4_IOFile bevt_3_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_4_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_ta_ph.bevi_bool))/* Line: 353*/ {
bevl_clend = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_1_ta_ph = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_ta_ph.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 359*/ {
bevt_4_ta_ph = beva_cle.bem_pathGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_fileGet_0();
bevt_3_ta_ph.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 361*/
} /* Line: 359*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 368*/ {
bevt_8_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_8_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(beva_mvn);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_9_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(beva_mvn);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_3_ta_ph.bem_addValue_1(bevp_nl);
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevt_13_ta_ph);
bevt_11_ta_ph.bem_addValue_1(bevp_nl);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_14_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_15_ta_ph);
bevt_14_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 371*/
return bevl_bet;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_9_4_ContainerList bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_9_4_ContainerList bevt_42_ta_ph = null;
BEC_2_6_6_SystemObject bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_5_4_LogicBool bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_6_TextString bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_4_6_TextString bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_3_2_4_6_IOFileWriter bevt_103_ta_ph = null;
BEC_2_4_3_MathInt bevt_104_ta_ph = null;
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_2_ta_ph = bevt_3_ta_ph.bem_add_1(bevt_6_ta_ph);
bevp_deow.bem_write_1(bevt_2_ta_ph);
bevl_beh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_ta_ph = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_13_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevl_beh.bem_addValue_1(bevt_16_ta_ph);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevl_beh.bem_addValue_1(bevt_17_ta_ph);
bevt_20_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_19_ta_ph = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_20_ta_ph);
bevt_18_ta_ph = (BEC_2_4_6_TextString) bevt_19_ta_ph.bem_addValue_1(bevp_onceDecRefsCount);
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_18_ta_ph.bem_addValue_1(bevt_21_ta_ph);
bevt_22_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevl_beh.bem_addValue_1(bevt_22_ta_ph);
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_beh.bem_addValue_1(bevt_23_ta_ph);
bevt_24_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevl_beh.bem_addValue_1(bevt_24_ta_ph);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_28_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_27_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_28_ta_ph);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_26_ta_ph = (BEC_2_4_6_TextString) bevt_27_ta_ph.bem_addValue_1(bevt_29_ta_ph);
bevt_30_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_25_ta_ph = (BEC_2_4_6_TextString) bevt_26_ta_ph.bem_addValue_1(bevt_30_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevt_25_ta_ph.bem_addValue_1(bevt_31_ta_ph);
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevl_bet.bem_addValue_1(bevt_32_ta_ph);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_33_ta_ph = bevp_csyn.bem_mtdListGet_0();
bevt_0_ta_loop = bevt_33_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 394*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 394*/ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_loop.bemd_0(409355098);
if (bevl_firstmnsyn.bevi_bool)/* Line: 395*/ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 396*/
 else /* Line: 397*/ {
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevl_bet.bem_addValue_1(bevt_35_ta_ph);
} /* Line: 398*/
bevt_37_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_38_ta_ph = bevl_mnsyn.bem_nameGet_0();
bevt_36_ta_ph = (BEC_2_4_6_TextString) bevt_37_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_36_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 400*/
 else /* Line: 394*/ {
break;
} /* Line: 394*/
} /* Line: 394*/
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevl_bet.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevl_bet.bem_addValue_1(bevt_40_ta_ph);
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevl_bet.bem_addValue_1(bevt_41_ta_ph);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_42_ta_ph = bevp_csyn.bem_ptyListGet_0();
bevt_1_ta_loop = bevt_42_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 407*/ {
bevt_43_ta_ph = bevt_1_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_43_ta_ph).bevi_bool)/* Line: 407*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_ta_loop.bemd_0(409355098);
if (bevl_firstptsyn.bevi_bool)/* Line: 408*/ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 409*/
 else /* Line: 410*/ {
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevl_bet.bem_addValue_1(bevt_44_ta_ph);
} /* Line: 411*/
bevt_46_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_47_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_45_ta_ph = (BEC_2_4_6_TextString) bevt_46_ta_ph.bem_addValue_1(bevt_47_ta_ph);
bevt_45_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 413*/
 else /* Line: 407*/ {
break;
} /* Line: 407*/
} /* Line: 407*/
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevl_bet.bem_addValue_1(bevt_48_ta_ph);
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_49_ta_ph);
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevt_51_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_52_ta_ph);
bevt_53_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_50_ta_ph = (BEC_2_4_6_TextString) bevt_51_ta_ph.bem_addValue_1(bevt_53_ta_ph);
bevt_54_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevt_50_ta_ph.bem_addValue_1(bevt_54_ta_ph);
bevt_56_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_57_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevt_55_ta_ph = bevt_56_ta_ph.bem_equals_1(bevt_57_ta_ph);
if (bevt_55_ta_ph.bevi_bool)/* Line: 420*/ {
bevt_60_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_59_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_60_ta_ph);
bevt_61_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_58_ta_ph = (BEC_2_4_6_TextString) bevt_59_ta_ph.bem_addValue_1(bevt_61_ta_ph);
bevt_62_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_58_ta_ph.bem_addValue_1(bevt_62_ta_ph);
} /* Line: 421*/
 else /* Line: 422*/ {
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_64_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_65_ta_ph);
bevt_66_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_63_ta_ph = (BEC_2_4_6_TextString) bevt_64_ta_ph.bem_addValue_1(bevt_66_ta_ph);
bevt_67_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_63_ta_ph.bem_addValue_1(bevt_67_ta_ph);
} /* Line: 423*/
bevt_68_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_68_ta_ph);
bevt_71_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_70_ta_ph = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_71_ta_ph);
bevt_72_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_69_ta_ph = (BEC_2_4_6_TextString) bevt_70_ta_ph.bem_addValue_1(bevt_72_ta_ph);
bevt_73_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevt_69_ta_ph.bem_addValue_1(bevt_73_ta_ph);
bevt_74_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevl_bet.bem_addValue_1(bevt_74_ta_ph);
bevt_76_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_75_ta_ph = bem_genMark_1(bevt_76_ta_ph);
bevl_bet.bem_addValue_1(bevt_75_ta_ph);
bevt_77_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_112));
bevl_bet.bem_addValue_1(bevt_77_ta_ph);
bevt_78_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(56, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevl_bet.bem_addValue_1(bevt_78_ta_ph);
bevt_80_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_79_ta_ph = bem_genMark_1(bevt_80_ta_ph);
bevl_bet.bem_addValue_1(bevt_79_ta_ph);
bevt_81_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_81_ta_ph);
bevt_82_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevl_bet.bem_addValue_1(bevt_82_ta_ph);
bevt_90_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_89_ta_ph = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevt_90_ta_ph);
bevt_91_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_88_ta_ph = (BEC_2_4_6_TextString) bevt_89_ta_ph.bem_addValue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevt_87_ta_ph = (BEC_2_4_6_TextString) bevt_88_ta_ph.bem_addValue_1(bevt_92_ta_ph);
bevt_86_ta_ph = (BEC_2_4_6_TextString) bevt_87_ta_ph.bem_addValue_1(bevp_onceDecRefsCount);
bevt_93_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_85_ta_ph = (BEC_2_4_6_TextString) bevt_86_ta_ph.bem_addValue_1(bevt_93_ta_ph);
bevt_84_ta_ph = (BEC_2_4_6_TextString) bevt_85_ta_ph.bem_addValue_1(bevp_onceDecRefs);
bevt_94_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevt_83_ta_ph = (BEC_2_4_6_TextString) bevt_84_ta_ph.bem_addValue_1(bevt_94_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevt_98_ta_ph = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevt_99_ta_ph);
bevt_100_ta_ph = bevp_classConf.bem_typeEmitNameGet_0();
bevt_97_ta_ph = (BEC_2_4_6_TextString) bevt_98_ta_ph.bem_addValue_1(bevt_100_ta_ph);
bevt_101_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_96_ta_ph = (BEC_2_4_6_TextString) bevt_97_ta_ph.bem_addValue_1(bevt_101_ta_ph);
bevt_95_ta_ph = (BEC_2_4_6_TextString) bevt_96_ta_ph.bem_addValue_1(bevp_onceDecRefsCount);
bevt_102_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_95_ta_ph.bem_addValue_1(bevt_102_ta_ph);
bevp_onceDecRefs.bem_clear_0();
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_103_ta_ph = bem_getClassOutput_0();
bevt_103_ta_ph.bem_write_1(bevl_bet);
bevt_104_ta_ph = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_104_ta_ph.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_16_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_2_4_IOFile bevt_20_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_2_4_IOFile bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_2_4_IOFile bevt_27_ta_ph = null;
BEC_2_5_4_LogicBool bevt_28_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_31_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_35_ta_ph = null;
BEC_2_6_6_SystemObject bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_5_4_LogicBool bevt_43_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_46_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_6_6_SystemObject bevt_49_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_2_6_6_SystemObject bevt_53_ta_ph = null;
BEC_2_5_4_LogicBool bevt_54_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_57_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
if (bevp_deow == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 454*/ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_8_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevt_9_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_libName);
bevp_deon = bevt_4_ta_ph.bem_add_1(bevp_headExt);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_14_ta_ph = bevl_libName.bem_sizeGet_0();
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
bevt_15_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_11_ta_ph = bevt_12_ta_ph.bem_add_1(bevt_15_ta_ph);
bevt_10_ta_ph = bevt_11_ta_ph.bem_add_1(bevl_libName);
bevp_heon = bevt_10_ta_ph.bem_add_1(bevp_headExt);
bevt_16_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_ta_ph.bem_addStep_1(bevp_deon);
bevt_17_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_ta_ph.bem_addStep_1(bevp_heon);
bevt_21_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bem_fileGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_existsGet_0();
if (bevt_19_ta_ph.bevi_bool) {
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 460*/ {
bevt_23_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_22_ta_ph = bevt_23_ta_ph.bem_fileGet_0();
bevt_22_ta_ph.bem_makeDirs_0();
} /* Line: 461*/
bevt_25_ta_ph = bevp_deop.bem_fileGet_0();
bevt_24_ta_ph = bevt_25_ta_ph.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_ta_ph.bemd_0(212584225);
bevt_27_ta_ph = bevp_heop.bem_fileGet_0();
bevt_26_ta_ph = bevt_27_ta_ph.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_ta_ph.bemd_0(212584225);
bevt_29_ta_ph = bevp_build.bem_paramsGet_0();
bevt_30_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_28_ta_ph = bevt_29_ta_ph.bem_has_1(bevt_30_ta_ph);
if (bevt_28_ta_ph.bevi_bool)/* Line: 466*/ {
bevt_32_ta_ph = bevp_build.bem_paramsGet_0();
bevt_33_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_31_ta_ph = bevt_32_ta_ph.bem_get_1(bevt_33_ta_ph);
bevt_0_ta_loop = bevt_31_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 468*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 468*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(409355098);
bevt_35_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_ta_ph.bem_fileGet_0();
bevt_37_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_36_ta_ph = bevt_37_ta_ph.bemd_0(212584225);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_ta_ph.bemd_0(-1040535372);
bevt_38_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_38_ta_ph.bemd_0(-1469993846);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 474*/
 else /* Line: 468*/ {
break;
} /* Line: 468*/
} /* Line: 468*/
} /* Line: 468*/
bevt_39_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevp_heow.bem_write_1(bevt_39_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
bevp_heow.bem_write_1(bevt_40_ta_ph);
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevp_deow.bem_write_1(bevt_41_ta_ph);
bevt_42_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevp_heow.bem_write_1(bevt_42_ta_ph);
bevt_44_ta_ph = bevp_build.bem_paramsGet_0();
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_43_ta_ph = bevt_44_ta_ph.bem_has_1(bevt_45_ta_ph);
if (bevt_43_ta_ph.bevi_bool)/* Line: 488*/ {
bevt_47_ta_ph = bevp_build.bem_paramsGet_0();
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_127));
bevt_46_ta_ph = bevt_47_ta_ph.bem_get_1(bevt_48_ta_ph);
bevt_1_ta_loop = bevt_46_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 490*/ {
bevt_49_ta_ph = bevt_1_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_49_ta_ph).bevi_bool)/* Line: 490*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(409355098);
bevt_50_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_50_ta_ph.bem_fileGet_0();
bevt_52_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_51_ta_ph = bevt_52_ta_ph.bemd_0(212584225);
bevl_inc = (BEC_2_4_6_TextString) bevt_51_ta_ph.bemd_0(-1040535372);
bevt_53_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_53_ta_ph.bemd_0(-1469993846);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 496*/
 else /* Line: 490*/ {
break;
} /* Line: 490*/
} /* Line: 490*/
} /* Line: 490*/
bevt_55_ta_ph = bevp_build.bem_paramsGet_0();
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_54_ta_ph = bevt_55_ta_ph.bem_has_1(bevt_56_ta_ph);
if (bevt_54_ta_ph.bevi_bool)/* Line: 499*/ {
bevt_58_ta_ph = bevp_build.bem_paramsGet_0();
bevt_59_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_57_ta_ph = bevt_58_ta_ph.bem_get_1(bevt_59_ta_ph);
bevt_2_ta_loop = bevt_57_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 501*/ {
bevt_60_ta_ph = bevt_2_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_60_ta_ph).bevi_bool)/* Line: 501*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_ta_loop.bemd_0(409355098);
bevt_61_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_61_ta_ph.bem_fileGet_0();
bevt_63_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_62_ta_ph = bevt_63_ta_ph.bemd_0(212584225);
bevl_inc = (BEC_2_4_6_TextString) bevt_62_ta_ph.bemd_0(-1040535372);
bevt_64_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_64_ta_ph.bemd_0(-1469993846);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 507*/
 else /* Line: 501*/ {
break;
} /* Line: 501*/
} /* Line: 501*/
} /* Line: 501*/
} /* Line: 499*/
return this;
} /*method end*/
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_2_4_IOFile bevt_5_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_6_ta_ph = null;
BEC_2_2_4_IOFile bevt_7_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_2_4_IOFile bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_15_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_27_ta_ph = null;
BEC_2_6_10_SystemParameters bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_6_6_SystemObject bevt_30_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_4_3_MathInt bevt_35_ta_ph = null;
if (bevp_shlibe == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 520*/ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_6_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_5_ta_ph = bevt_6_ta_ph.bem_fileGet_0();
bevt_4_ta_ph = bevt_5_ta_ph.bem_existsGet_0();
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 522*/ {
bevt_8_ta_ph = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_7_ta_ph = bevt_8_ta_ph.bem_fileGet_0();
bevt_7_ta_ph.bem_makeDirs_0();
} /* Line: 523*/
bevt_10_ta_ph = bevp_libEmitPath.bem_fileGet_0();
bevt_9_ta_ph = bevt_10_ta_ph.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_ta_ph.bemd_0(212584225);
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevp_shlibe.bem_write_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevp_build.bem_paramsGet_0();
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_12_ta_ph = bevt_13_ta_ph.bem_has_1(bevt_14_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 529*/ {
bevt_16_ta_ph = bevp_build.bem_paramsGet_0();
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_15_ta_ph = bevt_16_ta_ph.bem_get_1(bevt_17_ta_ph);
bevt_0_ta_loop = bevt_15_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 531*/ {
bevt_18_ta_ph = bevt_0_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 531*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(409355098);
bevt_19_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_ta_ph.bem_fileGet_0();
bevt_21_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_20_ta_ph = bevt_21_ta_ph.bemd_0(212584225);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_ta_ph.bemd_0(-1040535372);
bevt_22_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_22_ta_ph.bemd_0(-1469993846);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 537*/
 else /* Line: 531*/ {
break;
} /* Line: 531*/
} /* Line: 531*/
} /* Line: 531*/
bevt_23_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_126));
bevp_shlibe.bem_write_1(bevt_23_ta_ph);
bevp_lineCount.bem_increment_0();
bevt_25_ta_ph = bevp_build.bem_paramsGet_0();
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_24_ta_ph = bevt_25_ta_ph.bem_has_1(bevt_26_ta_ph);
if (bevt_24_ta_ph.bevi_bool)/* Line: 543*/ {
bevt_28_ta_ph = bevp_build.bem_paramsGet_0();
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevt_27_ta_ph = bevt_28_ta_ph.bem_get_1(bevt_29_ta_ph);
bevt_1_ta_loop = bevt_27_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 544*/ {
bevt_30_ta_ph = bevt_1_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_30_ta_ph).bevi_bool)/* Line: 544*/ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_ta_loop.bemd_0(409355098);
bevt_31_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_ta_ph.bem_fileGet_0();
bevt_33_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_32_ta_ph = bevt_33_ta_ph.bemd_0(212584225);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_ta_ph.bemd_0(-1040535372);
bevt_34_ta_ph = bevl_jsi.bem_readerGet_0();
bevt_34_ta_ph.bemd_0(-1469993846);
bevt_35_ta_ph = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_ta_ph.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 549*/
 else /* Line: 544*/ {
break;
} /* Line: 544*/
} /* Line: 544*/
} /* Line: 544*/
} /* Line: 543*/
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevp_heow.bem_write_1(bevt_1_ta_ph);
bevt_3_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_2_ta_ph = bevt_3_ta_ph.bem_has_1(bevt_4_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 567*/ {
bevl_mh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevl_mh.bem_addValue_1(bevt_6_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 570*/
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_0_ta_ph = bevt_1_ta_ph.bem_has_1(bevt_2_ta_ph);
if (bevt_0_ta_ph.bevi_bool)/* Line: 583*/ {
bevt_5_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevt_4_ta_ph = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_5_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) bevt_4_ta_ph.bem_addValue_1(beva_belsName);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_3_ta_ph.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 584*/
 else /* Line: 583*/ {
bevt_8_ta_ph = bevp_build.bem_emitChecksGet_0();
bevt_9_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_7_ta_ph = bevt_8_ta_ph.bem_has_1(bevt_9_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 585*/ {
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevt_11_ta_ph = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_12_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) bevt_11_ta_ph.bem_addValue_1(beva_belsName);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_10_ta_ph.bem_addValue_1(bevt_13_ta_ph);
} /* Line: 586*/
} /* Line: 583*/
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevt_1_ta_ph = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_ta_ph.bemd_0(934833595);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_2_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_2_ta_ph.bem_addValue_1(bevt_4_ta_ph);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_ta_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
/* Line: 598*/ {
bevt_5_ta_ph = bevt_0_ta_loop.bemd_0(-1975680234);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 598*/ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_ta_loop.bemd_0(409355098);
if (bevl_first.bevi_bool)/* Line: 599*/ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 600*/
 else /* Line: 601*/ {
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevp_ccMethods.bem_addValue_1(bevt_6_ta_ph);
} /* Line: 602*/
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevt_9_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevl_ptySyn.bem_nameGet_0();
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_7_ta_ph.bem_addValue_1(bevp_q);
} /* Line: 604*/
 else /* Line: 598*/ {
break;
} /* Line: 598*/
} /* Line: 598*/
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_12_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_2_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevl_bein = bevt_0_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_9_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_9_ta_ph);
bevt_10_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_10_ta_ph);
bevt_11_ta_ph = bevp_classConf.bem_emitNameGet_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevt_11_ta_ph);
bevt_12_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_12_ta_ph);
bevt_4_ta_ph = (BEC_2_4_6_TextString) bevt_5_ta_ph.bem_addValue_1(bevl_bein);
bevt_13_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_ta_ph.bem_addValue_1(bevt_13_ta_ph);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
return bevl_bein;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_runtimeInitGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevp_nl);
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_6_TextString bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_4_6_TextString bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_2_4_6_TextString bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_4_6_TextString bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_4_6_TextString bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_5_4_LogicBool bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_4_6_TextString bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_4_6_TextString bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_6_TextString bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_4_6_TextString bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_4_6_TextString bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_4_6_TextString bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
bevt_1_ta_ph = bem_getClassConfig_1(bevp_objectNp);
bevt_2_ta_ph = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_ta_ph.bem_relEmitName_1(bevt_2_ta_ph);
bevt_4_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(782632493);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_ta_ph );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_ta_ph = bem_overrideMtdDecGet_0();
bevt_12_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_ta_ph);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_11_ta_ph = (BEC_2_4_6_TextString) bevt_12_ta_ph.bem_addValue_1(bevt_14_ta_ph);
bevt_15_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_10_ta_ph = (BEC_2_4_6_TextString) bevt_11_ta_ph.bem_addValue_1(bevt_15_ta_ph);
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_9_ta_ph = (BEC_2_4_6_TextString) bevt_10_ta_ph.bem_addValue_1(bevt_16_ta_ph);
bevt_8_ta_ph = (BEC_2_4_6_TextString) bevt_9_ta_ph.bem_addValue_1(bevl_oname);
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_7_ta_ph = (BEC_2_4_6_TextString) bevt_8_ta_ph.bem_addValue_1(bevt_17_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) bevt_7_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_18_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_5_ta_ph = (BEC_2_4_6_TextString) bevt_6_ta_ph.bem_addValue_1(bevt_18_ta_ph);
bevt_5_ta_ph.bem_addValue_1(bevp_nl);
bevl_asnr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_20_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_19_ta_ph = bevt_20_ta_ph.bem_notEquals_1(bevl_oname);
if (bevt_19_ta_ph.bevi_bool)/* Line: 645*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_ta_ph, bevl_asnr);
} /* Line: 646*/
bevt_25_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_24_ta_ph = (BEC_2_4_6_TextString) bevt_25_ta_ph.bem_addValue_1(bevt_26_ta_ph);
bevt_23_ta_ph = (BEC_2_4_6_TextString) bevt_24_ta_ph.bem_addValue_1(bevl_asnr);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_22_ta_ph = (BEC_2_4_6_TextString) bevt_23_ta_ph.bem_addValue_1(bevt_27_ta_ph);
bevt_22_ta_ph.bem_addValue_1(bevp_nl);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_28_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_29_ta_ph);
bevt_28_ta_ph.bem_addValue_1(bevp_nl);
bevt_37_ta_ph = bem_overrideMtdDecGet_0();
bevt_36_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_ta_ph);
bevt_35_ta_ph = (BEC_2_4_6_TextString) bevt_36_ta_ph.bem_addValue_1(bevl_oname);
bevt_38_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_34_ta_ph = (BEC_2_4_6_TextString) bevt_35_ta_ph.bem_addValue_1(bevt_38_ta_ph);
bevt_39_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_33_ta_ph = (BEC_2_4_6_TextString) bevt_34_ta_ph.bem_addValue_1(bevt_39_ta_ph);
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_32_ta_ph = (BEC_2_4_6_TextString) bevt_33_ta_ph.bem_addValue_1(bevt_40_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) bevt_32_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_41_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_30_ta_ph = (BEC_2_4_6_TextString) bevt_31_ta_ph.bem_addValue_1(bevt_41_ta_ph);
bevt_30_ta_ph.bem_addValue_1(bevp_nl);
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_44_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_45_ta_ph);
bevt_43_ta_ph = (BEC_2_4_6_TextString) bevt_44_ta_ph.bem_addValue_1(bevl_stinst);
bevt_46_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_42_ta_ph = (BEC_2_4_6_TextString) bevt_43_ta_ph.bem_addValue_1(bevt_46_ta_ph);
bevt_42_ta_ph.bem_addValue_1(bevp_nl);
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_47_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_48_ta_ph);
bevt_47_ta_ph.bem_addValue_1(bevp_nl);
bevt_55_ta_ph = bem_overrideMtdDecGet_0();
bevt_54_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_55_ta_ph);
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevt_53_ta_ph = (BEC_2_4_6_TextString) bevt_54_ta_ph.bem_addValue_1(bevt_56_ta_ph);
bevt_57_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_52_ta_ph = (BEC_2_4_6_TextString) bevt_53_ta_ph.bem_addValue_1(bevt_57_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_51_ta_ph = (BEC_2_4_6_TextString) bevt_52_ta_ph.bem_addValue_1(bevt_58_ta_ph);
bevt_50_ta_ph = (BEC_2_4_6_TextString) bevt_51_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_59_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_49_ta_ph = (BEC_2_4_6_TextString) bevt_50_ta_ph.bem_addValue_1(bevt_59_ta_ph);
bevt_49_ta_ph.bem_addValue_1(bevp_nl);
bevt_62_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_61_ta_ph = bevt_62_ta_ph.bemd_0(2056024194);
if (bevt_61_ta_ph == null) {
bevt_60_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_60_ta_ph.bevi_bool)/* Line: 665*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 665*/ {
bevt_65_ta_ph = bevp_cnode.bem_heldGet_0();
bevt_64_ta_ph = bevt_65_ta_ph.bemd_0(2056024194);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_1(596540473, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_ta_ph).bevi_bool)/* Line: 665*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 665*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 665*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 665*/ {
bevt_67_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_151));
bevt_66_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_67_ta_ph);
bevt_66_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 666*/
 else /* Line: 667*/ {
bevt_69_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_68_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_69_ta_ph);
bevt_68_ta_ph.bem_addValue_1(bevp_nl);
} /* Line: 668*/
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_70_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_71_ta_ph);
bevt_70_ta_ph.bem_addValue_1(bevp_nl);
bevt_78_ta_ph = bem_overrideMtdDecGet_0();
bevt_77_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_78_ta_ph);
bevt_79_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_153));
bevt_76_ta_ph = (BEC_2_4_6_TextString) bevt_77_ta_ph.bem_addValue_1(bevt_79_ta_ph);
bevt_80_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_75_ta_ph = (BEC_2_4_6_TextString) bevt_76_ta_ph.bem_addValue_1(bevt_80_ta_ph);
bevt_81_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_154));
bevt_74_ta_ph = (BEC_2_4_6_TextString) bevt_75_ta_ph.bem_addValue_1(bevt_81_ta_ph);
bevt_73_ta_ph = (BEC_2_4_6_TextString) bevt_74_ta_ph.bem_addValue_1(bevp_exceptDec);
bevt_82_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_72_ta_ph = (BEC_2_4_6_TextString) bevt_73_ta_ph.bem_addValue_1(bevt_82_ta_ph);
bevt_72_ta_ph.bem_addValue_1(bevp_nl);
bevt_84_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
bevt_83_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_84_ta_ph);
bevt_83_ta_ph.bem_addValue_1(bevp_nl);
bevt_86_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_85_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_86_ta_ph);
bevt_85_ta_ph.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
bevt_89_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_90_ta_ph);
bevt_91_ta_ph = bevl_newcc.bem_emitNameGet_0();
bevt_88_ta_ph = (BEC_2_4_6_TextString) bevt_89_ta_ph.bem_addValue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_157));
bevt_87_ta_ph = (BEC_2_4_6_TextString) bevt_88_ta_ph.bem_addValue_1(bevt_92_ta_ph);
bevt_87_ta_ph.bem_addValue_1(bevp_nl);
bevt_96_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_158));
bevt_95_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_96_ta_ph);
bevt_94_ta_ph = (BEC_2_4_6_TextString) bevt_95_ta_ph.bem_addValue_1(bevl_tinst);
bevt_97_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_93_ta_ph = (BEC_2_4_6_TextString) bevt_94_ta_ph.bem_addValue_1(bevt_97_ta_ph);
bevt_93_ta_ph.bem_addValue_1(bevp_nl);
bevt_99_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_98_ta_ph = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_99_ta_ph);
bevt_98_ta_ph.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_libEmitName);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevp_deow.bem_write_1(bevt_0_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(bevp_libEmitName);
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_159));
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevt_7_ta_ph);
bevp_heow.bem_write_1(bevt_4_ta_ph);
base.bem_emitLib_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_ta_ph);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevl_nccn);
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevl_bein = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_ta_ph = bevl_nccn.bem_add_1(bevt_6_ta_ph);
bevt_4_ta_ph = bevt_5_ta_ph.bem_add_1(bevl_bein);
return bevt_4_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGetDirect_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGetDirect_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGet_0() {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGetDirect_0() {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGet_0() {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGetDirect_0() {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() {
return bevp_deon;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGetDirect_0() {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() {
return bevp_heon;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGetDirect_0() {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() {
return bevp_deop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() {
return bevp_heop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() {
return bevp_deow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() {
return bevp_heow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 21, 22, 23, 24, 25, 29, 31, 32, 33, 34, 35, 39, 43, 43, 44, 44, 44, 46, 46, 48, 48, 48, 48, 48, 48, 50, 50, 51, 51, 53, 53, 55, 55, 55, 55, 55, 55, 55, 57, 57, 59, 59, 61, 61, 64, 64, 66, 66, 68, 70, 72, 74, 76, 76, 77, 77, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 86, 86, 87, 87, 87, 87, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 98, 98, 98, 102, 104, 105, 106, 106, 107, 111, 111, 115, 115, 119, 119, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 126, 128, 128, 128, 128, 128, 128, 130, 130, 130, 130, 130, 130, 130, 130, 130, 130, 132, 134, 134, 140, 140, 140, 140, 141, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 147, 147, 149, 153, 153, 153, 153, 154, 154, 155, 157, 157, 161, 161, 161, 161, 161, 161, 161, 161, 165, 165, 165, 165, 166, 166, 166, 168, 174, 174, 174, 174, 174, 176, 176, 176, 176, 176, 176, 176, 176, 178, 180, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 191, 191, 191, 192, 193, 193, 193, 193, 193, 193, 195, 195, 195, 195, 195, 195, 195, 195, 195, 195, 199, 199, 199, 200, 200, 200, 200, 200, 202, 202, 202, 202, 202, 202, 202, 207, 207, 208, 210, 210, 210, 211, 213, 216, 216, 216, 216, 216, 216, 216, 216, 221, 221, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 226, 226, 226, 226, 226, 226, 226, 226, 226, 228, 228, 228, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 233, 235, 235, 235, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 236, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 238, 240, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 245, 247, 247, 247, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 248, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 252, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 257, 260, 260, 260, 260, 260, 261, 261, 261, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 262, 264, 264, 264, 264, 264, 264, 264, 264, 264, 264, 264, 264, 264, 264, 266, 270, 271, 271, 272, 272, 274, 274, 274, 275, 275, 275, 275, 275, 280, 281, 282, 282, 283, 289, 289, 289, 289, 293, 293, 297, 297, 302, 302, 306, 306, 310, 310, 314, 314, 314, 321, 322, 0, 322, 322, 322, 322, 322, 0, 0, 323, 325, 325, 325, 326, 326, 326, 327, 330, 333, 338, 339, 339, 341, 341, 345, 346, 347, 347, 348, 353, 355, 356, 356, 357, 358, 359, 359, 360, 360, 360, 361, 367, 368, 368, 368, 369, 369, 369, 369, 369, 369, 369, 369, 369, 370, 370, 370, 370, 371, 371, 371, 373, 377, 377, 377, 377, 377, 377, 378, 379, 379, 379, 379, 379, 379, 380, 380, 381, 381, 381, 381, 382, 382, 383, 383, 384, 384, 384, 384, 384, 385, 385, 386, 386, 387, 387, 388, 390, 391, 391, 391, 391, 391, 391, 391, 391, 392, 392, 393, 394, 394, 0, 394, 394, 396, 398, 398, 400, 400, 400, 400, 402, 402, 403, 403, 405, 405, 406, 407, 407, 0, 407, 407, 409, 411, 411, 413, 413, 413, 413, 415, 415, 417, 417, 419, 419, 419, 419, 419, 419, 420, 420, 420, 421, 421, 421, 421, 421, 421, 423, 423, 423, 423, 423, 423, 425, 425, 427, 427, 427, 427, 427, 427, 428, 428, 429, 429, 429, 430, 430, 431, 431, 432, 432, 432, 433, 433, 434, 434, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 436, 437, 437, 437, 437, 437, 437, 437, 437, 437, 438, 439, 441, 441, 442, 442, 454, 454, 455, 456, 456, 456, 456, 456, 456, 456, 457, 457, 457, 457, 457, 457, 457, 458, 458, 459, 459, 460, 460, 460, 460, 460, 461, 461, 461, 463, 463, 463, 464, 464, 464, 466, 466, 466, 468, 468, 468, 468, 0, 468, 468, 470, 470, 471, 471, 471, 472, 472, 474, 478, 478, 479, 479, 481, 481, 482, 482, 488, 488, 488, 490, 490, 490, 490, 0, 490, 490, 492, 492, 493, 493, 493, 494, 494, 496, 499, 499, 499, 501, 501, 501, 501, 0, 501, 501, 503, 503, 504, 504, 504, 505, 505, 507, 514, 515, 520, 520, 521, 522, 522, 522, 522, 522, 523, 523, 523, 525, 525, 525, 527, 527, 529, 529, 529, 531, 531, 531, 531, 0, 531, 531, 533, 533, 534, 534, 534, 535, 535, 537, 541, 541, 542, 543, 543, 543, 544, 544, 544, 544, 0, 544, 544, 545, 545, 546, 546, 546, 547, 547, 548, 548, 549, 555, 560, 561, 563, 563, 565, 565, 567, 567, 567, 568, 569, 569, 569, 570, 573, 574, 579, 579, 583, 583, 583, 584, 584, 584, 584, 584, 585, 585, 585, 586, 586, 586, 586, 586, 592, 592, 593, 595, 595, 595, 595, 597, 598, 0, 598, 598, 600, 602, 602, 604, 604, 604, 604, 604, 604, 608, 608, 608, 613, 615, 615, 615, 615, 615, 617, 617, 617, 617, 617, 617, 617, 617, 617, 617, 617, 619, 623, 623, 624, 624, 624, 624, 625, 629, 629, 630, 630, 630, 630, 631, 631, 631, 631, 635, 635, 635, 639, 639, 639, 640, 640, 640, 641, 643, 643, 643, 643, 643, 643, 643, 643, 643, 643, 643, 643, 643, 643, 643, 644, 645, 645, 646, 646, 649, 649, 649, 649, 649, 649, 649, 651, 651, 651, 654, 654, 654, 654, 654, 654, 654, 654, 654, 654, 654, 654, 654, 659, 659, 659, 659, 659, 659, 662, 662, 662, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 664, 665, 665, 665, 665, 0, 665, 665, 665, 0, 0, 666, 666, 666, 668, 668, 668, 670, 671, 674, 674, 674, 676, 676, 676, 676, 676, 676, 676, 676, 676, 676, 676, 676, 677, 677, 677, 679, 679, 679, 681, 683, 683, 683, 683, 683, 683, 683, 685, 685, 685, 685, 685, 685, 687, 687, 687, 693, 693, 693, 693, 693, 694, 694, 694, 694, 694, 696, 701, 701, 702, 702, 702, 702, 703, 703, 703, 703, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 203, 262, 267, 268, 269, 270, 273, 274, 276, 277, 278, 279, 280, 281, 282, 287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 297, 298, 301, 302, 303, 304, 305, 306, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 424, 425, 426, 427, 428, 429, 433, 434, 438, 439, 443, 444, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 523, 524, 525, 530, 531, 534, 535, 536, 537, 539, 542, 543, 544, 545, 547, 550, 551, 555, 565, 566, 567, 568, 570, 571, 572, 574, 575, 585, 586, 587, 588, 589, 590, 591, 592, 602, 603, 604, 605, 607, 608, 609, 612, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 749, 750, 755, 756, 757, 758, 759, 760, 763, 764, 765, 766, 767, 768, 769, 787, 788, 790, 793, 794, 795, 797, 800, 803, 804, 805, 806, 807, 808, 809, 810, 814, 815, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 931, 932, 933, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 970, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1032, 1033, 1034, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1071, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1134, 1136, 1137, 1138, 1139, 1140, 1141, 1142, 1143, 1145, 1146, 1147, 1148, 1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1158, 1161, 1162, 1163, 1164, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1173, 1174, 1176, 1188, 1189, 1190, 1192, 1193, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1207, 1208, 1209, 1210, 1211, 1218, 1219, 1220, 1221, 1225, 1226, 1230, 1231, 1235, 1236, 1240, 1241, 1245, 1246, 1251, 1252, 1253, 1269, 1270, 1272, 1275, 1276, 1277, 1278, 1283, 1284, 1287, 1291, 1294, 1295, 1296, 1297, 1298, 1299, 1300, 1302, 1304, 1312, 1314, 1315, 1317, 1318, 1324, 1326, 1327, 1328, 1329, 1340, 1342, 1343, 1344, 1345, 1346, 1347, 1352, 1353, 1354, 1355, 1356, 1379, 1380, 1381, 1382, 1384, 1385, 1386, 1387, 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1401, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1563, 1566, 1568, 1570, 1573, 1574, 1576, 1577, 1578, 1579, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1593, 1596, 1598, 1600, 1603, 1604, 1606, 1607, 1608, 1609, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1629, 1630, 1631, 1632, 1633, 1634, 1637, 1638, 1639, 1640, 1641, 1642, 1644, 1645, 1646, 1647, 1648, 1649, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1659, 1660, 1661, 1662, 1663, 1664, 1665, 1666, 1667, 1668, 1669, 1670, 1671, 1672, 1673, 1674, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1684, 1685, 1686, 1687, 1688, 1689, 1690, 1691, 1692, 1693, 1694, 1695, 1768, 1773, 1774, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1783, 1784, 1785, 1786, 1787, 1788, 1789, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1801, 1802, 1803, 1804, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1813, 1814, 1816, 1817, 1818, 1819, 1819, 1822, 1824, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1839, 1840, 1841, 1842, 1843, 1844, 1845, 1846, 1847, 1848, 1849, 1851, 1852, 1853, 1854, 1854, 1857, 1859, 1860, 1861, 1862, 1863, 1864, 1865, 1866, 1867, 1874, 1875, 1876, 1878, 1879, 1880, 1881, 1881, 1884, 1886, 1887, 1888, 1889, 1890, 1891, 1892, 1893, 1894, 1905, 1906, 1949, 1954, 1955, 1956, 1957, 1958, 1959, 1964, 1965, 1966, 1967, 1969, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1978, 1979, 1980, 1981, 1981, 1984, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 2001, 2002, 2003, 2004, 2005, 2006, 2008, 2009, 2010, 2011, 2011, 2014, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2034, 2045, 2046, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2055, 2056, 2057, 2058, 2059, 2061, 2062, 2067, 2068, 2085, 2086, 2087, 2089, 2090, 2091, 2092, 2093, 2096, 2097, 2098, 2100, 2101, 2102, 2103, 2104, 2128, 2129, 2130, 2131, 2132, 2133, 2134, 2135, 2136, 2136, 2139, 2141, 2143, 2146, 2147, 2149, 2150, 2151, 2152, 2153, 2154, 2160, 2161, 2162, 2182, 2183, 2184, 2185, 2186, 2187, 2188, 2189, 2190, 2191, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233, 2234, 2235, 2240, 2241, 2242, 2350, 2351, 2352, 2353, 2354, 2355, 2356, 2357, 2358, 2359, 2360, 2361, 2362, 2363, 2364, 2365, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2376, 2377, 2379, 2380, 2381, 2382, 2383, 2384, 2385, 2386, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2394, 2395, 2396, 2397, 2398, 2399, 2400, 2401, 2402, 2403, 2404, 2405, 2406, 2407, 2408, 2409, 2410, 2411, 2412, 2413, 2414, 2415, 2416, 2417, 2418, 2419, 2420, 2421, 2422, 2423, 2424, 2425, 2430, 2431, 2434, 2435, 2436, 2438, 2441, 2445, 2446, 2447, 2450, 2451, 2452, 2454, 2455, 2456, 2457, 2458, 2459, 2460, 2461, 2462, 2463, 2464, 2465, 2466, 2467, 2468, 2469, 2470, 2471, 2472, 2473, 2474, 2475, 2476, 2477, 2478, 2479, 2480, 2481, 2482, 2483, 2484, 2485, 2486, 2487, 2488, 2489, 2490, 2491, 2492, 2493, 2505, 2506, 2507, 2508, 2509, 2510, 2511, 2512, 2513, 2514, 2515, 2528, 2529, 2530, 2531, 2532, 2533, 2534, 2535, 2536, 2537, 2540, 2543, 2546, 2550, 2554, 2557, 2560, 2564, 2568, 2571, 2574, 2578, 2582, 2585, 2588, 2592, 2596, 2599, 2602, 2606, 2610, 2613, 2616, 2620, 2624, 2627, 2630, 2634, 2638, 2641, 2644, 2648, 2652, 2655, 2658, 2662, 2666, 2669, 2672, 2676, 2680, 2683, 2686, 2690, 2694, 2697, 2700, 2704, 2708, 2711, 2714, 2718};
/* BEGIN LINEINFO 
assign 1 17 186
new 0 17 186
assign 1 18 187
new 0 18 187
assign 1 19 188
new 0 19 188
assign 1 21 189
new 0 21 189
assign 1 22 190
new 0 22 190
assign 1 23 191
new 0 23 191
assign 1 24 192
new 0 24 192
assign 1 25 193
new 0 25 193
new 1 29 194
assign 1 31 195
new 0 31 195
assign 1 32 196
new 0 32 196
assign 1 33 197
new 0 33 197
assign 1 34 198
new 0 34 198
assign 1 35 199
new 0 35 199
addValue 1 39 203
assign 1 43 262
def 1 43 267
assign 1 44 268
libNameGet 0 44 268
assign 1 44 269
relEmitName 1 44 269
assign 1 44 270
extend 1 44 270
assign 1 46 273
new 0 46 273
assign 1 46 274
extend 1 46 274
assign 1 48 276
new 0 48 276
assign 1 48 277
emitNameGet 0 48 277
assign 1 48 278
addValue 1 48 278
assign 1 48 279
addValue 1 48 279
assign 1 48 280
new 0 48 280
assign 1 48 281
addValue 1 48 281
assign 1 50 282
def 1 50 287
assign 1 51 288
new 0 51 288
addValue 1 51 289
assign 1 53 290
new 0 53 290
addValue 1 53 291
assign 1 55 292
new 0 55 292
assign 1 55 293
addValue 1 55 293
assign 1 55 294
libNameGet 0 55 294
assign 1 55 295
relEmitName 1 55 295
assign 1 55 296
addValue 1 55 296
assign 1 55 297
new 0 55 297
addValue 1 55 298
assign 1 57 301
new 0 57 301
addValue 1 57 302
assign 1 59 303
new 0 59 303
addValue 1 59 304
assign 1 61 305
new 0 61 305
addValue 1 61 306
assign 1 64 308
new 0 64 308
addValue 1 64 309
assign 1 66 310
new 0 66 310
addValue 1 66 311
write 1 68 312
write 1 70 313
write 1 72 314
clear 0 74 315
assign 1 76 316
new 0 76 316
write 1 76 317
assign 1 77 318
new 0 77 318
write 1 77 319
assign 1 78 320
new 0 78 320
write 1 78 321
assign 1 79 322
new 0 79 322
assign 1 79 323
emitNameGet 0 79 323
assign 1 79 324
add 1 79 324
assign 1 79 325
new 0 79 325
assign 1 79 326
add 1 79 326
assign 1 79 327
getHeaderInitialInst 1 79 327
assign 1 79 328
add 1 79 328
assign 1 79 329
new 0 79 329
assign 1 79 330
add 1 79 330
write 1 79 331
assign 1 80 332
new 0 80 332
write 1 80 333
assign 1 81 334
new 0 81 334
write 1 81 335
assign 1 82 336
new 0 82 336
write 1 82 337
assign 1 83 338
new 0 83 338
write 1 83 339
assign 1 84 340
new 0 84 340
write 1 84 341
assign 1 85 342
new 0 85 342
write 1 85 343
assign 1 86 344
new 0 86 344
write 1 86 345
assign 1 87 346
new 0 87 346
assign 1 87 347
emitNameGet 0 87 347
assign 1 87 348
add 1 87 348
assign 1 87 349
new 0 87 349
assign 1 87 350
add 1 87 350
write 1 87 351
assign 1 89 352
new 0 89 352
assign 1 89 353
emitNameGet 0 89 353
assign 1 89 354
add 1 89 354
assign 1 89 355
new 0 89 355
assign 1 89 356
add 1 89 356
write 1 89 357
assign 1 91 358
new 0 91 358
return 1 91 359
assign 1 95 389
overrideMtdDecGet 0 95 389
assign 1 95 390
addValue 1 95 390
assign 1 95 391
getClassConfig 1 95 391
assign 1 95 392
libNameGet 0 95 392
assign 1 95 393
relEmitName 1 95 393
assign 1 95 394
addValue 1 95 394
assign 1 95 395
new 0 95 395
assign 1 95 396
addValue 1 95 396
assign 1 95 397
emitNameGet 0 95 397
assign 1 95 398
addValue 1 95 398
assign 1 95 399
new 0 95 399
assign 1 95 400
addValue 1 95 400
assign 1 95 401
addValue 1 95 401
assign 1 95 402
new 0 95 402
assign 1 95 403
addValue 1 95 403
addValue 1 95 404
assign 1 96 405
new 0 96 405
assign 1 96 406
addValue 1 96 406
assign 1 96 407
heldGet 0 96 407
assign 1 96 408
namepathGet 0 96 408
assign 1 96 409
getClassConfig 1 96 409
assign 1 96 410
libNameGet 0 96 410
assign 1 96 411
relEmitName 1 96 411
assign 1 96 412
addValue 1 96 412
assign 1 96 413
new 0 96 413
assign 1 96 414
addValue 1 96 414
addValue 1 96 415
assign 1 98 416
new 0 98 416
assign 1 98 417
addValue 1 98 417
addValue 1 98 418
assign 1 102 424
new 0 102 424
write 1 104 425
clear 0 105 426
assign 1 106 427
new 0 106 427
write 1 106 428
return 1 107 429
assign 1 111 433
new 0 111 433
return 1 111 434
assign 1 115 438
new 0 115 438
return 1 115 439
assign 1 119 443
new 0 119 443
return 1 119 444
assign 1 124 474
addValue 1 124 474
assign 1 124 475
libNameGet 0 124 475
assign 1 124 476
relEmitName 1 124 476
assign 1 124 477
addValue 1 124 477
assign 1 124 478
new 0 124 478
assign 1 124 479
addValue 1 124 479
assign 1 124 480
emitNameGet 0 124 480
assign 1 124 481
addValue 1 124 481
assign 1 124 482
new 0 124 482
assign 1 124 483
addValue 1 124 483
assign 1 124 484
addValue 1 124 484
assign 1 124 485
new 0 124 485
addValue 1 124 486
addValue 1 126 487
assign 1 128 488
new 0 128 488
assign 1 128 489
addValue 1 128 489
assign 1 128 490
addValue 1 128 490
assign 1 128 491
new 0 128 491
assign 1 128 492
addValue 1 128 492
addValue 1 128 493
assign 1 130 494
new 0 130 494
assign 1 130 495
addValue 1 130 495
assign 1 130 496
libNameGet 0 130 496
assign 1 130 497
relEmitName 1 130 497
assign 1 130 498
addValue 1 130 498
assign 1 130 499
new 0 130 499
assign 1 130 500
addValue 1 130 500
assign 1 130 501
addValue 1 130 501
assign 1 130 502
new 0 130 502
addValue 1 130 503
addValue 1 132 504
assign 1 134 505
new 0 134 505
addValue 1 134 506
assign 1 140 523
typenameGet 0 140 523
assign 1 140 524
NULLGet 0 140 524
assign 1 140 525
equals 1 140 530
assign 1 141 531
new 0 141 531
assign 1 142 534
heldGet 0 142 534
assign 1 142 535
nameGet 0 142 535
assign 1 142 536
new 0 142 536
assign 1 142 537
equals 1 142 537
assign 1 143 539
new 0 143 539
assign 1 144 542
heldGet 0 144 542
assign 1 144 543
nameGet 0 144 543
assign 1 144 544
new 0 144 544
assign 1 144 545
equals 1 144 545
assign 1 145 547
new 0 145 547
assign 1 147 550
heldGet 0 147 550
assign 1 147 551
nameForVar 1 147 551
return 1 149 555
assign 1 153 565
heldGet 0 153 565
assign 1 153 566
nameGet 0 153 566
assign 1 153 567
new 0 153 567
assign 1 153 568
equals 1 153 568
assign 1 154 570
new 0 154 570
assign 1 154 571
add 1 154 571
return 1 155 572
assign 1 157 574
formCallTarg 1 157 574
return 1 157 575
assign 1 161 585
new 0 161 585
assign 1 161 586
addValue 1 161 586
assign 1 161 587
secondGet 0 161 587
assign 1 161 588
formTarg 1 161 588
assign 1 161 589
addValue 1 161 589
assign 1 161 590
new 0 161 590
assign 1 161 591
addValue 1 161 591
addValue 1 161 592
assign 1 165 602
heldGet 0 165 602
assign 1 165 603
langsGet 0 165 603
assign 1 165 604
new 0 165 604
assign 1 165 605
has 1 165 605
assign 1 166 607
heldGet 0 166 607
assign 1 166 608
textGet 0 166 608
addValue 1 166 609
handleClassEmit 1 168 612
assign 1 174 654
new 0 174 654
assign 1 174 655
emitNameGet 0 174 655
assign 1 174 656
add 1 174 656
assign 1 174 657
new 0 174 657
assign 1 174 658
add 1 174 658
assign 1 176 659
new 0 176 659
assign 1 176 660
typeEmitNameGet 0 176 660
assign 1 176 661
add 1 176 661
assign 1 176 662
new 0 176 662
assign 1 176 663
add 1 176 663
assign 1 176 664
add 1 176 664
assign 1 176 665
new 0 176 665
assign 1 176 666
add 1 176 666
addClassHeader 1 178 667
assign 1 180 668
new 0 180 668
assign 1 182 669
typeEmitNameGet 0 182 669
assign 1 182 670
addValue 1 182 670
assign 1 182 671
new 0 182 671
assign 1 182 672
addValue 1 182 672
assign 1 182 673
emitNameGet 0 182 673
assign 1 182 674
addValue 1 182 674
assign 1 182 675
new 0 182 675
assign 1 182 676
addValue 1 182 676
assign 1 182 677
addValue 1 182 677
assign 1 182 678
new 0 182 678
addValue 1 182 679
assign 1 184 680
new 0 184 680
assign 1 184 681
addValue 1 184 681
assign 1 184 682
typeEmitNameGet 0 184 682
assign 1 184 683
addValue 1 184 683
assign 1 184 684
new 0 184 684
assign 1 184 685
addValue 1 184 685
assign 1 184 686
emitNameGet 0 184 686
assign 1 184 687
addValue 1 184 687
assign 1 184 688
new 0 184 688
assign 1 184 689
emitNameGet 0 184 689
assign 1 184 690
add 1 184 690
assign 1 184 691
new 0 184 691
assign 1 184 692
add 1 184 692
addValue 1 184 693
return 1 186 694
assign 1 191 714
new 0 191 714
assign 1 191 715
toString 0 191 715
assign 1 191 716
add 1 191 716
incrementValue 0 192 717
assign 1 193 718
new 0 193 718
assign 1 193 719
addValue 1 193 719
assign 1 193 720
addValue 1 193 720
assign 1 193 721
new 0 193 721
assign 1 193 722
addValue 1 193 722
addValue 1 193 723
assign 1 195 724
containedGet 0 195 724
assign 1 195 725
firstGet 0 195 725
assign 1 195 726
containedGet 0 195 726
assign 1 195 727
firstGet 0 195 727
assign 1 195 728
new 0 195 728
assign 1 195 729
add 1 195 729
assign 1 195 730
new 0 195 730
assign 1 195 731
add 1 195 731
assign 1 195 732
finalAssign 4 195 732
addValue 1 195 733
assign 1 199 749
isTypedGet 0 199 749
assign 1 199 750
not 0 199 755
assign 1 200 756
libNameGet 0 200 756
assign 1 200 757
relEmitName 1 200 757
assign 1 200 758
addValue 1 200 758
assign 1 200 759
new 0 200 759
addValue 1 200 760
assign 1 202 763
namepathGet 0 202 763
assign 1 202 764
getClassConfig 1 202 764
assign 1 202 765
libNameGet 0 202 765
assign 1 202 766
relEmitName 1 202 766
assign 1 202 767
addValue 1 202 767
assign 1 202 768
new 0 202 768
addValue 1 202 769
assign 1 207 787
new 0 207 787
assign 1 207 788
equals 1 207 788
assign 1 208 790
new 0 208 790
assign 1 210 793
emitChecksGet 0 210 793
assign 1 210 794
new 0 210 794
assign 1 210 795
has 1 210 795
assign 1 211 797
new 0 211 797
assign 1 213 800
new 0 213 800
assign 1 216 803
new 0 216 803
assign 1 216 804
add 1 216 804
assign 1 216 805
libNameGet 0 216 805
assign 1 216 806
relEmitName 1 216 806
assign 1 216 807
add 1 216 807
assign 1 216 808
new 0 216 808
assign 1 216 809
add 1 216 809
return 1 216 810
assign 1 221 814
new 0 221 814
return 1 221 815
assign 1 225 842
overrideMtdDecGet 0 225 842
assign 1 225 843
addValue 1 225 843
assign 1 225 844
new 0 225 844
assign 1 225 845
addValue 1 225 845
assign 1 225 846
emitNameGet 0 225 846
assign 1 225 847
addValue 1 225 847
assign 1 225 848
new 0 225 848
assign 1 225 849
addValue 1 225 849
assign 1 225 850
addValue 1 225 850
assign 1 225 851
new 0 225 851
assign 1 225 852
addValue 1 225 852
assign 1 225 853
addValue 1 225 853
assign 1 225 854
new 0 225 854
assign 1 225 855
addValue 1 225 855
addValue 1 225 856
assign 1 226 857
new 0 226 857
assign 1 226 858
addValue 1 226 858
assign 1 226 859
addValue 1 226 859
assign 1 226 860
new 0 226 860
assign 1 226 861
addValue 1 226 861
assign 1 226 862
addValue 1 226 862
assign 1 226 863
new 0 226 863
assign 1 226 864
addValue 1 226 864
addValue 1 226 865
assign 1 228 866
new 0 228 866
assign 1 228 867
addValue 1 228 867
addValue 1 228 868
assign 1 233 918
new 0 233 918
assign 1 233 919
libNameGet 0 233 919
assign 1 233 920
relEmitName 1 233 920
assign 1 233 921
add 1 233 921
assign 1 233 922
new 0 233 922
assign 1 233 923
add 1 233 923
assign 1 233 924
heldGet 0 233 924
assign 1 233 925
literalValueGet 0 233 925
assign 1 233 926
add 1 233 926
assign 1 233 927
new 0 233 927
assign 1 233 928
add 1 233 928
return 1 233 929
assign 1 235 931
emitChecksGet 0 235 931
assign 1 235 932
new 0 235 932
assign 1 235 933
has 1 235 933
assign 1 236 935
new 0 236 935
assign 1 236 936
libNameGet 0 236 936
assign 1 236 937
relEmitName 1 236 937
assign 1 236 938
add 1 236 938
assign 1 236 939
new 0 236 939
assign 1 236 940
add 1 236 940
assign 1 236 941
libNameGet 0 236 941
assign 1 236 942
relEmitName 1 236 942
assign 1 236 943
add 1 236 943
assign 1 236 944
new 0 236 944
assign 1 236 945
add 1 236 945
assign 1 236 946
heldGet 0 236 946
assign 1 236 947
literalValueGet 0 236 947
assign 1 236 948
add 1 236 948
assign 1 236 949
new 0 236 949
assign 1 236 950
add 1 236 950
assign 1 238 953
new 0 238 953
assign 1 238 954
libNameGet 0 238 954
assign 1 238 955
relEmitName 1 238 955
assign 1 238 956
add 1 238 956
assign 1 238 957
new 0 238 957
assign 1 238 958
add 1 238 958
assign 1 238 959
libNameGet 0 238 959
assign 1 238 960
relEmitName 1 238 960
assign 1 238 961
add 1 238 961
assign 1 238 962
new 0 238 962
assign 1 238 963
add 1 238 963
assign 1 238 964
heldGet 0 238 964
assign 1 238 965
literalValueGet 0 238 965
assign 1 238 966
add 1 238 966
assign 1 238 967
new 0 238 967
assign 1 238 968
add 1 238 968
return 1 240 970
assign 1 245 1019
new 0 245 1019
assign 1 245 1020
libNameGet 0 245 1020
assign 1 245 1021
relEmitName 1 245 1021
assign 1 245 1022
add 1 245 1022
assign 1 245 1023
new 0 245 1023
assign 1 245 1024
add 1 245 1024
assign 1 245 1025
heldGet 0 245 1025
assign 1 245 1026
literalValueGet 0 245 1026
assign 1 245 1027
add 1 245 1027
assign 1 245 1028
new 0 245 1028
assign 1 245 1029
add 1 245 1029
return 1 245 1030
assign 1 247 1032
emitChecksGet 0 247 1032
assign 1 247 1033
new 0 247 1033
assign 1 247 1034
has 1 247 1034
assign 1 248 1036
new 0 248 1036
assign 1 248 1037
libNameGet 0 248 1037
assign 1 248 1038
relEmitName 1 248 1038
assign 1 248 1039
add 1 248 1039
assign 1 248 1040
new 0 248 1040
assign 1 248 1041
add 1 248 1041
assign 1 248 1042
libNameGet 0 248 1042
assign 1 248 1043
relEmitName 1 248 1043
assign 1 248 1044
add 1 248 1044
assign 1 248 1045
new 0 248 1045
assign 1 248 1046
add 1 248 1046
assign 1 248 1047
heldGet 0 248 1047
assign 1 248 1048
literalValueGet 0 248 1048
assign 1 248 1049
add 1 248 1049
assign 1 248 1050
new 0 248 1050
assign 1 248 1051
add 1 248 1051
assign 1 250 1054
new 0 250 1054
assign 1 250 1055
libNameGet 0 250 1055
assign 1 250 1056
relEmitName 1 250 1056
assign 1 250 1057
add 1 250 1057
assign 1 250 1058
new 0 250 1058
assign 1 250 1059
add 1 250 1059
assign 1 250 1060
libNameGet 0 250 1060
assign 1 250 1061
relEmitName 1 250 1061
assign 1 250 1062
add 1 250 1062
assign 1 250 1063
new 0 250 1063
assign 1 250 1064
add 1 250 1064
assign 1 250 1065
heldGet 0 250 1065
assign 1 250 1066
literalValueGet 0 250 1066
assign 1 250 1067
add 1 250 1067
assign 1 250 1068
new 0 250 1068
assign 1 250 1069
add 1 250 1069
return 1 252 1071
assign 1 257 1122
new 0 257 1122
assign 1 257 1123
libNameGet 0 257 1123
assign 1 257 1124
relEmitName 1 257 1124
assign 1 257 1125
add 1 257 1125
assign 1 257 1126
new 0 257 1126
assign 1 257 1127
add 1 257 1127
assign 1 257 1128
add 1 257 1128
assign 1 257 1129
new 0 257 1129
assign 1 257 1130
add 1 257 1130
assign 1 257 1131
add 1 257 1131
assign 1 257 1132
new 0 257 1132
assign 1 257 1133
add 1 257 1133
return 1 257 1134
assign 1 260 1136
new 0 260 1136
assign 1 260 1137
add 1 260 1137
assign 1 260 1138
new 0 260 1138
assign 1 260 1139
add 1 260 1139
assign 1 260 1140
add 1 260 1140
assign 1 261 1141
emitChecksGet 0 261 1141
assign 1 261 1142
new 0 261 1142
assign 1 261 1143
has 1 261 1143
assign 1 262 1145
new 0 262 1145
assign 1 262 1146
libNameGet 0 262 1146
assign 1 262 1147
relEmitName 1 262 1147
assign 1 262 1148
add 1 262 1148
assign 1 262 1149
new 0 262 1149
assign 1 262 1150
add 1 262 1150
assign 1 262 1151
libNameGet 0 262 1151
assign 1 262 1152
relEmitName 1 262 1152
assign 1 262 1153
add 1 262 1153
assign 1 262 1154
new 0 262 1154
assign 1 262 1155
add 1 262 1155
assign 1 262 1156
add 1 262 1156
assign 1 262 1157
new 0 262 1157
assign 1 262 1158
add 1 262 1158
assign 1 264 1161
new 0 264 1161
assign 1 264 1162
libNameGet 0 264 1162
assign 1 264 1163
relEmitName 1 264 1163
assign 1 264 1164
add 1 264 1164
assign 1 264 1165
new 0 264 1165
assign 1 264 1166
add 1 264 1166
assign 1 264 1167
libNameGet 0 264 1167
assign 1 264 1168
relEmitName 1 264 1168
assign 1 264 1169
add 1 264 1169
assign 1 264 1170
new 0 264 1170
assign 1 264 1171
add 1 264 1171
assign 1 264 1172
add 1 264 1172
assign 1 264 1173
new 0 264 1173
assign 1 264 1174
add 1 264 1174
return 1 266 1176
incrementValue 0 270 1188
assign 1 271 1189
new 0 271 1189
assign 1 271 1190
notEmpty 1 271 1190
assign 1 272 1192
new 0 272 1192
addValue 1 272 1193
assign 1 274 1195
new 0 274 1195
assign 1 274 1196
addValue 1 274 1196
addValue 1 274 1197
assign 1 275 1198
new 0 275 1198
assign 1 275 1199
add 1 275 1199
assign 1 275 1200
new 0 275 1200
assign 1 275 1201
add 1 275 1201
return 1 275 1202
getCode 2 280 1207
assign 1 281 1208
toHexString 1 281 1208
assign 1 282 1209
new 0 282 1209
addValue 1 282 1210
addValue 1 283 1211
assign 1 289 1218
new 0 289 1218
assign 1 289 1219
add 1 289 1219
assign 1 289 1220
add 1 289 1220
return 1 289 1221
assign 1 293 1225
new 0 293 1225
return 1 293 1226
assign 1 297 1230
new 0 297 1230
return 1 297 1231
assign 1 302 1235
new 0 302 1235
return 1 302 1236
assign 1 306 1240
new 0 306 1240
return 1 306 1241
assign 1 310 1245
new 0 310 1245
return 1 310 1246
assign 1 314 1251
new 0 314 1251
assign 1 314 1252
add 1 314 1252
return 1 314 1253
assign 1 321 1269
assign 1 322 1270
singleCCGet 0 322 1270
assign 1 0 1272
assign 1 322 1275
classPathGet 0 322 1275
assign 1 322 1276
fileGet 0 322 1276
assign 1 322 1277
existsGet 0 322 1277
assign 1 322 1278
not 0 322 1283
assign 1 0 1284
assign 1 0 1287
return 1 323 1291
assign 1 325 1294
classPathGet 0 325 1294
assign 1 325 1295
fileGet 0 325 1295
assign 1 325 1296
lastUpdatedGet 0 325 1296
assign 1 326 1297
fromFileGet 0 326 1297
assign 1 326 1298
fileGet 0 326 1298
assign 1 326 1299
lastUpdatedGet 0 326 1299
assign 1 327 1300
greater 1 327 1300
return 1 330 1302
assign 1 333 1304
assign 1 338 1312
singleCCGet 0 338 1312
assign 1 339 1314
getLibOutput 0 339 1314
return 1 339 1315
assign 1 341 1317
getClassOutput 0 341 1317
return 1 341 1318
assign 1 345 1324
singleCCGet 0 345 1324
assign 1 346 1326
new 0 346 1326
assign 1 347 1327
countLines 1 347 1327
addValue 1 347 1328
write 1 348 1329
assign 1 353 1340
singleCCGet 0 353 1340
assign 1 355 1342
new 0 355 1342
assign 1 356 1343
countLines 1 356 1343
addValue 1 356 1344
write 1 357 1345
close 0 358 1346
assign 1 359 1347
def 1 359 1352
assign 1 360 1353
pathGet 0 360 1353
assign 1 360 1354
fileGet 0 360 1354
lastUpdatedSet 1 360 1355
assign 1 361 1356
assign 1 367 1379
new 0 367 1379
assign 1 368 1380
emitChecksGet 0 368 1380
assign 1 368 1381
new 0 368 1381
assign 1 368 1382
has 1 368 1382
assign 1 369 1384
new 0 369 1384
assign 1 369 1385
addValue 1 369 1385
assign 1 369 1386
addValue 1 369 1386
assign 1 369 1387
new 0 369 1387
assign 1 369 1388
addValue 1 369 1388
assign 1 369 1389
addValue 1 369 1389
assign 1 369 1390
new 0 369 1390
assign 1 369 1391
addValue 1 369 1391
addValue 1 369 1392
assign 1 370 1393
addValue 1 370 1393
assign 1 370 1394
new 0 370 1394
assign 1 370 1395
addValue 1 370 1395
addValue 1 370 1396
assign 1 371 1397
new 0 371 1397
assign 1 371 1398
addValue 1 371 1398
addValue 1 371 1399
return 1 373 1401
assign 1 377 1515
new 0 377 1515
assign 1 377 1516
typeEmitNameGet 0 377 1516
assign 1 377 1517
add 1 377 1517
assign 1 377 1518
new 0 377 1518
assign 1 377 1519
add 1 377 1519
write 1 377 1520
assign 1 378 1521
new 0 378 1521
assign 1 379 1522
new 0 379 1522
assign 1 379 1523
addValue 1 379 1523
assign 1 379 1524
typeEmitNameGet 0 379 1524
assign 1 379 1525
addValue 1 379 1525
assign 1 379 1526
new 0 379 1526
addValue 1 379 1527
assign 1 380 1528
new 0 380 1528
addValue 1 380 1529
assign 1 381 1530
typeEmitNameGet 0 381 1530
assign 1 381 1531
addValue 1 381 1531
assign 1 381 1532
new 0 381 1532
addValue 1 381 1533
assign 1 382 1534
new 0 382 1534
addValue 1 382 1535
assign 1 383 1536
new 0 383 1536
addValue 1 383 1537
assign 1 384 1538
new 0 384 1538
assign 1 384 1539
addValue 1 384 1539
assign 1 384 1540
addValue 1 384 1540
assign 1 384 1541
new 0 384 1541
addValue 1 384 1542
assign 1 385 1543
new 0 385 1543
addValue 1 385 1544
assign 1 386 1545
new 0 386 1545
addValue 1 386 1546
assign 1 387 1547
new 0 387 1547
addValue 1 387 1548
write 1 388 1549
assign 1 390 1550
new 0 390 1550
assign 1 391 1551
typeEmitNameGet 0 391 1551
assign 1 391 1552
addValue 1 391 1552
assign 1 391 1553
new 0 391 1553
assign 1 391 1554
addValue 1 391 1554
assign 1 391 1555
typeEmitNameGet 0 391 1555
assign 1 391 1556
addValue 1 391 1556
assign 1 391 1557
new 0 391 1557
addValue 1 391 1558
assign 1 392 1559
new 0 392 1559
addValue 1 392 1560
assign 1 393 1561
new 0 393 1561
assign 1 394 1562
mtdListGet 0 394 1562
assign 1 394 1563
iteratorGet 0 0 1563
assign 1 394 1566
hasNextGet 0 394 1566
assign 1 394 1568
nextGet 0 394 1568
assign 1 396 1570
new 0 396 1570
assign 1 398 1573
new 0 398 1573
addValue 1 398 1574
assign 1 400 1576
addValue 1 400 1576
assign 1 400 1577
nameGet 0 400 1577
assign 1 400 1578
addValue 1 400 1578
addValue 1 400 1579
assign 1 402 1585
new 0 402 1585
addValue 1 402 1586
assign 1 403 1587
new 0 403 1587
addValue 1 403 1588
assign 1 405 1589
new 0 405 1589
addValue 1 405 1590
assign 1 406 1591
new 0 406 1591
assign 1 407 1592
ptyListGet 0 407 1592
assign 1 407 1593
iteratorGet 0 0 1593
assign 1 407 1596
hasNextGet 0 407 1596
assign 1 407 1598
nextGet 0 407 1598
assign 1 409 1600
new 0 409 1600
assign 1 411 1603
new 0 411 1603
addValue 1 411 1604
assign 1 413 1606
addValue 1 413 1606
assign 1 413 1607
nameGet 0 413 1607
assign 1 413 1608
addValue 1 413 1608
addValue 1 413 1609
assign 1 415 1615
new 0 415 1615
addValue 1 415 1616
assign 1 417 1617
new 0 417 1617
addValue 1 417 1618
assign 1 419 1619
new 0 419 1619
assign 1 419 1620
addValue 1 419 1620
assign 1 419 1621
typeEmitNameGet 0 419 1621
assign 1 419 1622
addValue 1 419 1622
assign 1 419 1623
new 0 419 1623
addValue 1 419 1624
assign 1 420 1625
emitNameGet 0 420 1625
assign 1 420 1626
new 0 420 1626
assign 1 420 1627
equals 1 420 1627
assign 1 421 1629
new 0 421 1629
assign 1 421 1630
addValue 1 421 1630
assign 1 421 1631
emitNameGet 0 421 1631
assign 1 421 1632
addValue 1 421 1632
assign 1 421 1633
new 0 421 1633
addValue 1 421 1634
assign 1 423 1637
new 0 423 1637
assign 1 423 1638
addValue 1 423 1638
assign 1 423 1639
emitNameGet 0 423 1639
assign 1 423 1640
addValue 1 423 1640
assign 1 423 1641
new 0 423 1641
addValue 1 423 1642
assign 1 425 1644
new 0 425 1644
addValue 1 425 1645
assign 1 427 1646
new 0 427 1646
assign 1 427 1647
addValue 1 427 1647
assign 1 427 1648
typeEmitNameGet 0 427 1648
assign 1 427 1649
addValue 1 427 1649
assign 1 427 1650
new 0 427 1650
addValue 1 427 1651
assign 1 428 1652
new 0 428 1652
addValue 1 428 1653
assign 1 429 1654
new 0 429 1654
assign 1 429 1655
genMark 1 429 1655
addValue 1 429 1656
assign 1 430 1657
new 0 430 1657
addValue 1 430 1658
assign 1 431 1659
new 0 431 1659
addValue 1 431 1660
assign 1 432 1661
new 0 432 1661
assign 1 432 1662
genMark 1 432 1662
addValue 1 432 1663
assign 1 433 1664
new 0 433 1664
addValue 1 433 1665
assign 1 434 1666
new 0 434 1666
addValue 1 434 1667
assign 1 436 1668
new 0 436 1668
assign 1 436 1669
addValue 1 436 1669
assign 1 436 1670
typeEmitNameGet 0 436 1670
assign 1 436 1671
addValue 1 436 1671
assign 1 436 1672
new 0 436 1672
assign 1 436 1673
addValue 1 436 1673
assign 1 436 1674
addValue 1 436 1674
assign 1 436 1675
new 0 436 1675
assign 1 436 1676
addValue 1 436 1676
assign 1 436 1677
addValue 1 436 1677
assign 1 436 1678
new 0 436 1678
assign 1 436 1679
addValue 1 436 1679
addValue 1 436 1680
assign 1 437 1681
new 0 437 1681
assign 1 437 1682
addValue 1 437 1682
assign 1 437 1683
typeEmitNameGet 0 437 1683
assign 1 437 1684
addValue 1 437 1684
assign 1 437 1685
new 0 437 1685
assign 1 437 1686
addValue 1 437 1686
assign 1 437 1687
addValue 1 437 1687
assign 1 437 1688
new 0 437 1688
addValue 1 437 1689
clear 0 438 1690
assign 1 439 1691
new 0 439 1691
assign 1 441 1692
getClassOutput 0 441 1692
write 1 441 1693
assign 1 442 1694
countLines 1 442 1694
addValue 1 442 1695
assign 1 454 1768
undef 1 454 1773
assign 1 455 1774
libNameGet 0 455 1774
assign 1 456 1775
new 0 456 1775
assign 1 456 1776
sizeGet 0 456 1776
assign 1 456 1777
add 1 456 1777
assign 1 456 1778
new 0 456 1778
assign 1 456 1779
add 1 456 1779
assign 1 456 1780
add 1 456 1780
assign 1 456 1781
add 1 456 1781
assign 1 457 1782
new 0 457 1782
assign 1 457 1783
sizeGet 0 457 1783
assign 1 457 1784
add 1 457 1784
assign 1 457 1785
new 0 457 1785
assign 1 457 1786
add 1 457 1786
assign 1 457 1787
add 1 457 1787
assign 1 457 1788
add 1 457 1788
assign 1 458 1789
parentGet 0 458 1789
assign 1 458 1790
addStep 1 458 1790
assign 1 459 1791
parentGet 0 459 1791
assign 1 459 1792
addStep 1 459 1792
assign 1 460 1793
parentGet 0 460 1793
assign 1 460 1794
fileGet 0 460 1794
assign 1 460 1795
existsGet 0 460 1795
assign 1 460 1796
not 0 460 1801
assign 1 461 1802
parentGet 0 461 1802
assign 1 461 1803
fileGet 0 461 1803
makeDirs 0 461 1804
assign 1 463 1806
fileGet 0 463 1806
assign 1 463 1807
writerGet 0 463 1807
assign 1 463 1808
open 0 463 1808
assign 1 464 1809
fileGet 0 464 1809
assign 1 464 1810
writerGet 0 464 1810
assign 1 464 1811
open 0 464 1811
assign 1 466 1812
paramsGet 0 466 1812
assign 1 466 1813
new 0 466 1813
assign 1 466 1814
has 1 466 1814
assign 1 468 1816
paramsGet 0 468 1816
assign 1 468 1817
new 0 468 1817
assign 1 468 1818
get 1 468 1818
assign 1 468 1819
iteratorGet 0 0 1819
assign 1 468 1822
hasNextGet 0 468 1822
assign 1 468 1824
nextGet 0 468 1824
assign 1 470 1825
apNew 1 470 1825
assign 1 470 1826
fileGet 0 470 1826
assign 1 471 1827
readerGet 0 471 1827
assign 1 471 1828
open 0 471 1828
assign 1 471 1829
readString 0 471 1829
assign 1 472 1830
readerGet 0 472 1830
close 0 472 1831
write 1 474 1832
assign 1 478 1839
new 0 478 1839
write 1 478 1840
assign 1 479 1841
new 0 479 1841
write 1 479 1842
assign 1 481 1843
new 0 481 1843
write 1 481 1844
assign 1 482 1845
new 0 482 1845
write 1 482 1846
assign 1 488 1847
paramsGet 0 488 1847
assign 1 488 1848
new 0 488 1848
assign 1 488 1849
has 1 488 1849
assign 1 490 1851
paramsGet 0 490 1851
assign 1 490 1852
new 0 490 1852
assign 1 490 1853
get 1 490 1853
assign 1 490 1854
iteratorGet 0 0 1854
assign 1 490 1857
hasNextGet 0 490 1857
assign 1 490 1859
nextGet 0 490 1859
assign 1 492 1860
apNew 1 492 1860
assign 1 492 1861
fileGet 0 492 1861
assign 1 493 1862
readerGet 0 493 1862
assign 1 493 1863
open 0 493 1863
assign 1 493 1864
readString 0 493 1864
assign 1 494 1865
readerGet 0 494 1865
close 0 494 1866
write 1 496 1867
assign 1 499 1874
paramsGet 0 499 1874
assign 1 499 1875
new 0 499 1875
assign 1 499 1876
has 1 499 1876
assign 1 501 1878
paramsGet 0 501 1878
assign 1 501 1879
new 0 501 1879
assign 1 501 1880
get 1 501 1880
assign 1 501 1881
iteratorGet 0 0 1881
assign 1 501 1884
hasNextGet 0 501 1884
assign 1 501 1886
nextGet 0 501 1886
assign 1 503 1887
apNew 1 503 1887
assign 1 503 1888
fileGet 0 503 1888
assign 1 504 1889
readerGet 0 504 1889
assign 1 504 1890
open 0 504 1890
assign 1 504 1891
readString 0 504 1891
assign 1 505 1892
readerGet 0 505 1892
close 0 505 1893
write 1 507 1894
begin 1 514 1905
prepHeaderOutput 0 515 1906
assign 1 520 1949
undef 1 520 1954
assign 1 521 1955
new 0 521 1955
assign 1 522 1956
parentGet 0 522 1956
assign 1 522 1957
fileGet 0 522 1957
assign 1 522 1958
existsGet 0 522 1958
assign 1 522 1959
not 0 522 1964
assign 1 523 1965
parentGet 0 523 1965
assign 1 523 1966
fileGet 0 523 1966
makeDirs 0 523 1967
assign 1 525 1969
fileGet 0 525 1969
assign 1 525 1970
writerGet 0 525 1970
assign 1 525 1971
open 0 525 1971
assign 1 527 1972
new 0 527 1972
write 1 527 1973
assign 1 529 1974
paramsGet 0 529 1974
assign 1 529 1975
new 0 529 1975
assign 1 529 1976
has 1 529 1976
assign 1 531 1978
paramsGet 0 531 1978
assign 1 531 1979
new 0 531 1979
assign 1 531 1980
get 1 531 1980
assign 1 531 1981
iteratorGet 0 0 1981
assign 1 531 1984
hasNextGet 0 531 1984
assign 1 531 1986
nextGet 0 531 1986
assign 1 533 1987
apNew 1 533 1987
assign 1 533 1988
fileGet 0 533 1988
assign 1 534 1989
readerGet 0 534 1989
assign 1 534 1990
open 0 534 1990
assign 1 534 1991
readString 0 534 1991
assign 1 535 1992
readerGet 0 535 1992
close 0 535 1993
write 1 537 1994
assign 1 541 2001
new 0 541 2001
write 1 541 2002
increment 0 542 2003
assign 1 543 2004
paramsGet 0 543 2004
assign 1 543 2005
new 0 543 2005
assign 1 543 2006
has 1 543 2006
assign 1 544 2008
paramsGet 0 544 2008
assign 1 544 2009
new 0 544 2009
assign 1 544 2010
get 1 544 2010
assign 1 544 2011
iteratorGet 0 0 2011
assign 1 544 2014
hasNextGet 0 544 2014
assign 1 544 2016
nextGet 0 544 2016
assign 1 545 2017
apNew 1 545 2017
assign 1 545 2018
fileGet 0 545 2018
assign 1 546 2019
readerGet 0 546 2019
assign 1 546 2020
open 0 546 2020
assign 1 546 2021
readString 0 546 2021
assign 1 547 2022
readerGet 0 547 2022
close 0 547 2023
assign 1 548 2024
countLines 1 548 2024
addValue 1 548 2025
write 1 549 2026
return 1 555 2034
close 0 560 2045
assign 1 561 2046
assign 1 563 2047
new 0 563 2047
write 1 563 2048
assign 1 565 2049
new 0 565 2049
write 1 565 2050
assign 1 567 2051
emitChecksGet 0 567 2051
assign 1 567 2052
new 0 567 2052
assign 1 567 2053
has 1 567 2053
assign 1 568 2055
new 0 568 2055
assign 1 569 2056
new 0 569 2056
assign 1 569 2057
addValue 1 569 2057
addValue 1 569 2058
write 1 570 2059
close 0 573 2061
close 0 574 2062
assign 1 579 2067
new 0 579 2067
return 1 579 2068
assign 1 583 2085
emitChecksGet 0 583 2085
assign 1 583 2086
new 0 583 2086
assign 1 583 2087
has 1 583 2087
assign 1 584 2089
new 0 584 2089
assign 1 584 2090
addValue 1 584 2090
assign 1 584 2091
addValue 1 584 2091
assign 1 584 2092
new 0 584 2092
addValue 1 584 2093
assign 1 585 2096
emitChecksGet 0 585 2096
assign 1 585 2097
new 0 585 2097
assign 1 585 2098
has 1 585 2098
assign 1 586 2100
new 0 586 2100
assign 1 586 2101
addValue 1 586 2101
assign 1 586 2102
addValue 1 586 2102
assign 1 586 2103
new 0 586 2103
addValue 1 586 2104
assign 1 592 2128
heldGet 0 592 2128
assign 1 592 2129
synGet 0 592 2129
assign 1 593 2130
ptyListGet 0 593 2130
assign 1 595 2131
emitNameGet 0 595 2131
assign 1 595 2132
addValue 1 595 2132
assign 1 595 2133
new 0 595 2133
addValue 1 595 2134
assign 1 597 2135
new 0 597 2135
assign 1 598 2136
iteratorGet 0 0 2136
assign 1 598 2139
hasNextGet 0 598 2139
assign 1 598 2141
nextGet 0 598 2141
assign 1 600 2143
new 0 600 2143
assign 1 602 2146
new 0 602 2146
addValue 1 602 2147
assign 1 604 2149
addValue 1 604 2149
assign 1 604 2150
new 0 604 2150
assign 1 604 2151
addValue 1 604 2151
assign 1 604 2152
nameGet 0 604 2152
assign 1 604 2153
addValue 1 604 2153
addValue 1 604 2154
assign 1 608 2160
new 0 608 2160
assign 1 608 2161
addValue 1 608 2161
addValue 1 608 2162
assign 1 613 2182
new 0 613 2182
assign 1 615 2183
new 0 615 2183
assign 1 615 2184
emitNameGet 0 615 2184
assign 1 615 2185
add 1 615 2185
assign 1 615 2186
new 0 615 2186
assign 1 615 2187
add 1 615 2187
assign 1 617 2188
emitNameGet 0 617 2188
assign 1 617 2189
addValue 1 617 2189
assign 1 617 2190
new 0 617 2190
assign 1 617 2191
addValue 1 617 2191
assign 1 617 2192
emitNameGet 0 617 2192
assign 1 617 2193
addValue 1 617 2193
assign 1 617 2194
new 0 617 2194
assign 1 617 2195
addValue 1 617 2195
assign 1 617 2196
addValue 1 617 2196
assign 1 617 2197
new 0 617 2197
addValue 1 617 2198
return 1 619 2199
assign 1 623 2208
libNameGet 0 623 2208
assign 1 623 2209
relEmitName 1 623 2209
assign 1 624 2210
new 0 624 2210
assign 1 624 2211
add 1 624 2211
assign 1 624 2212
new 0 624 2212
assign 1 624 2213
add 1 624 2213
return 1 625 2214
assign 1 629 2226
libNameGet 0 629 2226
assign 1 629 2227
relEmitName 1 629 2227
assign 1 630 2228
new 0 630 2228
assign 1 630 2229
add 1 630 2229
assign 1 630 2230
new 0 630 2230
assign 1 630 2231
add 1 630 2231
assign 1 631 2232
new 0 631 2232
assign 1 631 2233
add 1 631 2233
assign 1 631 2234
add 1 631 2234
return 1 631 2235
assign 1 635 2240
new 0 635 2240
assign 1 635 2241
add 1 635 2241
return 1 635 2242
assign 1 639 2350
getClassConfig 1 639 2350
assign 1 639 2351
libNameGet 0 639 2351
assign 1 639 2352
relEmitName 1 639 2352
assign 1 640 2353
heldGet 0 640 2353
assign 1 640 2354
namepathGet 0 640 2354
assign 1 640 2355
getClassConfig 1 640 2355
assign 1 641 2356
getInitialInst 1 641 2356
assign 1 643 2357
overrideMtdDecGet 0 643 2357
assign 1 643 2358
addValue 1 643 2358
assign 1 643 2359
new 0 643 2359
assign 1 643 2360
addValue 1 643 2360
assign 1 643 2361
emitNameGet 0 643 2361
assign 1 643 2362
addValue 1 643 2362
assign 1 643 2363
new 0 643 2363
assign 1 643 2364
addValue 1 643 2364
assign 1 643 2365
addValue 1 643 2365
assign 1 643 2366
new 0 643 2366
assign 1 643 2367
addValue 1 643 2367
assign 1 643 2368
addValue 1 643 2368
assign 1 643 2369
new 0 643 2369
assign 1 643 2370
addValue 1 643 2370
addValue 1 643 2371
assign 1 644 2372
new 0 644 2372
assign 1 645 2373
emitNameGet 0 645 2373
assign 1 645 2374
notEquals 1 645 2374
assign 1 646 2376
new 0 646 2376
assign 1 646 2377
formCast 3 646 2377
assign 1 649 2379
addValue 1 649 2379
assign 1 649 2380
new 0 649 2380
assign 1 649 2381
addValue 1 649 2381
assign 1 649 2382
addValue 1 649 2382
assign 1 649 2383
new 0 649 2383
assign 1 649 2384
addValue 1 649 2384
addValue 1 649 2385
assign 1 651 2386
new 0 651 2386
assign 1 651 2387
addValue 1 651 2387
addValue 1 651 2388
assign 1 654 2389
overrideMtdDecGet 0 654 2389
assign 1 654 2390
addValue 1 654 2390
assign 1 654 2391
addValue 1 654 2391
assign 1 654 2392
new 0 654 2392
assign 1 654 2393
addValue 1 654 2393
assign 1 654 2394
emitNameGet 0 654 2394
assign 1 654 2395
addValue 1 654 2395
assign 1 654 2396
new 0 654 2396
assign 1 654 2397
addValue 1 654 2397
assign 1 654 2398
addValue 1 654 2398
assign 1 654 2399
new 0 654 2399
assign 1 654 2400
addValue 1 654 2400
addValue 1 654 2401
assign 1 659 2402
new 0 659 2402
assign 1 659 2403
addValue 1 659 2403
assign 1 659 2404
addValue 1 659 2404
assign 1 659 2405
new 0 659 2405
assign 1 659 2406
addValue 1 659 2406
addValue 1 659 2407
assign 1 662 2408
new 0 662 2408
assign 1 662 2409
addValue 1 662 2409
addValue 1 662 2410
assign 1 664 2411
overrideMtdDecGet 0 664 2411
assign 1 664 2412
addValue 1 664 2412
assign 1 664 2413
new 0 664 2413
assign 1 664 2414
addValue 1 664 2414
assign 1 664 2415
emitNameGet 0 664 2415
assign 1 664 2416
addValue 1 664 2416
assign 1 664 2417
new 0 664 2417
assign 1 664 2418
addValue 1 664 2418
assign 1 664 2419
addValue 1 664 2419
assign 1 664 2420
new 0 664 2420
assign 1 664 2421
addValue 1 664 2421
addValue 1 664 2422
assign 1 665 2423
heldGet 0 665 2423
assign 1 665 2424
extendsGet 0 665 2424
assign 1 665 2425
undef 1 665 2430
assign 1 0 2431
assign 1 665 2434
heldGet 0 665 2434
assign 1 665 2435
extendsGet 0 665 2435
assign 1 665 2436
equals 1 665 2436
assign 1 0 2438
assign 1 0 2441
assign 1 666 2445
new 0 666 2445
assign 1 666 2446
addValue 1 666 2446
addValue 1 666 2447
assign 1 668 2450
new 0 668 2450
assign 1 668 2451
addValue 1 668 2451
addValue 1 668 2452
addValue 1 670 2454
clear 0 671 2455
assign 1 674 2456
new 0 674 2456
assign 1 674 2457
addValue 1 674 2457
addValue 1 674 2458
assign 1 676 2459
overrideMtdDecGet 0 676 2459
assign 1 676 2460
addValue 1 676 2460
assign 1 676 2461
new 0 676 2461
assign 1 676 2462
addValue 1 676 2462
assign 1 676 2463
emitNameGet 0 676 2463
assign 1 676 2464
addValue 1 676 2464
assign 1 676 2465
new 0 676 2465
assign 1 676 2466
addValue 1 676 2466
assign 1 676 2467
addValue 1 676 2467
assign 1 676 2468
new 0 676 2468
assign 1 676 2469
addValue 1 676 2469
addValue 1 676 2470
assign 1 677 2471
new 0 677 2471
assign 1 677 2472
addValue 1 677 2472
addValue 1 677 2473
assign 1 679 2474
new 0 679 2474
assign 1 679 2475
addValue 1 679 2475
addValue 1 679 2476
assign 1 681 2477
getTypeInst 1 681 2477
assign 1 683 2478
new 0 683 2478
assign 1 683 2479
addValue 1 683 2479
assign 1 683 2480
emitNameGet 0 683 2480
assign 1 683 2481
addValue 1 683 2481
assign 1 683 2482
new 0 683 2482
assign 1 683 2483
addValue 1 683 2483
addValue 1 683 2484
assign 1 685 2485
new 0 685 2485
assign 1 685 2486
addValue 1 685 2486
assign 1 685 2487
addValue 1 685 2487
assign 1 685 2488
new 0 685 2488
assign 1 685 2489
addValue 1 685 2489
addValue 1 685 2490
assign 1 687 2491
new 0 687 2491
assign 1 687 2492
addValue 1 687 2492
addValue 1 687 2493
assign 1 693 2505
new 0 693 2505
assign 1 693 2506
add 1 693 2506
assign 1 693 2507
new 0 693 2507
assign 1 693 2508
add 1 693 2508
write 1 693 2509
assign 1 694 2510
new 0 694 2510
assign 1 694 2511
add 1 694 2511
assign 1 694 2512
new 0 694 2512
assign 1 694 2513
add 1 694 2513
write 1 694 2514
emitLib 0 696 2515
assign 1 701 2528
libNameGet 0 701 2528
assign 1 701 2529
relEmitName 1 701 2529
assign 1 702 2530
new 0 702 2530
assign 1 702 2531
add 1 702 2531
assign 1 702 2532
new 0 702 2532
assign 1 702 2533
add 1 702 2533
assign 1 703 2534
new 0 703 2534
assign 1 703 2535
add 1 703 2535
assign 1 703 2536
add 1 703 2536
return 1 703 2537
return 1 0 2540
return 1 0 2543
assign 1 0 2546
assign 1 0 2550
return 1 0 2554
return 1 0 2557
assign 1 0 2560
assign 1 0 2564
return 1 0 2568
return 1 0 2571
assign 1 0 2574
assign 1 0 2578
return 1 0 2582
return 1 0 2585
assign 1 0 2588
assign 1 0 2592
return 1 0 2596
return 1 0 2599
assign 1 0 2602
assign 1 0 2606
return 1 0 2610
return 1 0 2613
assign 1 0 2616
assign 1 0 2620
return 1 0 2624
return 1 0 2627
assign 1 0 2630
assign 1 0 2634
return 1 0 2638
return 1 0 2641
assign 1 0 2644
assign 1 0 2648
return 1 0 2652
return 1 0 2655
assign 1 0 2658
assign 1 0 2662
return 1 0 2666
return 1 0 2669
assign 1 0 2672
assign 1 0 2676
return 1 0 2680
return 1 0 2683
assign 1 0 2686
assign 1 0 2690
return 1 0 2694
return 1 0 2697
assign 1 0 2700
assign 1 0 2704
return 1 0 2708
return 1 0 2711
assign 1 0 2714
assign 1 0 2718
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1790467505: return bem_saveSyns_0();
case -1858449465: return bem_nameToIdGet_0();
case 41609423: return bem_onceDecRefsGetDirect_0();
case 1823036555: return bem_onceDecsGet_0();
case -60758651: return bem_inFilePathedGetDirect_0();
case 1224263747: return bem_heopGet_0();
case 1597327951: return bem_create_0();
case 361458285: return bem_emitLangGetDirect_0();
case -892428320: return bem_lastMethodBodySizeGet_0();
case -371634322: return bem_exceptDecGet_0();
case -817993994: return bem_cnodeGetDirect_0();
case -2049282719: return bem_fullLibEmitNameGetDirect_0();
case 1714139488: return bem_propertyDecsGet_0();
case -826740154: return bem_ccMethodsGetDirect_0();
case 889734871: return bem_belslitsGet_0();
case -1109163882: return bem_mainOutsideNsGet_0();
case 734337062: return bem_methodCallsGet_0();
case -431471745: return bem_returnTypeGetDirect_0();
case 999662149: return bem_methodCatchGetDirect_0();
case 543913513: return bem_superCallsGetDirect_0();
case -1735678572: return bem_methodCallsGetDirect_0();
case 371157924: return bem_sourceFileNameGet_0();
case -237055860: return bem_useDynMethodsGet_0();
case -245773137: return bem_deonGet_0();
case 567522168: return bem_lastMethodsLinesGetDirect_0();
case -944770653: return bem_headExtGet_0();
case -487972665: return bem_smnlcsGet_0();
case 463788229: return bem_fileExtGet_0();
case 1617040530: return bem_intNpGetDirect_0();
case -2019148434: return bem_classHeadBodyGetDirect_0();
case 1470667102: return bem_buildGet_0();
case 16088203: return bem_nameToIdPathGet_0();
case 1093015569: return bem_buildPropList_0();
case -275210420: return bem_classConfGet_0();
case -1557977439: return bem_msynGetDirect_0();
case -718860559: return bem_shlibeGetDirect_0();
case -1355196047: return bem_methodCatchGet_0();
case 2096186836: return bem_instanceNotEqualGet_0();
case 276317324: return bem_runtimeInitGet_0();
case -1709229402: return bem_invpGet_0();
case 1156355833: return bem_propDecGet_0();
case 445637313: return bem_baseSmtdDecGet_0();
case -1562232274: return bem_smnlcsGetDirect_0();
case -1469937936: return bem_classCallsGetDirect_0();
case 1331843511: return bem_dynMethodsGet_0();
case -1973972385: return bem_classEmitsGetDirect_0();
case 1428031048: return bem_nameToIdGetDirect_0();
case 2006605399: return bem_libEmitNameGet_0();
case 1789892384: return bem_lastCallGetDirect_0();
case 1266491199: return bem_parentConfGetDirect_0();
case 1364594937: return bem_writeBET_0();
case 540970824: return bem_lastMethodsLinesGet_0();
case -514412738: return bem_boolNpGetDirect_0();
case 1422055415: return bem_floatNpGetDirect_0();
case 883299036: return bem_nativeCSlotsGetDirect_0();
case 121287662: return bem_nlGet_0();
case 395403578: return bem_mainInClassGet_0();
case -919758073: return bem_falseValueGet_0();
case 1584545475: return bem_classHeadBodyGet_0();
case 484073492: return bem_falseValueGetDirect_0();
case -1174532882: return bem_fileExtGetDirect_0();
case 404632777: return bem_nullValueGetDirect_0();
case -1760538533: return bem_classNameGet_0();
case -1592040875: return bem_ccCacheGet_0();
case -799255133: return bem_mnodeGet_0();
case -447432319: return bem_many_0();
case 1097162015: return bem_ntypesGet_0();
case 1512843274: return bem_propertyDecsGetDirect_0();
case 781961374: return bem_superNameGet_0();
case 1143803476: return bem_covariantReturnsGet_0();
case 216675699: return bem_fullLibEmitNameGet_0();
case 726663492: return bem_deowGet_0();
case -1302240375: return bem_setOutputTimeGet_0();
case 164845524: return bem_buildInitial_0();
case 1889423242: return bem_beginNs_0();
case 585408479: return bem_ccCacheGetDirect_0();
case 1181145469: return bem_randGet_0();
case 1753504169: return bem_preClassGetDirect_0();
case 698669131: return bem_spropDecGet_0();
case -1270436007: return bem_constGetDirect_0();
case 170363896: return bem_intNpGet_0();
case 409434765: return bem_scvpGet_0();
case 1002702137: return bem_typeDecGet_0();
case -893728208: return bem_onceDecRefsGet_0();
case 46133970: return bem_objectNpGetDirect_0();
case -940161709: return bem_synEmitPathGet_0();
case -1322141523: return bem_lastCallGet_0();
case 1078115428: return bem_lastMethodsSizeGet_0();
case -1242995094: return bem_instOfGetDirect_0();
case -793241295: return bem_iteratorGet_0();
case -2040806524: return bem_newDecGet_0();
case -1786025375: return bem_scvpGetDirect_0();
case 1652521523: return bem_serializeContents_0();
case 560929964: return bem_callNamesGet_0();
case -1117747906: return bem_idToNameGet_0();
case -788356489: return bem_parentConfGet_0();
case 1920668140: return bem_shlibeGet_0();
case 1267521925: return bem_boolCcGetDirect_0();
case -402365244: return bem_smnlecsGet_0();
case 55654440: return bem_qGetDirect_0();
case -1002718399: return bem_idToNamePathGet_0();
case 1314579317: return bem_dynMethodsGetDirect_0();
case -1294051341: return bem_classConfGetDirect_0();
case -793833349: return bem_setOutputTimeGetDirect_0();
case -1202777531: return bem_lastMethodBodySizeGetDirect_0();
case -703954273: return bem_ccMethodsGet_0();
case 551086862: return bem_deonGetDirect_0();
case -1753846910: return bem_loadIds_0();
case -1303453326: return bem_trueValueGet_0();
case 1278293195: return bem_floatNpGet_0();
case -1188922735: return bem_echo_0();
case -451466867: return bem_stringNpGet_0();
case 1905607512: return bem_callNamesGetDirect_0();
case 55053193: return bem_synEmitPathGetDirect_0();
case 1473320256: return bem_mainEndGet_0();
case -1864404418: return bem_onceDecsGetDirect_0();
case 1110684838: return bem_instanceNotEqualGetDirect_0();
case 895193825: return bem_once_0();
case 1604757637: return bem_instanceEqualGet_0();
case 1366752079: return bem_mainStartGet_0();
case 990271367: return bem_libEmitPathGetDirect_0();
case -335109776: return bem_classHeadersGetDirect_0();
case 479020018: return bem_objectCcGetDirect_0();
case 2077601928: return bem_libEmitNameGetDirect_0();
case 1092105192: return bem_hashGet_0();
case -430715150: return bem_heonGet_0();
case -818280407: return bem_nlGetDirect_0();
case 266392128: return bem_onceDecRefsCountGet_0();
case 2006980831: return bem_objectNpGet_0();
case -726878623: return bem_classHeadersGet_0();
case -1004507038: return bem_maxDynArgsGetDirect_0();
case 914615151: return bem_msynGet_0();
case 1928259890: return bem_csynGetDirect_0();
case 774594932: return bem_boolTypeGet_0();
case -1961683054: return bem_getClassOutput_0();
case -1851266374: return bem_csynGet_0();
case 7254011: return bem_fieldIteratorGet_0();
case 1890854002: return bem_tagGet_0();
case -1421515936: return bem_lineCountGet_0();
case -188263053: return bem_ntypesGetDirect_0();
case -1165192912: return bem_cnodeGet_0();
case -13524132: return bem_libEmitPathGet_0();
case 616238128: return bem_deopGet_0();
case -1323898541: return bem_toAny_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -921473949: return bem_fieldNamesGet_0();
case 384422654: return bem_classCallsGet_0();
case 1885310324: return bem_transGet_0();
case 1404199941: return bem_preClassGet_0();
case 151823431: return bem_heopGetDirect_0();
case -380388784: return bem_gcMarksGet_0();
case -2057918797: return bem_classesInDepthOrderGet_0();
case 940840800: return bem_maxSpillArgsLenGetDirect_0();
case -581365998: return bem_emitLangGet_0();
case 2121610934: return bem_buildGetDirect_0();
case -95361141: return bem_qGet_0();
case -625125147: return bem_afterCast_0();
case 617831483: return bem_lastMethodBodyLinesGet_0();
case 1950803603: return bem_exceptDecGetDirect_0();
case -41618036: return bem_gcMarksGetDirect_0();
case -618477722: return bem_onceCountGetDirect_0();
case -1798054597: return bem_idToNamePathGetDirect_0();
case -105946774: return bem_serializeToString_0();
case 1731438654: return bem_superCallsGet_0();
case -2023229076: return bem_inClassGet_0();
case 1547198684: return bem_getLibOutput_0();
case 1319388306: return bem_copy_0();
case -330142374: return bem_trueValueGetDirect_0();
case 1082588771: return bem_lastMethodsSizeGetDirect_0();
case 1927806163: return bem_heowGet_0();
case -627377475: return bem_nameToIdPathGetDirect_0();
case -465904768: return bem_nullValueGet_0();
case 971586696: return bem_transGetDirect_0();
case -257505937: return bem_idToNameGetDirect_0();
case -1231191973: return bem_buildClassInfo_0();
case 251690215: return bem_initialDecGet_0();
case 1870016333: return bem_classEmitsGet_0();
case -1590759630: return bem_preClassOutput_0();
case 2089669280: return bem_lastMethodBodyLinesGetDirect_0();
case -1162755856: return bem_objectCcGet_0();
case 834819986: return bem_methodBodyGet_0();
case -1935640673: return bem_methodsGet_0();
case -833636360: return bem_belslitsGetDirect_0();
case -1010448294: return bem_instOfGet_0();
case 814304829: return bem_nativeCSlotsGet_0();
case 1636079975: return bem_prepHeaderOutput_0();
case -246316025: return bem_overrideMtdDecGet_0();
case 2095178120: return bem_deowGetDirect_0();
case -1363819567: return bem_new_0();
case 133132289: return bem_baseMtdDecGet_0();
case -1832959342: return bem_emitLib_0();
case -1353880313: return bem_heonGetDirect_0();
case 304525154: return bem_randGetDirect_0();
case 1445067893: return bem_invpGetDirect_0();
case 1876360294: return bem_maxDynArgsGet_0();
case -594648963: return bem_constGet_0();
case 524990766: return bem_inClassGetDirect_0();
case -1166815747: return bem_mnodeGetDirect_0();
case 1321020346: return bem_headExtGetDirect_0();
case 397382676: return bem_returnTypeGet_0();
case -1598501627: return bem_inFilePathedGet_0();
case -300478590: return bem_instanceEqualGetDirect_0();
case -209588614: return bem_boolNpGet_0();
case -1190894665: return bem_endNs_0();
case 727954584: return bem_stringNpGetDirect_0();
case 628229029: return bem_smnlecsGetDirect_0();
case -585864672: return bem_heowGetDirect_0();
case -797321775: return bem_deopGetDirect_0();
case -1387831588: return bem_print_0();
case 1709260721: return bem_doEmit_0();
case 73260136: return bem_boolCcGet_0();
case -1513625883: return bem_methodsGetDirect_0();
case 280488183: return bem_methodBodyGetDirect_0();
case 1819789437: return bem_classesInDepthOrderGetDirect_0();
case 1346641342: return bem_onceDecRefsCountGetDirect_0();
case 591559001: return bem_buildCreate_0();
case 542835040: return bem_classEndGet_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -467511392: return bem_toString_0();
case 1974374768: return bem_lineCountGetDirect_0();
case 1178690698: return bem_onceCountGet_0();
case -1224142116: return bem_saveIds_0();
case -785786350: return bem_maxSpillArgsLenGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 509900879: return bem_inClassSetDirect_1(bevd_0);
case -1482433831: return bem_classConfSet_1(bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case 640502850: return bem_classHeadersSet_1(bevd_0);
case 1115965110: return bem_mnodeSetDirect_1(bevd_0);
case -818281241: return bem_constSetDirect_1(bevd_0);
case 600485126: return bem_classConfSetDirect_1(bevd_0);
case -277639662: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case 1758995826: return bem_onceDecRefsSet_1(bevd_0);
case 1929898803: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1429259578: return bem_deonSet_1(bevd_0);
case -1914285233: return bem_nameToIdPathSetDirect_1(bevd_0);
case 2004429120: return bem_exceptDecSetDirect_1(bevd_0);
case 1426365364: return bem_headExtSet_1(bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -2095499858: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 723817677: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 1594232521: return bem_classEmitsSet_1(bevd_0);
case 1774489500: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 274865631: return bem_trueValueSet_1(bevd_0);
case -43940640: return bem_loadIds_1((BEC_2_4_6_TextString) bevd_0);
case 180312666: return bem_classEmitsSetDirect_1(bevd_0);
case 310788392: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1898758013: return bem_methodCatchSet_1(bevd_0);
case 428344616: return bem_lastCallSet_1(bevd_0);
case 1575558496: return bem_nlSet_1(bevd_0);
case -558463194: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 323892706: return bem_stringNpSet_1(bevd_0);
case 2031201288: return bem_returnTypeSet_1(bevd_0);
case -832672837: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case -11084828: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case 393592109: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -383631562: return bem_exceptDecSet_1(bevd_0);
case 1079205384: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 244694785: return bem_classCallsSetDirect_1(bevd_0);
case 1983655486: return bem_onceDecRefsCountSetDirect_1(bevd_0);
case 431494648: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1574006862: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 1883467921: return bem_smnlcsSet_1(bevd_0);
case 677839290: return bem_nameToIdSetDirect_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case 601298448: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -30276354: return bem_scvpSetDirect_1(bevd_0);
case -203855009: return bem_smnlcsSetDirect_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 882109446: return bem_maxDynArgsSet_1(bevd_0);
case -1652564546: return bem_propertyDecsSet_1(bevd_0);
case 2080271532: return bem_lastMethodsLinesSet_1(bevd_0);
case -603986489: return bem_onceDecsSetDirect_1(bevd_0);
case -1617608692: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 36234348: return bem_mnodeSet_1(bevd_0);
case -1193630450: return bem_deonSetDirect_1(bevd_0);
case 850756104: return bem_idToNameSetDirect_1(bevd_0);
case -418880200: return bem_trueValueSetDirect_1(bevd_0);
case 1636332203: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -383714952: return bem_nlSetDirect_1(bevd_0);
case -1700113701: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1054490520: return bem_msynSetDirect_1(bevd_0);
case 254178367: return bem_heowSetDirect_1(bevd_0);
case 1537548678: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -2114226925: return bem_transSet_1(bevd_0);
case -853798251: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 79697672: return bem_onceDecRefsSetDirect_1(bevd_0);
case -9216284: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 1337210542: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case -1979397599: return bem_stringNpSetDirect_1(bevd_0);
case -780422694: return bem_nullValueSet_1(bevd_0);
case -36474717: return bem_setOutputTimeSet_1(bevd_0);
case -874944946: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -904426382: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 2024979222: return bem_instanceEqualSet_1(bevd_0);
case -871351844: return bem_callNamesSet_1(bevd_0);
case -1257889521: return bem_csynSetDirect_1(bevd_0);
case 824347862: return bem_methodCatchSetDirect_1(bevd_0);
case -1230597289: return bem_heopSet_1(bevd_0);
case -2096242764: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1164765213: return bem_shlibeSet_1(bevd_0);
case 2080533711: return bem_inClassSet_1(bevd_0);
case 715757744: return bem_parentConfSet_1(bevd_0);
case 377963742: return bem_classHeadBodySet_1(bevd_0);
case -1242488464: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -1395619451: return bem_parentConfSetDirect_1(bevd_0);
case 612488141: return bem_ccCacheSet_1(bevd_0);
case -2122950095: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 6439337: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -14106061: return bem_nativeCSlotsSet_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1068343358: return bem_maxDynArgsSetDirect_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -572017810: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 473425151: return bem_falseValueSetDirect_1(bevd_0);
case -104163787: return bem_lastCallSetDirect_1(bevd_0);
case -1460164637: return bem_deopSet_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -1747826374: return bem_propertyDecsSetDirect_1(bevd_0);
case -1149114898: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -381230780: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1112333174: return bem_buildSetDirect_1(bevd_0);
case -708734775: return bem_onceDecsSet_1(bevd_0);
case -202497916: return bem_csynSet_1(bevd_0);
case 343500755: return bem_smnlecsSetDirect_1(bevd_0);
case 1737333305: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1633792695: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1380581894: return bem_gcMarksSet_1(bevd_0);
case -519447183: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1383787143: return bem_nameToIdPathSet_1(bevd_0);
case -1965139301: return bem_methodBodySet_1(bevd_0);
case -1772738771: return bem_idToNamePathSetDirect_1(bevd_0);
case -677667804: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1975229229: return bem_methodCallsSet_1(bevd_0);
case 1598285749: return bem_smnlecsSet_1(bevd_0);
case -176107972: return bem_floatNpSet_1(bevd_0);
case 1079729814: return bem_constSet_1(bevd_0);
case 1998020025: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -903013723: return bem_heopSetDirect_1(bevd_0);
case -926817517: return bem_emitLangSet_1(bevd_0);
case -502620636: return bem_gcMarksSetDirect_1(bevd_0);
case 1292658187: return bem_methodsSet_1(bevd_0);
case 1329636983: return bem_nullValueSetDirect_1(bevd_0);
case 1490394685: return bem_qSetDirect_1(bevd_0);
case -1673216481: return bem_ccCacheSetDirect_1(bevd_0);
case -953069175: return bem_classHeadersSetDirect_1(bevd_0);
case 1999470410: return bem_superCallsSet_1(bevd_0);
case -1276604355: return bem_classesInDepthOrderSet_1(bevd_0);
case 498861275: return bem_cnodeSetDirect_1(bevd_0);
case 1420042659: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2048177144: return bem_fileExtSet_1(bevd_0);
case 12810355: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 916924871: return bem_fileExtSetDirect_1(bevd_0);
case -1099297133: return bem_buildSet_1(bevd_0);
case -1345247667: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -186228948: return bem_cnodeSet_1(bevd_0);
case -200758756: return bem_ntypesSet_1(bevd_0);
case 1764582864: return bem_idToNamePathSet_1(bevd_0);
case 934136540: return bem_preClassSetDirect_1(bevd_0);
case 2523520: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -214057008: return bem_instOfSetDirect_1(bevd_0);
case -1095636320: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -786458555: return bem_nameToIdSet_1(bevd_0);
case -1257370053: return bem_instanceEqualSetDirect_1(bevd_0);
case -821993346: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 625713262: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 363351679: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -214928485: return bem_objectNpSet_1(bevd_0);
case -807746843: return bem_falseValueSet_1(bevd_0);
case 1078569526: return bem_boolNpSetDirect_1(bevd_0);
case -31515579: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1366489939: return bem_emitLangSetDirect_1(bevd_0);
case 367262071: return bem_intNpSetDirect_1(bevd_0);
case -583247764: return bem_instOfSet_1(bevd_0);
case -2135396318: return bem_heowSet_1(bevd_0);
case 1666584727: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -386342718: return bem_objectNpSetDirect_1(bevd_0);
case -662064098: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -1250208536: return bem_onceCountSet_1(bevd_0);
case 1777231742: return bem_shlibeSetDirect_1(bevd_0);
case -64781240: return bem_synEmitPathSet_1(bevd_0);
case -1001859495: return bem_setOutputTimeSetDirect_1(bevd_0);
case 1302000426: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1948944511: return bem_callNamesSetDirect_1(bevd_0);
case -198314404: return bem_methodsSetDirect_1(bevd_0);
case -1170077597: return bem_qSet_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -211224673: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1815762396: return bem_randSet_1(bevd_0);
case -1289782987: return bem_ccMethodsSet_1(bevd_0);
case 191075712: return bem_deowSetDirect_1(bevd_0);
case -1039056948: return bem_libEmitPathSet_1(bevd_0);
case 822135248: return bem_fullLibEmitNameSet_1(bevd_0);
case -1872773197: return bem_headExtSetDirect_1(bevd_0);
case 121890637: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -128710627: return bem_begin_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case -1453539676: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -1077033401: return bem_libEmitNameSetDirect_1(bevd_0);
case 1035469982: return bem_ntypesSetDirect_1(bevd_0);
case -1880058179: return bem_msynSet_1(bevd_0);
case -549194306: return bem_lineCountSetDirect_1(bevd_0);
case -1079570532: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 1559953036: return bem_objectCcSetDirect_1(bevd_0);
case -1212724994: return bem_lastMethodsSizeSet_1(bevd_0);
case -884657549: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -228282517: return bem_transSetDirect_1(bevd_0);
case 1932456675: return bem_invpSetDirect_1(bevd_0);
case -599114206: return bem_deopSetDirect_1(bevd_0);
case 1479209416: return bem_instanceNotEqualSet_1(bevd_0);
case 16792187: return bem_onceCountSetDirect_1(bevd_0);
case 1356594415: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -321597811: return bem_libEmitNameSet_1(bevd_0);
case -246756559: return bem_methodBodySetDirect_1(bevd_0);
case -450715677: return bem_preClassSet_1(bevd_0);
case -1857082798: return bem_heonSet_1(bevd_0);
case 1035427040: return bem_boolNpSet_1(bevd_0);
case 2076874172: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1553247118: return bem_classHeadBodySetDirect_1(bevd_0);
case 1486103380: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1232898736: return bem_intNpSet_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -980091309: return bem_dynMethodsSet_1(bevd_0);
case -1718035258: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 868976376: return bem_boolCcSetDirect_1(bevd_0);
case -1805343396: return bem_objectCcSet_1(bevd_0);
case 1498761218: return bem_methodCallsSetDirect_1(bevd_0);
case -1928469599: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -798359611: return bem_inFilePathedSet_1(bevd_0);
case -497467415: return bem_belslitsSet_1(bevd_0);
case 843688664: return bem_ccMethodsSetDirect_1(bevd_0);
case 1524363208: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 331909617: return bem_scvpSet_1(bevd_0);
case 1826271486: return bem_superCallsSetDirect_1(bevd_0);
case 1847276426: return bem_onceDecRefsCountSet_1(bevd_0);
case -1442076951: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -705099828: return bem_end_1(bevd_0);
case 1824611916: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 826701866: return bem_floatNpSetDirect_1(bevd_0);
case 1312974506: return bem_inFilePathedSetDirect_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -1140381197: return bem_randSetDirect_1(bevd_0);
case 1880655935: return bem_belslitsSetDirect_1(bevd_0);
case 343265053: return bem_idToNameSet_1(bevd_0);
case -1839104842: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case 1132345064: return bem_lastMethodBodySizeSet_1(bevd_0);
case -285838677: return bem_heonSetDirect_1(bevd_0);
case -1360939270: return bem_synEmitPathSetDirect_1(bevd_0);
case 451833740: return bem_dynMethodsSetDirect_1(bevd_0);
case -259605614: return bem_invpSet_1(bevd_0);
case -1593320665: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 611932561: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -678180330: return bem_libEmitPathSetDirect_1(bevd_0);
case -1583926695: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1892202366: return bem_maxSpillArgsLenSet_1(bevd_0);
case -754259415: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1513420756: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 1133364399: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 2113585629: return bem_returnTypeSetDirect_1(bevd_0);
case 547279861: return bem_boolCcSet_1(bevd_0);
case 39531210: return bem_deowSet_1(bevd_0);
case 1511394846: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1605846271: return bem_classCallsSet_1(bevd_0);
case -1265496694: return bem_lineCountSet_1(bevd_0);
case 150923335: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -964646268: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case -500961071: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1646641334: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1687722982: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1939362851: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1394598096: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1290471505: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -507260193: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 253012048: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1279295135: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 956381879: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 1023956403: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -403929878: return bem_loadIdsInner_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_9_3_ContainerMap) bevd_2);
case 1120041870: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1363017199: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 946794049: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1627691834: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1032844246: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -1722998094: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 535652683: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1924099879: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCCEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
}
