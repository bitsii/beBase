namespace be {
/* IO:File: source/build/CCEmitter.be */
public sealed class BEC_2_5_9_BuildCCEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
static BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_21, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x2A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_22, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x7E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_31, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x28,0x29,0x20,0x3D,0x20,0x64,0x65,0x66,0x61,0x75,0x6C,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_32, 14));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_10, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_46, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_51, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_21, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_52, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x3A,0x3A,0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_55, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_56, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_57, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x3A,0x3A,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_60, 28));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_39, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x2A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_62, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_65, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x2A,0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_66, 3));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 4));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_39, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x63,0x63,0x53,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x2A,0x29,0x20,0x28,0x62,0x65,0x76,0x73,0x5F,0x73,0x74,0x61,0x63,0x6B,0x46,0x72,0x61,0x6D,0x65,0x2E,0x62,0x65,0x76,0x73,0x5F,0x6C,0x61,0x73,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 45));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x2A,0x29,0x20,0x28,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 8));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 4));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_77, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 45));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x66,0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_78, 3));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 8));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_78, 3));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_72, 4));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_39, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_2, 0));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_79, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_52 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_53 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_74, 45));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_55 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_56 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 8));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_58 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_38, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_59 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_75, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x28,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x29,0x20,0x26};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_60 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_21, 7));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_61 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_22, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_62 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_81, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_63 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_52, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_64 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_83, 19));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_65 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_11, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_66 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_89, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x7D,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_67 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x69,0x66,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x20,0x21,0x3D,0x20,0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72,0x20,0x26,0x26,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x2D,0x3E,0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x21,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x2D,0x3E,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_68 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_10, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_69 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x5D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x2A,0x20,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_70 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_112, 22));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x74,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x20,0x3D,0x20,0x2A,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x62,0x65,0x76,0x73,0x6C,0x5F,0x69,0x6E,0x73,0x74,0x5F,0x72,0x65,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x66,0x6F,0x72,0x20,0x28,0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x69,0x20,0x3D,0x20,0x30,0x3B,0x20,0x69,0x20,0x3C,0x20,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x3B,0x20,0x69,0x2B,0x2B,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20,0x62,0x65,0x76,0x67,0x5F,0x6C,0x65,0x20,0x3D,0x20,0x2A,0x28,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B,0x69,0x5D,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x62,0x65,0x76,0x67,0x5F,0x6C,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x5D,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x7D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {0x3A,0x3A,0x62,0x65,0x76,0x73,0x5F,0x62,0x65,0x76,0x6F,0x5F,0x72,0x65,0x66,0x73,0x5F,0x63,0x6F,0x75,0x6E,0x74,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_71 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_125, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_72 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_126, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_73 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_127, 4));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_74 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_126, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x48,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_75 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_137, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x69,0x6E,0x74,0x20,0x62,0x65,0x6D,0x73,0x5F,0x72,0x65,0x6C,0x6F,0x63,0x4D,0x61,0x69,0x6E,0x28,0x69,0x6E,0x74,0x20,0x61,0x72,0x67,0x63,0x2C,0x20,0x63,0x68,0x61,0x72,0x20,0x2A,0x2A,0x61,0x72,0x67,0x76,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_76 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x63,0x63,0x42,0x67,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_77 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_141, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x2C,0x20,0x67,0x63,0x5F,0x61,0x6C,0x6C,0x6F,0x63,0x61,0x74,0x6F,0x72,0x3C,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x3E,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x5D,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_78 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_79 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_146, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_80 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_81 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_146, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_82 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_83 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_146, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_84 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_5, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_85 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_147, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x2A,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x62,0x65,0x76,0x67,0x5F,0x67,0x63,0x4D,0x61,0x72,0x6B,0x20,0x3D,0x20,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x65,0x76,0x67,0x5F,0x63,0x75,0x72,0x72,0x65,0x6E,0x74,0x47,0x63,0x4D,0x61,0x72,0x6B,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x64,0x6F,0x4D,0x61,0x72,0x6B,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x73,0x69,0x7A,0x65,0x5F,0x74,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_159 = {0x3A,0x3A,0x62,0x65,0x6D,0x67,0x5F,0x67,0x65,0x74,0x53,0x69,0x7A,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_160 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x69,0x7A,0x65,0x6F,0x66,0x28,0x2A,0x74,0x68,0x69,0x73,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_161 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_162 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_163 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_164 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_165 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x42,0x45,0x58,0x5F,0x45,0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x43,0x53,0x5F,0x4C,0x69,0x62,0x20,0x7B,0x0A,0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B,0x0A,0x7D,0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_86 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_50, 5));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_87 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_51, 10));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_88 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_5, 2));
public static new BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static new BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_6_TextString bevp_onceDecRefs;
public BEC_2_4_3_MathInt bevp_onceDecRefsCount;
public BEC_2_4_8_TimeInterval bevp_setOutputTime;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
base.bem_new_1(beva__build);
bevp_invp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 43 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 44 */
 else  /* Line: 45 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 46 */
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
if (bevp_parentConf == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 55 */
 else  /* Line: 56 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_20_tmpany_phold);
} /* Line: 61 */
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_22_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevp_heow.bem_write_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_31_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_34_tmpany_phold);
bevp_heow.bem_write_1(bevt_26_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevp_heow.bem_write_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(51, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_36_tmpany_phold);
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(31, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_29));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_30));
bevp_heow.bem_write_1(bevt_41_tmpany_phold);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_45_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_add_1(bevt_45_tmpany_phold);
bevt_46_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_add_1(bevt_46_tmpany_phold);
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_49_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_50_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_51_tmpany_phold);
bevp_deow.bem_write_1(bevt_47_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_52_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_7_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_22_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-1117649733);
bevt_20_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_21_tmpany_phold );
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_26_tmpany_phold);
bevt_25_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_0_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevp_classHeadBody.bem_addValue_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_22_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_23_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_17_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
bevp_classHeadBody.bem_addValue_1(bevt_26_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_tmpany_phold.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 140 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
} /* Line: 141 */
 else  /* Line: 140 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1041439923);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-390319261, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
} /* Line: 143 */
 else  /* Line: 140 */ {
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1041439923);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(-390319261, bevt_10_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 144 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
} /* Line: 145 */
 else  /* Line: 146 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_11_tmpany_phold );
} /* Line: 147 */
} /* Line: 140 */
} /* Line: 140 */
return bevl_tcall;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1041439923);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-390319261, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevl_tcall = bevt_4_tmpany_phold.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 155 */
bevt_5_tmpany_phold = base.bem_formCallTarg_1(beva_node);
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(350422066);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(479707204, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 165 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1202395188);
bevp_classHeaders.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 166 */
 else  /* Line: 167 */ {
base.bem_handleClassEmit_1(beva_node);
} /* Line: 168 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_8_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevl_clh = bevt_4_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_11_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_25_tmpany_phold);
bevt_26_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevt_24_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevt_22_tmpany_phold.bem_addValue_1(bevt_28_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_32_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_33_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-12868923);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1206759967);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_8_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_4_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_3_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_4_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_2_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
} /* Line: 200 */
 else  /* Line: 201 */ {
bevt_9_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_8_tmpany_phold = bem_getClassConfig_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_61));
bevt_6_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
} /* Line: 202 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
} /* Line: 208 */
 else  /* Line: 209 */ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
} /* Line: 210 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_afterCast_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_67));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_68));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_69));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 228 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-670418413);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 229 */
bevt_12_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 231 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_20_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_23_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_24_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = beva_node.bem_heldGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bemd_0(-670418413);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevl_newCall = bevt_14_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
} /* Line: 232 */
 else  /* Line: 233 */ {
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_36_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_35_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_36_tmpany_phold);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_37_tmpany_phold);
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = beva_node.bem_heldGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-670418413);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevl_newCall = bevt_29_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
} /* Line: 234 */
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 240 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-670418413);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 241 */
bevt_12_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 243 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_21_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_20_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_21_tmpany_phold);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_23_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_24_tmpany_phold);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = beva_node.bem_heldGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bemd_0(-670418413);
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_26_tmpany_phold);
bevt_28_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevl_newCall = bevt_14_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
} /* Line: 244 */
 else  /* Line: 245 */ {
bevt_34_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_41;
bevt_36_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_35_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_36_tmpany_phold);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_35_tmpany_phold);
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_42;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevt_37_tmpany_phold);
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_43;
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = beva_node.bem_heldGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_0(-670418413);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_44;
bevl_newCall = bevt_29_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
} /* Line: 246 */
return bevl_newCall;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevl_litArgs = null;
BEC_2_4_6_TextString bevl_newCall = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 252 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_45;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_46;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_47;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_48;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 253 */
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_49;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_50;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevl_litArgs = bevt_12_tmpany_phold.bem_add_1(beva_belsName);
bevt_17_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_51;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_has_1(bevt_18_tmpany_phold);
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 257 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_52;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_53;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_28_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_54;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevl_litArgs);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_55;
bevl_newCall = bevt_19_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
} /* Line: 258 */
 else  /* Line: 259 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_56;
bevt_39_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_38_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_39_tmpany_phold);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevt_38_tmpany_phold);
bevt_40_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_57;
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_42_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_41_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_42_tmpany_phold);
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevt_43_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_58;
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_add_1(bevt_43_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevl_litArgs);
bevt_44_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_59;
bevl_newCall = bevt_32_tmpany_phold.bem_add_1(bevt_44_tmpany_phold);
} /* Line: 260 */
return bevl_newCall;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevp_onceDecRefsCount.bevi_int++;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_notEmpty_1(bevp_onceDecRefs);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevp_onceDecRefs.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 268 */
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecRefs.bem_addValue_1(bevt_4_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(beva_anyName);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_60;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_typeName);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_61;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_62;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_0_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_63;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_82));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainInClassGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_mainOutsideNsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_64;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_65;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_85));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_86));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1041439923);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
return bevt_18_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_66;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_preClassOutput_0() {
BEC_2_4_8_TimeInterval bevl_outts = null;
BEC_2_4_8_TimeInterval bevl_ints = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
bevp_setOutputTime = null;
bevt_1_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 323 */ {
bevt_5_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 323 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 323 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 323 */ {
return this;
} /* Line: 324 */
 else  /* Line: 325 */ {
bevt_7_tmpany_phold = bevp_classConf.bem_classPathGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevl_outts = bevt_6_tmpany_phold.bem_lastUpdatedGet_0();
bevt_9_tmpany_phold = bevp_inClass.bem_fromFileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1325771815);
bevl_ints = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bemd_0(1193241982);
bevt_10_tmpany_phold = bevl_ints.bem_greater_1(bevl_outts);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 328 */ {
return this;
} /* Line: 331 */
bevp_setOutputTime = bevl_outts;
} /* Line: 334 */
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_1_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 339 */ {
bevt_1_tmpany_phold = bem_getLibOutput_0();
return bevt_1_tmpany_phold;
} /* Line: 340 */
bevt_2_tmpany_phold = base.bem_getClassOutput_0();
return bevt_2_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clns = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 346 */ {
bevl_clns = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clns);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clns);
} /* Line: 349 */
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
BEC_2_4_6_TextString bevl_clend = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_3_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_singleCCGet_0();
if (!(bevt_0_tmpany_phold.bevi_bool)) /* Line: 354 */ {
bevl_clend = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_1_tmpany_phold = bem_countLines_1(bevl_clend);
bevp_lineCount.bevi_int += bevt_1_tmpany_phold.bevi_int;
beva_cle.bem_write_1(bevl_clend);
beva_cle.bem_close_0();
if (bevp_setOutputTime == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 360 */ {
bevt_4_tmpany_phold = beva_cle.bem_pathGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold.bem_lastUpdatedSet_1(bevp_setOutputTime);
bevp_setOutputTime = null;
} /* Line: 362 */
} /* Line: 360 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_genMark_1(BEC_2_4_6_TextString beva_mvn) {
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_67;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_has_1(bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 369 */ {
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(beva_mvn);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_3_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(beva_mvn);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 372 */
return bevl_bet;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_42_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_68;
bevt_5_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_69;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevp_deow.bem_write_1(bevt_2_tmpany_phold);
bevl_beh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_96));
bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_beh.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(55, bece_BEC_2_5_9_BuildCCEmitter_bels_98));
bevl_beh.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_99));
bevl_beh.bem_addValue_1(bevt_17_tmpany_phold);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_100));
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_20_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_101));
bevt_18_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_102));
bevl_beh.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_103));
bevl_beh.bem_addValue_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_104));
bevl_beh.bem_addValue_1(bevt_24_tmpany_phold);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_28_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) bevt_27_tmpany_phold.bem_addValue_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevt_26_tmpany_phold.bem_addValue_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_105));
bevt_25_tmpany_phold.bem_addValue_1(bevt_31_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_106));
bevl_bet.bem_addValue_1(bevt_32_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_33_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_33_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 395 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 395 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(-1738265524);
if (bevl_firstmnsyn.bevi_bool) /* Line: 396 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 397 */
 else  /* Line: 398 */ {
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_bet.bem_addValue_1(bevt_35_tmpany_phold);
} /* Line: 399 */
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_38_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevt_37_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_36_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 401 */
 else  /* Line: 395 */ {
break;
} /* Line: 395 */
} /* Line: 395 */
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevl_bet.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_108));
bevl_bet.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_109));
bevl_bet.bem_addValue_1(bevt_41_tmpany_phold);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_42_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_42_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 408 */ {
bevt_43_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_43_tmpany_phold).bevi_bool) /* Line: 408 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(-1738265524);
if (bevl_firstptsyn.bevi_bool) /* Line: 409 */ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 410 */
 else  /* Line: 411 */ {
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
} /* Line: 412 */
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_47_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) bevt_46_tmpany_phold.bem_addValue_1(bevt_47_tmpany_phold);
bevt_45_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 414 */
 else  /* Line: 408 */ {
break;
} /* Line: 408 */
} /* Line: 408 */
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_107));
bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_bet.bem_addValue_1(bevt_49_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_110));
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_111));
bevt_50_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_57_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_70;
bevt_55_tmpany_phold = bevt_56_tmpany_phold.bem_equals_1(bevt_57_tmpany_phold);
if (bevt_55_tmpany_phold.bevi_bool) /* Line: 421 */ {
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_60_tmpany_phold);
bevt_61_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) bevt_59_tmpany_phold.bem_addValue_1(bevt_61_tmpany_phold);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_58_tmpany_phold.bem_addValue_1(bevt_62_tmpany_phold);
} /* Line: 422 */
 else  /* Line: 423 */ {
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_65_tmpany_phold);
bevt_66_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) bevt_64_tmpany_phold.bem_addValue_1(bevt_66_tmpany_phold);
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_97));
bevt_63_tmpany_phold.bem_addValue_1(bevt_67_tmpany_phold);
} /* Line: 424 */
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_bet.bem_addValue_1(bevt_68_tmpany_phold);
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_71_tmpany_phold);
bevt_72_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) bevt_70_tmpany_phold.bem_addValue_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_114));
bevt_69_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_115));
bevl_bet.bem_addValue_1(bevt_74_tmpany_phold);
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
bevt_75_tmpany_phold = bem_genMark_1(bevt_76_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_75_tmpany_phold);
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(52, bece_BEC_2_5_9_BuildCCEmitter_bels_117));
bevl_bet.bem_addValue_1(bevt_77_tmpany_phold);
bevt_78_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(56, bece_BEC_2_5_9_BuildCCEmitter_bels_118));
bevl_bet.bem_addValue_1(bevt_78_tmpany_phold);
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_79_tmpany_phold = bem_genMark_1(bevt_80_tmpany_phold);
bevl_bet.bem_addValue_1(bevt_79_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_bet.bem_addValue_1(bevt_81_tmpany_phold);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevl_bet.bem_addValue_1(bevt_82_tmpany_phold);
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(17, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) bevt_87_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) bevt_86_tmpany_phold.bem_addValue_1(bevt_93_tmpany_phold);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) bevt_85_tmpany_phold.bem_addValue_1(bevp_onceDecRefs);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) bevt_84_tmpany_phold.bem_addValue_1(bevt_94_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevp_onceDecs.bem_addValue_1(bevt_99_tmpany_phold);
bevt_100_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_101_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(25, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) bevt_97_tmpany_phold.bem_addValue_1(bevt_101_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) bevt_96_tmpany_phold.bem_addValue_1(bevp_onceDecRefsCount);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_95_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevp_onceDecRefs.bem_clear_0();
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_103_tmpany_phold = bem_getClassOutput_0();
bevt_103_tmpany_phold.bem_write_1(bevl_bet);
bevt_104_tmpany_phold = bem_countLines_1(bevl_bet);
bevp_lineCount.bevi_int += bevt_104_tmpany_phold.bevi_int;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_20_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_31_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
if (bevp_deow == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 455 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_71;
bevt_8_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_72;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_4_tmpany_phold.bem_add_1(bevp_headExt);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_73;
bevt_14_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_74;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_10_tmpany_phold.bem_add_1(bevp_headExt);
bevt_16_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_21_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_existsGet_0();
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 461 */ {
bevt_23_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_fileGet_0();
bevt_22_tmpany_phold.bem_makeDirs_0();
} /* Line: 462 */
bevt_25_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_tmpany_phold.bemd_0(-1045111996);
bevt_27_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_tmpany_phold.bemd_0(-1045111996);
bevt_29_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_has_1(bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 467 */ {
bevt_32_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_128));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_get_1(bevt_33_tmpany_phold);
bevt_0_tmpany_loop = bevt_31_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 469 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 469 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1738265524);
bevt_35_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_tmpany_phold.bem_fileGet_0();
bevt_37_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-1045111996);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bemd_0(1103552481);
bevt_38_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_38_tmpany_phold.bemd_0(-2056320704);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 475 */
 else  /* Line: 469 */ {
break;
} /* Line: 469 */
} /* Line: 469 */
} /* Line: 469 */
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevp_deow.bem_write_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_has_1(bevt_45_tmpany_phold);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 489 */ {
bevt_47_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_get_1(bevt_48_tmpany_phold);
bevt_1_tmpany_loop = bevt_46_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 491 */ {
bevt_49_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_49_tmpany_phold).bevi_bool) /* Line: 491 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(-1738265524);
bevt_50_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_50_tmpany_phold.bem_fileGet_0();
bevt_52_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(-1045111996);
bevl_inc = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bemd_0(1103552481);
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_53_tmpany_phold.bemd_0(-2056320704);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 497 */
 else  /* Line: 491 */ {
break;
} /* Line: 491 */
} /* Line: 491 */
} /* Line: 491 */
bevt_55_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_has_1(bevt_56_tmpany_phold);
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 500 */ {
bevt_58_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_get_1(bevt_59_tmpany_phold);
bevt_2_tmpany_loop = bevt_57_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 502 */ {
bevt_60_tmpany_phold = bevt_2_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 502 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(-1738265524);
bevt_61_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_61_tmpany_phold.bem_fileGet_0();
bevt_63_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(-1045111996);
bevl_inc = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bemd_0(1103552481);
bevt_64_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_64_tmpany_phold.bemd_0(-2056320704);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 508 */
 else  /* Line: 502 */ {
break;
} /* Line: 502 */
} /* Line: 502 */
} /* Line: 502 */
} /* Line: 500 */
return this;
} /*method end*/
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_27_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_35_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 521 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_6_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_existsGet_0();
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 523 */ {
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 524 */
bevt_10_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_tmpany_phold.bemd_0(-1045111996);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevp_shlibe.bem_write_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_has_1(bevt_14_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 530 */ {
bevt_16_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_get_1(bevt_17_tmpany_phold);
bevt_0_tmpany_loop = bevt_15_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 532 */ {
bevt_18_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 532 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1738265524);
bevt_19_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_19_tmpany_phold.bem_fileGet_0();
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-1045111996);
bevl_inc = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bemd_0(1103552481);
bevt_22_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_22_tmpany_phold.bemd_0(-2056320704);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 538 */
 else  /* Line: 532 */ {
break;
} /* Line: 532 */
} /* Line: 532 */
} /* Line: 532 */
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevp_shlibe.bem_write_1(bevt_23_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_25_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_has_1(bevt_26_tmpany_phold);
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 544 */ {
bevt_28_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_get_1(bevt_29_tmpany_phold);
bevt_1_tmpany_loop = bevt_27_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 545 */ {
bevt_30_tmpany_phold = bevt_1_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_30_tmpany_phold).bevi_bool) /* Line: 545 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(-1738265524);
bevt_31_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_31_tmpany_phold.bem_fileGet_0();
bevt_33_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-1045111996);
bevl_inc = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bemd_0(1103552481);
bevt_34_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_34_tmpany_phold.bemd_0(-2056320704);
bevt_35_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_35_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 550 */
 else  /* Line: 545 */ {
break;
} /* Line: 545 */
} /* Line: 545 */
} /* Line: 545 */
} /* Line: 544 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
BEC_2_4_6_TextString bevl_mh = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_75;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_has_1(bevt_4_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 568 */ {
bevl_mh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevl_mh.bem_addValue_1(bevt_6_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevp_heow.bem_write_1(bevl_mh);
} /* Line: 571 */
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_covariantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_76;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_has_1(bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 584 */ {
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 585 */
 else  /* Line: 584 */ {
bevt_8_tmpany_phold = bevp_build.bem_emitChecksGet_0();
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_77;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_has_1(bevt_9_tmpany_phold);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 586 */ {
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_12_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevt_10_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
} /* Line: 587 */
} /* Line: 584 */
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(-184726534);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 599 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 599 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(-1738265524);
if (bevl_first.bevi_bool) /* Line: 600 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 601 */
 else  /* Line: 602 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 603 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 605 */
 else  /* Line: 599 */ {
break;
} /* Line: 599 */
} /* Line: 599 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_78;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_79;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_23));
bevt_4_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_80;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_81;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_82;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_83;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_84;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_runtimeInitGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_85;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_11_BuildClassConfig bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
bevt_1_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_1_tmpany_phold.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(-1117649733);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_3_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_13_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_5_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevt_20_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 646 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_21_tmpany_phold, bevl_asnr);
} /* Line: 647 */
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_151));
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevt_25_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevt_24_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevt_23_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_29_tmpany_phold);
bevt_28_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_22));
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_39_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_153));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) bevt_31_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_154));
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_45_tmpany_phold);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) bevt_44_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) bevt_43_tmpany_phold.bem_addValue_1(bevt_46_tmpany_phold);
bevt_42_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_48_tmpany_phold);
bevt_47_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_55_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_55_tmpany_phold);
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) bevt_54_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_57_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevt_53_tmpany_phold.bem_addValue_1(bevt_57_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevt_50_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_49_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_62_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_61_tmpany_phold = bevt_62_tmpany_phold.bemd_0(912240337);
if (bevt_61_tmpany_phold == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 666 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 666 */ {
bevt_65_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_64_tmpany_phold = bevt_65_tmpany_phold.bemd_0(912240337);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_1(-390319261, bevp_objectNp);
if (((BEC_2_5_4_LogicBool) bevt_63_tmpany_phold).bevi_bool) /* Line: 666 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 666 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 666 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 666 */ {
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(47, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_67_tmpany_phold);
bevt_66_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 667 */
 else  /* Line: 668 */ {
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_157));
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_69_tmpany_phold);
bevt_68_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 669 */
bevp_ccMethods.bem_addValue_1(bevp_gcMarks);
bevp_gcMarks.bem_clear_0();
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_71_tmpany_phold);
bevt_70_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_78_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_77_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_78_tmpany_phold);
bevt_79_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_158));
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) bevt_77_tmpany_phold.bem_addValue_1(bevt_79_tmpany_phold);
bevt_80_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) bevt_76_tmpany_phold.bem_addValue_1(bevt_80_tmpany_phold);
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildCCEmitter_bels_159));
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) bevt_75_tmpany_phold.bem_addValue_1(bevt_81_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) bevt_74_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) bevt_73_tmpany_phold.bem_addValue_1(bevt_82_tmpany_phold);
bevt_72_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_160));
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_84_tmpany_phold);
bevt_83_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_86_tmpany_phold);
bevt_85_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_161));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_162));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_163));
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_96_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) bevt_95_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_152));
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) bevt_94_tmpany_phold.bem_addValue_1(bevt_97_tmpany_phold);
bevt_93_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_99_tmpany_phold);
bevt_98_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_164));
bevp_deow.bem_write_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildCCEmitter_bels_165));
bevp_heow.bem_write_1(bevt_1_tmpany_phold);
base.bem_emitLib_0();
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_86;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_87;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_88;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGetDirect_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGetDirect_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGet_0() {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_4_6_TextString bem_onceDecRefsGetDirect_0() {
return bevp_onceDecRefs;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGet_0() {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_4_3_MathInt bem_onceDecRefsCountGetDirect_0() {
return bevp_onceDecRefsCount;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_onceDecRefsCountSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_onceDecRefsCount = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGet_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_setOutputTimeGetDirect_0() {
return bevp_setOutputTime;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_setOutputTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_setOutputTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() {
return bevp_deon;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGetDirect_0() {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() {
return bevp_heon;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGetDirect_0() {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() {
return bevp_deop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() {
return bevp_heop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() {
return bevp_deow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() {
return bevp_heow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 21, 22, 23, 24, 25, 29, 31, 32, 33, 34, 35, 39, 43, 43, 44, 44, 44, 46, 46, 48, 48, 48, 48, 48, 48, 50, 50, 51, 51, 53, 53, 55, 55, 55, 55, 55, 55, 55, 57, 57, 59, 59, 61, 61, 64, 64, 66, 66, 68, 70, 72, 74, 76, 76, 77, 77, 78, 78, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 80, 80, 81, 81, 82, 82, 83, 83, 84, 84, 85, 85, 86, 86, 87, 87, 87, 87, 87, 87, 89, 89, 89, 89, 89, 89, 91, 91, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 95, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96, 98, 98, 98, 102, 104, 105, 106, 106, 107, 111, 111, 115, 115, 119, 119, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 124, 126, 128, 128, 128, 128, 128, 128, 130, 130, 130, 130, 130, 130, 130, 130, 130, 130, 132, 134, 134, 140, 140, 140, 140, 141, 142, 142, 142, 142, 143, 144, 144, 144, 144, 145, 147, 147, 149, 153, 153, 153, 153, 154, 154, 155, 157, 157, 161, 161, 161, 161, 161, 161, 161, 161, 165, 165, 165, 165, 166, 166, 166, 168, 174, 174, 174, 174, 174, 176, 176, 176, 176, 176, 176, 176, 176, 178, 180, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 182, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 184, 186, 191, 191, 191, 192, 193, 193, 193, 193, 193, 193, 195, 195, 195, 195, 195, 195, 195, 195, 195, 195, 199, 199, 199, 200, 200, 200, 200, 200, 202, 202, 202, 202, 202, 202, 202, 207, 207, 208, 210, 212, 212, 212, 212, 212, 212, 212, 212, 217, 217, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 221, 222, 222, 222, 222, 222, 222, 222, 222, 222, 224, 224, 224, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 229, 231, 231, 231, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 232, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 234, 236, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 241, 243, 243, 243, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 244, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 246, 248, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 253, 256, 256, 256, 256, 256, 257, 257, 257, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 258, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 262, 266, 267, 267, 268, 268, 270, 270, 270, 271, 271, 271, 271, 271, 276, 277, 278, 278, 278, 279, 285, 285, 285, 285, 289, 289, 293, 293, 298, 298, 302, 302, 302, 302, 302, 303, 303, 303, 303, 303, 303, 304, 304, 304, 305, 305, 305, 305, 305, 305, 305, 305, 307, 307, 311, 311, 315, 315, 315, 315, 322, 323, 0, 323, 323, 323, 323, 323, 0, 0, 324, 326, 326, 326, 327, 327, 327, 328, 331, 334, 339, 340, 340, 342, 342, 346, 347, 348, 348, 349, 354, 356, 357, 357, 358, 359, 360, 360, 361, 361, 361, 362, 368, 369, 369, 369, 370, 370, 370, 370, 370, 370, 370, 370, 370, 371, 371, 371, 371, 372, 372, 372, 374, 378, 378, 378, 378, 378, 378, 379, 380, 380, 380, 380, 380, 380, 381, 381, 382, 382, 382, 382, 383, 383, 384, 384, 385, 385, 385, 385, 385, 386, 386, 387, 387, 388, 388, 389, 391, 392, 392, 392, 392, 392, 392, 392, 392, 393, 393, 394, 395, 395, 0, 395, 395, 397, 399, 399, 401, 401, 401, 401, 403, 403, 404, 404, 406, 406, 407, 408, 408, 0, 408, 408, 410, 412, 412, 414, 414, 414, 414, 416, 416, 418, 418, 420, 420, 420, 420, 420, 420, 421, 421, 421, 422, 422, 422, 422, 422, 422, 424, 424, 424, 424, 424, 424, 426, 426, 428, 428, 428, 428, 428, 428, 429, 429, 430, 430, 430, 431, 431, 432, 432, 433, 433, 433, 434, 434, 435, 435, 437, 437, 437, 437, 437, 437, 437, 437, 437, 437, 437, 437, 437, 438, 438, 438, 438, 438, 438, 438, 438, 438, 439, 440, 442, 442, 443, 443, 455, 455, 456, 457, 457, 457, 457, 457, 457, 457, 458, 458, 458, 458, 458, 458, 458, 459, 459, 460, 460, 461, 461, 461, 461, 461, 462, 462, 462, 464, 464, 464, 465, 465, 465, 467, 467, 467, 469, 469, 469, 469, 0, 469, 469, 471, 471, 472, 472, 472, 473, 473, 475, 479, 479, 480, 480, 482, 482, 483, 483, 489, 489, 489, 491, 491, 491, 491, 0, 491, 491, 493, 493, 494, 494, 494, 495, 495, 497, 500, 500, 500, 502, 502, 502, 502, 0, 502, 502, 504, 504, 505, 505, 505, 506, 506, 508, 515, 516, 521, 521, 522, 523, 523, 523, 523, 523, 524, 524, 524, 526, 526, 526, 528, 528, 530, 530, 530, 532, 532, 532, 532, 0, 532, 532, 534, 534, 535, 535, 535, 536, 536, 538, 542, 542, 543, 544, 544, 544, 545, 545, 545, 545, 0, 545, 545, 546, 546, 547, 547, 547, 548, 548, 549, 549, 550, 556, 561, 562, 564, 564, 566, 566, 568, 568, 568, 569, 570, 570, 570, 571, 574, 575, 580, 580, 584, 584, 584, 585, 585, 585, 585, 585, 586, 586, 586, 587, 587, 587, 587, 587, 593, 593, 594, 596, 596, 596, 596, 598, 599, 0, 599, 599, 601, 603, 603, 605, 605, 605, 605, 605, 605, 609, 609, 609, 614, 616, 616, 616, 616, 616, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 618, 620, 624, 624, 625, 625, 625, 625, 626, 630, 630, 631, 631, 631, 631, 632, 632, 632, 632, 636, 636, 636, 640, 640, 640, 641, 641, 641, 642, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 644, 645, 646, 646, 647, 647, 650, 650, 650, 650, 650, 650, 650, 652, 652, 652, 655, 655, 655, 655, 655, 655, 655, 655, 655, 655, 655, 655, 655, 660, 660, 660, 660, 660, 660, 663, 663, 663, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 665, 666, 666, 666, 666, 0, 666, 666, 666, 0, 0, 667, 667, 667, 669, 669, 669, 671, 672, 675, 675, 675, 677, 677, 677, 677, 677, 677, 677, 677, 677, 677, 677, 677, 678, 678, 678, 680, 680, 680, 682, 684, 684, 684, 684, 684, 684, 684, 686, 686, 686, 686, 686, 686, 688, 688, 688, 694, 694, 695, 695, 697, 702, 702, 703, 703, 703, 703, 704, 704, 704, 704, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294, 298, 357, 362, 363, 364, 365, 368, 369, 371, 372, 373, 374, 375, 376, 377, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 396, 397, 398, 399, 400, 401, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 519, 520, 521, 522, 523, 524, 528, 529, 533, 534, 538, 539, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 618, 619, 620, 625, 626, 629, 630, 631, 632, 634, 637, 638, 639, 640, 642, 645, 646, 650, 660, 661, 662, 663, 665, 666, 667, 669, 670, 680, 681, 682, 683, 684, 685, 686, 687, 697, 698, 699, 700, 702, 703, 704, 707, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 844, 845, 850, 851, 852, 853, 854, 855, 858, 859, 860, 861, 862, 863, 864, 879, 880, 882, 885, 887, 888, 889, 890, 891, 892, 893, 894, 898, 899, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013, 1015, 1016, 1017, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1054, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1116, 1117, 1118, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1138, 1139, 1140, 1141, 1142, 1143, 1144, 1145, 1146, 1147, 1148, 1149, 1150, 1151, 1152, 1153, 1155, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1260, 1272, 1273, 1274, 1276, 1277, 1279, 1280, 1281, 1282, 1283, 1284, 1285, 1286, 1292, 1293, 1294, 1295, 1296, 1297, 1304, 1305, 1306, 1307, 1311, 1312, 1316, 1317, 1321, 1322, 1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1372, 1373, 1379, 1380, 1381, 1382, 1398, 1399, 1401, 1404, 1405, 1406, 1407, 1412, 1413, 1416, 1420, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1431, 1433, 1441, 1443, 1444, 1446, 1447, 1453, 1455, 1456, 1457, 1458, 1469, 1471, 1472, 1473, 1474, 1475, 1476, 1481, 1482, 1483, 1484, 1485, 1508, 1509, 1510, 1511, 1513, 1514, 1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1530, 1644, 1645, 1646, 1647, 1648, 1649, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1659, 1660, 1661, 1662, 1663, 1664, 1665, 1666, 1667, 1668, 1669, 1670, 1671, 1672, 1673, 1674, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1684, 1685, 1686, 1687, 1688, 1689, 1690, 1691, 1692, 1692, 1695, 1697, 1699, 1702, 1703, 1705, 1706, 1707, 1708, 1714, 1715, 1716, 1717, 1718, 1719, 1720, 1721, 1722, 1722, 1725, 1727, 1729, 1732, 1733, 1735, 1736, 1737, 1738, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1758, 1759, 1760, 1761, 1762, 1763, 1766, 1767, 1768, 1769, 1770, 1771, 1773, 1774, 1775, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1783, 1784, 1785, 1786, 1787, 1788, 1789, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1800, 1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1813, 1814, 1815, 1816, 1817, 1818, 1819, 1820, 1821, 1822, 1823, 1824, 1897, 1902, 1903, 1904, 1905, 1906, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1916, 1917, 1918, 1919, 1920, 1921, 1922, 1923, 1924, 1925, 1930, 1931, 1932, 1933, 1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943, 1945, 1946, 1947, 1948, 1948, 1951, 1953, 1954, 1955, 1956, 1957, 1958, 1959, 1960, 1961, 1968, 1969, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1978, 1980, 1981, 1982, 1983, 1983, 1986, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 2003, 2004, 2005, 2007, 2008, 2009, 2010, 2010, 2013, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2034, 2035, 2078, 2083, 2084, 2085, 2086, 2087, 2088, 2093, 2094, 2095, 2096, 2098, 2099, 2100, 2101, 2102, 2103, 2104, 2105, 2107, 2108, 2109, 2110, 2110, 2113, 2115, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2130, 2131, 2132, 2133, 2134, 2135, 2137, 2138, 2139, 2140, 2140, 2143, 2145, 2146, 2147, 2148, 2149, 2150, 2151, 2152, 2153, 2154, 2155, 2163, 2174, 2175, 2176, 2177, 2178, 2179, 2180, 2181, 2182, 2184, 2185, 2186, 2187, 2188, 2190, 2191, 2196, 2197, 2214, 2215, 2216, 2218, 2219, 2220, 2221, 2222, 2225, 2226, 2227, 2229, 2230, 2231, 2232, 2233, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2265, 2268, 2270, 2272, 2275, 2276, 2278, 2279, 2280, 2281, 2282, 2283, 2289, 2290, 2291, 2311, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2337, 2338, 2339, 2340, 2341, 2342, 2343, 2355, 2356, 2357, 2358, 2359, 2360, 2361, 2362, 2363, 2364, 2369, 2370, 2371, 2479, 2480, 2481, 2482, 2483, 2484, 2485, 2486, 2487, 2488, 2489, 2490, 2491, 2492, 2493, 2494, 2495, 2496, 2497, 2498, 2499, 2500, 2501, 2502, 2503, 2505, 2506, 2508, 2509, 2510, 2511, 2512, 2513, 2514, 2515, 2516, 2517, 2518, 2519, 2520, 2521, 2522, 2523, 2524, 2525, 2526, 2527, 2528, 2529, 2530, 2531, 2532, 2533, 2534, 2535, 2536, 2537, 2538, 2539, 2540, 2541, 2542, 2543, 2544, 2545, 2546, 2547, 2548, 2549, 2550, 2551, 2552, 2553, 2554, 2559, 2560, 2563, 2564, 2565, 2567, 2570, 2574, 2575, 2576, 2579, 2580, 2581, 2583, 2584, 2585, 2586, 2587, 2588, 2589, 2590, 2591, 2592, 2593, 2594, 2595, 2596, 2597, 2598, 2599, 2600, 2601, 2602, 2603, 2604, 2605, 2606, 2607, 2608, 2609, 2610, 2611, 2612, 2613, 2614, 2615, 2616, 2617, 2618, 2619, 2620, 2621, 2622, 2628, 2629, 2630, 2631, 2632, 2645, 2646, 2647, 2648, 2649, 2650, 2651, 2652, 2653, 2654, 2657, 2660, 2663, 2667, 2671, 2674, 2677, 2681, 2685, 2688, 2691, 2695, 2699, 2702, 2705, 2709, 2713, 2716, 2719, 2723, 2727, 2730, 2733, 2737, 2741, 2744, 2747, 2751, 2755, 2758, 2761, 2765, 2769, 2772, 2775, 2779, 2783, 2786, 2789, 2793, 2797, 2800, 2803, 2807, 2811, 2814, 2817, 2821, 2825, 2828, 2831, 2835};
/* BEGIN LINEINFO 
assign 1 17 281
new 0 17 281
assign 1 18 282
new 0 18 282
assign 1 19 283
new 0 19 283
assign 1 21 284
new 0 21 284
assign 1 22 285
new 0 22 285
assign 1 23 286
new 0 23 286
assign 1 24 287
new 0 24 287
assign 1 25 288
new 0 25 288
new 1 29 289
assign 1 31 290
new 0 31 290
assign 1 32 291
new 0 32 291
assign 1 33 292
new 0 33 292
assign 1 34 293
new 0 34 293
assign 1 35 294
new 0 35 294
addValue 1 39 298
assign 1 43 357
def 1 43 362
assign 1 44 363
libNameGet 0 44 363
assign 1 44 364
relEmitName 1 44 364
assign 1 44 365
extend 1 44 365
assign 1 46 368
new 0 46 368
assign 1 46 369
extend 1 46 369
assign 1 48 371
new 0 48 371
assign 1 48 372
emitNameGet 0 48 372
assign 1 48 373
addValue 1 48 373
assign 1 48 374
addValue 1 48 374
assign 1 48 375
new 0 48 375
assign 1 48 376
addValue 1 48 376
assign 1 50 377
def 1 50 382
assign 1 51 383
new 0 51 383
addValue 1 51 384
assign 1 53 385
new 0 53 385
addValue 1 53 386
assign 1 55 387
new 0 55 387
assign 1 55 388
addValue 1 55 388
assign 1 55 389
libNameGet 0 55 389
assign 1 55 390
relEmitName 1 55 390
assign 1 55 391
addValue 1 55 391
assign 1 55 392
new 0 55 392
addValue 1 55 393
assign 1 57 396
new 0 57 396
addValue 1 57 397
assign 1 59 398
new 0 59 398
addValue 1 59 399
assign 1 61 400
new 0 61 400
addValue 1 61 401
assign 1 64 403
new 0 64 403
addValue 1 64 404
assign 1 66 405
new 0 66 405
addValue 1 66 406
write 1 68 407
write 1 70 408
write 1 72 409
clear 0 74 410
assign 1 76 411
new 0 76 411
write 1 76 412
assign 1 77 413
new 0 77 413
write 1 77 414
assign 1 78 415
new 0 78 415
write 1 78 416
assign 1 79 417
new 0 79 417
assign 1 79 418
emitNameGet 0 79 418
assign 1 79 419
add 1 79 419
assign 1 79 420
new 0 79 420
assign 1 79 421
add 1 79 421
assign 1 79 422
getHeaderInitialInst 1 79 422
assign 1 79 423
add 1 79 423
assign 1 79 424
new 0 79 424
assign 1 79 425
add 1 79 425
write 1 79 426
assign 1 80 427
new 0 80 427
write 1 80 428
assign 1 81 429
new 0 81 429
write 1 81 430
assign 1 82 431
new 0 82 431
write 1 82 432
assign 1 83 433
new 0 83 433
write 1 83 434
assign 1 84 435
new 0 84 435
write 1 84 436
assign 1 85 437
new 0 85 437
write 1 85 438
assign 1 86 439
new 0 86 439
write 1 86 440
assign 1 87 441
new 0 87 441
assign 1 87 442
emitNameGet 0 87 442
assign 1 87 443
add 1 87 443
assign 1 87 444
new 0 87 444
assign 1 87 445
add 1 87 445
write 1 87 446
assign 1 89 447
new 0 89 447
assign 1 89 448
emitNameGet 0 89 448
assign 1 89 449
add 1 89 449
assign 1 89 450
new 0 89 450
assign 1 89 451
add 1 89 451
write 1 89 452
assign 1 91 453
new 0 91 453
return 1 91 454
assign 1 95 484
overrideMtdDecGet 0 95 484
assign 1 95 485
addValue 1 95 485
assign 1 95 486
getClassConfig 1 95 486
assign 1 95 487
libNameGet 0 95 487
assign 1 95 488
relEmitName 1 95 488
assign 1 95 489
addValue 1 95 489
assign 1 95 490
new 0 95 490
assign 1 95 491
addValue 1 95 491
assign 1 95 492
emitNameGet 0 95 492
assign 1 95 493
addValue 1 95 493
assign 1 95 494
new 0 95 494
assign 1 95 495
addValue 1 95 495
assign 1 95 496
addValue 1 95 496
assign 1 95 497
new 0 95 497
assign 1 95 498
addValue 1 95 498
addValue 1 95 499
assign 1 96 500
new 0 96 500
assign 1 96 501
addValue 1 96 501
assign 1 96 502
heldGet 0 96 502
assign 1 96 503
namepathGet 0 96 503
assign 1 96 504
getClassConfig 1 96 504
assign 1 96 505
libNameGet 0 96 505
assign 1 96 506
relEmitName 1 96 506
assign 1 96 507
addValue 1 96 507
assign 1 96 508
new 0 96 508
assign 1 96 509
addValue 1 96 509
addValue 1 96 510
assign 1 98 511
new 0 98 511
assign 1 98 512
addValue 1 98 512
addValue 1 98 513
assign 1 102 519
new 0 102 519
write 1 104 520
clear 0 105 521
assign 1 106 522
new 0 106 522
write 1 106 523
return 1 107 524
assign 1 111 528
new 0 111 528
return 1 111 529
assign 1 115 533
new 0 115 533
return 1 115 534
assign 1 119 538
new 0 119 538
return 1 119 539
assign 1 124 569
addValue 1 124 569
assign 1 124 570
libNameGet 0 124 570
assign 1 124 571
relEmitName 1 124 571
assign 1 124 572
addValue 1 124 572
assign 1 124 573
new 0 124 573
assign 1 124 574
addValue 1 124 574
assign 1 124 575
emitNameGet 0 124 575
assign 1 124 576
addValue 1 124 576
assign 1 124 577
new 0 124 577
assign 1 124 578
addValue 1 124 578
assign 1 124 579
addValue 1 124 579
assign 1 124 580
new 0 124 580
addValue 1 124 581
addValue 1 126 582
assign 1 128 583
new 0 128 583
assign 1 128 584
addValue 1 128 584
assign 1 128 585
addValue 1 128 585
assign 1 128 586
new 0 128 586
assign 1 128 587
addValue 1 128 587
addValue 1 128 588
assign 1 130 589
new 0 130 589
assign 1 130 590
addValue 1 130 590
assign 1 130 591
libNameGet 0 130 591
assign 1 130 592
relEmitName 1 130 592
assign 1 130 593
addValue 1 130 593
assign 1 130 594
new 0 130 594
assign 1 130 595
addValue 1 130 595
assign 1 130 596
addValue 1 130 596
assign 1 130 597
new 0 130 597
addValue 1 130 598
addValue 1 132 599
assign 1 134 600
new 0 134 600
addValue 1 134 601
assign 1 140 618
typenameGet 0 140 618
assign 1 140 619
NULLGet 0 140 619
assign 1 140 620
equals 1 140 625
assign 1 141 626
new 0 141 626
assign 1 142 629
heldGet 0 142 629
assign 1 142 630
nameGet 0 142 630
assign 1 142 631
new 0 142 631
assign 1 142 632
equals 1 142 632
assign 1 143 634
new 0 143 634
assign 1 144 637
heldGet 0 144 637
assign 1 144 638
nameGet 0 144 638
assign 1 144 639
new 0 144 639
assign 1 144 640
equals 1 144 640
assign 1 145 642
new 0 145 642
assign 1 147 645
heldGet 0 147 645
assign 1 147 646
nameForVar 1 147 646
return 1 149 650
assign 1 153 660
heldGet 0 153 660
assign 1 153 661
nameGet 0 153 661
assign 1 153 662
new 0 153 662
assign 1 153 663
equals 1 153 663
assign 1 154 665
new 0 154 665
assign 1 154 666
add 1 154 666
return 1 155 667
assign 1 157 669
formCallTarg 1 157 669
return 1 157 670
assign 1 161 680
new 0 161 680
assign 1 161 681
addValue 1 161 681
assign 1 161 682
secondGet 0 161 682
assign 1 161 683
formTarg 1 161 683
assign 1 161 684
addValue 1 161 684
assign 1 161 685
new 0 161 685
assign 1 161 686
addValue 1 161 686
addValue 1 161 687
assign 1 165 697
heldGet 0 165 697
assign 1 165 698
langsGet 0 165 698
assign 1 165 699
new 0 165 699
assign 1 165 700
has 1 165 700
assign 1 166 702
heldGet 0 166 702
assign 1 166 703
textGet 0 166 703
addValue 1 166 704
handleClassEmit 1 168 707
assign 1 174 749
new 0 174 749
assign 1 174 750
emitNameGet 0 174 750
assign 1 174 751
add 1 174 751
assign 1 174 752
new 0 174 752
assign 1 174 753
add 1 174 753
assign 1 176 754
new 0 176 754
assign 1 176 755
typeEmitNameGet 0 176 755
assign 1 176 756
add 1 176 756
assign 1 176 757
new 0 176 757
assign 1 176 758
add 1 176 758
assign 1 176 759
add 1 176 759
assign 1 176 760
new 0 176 760
assign 1 176 761
add 1 176 761
addClassHeader 1 178 762
assign 1 180 763
new 0 180 763
assign 1 182 764
typeEmitNameGet 0 182 764
assign 1 182 765
addValue 1 182 765
assign 1 182 766
new 0 182 766
assign 1 182 767
addValue 1 182 767
assign 1 182 768
emitNameGet 0 182 768
assign 1 182 769
addValue 1 182 769
assign 1 182 770
new 0 182 770
assign 1 182 771
addValue 1 182 771
assign 1 182 772
addValue 1 182 772
assign 1 182 773
new 0 182 773
addValue 1 182 774
assign 1 184 775
new 0 184 775
assign 1 184 776
addValue 1 184 776
assign 1 184 777
typeEmitNameGet 0 184 777
assign 1 184 778
addValue 1 184 778
assign 1 184 779
new 0 184 779
assign 1 184 780
addValue 1 184 780
assign 1 184 781
emitNameGet 0 184 781
assign 1 184 782
addValue 1 184 782
assign 1 184 783
new 0 184 783
assign 1 184 784
emitNameGet 0 184 784
assign 1 184 785
add 1 184 785
assign 1 184 786
new 0 184 786
assign 1 184 787
add 1 184 787
addValue 1 184 788
return 1 186 789
assign 1 191 809
new 0 191 809
assign 1 191 810
toString 0 191 810
assign 1 191 811
add 1 191 811
incrementValue 0 192 812
assign 1 193 813
new 0 193 813
assign 1 193 814
addValue 1 193 814
assign 1 193 815
addValue 1 193 815
assign 1 193 816
new 0 193 816
assign 1 193 817
addValue 1 193 817
addValue 1 193 818
assign 1 195 819
containedGet 0 195 819
assign 1 195 820
firstGet 0 195 820
assign 1 195 821
containedGet 0 195 821
assign 1 195 822
firstGet 0 195 822
assign 1 195 823
new 0 195 823
assign 1 195 824
add 1 195 824
assign 1 195 825
new 0 195 825
assign 1 195 826
add 1 195 826
assign 1 195 827
finalAssign 4 195 827
addValue 1 195 828
assign 1 199 844
isTypedGet 0 199 844
assign 1 199 845
not 0 199 850
assign 1 200 851
libNameGet 0 200 851
assign 1 200 852
relEmitName 1 200 852
assign 1 200 853
addValue 1 200 853
assign 1 200 854
new 0 200 854
addValue 1 200 855
assign 1 202 858
namepathGet 0 202 858
assign 1 202 859
getClassConfig 1 202 859
assign 1 202 860
libNameGet 0 202 860
assign 1 202 861
relEmitName 1 202 861
assign 1 202 862
addValue 1 202 862
assign 1 202 863
new 0 202 863
addValue 1 202 864
assign 1 207 879
new 0 207 879
assign 1 207 880
equals 1 207 880
assign 1 208 882
new 0 208 882
assign 1 210 885
new 0 210 885
assign 1 212 887
new 0 212 887
assign 1 212 888
add 1 212 888
assign 1 212 889
libNameGet 0 212 889
assign 1 212 890
relEmitName 1 212 890
assign 1 212 891
add 1 212 891
assign 1 212 892
new 0 212 892
assign 1 212 893
add 1 212 893
return 1 212 894
assign 1 217 898
new 0 217 898
return 1 217 899
assign 1 221 926
overrideMtdDecGet 0 221 926
assign 1 221 927
addValue 1 221 927
assign 1 221 928
new 0 221 928
assign 1 221 929
addValue 1 221 929
assign 1 221 930
emitNameGet 0 221 930
assign 1 221 931
addValue 1 221 931
assign 1 221 932
new 0 221 932
assign 1 221 933
addValue 1 221 933
assign 1 221 934
addValue 1 221 934
assign 1 221 935
new 0 221 935
assign 1 221 936
addValue 1 221 936
assign 1 221 937
addValue 1 221 937
assign 1 221 938
new 0 221 938
assign 1 221 939
addValue 1 221 939
addValue 1 221 940
assign 1 222 941
new 0 222 941
assign 1 222 942
addValue 1 222 942
assign 1 222 943
addValue 1 222 943
assign 1 222 944
new 0 222 944
assign 1 222 945
addValue 1 222 945
assign 1 222 946
addValue 1 222 946
assign 1 222 947
new 0 222 947
assign 1 222 948
addValue 1 222 948
addValue 1 222 949
assign 1 224 950
new 0 224 950
assign 1 224 951
addValue 1 224 951
addValue 1 224 952
assign 1 229 1002
new 0 229 1002
assign 1 229 1003
libNameGet 0 229 1003
assign 1 229 1004
relEmitName 1 229 1004
assign 1 229 1005
add 1 229 1005
assign 1 229 1006
new 0 229 1006
assign 1 229 1007
add 1 229 1007
assign 1 229 1008
heldGet 0 229 1008
assign 1 229 1009
literalValueGet 0 229 1009
assign 1 229 1010
add 1 229 1010
assign 1 229 1011
new 0 229 1011
assign 1 229 1012
add 1 229 1012
return 1 229 1013
assign 1 231 1015
emitChecksGet 0 231 1015
assign 1 231 1016
new 0 231 1016
assign 1 231 1017
has 1 231 1017
assign 1 232 1019
new 0 232 1019
assign 1 232 1020
libNameGet 0 232 1020
assign 1 232 1021
relEmitName 1 232 1021
assign 1 232 1022
add 1 232 1022
assign 1 232 1023
new 0 232 1023
assign 1 232 1024
add 1 232 1024
assign 1 232 1025
libNameGet 0 232 1025
assign 1 232 1026
relEmitName 1 232 1026
assign 1 232 1027
add 1 232 1027
assign 1 232 1028
new 0 232 1028
assign 1 232 1029
add 1 232 1029
assign 1 232 1030
heldGet 0 232 1030
assign 1 232 1031
literalValueGet 0 232 1031
assign 1 232 1032
add 1 232 1032
assign 1 232 1033
new 0 232 1033
assign 1 232 1034
add 1 232 1034
assign 1 234 1037
new 0 234 1037
assign 1 234 1038
libNameGet 0 234 1038
assign 1 234 1039
relEmitName 1 234 1039
assign 1 234 1040
add 1 234 1040
assign 1 234 1041
new 0 234 1041
assign 1 234 1042
add 1 234 1042
assign 1 234 1043
libNameGet 0 234 1043
assign 1 234 1044
relEmitName 1 234 1044
assign 1 234 1045
add 1 234 1045
assign 1 234 1046
new 0 234 1046
assign 1 234 1047
add 1 234 1047
assign 1 234 1048
heldGet 0 234 1048
assign 1 234 1049
literalValueGet 0 234 1049
assign 1 234 1050
add 1 234 1050
assign 1 234 1051
new 0 234 1051
assign 1 234 1052
add 1 234 1052
return 1 236 1054
assign 1 241 1103
new 0 241 1103
assign 1 241 1104
libNameGet 0 241 1104
assign 1 241 1105
relEmitName 1 241 1105
assign 1 241 1106
add 1 241 1106
assign 1 241 1107
new 0 241 1107
assign 1 241 1108
add 1 241 1108
assign 1 241 1109
heldGet 0 241 1109
assign 1 241 1110
literalValueGet 0 241 1110
assign 1 241 1111
add 1 241 1111
assign 1 241 1112
new 0 241 1112
assign 1 241 1113
add 1 241 1113
return 1 241 1114
assign 1 243 1116
emitChecksGet 0 243 1116
assign 1 243 1117
new 0 243 1117
assign 1 243 1118
has 1 243 1118
assign 1 244 1120
new 0 244 1120
assign 1 244 1121
libNameGet 0 244 1121
assign 1 244 1122
relEmitName 1 244 1122
assign 1 244 1123
add 1 244 1123
assign 1 244 1124
new 0 244 1124
assign 1 244 1125
add 1 244 1125
assign 1 244 1126
libNameGet 0 244 1126
assign 1 244 1127
relEmitName 1 244 1127
assign 1 244 1128
add 1 244 1128
assign 1 244 1129
new 0 244 1129
assign 1 244 1130
add 1 244 1130
assign 1 244 1131
heldGet 0 244 1131
assign 1 244 1132
literalValueGet 0 244 1132
assign 1 244 1133
add 1 244 1133
assign 1 244 1134
new 0 244 1134
assign 1 244 1135
add 1 244 1135
assign 1 246 1138
new 0 246 1138
assign 1 246 1139
libNameGet 0 246 1139
assign 1 246 1140
relEmitName 1 246 1140
assign 1 246 1141
add 1 246 1141
assign 1 246 1142
new 0 246 1142
assign 1 246 1143
add 1 246 1143
assign 1 246 1144
libNameGet 0 246 1144
assign 1 246 1145
relEmitName 1 246 1145
assign 1 246 1146
add 1 246 1146
assign 1 246 1147
new 0 246 1147
assign 1 246 1148
add 1 246 1148
assign 1 246 1149
heldGet 0 246 1149
assign 1 246 1150
literalValueGet 0 246 1150
assign 1 246 1151
add 1 246 1151
assign 1 246 1152
new 0 246 1152
assign 1 246 1153
add 1 246 1153
return 1 248 1155
assign 1 253 1206
new 0 253 1206
assign 1 253 1207
libNameGet 0 253 1207
assign 1 253 1208
relEmitName 1 253 1208
assign 1 253 1209
add 1 253 1209
assign 1 253 1210
new 0 253 1210
assign 1 253 1211
add 1 253 1211
assign 1 253 1212
add 1 253 1212
assign 1 253 1213
new 0 253 1213
assign 1 253 1214
add 1 253 1214
assign 1 253 1215
add 1 253 1215
assign 1 253 1216
new 0 253 1216
assign 1 253 1217
add 1 253 1217
return 1 253 1218
assign 1 256 1220
new 0 256 1220
assign 1 256 1221
add 1 256 1221
assign 1 256 1222
new 0 256 1222
assign 1 256 1223
add 1 256 1223
assign 1 256 1224
add 1 256 1224
assign 1 257 1225
emitChecksGet 0 257 1225
assign 1 257 1226
new 0 257 1226
assign 1 257 1227
has 1 257 1227
assign 1 258 1229
new 0 258 1229
assign 1 258 1230
libNameGet 0 258 1230
assign 1 258 1231
relEmitName 1 258 1231
assign 1 258 1232
add 1 258 1232
assign 1 258 1233
new 0 258 1233
assign 1 258 1234
add 1 258 1234
assign 1 258 1235
libNameGet 0 258 1235
assign 1 258 1236
relEmitName 1 258 1236
assign 1 258 1237
add 1 258 1237
assign 1 258 1238
new 0 258 1238
assign 1 258 1239
add 1 258 1239
assign 1 258 1240
add 1 258 1240
assign 1 258 1241
new 0 258 1241
assign 1 258 1242
add 1 258 1242
assign 1 260 1245
new 0 260 1245
assign 1 260 1246
libNameGet 0 260 1246
assign 1 260 1247
relEmitName 1 260 1247
assign 1 260 1248
add 1 260 1248
assign 1 260 1249
new 0 260 1249
assign 1 260 1250
add 1 260 1250
assign 1 260 1251
libNameGet 0 260 1251
assign 1 260 1252
relEmitName 1 260 1252
assign 1 260 1253
add 1 260 1253
assign 1 260 1254
new 0 260 1254
assign 1 260 1255
add 1 260 1255
assign 1 260 1256
add 1 260 1256
assign 1 260 1257
new 0 260 1257
assign 1 260 1258
add 1 260 1258
return 1 262 1260
incrementValue 0 266 1272
assign 1 267 1273
new 0 267 1273
assign 1 267 1274
notEmpty 1 267 1274
assign 1 268 1276
new 0 268 1276
addValue 1 268 1277
assign 1 270 1279
new 0 270 1279
assign 1 270 1280
addValue 1 270 1280
addValue 1 270 1281
assign 1 271 1282
new 0 271 1282
assign 1 271 1283
add 1 271 1283
assign 1 271 1284
new 0 271 1284
assign 1 271 1285
add 1 271 1285
return 1 271 1286
getCode 2 276 1292
assign 1 277 1293
toHexString 1 277 1293
assign 1 278 1294
new 0 278 1294
assign 1 278 1295
once 0 278 1295
addValue 1 278 1296
addValue 1 279 1297
assign 1 285 1304
new 0 285 1304
assign 1 285 1305
add 1 285 1305
assign 1 285 1306
add 1 285 1306
return 1 285 1307
assign 1 289 1311
new 0 289 1311
return 1 289 1312
assign 1 293 1316
new 0 293 1316
return 1 293 1317
assign 1 298 1321
new 0 298 1321
return 1 298 1322
assign 1 302 1345
new 0 302 1345
assign 1 302 1346
add 1 302 1346
assign 1 302 1347
new 0 302 1347
assign 1 302 1348
add 1 302 1348
assign 1 302 1349
add 1 302 1349
assign 1 303 1350
new 0 303 1350
assign 1 303 1351
addValue 1 303 1351
assign 1 303 1352
addValue 1 303 1352
assign 1 303 1353
new 0 303 1353
assign 1 303 1354
addValue 1 303 1354
addValue 1 303 1355
assign 1 304 1356
new 0 304 1356
assign 1 304 1357
addValue 1 304 1357
addValue 1 304 1358
assign 1 305 1359
new 0 305 1359
assign 1 305 1360
addValue 1 305 1360
assign 1 305 1361
outputPlatformGet 0 305 1361
assign 1 305 1362
nameGet 0 305 1362
assign 1 305 1363
addValue 1 305 1363
assign 1 305 1364
new 0 305 1364
assign 1 305 1365
addValue 1 305 1365
addValue 1 305 1366
assign 1 307 1367
new 0 307 1367
return 1 307 1368
assign 1 311 1372
new 0 311 1372
return 1 311 1373
assign 1 315 1379
new 0 315 1379
assign 1 315 1380
once 0 315 1380
assign 1 315 1381
add 1 315 1381
return 1 315 1382
assign 1 322 1398
assign 1 323 1399
singleCCGet 0 323 1399
assign 1 0 1401
assign 1 323 1404
classPathGet 0 323 1404
assign 1 323 1405
fileGet 0 323 1405
assign 1 323 1406
existsGet 0 323 1406
assign 1 323 1407
not 0 323 1412
assign 1 0 1413
assign 1 0 1416
return 1 324 1420
assign 1 326 1423
classPathGet 0 326 1423
assign 1 326 1424
fileGet 0 326 1424
assign 1 326 1425
lastUpdatedGet 0 326 1425
assign 1 327 1426
fromFileGet 0 327 1426
assign 1 327 1427
fileGet 0 327 1427
assign 1 327 1428
lastUpdatedGet 0 327 1428
assign 1 328 1429
greater 1 328 1429
return 1 331 1431
assign 1 334 1433
assign 1 339 1441
singleCCGet 0 339 1441
assign 1 340 1443
getLibOutput 0 340 1443
return 1 340 1444
assign 1 342 1446
getClassOutput 0 342 1446
return 1 342 1447
assign 1 346 1453
singleCCGet 0 346 1453
assign 1 347 1455
new 0 347 1455
assign 1 348 1456
countLines 1 348 1456
addValue 1 348 1457
write 1 349 1458
assign 1 354 1469
singleCCGet 0 354 1469
assign 1 356 1471
new 0 356 1471
assign 1 357 1472
countLines 1 357 1472
addValue 1 357 1473
write 1 358 1474
close 0 359 1475
assign 1 360 1476
def 1 360 1481
assign 1 361 1482
pathGet 0 361 1482
assign 1 361 1483
fileGet 0 361 1483
lastUpdatedSet 1 361 1484
assign 1 362 1485
assign 1 368 1508
new 0 368 1508
assign 1 369 1509
emitChecksGet 0 369 1509
assign 1 369 1510
new 0 369 1510
assign 1 369 1511
has 1 369 1511
assign 1 370 1513
new 0 370 1513
assign 1 370 1514
addValue 1 370 1514
assign 1 370 1515
addValue 1 370 1515
assign 1 370 1516
new 0 370 1516
assign 1 370 1517
addValue 1 370 1517
assign 1 370 1518
addValue 1 370 1518
assign 1 370 1519
new 0 370 1519
assign 1 370 1520
addValue 1 370 1520
addValue 1 370 1521
assign 1 371 1522
addValue 1 371 1522
assign 1 371 1523
new 0 371 1523
assign 1 371 1524
addValue 1 371 1524
addValue 1 371 1525
assign 1 372 1526
new 0 372 1526
assign 1 372 1527
addValue 1 372 1527
addValue 1 372 1528
return 1 374 1530
assign 1 378 1644
new 0 378 1644
assign 1 378 1645
typeEmitNameGet 0 378 1645
assign 1 378 1646
add 1 378 1646
assign 1 378 1647
new 0 378 1647
assign 1 378 1648
add 1 378 1648
write 1 378 1649
assign 1 379 1650
new 0 379 1650
assign 1 380 1651
new 0 380 1651
assign 1 380 1652
addValue 1 380 1652
assign 1 380 1653
typeEmitNameGet 0 380 1653
assign 1 380 1654
addValue 1 380 1654
assign 1 380 1655
new 0 380 1655
addValue 1 380 1656
assign 1 381 1657
new 0 381 1657
addValue 1 381 1658
assign 1 382 1659
typeEmitNameGet 0 382 1659
assign 1 382 1660
addValue 1 382 1660
assign 1 382 1661
new 0 382 1661
addValue 1 382 1662
assign 1 383 1663
new 0 383 1663
addValue 1 383 1664
assign 1 384 1665
new 0 384 1665
addValue 1 384 1666
assign 1 385 1667
new 0 385 1667
assign 1 385 1668
addValue 1 385 1668
assign 1 385 1669
addValue 1 385 1669
assign 1 385 1670
new 0 385 1670
addValue 1 385 1671
assign 1 386 1672
new 0 386 1672
addValue 1 386 1673
assign 1 387 1674
new 0 387 1674
addValue 1 387 1675
assign 1 388 1676
new 0 388 1676
addValue 1 388 1677
write 1 389 1678
assign 1 391 1679
new 0 391 1679
assign 1 392 1680
typeEmitNameGet 0 392 1680
assign 1 392 1681
addValue 1 392 1681
assign 1 392 1682
new 0 392 1682
assign 1 392 1683
addValue 1 392 1683
assign 1 392 1684
typeEmitNameGet 0 392 1684
assign 1 392 1685
addValue 1 392 1685
assign 1 392 1686
new 0 392 1686
addValue 1 392 1687
assign 1 393 1688
new 0 393 1688
addValue 1 393 1689
assign 1 394 1690
new 0 394 1690
assign 1 395 1691
mtdListGet 0 395 1691
assign 1 395 1692
iteratorGet 0 0 1692
assign 1 395 1695
hasNextGet 0 395 1695
assign 1 395 1697
nextGet 0 395 1697
assign 1 397 1699
new 0 397 1699
assign 1 399 1702
new 0 399 1702
addValue 1 399 1703
assign 1 401 1705
addValue 1 401 1705
assign 1 401 1706
nameGet 0 401 1706
assign 1 401 1707
addValue 1 401 1707
addValue 1 401 1708
assign 1 403 1714
new 0 403 1714
addValue 1 403 1715
assign 1 404 1716
new 0 404 1716
addValue 1 404 1717
assign 1 406 1718
new 0 406 1718
addValue 1 406 1719
assign 1 407 1720
new 0 407 1720
assign 1 408 1721
ptyListGet 0 408 1721
assign 1 408 1722
iteratorGet 0 0 1722
assign 1 408 1725
hasNextGet 0 408 1725
assign 1 408 1727
nextGet 0 408 1727
assign 1 410 1729
new 0 410 1729
assign 1 412 1732
new 0 412 1732
addValue 1 412 1733
assign 1 414 1735
addValue 1 414 1735
assign 1 414 1736
nameGet 0 414 1736
assign 1 414 1737
addValue 1 414 1737
addValue 1 414 1738
assign 1 416 1744
new 0 416 1744
addValue 1 416 1745
assign 1 418 1746
new 0 418 1746
addValue 1 418 1747
assign 1 420 1748
new 0 420 1748
assign 1 420 1749
addValue 1 420 1749
assign 1 420 1750
typeEmitNameGet 0 420 1750
assign 1 420 1751
addValue 1 420 1751
assign 1 420 1752
new 0 420 1752
addValue 1 420 1753
assign 1 421 1754
emitNameGet 0 421 1754
assign 1 421 1755
new 0 421 1755
assign 1 421 1756
equals 1 421 1756
assign 1 422 1758
new 0 422 1758
assign 1 422 1759
addValue 1 422 1759
assign 1 422 1760
emitNameGet 0 422 1760
assign 1 422 1761
addValue 1 422 1761
assign 1 422 1762
new 0 422 1762
addValue 1 422 1763
assign 1 424 1766
new 0 424 1766
assign 1 424 1767
addValue 1 424 1767
assign 1 424 1768
emitNameGet 0 424 1768
assign 1 424 1769
addValue 1 424 1769
assign 1 424 1770
new 0 424 1770
addValue 1 424 1771
assign 1 426 1773
new 0 426 1773
addValue 1 426 1774
assign 1 428 1775
new 0 428 1775
assign 1 428 1776
addValue 1 428 1776
assign 1 428 1777
typeEmitNameGet 0 428 1777
assign 1 428 1778
addValue 1 428 1778
assign 1 428 1779
new 0 428 1779
addValue 1 428 1780
assign 1 429 1781
new 0 429 1781
addValue 1 429 1782
assign 1 430 1783
new 0 430 1783
assign 1 430 1784
genMark 1 430 1784
addValue 1 430 1785
assign 1 431 1786
new 0 431 1786
addValue 1 431 1787
assign 1 432 1788
new 0 432 1788
addValue 1 432 1789
assign 1 433 1790
new 0 433 1790
assign 1 433 1791
genMark 1 433 1791
addValue 1 433 1792
assign 1 434 1793
new 0 434 1793
addValue 1 434 1794
assign 1 435 1795
new 0 435 1795
addValue 1 435 1796
assign 1 437 1797
new 0 437 1797
assign 1 437 1798
addValue 1 437 1798
assign 1 437 1799
typeEmitNameGet 0 437 1799
assign 1 437 1800
addValue 1 437 1800
assign 1 437 1801
new 0 437 1801
assign 1 437 1802
addValue 1 437 1802
assign 1 437 1803
addValue 1 437 1803
assign 1 437 1804
new 0 437 1804
assign 1 437 1805
addValue 1 437 1805
assign 1 437 1806
addValue 1 437 1806
assign 1 437 1807
new 0 437 1807
assign 1 437 1808
addValue 1 437 1808
addValue 1 437 1809
assign 1 438 1810
new 0 438 1810
assign 1 438 1811
addValue 1 438 1811
assign 1 438 1812
typeEmitNameGet 0 438 1812
assign 1 438 1813
addValue 1 438 1813
assign 1 438 1814
new 0 438 1814
assign 1 438 1815
addValue 1 438 1815
assign 1 438 1816
addValue 1 438 1816
assign 1 438 1817
new 0 438 1817
addValue 1 438 1818
clear 0 439 1819
assign 1 440 1820
new 0 440 1820
assign 1 442 1821
getClassOutput 0 442 1821
write 1 442 1822
assign 1 443 1823
countLines 1 443 1823
addValue 1 443 1824
assign 1 455 1897
undef 1 455 1902
assign 1 456 1903
libNameGet 0 456 1903
assign 1 457 1904
new 0 457 1904
assign 1 457 1905
sizeGet 0 457 1905
assign 1 457 1906
add 1 457 1906
assign 1 457 1907
new 0 457 1907
assign 1 457 1908
add 1 457 1908
assign 1 457 1909
add 1 457 1909
assign 1 457 1910
add 1 457 1910
assign 1 458 1911
new 0 458 1911
assign 1 458 1912
sizeGet 0 458 1912
assign 1 458 1913
add 1 458 1913
assign 1 458 1914
new 0 458 1914
assign 1 458 1915
add 1 458 1915
assign 1 458 1916
add 1 458 1916
assign 1 458 1917
add 1 458 1917
assign 1 459 1918
parentGet 0 459 1918
assign 1 459 1919
addStep 1 459 1919
assign 1 460 1920
parentGet 0 460 1920
assign 1 460 1921
addStep 1 460 1921
assign 1 461 1922
parentGet 0 461 1922
assign 1 461 1923
fileGet 0 461 1923
assign 1 461 1924
existsGet 0 461 1924
assign 1 461 1925
not 0 461 1930
assign 1 462 1931
parentGet 0 462 1931
assign 1 462 1932
fileGet 0 462 1932
makeDirs 0 462 1933
assign 1 464 1935
fileGet 0 464 1935
assign 1 464 1936
writerGet 0 464 1936
assign 1 464 1937
open 0 464 1937
assign 1 465 1938
fileGet 0 465 1938
assign 1 465 1939
writerGet 0 465 1939
assign 1 465 1940
open 0 465 1940
assign 1 467 1941
paramsGet 0 467 1941
assign 1 467 1942
new 0 467 1942
assign 1 467 1943
has 1 467 1943
assign 1 469 1945
paramsGet 0 469 1945
assign 1 469 1946
new 0 469 1946
assign 1 469 1947
get 1 469 1947
assign 1 469 1948
iteratorGet 0 0 1948
assign 1 469 1951
hasNextGet 0 469 1951
assign 1 469 1953
nextGet 0 469 1953
assign 1 471 1954
apNew 1 471 1954
assign 1 471 1955
fileGet 0 471 1955
assign 1 472 1956
readerGet 0 472 1956
assign 1 472 1957
open 0 472 1957
assign 1 472 1958
readString 0 472 1958
assign 1 473 1959
readerGet 0 473 1959
close 0 473 1960
write 1 475 1961
assign 1 479 1968
new 0 479 1968
write 1 479 1969
assign 1 480 1970
new 0 480 1970
write 1 480 1971
assign 1 482 1972
new 0 482 1972
write 1 482 1973
assign 1 483 1974
new 0 483 1974
write 1 483 1975
assign 1 489 1976
paramsGet 0 489 1976
assign 1 489 1977
new 0 489 1977
assign 1 489 1978
has 1 489 1978
assign 1 491 1980
paramsGet 0 491 1980
assign 1 491 1981
new 0 491 1981
assign 1 491 1982
get 1 491 1982
assign 1 491 1983
iteratorGet 0 0 1983
assign 1 491 1986
hasNextGet 0 491 1986
assign 1 491 1988
nextGet 0 491 1988
assign 1 493 1989
apNew 1 493 1989
assign 1 493 1990
fileGet 0 493 1990
assign 1 494 1991
readerGet 0 494 1991
assign 1 494 1992
open 0 494 1992
assign 1 494 1993
readString 0 494 1993
assign 1 495 1994
readerGet 0 495 1994
close 0 495 1995
write 1 497 1996
assign 1 500 2003
paramsGet 0 500 2003
assign 1 500 2004
new 0 500 2004
assign 1 500 2005
has 1 500 2005
assign 1 502 2007
paramsGet 0 502 2007
assign 1 502 2008
new 0 502 2008
assign 1 502 2009
get 1 502 2009
assign 1 502 2010
iteratorGet 0 0 2010
assign 1 502 2013
hasNextGet 0 502 2013
assign 1 502 2015
nextGet 0 502 2015
assign 1 504 2016
apNew 1 504 2016
assign 1 504 2017
fileGet 0 504 2017
assign 1 505 2018
readerGet 0 505 2018
assign 1 505 2019
open 0 505 2019
assign 1 505 2020
readString 0 505 2020
assign 1 506 2021
readerGet 0 506 2021
close 0 506 2022
write 1 508 2023
begin 1 515 2034
prepHeaderOutput 0 516 2035
assign 1 521 2078
undef 1 521 2083
assign 1 522 2084
new 0 522 2084
assign 1 523 2085
parentGet 0 523 2085
assign 1 523 2086
fileGet 0 523 2086
assign 1 523 2087
existsGet 0 523 2087
assign 1 523 2088
not 0 523 2093
assign 1 524 2094
parentGet 0 524 2094
assign 1 524 2095
fileGet 0 524 2095
makeDirs 0 524 2096
assign 1 526 2098
fileGet 0 526 2098
assign 1 526 2099
writerGet 0 526 2099
assign 1 526 2100
open 0 526 2100
assign 1 528 2101
new 0 528 2101
write 1 528 2102
assign 1 530 2103
paramsGet 0 530 2103
assign 1 530 2104
new 0 530 2104
assign 1 530 2105
has 1 530 2105
assign 1 532 2107
paramsGet 0 532 2107
assign 1 532 2108
new 0 532 2108
assign 1 532 2109
get 1 532 2109
assign 1 532 2110
iteratorGet 0 0 2110
assign 1 532 2113
hasNextGet 0 532 2113
assign 1 532 2115
nextGet 0 532 2115
assign 1 534 2116
apNew 1 534 2116
assign 1 534 2117
fileGet 0 534 2117
assign 1 535 2118
readerGet 0 535 2118
assign 1 535 2119
open 0 535 2119
assign 1 535 2120
readString 0 535 2120
assign 1 536 2121
readerGet 0 536 2121
close 0 536 2122
write 1 538 2123
assign 1 542 2130
new 0 542 2130
write 1 542 2131
increment 0 543 2132
assign 1 544 2133
paramsGet 0 544 2133
assign 1 544 2134
new 0 544 2134
assign 1 544 2135
has 1 544 2135
assign 1 545 2137
paramsGet 0 545 2137
assign 1 545 2138
new 0 545 2138
assign 1 545 2139
get 1 545 2139
assign 1 545 2140
iteratorGet 0 0 2140
assign 1 545 2143
hasNextGet 0 545 2143
assign 1 545 2145
nextGet 0 545 2145
assign 1 546 2146
apNew 1 546 2146
assign 1 546 2147
fileGet 0 546 2147
assign 1 547 2148
readerGet 0 547 2148
assign 1 547 2149
open 0 547 2149
assign 1 547 2150
readString 0 547 2150
assign 1 548 2151
readerGet 0 548 2151
close 0 548 2152
assign 1 549 2153
countLines 1 549 2153
addValue 1 549 2154
write 1 550 2155
return 1 556 2163
close 0 561 2174
assign 1 562 2175
assign 1 564 2176
new 0 564 2176
write 1 564 2177
assign 1 566 2178
new 0 566 2178
write 1 566 2179
assign 1 568 2180
emitChecksGet 0 568 2180
assign 1 568 2181
new 0 568 2181
assign 1 568 2182
has 1 568 2182
assign 1 569 2184
new 0 569 2184
assign 1 570 2185
new 0 570 2185
assign 1 570 2186
addValue 1 570 2186
addValue 1 570 2187
write 1 571 2188
close 0 574 2190
close 0 575 2191
assign 1 580 2196
new 0 580 2196
return 1 580 2197
assign 1 584 2214
emitChecksGet 0 584 2214
assign 1 584 2215
new 0 584 2215
assign 1 584 2216
has 1 584 2216
assign 1 585 2218
new 0 585 2218
assign 1 585 2219
addValue 1 585 2219
assign 1 585 2220
addValue 1 585 2220
assign 1 585 2221
new 0 585 2221
addValue 1 585 2222
assign 1 586 2225
emitChecksGet 0 586 2225
assign 1 586 2226
new 0 586 2226
assign 1 586 2227
has 1 586 2227
assign 1 587 2229
new 0 587 2229
assign 1 587 2230
addValue 1 587 2230
assign 1 587 2231
addValue 1 587 2231
assign 1 587 2232
new 0 587 2232
addValue 1 587 2233
assign 1 593 2257
heldGet 0 593 2257
assign 1 593 2258
synGet 0 593 2258
assign 1 594 2259
ptyListGet 0 594 2259
assign 1 596 2260
emitNameGet 0 596 2260
assign 1 596 2261
addValue 1 596 2261
assign 1 596 2262
new 0 596 2262
addValue 1 596 2263
assign 1 598 2264
new 0 598 2264
assign 1 599 2265
iteratorGet 0 0 2265
assign 1 599 2268
hasNextGet 0 599 2268
assign 1 599 2270
nextGet 0 599 2270
assign 1 601 2272
new 0 601 2272
assign 1 603 2275
new 0 603 2275
addValue 1 603 2276
assign 1 605 2278
addValue 1 605 2278
assign 1 605 2279
new 0 605 2279
assign 1 605 2280
addValue 1 605 2280
assign 1 605 2281
nameGet 0 605 2281
assign 1 605 2282
addValue 1 605 2282
addValue 1 605 2283
assign 1 609 2289
new 0 609 2289
assign 1 609 2290
addValue 1 609 2290
addValue 1 609 2291
assign 1 614 2311
new 0 614 2311
assign 1 616 2312
new 0 616 2312
assign 1 616 2313
emitNameGet 0 616 2313
assign 1 616 2314
add 1 616 2314
assign 1 616 2315
new 0 616 2315
assign 1 616 2316
add 1 616 2316
assign 1 618 2317
emitNameGet 0 618 2317
assign 1 618 2318
addValue 1 618 2318
assign 1 618 2319
new 0 618 2319
assign 1 618 2320
addValue 1 618 2320
assign 1 618 2321
emitNameGet 0 618 2321
assign 1 618 2322
addValue 1 618 2322
assign 1 618 2323
new 0 618 2323
assign 1 618 2324
addValue 1 618 2324
assign 1 618 2325
addValue 1 618 2325
assign 1 618 2326
new 0 618 2326
addValue 1 618 2327
return 1 620 2328
assign 1 624 2337
libNameGet 0 624 2337
assign 1 624 2338
relEmitName 1 624 2338
assign 1 625 2339
new 0 625 2339
assign 1 625 2340
add 1 625 2340
assign 1 625 2341
new 0 625 2341
assign 1 625 2342
add 1 625 2342
return 1 626 2343
assign 1 630 2355
libNameGet 0 630 2355
assign 1 630 2356
relEmitName 1 630 2356
assign 1 631 2357
new 0 631 2357
assign 1 631 2358
add 1 631 2358
assign 1 631 2359
new 0 631 2359
assign 1 631 2360
add 1 631 2360
assign 1 632 2361
new 0 632 2361
assign 1 632 2362
add 1 632 2362
assign 1 632 2363
add 1 632 2363
return 1 632 2364
assign 1 636 2369
new 0 636 2369
assign 1 636 2370
add 1 636 2370
return 1 636 2371
assign 1 640 2479
getClassConfig 1 640 2479
assign 1 640 2480
libNameGet 0 640 2480
assign 1 640 2481
relEmitName 1 640 2481
assign 1 641 2482
heldGet 0 641 2482
assign 1 641 2483
namepathGet 0 641 2483
assign 1 641 2484
getClassConfig 1 641 2484
assign 1 642 2485
getInitialInst 1 642 2485
assign 1 644 2486
overrideMtdDecGet 0 644 2486
assign 1 644 2487
addValue 1 644 2487
assign 1 644 2488
new 0 644 2488
assign 1 644 2489
addValue 1 644 2489
assign 1 644 2490
emitNameGet 0 644 2490
assign 1 644 2491
addValue 1 644 2491
assign 1 644 2492
new 0 644 2492
assign 1 644 2493
addValue 1 644 2493
assign 1 644 2494
addValue 1 644 2494
assign 1 644 2495
new 0 644 2495
assign 1 644 2496
addValue 1 644 2496
assign 1 644 2497
addValue 1 644 2497
assign 1 644 2498
new 0 644 2498
assign 1 644 2499
addValue 1 644 2499
addValue 1 644 2500
assign 1 645 2501
new 0 645 2501
assign 1 646 2502
emitNameGet 0 646 2502
assign 1 646 2503
notEquals 1 646 2503
assign 1 647 2505
new 0 647 2505
assign 1 647 2506
formCast 3 647 2506
assign 1 650 2508
addValue 1 650 2508
assign 1 650 2509
new 0 650 2509
assign 1 650 2510
addValue 1 650 2510
assign 1 650 2511
addValue 1 650 2511
assign 1 650 2512
new 0 650 2512
assign 1 650 2513
addValue 1 650 2513
addValue 1 650 2514
assign 1 652 2515
new 0 652 2515
assign 1 652 2516
addValue 1 652 2516
addValue 1 652 2517
assign 1 655 2518
overrideMtdDecGet 0 655 2518
assign 1 655 2519
addValue 1 655 2519
assign 1 655 2520
addValue 1 655 2520
assign 1 655 2521
new 0 655 2521
assign 1 655 2522
addValue 1 655 2522
assign 1 655 2523
emitNameGet 0 655 2523
assign 1 655 2524
addValue 1 655 2524
assign 1 655 2525
new 0 655 2525
assign 1 655 2526
addValue 1 655 2526
assign 1 655 2527
addValue 1 655 2527
assign 1 655 2528
new 0 655 2528
assign 1 655 2529
addValue 1 655 2529
addValue 1 655 2530
assign 1 660 2531
new 0 660 2531
assign 1 660 2532
addValue 1 660 2532
assign 1 660 2533
addValue 1 660 2533
assign 1 660 2534
new 0 660 2534
assign 1 660 2535
addValue 1 660 2535
addValue 1 660 2536
assign 1 663 2537
new 0 663 2537
assign 1 663 2538
addValue 1 663 2538
addValue 1 663 2539
assign 1 665 2540
overrideMtdDecGet 0 665 2540
assign 1 665 2541
addValue 1 665 2541
assign 1 665 2542
new 0 665 2542
assign 1 665 2543
addValue 1 665 2543
assign 1 665 2544
emitNameGet 0 665 2544
assign 1 665 2545
addValue 1 665 2545
assign 1 665 2546
new 0 665 2546
assign 1 665 2547
addValue 1 665 2547
assign 1 665 2548
addValue 1 665 2548
assign 1 665 2549
new 0 665 2549
assign 1 665 2550
addValue 1 665 2550
addValue 1 665 2551
assign 1 666 2552
heldGet 0 666 2552
assign 1 666 2553
extendsGet 0 666 2553
assign 1 666 2554
undef 1 666 2559
assign 1 0 2560
assign 1 666 2563
heldGet 0 666 2563
assign 1 666 2564
extendsGet 0 666 2564
assign 1 666 2565
equals 1 666 2565
assign 1 0 2567
assign 1 0 2570
assign 1 667 2574
new 0 667 2574
assign 1 667 2575
addValue 1 667 2575
addValue 1 667 2576
assign 1 669 2579
new 0 669 2579
assign 1 669 2580
addValue 1 669 2580
addValue 1 669 2581
addValue 1 671 2583
clear 0 672 2584
assign 1 675 2585
new 0 675 2585
assign 1 675 2586
addValue 1 675 2586
addValue 1 675 2587
assign 1 677 2588
overrideMtdDecGet 0 677 2588
assign 1 677 2589
addValue 1 677 2589
assign 1 677 2590
new 0 677 2590
assign 1 677 2591
addValue 1 677 2591
assign 1 677 2592
emitNameGet 0 677 2592
assign 1 677 2593
addValue 1 677 2593
assign 1 677 2594
new 0 677 2594
assign 1 677 2595
addValue 1 677 2595
assign 1 677 2596
addValue 1 677 2596
assign 1 677 2597
new 0 677 2597
assign 1 677 2598
addValue 1 677 2598
addValue 1 677 2599
assign 1 678 2600
new 0 678 2600
assign 1 678 2601
addValue 1 678 2601
addValue 1 678 2602
assign 1 680 2603
new 0 680 2603
assign 1 680 2604
addValue 1 680 2604
addValue 1 680 2605
assign 1 682 2606
getTypeInst 1 682 2606
assign 1 684 2607
new 0 684 2607
assign 1 684 2608
addValue 1 684 2608
assign 1 684 2609
emitNameGet 0 684 2609
assign 1 684 2610
addValue 1 684 2610
assign 1 684 2611
new 0 684 2611
assign 1 684 2612
addValue 1 684 2612
addValue 1 684 2613
assign 1 686 2614
new 0 686 2614
assign 1 686 2615
addValue 1 686 2615
assign 1 686 2616
addValue 1 686 2616
assign 1 686 2617
new 0 686 2617
assign 1 686 2618
addValue 1 686 2618
addValue 1 686 2619
assign 1 688 2620
new 0 688 2620
assign 1 688 2621
addValue 1 688 2621
addValue 1 688 2622
assign 1 694 2628
new 0 694 2628
write 1 694 2629
assign 1 695 2630
new 0 695 2630
write 1 695 2631
emitLib 0 697 2632
assign 1 702 2645
libNameGet 0 702 2645
assign 1 702 2646
relEmitName 1 702 2646
assign 1 703 2647
new 0 703 2647
assign 1 703 2648
add 1 703 2648
assign 1 703 2649
new 0 703 2649
assign 1 703 2650
add 1 703 2650
assign 1 704 2651
new 0 704 2651
assign 1 704 2652
add 1 704 2652
assign 1 704 2653
add 1 704 2653
return 1 704 2654
return 1 0 2657
return 1 0 2660
assign 1 0 2663
assign 1 0 2667
return 1 0 2671
return 1 0 2674
assign 1 0 2677
assign 1 0 2681
return 1 0 2685
return 1 0 2688
assign 1 0 2691
assign 1 0 2695
return 1 0 2699
return 1 0 2702
assign 1 0 2705
assign 1 0 2709
return 1 0 2713
return 1 0 2716
assign 1 0 2719
assign 1 0 2723
return 1 0 2727
return 1 0 2730
assign 1 0 2733
assign 1 0 2737
return 1 0 2741
return 1 0 2744
assign 1 0 2747
assign 1 0 2751
return 1 0 2755
return 1 0 2758
assign 1 0 2761
assign 1 0 2765
return 1 0 2769
return 1 0 2772
assign 1 0 2775
assign 1 0 2779
return 1 0 2783
return 1 0 2786
assign 1 0 2789
assign 1 0 2793
return 1 0 2797
return 1 0 2800
assign 1 0 2803
assign 1 0 2807
return 1 0 2811
return 1 0 2814
assign 1 0 2817
assign 1 0 2821
return 1 0 2825
return 1 0 2828
assign 1 0 2831
assign 1 0 2835
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1578752349: return bem_superCallsGet_0();
case -132394584: return bem_gcMarksGetDirect_0();
case -184536522: return bem_methodCatchGetDirect_0();
case -214204552: return bem_objectCcGetDirect_0();
case 1182573638: return bem_lineCountGet_0();
case -1344742679: return bem_classHeadersGet_0();
case -122891338: return bem_lastMethodBodyLinesGet_0();
case 396478404: return bem_nullValueGet_0();
case -1073864238: return bem_buildCreate_0();
case 402341494: return bem_methodBodyGetDirect_0();
case 1402840917: return bem_qGetDirect_0();
case 1076606196: return bem_classConfGetDirect_0();
case 835349186: return bem_lastMethodBodySizeGetDirect_0();
case -478321755: return bem_boolCcGetDirect_0();
case -1868291768: return bem_exceptDecGetDirect_0();
case 658139934: return bem_deonGetDirect_0();
case 773963565: return bem_emitLib_0();
case -1062777262: return bem_boolNpGet_0();
case 1577195459: return bem_serializationIteratorGet_0();
case 765877792: return bem_randGet_0();
case -420649750: return bem_libEmitPathGetDirect_0();
case 341575045: return bem_many_0();
case -454237579: return bem_lineCountGetDirect_0();
case -1123278056: return bem_tagGet_0();
case 1507551114: return bem_libEmitNameGetDirect_0();
case -31498839: return bem_falseValueGetDirect_0();
case -336284530: return bem_emitLangGet_0();
case -2082769495: return bem_nlGetDirect_0();
case -252471527: return bem_classHeadBodyGet_0();
case -813800834: return bem_belslitsGetDirect_0();
case -622702543: return bem_nameToIdPathGetDirect_0();
case -713163994: return bem_toAny_0();
case -1148301170: return bem_headExtGet_0();
case -1086782351: return bem_print_0();
case 932492845: return bem_parentConfGetDirect_0();
case -369320135: return bem_lastMethodBodyLinesGetDirect_0();
case -1059184096: return bem_inFilePathedGetDirect_0();
case -2099367318: return bem_covariantReturnsGet_0();
case -1892050764: return bem_heopGetDirect_0();
case -1266447496: return bem_classNameGet_0();
case 747350866: return bem_nativeCSlotsGetDirect_0();
case -10010145: return bem_copy_0();
case -317018644: return bem_smnlcsGet_0();
case 1747470980: return bem_runtimeInitGet_0();
case 1612580804: return bem_lastCallGet_0();
case -204256404: return bem_typeDecGet_0();
case -1685240182: return bem_shlibeGetDirect_0();
case 44569738: return bem_buildInitial_0();
case -442958039: return bem_onceDecsGetDirect_0();
case -1940333070: return bem_instanceNotEqualGetDirect_0();
case -504842964: return bem_endNs_0();
case -2126174019: return bem_overrideMtdDecGet_0();
case 637264206: return bem_nlGet_0();
case 484951238: return bem_deonGet_0();
case 282905452: return bem_parentConfGet_0();
case -2051518290: return bem_once_0();
case -1216448909: return bem_fullLibEmitNameGet_0();
case -706489572: return bem_spropDecGet_0();
case -1952046034: return bem_beginNs_0();
case 1683842908: return bem_mnodeGet_0();
case 96033137: return bem_serializeToString_0();
case -985646934: return bem_methodsGetDirect_0();
case 1676322853: return bem_preClassGet_0();
case 1111339989: return bem_instanceEqualGetDirect_0();
case -1470044496: return bem_intNpGet_0();
case 1304840881: return bem_classesInDepthOrderGet_0();
case 1801876218: return bem_mainStartGet_0();
case 1162304104: return bem_libEmitNameGet_0();
case 1486588983: return bem_nativeCSlotsGet_0();
case -1765925991: return bem_idToNamePathGetDirect_0();
case -1588104394: return bem_cnodeGetDirect_0();
case 1942283510: return bem_sourceFileNameGet_0();
case -212842115: return bem_smnlecsGetDirect_0();
case 407367788: return bem_onceCountGet_0();
case 144348929: return bem_onceDecRefsGet_0();
case 1320546996: return bem_preClassOutput_0();
case 1851908877: return bem_hashGet_0();
case -722894814: return bem_onceDecRefsGetDirect_0();
case 869557719: return bem_propertyDecsGetDirect_0();
case 1193197051: return bem_ntypesGet_0();
case -1389346542: return bem_deowGetDirect_0();
case 1006271437: return bem_msynGetDirect_0();
case 209874246: return bem_nameToIdGet_0();
case -370719028: return bem_instOfGet_0();
case -832882259: return bem_scvpGet_0();
case 347266937: return bem_ccCacheGetDirect_0();
case 434161300: return bem_setOutputTimeGetDirect_0();
case 379656857: return bem_scvpGetDirect_0();
case 266994385: return bem_classHeadersGetDirect_0();
case 732697998: return bem_idToNamePathGet_0();
case 1163216647: return bem_fileExtGet_0();
case 699017196: return bem_boolCcGet_0();
case -1298453047: return bem_buildGet_0();
case -2068363357: return bem_methodCallsGetDirect_0();
case 1541400520: return bem_idToNameGet_0();
case 15402397: return bem_objectNpGetDirect_0();
case -480726674: return bem_csynGetDirect_0();
case 1126288320: return bem_smnlcsGetDirect_0();
case -1999164817: return bem_transGetDirect_0();
case -1444157789: return bem_nullValueGetDirect_0();
case 389653078: return bem_floatNpGet_0();
case 245459276: return bem_newDecGet_0();
case -1053283121: return bem_methodBodyGet_0();
case -1410576775: return bem_superCallsGetDirect_0();
case -1437070352: return bem_libEmitPathGet_0();
case 611670694: return bem_fieldIteratorGet_0();
case 85992302: return bem_gcMarksGet_0();
case 257325317: return bem_lastCallGetDirect_0();
case -1546971192: return bem_invpGetDirect_0();
case -189437710: return bem_buildPropList_0();
case -418642594: return bem_classEndGet_0();
case 1076775546: return bem_preClassGetDirect_0();
case 771723657: return bem_propDecGet_0();
case -44338819: return bem_synEmitPathGetDirect_0();
case 1521848686: return bem_baseMtdDecGet_0();
case -1300057562: return bem_csynGet_0();
case 814508836: return bem_onceDecRefsCountGet_0();
case 360251852: return bem_shlibeGet_0();
case 894734870: return bem_inClassGetDirect_0();
case -565265786: return bem_heonGet_0();
case -711116787: return bem_maxDynArgsGet_0();
case 1726004327: return bem_methodCatchGet_0();
case 990360647: return bem_new_0();
case -155311229: return bem_onceDecRefsCountGetDirect_0();
case 379358518: return bem_lastMethodsSizeGetDirect_0();
case -1607079592: return bem_smnlecsGet_0();
case 1369882092: return bem_onceCountGetDirect_0();
case 81507498: return bem_heowGetDirect_0();
case -210315029: return bem_lastMethodBodySizeGet_0();
case -1535565120: return bem_nameToIdPathGet_0();
case -87470459: return bem_methodCallsGet_0();
case 887361644: return bem_fullLibEmitNameGetDirect_0();
case -1228184212: return bem_trueValueGet_0();
case -294234846: return bem_heowGet_0();
case 1205271118: return bem_floatNpGetDirect_0();
case 1859124881: return bem_instOfGetDirect_0();
case 2142754364: return bem_classEmitsGet_0();
case 693568227: return bem_lastMethodsLinesGetDirect_0();
case 403157348: return bem_exceptDecGet_0();
case 1001628229: return bem_initialDecGet_0();
case -1312922573: return bem_objectNpGet_0();
case -1909223916: return bem_randGetDirect_0();
case -1171583728: return bem_methodsGet_0();
case -1609070142: return bem_buildClassInfo_0();
case 1576999707: return bem_fileExtGetDirect_0();
case -777448052: return bem_emitLangGetDirect_0();
case 1355561260: return bem_nameToIdGetDirect_0();
case -511820512: return bem_synEmitPathGet_0();
case -1619538614: return bem_saveSyns_0();
case 114962970: return bem_doEmit_0();
case -787237766: return bem_getClassOutput_0();
case -1330718345: return bem_heopGet_0();
case -757722908: return bem_classConfGet_0();
case -891395244: return bem_heonGetDirect_0();
case -919832086: return bem_deopGetDirect_0();
case -42869477: return bem_falseValueGet_0();
case -385502167: return bem_classCallsGetDirect_0();
case 1049178746: return bem_qGet_0();
case 1139700098: return bem_transGet_0();
case -1109932284: return bem_mainEndGet_0();
case 731309399: return bem_afterCast_0();
case 1603413876: return bem_msynGet_0();
case -555391160: return bem_classHeadBodyGetDirect_0();
case 1079791851: return bem_classesInDepthOrderGetDirect_0();
case -2056406479: return bem_stringNpGet_0();
case 144584723: return bem_create_0();
case -816706481: return bem_cnodeGet_0();
case 1179490652: return bem_maxDynArgsGetDirect_0();
case 1860736480: return bem_constGetDirect_0();
case -1233955270: return bem_dynMethodsGetDirect_0();
case 502604059: return bem_returnTypeGetDirect_0();
case 44008059: return bem_writeBET_0();
case 984259789: return bem_boolTypeGet_0();
case -610767888: return bem_dynMethodsGet_0();
case 508154468: return bem_instanceEqualGet_0();
case 2039882608: return bem_ccMethodsGet_0();
case 532445272: return bem_inClassGet_0();
case -1993157878: return bem_ntypesGetDirect_0();
case -910988398: return bem_classEmitsGetDirect_0();
case -763786472: return bem_boolNpGetDirect_0();
case 934001470: return bem_objectCcGet_0();
case 1823315786: return bem_ccMethodsGetDirect_0();
case 1271376725: return bem_getLibOutput_0();
case 1647816832: return bem_callNamesGet_0();
case 1194804327: return bem_fieldNamesGet_0();
case -1977352474: return bem_mainOutsideNsGet_0();
case -272301572: return bem_headExtGetDirect_0();
case -623366174: return bem_ccCacheGet_0();
case -1894930378: return bem_onceDecsGet_0();
case -1114977715: return bem_constGet_0();
case 578285257: return bem_deowGet_0();
case -116860886: return bem_mnodeGetDirect_0();
case 1315612761: return bem_intNpGetDirect_0();
case 1903781713: return bem_prepHeaderOutput_0();
case -1622521468: return bem_lastMethodsSizeGet_0();
case 1513233059: return bem_toString_0();
case 1327285718: return bem_belslitsGet_0();
case 684312943: return bem_inFilePathedGet_0();
case -1362850090: return bem_serializeContents_0();
case -248170874: return bem_invpGet_0();
case -2065072389: return bem_deopGet_0();
case -209472074: return bem_maxSpillArgsLenGetDirect_0();
case 1225278041: return bem_stringNpGetDirect_0();
case 1469223802: return bem_callNamesGetDirect_0();
case -660368452: return bem_classCallsGet_0();
case -104403161: return bem_loadIds_0();
case 1071461198: return bem_echo_0();
case -1061498667: return bem_superNameGet_0();
case -130364354: return bem_idToNameGetDirect_0();
case -414785750: return bem_useDynMethodsGet_0();
case 1308326065: return bem_saveIds_0();
case 1307673902: return bem_setOutputTimeGet_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case 200095578: return bem_trueValueGetDirect_0();
case -449079106: return bem_iteratorGet_0();
case -339817320: return bem_instanceNotEqualGet_0();
case 964129689: return bem_baseSmtdDecGet_0();
case -623500174: return bem_lastMethodsLinesGet_0();
case 443668781: return bem_propertyDecsGet_0();
case 665679587: return bem_returnTypeGet_0();
case 1739543710: return bem_mainInClassGet_0();
case 936251957: return bem_buildGetDirect_0();
case -141585115: return bem_maxSpillArgsLenGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -496737335: return bem_setOutputTimeSet_1(bevd_0);
case -1966059311: return bem_superCallsSet_1(bevd_0);
case 1375494165: return bem_libEmitNameSet_1(bevd_0);
case -765291421: return bem_propertyDecsSetDirect_1(bevd_0);
case 29346616: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -2129277976: return bem_libEmitPathSet_1(bevd_0);
case -735549421: return bem_returnTypeSet_1(bevd_0);
case 734124317: return bem_onceDecRefsSet_1(bevd_0);
case -1071001840: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 618439670: return bem_preClassSetDirect_1(bevd_0);
case 1673046369: return bem_csynSetDirect_1(bevd_0);
case 1440239300: return bem_belslitsSet_1(bevd_0);
case -19524766: return bem_emitLangSetDirect_1(bevd_0);
case -2093050870: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -478468566: return bem_scvpSet_1(bevd_0);
case -977770464: return bem_trueValueSetDirect_1(bevd_0);
case 1222154172: return bem_inFilePathedSet_1(bevd_0);
case -1575442379: return bem_floatNpSetDirect_1(bevd_0);
case -1888592187: return bem_deowSet_1(bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1839965950: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case 237726194: return bem_heopSetDirect_1(bevd_0);
case -1425015314: return bem_methodBodySetDirect_1(bevd_0);
case -1272792662: return bem_exceptDecSetDirect_1(bevd_0);
case -1436296903: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 2016964848: return bem_libEmitNameSetDirect_1(bevd_0);
case -312679344: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 2104655978: return bem_instanceNotEqualSet_1(bevd_0);
case 1523143690: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 625964127: return bem_deonSetDirect_1(bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -253694439: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 342584641: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 2074141809: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -72144144: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1579221998: return bem_qSetDirect_1(bevd_0);
case 1520792655: return bem_heopSet_1(bevd_0);
case -534989708: return bem_nlSetDirect_1(bevd_0);
case 1165172214: return bem_stringNpSet_1(bevd_0);
case 1185359129: return bem_smnlcsSetDirect_1(bevd_0);
case 1264173159: return bem_heowSet_1(bevd_0);
case 1931596767: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -751596479: return bem_instanceEqualSetDirect_1(bevd_0);
case -2129391475: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 829465663: return bem_genMark_1((BEC_2_4_6_TextString) bevd_0);
case 1463568798: return bem_intNpSetDirect_1(bevd_0);
case -1549759476: return bem_fullLibEmitNameSet_1(bevd_0);
case -1938964126: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case -1876472922: return bem_smnlecsSet_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
case 77336253: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 873892036: return bem_intNpSet_1(bevd_0);
case -584397764: return bem_csynSet_1(bevd_0);
case -923758196: return bem_boolCcSet_1(bevd_0);
case -1666737542: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -497312533: return bem_scvpSetDirect_1(bevd_0);
case -850839296: return bem_lastCallSet_1(bevd_0);
case -364649010: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1204315827: return bem_idToNameSet_1(bevd_0);
case 583073200: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 631470326: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1485209279: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 1337189736: return bem_deopSet_1(bevd_0);
case -1160533106: return bem_mnodeSetDirect_1(bevd_0);
case -1137696884: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 139102551: return bem_boolCcSetDirect_1(bevd_0);
case -677011010: return bem_randSetDirect_1(bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case -1963646313: return bem_objectCcSet_1(bevd_0);
case 1291922289: return bem_onceDecRefsCountSet_1(bevd_0);
case 1449340032: return bem_otherClass_1(bevd_0);
case 812295678: return bem_invpSet_1(bevd_0);
case 1799680711: return bem_synEmitPathSetDirect_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case -608257616: return bem_constSetDirect_1(bevd_0);
case -1413169437: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1944037126: return bem_lastCallSetDirect_1(bevd_0);
case 1251595701: return bem_deowSetDirect_1(bevd_0);
case 422384913: return bem_end_1(bevd_0);
case -200065239: return bem_shlibeSet_1(bevd_0);
case -131518903: return bem_nlSet_1(bevd_0);
case 1849958179: return bem_smnlecsSetDirect_1(bevd_0);
case -1387056138: return bem_nameToIdSetDirect_1(bevd_0);
case 1830857400: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -655019399: return bem_def_1(bevd_0);
case 795342124: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -2022144941: return bem_nativeCSlotsSet_1(bevd_0);
case -2099354926: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1519644425: return bem_deopSetDirect_1(bevd_0);
case -1968785123: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case 754381394: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 657307822: return bem_setOutputTimeSetDirect_1(bevd_0);
case 602949761: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 842590438: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -2049843573: return bem_classHeadersSetDirect_1(bevd_0);
case -1198311367: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1741923406: return bem_msynSet_1(bevd_0);
case -1758669993: return bem_idToNameSetDirect_1(bevd_0);
case 1146822394: return bem_maxDynArgsSet_1(bevd_0);
case 2021071567: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case -936795051: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -710686604: return bem_methodsSet_1(bevd_0);
case -304264586: return bem_objectNpSetDirect_1(bevd_0);
case 2105862247: return bem_methodCallsSetDirect_1(bevd_0);
case 1527423025: return bem_dynMethodsSetDirect_1(bevd_0);
case 305805845: return bem_lastMethodsSizeSet_1(bevd_0);
case 686048638: return bem_cnodeSetDirect_1(bevd_0);
case 1709566697: return bem_dynMethodsSet_1(bevd_0);
case 340011591: return bem_ccCacheSetDirect_1(bevd_0);
case 680480088: return bem_classHeadBodySet_1(bevd_0);
case 1839872882: return bem_transSetDirect_1(bevd_0);
case -1850341448: return bem_exceptDecSet_1(bevd_0);
case -1382897278: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1162156522: return bem_headExtSet_1(bevd_0);
case 77004232: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -124136354: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case 2146295869: return bem_nameToIdPathSetDirect_1(bevd_0);
case -2054323176: return bem_classEmitsSetDirect_1(bevd_0);
case 184392637: return bem_nameToIdPathSet_1(bevd_0);
case -1863892649: return bem_parentConfSetDirect_1(bevd_0);
case 949467430: return bem_onceCountSet_1(bevd_0);
case 147917510: return bem_ccCacheSet_1(bevd_0);
case -1855900775: return bem_instOfSetDirect_1(bevd_0);
case 1960529933: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1493999205: return bem_mnodeSet_1(bevd_0);
case -1360560319: return bem_gcMarksSetDirect_1(bevd_0);
case 1031200753: return bem_cnodeSet_1(bevd_0);
case 1191176750: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 630607896: return bem_classEmitsSet_1(bevd_0);
case 1901507392: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 928759557: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -443806036: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -348295685: return bem_heonSetDirect_1(bevd_0);
case -1957177586: return bem_boolNpSet_1(bevd_0);
case -1204743617: return bem_heonSet_1(bevd_0);
case -1360356406: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1793290425: return bem_classesInDepthOrderSet_1(bevd_0);
case 1853505864: return bem_fileExtSet_1(bevd_0);
case -51145431: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -294141752: return bem_methodCatchSetDirect_1(bevd_0);
case 1205927119: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1295096725: return bem_stringNpSetDirect_1(bevd_0);
case 1983758816: return bem_floatNpSet_1(bevd_0);
case -1264667292: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1935408823: return bem_onceDecRefsSetDirect_1(bevd_0);
case -511690288: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1398203560: return bem_boolNpSetDirect_1(bevd_0);
case -1785129258: return bem_classHeadersSet_1(bevd_0);
case 219910861: return bem_ccMethodsSet_1(bevd_0);
case -708408320: return bem_falseValueSetDirect_1(bevd_0);
case -319046774: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -84334328: return bem_inFilePathedSetDirect_1(bevd_0);
case 123364704: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1744479301: return bem_ntypesSetDirect_1(bevd_0);
case 750565179: return bem_methodCatchSet_1(bevd_0);
case -990161917: return bem_parentConfSet_1(bevd_0);
case -2113255311: return bem_nullValueSet_1(bevd_0);
case 1776359002: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1735530030: return bem_begin_1(bevd_0);
case 320114125: return bem_smnlcsSet_1(bevd_0);
case 723576085: return bem_objectNpSet_1(bevd_0);
case 486324193: return bem_preClassSet_1(bevd_0);
case 651721249: return bem_classCallsSet_1(bevd_0);
case 512729489: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1183675069: return bem_objectCcSetDirect_1(bevd_0);
case -2023906935: return bem_randSet_1(bevd_0);
case 1486679654: return bem_libEmitPathSetDirect_1(bevd_0);
case -565659437: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1309580499: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 548799924: return bem_callNamesSet_1(bevd_0);
case -467578317: return bem_synEmitPathSet_1(bevd_0);
case -570110629: return bem_emitLangSet_1(bevd_0);
case -1226089433: return bem_lineCountSetDirect_1(bevd_0);
case 423208573: return bem_instanceEqualSet_1(bevd_0);
case -548395035: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1832895812: return bem_deonSet_1(bevd_0);
case -2018762290: return bem_lastMethodsLinesSet_1(bevd_0);
case 631726084: return bem_constSet_1(bevd_0);
case -1192919647: return bem_inClassSet_1(bevd_0);
case -171721339: return bem_methodCallsSet_1(bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1634721353: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1832189577: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 43803970: return bem_returnTypeSetDirect_1(bevd_0);
case -258320110: return bem_falseValueSet_1(bevd_0);
case 99361175: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1918339483: return bem_nullValueSetDirect_1(bevd_0);
case 497326742: return bem_heowSetDirect_1(bevd_0);
case 1492826074: return bem_fileExtSetDirect_1(bevd_0);
case 1575573273: return bem_onceDecsSet_1(bevd_0);
case 1073870044: return bem_nameToIdSet_1(bevd_0);
case 930474266: return bem_transSet_1(bevd_0);
case 1246242002: return bem_inClassSetDirect_1(bevd_0);
case 1901451751: return bem_gcMarksSet_1(bevd_0);
case 1285868748: return bem_methodsSetDirect_1(bevd_0);
case -1564260397: return bem_onceDecsSetDirect_1(bevd_0);
case -1306878095: return bem_onceDecRefsCountSetDirect_1(bevd_0);
case 7733892: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -953998008: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1569285955: return bem_belslitsSetDirect_1(bevd_0);
case -675741355: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -873696112: return bem_onceCountSetDirect_1(bevd_0);
case -1590226241: return bem_msynSetDirect_1(bevd_0);
case -1093394748: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -52621632: return bem_qSet_1(bevd_0);
case 56608184: return bem_headExtSetDirect_1(bevd_0);
case -574329750: return bem_propertyDecsSet_1(bevd_0);
case -209888717: return bem_buildSet_1(bevd_0);
case -1800539309: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1048585607: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -94059682: return bem_lineCountSet_1(bevd_0);
case 893650928: return bem_superCallsSetDirect_1(bevd_0);
case 1130752158: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1192003470: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -187300612: return bem_ntypesSet_1(bevd_0);
case -524369573: return bem_methodBodySet_1(bevd_0);
case 1115669322: return bem_trueValueSet_1(bevd_0);
case 1045644519: return bem_classCallsSetDirect_1(bevd_0);
case 303889411: return bem_classConfSetDirect_1(bevd_0);
case 2070101211: return bem_idToNamePathSetDirect_1(bevd_0);
case 1936866364: return bem_shlibeSetDirect_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case 330963390: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 142328325: return bem_buildSetDirect_1(bevd_0);
case -571897364: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 906276201: return bem_maxDynArgsSetDirect_1(bevd_0);
case -749046838: return bem_instOfSet_1(bevd_0);
case 64324229: return bem_invpSetDirect_1(bevd_0);
case 164383017: return bem_ccMethodsSetDirect_1(bevd_0);
case 1364246935: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1708846361: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -2064510787: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1426031916: return bem_classConfSet_1(bevd_0);
case 2069548891: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 536018729: return bem_callNamesSetDirect_1(bevd_0);
case 1661036335: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2029492180: return bem_idToNamePathSet_1(bevd_0);
case -2145839228: return bem_classHeadBodySetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -645292326: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1687973462: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 37078669: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -190693014: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 671177669: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 822570235: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1274029020: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2132898740: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -716768877: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 720307412: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 859116931: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1053239201: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1310199708: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 951835725: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 607073871: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1359310400: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1216628463: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1330495313: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1651528258: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -451352603: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCCEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
}
