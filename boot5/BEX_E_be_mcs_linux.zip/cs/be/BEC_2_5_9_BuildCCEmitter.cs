namespace be {
/* IO:File: source/build/CCEmitter.be */
public sealed class BEC_2_5_9_BuildCCEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildCCEmitter() { }
static BEC_2_5_9_BuildCCEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildCCEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_0 = {0x63,0x63};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_1 = {0x2E,0x63,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_3 = {0x2E,0x68,0x70,0x70};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_4 = {0x2D,0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_5 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_6 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_7 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_8 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_9 = {0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_10 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_11 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_12 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_13 = {0x70,0x72,0x69,0x76,0x61,0x74,0x65,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_14 = {0x74,0x79,0x70,0x65,0x64,0x65,0x66,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_15 = {0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_16 = {0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_17 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_18 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x6E,0x61,0x6D,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_19 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x6C,0x66,0x69,0x6C,0x65,0x73,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_20 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_21 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_21, 18));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_22 = {0x3E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_22, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_23 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_23, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_24 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x76,0x6F,0x69,0x64,0x20,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_25 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_26 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_27 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_28 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x69,0x6E,0x74,0x33,0x32,0x5F,0x74,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x73,0x6D,0x6E,0x6C,0x65,0x63,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_29 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_29, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_30 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_30, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_31 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_32 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_33 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_34 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_35 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_36 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_37 = {0x3E,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_38 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_39 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_40 = {0x7D,0x3B,0x0A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_41 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_42 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_43 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_44 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_45 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_46 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_47 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_48 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_49 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_50 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_51 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_52 = {0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_53 = {0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_54 = {0x6E,0x75,0x6C,0x6C,0x70,0x74,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_55 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_56 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_56, 20));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_57 = {0x3E,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x66,0x72,0x6F,0x6D,0x5F,0x74,0x68,0x69,0x73,0x28,0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_57, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_58 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_59 = {0x62,0x65,0x65,0x5F,0x79,0x6F,0x73,0x75,0x70,0x65,0x72,0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_60 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_61 = {0x62,0x65,0x76,0x73,0x5F,0x73,0x75,0x70,0x65,0x72};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_61, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_62 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_63 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_64 = {0x63,0x63,0x5F,0x63,0x6C,0x61,0x73,0x73,0x48,0x65,0x61,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_65 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_65, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_66 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_66, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_67 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_67, 7));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_68 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_68, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_69 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_69, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_70 = {0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_71 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_72 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_73 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_73, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_74 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_75 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_76 = {0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x2E,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_76, 27));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_77 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_77, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_78 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_79 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_80 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_81 = {0x3E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_82 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_82, 9));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_83 = {0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_84 = {0x64,0x79,0x6E,0x61,0x6D,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_85 = {0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_85, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_86 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_86, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_87 = {0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_88 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_89 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_90 = {0x73,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_91 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_92 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x34,0x5F,0x36,0x5F,0x54,0x65,0x78,0x74,0x53,0x74,0x72,0x69,0x6E,0x67,0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_93 = {0x2C,0x20,0x62,0x65,0x63,0x63,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_94 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_95 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_96 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_96, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_97 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_97, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_98 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_98, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_99 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_99, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_100 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_100, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_101 = {0x66,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_101, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_102 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_102, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_103 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_103, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_104 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_104, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_105 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_105, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_106 = {0x6D,0x61,0x6B,0x65,0x5F,0x73,0x68,0x61,0x72,0x65,0x64,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_106, 12));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_107 = {0x3E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_107, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_108 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_108, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_109 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_109, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_110 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_110, 18));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_111 = {0x3E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_111, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_112 = {0x2D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_112, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_113 = {0x2D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_114 = {0x30,0x78};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_114, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_115 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_115, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_116 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_117 = {0x6D,0x61,0x69,0x6E,0x28,0x53,0x74,0x72,0x69,0x6E,0x67,0x5B,0x5D,0x20,0x61,0x72,0x67,0x73,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_117, 19));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_118 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_118, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_119 = {0x73,0x79,0x6E,0x63,0x68,0x72,0x6F,0x6E,0x69,0x7A,0x65,0x64,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_120 = {0x2E,0x63,0x6C,0x61,0x73,0x73,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_121 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x61,0x72,0x67,0x73,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_122 = {0x62,0x65,0x2E,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_123 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_124 = {};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_125 = {0x73,0x75,0x70,0x65,0x72};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_126 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_126, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_127 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_127, 6));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_128 = {0x3B,0x0A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_128, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_129 = {0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_130 = {0x20,0x3A,0x20,0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_131 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x3A,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_132 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_133 = {0x76,0x69,0x72,0x74,0x75,0x61,0x6C,0x20,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x36,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x4F,0x62,0x6A,0x65,0x63,0x74,0x3E,0x20,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_134 = {0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_135 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_136 = {0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_137 = {0x73,0x74,0x64,0x3A,0x3A,0x76,0x65,0x63,0x74,0x6F,0x72,0x3C,0x73,0x74,0x64,0x3A,0x3A,0x73,0x74,0x72,0x69,0x6E,0x67,0x3E,0x20,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_138 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_139 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_140 = {0x62,0x65,0x6D,0x73,0x5F,0x62,0x75,0x69,0x6C,0x64,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x61,0x6D,0x65,0x73,0x28,0x62,0x65,0x76,0x73,0x5F,0x6D,0x74,0x6E,0x61,0x6D,0x65,0x73,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_141 = {0x62,0x65,0x76,0x73,0x5F,0x66,0x69,0x65,0x6C,0x64,0x4E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x7B,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_142 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_143 = {0x20,0x7D,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_144 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_145 = {0x3A,0x3A,0x62,0x65,0x6D,0x73,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x28,0x29,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_146 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_147 = {0x28,0x29,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_148 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_149 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_150 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_151 = {0x42,0x45,0x44,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_151, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_152 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_152, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_153 = {0x42,0x45,0x48,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_153, 4));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_154 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_154, 1));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_155 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_156 = {0x63,0x63,0x68,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_157 = {0x23,0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x20,0x22,0x42,0x45,0x44,0x5F,0x34,0x5F,0x42,0x61,0x73,0x65,0x2E,0x68,0x70,0x70,0x22,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_158 = {0x75,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x73,0x74,0x64,0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_159 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_160 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_161 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_162 = {0x63,0x63,0x64,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_163 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_164 = {0x63,0x63,0x68,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_165 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_166 = {0x63,0x63,0x49,0x6D,0x70,0x6F,0x72,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_167 = {0x6E,0x61,0x6D,0x65,0x73,0x70,0x61,0x63,0x65,0x20,0x62,0x65,0x20,0x7B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_168 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_169 = {0x63,0x63,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_170 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_171 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_172 = {0x7D,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_173 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x75,0x6E,0x73,0x69,0x67,0x6E,0x65,0x64,0x20,0x63,0x68,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_174 = {0x5B,0x5D,0x20,0x3D,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_175 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_176 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_177 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_178 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_179 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_179, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_180 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_180, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_181 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_182 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_183 = {0x3A,0x3A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_184 = {0x3B,0x0A};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_185 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_185, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_186 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_186, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_187 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_187, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_188 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_52 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_188, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_189 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_53 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_189, 2));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_190 = {0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x3A,0x3A,0x69,0x6E,0x69,0x74,0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_54 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_190, 21));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_191 = {0x76,0x6F,0x69,0x64,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_192 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_193 = {0x3E,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_194 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_195 = {0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_196 = {0x75,0x6E,0x63,0x68,0x65,0x63,0x6B,0x65,0x64};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_197 = {0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_198 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_199 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_200 = {0x73,0x68,0x61,0x72,0x65,0x64,0x5F,0x70,0x74,0x72,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_201 = {0x3E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_202 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x28,0x29};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_203 = {0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_204 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x5F,0x70,0x6F,0x69,0x6E,0x74,0x65,0x72,0x5F,0x63,0x61,0x73,0x74,0x3C};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_205 = {0x3E,0x28};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_206 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_207 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_208 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_209 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_210 = {0x42,0x45,0x54,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x2A,0x20};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_211 = {0x3A,0x3A,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x54,0x79,0x70,0x65,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_212 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x26};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_213 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_214 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_215 = {0x62,0x65,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_55 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_215, 5));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_216 = {0x5F,0x62,0x65,0x76,0x73,0x5F,0x74,0x79,0x70,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_56 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_216, 10));
private static byte[] bece_BEC_2_5_9_BuildCCEmitter_bels_217 = {0x3A,0x3A};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildCCEmitter_bevo_57 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildCCEmitter_bels_217, 2));
public static new BEC_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;

public static new BET_2_5_9_BuildCCEmitter bece_BEC_2_5_9_BuildCCEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_headExt;
public BEC_2_4_6_TextString bevp_classHeadBody;
public BEC_2_4_6_TextString bevp_classHeaders;
public BEC_2_4_6_TextString bevp_deon;
public BEC_2_4_6_TextString bevp_heon;
public BEC_3_2_4_4_IOFilePath bevp_deop;
public BEC_3_2_4_4_IOFilePath bevp_heop;
public BEC_3_2_4_6_IOFileWriter bevp_deow;
public BEC_3_2_4_6_IOFileWriter bevp_heow;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_2));
bevp_headExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_3));
bevp_classHeadBody = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_classHeaders = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
base.bem_new_1(beva__build);
bevp_invp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_4));
bevp_scvp = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_5));
bevp_nullValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_6));
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildCCEmitter_bels_7));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_8));
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_addClassHeader_1(BEC_2_4_6_TextString beva_h) {
bevp_classHeaders.bem_addValue_1(beva_h);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 42 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 43 */
 else  /* Line: 44 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_9));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 45 */
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_10));
bevt_7_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_extends);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_11));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
if (bevp_parentConf == null) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 49 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_12));
bevl_begin.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_13));
bevl_begin.bem_addValue_1(bevt_11_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_14));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_15_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_16_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_15));
bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
} /* Line: 54 */
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_16));
bevl_begin.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_17));
bevl_begin.bem_addValue_1(bevt_19_tmpany_phold);
bevp_heow.bem_write_1(bevl_begin);
bevp_heow.bem_write_1(bevp_propertyDecs);
bevp_heow.bem_write_1(bevp_classHeadBody);
bevp_classHeadBody.bem_clear_0();
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_18));
bevp_heow.bem_write_1(bevt_20_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(57, bece_BEC_2_5_9_BuildCCEmitter_bels_19));
bevp_heow.bem_write_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(58, bece_BEC_2_5_9_BuildCCEmitter_bels_20));
bevp_heow.bem_write_1(bevt_22_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_0;
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_1;
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_30_tmpany_phold = bem_getHeaderInitialInst_1(bevp_classConf);
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_2;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
bevp_heow.bem_write_1(bevt_23_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(76, bece_BEC_2_5_9_BuildCCEmitter_bels_24));
bevp_heow.bem_write_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(62, bece_BEC_2_5_9_BuildCCEmitter_bels_25));
bevp_heow.bem_write_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_26));
bevp_heow.bem_write_1(bevt_34_tmpany_phold);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildCCEmitter_bels_27));
bevp_heow.bem_write_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(36, bece_BEC_2_5_9_BuildCCEmitter_bels_28));
bevp_heow.bem_write_1(bevt_36_tmpany_phold);
bevt_39_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_3;
bevt_40_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_add_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_4;
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_add_1(bevt_41_tmpany_phold);
bevp_deow.bem_write_1(bevt_37_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_31));
return bevt_42_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_32));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_33));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_34));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_35));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_36));
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_20_tmpany_phold);
bevt_24_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(83257762);
bevt_22_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_23_tmpany_phold );
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_37));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_17_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_38));
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_39));
bevp_heow.bem_write_1(bevp_classHeaders);
bevp_classHeaders.bem_clear_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_40));
bevp_heow.bem_write_1(bevt_0_tmpany_phold);
return bevl_end;
} /*method end*/
public override BEC_2_4_6_TextString bem_baseMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_41));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_overrideMtdDec_1(BEC_2_5_6_BuildMtdSyn beva_msyn) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_42));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_43));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(beva_mtdDec);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_44));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_45));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_46));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_47));
bevt_0_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_48));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_17_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(beva_exceptDec);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_49));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_50));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevp_classHeadBody.bem_addValue_1(bevt_23_tmpany_phold);
bevt_25_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_24_tmpany_phold = beva_returnType.bem_relEmitName_1(bevt_25_tmpany_phold);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevt_22_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_51));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevt_21_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_52));
bevt_19_tmpany_phold.bem_addValue_1(bevt_27_tmpany_phold);
bevp_classHeadBody.bem_addValue_1(beva_argDecs);
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_53));
bevp_classHeadBody.bem_addValue_1(bevt_28_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_2_tmpany_phold = bevp_ntypes.bem_NULLGet_0();
if (bevt_1_tmpany_phold.bevi_int == bevt_2_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_54));
} /* Line: 131 */
 else  /* Line: 130 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(510108416);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_55));
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(1560831110, bevt_6_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 132 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_5;
bevt_9_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_6;
bevl_tcall = bevt_7_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
} /* Line: 133 */
 else  /* Line: 130 */ {
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(510108416);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_58));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_1(1560831110, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 134 */ {
bevl_tcall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_59));
} /* Line: 135 */
 else  /* Line: 136 */ {
bevt_15_tmpany_phold = beva_node.bem_heldGet_0();
bevl_tcall = bem_nameForVar_1((BEC_2_5_3_BuildVar) bevt_15_tmpany_phold );
} /* Line: 137 */
} /* Line: 130 */
} /* Line: 130 */
return bevl_tcall;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_tcall = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(510108416);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_60));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1560831110, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 143 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_7;
bevl_tcall = bevt_4_tmpany_phold.bem_add_1(bevp_scvp);
return bevl_tcall;
} /* Line: 145 */
bevt_5_tmpany_phold = base.bem_formCallTarg_1(beva_node);
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_62));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_63));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_handleClassEmit_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
bevt_2_tmpany_phold = beva_node.bem_heldGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(471004704);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_64));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1791929854, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(894615671);
bevp_classHeaders.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 156 */
 else  /* Line: 157 */ {
base.bem_handleClassEmit_1(beva_node);
} /* Line: 158 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevl_clh = null;
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_8;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_9;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_10;
bevt_8_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_11;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_12;
bevl_clh = bevt_4_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bem_addClassHeader_1(bevl_clh);
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_16_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_70));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevt_14_tmpany_phold.bem_addValue_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_71));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_72));
bevt_11_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_13;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(23, bece_BEC_2_5_9_BuildCCEmitter_bels_74));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_75));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1663291856);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1865033616);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_14;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_15;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_typeDecForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_12_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = beva_v.bem_isTypedGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 187 */ {
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_78));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = bevp_objectCc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_79));
bevt_2_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
} /* Line: 188 */
 else  /* Line: 189 */ {
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_80));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) beva_b.bem_addValue_1(bevt_10_tmpany_phold);
bevt_13_tmpany_phold = beva_v.bem_namepathGet_0();
bevt_12_tmpany_phold = bem_getClassConfig_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_relEmitName_1(bevt_14_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_81));
bevt_8_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
} /* Line: 190 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevl_ccall = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_16;
bevt_0_tmpany_phold = beva_type.bem_equals_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 195 */ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_83));
} /* Line: 196 */
 else  /* Line: 197 */ {
bevl_ccall = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_84));
} /* Line: 198 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_17;
bevt_4_tmpany_phold = bevl_ccall.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_6_tmpany_phold = beva_cc.bem_relEmitName_1(bevt_7_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_18;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_2_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_afterCast_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_87));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevt_8_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(33, bece_BEC_2_5_9_BuildCCEmitter_bels_88));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_89));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(beva_bemBase);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_90));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_91));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildCCEmitter_bels_92));
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_19_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bem_addValue_1(beva_len);
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_93));
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevt_20_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(beva_belsBase);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_94));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_addValue_1(bevt_21_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_95));
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_23_tmpany_phold);
bevt_22_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_19;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_20;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1464534398);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_21;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_22;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1464534398);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 224 */ {
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_25;
bevt_8_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_8_tmpany_phold);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_26;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_27;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_28;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 225 */
bevt_18_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_29;
bevt_20_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_19_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_20_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_30;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bem_add_1(beva_lisz);
bevt_22_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_31;
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(beva_belsName);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_32;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
return bevt_12_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_33;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_typeName);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_34;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
beva_lival.bem_getInt_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toHexString_1(beva_hs);
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_35;
bevt_0_tmpany_phold = bevl_bc.bem_begins_1(bevt_1_tmpany_phold);
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 238 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_bc = bevl_bc.bem_substring_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_113));
beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 240 */
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_36;
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_once_0();
beva_sdec.bem_addValue_1(bevt_4_tmpany_phold);
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_37;
bevt_1_tmpany_phold = beva_typeName.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_anyName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_116));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevl_ms = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_38;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_39;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevl_ms = bevt_0_tmpany_phold.bem_add_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildCCEmitter_bels_119));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_7_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_libEmitName);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_120));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildCCEmitter_bels_121));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(32, bece_BEC_2_5_9_BuildCCEmitter_bels_122));
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_ms.bem_addValue_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(510108416);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_123));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildCCEmitter_bels_124));
return bevt_18_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_125));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_40;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_parent);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
BEC_2_4_6_TextString bevl_beh = null;
BEC_2_4_6_TextString bevl_bet = null;
BEC_2_5_4_LogicBool bevl_firstmnsyn = null;
BEC_2_5_6_BuildMtdSyn bevl_mnsyn = null;
BEC_2_5_4_LogicBool bevl_firstptsyn = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_2_4_6_IOFileWriter bevt_54_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_41;
bevt_5_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_42;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevp_deow.bem_write_1(bevt_2_tmpany_phold);
bevl_beh = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_129));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_9_tmpany_phold);
bevt_10_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(24, bece_BEC_2_5_9_BuildCCEmitter_bels_130));
bevt_7_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_131));
bevl_beh.bem_addValue_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) bevl_beh.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_132));
bevt_13_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(66, bece_BEC_2_5_9_BuildCCEmitter_bels_133));
bevl_beh.bem_addValue_1(bevt_16_tmpany_phold);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_134));
bevl_beh.bem_addValue_1(bevt_17_tmpany_phold);
bevp_heow.bem_write_1(bevl_beh);
bevl_bet = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_21_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_21_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_135));
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_addValue_1(bevt_22_tmpany_phold);
bevt_23_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_addValue_1(bevt_23_tmpany_phold);
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_136));
bevt_18_tmpany_phold.bem_addValue_1(bevt_24_tmpany_phold);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildCCEmitter_bels_137));
bevl_bet.bem_addValue_1(bevt_25_tmpany_phold);
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_26_tmpany_phold = bevp_csyn.bem_mtdListGet_0();
bevt_0_tmpany_loop = bevt_26_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 294 */ {
bevt_27_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_27_tmpany_phold).bevi_bool) /* Line: 294 */ {
bevl_mnsyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_tmpany_loop.bemd_0(1538356292);
if (bevl_firstmnsyn.bevi_bool) /* Line: 295 */ {
bevl_firstmnsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 296 */
 else  /* Line: 297 */ {
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_138));
bevl_bet.bem_addValue_1(bevt_28_tmpany_phold);
} /* Line: 298 */
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_31_tmpany_phold = bevl_mnsyn.bem_nameGet_0();
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) bevt_30_tmpany_phold.bem_addValue_1(bevt_31_tmpany_phold);
bevt_29_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 300 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_139));
bevl_bet.bem_addValue_1(bevt_32_tmpany_phold);
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildCCEmitter_bels_140));
bevl_bet.bem_addValue_1(bevt_33_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(20, bece_BEC_2_5_9_BuildCCEmitter_bels_141));
bevl_bet.bem_addValue_1(bevt_34_tmpany_phold);
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_35_tmpany_phold = bevp_csyn.bem_ptyListGet_0();
bevt_1_tmpany_loop = bevt_35_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 307 */ {
bevt_36_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 307 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_1_tmpany_loop.bemd_0(1538356292);
if (bevl_firstptsyn.bevi_bool) /* Line: 308 */ {
bevl_firstptsyn = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 309 */
 else  /* Line: 310 */ {
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_142));
bevl_bet.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 311 */
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevp_q);
bevt_40_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) bevt_39_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_38_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 313 */
 else  /* Line: 307 */ {
break;
} /* Line: 307 */
} /* Line: 307 */
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_143));
bevl_bet.bem_addValue_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_144));
bevl_bet.bem_addValue_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevp_classConf.bem_typeEmitNameGet_0();
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_44_tmpany_phold);
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_145));
bevt_43_tmpany_phold.bem_addValue_1(bevt_45_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_146));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevl_bet.bem_addValue_1(bevt_48_tmpany_phold);
bevt_49_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevt_47_tmpany_phold.bem_addValue_1(bevt_49_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildCCEmitter_bels_147));
bevt_46_tmpany_phold.bem_addValue_1(bevt_50_tmpany_phold);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_148));
bevl_bet.bem_addValue_1(bevt_51_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_149));
bevl_bet.bem_addValue_1(bevt_52_tmpany_phold);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_150));
bevl_bet.bem_addValue_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = bem_getClassOutput_0();
bevt_54_tmpany_phold.bem_write_1(bevl_bet);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_prepHeaderOutput_0() {
BEC_2_4_6_TextString bevl_libName = null;
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_20_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_28_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_31_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_54_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
if (bevp_deow == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 336 */ {
bevl_libName = bevp_build.bem_libNameGet_0();
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_43;
bevt_8_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_44;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_libName);
bevp_deon = bevt_4_tmpany_phold.bem_add_1(bevp_headExt);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_45;
bevt_14_tmpany_phold = bevl_libName.bem_sizeGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_46;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevl_libName);
bevp_heon = bevt_10_tmpany_phold.bem_add_1(bevp_headExt);
bevt_16_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_16_tmpany_phold.bem_addStep_1(bevp_deon);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_17_tmpany_phold.bem_addStep_1(bevp_heon);
bevt_21_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_existsGet_0();
if (bevt_19_tmpany_phold.bevi_bool) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 342 */ {
bevt_23_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_fileGet_0();
bevt_22_tmpany_phold.bem_makeDirs_0();
} /* Line: 343 */
bevt_25_tmpany_phold = bevp_deop.bem_fileGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_writerGet_0();
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_24_tmpany_phold.bemd_0(-1540577205);
bevt_27_tmpany_phold = bevp_heop.bem_fileGet_0();
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_writerGet_0();
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_26_tmpany_phold.bemd_0(-1540577205);
bevt_29_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_155));
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_has_1(bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevt_32_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_156));
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bem_get_1(bevt_33_tmpany_phold);
bevt_0_tmpany_loop = bevt_31_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 350 */ {
bevt_34_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 350 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1538356292);
bevt_35_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_35_tmpany_phold.bem_fileGet_0();
bevt_37_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-1540577205);
bevl_inc = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bemd_0(1558784278);
bevt_38_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_38_tmpany_phold.bemd_0(-391602586);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 356 */
 else  /* Line: 350 */ {
break;
} /* Line: 350 */
} /* Line: 350 */
} /* Line: 350 */
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_157));
bevp_heow.bem_write_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_158));
bevp_heow.bem_write_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_159));
bevp_deow.bem_write_1(bevt_41_tmpany_phold);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_160));
bevp_heow.bem_write_1(bevt_42_tmpany_phold);
bevt_44_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_161));
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_has_1(bevt_45_tmpany_phold);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 370 */ {
bevt_47_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_162));
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_get_1(bevt_48_tmpany_phold);
bevt_1_tmpany_loop = bevt_46_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 372 */ {
bevt_49_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_49_tmpany_phold).bevi_bool) /* Line: 372 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(1538356292);
bevt_50_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_50_tmpany_phold.bem_fileGet_0();
bevt_52_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_51_tmpany_phold = bevt_52_tmpany_phold.bemd_0(-1540577205);
bevl_inc = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bemd_0(1558784278);
bevt_53_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_53_tmpany_phold.bemd_0(-391602586);
bevp_deow.bem_write_1(bevl_inc);
} /* Line: 378 */
 else  /* Line: 372 */ {
break;
} /* Line: 372 */
} /* Line: 372 */
} /* Line: 372 */
bevt_55_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_163));
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_has_1(bevt_56_tmpany_phold);
if (bevt_54_tmpany_phold.bevi_bool) /* Line: 381 */ {
bevt_58_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_9_BuildCCEmitter_bels_164));
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_get_1(bevt_59_tmpany_phold);
bevt_2_tmpany_loop = bevt_57_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 383 */ {
bevt_60_tmpany_phold = bevt_2_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_60_tmpany_phold).bevi_bool) /* Line: 383 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(1538356292);
bevt_61_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_61_tmpany_phold.bem_fileGet_0();
bevt_63_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_62_tmpany_phold = bevt_63_tmpany_phold.bemd_0(-1540577205);
bevl_inc = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bemd_0(1558784278);
bevt_64_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_64_tmpany_phold.bemd_0(-391602586);
bevp_heow.bem_write_1(bevl_inc);
} /* Line: 389 */
 else  /* Line: 383 */ {
break;
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 383 */
} /* Line: 381 */
return this;
} /*method end*/
public override BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) {
base.bem_begin_1(beva_transi);
bem_prepHeaderOutput_0();
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_5_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_6_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_7_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_14_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_26_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 402 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_6_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_fileGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_existsGet_0();
if (bevt_4_tmpany_phold.bevi_bool) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_8_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_fileGet_0();
bevt_7_tmpany_phold.bem_makeDirs_0();
} /* Line: 405 */
bevt_10_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_9_tmpany_phold.bemd_0(-1540577205);
bevt_12_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_165));
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_has_1(bevt_13_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevt_15_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_166));
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_get_1(bevt_16_tmpany_phold);
bevt_0_tmpany_loop = bevt_14_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 412 */ {
bevt_17_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_17_tmpany_phold).bevi_bool) /* Line: 412 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1538356292);
bevt_18_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_18_tmpany_phold.bem_fileGet_0();
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(-1540577205);
bevl_inc = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bemd_0(1558784278);
bevt_21_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_21_tmpany_phold.bemd_0(-391602586);
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 418 */
 else  /* Line: 412 */ {
break;
} /* Line: 412 */
} /* Line: 412 */
} /* Line: 412 */
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildCCEmitter_bels_167));
bevp_shlibe.bem_write_1(bevt_22_tmpany_phold);
bevp_lineCount.bem_increment_0();
bevt_24_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_168));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_has_1(bevt_25_tmpany_phold);
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 424 */ {
bevt_27_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_169));
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_get_1(bevt_28_tmpany_phold);
bevt_1_tmpany_loop = bevt_26_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 425 */ {
bevt_29_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_29_tmpany_phold).bevi_bool) /* Line: 425 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bemd_0(1538356292);
bevt_30_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_30_tmpany_phold.bem_fileGet_0();
bevt_32_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_0(-1540577205);
bevl_inc = (BEC_2_4_6_TextString) bevt_31_tmpany_phold.bemd_0(1558784278);
bevt_33_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_33_tmpany_phold.bemd_0(-391602586);
bevt_34_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_34_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 430 */
 else  /* Line: 425 */ {
break;
} /* Line: 425 */
} /* Line: 425 */
} /* Line: 425 */
} /* Line: 424 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_170));
beva_libe.bem_write_1(bevt_0_tmpany_phold);
beva_libe.bem_close_0();
bevp_shlibe = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_171));
bevp_deow.bem_write_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_172));
bevp_heow.bem_write_1(bevt_2_tmpany_phold);
bevp_deow.bem_close_0();
bevp_heow.bem_close_0();
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_coanyiantReturnsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_9_BuildCCEmitter_bels_173));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_9_BuildCCEmitter_bels_174));
bevt_0_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(301369084);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildCCEmitter_bels_175));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 469 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1778311841);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 469 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(1538356292);
if (bevl_first.bevi_bool) /* Line: 470 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 471 */
 else  /* Line: 472 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_176));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 473 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_177));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 475 */
 else  /* Line: 469 */ {
break;
} /* Line: 469 */
} /* Line: 469 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_178));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevl_initialDec = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevl_initialDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_47;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_48;
bevl_bein = bevt_0_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_181));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevl_initialDec.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_182));
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_183));
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevl_bein);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_184));
bevt_4_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
return bevl_initialDec;
} /*method end*/
public BEC_2_4_6_TextString bem_getHeaderInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_49;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_50;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevl_bein;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_51;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_52;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_53;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_runtimeInitGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_54;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_4_6_TextString bevl_oname = null;
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_4_6_TextString bevl_asnr = null;
BEC_2_4_6_TextString bevl_tinst = null;
BEC_2_5_11_BuildClassConfig bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getClassConfig_1(bevp_objectNp);
bevt_1_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_oname = bevt_0_tmpany_phold.bem_relEmitName_1(bevt_1_tmpany_phold);
bevt_3_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bemd_0(83257762);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_2_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_12_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildCCEmitter_bels_191));
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) bevt_11_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevt_10_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(29, bece_BEC_2_5_9_BuildCCEmitter_bels_192));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildCCEmitter_bels_193));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_16_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_194));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_17_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_asnr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_195));
bevt_19_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 516 */ {
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildCCEmitter_bels_196));
bevl_asnr = bem_formCast_3(bevp_classConf, bevt_20_tmpany_phold, bevl_asnr);
} /* Line: 517 */
bevt_24_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildCCEmitter_bels_197));
bevt_23_tmpany_phold = (BEC_2_4_6_TextString) bevt_24_tmpany_phold.bem_addValue_1(bevt_25_tmpany_phold);
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) bevt_23_tmpany_phold.bem_addValue_1(bevl_asnr);
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_198));
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) bevt_22_tmpany_phold.bem_addValue_1(bevt_26_tmpany_phold);
bevt_21_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_28_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_199));
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_28_tmpany_phold);
bevt_27_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_37_tmpany_phold = bem_overrideMtdDecGet_0();
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_37_tmpany_phold);
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildCCEmitter_bels_200));
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) bevt_36_tmpany_phold.bem_addValue_1(bevt_38_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) bevt_35_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_201));
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevt_34_tmpany_phold.bem_addValue_1(bevt_39_tmpany_phold);
bevt_40_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_9_BuildCCEmitter_bels_202));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_41_tmpany_phold);
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) bevt_31_tmpany_phold.bem_addValue_1(bevp_exceptDec);
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_203));
bevt_29_tmpany_phold = (BEC_2_4_6_TextString) bevt_30_tmpany_phold.bem_addValue_1(bevt_42_tmpany_phold);
bevt_29_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_44_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_notEquals_1(bevl_oname);
if (bevt_43_tmpany_phold.bevi_bool) /* Line: 527 */ {
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(27, bece_BEC_2_5_9_BuildCCEmitter_bels_204));
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_50_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) bevt_49_tmpany_phold.bem_addValue_1(bevl_oname);
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_205));
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevt_48_tmpany_phold.bem_addValue_1(bevt_51_tmpany_phold);
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevt_47_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildCCEmitter_bels_206));
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) bevt_46_tmpany_phold.bem_addValue_1(bevt_52_tmpany_phold);
bevt_45_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 528 */
 else  /* Line: 529 */ {
bevt_56_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildCCEmitter_bels_207));
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_56_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_208));
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) bevt_54_tmpany_phold.bem_addValue_1(bevt_57_tmpany_phold);
bevt_53_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 530 */
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_209));
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_59_tmpany_phold);
bevt_58_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_tinst = bem_getTypeInst_1(bevl_newcc);
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildCCEmitter_bels_210));
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_63_tmpany_phold);
bevt_64_tmpany_phold = bevl_newcc.bem_emitNameGet_0();
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bem_addValue_1(bevt_64_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(18, bece_BEC_2_5_9_BuildCCEmitter_bels_211));
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) bevt_61_tmpany_phold.bem_addValue_1(bevt_65_tmpany_phold);
bevt_60_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_69_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildCCEmitter_bels_212));
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_69_tmpany_phold);
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) bevt_68_tmpany_phold.bem_addValue_1(bevl_tinst);
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_213));
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevt_67_tmpany_phold.bem_addValue_1(bevt_70_tmpany_phold);
bevt_66_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildCCEmitter_bels_214));
bevt_71_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_72_tmpany_phold);
bevt_71_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_getTypeInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevl_nccn = null;
BEC_2_4_6_TextString bevl_bein = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_build.bem_libNameGet_0();
bevl_nccn = beva_newcc.bem_relEmitName_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_55;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevl_nccn);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_56;
bevl_bein = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_6_tmpany_phold = bece_BEC_2_5_9_BuildCCEmitter_bevo_57;
bevt_5_tmpany_phold = bevl_nccn.bem_add_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_bein);
return bevt_4_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGet_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_4_6_TextString bem_headExtGetDirect_0() {
return bevp_headExt;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_headExtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_headExt = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGet_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadBodyGetDirect_0() {
return bevp_classHeadBody;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadBodySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeadBody = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGet_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_4_6_TextString bem_classHeadersGetDirect_0() {
return bevp_classHeaders;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_classHeadersSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_classHeaders = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGet_0() {
return bevp_deon;
} /*method end*/
public BEC_2_4_6_TextString bem_deonGetDirect_0() {
return bevp_deon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGet_0() {
return bevp_heon;
} /*method end*/
public BEC_2_4_6_TextString bem_heonGetDirect_0() {
return bevp_heon;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heon = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGet_0() {
return bevp_deop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_deopGetDirect_0() {
return bevp_deop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGet_0() {
return bevp_heop;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_heopGetDirect_0() {
return bevp_heop;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heopSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heop = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGet_0() {
return bevp_deow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_deowGetDirect_0() {
return bevp_deow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_deowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGet_0() {
return bevp_heow;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_heowGetDirect_0() {
return bevp_heow;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_heowSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_heow = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildCCEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 19, 20, 22, 23, 24, 28, 30, 31, 32, 33, 34, 38, 42, 42, 43, 43, 43, 45, 45, 47, 47, 47, 47, 47, 47, 49, 49, 50, 50, 52, 52, 54, 54, 54, 54, 54, 54, 54, 57, 57, 59, 59, 61, 63, 65, 67, 69, 69, 70, 70, 71, 71, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 73, 73, 74, 74, 75, 75, 76, 76, 77, 77, 79, 79, 79, 79, 79, 79, 81, 81, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 86, 86, 86, 86, 86, 86, 86, 86, 86, 86, 86, 88, 88, 88, 92, 94, 95, 96, 96, 97, 101, 101, 105, 105, 109, 109, 114, 114, 114, 114, 114, 114, 114, 114, 114, 114, 114, 114, 114, 114, 114, 116, 118, 118, 118, 118, 118, 118, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 122, 124, 124, 130, 130, 130, 130, 131, 132, 132, 132, 132, 133, 133, 133, 133, 133, 134, 134, 134, 134, 135, 137, 137, 139, 143, 143, 143, 143, 144, 144, 145, 147, 147, 151, 151, 151, 151, 151, 151, 151, 151, 155, 155, 155, 155, 156, 156, 156, 158, 164, 164, 164, 164, 164, 166, 166, 166, 166, 166, 166, 166, 166, 168, 170, 172, 172, 172, 172, 172, 172, 172, 172, 172, 172, 172, 174, 179, 179, 179, 180, 181, 181, 181, 181, 181, 181, 183, 183, 183, 183, 183, 183, 183, 183, 183, 183, 187, 187, 187, 188, 188, 188, 188, 188, 188, 188, 190, 190, 190, 190, 190, 190, 190, 190, 190, 195, 195, 196, 198, 200, 200, 200, 200, 200, 200, 200, 200, 205, 205, 209, 209, 209, 209, 209, 209, 209, 209, 209, 209, 209, 209, 209, 209, 209, 210, 210, 210, 210, 210, 210, 210, 210, 210, 212, 212, 212, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 216, 220, 220, 220, 220, 220, 220, 220, 220, 220, 220, 220, 220, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 225, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 227, 231, 231, 231, 231, 231, 236, 237, 238, 238, 239, 239, 240, 240, 242, 242, 242, 243, 249, 249, 249, 249, 253, 253, 257, 257, 257, 257, 257, 258, 258, 258, 258, 258, 258, 259, 259, 259, 260, 260, 260, 260, 260, 260, 260, 260, 262, 262, 266, 266, 270, 270, 270, 270, 274, 274, 281, 281, 281, 281, 281, 281, 282, 283, 283, 283, 283, 283, 283, 284, 284, 285, 285, 285, 285, 286, 286, 287, 287, 288, 290, 291, 291, 291, 291, 291, 291, 291, 291, 292, 292, 293, 294, 294, 0, 294, 294, 296, 298, 298, 300, 300, 300, 300, 302, 302, 303, 303, 305, 305, 306, 307, 307, 0, 307, 307, 309, 311, 311, 313, 313, 313, 313, 315, 315, 317, 317, 319, 319, 319, 319, 320, 320, 320, 320, 320, 320, 321, 321, 322, 322, 323, 323, 324, 324, 336, 336, 337, 338, 338, 338, 338, 338, 338, 338, 339, 339, 339, 339, 339, 339, 339, 340, 340, 341, 341, 342, 342, 342, 342, 342, 343, 343, 343, 345, 345, 345, 346, 346, 346, 348, 348, 348, 350, 350, 350, 350, 0, 350, 350, 352, 352, 353, 353, 353, 354, 354, 356, 360, 360, 361, 361, 363, 363, 364, 364, 370, 370, 370, 372, 372, 372, 372, 0, 372, 372, 374, 374, 375, 375, 375, 376, 376, 378, 381, 381, 381, 383, 383, 383, 383, 0, 383, 383, 385, 385, 386, 386, 386, 387, 387, 389, 396, 397, 402, 402, 403, 404, 404, 404, 404, 404, 405, 405, 405, 407, 407, 407, 410, 410, 410, 412, 412, 412, 412, 0, 412, 412, 414, 414, 415, 415, 415, 416, 416, 418, 422, 422, 423, 424, 424, 424, 425, 425, 425, 425, 0, 425, 425, 426, 426, 427, 427, 427, 428, 428, 429, 429, 430, 436, 441, 441, 442, 443, 445, 445, 447, 447, 448, 449, 454, 454, 458, 458, 458, 458, 458, 463, 463, 464, 466, 466, 466, 466, 468, 469, 0, 469, 469, 471, 473, 473, 475, 475, 475, 475, 475, 475, 479, 479, 479, 484, 486, 486, 486, 486, 486, 488, 488, 488, 488, 488, 488, 488, 488, 488, 488, 488, 488, 488, 490, 494, 494, 495, 495, 495, 495, 496, 500, 500, 501, 501, 501, 501, 502, 502, 502, 502, 506, 506, 506, 510, 510, 510, 511, 511, 511, 512, 514, 514, 514, 514, 514, 514, 514, 514, 514, 514, 514, 514, 514, 514, 514, 515, 516, 516, 517, 517, 520, 520, 520, 520, 520, 520, 520, 522, 522, 522, 525, 525, 525, 525, 525, 525, 525, 525, 525, 525, 525, 525, 525, 525, 525, 527, 527, 528, 528, 528, 528, 528, 528, 528, 528, 528, 530, 530, 530, 530, 530, 530, 533, 533, 533, 535, 537, 537, 537, 537, 537, 537, 537, 539, 539, 539, 539, 539, 539, 541, 541, 541, 546, 546, 547, 547, 547, 547, 548, 548, 548, 548, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 314, 363, 368, 369, 370, 371, 374, 375, 377, 378, 379, 380, 381, 382, 383, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502, 503, 504, 505, 511, 512, 513, 514, 515, 516, 520, 521, 525, 526, 530, 531, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 618, 619, 620, 625, 626, 629, 630, 631, 632, 634, 635, 636, 637, 638, 641, 642, 643, 644, 646, 649, 650, 654, 664, 665, 666, 667, 669, 670, 671, 673, 674, 684, 685, 686, 687, 688, 689, 690, 691, 701, 702, 703, 704, 706, 707, 708, 711, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 825, 826, 831, 832, 833, 834, 835, 836, 837, 838, 841, 842, 843, 844, 845, 846, 847, 848, 849, 864, 865, 867, 870, 872, 873, 874, 875, 876, 877, 878, 879, 883, 884, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934, 935, 936, 937, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 977, 978, 979, 980, 981, 982, 983, 984, 985, 986, 987, 988, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1049, 1050, 1051, 1052, 1053, 1063, 1064, 1065, 1066, 1068, 1069, 1070, 1071, 1073, 1074, 1075, 1076, 1083, 1084, 1085, 1086, 1090, 1091, 1114, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1141, 1142, 1148, 1149, 1150, 1151, 1155, 1156, 1223, 1224, 1225, 1226, 1227, 1228, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1260, 1260, 1263, 1265, 1267, 1270, 1271, 1273, 1274, 1275, 1276, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1290, 1293, 1295, 1297, 1300, 1301, 1303, 1304, 1305, 1306, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1406, 1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1439, 1440, 1441, 1442, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1454, 1455, 1456, 1457, 1457, 1460, 1462, 1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1489, 1490, 1491, 1492, 1492, 1495, 1497, 1498, 1499, 1500, 1501, 1502, 1503, 1504, 1505, 1512, 1513, 1514, 1516, 1517, 1518, 1519, 1519, 1522, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1531, 1532, 1543, 1544, 1586, 1591, 1592, 1593, 1594, 1595, 1596, 1601, 1602, 1603, 1604, 1606, 1607, 1608, 1609, 1610, 1611, 1613, 1614, 1615, 1616, 1616, 1619, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1636, 1637, 1638, 1639, 1640, 1641, 1643, 1644, 1645, 1646, 1646, 1649, 1651, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1659, 1660, 1661, 1669, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1684, 1689, 1690, 1697, 1698, 1699, 1700, 1701, 1723, 1724, 1725, 1726, 1727, 1728, 1729, 1730, 1731, 1731, 1734, 1736, 1738, 1741, 1742, 1744, 1745, 1746, 1747, 1748, 1749, 1755, 1756, 1757, 1779, 1780, 1781, 1782, 1783, 1784, 1785, 1786, 1787, 1788, 1789, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1797, 1798, 1807, 1808, 1809, 1810, 1811, 1812, 1813, 1825, 1826, 1827, 1828, 1829, 1830, 1831, 1832, 1833, 1834, 1839, 1840, 1841, 1922, 1923, 1924, 1925, 1926, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943, 1944, 1945, 1946, 1948, 1949, 1951, 1952, 1953, 1954, 1955, 1956, 1957, 1958, 1959, 1960, 1961, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1969, 1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1990, 1991, 1992, 1993, 1994, 1995, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2036, 2037, 2038, 2041, 2044, 2047, 2051, 2055, 2058, 2061, 2065, 2069, 2072, 2075, 2079, 2083, 2086, 2089, 2093, 2097, 2100, 2103, 2107, 2111, 2114, 2117, 2121, 2125, 2128, 2131, 2135, 2139, 2142, 2145, 2149, 2153, 2156, 2159, 2163, 2167, 2170, 2173, 2177};
/* BEGIN LINEINFO 
assign 1 18 299
new 0 18 299
assign 1 19 300
new 0 19 300
assign 1 20 301
new 0 20 301
assign 1 22 302
new 0 22 302
assign 1 23 303
new 0 23 303
assign 1 24 304
new 0 24 304
new 1 28 305
assign 1 30 306
new 0 30 306
assign 1 31 307
new 0 31 307
assign 1 32 308
new 0 32 308
assign 1 33 309
new 0 33 309
assign 1 34 310
new 0 34 310
addValue 1 38 314
assign 1 42 363
def 1 42 368
assign 1 43 369
libNameGet 0 43 369
assign 1 43 370
relEmitName 1 43 370
assign 1 43 371
extend 1 43 371
assign 1 45 374
new 0 45 374
assign 1 45 375
extend 1 45 375
assign 1 47 377
new 0 47 377
assign 1 47 378
emitNameGet 0 47 378
assign 1 47 379
addValue 1 47 379
assign 1 47 380
addValue 1 47 380
assign 1 47 381
new 0 47 381
assign 1 47 382
addValue 1 47 382
assign 1 49 383
def 1 49 388
assign 1 50 389
new 0 50 389
addValue 1 50 390
assign 1 52 391
new 0 52 391
addValue 1 52 392
assign 1 54 393
new 0 54 393
assign 1 54 394
addValue 1 54 394
assign 1 54 395
libNameGet 0 54 395
assign 1 54 396
relEmitName 1 54 396
assign 1 54 397
addValue 1 54 397
assign 1 54 398
new 0 54 398
addValue 1 54 399
assign 1 57 401
new 0 57 401
addValue 1 57 402
assign 1 59 403
new 0 59 403
addValue 1 59 404
write 1 61 405
write 1 63 406
write 1 65 407
clear 0 67 408
assign 1 69 409
new 0 69 409
write 1 69 410
assign 1 70 411
new 0 70 411
write 1 70 412
assign 1 71 413
new 0 71 413
write 1 71 414
assign 1 72 415
new 0 72 415
assign 1 72 416
emitNameGet 0 72 416
assign 1 72 417
add 1 72 417
assign 1 72 418
new 0 72 418
assign 1 72 419
add 1 72 419
assign 1 72 420
getHeaderInitialInst 1 72 420
assign 1 72 421
add 1 72 421
assign 1 72 422
new 0 72 422
assign 1 72 423
add 1 72 423
write 1 72 424
assign 1 73 425
new 0 73 425
write 1 73 426
assign 1 74 427
new 0 74 427
write 1 74 428
assign 1 75 429
new 0 75 429
write 1 75 430
assign 1 76 431
new 0 76 431
write 1 76 432
assign 1 77 433
new 0 77 433
write 1 77 434
assign 1 79 435
new 0 79 435
assign 1 79 436
emitNameGet 0 79 436
assign 1 79 437
add 1 79 437
assign 1 79 438
new 0 79 438
assign 1 79 439
add 1 79 439
write 1 79 440
assign 1 81 441
new 0 81 441
return 1 81 442
assign 1 85 474
overrideMtdDecGet 0 85 474
assign 1 85 475
addValue 1 85 475
assign 1 85 476
new 0 85 476
assign 1 85 477
addValue 1 85 477
assign 1 85 478
getClassConfig 1 85 478
assign 1 85 479
libNameGet 0 85 479
assign 1 85 480
relEmitName 1 85 480
assign 1 85 481
addValue 1 85 481
assign 1 85 482
new 0 85 482
assign 1 85 483
addValue 1 85 483
assign 1 85 484
emitNameGet 0 85 484
assign 1 85 485
addValue 1 85 485
assign 1 85 486
new 0 85 486
assign 1 85 487
addValue 1 85 487
assign 1 85 488
addValue 1 85 488
assign 1 85 489
new 0 85 489
assign 1 85 490
addValue 1 85 490
addValue 1 85 491
assign 1 86 492
new 0 86 492
assign 1 86 493
addValue 1 86 493
assign 1 86 494
heldGet 0 86 494
assign 1 86 495
namepathGet 0 86 495
assign 1 86 496
getClassConfig 1 86 496
assign 1 86 497
libNameGet 0 86 497
assign 1 86 498
relEmitName 1 86 498
assign 1 86 499
addValue 1 86 499
assign 1 86 500
new 0 86 500
assign 1 86 501
addValue 1 86 501
addValue 1 86 502
assign 1 88 503
new 0 88 503
assign 1 88 504
addValue 1 88 504
addValue 1 88 505
assign 1 92 511
new 0 92 511
write 1 94 512
clear 0 95 513
assign 1 96 514
new 0 96 514
write 1 96 515
return 1 97 516
assign 1 101 520
new 0 101 520
return 1 101 521
assign 1 105 525
new 0 105 525
return 1 105 526
assign 1 109 530
new 0 109 530
return 1 109 531
assign 1 114 563
addValue 1 114 563
assign 1 114 564
new 0 114 564
assign 1 114 565
addValue 1 114 565
assign 1 114 566
libNameGet 0 114 566
assign 1 114 567
relEmitName 1 114 567
assign 1 114 568
addValue 1 114 568
assign 1 114 569
new 0 114 569
assign 1 114 570
addValue 1 114 570
assign 1 114 571
emitNameGet 0 114 571
assign 1 114 572
addValue 1 114 572
assign 1 114 573
new 0 114 573
assign 1 114 574
addValue 1 114 574
assign 1 114 575
addValue 1 114 575
assign 1 114 576
new 0 114 576
addValue 1 114 577
addValue 1 116 578
assign 1 118 579
new 0 118 579
assign 1 118 580
addValue 1 118 580
assign 1 118 581
addValue 1 118 581
assign 1 118 582
new 0 118 582
assign 1 118 583
addValue 1 118 583
addValue 1 118 584
assign 1 120 585
new 0 120 585
assign 1 120 586
addValue 1 120 586
assign 1 120 587
libNameGet 0 120 587
assign 1 120 588
relEmitName 1 120 588
assign 1 120 589
addValue 1 120 589
assign 1 120 590
new 0 120 590
assign 1 120 591
addValue 1 120 591
assign 1 120 592
addValue 1 120 592
assign 1 120 593
new 0 120 593
addValue 1 120 594
addValue 1 122 595
assign 1 124 596
new 0 124 596
addValue 1 124 597
assign 1 130 618
typenameGet 0 130 618
assign 1 130 619
NULLGet 0 130 619
assign 1 130 620
equals 1 130 625
assign 1 131 626
new 0 131 626
assign 1 132 629
heldGet 0 132 629
assign 1 132 630
nameGet 0 132 630
assign 1 132 631
new 0 132 631
assign 1 132 632
equals 1 132 632
assign 1 133 634
new 0 133 634
assign 1 133 635
emitNameGet 0 133 635
assign 1 133 636
add 1 133 636
assign 1 133 637
new 0 133 637
assign 1 133 638
add 1 133 638
assign 1 134 641
heldGet 0 134 641
assign 1 134 642
nameGet 0 134 642
assign 1 134 643
new 0 134 643
assign 1 134 644
equals 1 134 644
assign 1 135 646
new 0 135 646
assign 1 137 649
heldGet 0 137 649
assign 1 137 650
nameForVar 1 137 650
return 1 139 654
assign 1 143 664
heldGet 0 143 664
assign 1 143 665
nameGet 0 143 665
assign 1 143 666
new 0 143 666
assign 1 143 667
equals 1 143 667
assign 1 144 669
new 0 144 669
assign 1 144 670
add 1 144 670
return 1 145 671
assign 1 147 673
formCallTarg 1 147 673
return 1 147 674
assign 1 151 684
new 0 151 684
assign 1 151 685
addValue 1 151 685
assign 1 151 686
secondGet 0 151 686
assign 1 151 687
formTarg 1 151 687
assign 1 151 688
addValue 1 151 688
assign 1 151 689
new 0 151 689
assign 1 151 690
addValue 1 151 690
addValue 1 151 691
assign 1 155 701
heldGet 0 155 701
assign 1 155 702
langsGet 0 155 702
assign 1 155 703
new 0 155 703
assign 1 155 704
has 1 155 704
assign 1 156 706
heldGet 0 156 706
assign 1 156 707
textGet 0 156 707
addValue 1 156 708
handleClassEmit 1 158 711
assign 1 164 740
new 0 164 740
assign 1 164 741
emitNameGet 0 164 741
assign 1 164 742
add 1 164 742
assign 1 164 743
new 0 164 743
assign 1 164 744
add 1 164 744
assign 1 166 745
new 0 166 745
assign 1 166 746
typeEmitNameGet 0 166 746
assign 1 166 747
add 1 166 747
assign 1 166 748
new 0 166 748
assign 1 166 749
add 1 166 749
assign 1 166 750
add 1 166 750
assign 1 166 751
new 0 166 751
assign 1 166 752
add 1 166 752
addClassHeader 1 168 753
assign 1 170 754
new 0 170 754
assign 1 172 755
typeEmitNameGet 0 172 755
assign 1 172 756
addValue 1 172 756
assign 1 172 757
new 0 172 757
assign 1 172 758
addValue 1 172 758
assign 1 172 759
emitNameGet 0 172 759
assign 1 172 760
addValue 1 172 760
assign 1 172 761
new 0 172 761
assign 1 172 762
addValue 1 172 762
assign 1 172 763
addValue 1 172 763
assign 1 172 764
new 0 172 764
addValue 1 172 765
return 1 174 766
assign 1 179 786
new 0 179 786
assign 1 179 787
toString 0 179 787
assign 1 179 788
add 1 179 788
incrementValue 0 180 789
assign 1 181 790
new 0 181 790
assign 1 181 791
addValue 1 181 791
assign 1 181 792
addValue 1 181 792
assign 1 181 793
new 0 181 793
assign 1 181 794
addValue 1 181 794
addValue 1 181 795
assign 1 183 796
containedGet 0 183 796
assign 1 183 797
firstGet 0 183 797
assign 1 183 798
containedGet 0 183 798
assign 1 183 799
firstGet 0 183 799
assign 1 183 800
new 0 183 800
assign 1 183 801
add 1 183 801
assign 1 183 802
new 0 183 802
assign 1 183 803
add 1 183 803
assign 1 183 804
finalAssign 4 183 804
addValue 1 183 805
assign 1 187 825
isTypedGet 0 187 825
assign 1 187 826
not 0 187 831
assign 1 188 832
new 0 188 832
assign 1 188 833
addValue 1 188 833
assign 1 188 834
libNameGet 0 188 834
assign 1 188 835
relEmitName 1 188 835
assign 1 188 836
addValue 1 188 836
assign 1 188 837
new 0 188 837
addValue 1 188 838
assign 1 190 841
new 0 190 841
assign 1 190 842
addValue 1 190 842
assign 1 190 843
namepathGet 0 190 843
assign 1 190 844
getClassConfig 1 190 844
assign 1 190 845
libNameGet 0 190 845
assign 1 190 846
relEmitName 1 190 846
assign 1 190 847
addValue 1 190 847
assign 1 190 848
new 0 190 848
addValue 1 190 849
assign 1 195 864
new 0 195 864
assign 1 195 865
equals 1 195 865
assign 1 196 867
new 0 196 867
assign 1 198 870
new 0 198 870
assign 1 200 872
new 0 200 872
assign 1 200 873
add 1 200 873
assign 1 200 874
libNameGet 0 200 874
assign 1 200 875
relEmitName 1 200 875
assign 1 200 876
add 1 200 876
assign 1 200 877
new 0 200 877
assign 1 200 878
add 1 200 878
return 1 200 879
assign 1 205 883
new 0 205 883
return 1 205 884
assign 1 209 911
overrideMtdDecGet 0 209 911
assign 1 209 912
addValue 1 209 912
assign 1 209 913
new 0 209 913
assign 1 209 914
addValue 1 209 914
assign 1 209 915
emitNameGet 0 209 915
assign 1 209 916
addValue 1 209 916
assign 1 209 917
new 0 209 917
assign 1 209 918
addValue 1 209 918
assign 1 209 919
addValue 1 209 919
assign 1 209 920
new 0 209 920
assign 1 209 921
addValue 1 209 921
assign 1 209 922
addValue 1 209 922
assign 1 209 923
new 0 209 923
assign 1 209 924
addValue 1 209 924
addValue 1 209 925
assign 1 210 926
new 0 210 926
assign 1 210 927
addValue 1 210 927
assign 1 210 928
addValue 1 210 928
assign 1 210 929
new 0 210 929
assign 1 210 930
addValue 1 210 930
assign 1 210 931
addValue 1 210 931
assign 1 210 932
new 0 210 932
assign 1 210 933
addValue 1 210 933
addValue 1 210 934
assign 1 212 935
new 0 212 935
assign 1 212 936
addValue 1 212 936
addValue 1 212 937
assign 1 216 952
new 0 216 952
assign 1 216 953
libNameGet 0 216 953
assign 1 216 954
relEmitName 1 216 954
assign 1 216 955
add 1 216 955
assign 1 216 956
new 0 216 956
assign 1 216 957
add 1 216 957
assign 1 216 958
heldGet 0 216 958
assign 1 216 959
literalValueGet 0 216 959
assign 1 216 960
add 1 216 960
assign 1 216 961
new 0 216 961
assign 1 216 962
add 1 216 962
return 1 216 963
assign 1 220 977
new 0 220 977
assign 1 220 978
libNameGet 0 220 978
assign 1 220 979
relEmitName 1 220 979
assign 1 220 980
add 1 220 980
assign 1 220 981
new 0 220 981
assign 1 220 982
add 1 220 982
assign 1 220 983
heldGet 0 220 983
assign 1 220 984
literalValueGet 0 220 984
assign 1 220 985
add 1 220 985
assign 1 220 986
new 0 220 986
assign 1 220 987
add 1 220 987
return 1 220 988
assign 1 225 1016
new 0 225 1016
assign 1 225 1017
libNameGet 0 225 1017
assign 1 225 1018
relEmitName 1 225 1018
assign 1 225 1019
add 1 225 1019
assign 1 225 1020
new 0 225 1020
assign 1 225 1021
add 1 225 1021
assign 1 225 1022
add 1 225 1022
assign 1 225 1023
new 0 225 1023
assign 1 225 1024
add 1 225 1024
assign 1 225 1025
add 1 225 1025
assign 1 225 1026
new 0 225 1026
assign 1 225 1027
add 1 225 1027
return 1 225 1028
assign 1 227 1030
new 0 227 1030
assign 1 227 1031
libNameGet 0 227 1031
assign 1 227 1032
relEmitName 1 227 1032
assign 1 227 1033
add 1 227 1033
assign 1 227 1034
new 0 227 1034
assign 1 227 1035
add 1 227 1035
assign 1 227 1036
add 1 227 1036
assign 1 227 1037
new 0 227 1037
assign 1 227 1038
add 1 227 1038
assign 1 227 1039
add 1 227 1039
assign 1 227 1040
new 0 227 1040
assign 1 227 1041
add 1 227 1041
return 1 227 1042
assign 1 231 1049
new 0 231 1049
assign 1 231 1050
add 1 231 1050
assign 1 231 1051
new 0 231 1051
assign 1 231 1052
add 1 231 1052
return 1 231 1053
getInt 2 236 1063
assign 1 237 1064
toHexString 1 237 1064
assign 1 238 1065
new 0 238 1065
assign 1 238 1066
begins 1 238 1066
assign 1 239 1068
new 0 239 1068
assign 1 239 1069
substring 1 239 1069
assign 1 240 1070
new 0 240 1070
addValue 1 240 1071
assign 1 242 1073
new 0 242 1073
assign 1 242 1074
once 0 242 1074
addValue 1 242 1075
addValue 1 243 1076
assign 1 249 1083
new 0 249 1083
assign 1 249 1084
add 1 249 1084
assign 1 249 1085
add 1 249 1085
return 1 249 1086
assign 1 253 1090
new 0 253 1090
return 1 253 1091
assign 1 257 1114
new 0 257 1114
assign 1 257 1115
add 1 257 1115
assign 1 257 1116
new 0 257 1116
assign 1 257 1117
add 1 257 1117
assign 1 257 1118
add 1 257 1118
assign 1 258 1119
new 0 258 1119
assign 1 258 1120
addValue 1 258 1120
assign 1 258 1121
addValue 1 258 1121
assign 1 258 1122
new 0 258 1122
assign 1 258 1123
addValue 1 258 1123
addValue 1 258 1124
assign 1 259 1125
new 0 259 1125
assign 1 259 1126
addValue 1 259 1126
addValue 1 259 1127
assign 1 260 1128
new 0 260 1128
assign 1 260 1129
addValue 1 260 1129
assign 1 260 1130
outputPlatformGet 0 260 1130
assign 1 260 1131
nameGet 0 260 1131
assign 1 260 1132
addValue 1 260 1132
assign 1 260 1133
new 0 260 1133
assign 1 260 1134
addValue 1 260 1134
addValue 1 260 1135
assign 1 262 1136
new 0 262 1136
return 1 262 1137
assign 1 266 1141
new 0 266 1141
return 1 266 1142
assign 1 270 1148
new 0 270 1148
assign 1 270 1149
once 0 270 1149
assign 1 270 1150
add 1 270 1150
return 1 270 1151
assign 1 274 1155
getLibOutput 0 274 1155
return 1 274 1156
assign 1 281 1223
new 0 281 1223
assign 1 281 1224
typeEmitNameGet 0 281 1224
assign 1 281 1225
add 1 281 1225
assign 1 281 1226
new 0 281 1226
assign 1 281 1227
add 1 281 1227
write 1 281 1228
assign 1 282 1229
new 0 282 1229
assign 1 283 1230
new 0 283 1230
assign 1 283 1231
addValue 1 283 1231
assign 1 283 1232
typeEmitNameGet 0 283 1232
assign 1 283 1233
addValue 1 283 1233
assign 1 283 1234
new 0 283 1234
addValue 1 283 1235
assign 1 284 1236
new 0 284 1236
addValue 1 284 1237
assign 1 285 1238
typeEmitNameGet 0 285 1238
assign 1 285 1239
addValue 1 285 1239
assign 1 285 1240
new 0 285 1240
addValue 1 285 1241
assign 1 286 1242
new 0 286 1242
addValue 1 286 1243
assign 1 287 1244
new 0 287 1244
addValue 1 287 1245
write 1 288 1246
assign 1 290 1247
new 0 290 1247
assign 1 291 1248
typeEmitNameGet 0 291 1248
assign 1 291 1249
addValue 1 291 1249
assign 1 291 1250
new 0 291 1250
assign 1 291 1251
addValue 1 291 1251
assign 1 291 1252
typeEmitNameGet 0 291 1252
assign 1 291 1253
addValue 1 291 1253
assign 1 291 1254
new 0 291 1254
addValue 1 291 1255
assign 1 292 1256
new 0 292 1256
addValue 1 292 1257
assign 1 293 1258
new 0 293 1258
assign 1 294 1259
mtdListGet 0 294 1259
assign 1 294 1260
iteratorGet 0 0 1260
assign 1 294 1263
hasNextGet 0 294 1263
assign 1 294 1265
nextGet 0 294 1265
assign 1 296 1267
new 0 296 1267
assign 1 298 1270
new 0 298 1270
addValue 1 298 1271
assign 1 300 1273
addValue 1 300 1273
assign 1 300 1274
nameGet 0 300 1274
assign 1 300 1275
addValue 1 300 1275
addValue 1 300 1276
assign 1 302 1282
new 0 302 1282
addValue 1 302 1283
assign 1 303 1284
new 0 303 1284
addValue 1 303 1285
assign 1 305 1286
new 0 305 1286
addValue 1 305 1287
assign 1 306 1288
new 0 306 1288
assign 1 307 1289
ptyListGet 0 307 1289
assign 1 307 1290
iteratorGet 0 0 1290
assign 1 307 1293
hasNextGet 0 307 1293
assign 1 307 1295
nextGet 0 307 1295
assign 1 309 1297
new 0 309 1297
assign 1 311 1300
new 0 311 1300
addValue 1 311 1301
assign 1 313 1303
addValue 1 313 1303
assign 1 313 1304
nameGet 0 313 1304
assign 1 313 1305
addValue 1 313 1305
addValue 1 313 1306
assign 1 315 1312
new 0 315 1312
addValue 1 315 1313
assign 1 317 1314
new 0 317 1314
addValue 1 317 1315
assign 1 319 1316
typeEmitNameGet 0 319 1316
assign 1 319 1317
addValue 1 319 1317
assign 1 319 1318
new 0 319 1318
addValue 1 319 1319
assign 1 320 1320
new 0 320 1320
assign 1 320 1321
addValue 1 320 1321
assign 1 320 1322
emitNameGet 0 320 1322
assign 1 320 1323
addValue 1 320 1323
assign 1 320 1324
new 0 320 1324
addValue 1 320 1325
assign 1 321 1326
new 0 321 1326
addValue 1 321 1327
assign 1 322 1328
new 0 322 1328
addValue 1 322 1329
assign 1 323 1330
new 0 323 1330
addValue 1 323 1331
assign 1 324 1332
getClassOutput 0 324 1332
write 1 324 1333
assign 1 336 1406
undef 1 336 1411
assign 1 337 1412
libNameGet 0 337 1412
assign 1 338 1413
new 0 338 1413
assign 1 338 1414
sizeGet 0 338 1414
assign 1 338 1415
add 1 338 1415
assign 1 338 1416
new 0 338 1416
assign 1 338 1417
add 1 338 1417
assign 1 338 1418
add 1 338 1418
assign 1 338 1419
add 1 338 1419
assign 1 339 1420
new 0 339 1420
assign 1 339 1421
sizeGet 0 339 1421
assign 1 339 1422
add 1 339 1422
assign 1 339 1423
new 0 339 1423
assign 1 339 1424
add 1 339 1424
assign 1 339 1425
add 1 339 1425
assign 1 339 1426
add 1 339 1426
assign 1 340 1427
parentGet 0 340 1427
assign 1 340 1428
addStep 1 340 1428
assign 1 341 1429
parentGet 0 341 1429
assign 1 341 1430
addStep 1 341 1430
assign 1 342 1431
parentGet 0 342 1431
assign 1 342 1432
fileGet 0 342 1432
assign 1 342 1433
existsGet 0 342 1433
assign 1 342 1434
not 0 342 1439
assign 1 343 1440
parentGet 0 343 1440
assign 1 343 1441
fileGet 0 343 1441
makeDirs 0 343 1442
assign 1 345 1444
fileGet 0 345 1444
assign 1 345 1445
writerGet 0 345 1445
assign 1 345 1446
open 0 345 1446
assign 1 346 1447
fileGet 0 346 1447
assign 1 346 1448
writerGet 0 346 1448
assign 1 346 1449
open 0 346 1449
assign 1 348 1450
paramsGet 0 348 1450
assign 1 348 1451
new 0 348 1451
assign 1 348 1452
has 1 348 1452
assign 1 350 1454
paramsGet 0 350 1454
assign 1 350 1455
new 0 350 1455
assign 1 350 1456
get 1 350 1456
assign 1 350 1457
iteratorGet 0 0 1457
assign 1 350 1460
hasNextGet 0 350 1460
assign 1 350 1462
nextGet 0 350 1462
assign 1 352 1463
apNew 1 352 1463
assign 1 352 1464
fileGet 0 352 1464
assign 1 353 1465
readerGet 0 353 1465
assign 1 353 1466
open 0 353 1466
assign 1 353 1467
readString 0 353 1467
assign 1 354 1468
readerGet 0 354 1468
close 0 354 1469
write 1 356 1470
assign 1 360 1477
new 0 360 1477
write 1 360 1478
assign 1 361 1479
new 0 361 1479
write 1 361 1480
assign 1 363 1481
new 0 363 1481
write 1 363 1482
assign 1 364 1483
new 0 364 1483
write 1 364 1484
assign 1 370 1485
paramsGet 0 370 1485
assign 1 370 1486
new 0 370 1486
assign 1 370 1487
has 1 370 1487
assign 1 372 1489
paramsGet 0 372 1489
assign 1 372 1490
new 0 372 1490
assign 1 372 1491
get 1 372 1491
assign 1 372 1492
iteratorGet 0 0 1492
assign 1 372 1495
hasNextGet 0 372 1495
assign 1 372 1497
nextGet 0 372 1497
assign 1 374 1498
apNew 1 374 1498
assign 1 374 1499
fileGet 0 374 1499
assign 1 375 1500
readerGet 0 375 1500
assign 1 375 1501
open 0 375 1501
assign 1 375 1502
readString 0 375 1502
assign 1 376 1503
readerGet 0 376 1503
close 0 376 1504
write 1 378 1505
assign 1 381 1512
paramsGet 0 381 1512
assign 1 381 1513
new 0 381 1513
assign 1 381 1514
has 1 381 1514
assign 1 383 1516
paramsGet 0 383 1516
assign 1 383 1517
new 0 383 1517
assign 1 383 1518
get 1 383 1518
assign 1 383 1519
iteratorGet 0 0 1519
assign 1 383 1522
hasNextGet 0 383 1522
assign 1 383 1524
nextGet 0 383 1524
assign 1 385 1525
apNew 1 385 1525
assign 1 385 1526
fileGet 0 385 1526
assign 1 386 1527
readerGet 0 386 1527
assign 1 386 1528
open 0 386 1528
assign 1 386 1529
readString 0 386 1529
assign 1 387 1530
readerGet 0 387 1530
close 0 387 1531
write 1 389 1532
begin 1 396 1543
prepHeaderOutput 0 397 1544
assign 1 402 1586
undef 1 402 1591
assign 1 403 1592
new 0 403 1592
assign 1 404 1593
parentGet 0 404 1593
assign 1 404 1594
fileGet 0 404 1594
assign 1 404 1595
existsGet 0 404 1595
assign 1 404 1596
not 0 404 1601
assign 1 405 1602
parentGet 0 405 1602
assign 1 405 1603
fileGet 0 405 1603
makeDirs 0 405 1604
assign 1 407 1606
fileGet 0 407 1606
assign 1 407 1607
writerGet 0 407 1607
assign 1 407 1608
open 0 407 1608
assign 1 410 1609
paramsGet 0 410 1609
assign 1 410 1610
new 0 410 1610
assign 1 410 1611
has 1 410 1611
assign 1 412 1613
paramsGet 0 412 1613
assign 1 412 1614
new 0 412 1614
assign 1 412 1615
get 1 412 1615
assign 1 412 1616
iteratorGet 0 0 1616
assign 1 412 1619
hasNextGet 0 412 1619
assign 1 412 1621
nextGet 0 412 1621
assign 1 414 1622
apNew 1 414 1622
assign 1 414 1623
fileGet 0 414 1623
assign 1 415 1624
readerGet 0 415 1624
assign 1 415 1625
open 0 415 1625
assign 1 415 1626
readString 0 415 1626
assign 1 416 1627
readerGet 0 416 1627
close 0 416 1628
write 1 418 1629
assign 1 422 1636
new 0 422 1636
write 1 422 1637
increment 0 423 1638
assign 1 424 1639
paramsGet 0 424 1639
assign 1 424 1640
new 0 424 1640
assign 1 424 1641
has 1 424 1641
assign 1 425 1643
paramsGet 0 425 1643
assign 1 425 1644
new 0 425 1644
assign 1 425 1645
get 1 425 1645
assign 1 425 1646
iteratorGet 0 0 1646
assign 1 425 1649
hasNextGet 0 425 1649
assign 1 425 1651
nextGet 0 425 1651
assign 1 426 1652
apNew 1 426 1652
assign 1 426 1653
fileGet 0 426 1653
assign 1 427 1654
readerGet 0 427 1654
assign 1 427 1655
open 0 427 1655
assign 1 427 1656
readString 0 427 1656
assign 1 428 1657
readerGet 0 428 1657
close 0 428 1658
assign 1 429 1659
countLines 1 429 1659
addValue 1 429 1660
write 1 430 1661
return 1 436 1669
assign 1 441 1675
new 0 441 1675
write 1 441 1676
close 0 442 1677
assign 1 443 1678
assign 1 445 1679
new 0 445 1679
write 1 445 1680
assign 1 447 1681
new 0 447 1681
write 1 447 1682
close 0 448 1683
close 0 449 1684
assign 1 454 1689
new 0 454 1689
return 1 454 1690
assign 1 458 1697
new 0 458 1697
assign 1 458 1698
addValue 1 458 1698
assign 1 458 1699
addValue 1 458 1699
assign 1 458 1700
new 0 458 1700
addValue 1 458 1701
assign 1 463 1723
heldGet 0 463 1723
assign 1 463 1724
synGet 0 463 1724
assign 1 464 1725
ptyListGet 0 464 1725
assign 1 466 1726
emitNameGet 0 466 1726
assign 1 466 1727
addValue 1 466 1727
assign 1 466 1728
new 0 466 1728
addValue 1 466 1729
assign 1 468 1730
new 0 468 1730
assign 1 469 1731
iteratorGet 0 0 1731
assign 1 469 1734
hasNextGet 0 469 1734
assign 1 469 1736
nextGet 0 469 1736
assign 1 471 1738
new 0 471 1738
assign 1 473 1741
new 0 473 1741
addValue 1 473 1742
assign 1 475 1744
addValue 1 475 1744
assign 1 475 1745
new 0 475 1745
assign 1 475 1746
addValue 1 475 1746
assign 1 475 1747
nameGet 0 475 1747
assign 1 475 1748
addValue 1 475 1748
addValue 1 475 1749
assign 1 479 1755
new 0 479 1755
assign 1 479 1756
addValue 1 479 1756
addValue 1 479 1757
assign 1 484 1779
new 0 484 1779
assign 1 486 1780
new 0 486 1780
assign 1 486 1781
emitNameGet 0 486 1781
assign 1 486 1782
add 1 486 1782
assign 1 486 1783
new 0 486 1783
assign 1 486 1784
add 1 486 1784
assign 1 488 1785
new 0 488 1785
assign 1 488 1786
addValue 1 488 1786
assign 1 488 1787
emitNameGet 0 488 1787
assign 1 488 1788
addValue 1 488 1788
assign 1 488 1789
new 0 488 1789
assign 1 488 1790
addValue 1 488 1790
assign 1 488 1791
emitNameGet 0 488 1791
assign 1 488 1792
addValue 1 488 1792
assign 1 488 1793
new 0 488 1793
assign 1 488 1794
addValue 1 488 1794
assign 1 488 1795
addValue 1 488 1795
assign 1 488 1796
new 0 488 1796
addValue 1 488 1797
return 1 490 1798
assign 1 494 1807
libNameGet 0 494 1807
assign 1 494 1808
relEmitName 1 494 1808
assign 1 495 1809
new 0 495 1809
assign 1 495 1810
add 1 495 1810
assign 1 495 1811
new 0 495 1811
assign 1 495 1812
add 1 495 1812
return 1 496 1813
assign 1 500 1825
libNameGet 0 500 1825
assign 1 500 1826
relEmitName 1 500 1826
assign 1 501 1827
new 0 501 1827
assign 1 501 1828
add 1 501 1828
assign 1 501 1829
new 0 501 1829
assign 1 501 1830
add 1 501 1830
assign 1 502 1831
new 0 502 1831
assign 1 502 1832
add 1 502 1832
assign 1 502 1833
add 1 502 1833
return 1 502 1834
assign 1 506 1839
new 0 506 1839
assign 1 506 1840
add 1 506 1840
return 1 506 1841
assign 1 510 1922
getClassConfig 1 510 1922
assign 1 510 1923
libNameGet 0 510 1923
assign 1 510 1924
relEmitName 1 510 1924
assign 1 511 1925
heldGet 0 511 1925
assign 1 511 1926
namepathGet 0 511 1926
assign 1 511 1927
getClassConfig 1 511 1927
assign 1 512 1928
getInitialInst 1 512 1928
assign 1 514 1929
overrideMtdDecGet 0 514 1929
assign 1 514 1930
addValue 1 514 1930
assign 1 514 1931
new 0 514 1931
assign 1 514 1932
addValue 1 514 1932
assign 1 514 1933
emitNameGet 0 514 1933
assign 1 514 1934
addValue 1 514 1934
assign 1 514 1935
new 0 514 1935
assign 1 514 1936
addValue 1 514 1936
assign 1 514 1937
addValue 1 514 1937
assign 1 514 1938
new 0 514 1938
assign 1 514 1939
addValue 1 514 1939
assign 1 514 1940
addValue 1 514 1940
assign 1 514 1941
new 0 514 1941
assign 1 514 1942
addValue 1 514 1942
addValue 1 514 1943
assign 1 515 1944
new 0 515 1944
assign 1 516 1945
emitNameGet 0 516 1945
assign 1 516 1946
notEquals 1 516 1946
assign 1 517 1948
new 0 517 1948
assign 1 517 1949
formCast 3 517 1949
assign 1 520 1951
addValue 1 520 1951
assign 1 520 1952
new 0 520 1952
assign 1 520 1953
addValue 1 520 1953
assign 1 520 1954
addValue 1 520 1954
assign 1 520 1955
new 0 520 1955
assign 1 520 1956
addValue 1 520 1956
addValue 1 520 1957
assign 1 522 1958
new 0 522 1958
assign 1 522 1959
addValue 1 522 1959
addValue 1 522 1960
assign 1 525 1961
overrideMtdDecGet 0 525 1961
assign 1 525 1962
addValue 1 525 1962
assign 1 525 1963
new 0 525 1963
assign 1 525 1964
addValue 1 525 1964
assign 1 525 1965
addValue 1 525 1965
assign 1 525 1966
new 0 525 1966
assign 1 525 1967
addValue 1 525 1967
assign 1 525 1968
emitNameGet 0 525 1968
assign 1 525 1969
addValue 1 525 1969
assign 1 525 1970
new 0 525 1970
assign 1 525 1971
addValue 1 525 1971
assign 1 525 1972
addValue 1 525 1972
assign 1 525 1973
new 0 525 1973
assign 1 525 1974
addValue 1 525 1974
addValue 1 525 1975
assign 1 527 1976
emitNameGet 0 527 1976
assign 1 527 1977
notEquals 1 527 1977
assign 1 528 1979
new 0 528 1979
assign 1 528 1980
addValue 1 528 1980
assign 1 528 1981
addValue 1 528 1981
assign 1 528 1982
new 0 528 1982
assign 1 528 1983
addValue 1 528 1983
assign 1 528 1984
addValue 1 528 1984
assign 1 528 1985
new 0 528 1985
assign 1 528 1986
addValue 1 528 1986
addValue 1 528 1987
assign 1 530 1990
new 0 530 1990
assign 1 530 1991
addValue 1 530 1991
assign 1 530 1992
addValue 1 530 1992
assign 1 530 1993
new 0 530 1993
assign 1 530 1994
addValue 1 530 1994
addValue 1 530 1995
assign 1 533 1997
new 0 533 1997
assign 1 533 1998
addValue 1 533 1998
addValue 1 533 1999
assign 1 535 2000
getTypeInst 1 535 2000
assign 1 537 2001
new 0 537 2001
assign 1 537 2002
addValue 1 537 2002
assign 1 537 2003
emitNameGet 0 537 2003
assign 1 537 2004
addValue 1 537 2004
assign 1 537 2005
new 0 537 2005
assign 1 537 2006
addValue 1 537 2006
addValue 1 537 2007
assign 1 539 2008
new 0 539 2008
assign 1 539 2009
addValue 1 539 2009
assign 1 539 2010
addValue 1 539 2010
assign 1 539 2011
new 0 539 2011
assign 1 539 2012
addValue 1 539 2012
addValue 1 539 2013
assign 1 541 2014
new 0 541 2014
assign 1 541 2015
addValue 1 541 2015
addValue 1 541 2016
assign 1 546 2029
libNameGet 0 546 2029
assign 1 546 2030
relEmitName 1 546 2030
assign 1 547 2031
new 0 547 2031
assign 1 547 2032
add 1 547 2032
assign 1 547 2033
new 0 547 2033
assign 1 547 2034
add 1 547 2034
assign 1 548 2035
new 0 548 2035
assign 1 548 2036
add 1 548 2036
assign 1 548 2037
add 1 548 2037
return 1 548 2038
return 1 0 2041
return 1 0 2044
assign 1 0 2047
assign 1 0 2051
return 1 0 2055
return 1 0 2058
assign 1 0 2061
assign 1 0 2065
return 1 0 2069
return 1 0 2072
assign 1 0 2075
assign 1 0 2079
return 1 0 2083
return 1 0 2086
assign 1 0 2089
assign 1 0 2093
return 1 0 2097
return 1 0 2100
assign 1 0 2103
assign 1 0 2107
return 1 0 2111
return 1 0 2114
assign 1 0 2117
assign 1 0 2121
return 1 0 2125
return 1 0 2128
assign 1 0 2131
assign 1 0 2135
return 1 0 2139
return 1 0 2142
assign 1 0 2145
assign 1 0 2149
return 1 0 2153
return 1 0 2156
assign 1 0 2159
assign 1 0 2163
return 1 0 2167
return 1 0 2170
assign 1 0 2173
assign 1 0 2177
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1291754014: return bem_fieldIteratorGet_0();
case -231378511: return bem_emitLangGetDirect_0();
case 1451798957: return bem_methodsGet_0();
case -1493788431: return bem_onceCountGet_0();
case 1218042043: return bem_classEmitsGetDirect_0();
case 310502183: return bem_overrideMtdDecGet_0();
case 1707761520: return bem_mainOutsideNsGet_0();
case -320016239: return bem_buildPropList_0();
case 934435013: return bem_lastMethodsSizeGetDirect_0();
case 1726245742: return bem_hashGet_0();
case -419692225: return bem_buildGet_0();
case -62351495: return bem_fullLibEmitNameGet_0();
case -1048621631: return bem_lastCallGetDirect_0();
case 1576086738: return bem_libEmitNameGetDirect_0();
case 1715204539: return bem_classesInDepthOrderGetDirect_0();
case -1643185716: return bem_msynGet_0();
case 2006236089: return bem_classConfGetDirect_0();
case 1339720849: return bem_heopGet_0();
case -1460274649: return bem_transGetDirect_0();
case -1914264312: return bem_serializationIteratorGet_0();
case 1747938195: return bem_nlGet_0();
case 600993198: return bem_preClassGetDirect_0();
case -188774864: return bem_fieldNamesGet_0();
case 1646965609: return bem_heopGetDirect_0();
case 1579239784: return bem_methodCallsGet_0();
case 238843301: return bem_buildInitial_0();
case 329659683: return bem_invpGetDirect_0();
case 1944235411: return bem_classesInDepthOrderGet_0();
case -1580760999: return bem_baseMtdDecGet_0();
case -783028637: return bem_lastMethodsLinesGet_0();
case -550460942: return bem_smnlcsGetDirect_0();
case 1170512450: return bem_stringNpGetDirect_0();
case 423100471: return bem_fileExtGetDirect_0();
case 1408442561: return bem_qGetDirect_0();
case 1577949277: return bem_exceptDecGetDirect_0();
case 1285722343: return bem_idToNameGet_0();
case 1447303766: return bem_deonGetDirect_0();
case -1178889524: return bem_baseSmtdDecGet_0();
case 1813298083: return bem_classHeadBodyGet_0();
case 637390067: return bem_instanceNotEqualGet_0();
case 1825531722: return bem_floatNpGet_0();
case -1079345866: return bem_getClassOutput_0();
case -40573534: return bem_ntypesGetDirect_0();
case -997235321: return bem_spropDecGet_0();
case -828152716: return bem_heonGetDirect_0();
case -144416364: return bem_nativeCSlotsGetDirect_0();
case 1605855277: return bem_nameToIdGet_0();
case 1041268379: return bem_instanceNotEqualGetDirect_0();
case 1159139454: return bem_propDecGet_0();
case -939140314: return bem_sourceFileNameGet_0();
case -1831600978: return bem_classHeadersGet_0();
case 505699825: return bem_idToNameGetDirect_0();
case 2123225624: return bem_boolCcGetDirect_0();
case -1102983485: return bem_objectNpGet_0();
case 45896086: return bem_preClassGet_0();
case -1595748276: return bem_boolNpGet_0();
case 1688122668: return bem_falseValueGet_0();
case 1561889985: return bem_mnodeGet_0();
case -1929980100: return bem_cnodeGet_0();
case -2019957540: return bem_dynMethodsGetDirect_0();
case 1924878947: return bem_serializeContents_0();
case 1112663560: return bem_propertyDecsGet_0();
case 511892068: return bem_trueValueGetDirect_0();
case -870016446: return bem_print_0();
case 1892440434: return bem_serializeToString_0();
case 190367210: return bem_classCallsGetDirect_0();
case 967768618: return bem_methodsGetDirect_0();
case 1301985048: return bem_lineCountGet_0();
case -400486696: return bem_boolNpGetDirect_0();
case 1490605816: return bem_coanyiantReturnsGet_0();
case -151982452: return bem_onceCountGetDirect_0();
case 2093694409: return bem_randGetDirect_0();
case 1717528483: return bem_methodCallsGetDirect_0();
case 392792001: return bem_ccMethodsGet_0();
case -92117391: return bem_inFilePathedGet_0();
case -173936017: return bem_emitLib_0();
case -440540280: return bem_ntypesGet_0();
case -1969689732: return bem_classCallsGet_0();
case -1210815456: return bem_deopGetDirect_0();
case -479604360: return bem_csynGet_0();
case 768490951: return bem_maxSpillArgsLenGetDirect_0();
case -1437120451: return bem_heonGet_0();
case -1553476526: return bem_ccCacheGet_0();
case -510214571: return bem_headExtGet_0();
case 669386754: return bem_methodBodyGetDirect_0();
case -1936919361: return bem_libEmitPathGetDirect_0();
case 793053533: return bem_qGet_0();
case -1763888011: return bem_lineCountGetDirect_0();
case -2092997093: return bem_heowGet_0();
case 517095092: return bem_emitLangGet_0();
case -503853586: return bem_callNamesGetDirect_0();
case -927580373: return bem_mainStartGet_0();
case -543476891: return bem_csynGetDirect_0();
case -550793719: return bem_boolCcGet_0();
case 1049031508: return bem_transGet_0();
case 619124967: return bem_methodBodyGet_0();
case -1388576510: return bem_instanceEqualGet_0();
case -1457583807: return bem_classEmitsGet_0();
case -1336547559: return bem_copy_0();
case -1673560399: return bem_toString_0();
case 720275876: return bem_getLibOutput_0();
case 699908035: return bem_nullValueGetDirect_0();
case 1298537663: return bem_methodCatchGet_0();
case -92876860: return bem_echo_0();
case 2119163914: return bem_invpGet_0();
case 389873125: return bem_libEmitNameGet_0();
case -1869817640: return bem_prepHeaderOutput_0();
case 2022591848: return bem_new_0();
case 1113325005: return bem_parentConfGetDirect_0();
case 823239968: return bem_trueValueGet_0();
case -973064091: return bem_libEmitPathGet_0();
case -1396821581: return bem_smnlecsGetDirect_0();
case 1428310617: return bem_onceDecsGet_0();
case 1714059697: return bem_iteratorGet_0();
case 1277530836: return bem_buildCreate_0();
case 1684359161: return bem_classNameGet_0();
case -997138031: return bem_create_0();
case -1439201376: return bem_nullValueGet_0();
case -2097142996: return bem_many_0();
case -518174144: return bem_fileExtGet_0();
case 376318330: return bem_toAny_0();
case 524959348: return bem_initialDecGet_0();
case 1656305855: return bem_instOfGet_0();
case 1596806439: return bem_shlibeGet_0();
case -1705108189: return bem_mainEndGet_0();
case 577455486: return bem_instOfGetDirect_0();
case 501171372: return bem_mainInClassGet_0();
case 372040847: return bem_constGet_0();
case -1506091570: return bem_stringNpGet_0();
case -2045393889: return bem_ccCacheGetDirect_0();
case 1301202414: return bem_maxDynArgsGetDirect_0();
case -1968467519: return bem_classHeadersGetDirect_0();
case 180089087: return bem_lastMethodsLinesGetDirect_0();
case -1155305657: return bem_heowGetDirect_0();
case -1658589354: return bem_intNpGet_0();
case -1772944905: return bem_constGetDirect_0();
case 532156623: return bem_lastMethodBodyLinesGet_0();
case 287103316: return bem_floatNpGetDirect_0();
case -1421264645: return bem_lastMethodBodyLinesGetDirect_0();
case 768040127: return bem_fullLibEmitNameGetDirect_0();
case -330189874: return bem_returnTypeGet_0();
case -1974782684: return bem_exceptDecGet_0();
case -1548450059: return bem_superNameGet_0();
case 1926933037: return bem_synEmitPathGetDirect_0();
case -782732218: return bem_intNpGetDirect_0();
case 1667556491: return bem_classEndGet_0();
case -172634187: return bem_once_0();
case -1787799932: return bem_saveSyns_0();
case 1334280455: return bem_ccMethodsGetDirect_0();
case 69341471: return bem_randGet_0();
case -1263377133: return bem_falseValueGetDirect_0();
case -1829245501: return bem_lastMethodBodySizeGet_0();
case 1479602655: return bem_nativeCSlotsGet_0();
case -93387738: return bem_classConfGet_0();
case -1009111011: return bem_inFilePathedGetDirect_0();
case -555275008: return bem_synEmitPathGet_0();
case 1933315772: return bem_doEmit_0();
case 1160274982: return bem_onceDecsGetDirect_0();
case 1844973187: return bem_buildClassInfo_0();
case -617503287: return bem_propertyDecsGetDirect_0();
case 2004461888: return bem_dynMethodsGet_0();
case -309376654: return bem_methodCatchGetDirect_0();
case -1845286658: return bem_nlGetDirect_0();
case -907904898: return bem_endNs_0();
case -6412711: return bem_afterCast_0();
case 123890466: return bem_tagGet_0();
case 376786083: return bem_cnodeGetDirect_0();
case 764150034: return bem_deopGet_0();
case 248589757: return bem_lastCallGet_0();
case -126204485: return bem_boolTypeGet_0();
case 1413763829: return bem_deonGet_0();
case -414015529: return bem_objectNpGetDirect_0();
case -1311340768: return bem_scvpGetDirect_0();
case 316693648: return bem_deowGet_0();
case -1076953855: return bem_superCallsGet_0();
case 1195036982: return bem_instanceEqualGetDirect_0();
case 1206219656: return bem_maxSpillArgsLenGet_0();
case -1311356222: return bem_objectCcGetDirect_0();
case -1031581112: return bem_smnlecsGet_0();
case 782585161: return bem_deserializeClassNameGet_0();
case 1396075820: return bem_buildGetDirect_0();
case -248067599: return bem_objectCcGet_0();
case 423751010: return bem_callNamesGet_0();
case -1236000242: return bem_maxDynArgsGet_0();
case -1315019380: return bem_classHeadBodyGetDirect_0();
case -2024977658: return bem_useDynMethodsGet_0();
case 1201588824: return bem_msynGetDirect_0();
case 188789487: return bem_beginNs_0();
case -1734013737: return bem_shlibeGetDirect_0();
case 571374919: return bem_nameToIdGetDirect_0();
case 156864109: return bem_parentConfGet_0();
case 17568112: return bem_scvpGet_0();
case 408324702: return bem_superCallsGetDirect_0();
case 1033375985: return bem_runtimeInitGet_0();
case -1604007505: return bem_typeDecGet_0();
case -158053455: return bem_headExtGetDirect_0();
case -1844359163: return bem_returnTypeGetDirect_0();
case -607550416: return bem_deowGetDirect_0();
case 759860608: return bem_lastMethodBodySizeGetDirect_0();
case -1909589759: return bem_lastMethodsSizeGet_0();
case 238052939: return bem_smnlcsGet_0();
case -228357660: return bem_writeBET_0();
case 847339792: return bem_mnodeGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2010659191: return bem_dynMethodsSetDirect_1(bevd_0);
case -639824218: return bem_ccCacheSet_1(bevd_0);
case 321217545: return bem_ccCacheSetDirect_1(bevd_0);
case 1589648778: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -665667897: return bem_constSetDirect_1(bevd_0);
case 1467710266: return bem_fullLibEmitNameSet_1(bevd_0);
case 1867078991: return bem_invpSet_1(bevd_0);
case -25733201: return bem_objectCcSet_1(bevd_0);
case 167550553: return bem_ccMethodsSetDirect_1(bevd_0);
case 389945586: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 477686070: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 459220305: return bem_methodCatchSet_1(bevd_0);
case 286823169: return bem_boolCcSetDirect_1(bevd_0);
case -1472858501: return bem_nameToIdSetDirect_1(bevd_0);
case -1403338215: return bem_synEmitPathSetDirect_1(bevd_0);
case 1516848703: return bem_classHeadBodySet_1(bevd_0);
case 1410783713: return bem_idToNameSet_1(bevd_0);
case 74595220: return bem_emitLangSetDirect_1(bevd_0);
case 568633730: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 477545357: return bem_classesInDepthOrderSet_1(bevd_0);
case -364520312: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 2092196085: return bem_maxDynArgsSetDirect_1(bevd_0);
case -216480192: return bem_exceptDecSet_1(bevd_0);
case 1291646517: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -712625767: return bem_scvpSet_1(bevd_0);
case 1317182977: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case -1634217108: return bem_deowSet_1(bevd_0);
case -1389535286: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -59913652: return bem_nameToIdSet_1(bevd_0);
case -326618154: return bem_nullValueSet_1(bevd_0);
case -9743810: return bem_sameObject_1(bevd_0);
case -539510064: return bem_libEmitPathSetDirect_1(bevd_0);
case -387802549: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -391494523: return bem_cnodeSet_1(bevd_0);
case -628251942: return bem_defined_1(bevd_0);
case 1671966100: return bem_lastMethodsLinesSet_1(bevd_0);
case 477140346: return bem_shlibeSetDirect_1(bevd_0);
case -1554389120: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -291904460: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1222489121: return bem_trueValueSet_1(bevd_0);
case 921396152: return bem_copyTo_1(bevd_0);
case 2060068789: return bem_objectNpSetDirect_1(bevd_0);
case -716557833: return bem_libEmitNameSet_1(bevd_0);
case 813046125: return bem_scvpSetDirect_1(bevd_0);
case -421712457: return bem_classConfSetDirect_1(bevd_0);
case -1846366342: return bem_libEmitNameSetDirect_1(bevd_0);
case -257411874: return bem_buildSet_1(bevd_0);
case -1607403738: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case -2098972836: return bem_returnTypeSet_1(bevd_0);
case -1399543145: return bem_instanceNotEqualSet_1(bevd_0);
case -1994787564: return bem_def_1(bevd_0);
case 1169598378: return bem_deowSetDirect_1(bevd_0);
case 1848940488: return bem_superCallsSetDirect_1(bevd_0);
case -681739807: return bem_floatNpSet_1(bevd_0);
case -1448257220: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 844633763: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1958353526: return bem_lastCallSetDirect_1(bevd_0);
case -886713353: return bem_nlSetDirect_1(bevd_0);
case 1404691116: return bem_constSet_1(bevd_0);
case -613964181: return bem_propertyDecsSetDirect_1(bevd_0);
case -1311016580: return bem_instanceEqualSetDirect_1(bevd_0);
case 1067833663: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case -1106061604: return bem_instanceEqualSet_1(bevd_0);
case 2023070255: return bem_getHeaderInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1687349246: return bem_transSetDirect_1(bevd_0);
case 508421587: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1521273298: return bem_msynSetDirect_1(bevd_0);
case -2026240208: return bem_methodsSetDirect_1(bevd_0);
case 934862545: return bem_mnodeSetDirect_1(bevd_0);
case -1139805373: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1299087238: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -198894381: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1747341983: return bem_idToNameSetDirect_1(bevd_0);
case 79707946: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -355995567: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 55566012: return bem_lastMethodsSizeSet_1(bevd_0);
case -142059454: return bem_stringNpSet_1(bevd_0);
case 2024151813: return bem_otherClass_1(bevd_0);
case -561399114: return bem_falseValueSetDirect_1(bevd_0);
case -1053244563: return bem_parentConfSet_1(bevd_0);
case -763897030: return bem_boolCcSet_1(bevd_0);
case 1241349444: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1977164141: return bem_nlSet_1(bevd_0);
case -767509332: return bem_falseValueSet_1(bevd_0);
case 684216416: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1059903873: return bem_randSet_1(bevd_0);
case -1387706645: return bem_classHeadersSet_1(bevd_0);
case -2070820576: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 906586952: return bem_transSet_1(bevd_0);
case 1850219339: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 1761342420: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1860558101: return bem_sameType_1(bevd_0);
case 4260225: return bem_synEmitPathSet_1(bevd_0);
case 109502111: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -741665973: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2108385190: return bem_undefined_1(bevd_0);
case -146636606: return bem_classEmitsSet_1(bevd_0);
case -934543931: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case -530641731: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1386441501: return bem_ntypesSetDirect_1(bevd_0);
case -228971327: return bem_nativeCSlotsSet_1(bevd_0);
case 497469574: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 1425885736: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -725829481: return bem_boolNpSetDirect_1(bevd_0);
case -974381487: return bem_headExtSetDirect_1(bevd_0);
case -264189270: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case 2033078425: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1196549262: return bem_parentConfSetDirect_1(bevd_0);
case -1474550742: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1008290922: return bem_randSetDirect_1(bevd_0);
case -693296362: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case 1723391476: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1717279239: return bem_msynSet_1(bevd_0);
case 458326703: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 692878735: return bem_methodCatchSetDirect_1(bevd_0);
case -857210172: return bem_superCallsSet_1(bevd_0);
case 1928616946: return bem_preClassSet_1(bevd_0);
case 1030989505: return bem_objectCcSetDirect_1(bevd_0);
case -1513749452: return bem_inFilePathedSet_1(bevd_0);
case 548671888: return bem_trueValueSetDirect_1(bevd_0);
case -684966647: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -2039449010: return bem_lineCountSet_1(bevd_0);
case 295942801: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1211980838: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1112507241: return bem_classHeadersSetDirect_1(bevd_0);
case -1694384494: return bem_end_1(bevd_0);
case 229592332: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case 1269915537: return bem_classEmitsSetDirect_1(bevd_0);
case 462405908: return bem_methodCallsSet_1(bevd_0);
case 295101304: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1150262191: return bem_heonSet_1(bevd_0);
case -59830570: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 322757114: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1646979062: return bem_lastCallSet_1(bevd_0);
case -1806899827: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1972803847: return bem_csynSetDirect_1(bevd_0);
case 2032317238: return bem_intNpSetDirect_1(bevd_0);
case -148425027: return bem_otherType_1(bevd_0);
case 846761274: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -518675940: return bem_smnlcsSetDirect_1(bevd_0);
case -283024341: return bem_deonSetDirect_1(bevd_0);
case -2036893851: return bem_methodsSet_1(bevd_0);
case 754997192: return bem_maxDynArgsSet_1(bevd_0);
case -1255264685: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1121955457: return bem_classCallsSetDirect_1(bevd_0);
case -610950045: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -45830929: return bem_callNamesSetDirect_1(bevd_0);
case 1890481704: return bem_mnodeSet_1(bevd_0);
case -432366987: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1185603219: return bem_smnlecsSetDirect_1(bevd_0);
case 845582075: return bem_onceCountSet_1(bevd_0);
case -963834849: return bem_heopSet_1(bevd_0);
case -226269489: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -1190081629: return bem_lineCountSetDirect_1(bevd_0);
case 2140846040: return bem_methodCallsSetDirect_1(bevd_0);
case 1138314608: return bem_inFilePathedSetDirect_1(bevd_0);
case -502649276: return bem_notEquals_1(bevd_0);
case -1862531411: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 2142781283: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -347987118: return bem_classHeadBodySetDirect_1(bevd_0);
case 110382121: return bem_instOfSetDirect_1(bevd_0);
case 1802133619: return bem_undef_1(bevd_0);
case 292368547: return bem_headExtSet_1(bevd_0);
case 937660115: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1791389686: return bem_deonSet_1(bevd_0);
case 827626725: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -786247508: return bem_instanceNotEqualSetDirect_1(bevd_0);
case 1065821597: return bem_deopSetDirect_1(bevd_0);
case -1008243312: return bem_exceptDecSetDirect_1(bevd_0);
case -1296909041: return bem_emitLangSet_1(bevd_0);
case -373438004: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1700897306: return bem_methodBodySet_1(bevd_0);
case -667810573: return bem_callNamesSet_1(bevd_0);
case -798177321: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1498288889: return bem_propertyDecsSet_1(bevd_0);
case 955788277: return bem_smnlcsSet_1(bevd_0);
case -901140167: return bem_shlibeSet_1(bevd_0);
case -1949676566: return bem_onceCountSetDirect_1(bevd_0);
case 1955506287: return bem_nativeCSlotsSetDirect_1(bevd_0);
case 636524381: return bem_begin_1(bevd_0);
case 680772414: return bem_fileExtSetDirect_1(bevd_0);
case -353983279: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 263466182: return bem_deopSet_1(bevd_0);
case -583430485: return bem_libEmitPathSet_1(bevd_0);
case 939626226: return bem_classCallsSet_1(bevd_0);
case 1570125346: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -141238979: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1712937816: return bem_onceDecsSetDirect_1(bevd_0);
case -1938711501: return bem_ccMethodsSet_1(bevd_0);
case -1483048386: return bem_cnodeSetDirect_1(bevd_0);
case -926879612: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 816287185: return bem_csynSet_1(bevd_0);
case -933231493: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1560831110: return bem_equals_1(bevd_0);
case -1807927146: return bem_buildSetDirect_1(bevd_0);
case -454255783: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -2024197739: return bem_methodBodySetDirect_1(bevd_0);
case 742915379: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -1783619507: return bem_sameClass_1(bevd_0);
case 750741635: return bem_floatNpSetDirect_1(bevd_0);
case 1154901930: return bem_heowSetDirect_1(bevd_0);
case 1566667222: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 754814525: return bem_onceDecsSet_1(bevd_0);
case -948460336: return bem_ntypesSet_1(bevd_0);
case -1635690056: return bem_heopSetDirect_1(bevd_0);
case 1505820899: return bem_intNpSet_1(bevd_0);
case -1593444658: return bem_qSetDirect_1(bevd_0);
case -1259222473: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1592750549: return bem_stringNpSetDirect_1(bevd_0);
case -462340282: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 834950091: return bem_heonSetDirect_1(bevd_0);
case 1830079234: return bem_boolNpSet_1(bevd_0);
case -1731140082: return bem_instOfSet_1(bevd_0);
case -312174665: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2045139553: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 294501325: return bem_heowSet_1(bevd_0);
case -675926352: return bem_invpSetDirect_1(bevd_0);
case 1678046245: return bem_smnlecsSet_1(bevd_0);
case -409756326: return bem_dynMethodsSet_1(bevd_0);
case 996603304: return bem_classConfSet_1(bevd_0);
case 685699943: return bem_nullValueSetDirect_1(bevd_0);
case -961545226: return bem_returnTypeSetDirect_1(bevd_0);
case 1669249554: return bem_fileExtSet_1(bevd_0);
case -1626181008: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1985859803: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -850442972: return bem_preClassSetDirect_1(bevd_0);
case -432473264: return bem_objectNpSet_1(bevd_0);
case 226320358: return bem_qSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1915330817: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1078652527: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -959873457: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1151426337: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -402932836: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -518118155: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1461670892: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 2096642438: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1247620887: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 496165285: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 860801126: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 689169096: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1141599202: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1849167568: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -355453886: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1443758120: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2029168740: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -1044311912: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1473014139: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1608629848: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 2139004158: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 69369055: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1032380922: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1924173716: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -354129637: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case 629780178: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildCCEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildCCEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildCCEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst = (BEC_2_5_9_BuildCCEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildCCEmitter.bece_BEC_2_5_9_BuildCCEmitter_bevs_type;
}
}
}
