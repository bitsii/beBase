namespace be {
/* IO:File: source/base/Logic.be */
public sealed class BEC_2_5_4_LogicBool : BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }
static BEC_2_5_4_LogicBool() { }

   
    public bool bevi_bool;
    public BEC_2_5_4_LogicBool(bool bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x66,0x61,0x6C,0x73,0x65};
public static new BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;

public static new BET_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_ta_ph = beva_str.bemd_1(1311824436, bevt_1_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 50*/ {
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 51*/
bevt_3_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
if (beva_str == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 57*/ {
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_2_ta_ph = beva_str.bemd_1(1311824436, bevt_3_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 57*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 57*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 57*/
 else /* Line: 57*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 57*/ {
bevt_4_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_ta_ph;
} /* Line: 58*/
bevt_5_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 68*/ {
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_1));
return bevt_0_ta_ph;
} /* Line: 69*/
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_1_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 79*/ {
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_0_ta_ph;
} /* Line: 80*/
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 94*/ {
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /* Line: 95*/
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
if (bevi_bool)/* Line: 101*/ {
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
return bevt_0_ta_ph;
} /* Line: 102*/
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_1_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {50, 50, 51, 51, 53, 53, 57, 57, 57, 57, 0, 0, 0, 58, 58, 60, 60, 64, 64, 69, 69, 71, 71, 75, 75, 80, 80, 82, 82, 86, 86, 90, 90, 95, 95, 97, 97, 102, 102, 104, 104, 108};
public static new int[] bevs_smnlec
 = new int[] {30, 31, 33, 34, 36, 37, 46, 51, 52, 53, 55, 58, 62, 65, 66, 68, 69, 73, 74, 80, 81, 83, 84, 88, 89, 95, 96, 98, 99, 103, 104, 108, 109, 115, 116, 118, 119, 125, 126, 128, 129, 132};
/* BEGIN LINEINFO 
assign 1 50 30
new 0 50 30
assign 1 50 31
equals 1 50 31
assign 1 51 33
new 0 51 33
return 1 51 34
assign 1 53 36
new 0 53 36
return 1 53 37
assign 1 57 46
def 1 57 51
assign 1 57 52
new 0 57 52
assign 1 57 53
equals 1 57 53
assign 1 0 55
assign 1 0 58
assign 1 0 62
assign 1 58 65
new 0 58 65
return 1 58 66
assign 1 60 68
new 0 60 68
return 1 60 69
assign 1 64 73
new 0 64 73
return 1 64 74
assign 1 69 80
new 0 69 80
return 1 69 81
assign 1 71 83
new 0 71 83
return 1 71 84
assign 1 75 88
new 0 75 88
return 1 75 89
assign 1 80 95
new 0 80 95
return 1 80 96
assign 1 82 98
new 0 82 98
return 1 82 99
assign 1 86 103
new 0 86 103
return 1 86 104
assign 1 90 108
new 0 90 108
return 1 90 109
assign 1 95 115
new 0 95 115
return 1 95 116
assign 1 97 118
new 0 97 118
return 1 97 119
assign 1 102 125
new 0 102 125
return 1 102 126
assign 1 104 128
new 0 104 128
return 1 104 129
return 1 108 132
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 501088997: return bem_sourceFileNameGet_0();
case -639297756: return bem_toAny_0();
case 281444821: return bem_fieldIteratorGet_0();
case -1486279572: return bem_serializeContents_0();
case -1275325619: return bem_toString_0();
case -2017009146: return bem_new_0();
case 1080161714: return bem_not_0();
case -744679096: return bem_fieldNamesGet_0();
case -1005119995: return bem_many_0();
case -1583672278: return bem_echo_0();
case 611702865: return bem_copy_0();
case 1196171179: return bem_hashGet_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case -1754478112: return bem_print_0();
case -678541085: return bem_classNameGet_0();
case -1475550710: return bem_create_0();
case -1261946063: return bem_decrement_0();
case 119461913: return bem_tagGet_0();
case -545556484: return bem_once_0();
case -2087088332: return bem_increment_0();
case -225870373: return bem_serializeToString_0();
case 2045941275: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1698900309: return bem_new_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case -899377893: return bem_checkDefNew_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_LogicBool();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_type;
}
}
}
