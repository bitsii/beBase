namespace be {
/* IO:File: source/base/Logic.be */
public sealed class BEC_2_5_4_LogicBool : BEC_2_6_6_SystemObject {
public BEC_2_5_4_LogicBool() { }
static BEC_2_5_4_LogicBool() { }

   
    public bool bevi_bool;
    public BEC_2_5_4_LogicBool(bool bevi_bool) { this.bevi_bool = bevi_bool; }
    
   private static byte[] becc_BEC_2_5_4_LogicBool_clname = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] becc_BEC_2_5_4_LogicBool_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x6F,0x67,0x69,0x63,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_0 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_1 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_2 = {0x31};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_3 = {0x30};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_4 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C,0x73};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_5 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_4_LogicBool_bels_6 = {0x66,0x61,0x6C,0x73,0x65};
public static new BEC_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_inst;

public static new BET_2_5_4_LogicBool bece_BEC_2_5_4_LogicBool_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_new_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_0));
bevt_0_tmpany_phold = beva_str.bemd_1(-1065536512, bevt_1_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 43 */ {
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 44 */
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_checkDefNew_1(BEC_2_6_6_SystemObject beva_str) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
if (beva_str == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_1));
bevt_2_tmpany_phold = beva_str.bemd_1(-1065536512, bevt_3_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_2_tmpany_phold).bevi_bool) /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 50 */
 else  /* Line: 50 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 50 */ {
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_4_tmpany_phold;
} /* Line: 51 */
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_5_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 61 */ {
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_2));
return bevt_0_tmpany_phold;
} /* Line: 62 */
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_4_LogicBool_bels_3));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_deserializeClassNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_4_LogicBool_bels_4));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 72 */ {
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
return bevt_0_tmpany_phold;
} /* Line: 73 */
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_increment_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_decrement_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_not_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 87 */ {
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /* Line: 88 */
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (bevi_bool) /* Line: 94 */ {
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_4_LogicBool_bels_5));
return bevt_0_tmpany_phold;
} /* Line: 95 */
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_4_LogicBool_bels_6));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {43, 43, 44, 44, 46, 46, 50, 50, 50, 50, 0, 0, 0, 51, 51, 53, 53, 57, 57, 62, 62, 64, 64, 68, 68, 73, 73, 75, 75, 79, 79, 83, 83, 88, 88, 90, 90, 95, 95, 97, 97, 101};
public static new int[] bevs_smnlec
 = new int[] {32, 33, 35, 36, 38, 39, 48, 53, 54, 55, 57, 60, 64, 67, 68, 70, 71, 75, 76, 82, 83, 85, 86, 90, 91, 97, 98, 100, 101, 105, 106, 110, 111, 117, 118, 120, 121, 127, 128, 130, 131, 134};
/* BEGIN LINEINFO 
assign 1 43 32
new 0 43 32
assign 1 43 33
equals 1 43 33
assign 1 44 35
new 0 44 35
return 1 44 36
assign 1 46 38
new 0 46 38
return 1 46 39
assign 1 50 48
def 1 50 53
assign 1 50 54
new 0 50 54
assign 1 50 55
equals 1 50 55
assign 1 0 57
assign 1 0 60
assign 1 0 64
assign 1 51 67
new 0 51 67
return 1 51 68
assign 1 53 70
new 0 53 70
return 1 53 71
assign 1 57 75
new 0 57 75
return 1 57 76
assign 1 62 82
new 0 62 82
return 1 62 83
assign 1 64 85
new 0 64 85
return 1 64 86
assign 1 68 90
new 0 68 90
return 1 68 91
assign 1 73 97
new 0 73 97
return 1 73 98
assign 1 75 100
new 0 75 100
return 1 75 101
assign 1 79 105
new 0 79 105
return 1 79 106
assign 1 83 110
new 0 83 110
return 1 83 111
assign 1 88 117
new 0 88 117
return 1 88 118
assign 1 90 120
new 0 90 120
return 1 90 121
assign 1 95 127
new 0 95 127
return 1 95 128
assign 1 97 130
new 0 97 130
return 1 97 131
return 1 101 134
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1131385505: return bem_toAny_0();
case 916294969: return bem_sourceFileNameGet_0();
case 343375430: return bem_create_0();
case -393995998: return bem_increment_0();
case 1970758688: return bem_fieldNamesGet_0();
case -928163909: return bem_fieldIteratorGet_0();
case -1574932366: return bem_print_0();
case 431618869: return bem_once_0();
case -825084265: return bem_hashGet_0();
case 131226213: return bem_toString_0();
case -1031399474: return bem_echo_0();
case 1253953314: return bem_serializationIteratorGet_0();
case -1204040414: return bem_decrement_0();
case -2051799514: return bem_new_0();
case 911313117: return bem_tagGet_0();
case -1846550974: return bem_serializeContents_0();
case -1485517163: return bem_copy_0();
case -462571513: return bem_not_0();
case 2063546474: return bem_classNameGet_0();
case 421749162: return bem_iteratorGet_0();
case 1279906777: return bem_serializeToString_0();
case -957769093: return bem_deserializeClassNameGet_0();
case 2061421621: return bem_many_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 747155616: return bem_notEquals_1(bevd_0);
case 1383324451: return bem_sameObject_1(bevd_0);
case -1551421646: return bem_copyTo_1(bevd_0);
case -1809169317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -2018944701: return bem_def_1(bevd_0);
case -1181240679: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -436556280: return bem_undef_1(bevd_0);
case 1044863323: return bem_defined_1(bevd_0);
case -628476976: return bem_otherClass_1(bevd_0);
case 1928047187: return bem_undefined_1(bevd_0);
case -1065536512: return bem_equals_1(bevd_0);
case -123960132: return bem_checkDefNew_1(bevd_0);
case 1555616281: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 192530319: return bem_otherType_1(bevd_0);
case 1889683305: return bem_new_1(bevd_0);
case 1768644351: return bem_sameClass_1(bevd_0);
case -1655018142: return bem_sameType_1(bevd_0);
case 1147111468: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1990600260: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1260241587: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -598891548: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1655882914: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1041029455: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -214435591: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -40143354: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(10, becc_BEC_2_5_4_LogicBool_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_4_LogicBool_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_4_LogicBool();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst = (BEC_2_5_4_LogicBool) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_4_LogicBool.bece_BEC_2_5_4_LogicBool_bevs_type;
}
}
}
