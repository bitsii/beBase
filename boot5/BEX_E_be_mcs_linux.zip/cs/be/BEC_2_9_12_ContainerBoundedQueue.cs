namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue : BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
static BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static new BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
bevp_max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public override BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
base.bem_enqueue_1(beva_item);
if (bevp_size.bevi_int > bevp_max.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 190 */ {
bem_dequeue_0();
} /* Line: 191 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGetDirect_0() {
return bevp_max;
} /*method end*/
public virtual BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {183, 185, 189, 190, 190, 191, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 20, 21, 26, 27, 32, 35, 38, 42};
/* BEGIN LINEINFO 
new 0 183 14
assign 1 185 15
new 0 185 15
enqueue 1 189 20
assign 1 190 21
greater 1 190 26
dequeue 0 191 27
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1747771860: return bem_classNameGet_0();
case -180509522: return bem_get_0();
case -2039257540: return bem_tagGet_0();
case 415331229: return bem_sizeGetDirect_0();
case 1292078539: return bem_maxGet_0();
case -1523902500: return bem_topGet_0();
case -1975328143: return bem_once_0();
case -248343006: return bem_dequeue_0();
case -704513283: return bem_maxGetDirect_0();
case 1625545847: return bem_isEmptyGet_0();
case -758375291: return bem_sizeGet_0();
case -1442113467: return bem_create_0();
case 767177150: return bem_fieldNamesGet_0();
case 1505927918: return bem_serializeContents_0();
case -304660926: return bem_sourceFileNameGet_0();
case 311064206: return bem_bottomGetDirect_0();
case 1094138997: return bem_endGet_0();
case -2023780708: return bem_bottomGet_0();
case -926866946: return bem_topGetDirect_0();
case -448869219: return bem_print_0();
case 583026473: return bem_toAny_0();
case 1091579640: return bem_new_0();
case 7855198: return bem_endGetDirect_0();
case -1616792218: return bem_deserializeClassNameGet_0();
case 1062973207: return bem_serializationIteratorGet_0();
case 1287866350: return bem_copy_0();
case 546322415: return bem_echo_0();
case -470506305: return bem_serializeToString_0();
case 1017833055: return bem_many_0();
case -275053926: return bem_fieldIteratorGet_0();
case -497450892: return bem_hashGet_0();
case 1884049010: return bem_toString_0();
case -926676223: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -13945303: return bem_defined_1(bevd_0);
case -1916951160: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1525010633: return bem_sizeSet_1(bevd_0);
case -396792969: return bem_otherType_1(bevd_0);
case -942274895: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -535557780: return bem_enqueue_1(bevd_0);
case -1239008965: return bem_maxSet_1(bevd_0);
case -867964185: return bem_topSet_1(bevd_0);
case 2047213073: return bem_equals_1(bevd_0);
case 13577034: return bem_def_1(bevd_0);
case 1011958071: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1731821746: return bem_endSet_1(bevd_0);
case -1193756156: return bem_topSetDirect_1(bevd_0);
case 205081622: return bem_sameObject_1(bevd_0);
case -1732969657: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -2015256342: return bem_maxSetDirect_1(bevd_0);
case -602412933: return bem_addValue_1(bevd_0);
case 1540996573: return bem_bottomSetDirect_1(bevd_0);
case -1680819360: return bem_undefined_1(bevd_0);
case -1067726303: return bem_put_1(bevd_0);
case 38080717: return bem_undef_1(bevd_0);
case 745295406: return bem_sameClass_1(bevd_0);
case -1507083548: return bem_otherClass_1(bevd_0);
case 1970503577: return bem_bottomSet_1(bevd_0);
case -1132198926: return bem_sameType_1(bevd_0);
case -706409765: return bem_endSetDirect_1(bevd_0);
case -149148452: return bem_copyTo_1(bevd_0);
case 171271048: return bem_sizeSetDirect_1(bevd_0);
case -1396938224: return bem_notEquals_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 276198978: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1047719554: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1611590654: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -927828157: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 62716626: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -931383679: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1041543114: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
}
