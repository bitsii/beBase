namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_12_ContainerBoundedQueue : BEC_2_9_5_ContainerQueue {
public BEC_2_9_12_ContainerBoundedQueue() { }
static BEC_2_9_12_ContainerBoundedQueue() { }
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x42,0x6F,0x75,0x6E,0x64,0x65,0x64,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_12_ContainerBoundedQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;

public static new BET_2_9_12_ContainerBoundedQueue bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;

public BEC_2_4_3_MathInt bevp_max;
public override BEC_2_6_6_SystemObject bem_new_0() {
base.bem_new_0();
bevp_max = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(99));
return this;
} /*method end*/
public override BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
base.bem_enqueue_1(beva_item);
if (bevp_size.bevi_int > bevp_max.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 191 */ {
bem_dequeue_0();
} /* Line: 192 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_maxGet_0() {
return bevp_max;
} /*method end*/
public BEC_2_4_3_MathInt bem_maxGetDirect_0() {
return bevp_max;
} /*method end*/
public virtual BEC_2_9_12_ContainerBoundedQueue bem_maxSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_12_ContainerBoundedQueue bem_maxSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_max = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {184, 186, 190, 191, 191, 192, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {14, 15, 20, 21, 26, 27, 32, 35, 38, 42};
/* BEGIN LINEINFO 
new 0 184 14
assign 1 186 15
new 0 186 15
enqueue 1 190 20
assign 1 191 21
greater 1 191 26
dequeue 0 192 27
return 1 0 32
return 1 0 35
assign 1 0 38
assign 1 0 42
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1882273343: return bem_bottomGetDirect_0();
case -1043543071: return bem_create_0();
case -534833998: return bem_maxGet_0();
case -1200514874: return bem_once_0();
case -1048585343: return bem_copy_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -2011984947: return bem_classNameGet_0();
case -1021558772: return bem_fieldIteratorGet_0();
case 795649196: return bem_serializationIteratorGet_0();
case 1195423285: return bem_dequeue_0();
case -1800587860: return bem_serializeToString_0();
case 190764838: return bem_toString_0();
case 976768273: return bem_fieldNamesGet_0();
case 451316734: return bem_new_0();
case 2022567405: return bem_tagGet_0();
case -1017732045: return bem_toAny_0();
case -204986197: return bem_print_0();
case -193453355: return bem_iteratorGet_0();
case 1809869265: return bem_many_0();
case 1090501779: return bem_endGetDirect_0();
case -1169168081: return bem_sizeGet_0();
case -1490444629: return bem_endGet_0();
case 1273358520: return bem_sizeGetDirect_0();
case 951607569: return bem_isEmptyGet_0();
case -1852647932: return bem_serializeContents_0();
case -1042709181: return bem_topGet_0();
case 2063807868: return bem_bottomGet_0();
case -477940854: return bem_hashGet_0();
case 1383491161: return bem_maxGetDirect_0();
case 1463816718: return bem_sourceFileNameGet_0();
case -1615839398: return bem_echo_0();
case 114961103: return bem_get_0();
case 430427447: return bem_topGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1255352870: return bem_notEquals_1(bevd_0);
case -1458532932: return bem_maxSetDirect_1(bevd_0);
case 2136830100: return bem_endSetDirect_1(bevd_0);
case 433553075: return bem_sizeSetDirect_1(bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case -974417776: return bem_undef_1(bevd_0);
case -2123752284: return bem_topSetDirect_1(bevd_0);
case -493207723: return bem_bottomSetDirect_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case -1153232623: return bem_enqueue_1(bevd_0);
case 1573288366: return bem_maxSet_1(bevd_0);
case -259661707: return bem_put_1(bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2127915014: return bem_topSet_1(bevd_0);
case 1066058523: return bem_bottomSet_1(bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case 616552912: return bem_sizeSet_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
case -252330168: return bem_def_1(bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1524540415: return bem_endSet_1(bevd_0);
case 1524541780: return bem_addValue_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_9_12_ContainerBoundedQueue_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_12_ContainerBoundedQueue_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_12_ContainerBoundedQueue();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst = (BEC_2_9_12_ContainerBoundedQueue) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_12_ContainerBoundedQueue.bece_BEC_2_9_12_ContainerBoundedQueue_bevs_type;
}
}
}
