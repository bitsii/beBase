namespace be {
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure : BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
static BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static new BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
base.bem_new_1(beva_descr);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
new 1 15 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -354093047: return bem_serializationIteratorGet_0();
case 958210078: return bem_klassNameGet_0();
case -108426847: return bem_translatedGet_0();
case -873942438: return bem_descriptionGet_0();
case -76505233: return bem_once_0();
case -1036233638: return bem_new_0();
case -1019192318: return bem_framesTextGet_0();
case -551298753: return bem_sourceFileNameGet_0();
case 1436235215: return bem_emitLangGet_0();
case -1791347111: return bem_translateEmittedExceptionInner_0();
case -1493103250: return bem_many_0();
case -362321661: return bem_deserializeClassNameGet_0();
case -386157741: return bem_serializeToString_0();
case 1028683886: return bem_toString_0();
case -1057001629: return bem_copy_0();
case 1808626047: return bem_lineNumberGet_0();
case -670475531: return bem_framesGet_0();
case -1003067230: return bem_translateEmittedException_0();
case 1836947478: return bem_serializeContents_0();
case -454910570: return bem_create_0();
case -1051826768: return bem_fileNameGet_0();
case -1991418516: return bem_getFrameText_0();
case -1326045228: return bem_langGet_0();
case 1048772166: return bem_echo_0();
case -1874213289: return bem_tagGet_0();
case 654084467: return bem_iteratorGet_0();
case -1312519804: return bem_hashGet_0();
case -1963468660: return bem_fieldIteratorGet_0();
case 714392359: return bem_classNameGet_0();
case 863669946: return bem_toAny_0();
case 1399672657: return bem_vvGet_0();
case -354590014: return bem_print_0();
case -1523591207: return bem_methodNameGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -510291619: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 325940335: return bem_emitLangSet_1(bevd_0);
case 1029357797: return bem_lineNumberSet_1(bevd_0);
case -403482348: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 338020222: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 729561267: return bem_copyTo_1(bevd_0);
case -1184340301: return bem_otherClass_1(bevd_0);
case -1114194262: return bem_framesTextSet_1(bevd_0);
case 812746411: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1810175630: return bem_translatedSet_1(bevd_0);
case -1941883659: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -504315826: return bem_sameObject_1(bevd_0);
case -999936361: return bem_defined_1(bevd_0);
case -1323133008: return bem_klassNameSet_1(bevd_0);
case 824179568: return bem_new_1(bevd_0);
case -1740189996: return bem_framesSet_1(bevd_0);
case -1374275511: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -747350143: return bem_undef_1(bevd_0);
case 1949282733: return bem_descriptionSet_1(bevd_0);
case 1066333018: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1127693126: return bem_vvSet_1(bevd_0);
case -1319594193: return bem_langSet_1(bevd_0);
case 2095964872: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -558198774: return bem_def_1(bevd_0);
case 1672825312: return bem_notEquals_1(bevd_0);
case 604922157: return bem_equals_1(bevd_0);
case 1782921206: return bem_otherType_1(bevd_0);
case -362472674: return bem_methodNameSet_1(bevd_0);
case 1601241054: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1188536421: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1978731115: return bem_sameType_1(bevd_0);
case -965306462: return bem_undefined_1(bevd_0);
case 265693241: return bem_fileNameSet_1(bevd_0);
case 1301577712: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -249962556: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -608983707: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 913536943: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1192068648: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1655666515: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 478589859: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2045713194: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1409729854: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TestFailure();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
}
