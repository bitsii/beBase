namespace be {
/* IO:File: source/base/Test.be */
public class BEC_2_4_7_TestFailure : BEC_2_6_9_SystemException {
public BEC_2_4_7_TestFailure() { }
static BEC_2_4_7_TestFailure() { }
private static byte[] becc_BEC_2_4_7_TestFailure_clname = {0x54,0x65,0x73,0x74,0x3A,0x46,0x61,0x69,0x6C,0x75,0x72,0x65};
private static byte[] becc_BEC_2_4_7_TestFailure_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x65,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_inst;

public static new BET_2_4_7_TestFailure bece_BEC_2_4_7_TestFailure_bevs_type;

public override BEC_2_6_9_SystemException bem_new_1(BEC_2_6_6_SystemObject beva_descr) {
base.bem_new_1(beva_descr);
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {15};
public static new int[] bevs_smnlec
 = new int[] {13};
/* BEGIN LINEINFO 
new 1 15 13
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1080054999: return bem_fileNameGet_0();
case 1131385505: return bem_toAny_0();
case -1218025920: return bem_emitLangGetDirect_0();
case -1603112585: return bem_framesTextGetDirect_0();
case 916294969: return bem_sourceFileNameGet_0();
case 431618869: return bem_once_0();
case 421749162: return bem_iteratorGet_0();
case 961668727: return bem_lineNumberGet_0();
case 527438159: return bem_langGet_0();
case 343375430: return bem_create_0();
case -1485517163: return bem_copy_0();
case 1876553597: return bem_translatedGetDirect_0();
case 911313117: return bem_tagGet_0();
case -825084265: return bem_hashGet_0();
case 1134538834: return bem_framesGetDirect_0();
case -47568588: return bem_langGetDirect_0();
case -994187651: return bem_klassNameGetDirect_0();
case -1574932366: return bem_print_0();
case -957769093: return bem_deserializeClassNameGet_0();
case 1253953314: return bem_serializationIteratorGet_0();
case 2061421621: return bem_many_0();
case 131226213: return bem_toString_0();
case -44380411: return bem_translateEmittedExceptionInner_0();
case -928163909: return bem_fieldIteratorGet_0();
case -1291664199: return bem_emitLangGet_0();
case -1031399474: return bem_echo_0();
case -1892968345: return bem_vvGetDirect_0();
case -30737044: return bem_fileNameGetDirect_0();
case -596937052: return bem_translatedGet_0();
case 49296636: return bem_getFrameText_0();
case 636535724: return bem_framesTextGet_0();
case 1013387649: return bem_klassNameGet_0();
case -1846550974: return bem_serializeContents_0();
case 1632975195: return bem_lineNumberGetDirect_0();
case 158887713: return bem_descriptionGet_0();
case 1970758688: return bem_fieldNamesGet_0();
case 2063546474: return bem_classNameGet_0();
case 1279906777: return bem_serializeToString_0();
case 2038987764: return bem_framesGet_0();
case 363873638: return bem_vvGet_0();
case 505935677: return bem_translateEmittedException_0();
case -2051799514: return bem_new_0();
case -429288713: return bem_methodNameGet_0();
case 1567126550: return bem_methodNameGetDirect_0();
case 575904374: return bem_descriptionGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 747155616: return bem_notEquals_1(bevd_0);
case -533301219: return bem_klassNameSetDirect_1(bevd_0);
case 2105188424: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1551421646: return bem_copyTo_1(bevd_0);
case 1383324451: return bem_sameObject_1(bevd_0);
case -1188841665: return bem_translatedSetDirect_1(bevd_0);
case -1844887269: return bem_langSetDirect_1(bevd_0);
case -540770072: return bem_lineNumberSet_1(bevd_0);
case 619324079: return bem_framesSet_1(bevd_0);
case 1782211682: return bem_emitLangSet_1(bevd_0);
case 811989693: return bem_framesTextSet_1(bevd_0);
case 1889683305: return bem_new_1(bevd_0);
case -1065536512: return bem_equals_1(bevd_0);
case -1809169317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1044863323: return bem_defined_1(bevd_0);
case 1375200128: return bem_methodNameSetDirect_1(bevd_0);
case -1911542934: return bem_langSet_1(bevd_0);
case -509955339: return bem_vvSetDirect_1(bevd_0);
case -1655018142: return bem_sameType_1(bevd_0);
case 175787343: return bem_descriptionSet_1(bevd_0);
case 1558226146: return bem_methodNameSet_1(bevd_0);
case -628476976: return bem_otherClass_1(bevd_0);
case -64538580: return bem_fileNameSet_1(bevd_0);
case 1536384989: return bem_vvSet_1(bevd_0);
case -303018602: return bem_emitLangSetDirect_1(bevd_0);
case -481487419: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1710958232: return bem_framesTextSetDirect_1(bevd_0);
case -116133038: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1713412654: return bem_fileNameSetDirect_1(bevd_0);
case 1910167067: return bem_framesSetDirect_1(bevd_0);
case 1147111468: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1850601476: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -1181240679: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -436556280: return bem_undef_1(bevd_0);
case 1555616281: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 85767481: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 522323083: return bem_klassNameSet_1(bevd_0);
case -2018944701: return bem_def_1(bevd_0);
case 1249639908: return bem_lineNumberSetDirect_1(bevd_0);
case 192530319: return bem_otherType_1(bevd_0);
case -984873939: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 1768644351: return bem_sameClass_1(bevd_0);
case 1928047187: return bem_undefined_1(bevd_0);
case 190511589: return bem_translatedSet_1(bevd_0);
case 471870792: return bem_descriptionSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1990600260: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1260241587: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -598891548: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1655882914: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1041029455: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -214435591: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -40143354: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 804756669: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_4_7_TestFailure_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(19, becc_BEC_2_4_7_TestFailure_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_7_TestFailure();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst = (BEC_2_4_7_TestFailure) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_7_TestFailure.bece_BEC_2_4_7_TestFailure_bevs_type;
}
}
}
