namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_3_MathInt : BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }
static BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_0 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_1 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_2 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_3 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_4 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_5 = (new BEC_2_4_3_MathInt(58));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_6 = (new BEC_2_4_3_MathInt(71));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_7 = (new BEC_2_4_3_MathInt(103));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_8 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_9 = (new BEC_2_4_3_MathInt(24));
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_0, 39));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_11 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_12 = (new BEC_2_4_3_MathInt(65));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_13 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_14 = (new BEC_2_4_3_MathInt(97));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_15 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_16 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_17 = (new BEC_2_4_3_MathInt(47));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_18 = (new BEC_2_4_3_MathInt(64));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_19 = (new BEC_2_4_3_MathInt(96));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_20 = (new BEC_2_4_3_MathInt(45));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_21 = (new BEC_2_4_3_MathInt(43));
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_1, 21));
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_4_3_MathInt_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_4_3_MathInt_bels_2, 1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_24 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_25 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_26 = (new BEC_2_4_3_MathInt(2));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_27 = (new BEC_2_4_3_MathInt(16));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_28 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_29 = (new BEC_2_4_3_MathInt(55));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_30 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_31 = (new BEC_2_4_3_MathInt(10));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_32 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_33 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_34 = (new BEC_2_4_3_MathInt(4));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_35 = (new BEC_2_4_3_MathInt(48));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_36 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_37 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
private static BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevo_38 = (new BEC_2_4_3_MathInt(0));
public static new BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static new BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return (BEC_2_6_6_SystemObject) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_0;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_1;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_2;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_3;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_4;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) bevt_1_tmpany_phold.bem_once_0();
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_5;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_5_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_6;
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) bevt_5_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_7;
bevt_6_tmpany_phold = (BEC_2_4_3_MathInt) bevt_7_tmpany_phold.bem_once_0();
bem_setStringValue_5(beva_str, bevt_0_tmpany_phold, bevt_2_tmpany_phold, bevt_4_tmpany_phold, bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_8;
if (beva_radix.bevi_int < bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_9;
if (beva_radix.bevi_int > bevt_4_tmpany_phold.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 96 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 96 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 96 */ {
bevt_7_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_10;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_radix);
bevt_5_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_5_tmpany_phold);
} /* Line: 97 */
bevt_9_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_11;
if (beva_radix.bevi_int < bevt_9_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 99 */ {
bevl_max0 = (BEC_2_4_3_MathInt) beva_radix.bem_copy_0();
} /* Line: 100 */
 else  /* Line: 101 */ {
bevl_max0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
} /* Line: 102 */
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_11_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_12;
bevt_13_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_13;
bevt_12_tmpany_phold = beva_radix.bem_subtract_1(bevt_13_tmpany_phold);
bevl_maxA = bevt_11_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_14;
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_15;
bevt_15_tmpany_phold = beva_radix.bem_subtract_1(bevt_16_tmpany_phold);
bevl_maxa = bevt_14_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_tmpany_phold.bevi_int;
bevt_4_tmpany_phold = beva_str.bem_sizeGet_0();
bevl_j = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 116 */ {
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_16;
if (bevl_j.bevi_int >= bevt_6_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 116 */ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_17;
if (bevl_ic.bevi_int > bevt_8_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 120 */ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 123 */
 else  /* Line: 120 */ {
bevt_12_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_18;
if (bevl_ic.bevi_int > bevt_12_tmpany_phold.bevi_int) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 124 */ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 124 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 124 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 124 */
 else  /* Line: 124 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 124 */ {
bevt_14_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 127 */
 else  /* Line: 120 */ {
bevt_16_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_19;
if (bevl_ic.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 128 */ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 128 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 128 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 128 */
 else  /* Line: 128 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 128 */ {
bevt_18_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_tmpany_phold);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 131 */
 else  /* Line: 120 */ {
bevt_20_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_20;
if (bevl_ic.bevi_int == bevt_20_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_21_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_tmpany_phold);
} /* Line: 134 */
 else  /* Line: 120 */ {
bevt_23_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_21;
if (bevl_ic.bevi_int == bevt_23_tmpany_phold.bevi_int) {
bevt_22_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 135 */ {
} /* Line: 135 */
 else  /* Line: 137 */ {
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_22;
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bem_add_1(beva_str);
bevt_29_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_23;
bevt_26_tmpany_phold = bevt_27_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_add_1(bevl_ic);
bevt_24_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_24_tmpany_phold);
} /* Line: 138 */
} /* Line: 120 */
} /* Line: 120 */
} /* Line: 120 */
} /* Line: 120 */
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 141 */
 else  /* Line: 116 */ {
break;
} /* Line: 116 */
} /* Line: 116 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toString_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_24;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_6_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_25;
bevt_5_tmpany_phold = (BEC_2_4_3_MathInt) bevt_6_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, bevt_3_tmpany_phold, bevt_5_tmpany_phold, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_toHexString_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_26;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_4_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_27;
bevt_3_tmpany_phold = (BEC_2_4_3_MathInt) bevt_4_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_3(beva_res, bevt_1_tmpany_phold, bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_28;
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) bevt_3_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(bevt_1_tmpany_phold, beva_zeroPad, beva_radix, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_29;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bevt_2_tmpany_phold.bem_once_0();
bevt_0_tmpany_phold = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_6_TextString bevt_38_tmpany_phold = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
 /* Line: 219 */ {
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_30;
if (bevl_ts.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 219 */ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_31;
if (bevl_val.bevi_int < bevt_3_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevt_4_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_tmpany_phold.bevi_int;
} /* Line: 223 */
 else  /* Line: 224 */ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 225 */
bevt_6_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_7_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_6_tmpany_phold.bevi_int <= bevt_7_tmpany_phold.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 228 */ {
bevt_9_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_10_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_32;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_8_tmpany_phold);
} /* Line: 229 */
bevt_11_tmpany_phold = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_tmpany_phold, bevl_val);
bevt_13_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_14_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_33;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_12_tmpany_phold);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 236 */
 else  /* Line: 219 */ {
break;
} /* Line: 219 */
} /* Line: 219 */
while (true)
 /* Line: 239 */ {
bevt_19_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_19_tmpany_phold.bevi_int < beva_zeroPad.bevi_int) {
bevt_18_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 239 */ {
bevt_21_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_22_tmpany_phold = beva_res.bem_sizeGet_0();
if (bevt_21_tmpany_phold.bevi_int <= bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_24_tmpany_phold = beva_res.bem_capacityGet_0();
bevt_25_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_34;
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
beva_res.bem_capacitySet_1(bevt_23_tmpany_phold);
} /* Line: 241 */
bevt_26_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_28_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_35;
bevt_27_tmpany_phold = (BEC_2_4_3_MathInt) bevt_28_tmpany_phold.bem_once_0();
beva_res.bem_setIntUnchecked_2(bevt_26_tmpany_phold, bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_res.bem_sizeGet_0();
bevt_31_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_36;
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
beva_res.bem_sizeSet_1(bevt_29_tmpany_phold);
} /* Line: 245 */
 else  /* Line: 239 */ {
break;
} /* Line: 239 */
} /* Line: 239 */
bevt_36_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_37;
if (bevi_int < bevt_36_tmpany_phold.bevi_int) {
bevt_35_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_35_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_35_tmpany_phold.bevi_bool) /* Line: 249 */ {
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_37_tmpany_phold);
} /* Line: 250 */
bevt_38_tmpany_phold = (BEC_2_4_6_TextString) beva_res.bem_reverseBytes_0();
return bevt_38_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) bem_copy_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_absValue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_4_3_MathInt_bevo_38;
if (bevi_int < bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 266 */ {
bevt_2_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_tmpany_phold);
} /* Line: 267 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevl_result = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 701 */ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 701 */ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 701 */
 else  /* Line: 701 */ {
break;
} /* Line: 701 */
} /* Line: 701 */
return bevl_result;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int == bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int != bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {77, 77, 80, 84, 88, 88, 88, 88, 88, 88, 88, 88, 88, 92, 92, 92, 92, 92, 92, 92, 92, 92, 96, 96, 96, 0, 96, 96, 96, 0, 0, 97, 97, 97, 97, 99, 99, 99, 100, 102, 104, 104, 105, 105, 105, 105, 106, 106, 106, 106, 107, 111, 111, 112, 112, 113, 114, 115, 116, 116, 116, 118, 120, 120, 120, 120, 120, 0, 0, 0, 121, 121, 122, 123, 124, 124, 124, 124, 124, 0, 0, 0, 125, 125, 126, 127, 128, 128, 128, 128, 128, 0, 0, 0, 129, 129, 130, 131, 132, 132, 132, 134, 134, 135, 135, 135, 138, 138, 138, 138, 138, 138, 138, 140, 141, 146, 146, 150, 154, 154, 158, 169, 192, 196, 196, 196, 196, 196, 196, 196, 196, 200, 200, 200, 200, 204, 204, 204, 204, 204, 204, 208, 208, 208, 208, 208, 212, 212, 212, 212, 216, 217, 218, 219, 219, 219, 220, 221, 222, 222, 222, 223, 223, 225, 228, 228, 228, 228, 229, 229, 229, 229, 231, 231, 232, 232, 232, 232, 236, 239, 239, 239, 240, 240, 240, 240, 241, 241, 241, 241, 243, 243, 243, 243, 244, 244, 244, 244, 249, 249, 249, 250, 250, 252, 252, 256, 257, 258, 262, 262, 262, 266, 266, 266, 267, 267, 288, 292, 303, 307, 318, 337, 356, 360, 371, 390, 394, 405, 424, 428, 439, 458, 462, 479, 504, 508, 519, 538, 542, 558, 577, 581, 597, 616, 620, 636, 655, 659, 675, 694, 699, 701, 701, 701, 702, 701, 704, 743, 743, 779, 779, 807, 807, 835, 835, 863, 863, 891, 891};
public static new int[] bevs_smnlec
 = new int[] {74, 75, 78, 82, 94, 95, 96, 97, 98, 99, 100, 101, 102, 114, 115, 116, 117, 118, 119, 120, 121, 122, 146, 147, 152, 153, 156, 157, 162, 163, 166, 170, 171, 172, 173, 175, 176, 181, 182, 185, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 234, 235, 236, 237, 238, 239, 240, 243, 244, 249, 250, 251, 252, 257, 258, 263, 264, 267, 271, 274, 275, 276, 277, 280, 281, 286, 287, 292, 293, 296, 300, 303, 304, 305, 306, 309, 310, 315, 316, 321, 322, 325, 329, 332, 333, 334, 335, 338, 339, 344, 345, 346, 349, 350, 355, 358, 359, 360, 361, 362, 363, 364, 370, 371, 381, 382, 385, 390, 391, 394, 398, 401, 411, 412, 413, 414, 415, 416, 417, 418, 424, 425, 426, 427, 435, 436, 437, 438, 439, 440, 447, 448, 449, 450, 451, 457, 458, 459, 460, 504, 505, 506, 509, 510, 515, 516, 517, 518, 519, 524, 525, 526, 529, 531, 532, 533, 538, 539, 540, 541, 542, 544, 545, 546, 547, 548, 549, 550, 558, 559, 564, 565, 566, 567, 572, 573, 574, 575, 576, 578, 579, 580, 581, 582, 583, 584, 585, 591, 592, 597, 598, 599, 601, 602, 606, 607, 608, 613, 614, 615, 621, 622, 627, 628, 629, 636, 640, 643, 647, 650, 655, 660, 664, 667, 672, 676, 679, 684, 688, 691, 696, 700, 703, 708, 712, 715, 720, 724, 727, 732, 736, 739, 744, 748, 751, 756, 760, 763, 768, 774, 775, 778, 783, 784, 785, 791, 801, 802, 812, 813, 822, 823, 832, 833, 842, 843, 852, 853};
/* BEGIN LINEINFO 
assign 1 77 74
new 0 77 74
return 1 77 75
setStringValueDec 1 80 78
setStringValueHex 1 84 82
assign 1 88 94
new 0 88 94
assign 1 88 95
once 0 88 95
assign 1 88 96
new 0 88 96
assign 1 88 97
once 0 88 97
assign 1 88 98
new 0 88 98
assign 1 88 99
once 0 88 99
assign 1 88 100
new 0 88 100
assign 1 88 101
once 0 88 101
setStringValue 5 88 102
assign 1 92 114
new 0 92 114
assign 1 92 115
once 0 92 115
assign 1 92 116
new 0 92 116
assign 1 92 117
once 0 92 117
assign 1 92 118
new 0 92 118
assign 1 92 119
once 0 92 119
assign 1 92 120
new 0 92 120
assign 1 92 121
once 0 92 121
setStringValue 5 92 122
assign 1 96 146
new 0 96 146
assign 1 96 147
lesser 1 96 152
assign 1 0 153
assign 1 96 156
new 0 96 156
assign 1 96 157
greater 1 96 162
assign 1 0 163
assign 1 0 166
assign 1 97 170
new 0 97 170
assign 1 97 171
add 1 97 171
assign 1 97 172
new 1 97 172
throw 1 97 173
assign 1 99 175
new 0 99 175
assign 1 99 176
lesser 1 99 181
assign 1 100 182
copy 0 100 182
assign 1 102 185
new 0 102 185
assign 1 104 187
new 0 104 187
addValue 1 104 188
assign 1 105 189
new 0 105 189
assign 1 105 190
new 0 105 190
assign 1 105 191
subtract 1 105 191
assign 1 105 192
add 1 105 192
assign 1 106 193
new 0 106 193
assign 1 106 194
new 0 106 194
assign 1 106 195
subtract 1 106 195
assign 1 106 196
add 1 106 196
setStringValue 5 107 197
assign 1 111 234
new 0 111 234
setValue 1 111 235
assign 1 112 236
sizeGet 0 112 236
assign 1 112 237
copy 0 112 237
decrementValue 0 113 238
assign 1 114 239
new 0 114 239
assign 1 115 240
new 0 115 240
assign 1 116 243
new 0 116 243
assign 1 116 244
greaterEquals 1 116 249
getInt 2 118 250
assign 1 120 251
new 0 120 251
assign 1 120 252
greater 1 120 257
assign 1 120 258
lesser 1 120 263
assign 1 0 264
assign 1 0 267
assign 1 0 271
assign 1 121 274
new 0 121 274
subtractValue 1 121 275
multiplyValue 1 122 276
addValue 1 123 277
assign 1 124 280
new 0 124 280
assign 1 124 281
greater 1 124 286
assign 1 124 287
lesser 1 124 292
assign 1 0 293
assign 1 0 296
assign 1 0 300
assign 1 125 303
new 0 125 303
subtractValue 1 125 304
multiplyValue 1 126 305
addValue 1 127 306
assign 1 128 309
new 0 128 309
assign 1 128 310
greater 1 128 315
assign 1 128 316
lesser 1 128 321
assign 1 0 322
assign 1 0 325
assign 1 0 329
assign 1 129 332
new 0 129 332
subtractValue 1 129 333
multiplyValue 1 130 334
addValue 1 131 335
assign 1 132 338
new 0 132 338
assign 1 132 339
equals 1 132 344
assign 1 134 345
new 0 134 345
multiplyValue 1 134 346
assign 1 135 349
new 0 135 349
assign 1 135 350
equals 1 135 355
assign 1 138 358
new 0 138 358
assign 1 138 359
add 1 138 359
assign 1 138 360
new 0 138 360
assign 1 138 361
add 1 138 361
assign 1 138 362
add 1 138 362
assign 1 138 363
new 1 138 363
throw 1 138 364
decrementValue 0 140 370
multiplyValue 1 141 371
assign 1 146 381
toString 0 146 381
return 1 146 382
new 1 150 385
assign 1 154 390
new 0 154 390
return 1 154 391
return 1 158 394
assign 1 169 398
new 0 169 398
return 1 192 401
assign 1 196 411
new 0 196 411
assign 1 196 412
new 1 196 412
assign 1 196 413
new 0 196 413
assign 1 196 414
once 0 196 414
assign 1 196 415
new 0 196 415
assign 1 196 416
once 0 196 416
assign 1 196 417
toString 4 196 417
return 1 196 418
assign 1 200 424
new 0 200 424
assign 1 200 425
new 1 200 425
assign 1 200 426
toHexString 1 200 426
return 1 200 427
assign 1 204 435
new 0 204 435
assign 1 204 436
once 0 204 436
assign 1 204 437
new 0 204 437
assign 1 204 438
once 0 204 438
assign 1 204 439
toString 3 204 439
return 1 204 440
assign 1 208 447
new 1 208 447
assign 1 208 448
new 0 208 448
assign 1 208 449
once 0 208 449
assign 1 208 450
toString 4 208 450
return 1 208 451
assign 1 212 457
new 0 212 457
assign 1 212 458
once 0 212 458
assign 1 212 459
toString 4 212 459
return 1 212 460
clear 0 216 504
assign 1 217 505
abs 0 217 505
assign 1 218 506
new 0 218 506
assign 1 219 509
new 0 219 509
assign 1 219 510
greater 1 219 515
setValue 1 220 516
modulusValue 1 221 517
assign 1 222 518
new 0 222 518
assign 1 222 519
lesser 1 222 524
assign 1 223 525
new 0 223 525
addValue 1 223 526
addValue 1 225 529
assign 1 228 531
capacityGet 0 228 531
assign 1 228 532
sizeGet 0 228 532
assign 1 228 533
lesserEquals 1 228 538
assign 1 229 539
capacityGet 0 229 539
assign 1 229 540
new 0 229 540
assign 1 229 541
add 1 229 541
capacitySet 1 229 542
assign 1 231 544
sizeGet 0 231 544
setIntUnchecked 2 231 545
assign 1 232 546
sizeGet 0 232 546
assign 1 232 547
new 0 232 547
assign 1 232 548
add 1 232 548
sizeSet 1 232 549
divideValue 1 236 550
assign 1 239 558
sizeGet 0 239 558
assign 1 239 559
lesser 1 239 564
assign 1 240 565
capacityGet 0 240 565
assign 1 240 566
sizeGet 0 240 566
assign 1 240 567
lesserEquals 1 240 572
assign 1 241 573
capacityGet 0 241 573
assign 1 241 574
new 0 241 574
assign 1 241 575
add 1 241 575
capacitySet 1 241 576
assign 1 243 578
sizeGet 0 243 578
assign 1 243 579
new 0 243 579
assign 1 243 580
once 0 243 580
setIntUnchecked 2 243 581
assign 1 244 582
sizeGet 0 244 582
assign 1 244 583
new 0 244 583
assign 1 244 584
add 1 244 584
sizeSet 1 244 585
assign 1 249 591
new 0 249 591
assign 1 249 592
lesser 1 249 597
assign 1 250 598
new 0 250 598
addValue 1 250 599
assign 1 252 601
reverseBytes 0 252 601
return 1 252 602
assign 1 256 606
new 0 256 606
setValue 1 257 607
return 1 258 608
assign 1 262 613
copy 0 262 613
assign 1 262 614
absValue 0 262 614
return 1 262 615
assign 1 266 621
new 0 266 621
assign 1 266 622
lesser 1 266 627
assign 1 267 628
new 0 267 628
multiplyValue 1 267 629
return 1 288 636
assign 1 292 640
new 0 292 640
return 1 303 643
assign 1 307 647
new 0 307 647
return 1 318 650
return 1 337 655
return 1 356 660
assign 1 360 664
new 0 360 664
return 1 371 667
return 1 390 672
assign 1 394 676
new 0 394 676
return 1 405 679
return 1 424 684
assign 1 428 688
new 0 428 688
return 1 439 691
return 1 458 696
assign 1 462 700
new 0 462 700
return 1 479 703
return 1 504 708
assign 1 508 712
new 0 508 712
return 1 519 715
return 1 538 720
assign 1 542 724
new 0 542 724
return 1 558 727
return 1 577 732
assign 1 581 736
new 0 581 736
return 1 597 739
return 1 616 744
assign 1 620 748
new 0 620 748
return 1 636 751
return 1 655 756
assign 1 659 760
new 0 659 760
return 1 675 763
return 1 694 768
assign 1 699 774
new 0 699 774
assign 1 701 775
new 0 701 775
assign 1 701 778
lesser 1 701 783
multiplyValue 1 702 784
incrementValue 0 701 785
return 1 704 791
assign 1 743 801
new 0 743 801
return 1 743 802
assign 1 779 812
new 0 779 812
return 1 779 813
assign 1 807 822
new 0 807 822
return 1 807 823
assign 1 835 832
new 0 835 832
return 1 835 833
assign 1 863 842
new 0 863 842
return 1 863 843
assign 1 891 852
new 0 891 852
return 1 891 853
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 491856761: return bem_vintGet_0();
case -1799416909: return bem_serializationIteratorGet_0();
case 658795083: return bem_decrement_0();
case 1804773996: return bem_create_0();
case -73436994: return bem_new_0();
case 1254813232: return bem_toAny_0();
case -2129637928: return bem_decrementValue_0();
case -1072030744: return bem_sourceFileNameGet_0();
case 653349672: return bem_copy_0();
case 2053526813: return bem_increment_0();
case -1637832144: return bem_vintSet_0();
case -1778497682: return bem_serializeToString_0();
case -222029356: return bem_incrementValue_0();
case -161105711: return bem_toHexString_0();
case 959038598: return bem_echo_0();
case -2120499139: return bem_iteratorGet_0();
case -1381157426: return bem_toFloat_0();
case 1562662552: return bem_many_0();
case 167710369: return bem_print_0();
case -297374401: return bem_hashGet_0();
case -1067704397: return bem_once_0();
case 39810102: return bem_tagGet_0();
case 1769468354: return bem_fieldNamesGet_0();
case -1628372783: return bem_classNameGet_0();
case 2033445049: return bem_absValue_0();
case -1071008216: return bem_serializeContents_0();
case 621276181: return bem_toString_0();
case -1320758604: return bem_abs_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case -1960297657: return bem_fieldIteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1587682401: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 450999525: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case 824742186: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case 959468467: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case -438924354: return bem_undefined_1(bevd_0);
case 1109878799: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case 849737299: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 241236484: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -438714936: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1857044719: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -421301665: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2014565549: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 809474136: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case 1990604741: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -1791739843: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case -2001515581: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1341810503: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case -2086595664: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case 622156781: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 112002855: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -1049172860: return bem_defined_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case -1985070098: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 906943584: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case 1940488640: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1110681556: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
case -1303271555: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case -532843132: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case 160394501: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case -405203942: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -1812149810: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -414228749: return bem_new_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -740860377: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 978571550: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -2078113853: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1499648468: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 157921860: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_3_MathInt();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
}
