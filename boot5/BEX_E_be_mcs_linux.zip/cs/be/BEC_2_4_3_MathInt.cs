namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_3_MathInt : BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }
static BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
public static new BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static new BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(97));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(71));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(103));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_9_SystemException bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (beva_radix.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(24));
if (beva_radix.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 99*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 99*/ {
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_4_3_MathInt_bels_0));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_radix);
bevt_5_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_ta_ph);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 100*/
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
if (beva_radix.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 102*/ {
bevl_max0 = (BEC_2_4_3_MathInt) beva_radix.bem_copy_0();
} /* Line: 103*/
 else /* Line: 104*/ {
bevl_max0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
} /* Line: 105*/
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_ta_ph.bevi_int;
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
bevt_13_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_12_ta_ph = beva_radix.bem_subtract_1(bevt_13_ta_ph);
bevl_maxA = bevt_11_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(97));
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_15_ta_ph = beva_radix.bem_subtract_1(bevt_16_ta_ph);
bevl_maxa = bevt_14_ta_ph.bem_add_1(bevt_15_ta_ph);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_9_SystemException bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_ta_ph.bevi_int;
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevl_j = (BEC_2_4_3_MathInt) bevt_4_ta_ph.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
/* Line: 119*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 119*/ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 123*/ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 123*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 123*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 123*/
 else /* Line: 123*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 123*/ {
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 126*/
 else /* Line: 123*/ {
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 127*/ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 127*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 127*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 127*/
 else /* Line: 127*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 127*/ {
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 130*/
 else /* Line: 123*/ {
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 131*/ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 131*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 131*/
 else /* Line: 131*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 131*/ {
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 134*/
 else /* Line: 123*/ {
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 135*/ {
bevt_21_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_ta_ph);
} /* Line: 137*/
 else /* Line: 123*/ {
bevt_23_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 138*/ {
} /* Line: 138*/
 else /* Line: 140*/ {
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_4_3_MathInt_bels_1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(beva_str);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_2));
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevl_ic);
bevt_24_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 141*/
} /* Line: 123*/
} /* Line: 123*/
} /* Line: 123*/
} /* Line: 123*/
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 144*/
 else /* Line: 119*/ {
break;
} /* Line: 119*/
} /* Line: 119*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_toHexString_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bem_toString_3(beva_res, bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, beva_zeroPad, beva_radix, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
/* Line: 188*/ {
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_ts.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 188*/ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
if (bevl_val.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 191*/ {
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_ta_ph.bevi_int;
} /* Line: 192*/
 else /* Line: 193*/ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 194*/
bevt_6_ta_ph = beva_res.bem_capacityGet_0();
bevt_7_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_6_ta_ph.bevi_int <= bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 197*/ {
bevt_9_ta_ph = beva_res.bem_capacityGet_0();
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_10_ta_ph);
beva_res.bem_capacitySet_1(bevt_8_ta_ph);
} /* Line: 198*/
bevt_11_ta_ph = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_ta_ph, bevl_val);
bevt_13_ta_ph = beva_res.bem_sizeGet_0();
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
beva_res.bem_sizeSet_1(bevt_12_ta_ph);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 205*/
 else /* Line: 188*/ {
break;
} /* Line: 188*/
} /* Line: 188*/
while (true)
/* Line: 208*/ {
bevt_18_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_18_ta_ph.bevi_int < beva_zeroPad.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 208*/ {
bevt_20_ta_ph = beva_res.bem_capacityGet_0();
bevt_21_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_20_ta_ph.bevi_int <= bevt_21_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 209*/ {
bevt_23_ta_ph = beva_res.bem_capacityGet_0();
bevt_24_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
beva_res.bem_capacitySet_1(bevt_22_ta_ph);
} /* Line: 210*/
bevt_25_ta_ph = beva_res.bem_sizeGet_0();
bevt_26_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
beva_res.bem_setIntUnchecked_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_28_ta_ph = beva_res.bem_sizeGet_0();
bevt_29_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(bevt_29_ta_ph);
beva_res.bem_sizeSet_1(bevt_27_ta_ph);
} /* Line: 214*/
 else /* Line: 208*/ {
break;
} /* Line: 208*/
} /* Line: 208*/
bevt_33_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_33_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 218*/ {
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 219*/
bevt_35_ta_ph = (BEC_2_4_6_TextString) beva_res.bem_reverseBytes_0();
return bevt_35_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_absValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 235*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_ta_ph);
} /* Line: 236*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 670*/ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 670*/ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 670*/
 else /* Line: 670*/ {
break;
} /* Line: 670*/
} /* Line: 670*/
return bevl_result;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int == bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int != bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {80, 80, 83, 87, 91, 91, 91, 91, 91, 95, 95, 95, 95, 95, 99, 99, 99, 0, 99, 99, 99, 0, 0, 100, 100, 100, 100, 102, 102, 102, 103, 105, 107, 107, 108, 108, 108, 108, 109, 109, 109, 109, 110, 114, 114, 115, 115, 116, 117, 118, 119, 119, 119, 121, 123, 123, 123, 123, 123, 0, 0, 0, 124, 124, 125, 126, 127, 127, 127, 127, 127, 0, 0, 0, 128, 128, 129, 130, 131, 131, 131, 131, 131, 0, 0, 0, 132, 132, 133, 134, 135, 135, 135, 137, 137, 138, 138, 138, 141, 141, 141, 141, 141, 141, 141, 143, 144, 149, 149, 153, 157, 157, 161, 165, 165, 165, 165, 165, 165, 169, 169, 169, 169, 173, 173, 173, 173, 177, 177, 177, 177, 181, 181, 181, 185, 186, 187, 188, 188, 188, 189, 190, 191, 191, 191, 192, 192, 194, 197, 197, 197, 197, 198, 198, 198, 198, 200, 200, 201, 201, 201, 201, 205, 208, 208, 208, 209, 209, 209, 209, 210, 210, 210, 210, 212, 212, 212, 213, 213, 213, 213, 218, 218, 218, 219, 219, 221, 221, 225, 226, 227, 231, 231, 231, 235, 235, 235, 236, 236, 257, 261, 272, 276, 287, 306, 325, 329, 340, 359, 363, 374, 393, 397, 408, 427, 431, 448, 473, 477, 488, 507, 511, 527, 546, 550, 566, 585, 589, 605, 624, 628, 644, 663, 668, 670, 670, 670, 671, 670, 673, 718, 718, 760, 760, 788, 788, 816, 816, 844, 844, 872, 872};
public static new int[] bevs_smnlec
 = new int[] {35, 36, 39, 43, 51, 52, 53, 54, 55, 63, 64, 65, 66, 67, 91, 92, 97, 98, 101, 102, 107, 108, 111, 115, 116, 117, 118, 120, 121, 126, 127, 130, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 179, 180, 181, 182, 183, 184, 185, 188, 189, 194, 195, 196, 197, 202, 203, 208, 209, 212, 216, 219, 220, 221, 222, 225, 226, 231, 232, 237, 238, 241, 245, 248, 249, 250, 251, 254, 255, 260, 261, 266, 267, 270, 274, 277, 278, 279, 280, 283, 284, 289, 290, 291, 294, 295, 300, 303, 304, 305, 306, 307, 308, 309, 315, 316, 326, 327, 330, 335, 336, 339, 347, 348, 349, 350, 351, 352, 358, 359, 360, 361, 367, 368, 369, 370, 376, 377, 378, 379, 384, 385, 386, 427, 428, 429, 432, 433, 438, 439, 440, 441, 442, 447, 448, 449, 452, 454, 455, 456, 461, 462, 463, 464, 465, 467, 468, 469, 470, 471, 472, 473, 481, 482, 487, 488, 489, 490, 495, 496, 497, 498, 499, 501, 502, 503, 504, 505, 506, 507, 513, 514, 519, 520, 521, 523, 524, 528, 529, 530, 535, 536, 537, 543, 544, 549, 550, 551, 558, 562, 565, 569, 572, 577, 582, 586, 589, 594, 598, 601, 606, 610, 613, 618, 622, 625, 630, 634, 637, 642, 646, 649, 654, 658, 661, 666, 670, 673, 678, 682, 685, 690, 696, 697, 700, 705, 706, 707, 713, 723, 724, 734, 735, 744, 745, 754, 755, 764, 765, 774, 775};
/* BEGIN LINEINFO 
assign 1 80 35
new 0 80 35
return 1 80 36
setStringValueDec 1 83 39
setStringValueHex 1 87 43
assign 1 91 51
new 0 91 51
assign 1 91 52
new 0 91 52
assign 1 91 53
new 0 91 53
assign 1 91 54
new 0 91 54
setStringValue 5 91 55
assign 1 95 63
new 0 95 63
assign 1 95 64
new 0 95 64
assign 1 95 65
new 0 95 65
assign 1 95 66
new 0 95 66
setStringValue 5 95 67
assign 1 99 91
new 0 99 91
assign 1 99 92
lesser 1 99 97
assign 1 0 98
assign 1 99 101
new 0 99 101
assign 1 99 102
greater 1 99 107
assign 1 0 108
assign 1 0 111
assign 1 100 115
new 0 100 115
assign 1 100 116
add 1 100 116
assign 1 100 117
new 1 100 117
throw 1 100 118
assign 1 102 120
new 0 102 120
assign 1 102 121
lesser 1 102 126
assign 1 103 127
copy 0 103 127
assign 1 105 130
new 0 105 130
assign 1 107 132
new 0 107 132
addValue 1 107 133
assign 1 108 134
new 0 108 134
assign 1 108 135
new 0 108 135
assign 1 108 136
subtract 1 108 136
assign 1 108 137
add 1 108 137
assign 1 109 138
new 0 109 138
assign 1 109 139
new 0 109 139
assign 1 109 140
subtract 1 109 140
assign 1 109 141
add 1 109 141
setStringValue 5 110 142
assign 1 114 179
new 0 114 179
setValue 1 114 180
assign 1 115 181
sizeGet 0 115 181
assign 1 115 182
copy 0 115 182
decrementValue 0 116 183
assign 1 117 184
new 0 117 184
assign 1 118 185
new 0 118 185
assign 1 119 188
new 0 119 188
assign 1 119 189
greaterEquals 1 119 194
getInt 2 121 195
assign 1 123 196
new 0 123 196
assign 1 123 197
greater 1 123 202
assign 1 123 203
lesser 1 123 208
assign 1 0 209
assign 1 0 212
assign 1 0 216
assign 1 124 219
new 0 124 219
subtractValue 1 124 220
multiplyValue 1 125 221
addValue 1 126 222
assign 1 127 225
new 0 127 225
assign 1 127 226
greater 1 127 231
assign 1 127 232
lesser 1 127 237
assign 1 0 238
assign 1 0 241
assign 1 0 245
assign 1 128 248
new 0 128 248
subtractValue 1 128 249
multiplyValue 1 129 250
addValue 1 130 251
assign 1 131 254
new 0 131 254
assign 1 131 255
greater 1 131 260
assign 1 131 261
lesser 1 131 266
assign 1 0 267
assign 1 0 270
assign 1 0 274
assign 1 132 277
new 0 132 277
subtractValue 1 132 278
multiplyValue 1 133 279
addValue 1 134 280
assign 1 135 283
new 0 135 283
assign 1 135 284
equals 1 135 289
assign 1 137 290
new 0 137 290
multiplyValue 1 137 291
assign 1 138 294
new 0 138 294
assign 1 138 295
equals 1 138 300
assign 1 141 303
new 0 141 303
assign 1 141 304
add 1 141 304
assign 1 141 305
new 0 141 305
assign 1 141 306
add 1 141 306
assign 1 141 307
add 1 141 307
assign 1 141 308
new 1 141 308
throw 1 141 309
decrementValue 0 143 315
multiplyValue 1 144 316
assign 1 149 326
toString 0 149 326
return 1 149 327
new 1 153 330
assign 1 157 335
new 0 157 335
return 1 157 336
return 1 161 339
assign 1 165 347
new 0 165 347
assign 1 165 348
new 1 165 348
assign 1 165 349
new 0 165 349
assign 1 165 350
new 0 165 350
assign 1 165 351
toString 4 165 351
return 1 165 352
assign 1 169 358
new 0 169 358
assign 1 169 359
new 1 169 359
assign 1 169 360
toHexString 1 169 360
return 1 169 361
assign 1 173 367
new 0 173 367
assign 1 173 368
new 0 173 368
assign 1 173 369
toString 3 173 369
return 1 173 370
assign 1 177 376
new 1 177 376
assign 1 177 377
new 0 177 377
assign 1 177 378
toString 4 177 378
return 1 177 379
assign 1 181 384
new 0 181 384
assign 1 181 385
toString 4 181 385
return 1 181 386
clear 0 185 427
assign 1 186 428
abs 0 186 428
assign 1 187 429
new 0 187 429
assign 1 188 432
new 0 188 432
assign 1 188 433
greater 1 188 438
setValue 1 189 439
modulusValue 1 190 440
assign 1 191 441
new 0 191 441
assign 1 191 442
lesser 1 191 447
assign 1 192 448
new 0 192 448
addValue 1 192 449
addValue 1 194 452
assign 1 197 454
capacityGet 0 197 454
assign 1 197 455
sizeGet 0 197 455
assign 1 197 456
lesserEquals 1 197 461
assign 1 198 462
capacityGet 0 198 462
assign 1 198 463
new 0 198 463
assign 1 198 464
add 1 198 464
capacitySet 1 198 465
assign 1 200 467
sizeGet 0 200 467
setIntUnchecked 2 200 468
assign 1 201 469
sizeGet 0 201 469
assign 1 201 470
new 0 201 470
assign 1 201 471
add 1 201 471
sizeSet 1 201 472
divideValue 1 205 473
assign 1 208 481
sizeGet 0 208 481
assign 1 208 482
lesser 1 208 487
assign 1 209 488
capacityGet 0 209 488
assign 1 209 489
sizeGet 0 209 489
assign 1 209 490
lesserEquals 1 209 495
assign 1 210 496
capacityGet 0 210 496
assign 1 210 497
new 0 210 497
assign 1 210 498
add 1 210 498
capacitySet 1 210 499
assign 1 212 501
sizeGet 0 212 501
assign 1 212 502
new 0 212 502
setIntUnchecked 2 212 503
assign 1 213 504
sizeGet 0 213 504
assign 1 213 505
new 0 213 505
assign 1 213 506
add 1 213 506
sizeSet 1 213 507
assign 1 218 513
new 0 218 513
assign 1 218 514
lesser 1 218 519
assign 1 219 520
new 0 219 520
addValue 1 219 521
assign 1 221 523
reverseBytes 0 221 523
return 1 221 524
assign 1 225 528
new 0 225 528
setValue 1 226 529
return 1 227 530
assign 1 231 535
copy 0 231 535
assign 1 231 536
absValue 0 231 536
return 1 231 537
assign 1 235 543
new 0 235 543
assign 1 235 544
lesser 1 235 549
assign 1 236 550
new 0 236 550
multiplyValue 1 236 551
return 1 257 558
assign 1 261 562
new 0 261 562
return 1 272 565
assign 1 276 569
new 0 276 569
return 1 287 572
return 1 306 577
return 1 325 582
assign 1 329 586
new 0 329 586
return 1 340 589
return 1 359 594
assign 1 363 598
new 0 363 598
return 1 374 601
return 1 393 606
assign 1 397 610
new 0 397 610
return 1 408 613
return 1 427 618
assign 1 431 622
new 0 431 622
return 1 448 625
return 1 473 630
assign 1 477 634
new 0 477 634
return 1 488 637
return 1 507 642
assign 1 511 646
new 0 511 646
return 1 527 649
return 1 546 654
assign 1 550 658
new 0 550 658
return 1 566 661
return 1 585 666
assign 1 589 670
new 0 589 670
return 1 605 673
return 1 624 678
assign 1 628 682
new 0 628 682
return 1 644 685
return 1 663 690
assign 1 668 696
new 0 668 696
assign 1 670 697
new 0 670 697
assign 1 670 700
lesser 1 670 705
multiplyValue 1 671 706
incrementValue 0 670 707
return 1 673 713
assign 1 718 723
new 0 718 723
return 1 718 724
assign 1 760 734
new 0 760 734
return 1 760 735
assign 1 788 744
new 0 788 744
return 1 788 745
assign 1 816 754
new 0 816 754
return 1 816 755
assign 1 844 764
new 0 844 764
return 1 844 765
assign 1 872 774
new 0 872 774
return 1 872 775
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1931705863: return bem_sourceFileNameGet_0();
case -523789164: return bem_toHexString_0();
case -893093197: return bem_toString_0();
case 767515792: return bem_abs_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case 954703233: return bem_create_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1834246217: return bem_classNameGet_0();
case -193582610: return bem_tagGet_0();
case 723573269: return bem_vintGet_0();
case -975498393: return bem_fieldNamesGet_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case 1747931697: return bem_vintSet_0();
case -1222440466: return bem_absValue_0();
case 639017651: return bem_increment_0();
case -1369468312: return bem_incrementValue_0();
case -544955612: return bem_decrement_0();
case -1653939165: return bem_iteratorGet_0();
case 2070336861: return bem_decrementValue_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2046264441: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case 1896341401: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case 119748808: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case -1615437732: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 198521581: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1005382720: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 659221263: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case 59504167: return bem_new_1(bevd_0);
case 1154418460: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -2119963393: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1280281489: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case 831552188: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -917252657: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 1076476896: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case 894168902: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case -822990651: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case 1012680220: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1007780901: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case -1731035814: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case -940917539: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case -729378219: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1231405046: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case 1757205067: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -728634447: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1000022126: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -1648734891: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case -300626998: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 1812444079: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case 1916991214: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -175683031: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 377232243: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -1322410780: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -303916959: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -776131811: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_3_MathInt();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
}
