namespace be {

using System.IO;
using System;
    /* IO:File: source/base/Int.be */
public sealed class BEC_2_4_3_MathInt : BEC_2_6_6_SystemObject {
public BEC_2_4_3_MathInt() { }
static BEC_2_4_3_MathInt() { }

   
    public int bevi_int;
    public BEC_2_4_3_MathInt(int bevi_int) { this.bevi_int = bevi_int; }
    
   private static byte[] becc_BEC_2_4_3_MathInt_clname = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] becc_BEC_2_4_3_MathInt_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x49,0x6E,0x74,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_3_MathInt_bels_0 = {0x44,0x6F,0x6E,0x27,0x74,0x20,0x6B,0x6E,0x6F,0x77,0x20,0x68,0x6F,0x77,0x20,0x74,0x6F,0x20,0x68,0x61,0x6E,0x64,0x6C,0x65,0x20,0x72,0x61,0x64,0x69,0x78,0x20,0x6F,0x66,0x20,0x73,0x69,0x7A,0x65,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_1 = {0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x69,0x73,0x20,0x6E,0x6F,0x74,0x20,0x61,0x6E,0x20,0x69,0x6E,0x74,0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_2 = {0x20};
private static byte[] bece_BEC_2_4_3_MathInt_bels_3 = {0x2D};
public static new BEC_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_inst;

public static new BET_2_4_3_MathInt bece_BEC_2_4_3_MathInt_bevs_type;

public BEC_2_4_3_MathInt bem_vintGet_0() {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vintSet_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
return (BEC_2_6_6_SystemObject) bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_new_1(BEC_2_6_6_SystemObject beva_str) {
bem_setStringValueDec_1((BEC_2_4_6_TextString) beva_str );
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hexNew_1(BEC_2_4_6_TextString beva_str) {
bem_setStringValueHex_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueDec_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(97));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValueHex_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(58));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(71));
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(103));
bem_setStringValue_5(beva_str, bevt_0_ta_ph, bevt_1_ta_ph, bevt_2_ta_ph, bevt_3_ta_ph);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_3_MathInt bevl_max0 = null;
BEC_2_4_3_MathInt bevl_maxA = null;
BEC_2_4_3_MathInt bevl_maxa = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_6_9_SystemException bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
if (beva_radix.bevi_int < bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 95*/ {
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(24));
if (beva_radix.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 95*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 95*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 95*/ {
bevt_7_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(39, bece_BEC_2_4_3_MathInt_bels_0));
bevt_6_ta_ph = bevt_7_ta_ph.bem_add_1(beva_radix);
bevt_5_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_6_ta_ph);
throw new be.BECS_ThrowBack(bevt_5_ta_ph);
} /* Line: 96*/
bevt_9_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
if (beva_radix.bevi_int < bevt_9_ta_ph.bevi_int) {
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 98*/ {
bevl_max0 = (BEC_2_4_3_MathInt) beva_radix.bem_copy_0();
} /* Line: 99*/
 else /* Line: 100*/ {
bevl_max0 = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
} /* Line: 101*/
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_max0.bevi_int += bevt_10_ta_ph.bevi_int;
bevt_11_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(65));
bevt_13_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_12_ta_ph = beva_radix.bem_subtract_1(bevt_13_ta_ph);
bevl_maxA = bevt_11_ta_ph.bem_add_1(bevt_12_ta_ph);
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(97));
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_15_ta_ph = beva_radix.bem_subtract_1(bevt_16_ta_ph);
bevl_maxa = bevt_14_ta_ph.bem_add_1(bevt_15_ta_ph);
bem_setStringValue_5(beva_str, beva_radix, bevl_max0, bevl_maxA, bevl_maxa);
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setStringValue_5(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_max0, BEC_2_4_3_MathInt beva_maxA, BEC_2_4_3_MathInt beva_maxa) {
BEC_2_4_3_MathInt bevl_j = null;
BEC_2_4_3_MathInt bevl_pow = null;
BEC_2_4_3_MathInt bevl_ic = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_6_9_SystemException bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevi_int = bevt_3_ta_ph.bevi_int;
bevt_4_ta_ph = beva_str.bem_sizeGet_0();
bevl_j = (BEC_2_4_3_MathInt) bevt_4_ta_ph.bem_copy_0();
bevl_j.bem_decrementValue_0();
bevl_pow = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_ic = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
/* Line: 115*/ {
bevt_6_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_j.bevi_int >= bevt_6_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 115*/ {
beva_str.bem_getInt_2(bevl_j, bevl_ic);
bevt_8_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(47));
if (bevl_ic.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 119*/ {
if (bevl_ic.bevi_int < beva_max0.bevi_int) {
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 119*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 119*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 119*/
 else /* Line: 119*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 119*/ {
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_ic.bem_subtractValue_1(bevt_10_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 122*/
 else /* Line: 119*/ {
bevt_12_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(64));
if (bevl_ic.bevi_int > bevt_12_ta_ph.bevi_int) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 123*/ {
if (bevl_ic.bevi_int < beva_maxA.bevi_int) {
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 123*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 123*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 123*/
 else /* Line: 123*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 123*/ {
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevl_ic.bem_subtractValue_1(bevt_14_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 126*/
 else /* Line: 119*/ {
bevt_16_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(96));
if (bevl_ic.bevi_int > bevt_16_ta_ph.bevi_int) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 127*/ {
if (bevl_ic.bevi_int < beva_maxa.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 127*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 127*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 127*/
 else /* Line: 127*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 127*/ {
bevt_18_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(87));
bevl_ic.bem_subtractValue_1(bevt_18_ta_ph);
bevl_ic.bem_multiplyValue_1(bevl_pow);
bevi_int += bevl_ic.bevi_int;
} /* Line: 130*/
 else /* Line: 119*/ {
bevt_20_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(45));
if (bevl_ic.bevi_int == bevt_20_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 131*/ {
bevt_21_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_21_ta_ph);
} /* Line: 133*/
 else /* Line: 119*/ {
bevt_23_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(43));
if (bevl_ic.bevi_int == bevt_23_ta_ph.bevi_int) {
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 134*/ {
} /* Line: 134*/
 else /* Line: 136*/ {
bevt_28_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_4_3_MathInt_bels_1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(beva_str);
bevt_29_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_2));
bevt_26_ta_ph = bevt_27_ta_ph.bem_add_1(bevt_29_ta_ph);
bevt_25_ta_ph = bevt_26_ta_ph.bem_add_1(bevl_ic);
bevt_24_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_25_ta_ph);
throw new be.BECS_ThrowBack(bevt_24_ta_ph);
} /* Line: 137*/
} /* Line: 119*/
} /* Line: 119*/
} /* Line: 119*/
} /* Line: 119*/
bevl_j.bem_decrementValue_0();
bevl_pow.bem_multiplyValue_1(beva_radix);
} /* Line: 140*/
 else /* Line: 115*/ {
break;
} /* Line: 115*/
} /* Line: 115*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_serializeToString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_toString_0();
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_snw) {
bem_new_1(beva_snw);
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_serializeContents_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_ta_ph;
} /*method end*/
public override BEC_2_4_3_MathInt bem_hashGet_0() {
return this;
} /*method end*/
public BEC_2_4_5_MathFloat bem_toFloat_0() {
BEC_2_4_5_MathFloat bevl_fi = null;
bevl_fi = (BEC_2_4_5_MathFloat) (new BEC_2_4_5_MathFloat()).bem_new_0();

      bevl_fi.bevi_float = (float) this.bevi_int;
      return bevl_fi;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, bevt_3_ta_ph, bevt_4_ta_ph, null);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_toHexString_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toHexString_1(BEC_2_4_6_TextString beva_res) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(2));
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(16));
bevt_0_ta_ph = bem_toString_3(beva_res, bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_2(BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(beva_zeroPad);
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(bevt_1_ta_ph, beva_zeroPad, beva_radix, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_3(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(55));
bevt_0_ta_ph = bem_toString_4(beva_res, beva_zeroPad, beva_radix, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_4(BEC_2_4_6_TextString beva_res, BEC_2_4_3_MathInt beva_zeroPad, BEC_2_4_3_MathInt beva_radix, BEC_2_4_3_MathInt beva_alphaStart) {
BEC_2_4_3_MathInt bevl_ts = null;
BEC_2_4_3_MathInt bevl_val = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_4_3_MathInt bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_4_3_MathInt bevt_21_ta_ph = null;
BEC_2_4_3_MathInt bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_4_3_MathInt bevt_24_ta_ph = null;
BEC_2_4_3_MathInt bevt_25_ta_ph = null;
BEC_2_4_3_MathInt bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_4_3_MathInt bevt_28_ta_ph = null;
BEC_2_4_3_MathInt bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_4_3_MathInt bevt_31_ta_ph = null;
BEC_2_5_4_LogicBool bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
beva_res.bem_clear_0();
bevl_ts = bem_abs_0();
bevl_val = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
while (true)
/* Line: 218*/ {
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevl_ts.bevi_int > bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 218*/ {
bevl_val.bevi_int = bevl_ts.bevi_int;
bevl_val.bem_modulusValue_1(beva_radix);
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(10));
if (bevl_val.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 221*/ {
bevt_4_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
bevl_val.bevi_int += bevt_4_ta_ph.bevi_int;
} /* Line: 222*/
 else /* Line: 223*/ {
bevl_val.bevi_int += beva_alphaStart.bevi_int;
} /* Line: 224*/
bevt_6_ta_ph = beva_res.bem_capacityGet_0();
bevt_7_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_6_ta_ph.bevi_int <= bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 227*/ {
bevt_9_ta_ph = beva_res.bem_capacityGet_0();
bevt_10_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_8_ta_ph = bevt_9_ta_ph.bem_add_1(bevt_10_ta_ph);
beva_res.bem_capacitySet_1(bevt_8_ta_ph);
} /* Line: 228*/
bevt_11_ta_ph = beva_res.bem_sizeGet_0();
beva_res.bem_setIntUnchecked_2(bevt_11_ta_ph, bevl_val);
bevt_13_ta_ph = beva_res.bem_sizeGet_0();
bevt_14_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_12_ta_ph = bevt_13_ta_ph.bem_add_1(bevt_14_ta_ph);
beva_res.bem_sizeSet_1(bevt_12_ta_ph);
bevl_ts.bem_divideValue_1(beva_radix);
} /* Line: 235*/
 else /* Line: 218*/ {
break;
} /* Line: 218*/
} /* Line: 218*/
while (true)
/* Line: 238*/ {
bevt_18_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_18_ta_ph.bevi_int < beva_zeroPad.bevi_int) {
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 238*/ {
bevt_20_ta_ph = beva_res.bem_capacityGet_0();
bevt_21_ta_ph = beva_res.bem_sizeGet_0();
if (bevt_20_ta_ph.bevi_int <= bevt_21_ta_ph.bevi_int) {
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 239*/ {
bevt_23_ta_ph = beva_res.bem_capacityGet_0();
bevt_24_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4));
bevt_22_ta_ph = bevt_23_ta_ph.bem_add_1(bevt_24_ta_ph);
beva_res.bem_capacitySet_1(bevt_22_ta_ph);
} /* Line: 240*/
bevt_25_ta_ph = beva_res.bem_sizeGet_0();
bevt_26_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(48));
beva_res.bem_setIntUnchecked_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_28_ta_ph = beva_res.bem_sizeGet_0();
bevt_29_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_27_ta_ph = bevt_28_ta_ph.bem_add_1(bevt_29_ta_ph);
beva_res.bem_sizeSet_1(bevt_27_ta_ph);
} /* Line: 244*/
 else /* Line: 238*/ {
break;
} /* Line: 238*/
} /* Line: 238*/
bevt_33_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_33_ta_ph.bevi_int) {
bevt_32_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_32_ta_ph.bevi_bool)/* Line: 248*/ {
bevt_34_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_4_3_MathInt_bels_3));
beva_res.bem_addValue_1(bevt_34_ta_ph);
} /* Line: 249*/
bevt_35_ta_ph = (BEC_2_4_6_TextString) beva_res.bem_reverseBytes_0();
return bevt_35_ta_ph;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_copy_0() {
BEC_2_4_3_MathInt bevl_c = null;
bevl_c = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());
bevl_c.bevi_int = bevi_int;
return (BEC_2_6_6_SystemObject) bevl_c;
} /*method end*/
public BEC_2_4_3_MathInt bem_abs_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) bem_copy_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_absValue_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_absValue_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
if (bevi_int < bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 265*/ {
bevt_2_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(-1));
bem_multiplyValue_1(bevt_2_ta_ph);
} /* Line: 266*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_setValue_1(BEC_2_4_3_MathInt beva_xi) {

this.bevi_int = beva_xi.bevi_int;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_increment_0() {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrement_0() {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - 1;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_incrementValue_0() {

      this.bevi_int++;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_decrementValue_0() {

      this.bevi_int--;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_add_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int + beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_addValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int += beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtract_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int - beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_subtractValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int -= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiply_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

            bevl_res.bevi_int = this.bevi_int * beva_xi.bevi_int;
        return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_multiplyValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int *= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_divide_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int / beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_divideValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int /= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulus_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_res = null;
bevl_res = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

                bevl_res.bevi_int = this.bevi_int % beva_xi.bevi_int;
            return bevl_res;
} /*method end*/
public BEC_2_4_3_MathInt bem_modulusValue_1(BEC_2_4_3_MathInt beva_xi) {

      this.bevi_int %= beva_xi.bevi_int;
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_and_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int & beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_andValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int &= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_or_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int | beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_orValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int |= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeft_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int << beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftLeftValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int <<= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRight_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_4_3_MathInt bevl_toReti = null;
bevl_toReti = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt());

        bevl_toReti.bevi_int = this.bevi_int >> beva_xi.bevi_int;
    return bevl_toReti;
} /*method end*/
public BEC_2_4_3_MathInt bem_shiftRightValue_1(BEC_2_4_3_MathInt beva_xi) {

        this.bevi_int >>= beva_xi.bevi_int;
    return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_power_1(BEC_2_4_3_MathInt beva_other) {
BEC_2_4_3_MathInt bevl_result = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
bevl_result = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 700*/ {
if (bevl_i.bevi_int < beva_other.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 700*/ {
bevl_result.bem_multiplyValue_1(this);
bevl_i.bevi_int++;
} /* Line: 700*/
 else /* Line: 700*/ {
break;
} /* Line: 700*/
} /* Line: 700*/
return bevl_result;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int == bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      var bevls_xi = beva_xi as BEC_2_4_3_MathInt;
      if (this.bevi_int != bevls_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greater_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int > beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesser_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int < beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_greaterEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int >= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_lesserEquals_1(BEC_2_4_3_MathInt beva_xi) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;

      if (this.bevi_int <= beva_xi.bevi_int) {
        return be.BECS_Runtime.boolTrue;
      }
      bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_1_ta_ph;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {76, 76, 79, 83, 87, 87, 87, 87, 87, 91, 91, 91, 91, 91, 95, 95, 95, 0, 95, 95, 95, 0, 0, 96, 96, 96, 96, 98, 98, 98, 99, 101, 103, 103, 104, 104, 104, 104, 105, 105, 105, 105, 106, 110, 110, 111, 111, 112, 113, 114, 115, 115, 115, 117, 119, 119, 119, 119, 119, 0, 0, 0, 120, 120, 121, 122, 123, 123, 123, 123, 123, 0, 0, 0, 124, 124, 125, 126, 127, 127, 127, 127, 127, 0, 0, 0, 128, 128, 129, 130, 131, 131, 131, 133, 133, 134, 134, 134, 137, 137, 137, 137, 137, 137, 137, 139, 140, 145, 145, 149, 153, 153, 157, 168, 191, 195, 195, 195, 195, 195, 195, 199, 199, 199, 199, 203, 203, 203, 203, 207, 207, 207, 207, 211, 211, 211, 215, 216, 217, 218, 218, 218, 219, 220, 221, 221, 221, 222, 222, 224, 227, 227, 227, 227, 228, 228, 228, 228, 230, 230, 231, 231, 231, 231, 235, 238, 238, 238, 239, 239, 239, 239, 240, 240, 240, 240, 242, 242, 242, 243, 243, 243, 243, 248, 248, 248, 249, 249, 251, 251, 255, 256, 257, 261, 261, 261, 265, 265, 265, 266, 266, 287, 291, 302, 306, 317, 336, 355, 359, 370, 389, 393, 404, 423, 427, 438, 457, 461, 478, 503, 507, 518, 537, 541, 557, 576, 580, 596, 615, 619, 635, 654, 658, 674, 693, 698, 700, 700, 700, 701, 700, 703, 748, 748, 790, 790, 818, 818, 846, 846, 874, 874, 902, 902};
public static new int[] bevs_smnlec
 = new int[] {35, 36, 39, 43, 51, 52, 53, 54, 55, 63, 64, 65, 66, 67, 91, 92, 97, 98, 101, 102, 107, 108, 111, 115, 116, 117, 118, 120, 121, 126, 127, 130, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 179, 180, 181, 182, 183, 184, 185, 188, 189, 194, 195, 196, 197, 202, 203, 208, 209, 212, 216, 219, 220, 221, 222, 225, 226, 231, 232, 237, 238, 241, 245, 248, 249, 250, 251, 254, 255, 260, 261, 266, 267, 270, 274, 277, 278, 279, 280, 283, 284, 289, 290, 291, 294, 295, 300, 303, 304, 305, 306, 307, 308, 309, 315, 316, 326, 327, 330, 335, 336, 339, 343, 346, 354, 355, 356, 357, 358, 359, 365, 366, 367, 368, 374, 375, 376, 377, 383, 384, 385, 386, 391, 392, 393, 434, 435, 436, 439, 440, 445, 446, 447, 448, 449, 454, 455, 456, 459, 461, 462, 463, 468, 469, 470, 471, 472, 474, 475, 476, 477, 478, 479, 480, 488, 489, 494, 495, 496, 497, 502, 503, 504, 505, 506, 508, 509, 510, 511, 512, 513, 514, 520, 521, 526, 527, 528, 530, 531, 535, 536, 537, 542, 543, 544, 550, 551, 556, 557, 558, 565, 569, 572, 576, 579, 584, 589, 593, 596, 601, 605, 608, 613, 617, 620, 625, 629, 632, 637, 641, 644, 649, 653, 656, 661, 665, 668, 673, 677, 680, 685, 689, 692, 697, 703, 704, 707, 712, 713, 714, 720, 730, 731, 741, 742, 751, 752, 761, 762, 771, 772, 781, 782};
/* BEGIN LINEINFO 
assign 1 76 35
new 0 76 35
return 1 76 36
setStringValueDec 1 79 39
setStringValueHex 1 83 43
assign 1 87 51
new 0 87 51
assign 1 87 52
new 0 87 52
assign 1 87 53
new 0 87 53
assign 1 87 54
new 0 87 54
setStringValue 5 87 55
assign 1 91 63
new 0 91 63
assign 1 91 64
new 0 91 64
assign 1 91 65
new 0 91 65
assign 1 91 66
new 0 91 66
setStringValue 5 91 67
assign 1 95 91
new 0 95 91
assign 1 95 92
lesser 1 95 97
assign 1 0 98
assign 1 95 101
new 0 95 101
assign 1 95 102
greater 1 95 107
assign 1 0 108
assign 1 0 111
assign 1 96 115
new 0 96 115
assign 1 96 116
add 1 96 116
assign 1 96 117
new 1 96 117
throw 1 96 118
assign 1 98 120
new 0 98 120
assign 1 98 121
lesser 1 98 126
assign 1 99 127
copy 0 99 127
assign 1 101 130
new 0 101 130
assign 1 103 132
new 0 103 132
addValue 1 103 133
assign 1 104 134
new 0 104 134
assign 1 104 135
new 0 104 135
assign 1 104 136
subtract 1 104 136
assign 1 104 137
add 1 104 137
assign 1 105 138
new 0 105 138
assign 1 105 139
new 0 105 139
assign 1 105 140
subtract 1 105 140
assign 1 105 141
add 1 105 141
setStringValue 5 106 142
assign 1 110 179
new 0 110 179
setValue 1 110 180
assign 1 111 181
sizeGet 0 111 181
assign 1 111 182
copy 0 111 182
decrementValue 0 112 183
assign 1 113 184
new 0 113 184
assign 1 114 185
new 0 114 185
assign 1 115 188
new 0 115 188
assign 1 115 189
greaterEquals 1 115 194
getInt 2 117 195
assign 1 119 196
new 0 119 196
assign 1 119 197
greater 1 119 202
assign 1 119 203
lesser 1 119 208
assign 1 0 209
assign 1 0 212
assign 1 0 216
assign 1 120 219
new 0 120 219
subtractValue 1 120 220
multiplyValue 1 121 221
addValue 1 122 222
assign 1 123 225
new 0 123 225
assign 1 123 226
greater 1 123 231
assign 1 123 232
lesser 1 123 237
assign 1 0 238
assign 1 0 241
assign 1 0 245
assign 1 124 248
new 0 124 248
subtractValue 1 124 249
multiplyValue 1 125 250
addValue 1 126 251
assign 1 127 254
new 0 127 254
assign 1 127 255
greater 1 127 260
assign 1 127 261
lesser 1 127 266
assign 1 0 267
assign 1 0 270
assign 1 0 274
assign 1 128 277
new 0 128 277
subtractValue 1 128 278
multiplyValue 1 129 279
addValue 1 130 280
assign 1 131 283
new 0 131 283
assign 1 131 284
equals 1 131 289
assign 1 133 290
new 0 133 290
multiplyValue 1 133 291
assign 1 134 294
new 0 134 294
assign 1 134 295
equals 1 134 300
assign 1 137 303
new 0 137 303
assign 1 137 304
add 1 137 304
assign 1 137 305
new 0 137 305
assign 1 137 306
add 1 137 306
assign 1 137 307
add 1 137 307
assign 1 137 308
new 1 137 308
throw 1 137 309
decrementValue 0 139 315
multiplyValue 1 140 316
assign 1 145 326
toString 0 145 326
return 1 145 327
new 1 149 330
assign 1 153 335
new 0 153 335
return 1 153 336
return 1 157 339
assign 1 168 343
new 0 168 343
return 1 191 346
assign 1 195 354
new 0 195 354
assign 1 195 355
new 1 195 355
assign 1 195 356
new 0 195 356
assign 1 195 357
new 0 195 357
assign 1 195 358
toString 4 195 358
return 1 195 359
assign 1 199 365
new 0 199 365
assign 1 199 366
new 1 199 366
assign 1 199 367
toHexString 1 199 367
return 1 199 368
assign 1 203 374
new 0 203 374
assign 1 203 375
new 0 203 375
assign 1 203 376
toString 3 203 376
return 1 203 377
assign 1 207 383
new 1 207 383
assign 1 207 384
new 0 207 384
assign 1 207 385
toString 4 207 385
return 1 207 386
assign 1 211 391
new 0 211 391
assign 1 211 392
toString 4 211 392
return 1 211 393
clear 0 215 434
assign 1 216 435
abs 0 216 435
assign 1 217 436
new 0 217 436
assign 1 218 439
new 0 218 439
assign 1 218 440
greater 1 218 445
setValue 1 219 446
modulusValue 1 220 447
assign 1 221 448
new 0 221 448
assign 1 221 449
lesser 1 221 454
assign 1 222 455
new 0 222 455
addValue 1 222 456
addValue 1 224 459
assign 1 227 461
capacityGet 0 227 461
assign 1 227 462
sizeGet 0 227 462
assign 1 227 463
lesserEquals 1 227 468
assign 1 228 469
capacityGet 0 228 469
assign 1 228 470
new 0 228 470
assign 1 228 471
add 1 228 471
capacitySet 1 228 472
assign 1 230 474
sizeGet 0 230 474
setIntUnchecked 2 230 475
assign 1 231 476
sizeGet 0 231 476
assign 1 231 477
new 0 231 477
assign 1 231 478
add 1 231 478
sizeSet 1 231 479
divideValue 1 235 480
assign 1 238 488
sizeGet 0 238 488
assign 1 238 489
lesser 1 238 494
assign 1 239 495
capacityGet 0 239 495
assign 1 239 496
sizeGet 0 239 496
assign 1 239 497
lesserEquals 1 239 502
assign 1 240 503
capacityGet 0 240 503
assign 1 240 504
new 0 240 504
assign 1 240 505
add 1 240 505
capacitySet 1 240 506
assign 1 242 508
sizeGet 0 242 508
assign 1 242 509
new 0 242 509
setIntUnchecked 2 242 510
assign 1 243 511
sizeGet 0 243 511
assign 1 243 512
new 0 243 512
assign 1 243 513
add 1 243 513
sizeSet 1 243 514
assign 1 248 520
new 0 248 520
assign 1 248 521
lesser 1 248 526
assign 1 249 527
new 0 249 527
addValue 1 249 528
assign 1 251 530
reverseBytes 0 251 530
return 1 251 531
assign 1 255 535
new 0 255 535
setValue 1 256 536
return 1 257 537
assign 1 261 542
copy 0 261 542
assign 1 261 543
absValue 0 261 543
return 1 261 544
assign 1 265 550
new 0 265 550
assign 1 265 551
lesser 1 265 556
assign 1 266 557
new 0 266 557
multiplyValue 1 266 558
return 1 287 565
assign 1 291 569
new 0 291 569
return 1 302 572
assign 1 306 576
new 0 306 576
return 1 317 579
return 1 336 584
return 1 355 589
assign 1 359 593
new 0 359 593
return 1 370 596
return 1 389 601
assign 1 393 605
new 0 393 605
return 1 404 608
return 1 423 613
assign 1 427 617
new 0 427 617
return 1 438 620
return 1 457 625
assign 1 461 629
new 0 461 629
return 1 478 632
return 1 503 637
assign 1 507 641
new 0 507 641
return 1 518 644
return 1 537 649
assign 1 541 653
new 0 541 653
return 1 557 656
return 1 576 661
assign 1 580 665
new 0 580 665
return 1 596 668
return 1 615 673
assign 1 619 677
new 0 619 677
return 1 635 680
return 1 654 685
assign 1 658 689
new 0 658 689
return 1 674 692
return 1 693 697
assign 1 698 703
new 0 698 703
assign 1 700 704
new 0 700 704
assign 1 700 707
lesser 1 700 712
multiplyValue 1 701 713
incrementValue 0 700 714
return 1 703 720
assign 1 748 730
new 0 748 730
return 1 748 731
assign 1 790 741
new 0 790 741
return 1 790 742
assign 1 818 751
new 0 818 751
return 1 818 752
assign 1 846 761
new 0 846 761
return 1 846 762
assign 1 874 771
new 0 874 771
return 1 874 772
assign 1 902 781
new 0 902 781
return 1 902 782
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 578203260: return bem_toFloat_0();
case -209450291: return bem_abs_0();
case -1387831588: return bem_print_0();
case -1188922735: return bem_echo_0();
case -793241295: return bem_iteratorGet_0();
case 371157924: return bem_sourceFileNameGet_0();
case -593965290: return bem_decrementValue_0();
case 1652521523: return bem_serializeContents_0();
case -854754207: return bem_incrementValue_0();
case -1760538533: return bem_classNameGet_0();
case -215604820: return bem_decrement_0();
case 7254011: return bem_fieldIteratorGet_0();
case -921473949: return bem_fieldNamesGet_0();
case 895193825: return bem_once_0();
case -467511392: return bem_toString_0();
case -1323898541: return bem_toAny_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -27893732: return bem_increment_0();
case 1403688004: return bem_serializationIteratorGet_0();
case -447432319: return bem_many_0();
case 1597327951: return bem_create_0();
case -1363819567: return bem_new_0();
case 1332710105: return bem_toHexString_0();
case 354794670: return bem_absValue_0();
case 1092105192: return bem_hashGet_0();
case -1013429750: return bem_vintSet_0();
case 939375888: return bem_vintGet_0();
case -105946774: return bem_serializeToString_0();
case 1890854002: return bem_tagGet_0();
case 1319388306: return bem_copy_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -686810675: return bem_copyTo_1(bevd_0);
case 1673607596: return bem_andValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1334133468: return bem_multiplyValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1634078582: return bem_addValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1838163827: return bem_and_1((BEC_2_4_3_MathInt) bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -1954193135: return bem_setValue_1((BEC_2_4_3_MathInt) bevd_0);
case -56309619: return bem_divideValue_1((BEC_2_4_3_MathInt) bevd_0);
case -475350780: return bem_add_1((BEC_2_4_3_MathInt) bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2036819915: return bem_lesser_1((BEC_2_4_3_MathInt) bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case -1292304462: return bem_multiply_1((BEC_2_4_3_MathInt) bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1396564732: return bem_shiftRight_1((BEC_2_4_3_MathInt) bevd_0);
case 1723283142: return bem_setStringValueDec_1((BEC_2_4_6_TextString) bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1654140440: return bem_divide_1((BEC_2_4_3_MathInt) bevd_0);
case 1657278772: return bem_setStringValueHex_1((BEC_2_4_6_TextString) bevd_0);
case -549502502: return bem_modulus_1((BEC_2_4_3_MathInt) bevd_0);
case -486077582: return bem_shiftLeft_1((BEC_2_4_3_MathInt) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case 815188456: return bem_or_1((BEC_2_4_3_MathInt) bevd_0);
case -2063389309: return bem_orValue_1((BEC_2_4_3_MathInt) bevd_0);
case -1483853795: return bem_greater_1((BEC_2_4_3_MathInt) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case 1201158403: return bem_toHexString_1((BEC_2_4_6_TextString) bevd_0);
case -308697036: return bem_hexNew_1((BEC_2_4_6_TextString) bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case 720013079: return bem_greaterEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -708188282: return bem_modulusValue_1((BEC_2_4_3_MathInt) bevd_0);
case 1820255345: return bem_shiftLeftValue_1((BEC_2_4_3_MathInt) bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1398792303: return bem_subtractValue_1((BEC_2_4_3_MathInt) bevd_0);
case 959391978: return bem_lesserEquals_1((BEC_2_4_3_MathInt) bevd_0);
case -447310481: return bem_subtract_1((BEC_2_4_3_MathInt) bevd_0);
case 1978323341: return bem_shiftRightValue_1((BEC_2_4_3_MathInt) bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case 1929898803: return bem_new_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case -876033008: return bem_power_1((BEC_2_4_3_MathInt) bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -925329384: return bem_toString_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -883394036: return bem_setStringValue_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1144549696: return bem_toString_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 2091448573: return bem_toString_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 213192001: return bem_setStringValue_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_3_MathInt) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(8, becc_BEC_2_4_3_MathInt_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(18, becc_BEC_2_4_3_MathInt_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_3_MathInt();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst = (BEC_2_4_3_MathInt) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_3_MathInt.bece_BEC_2_4_3_MathInt_bevs_type;
}
}
}
