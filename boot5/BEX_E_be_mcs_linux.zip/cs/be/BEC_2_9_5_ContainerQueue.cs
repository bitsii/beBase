namespace be {
/* IO:File: source/base/Stack.be */
public class BEC_2_9_5_ContainerQueue : BEC_2_6_6_SystemObject {
public BEC_2_9_5_ContainerQueue() { }
static BEC_2_9_5_ContainerQueue() { }
private static byte[] becc_BEC_2_9_5_ContainerQueue_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x51,0x75,0x65,0x75,0x65};
private static byte[] becc_BEC_2_9_5_ContainerQueue_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x61,0x63,0x6B,0x2E,0x62,0x65};
public static new BEC_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_inst;

public static new BET_2_9_5_ContainerQueue bece_BEC_2_9_5_ContainerQueue_bevs_type;

public BEC_3_9_5_4_ContainerStackNode bevp_top;
public BEC_3_9_5_4_ContainerStackNode bevp_bottom;
public BEC_3_9_5_4_ContainerStackNode bevp_end;
public BEC_2_4_3_MathInt bevp_size;
public override BEC_2_6_6_SystemObject bem_new_0() {
bevp_size = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_addValue_1(BEC_2_6_6_SystemObject beva_item) {
bem_enqueue_1(beva_item);
return this;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_enqueue_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_3_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_4_tmpany_phold = null;
BEC_3_9_5_4_ContainerStackNode bevt_5_tmpany_phold = null;
if (bevp_top == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_end = bevp_top;
bevp_bottom = bevp_top;
} /* Line: 129 */
 else  /* Line: 126 */ {
if (bevp_bottom == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 130 */ {
bevt_3_tmpany_phold = bevp_top.bem_nextGet_0();
if (bevt_3_tmpany_phold == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_4_tmpany_phold = (BEC_3_9_5_4_ContainerStackNode) (new BEC_3_9_5_4_ContainerStackNode()).bem_new_0();
bevp_top.bem_nextSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bevp_top.bem_nextGet_0();
bevt_5_tmpany_phold.bem_priorSet_1(bevp_top);
bevp_top = bevp_top.bem_nextGet_0();
bevp_end = bevp_top;
} /* Line: 135 */
 else  /* Line: 136 */ {
bevp_top = bevp_top.bem_nextGet_0();
} /* Line: 137 */
} /* Line: 131 */
 else  /* Line: 139 */ {
bevp_bottom = bevp_top;
} /* Line: 140 */
} /* Line: 126 */
bevp_top.bem_heldSet_1(beva_item);
bevp_size = bevp_size.bem_increment_0();
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_dequeue_0() {
BEC_2_6_6_SystemObject bevl_item = null;
BEC_3_9_5_4_ContainerStackNode bevl_last = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 147 */ {
return null;
} /* Line: 148 */
bevl_item = bevp_bottom.bem_heldGet_0();
bevp_bottom.bem_heldSet_1(null);
bevt_1_tmpany_phold = bevp_bottom.bem_equals_1(bevp_top);
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevp_bottom = null;
} /* Line: 153 */
 else  /* Line: 154 */ {
bevl_last = bevp_bottom;
bevp_bottom = bevp_bottom.bem_nextGet_0();
bevl_last.bem_nextSet_1(null);
bevl_last.bem_priorSet_1(bevp_end);
bevp_end.bem_nextSet_1(bevl_last);
bevp_end = bevl_last;
} /* Line: 161 */
bevp_size = bevp_size.bem_decrement_0();
return bevl_item;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_isEmptyGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_bottom == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_get_0() {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_dequeue_0();
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_put_1(BEC_2_6_6_SystemObject beva_item) {
BEC_2_9_5_ContainerQueue bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_9_5_ContainerQueue) bem_enqueue_1(beva_item);
return bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_topGet_0() {
return bevp_top;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_topGetDirect_0() {
return bevp_top;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_topSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_topSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_top = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_bottomGet_0() {
return bevp_bottom;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_bottomGetDirect_0() {
return bevp_bottom;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_bottomSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_bottomSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_bottom = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_3_9_5_4_ContainerStackNode bem_endGet_0() {
return bevp_end;
} /*method end*/
public BEC_3_9_5_4_ContainerStackNode bem_endGetDirect_0() {
return bevp_end;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_endSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_endSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_end = (BEC_3_9_5_4_ContainerStackNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_sizeGet_0() {
return bevp_size;
} /*method end*/
public BEC_2_4_3_MathInt bem_sizeGetDirect_0() {
return bevp_size;
} /*method end*/
public virtual BEC_2_9_5_ContainerQueue bem_sizeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_5_ContainerQueue bem_sizeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_size = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {116, 122, 126, 126, 127, 128, 129, 130, 130, 131, 131, 131, 132, 132, 133, 133, 134, 135, 137, 140, 142, 143, 147, 147, 148, 150, 151, 152, 153, 156, 157, 158, 159, 160, 161, 163, 164, 168, 168, 172, 172, 176, 176, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {17, 21, 31, 36, 37, 38, 39, 42, 47, 48, 49, 54, 55, 56, 57, 58, 59, 60, 63, 67, 70, 71, 79, 84, 85, 87, 88, 89, 91, 94, 95, 96, 97, 98, 99, 101, 102, 106, 111, 115, 116, 120, 121, 124, 127, 130, 134, 138, 141, 144, 148, 152, 155, 158, 162, 166, 169, 172, 176};
/* BEGIN LINEINFO 
assign 1 116 17
new 0 116 17
enqueue 1 122 21
assign 1 126 31
undef 1 126 36
assign 1 127 37
new 0 127 37
assign 1 128 38
assign 1 129 39
assign 1 130 42
def 1 130 47
assign 1 131 48
nextGet 0 131 48
assign 1 131 49
undef 1 131 54
assign 1 132 55
new 0 132 55
nextSet 1 132 56
assign 1 133 57
nextGet 0 133 57
priorSet 1 133 58
assign 1 134 59
nextGet 0 134 59
assign 1 135 60
assign 1 137 63
nextGet 0 137 63
assign 1 140 67
heldSet 1 142 70
assign 1 143 71
increment 0 143 71
assign 1 147 79
undef 1 147 84
return 1 148 85
assign 1 150 87
heldGet 0 150 87
heldSet 1 151 88
assign 1 152 89
equals 1 152 89
assign 1 153 91
assign 1 156 94
assign 1 157 95
nextGet 0 157 95
nextSet 1 158 96
priorSet 1 159 97
nextSet 1 160 98
assign 1 161 99
assign 1 163 101
decrement 0 163 101
return 1 164 102
assign 1 168 106
undef 1 168 111
return 1 168 111
assign 1 172 115
dequeue 0 172 115
return 1 172 116
assign 1 176 120
enqueue 1 176 120
return 1 176 121
return 1 0 124
return 1 0 127
assign 1 0 130
assign 1 0 134
return 1 0 138
return 1 0 141
assign 1 0 144
assign 1 0 148
return 1 0 152
return 1 0 155
assign 1 0 158
assign 1 0 162
return 1 0 166
return 1 0 169
assign 1 0 172
assign 1 0 176
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1581473659: return bem_endGetDirect_0();
case -1947998015: return bem_topGet_0();
case 1115941233: return bem_hashGet_0();
case 1978340744: return bem_copy_0();
case 347445468: return bem_deserializeClassNameGet_0();
case 1739040137: return bem_fieldIteratorGet_0();
case -1397319262: return bem_bottomGet_0();
case -1497387944: return bem_many_0();
case 876979386: return bem_iteratorGet_0();
case -1820718044: return bem_echo_0();
case 855089063: return bem_toAny_0();
case -1718750264: return bem_tagGet_0();
case 1044385788: return bem_new_0();
case 272746094: return bem_dequeue_0();
case -1936404363: return bem_create_0();
case -485032950: return bem_print_0();
case 860480151: return bem_sizeGet_0();
case 1846641427: return bem_classNameGet_0();
case 1139687182: return bem_serializeToString_0();
case 1735596577: return bem_get_0();
case 262448459: return bem_fieldNamesGet_0();
case -1287291624: return bem_toString_0();
case 1516511629: return bem_serializeContents_0();
case -1242864862: return bem_sourceFileNameGet_0();
case -916277928: return bem_endGet_0();
case -380774728: return bem_serializationIteratorGet_0();
case -638084554: return bem_bottomGetDirect_0();
case 16703875: return bem_topGetDirect_0();
case -21452594: return bem_sizeGetDirect_0();
case 1388220454: return bem_once_0();
case 95635585: return bem_isEmptyGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1109506577: return bem_topSet_1(bevd_0);
case -1895141083: return bem_enqueue_1(bevd_0);
case 2074542901: return bem_sizeSet_1(bevd_0);
case -403688940: return bem_topSetDirect_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case -325243293: return bem_bottomSetDirect_1(bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 757423185: return bem_put_1(bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case 877117635: return bem_endSetDirect_1(bevd_0);
case 1914094785: return bem_endSet_1(bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case 497812126: return bem_sizeSetDirect_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case -847200836: return bem_def_1(bevd_0);
case -1977071910: return bem_addValue_1(bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case 477404510: return bem_undefined_1(bevd_0);
case -1770093094: return bem_bottomSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_9_5_ContainerQueue_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_9_5_ContainerQueue_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_5_ContainerQueue();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst = (BEC_2_9_5_ContainerQueue) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_5_ContainerQueue.bece_BEC_2_9_5_ContainerQueue_bevs_type;
}
}
}
