namespace be {
/* IO:File: source/build/JSEmitter.be */
public sealed class BEC_2_5_9_BuildJSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
static BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_34, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x49,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_38, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x29,0x3B};
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_64, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_65, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 17));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 38));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_70, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_71, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_72, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_73, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 23));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_76, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_77, 27));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_78, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_79, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_80, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_81, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_82 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_82, 32));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_83 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_83, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_84 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_84, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_85 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_85, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_86 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_87 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_88 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_89 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_90 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_90, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_91 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_91, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_92 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_93 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_93, 11));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_94 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_94, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_95 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_95, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_96 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_96, 11));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_97 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_97, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_98 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_98, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_99 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_100 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_101 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_102 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_103 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_104 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_105 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_106 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_107 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_108 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_109 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_110 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_110, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_111 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_111, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_112 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_113 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_113, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_114 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_114, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_115 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_115, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_116 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_117 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_118 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_119 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_120 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_120, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_121 = {0x62,0x65};
public static new BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formTarg_1(beva_node);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_invp);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(1713234403);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(582228008);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1059996242);
bevt_9_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold );
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(1397447997);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 82 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(2083701427);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 82 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(283546086);
if (bevl_first.bevi_bool) /* Line: 83 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 84 */
 else  /* Line: 85 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 86 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 88 */
 else  /* Line: 82 */ {
break;
} /* Line: 82 */
} /* Line: 82 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(1059996242);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 133 */
bevt_4_tmpany_phold = base.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_typeInstances = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
bevl_libe = bem_getLibOutput_0();
bevl_typeInstances = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_libInit = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 147 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(2083701427);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 147 */ {
bevl_clnode = bevl_ci.bemd_0(283546086);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(40, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_typeInstances.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(643127393);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1059996242);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-109602708);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(643127393);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(1059996242);
bevt_15_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold );
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(643127393);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1397447997);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(1893805844);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(643127393);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(1059996242);
bevt_26_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold );
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(643127393);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(1397447997);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(1893805844);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 162 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 163 */
} /* Line: 162 */
} /* Line: 153 */
 else  /* Line: 147 */ {
break;
} /* Line: 147 */
} /* Line: 147 */
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 171 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(2083701427);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 171 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(283546086);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 174 */
 else  /* Line: 171 */ {
break;
} /* Line: 171 */
} /* Line: 171 */
bevl_libe.bem_write_1(bevl_smap);
bevl_libe.bem_write_1(bevl_typeInstances);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 186 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 200 */
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(-20081513);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_tmpany_phold);
bevt_104_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_106_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_107_tmpany_phold);
bevt_106_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 209 */
bevl_libe.bem_write_1(bevl_main);
bem_finishLibOutput_1(bevl_libe);
bevt_108_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 215 */ {
bem_saveSyns_0();
} /* Line: 216 */
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
} /* Line: 222 */
 else  /* Line: 224 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 226 */
bevt_4_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 228 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(4879691);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(4879691);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 260 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 261 */
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 268 */
 else  /* Line: 269 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_86));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 270 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_87));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_88));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_89));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_2_4_6_TextString bem_emitNameForCall_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1394670003);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 286 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(-20081513);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 287 */
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-20081513);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_6_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_92));
bevt_0_tmpany_loop = bevp_superCalls.bem_iteratorGet_0();
while (true)
 /* Line: 294 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(2083701427);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 294 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(283546086);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-20081513);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-20081513);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 295 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
return bevl_end;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevp_allOnceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 305 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 324 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(1729983304);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_99));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_100));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(2083701427);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 329 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(283546086);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1729983304);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(-193371689);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(-61483618);
bevt_21_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 334 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 328 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_101));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_102));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_103));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_104));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_105));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_106));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_107));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_108));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_109));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_112));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_116));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_117));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_118));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_119));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_43;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_121));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 25, 26, 28, 29, 33, 33, 33, 37, 37, 37, 37, 41, 41, 41, 41, 45, 45, 45, 45, 45, 45, 45, 45, 49, 49, 49, 50, 51, 51, 51, 51, 51, 51, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 64, 64, 64, 64, 64, 64, 64, 68, 68, 68, 68, 68, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 71, 71, 71, 76, 76, 77, 79, 79, 79, 79, 81, 82, 0, 82, 82, 84, 86, 86, 88, 88, 88, 88, 88, 88, 92, 92, 92, 97, 97, 97, 98, 100, 100, 100, 100, 100, 103, 103, 103, 103, 105, 105, 105, 107, 107, 107, 107, 107, 110, 110, 110, 110, 110, 110, 112, 112, 112, 114, 119, 120, 121, 127, 127, 127, 132, 133, 133, 133, 133, 135, 135, 141, 143, 144, 145, 146, 147, 147, 149, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 153, 153, 153, 155, 155, 155, 155, 155, 155, 155, 155, 155, 161, 161, 161, 161, 161, 161, 162, 162, 162, 163, 163, 163, 163, 163, 163, 169, 171, 171, 0, 171, 171, 173, 173, 173, 173, 173, 173, 173, 173, 173, 173, 173, 173, 173, 173, 173, 173, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 178, 180, 183, 183, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 189, 190, 193, 194, 194, 195, 197, 198, 198, 198, 198, 198, 198, 198, 199, 200, 200, 200, 202, 202, 202, 202, 202, 202, 202, 202, 203, 204, 205, 206, 207, 208, 208, 208, 209, 209, 209, 211, 213, 215, 216, 222, 225, 225, 225, 226, 226, 228, 228, 233, 233, 237, 237, 237, 237, 237, 237, 241, 241, 246, 246, 246, 246, 246, 246, 246, 247, 247, 247, 247, 247, 248, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 267, 267, 268, 268, 268, 270, 270, 272, 272, 272, 272, 272, 280, 280, 280, 281, 282, 286, 286, 287, 287, 287, 287, 287, 289, 289, 289, 289, 289, 293, 294, 0, 294, 294, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 297, 304, 304, 305, 307, 308, 308, 313, 313, 321, 321, 322, 323, 323, 323, 323, 323, 324, 324, 324, 326, 326, 326, 328, 328, 328, 329, 329, 329, 329, 0, 329, 329, 330, 330, 331, 331, 331, 332, 332, 333, 333, 334, 340, 344, 345, 350, 350, 354, 354, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 379, 379, 384, 384, 388, 388, 388, 388, 388, 388, 392, 392, 396, 396, 396, 396, 396, 401, 401, 401, 401, 401, 401, 401, 406, 406, 406, 406, 406, 406, 406, 408, 410, 410, 410, 415, 415, 419, 419, 423, 423, 423, 423, 428, 428, 432, 433, 433, 434, 438, 439, 439, 440, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {178, 179, 180, 181, 182, 183, 184, 185, 191, 192, 193, 199, 200, 201, 202, 208, 209, 210, 211, 221, 222, 223, 224, 225, 226, 227, 228, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 281, 282, 283, 284, 285, 286, 287, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 347, 348, 349, 350, 351, 352, 353, 354, 355, 355, 358, 360, 362, 365, 366, 368, 369, 370, 371, 372, 373, 379, 380, 381, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 444, 445, 446, 452, 453, 454, 463, 465, 466, 467, 468, 470, 471, 596, 597, 598, 599, 600, 601, 604, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 649, 650, 651, 652, 653, 654, 662, 663, 664, 664, 667, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 707, 708, 709, 710, 711, 712, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 744, 745, 746, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 762, 763, 764, 765, 766, 767, 769, 770, 771, 773, 783, 787, 788, 793, 794, 795, 797, 798, 804, 805, 813, 814, 815, 816, 817, 818, 822, 823, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 984, 989, 990, 991, 992, 995, 996, 998, 999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1020, 1021, 1023, 1024, 1025, 1026, 1027, 1029, 1030, 1031, 1032, 1033, 1062, 1063, 1063, 1066, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1097, 1102, 1107, 1108, 1110, 1111, 1112, 1116, 1117, 1148, 1153, 1154, 1155, 1156, 1157, 1158, 1163, 1164, 1165, 1166, 1168, 1169, 1170, 1171, 1172, 1173, 1175, 1176, 1177, 1178, 1178, 1181, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1201, 1204, 1205, 1210, 1211, 1215, 1216, 1220, 1221, 1225, 1226, 1230, 1231, 1235, 1236, 1240, 1241, 1245, 1246, 1250, 1251, 1259, 1260, 1261, 1262, 1263, 1264, 1268, 1269, 1276, 1277, 1278, 1279, 1280, 1289, 1290, 1291, 1292, 1293, 1294, 1295, 1306, 1307, 1308, 1309, 1310, 1311, 1312, 1313, 1314, 1315, 1316, 1321, 1322, 1326, 1327, 1333, 1334, 1335, 1336, 1340, 1341, 1346, 1347, 1348, 1349, 1354, 1355, 1356, 1357, 1360, 1363, 1367, 1370};
/* BEGIN LINEINFO 
assign 1 17 178
new 0 17 178
assign 1 18 179
new 0 18 179
assign 1 19 180
new 0 19 180
new 1 23 181
assign 1 25 182
new 0 25 182
assign 1 26 183
new 0 26 183
assign 1 28 184
new 0 28 184
assign 1 29 185
new 0 29 185
assign 1 33 191
formTarg 1 33 191
assign 1 33 192
add 1 33 192
return 1 33 193
assign 1 37 199
formCallTarg 1 37 199
assign 1 37 200
new 0 37 200
assign 1 37 201
add 1 37 201
return 1 37 202
assign 1 41 208
formCallTarg 1 41 208
assign 1 41 209
new 0 41 209
assign 1 41 210
add 1 41 210
return 1 41 211
assign 1 45 221
new 0 45 221
assign 1 45 222
addValue 1 45 222
assign 1 45 223
secondGet 0 45 223
assign 1 45 224
formTarg 1 45 224
assign 1 45 225
addValue 1 45 225
assign 1 45 226
new 0 45 226
assign 1 45 227
addValue 1 45 227
addValue 1 45 228
assign 1 49 249
new 0 49 249
assign 1 49 250
toString 0 49 250
assign 1 49 251
add 1 49 251
incrementValue 0 50 252
assign 1 51 253
new 0 51 253
assign 1 51 254
addValue 1 51 254
assign 1 51 255
addValue 1 51 255
assign 1 51 256
new 0 51 256
assign 1 51 257
addValue 1 51 257
addValue 1 51 258
assign 1 56 259
containedGet 0 56 259
assign 1 56 260
firstGet 0 56 260
assign 1 56 261
containedGet 0 56 261
assign 1 56 262
firstGet 0 56 262
assign 1 56 263
new 0 56 263
assign 1 56 264
add 1 56 264
assign 1 56 265
new 0 56 265
assign 1 56 266
add 1 56 266
assign 1 56 267
finalAssign 4 56 267
addValue 1 56 268
assign 1 64 281
emitNameGet 0 64 281
assign 1 64 282
addValue 1 64 282
assign 1 64 283
new 0 64 283
assign 1 64 284
addValue 1 64 284
assign 1 64 285
addValue 1 64 285
assign 1 64 286
new 0 64 286
addValue 1 64 287
assign 1 68 307
emitNameGet 0 68 307
assign 1 68 308
addValue 1 68 308
assign 1 68 309
new 0 68 309
assign 1 68 310
addValue 1 68 310
addValue 1 68 311
assign 1 69 312
new 0 69 312
assign 1 69 313
addValue 1 69 313
assign 1 69 314
heldGet 0 69 314
assign 1 69 315
namepathGet 0 69 315
assign 1 69 316
getClassConfig 1 69 316
assign 1 69 317
libNameGet 0 69 317
assign 1 69 318
relEmitName 1 69 318
assign 1 69 319
addValue 1 69 319
assign 1 69 320
new 0 69 320
assign 1 69 321
addValue 1 69 321
addValue 1 69 322
assign 1 71 323
new 0 71 323
assign 1 71 324
addValue 1 71 324
addValue 1 71 325
assign 1 76 347
heldGet 0 76 347
assign 1 76 348
synGet 0 76 348
assign 1 77 349
ptyListGet 0 77 349
assign 1 79 350
emitNameGet 0 79 350
assign 1 79 351
addValue 1 79 351
assign 1 79 352
new 0 79 352
addValue 1 79 353
assign 1 81 354
new 0 81 354
assign 1 82 355
iteratorGet 0 0 355
assign 1 82 358
hasNextGet 0 82 358
assign 1 82 360
nextGet 0 82 360
assign 1 84 362
new 0 84 362
assign 1 86 365
new 0 86 365
addValue 1 86 366
assign 1 88 368
addValue 1 88 368
assign 1 88 369
new 0 88 369
assign 1 88 370
addValue 1 88 370
assign 1 88 371
nameGet 0 88 371
assign 1 88 372
addValue 1 88 372
addValue 1 88 373
assign 1 92 379
new 0 92 379
assign 1 92 380
addValue 1 92 380
addValue 1 92 381
assign 1 97 409
heldGet 0 97 409
assign 1 97 410
namepathGet 0 97 410
assign 1 97 411
getClassConfig 1 97 411
assign 1 98 412
getInitialInst 1 98 412
assign 1 100 413
emitNameGet 0 100 413
assign 1 100 414
addValue 1 100 414
assign 1 100 415
new 0 100 415
assign 1 100 416
addValue 1 100 416
addValue 1 100 417
assign 1 103 418
addValue 1 103 418
assign 1 103 419
new 0 103 419
assign 1 103 420
addValue 1 103 420
addValue 1 103 421
assign 1 105 422
new 0 105 422
assign 1 105 423
addValue 1 105 423
addValue 1 105 424
assign 1 107 425
emitNameGet 0 107 425
assign 1 107 426
addValue 1 107 426
assign 1 107 427
new 0 107 427
assign 1 107 428
addValue 1 107 428
addValue 1 107 429
assign 1 110 430
new 0 110 430
assign 1 110 431
addValue 1 110 431
assign 1 110 432
addValue 1 110 432
assign 1 110 433
new 0 110 433
assign 1 110 434
addValue 1 110 434
addValue 1 110 435
assign 1 112 436
new 0 112 436
assign 1 112 437
addValue 1 112 437
addValue 1 112 438
buildPropList 0 114 439
getCode 2 119 444
assign 1 120 445
toString 0 120 445
addValue 1 121 446
assign 1 127 452
new 0 127 452
assign 1 127 453
addValue 1 127 453
addValue 1 127 454
assign 1 132 463
isPropertyGet 0 132 463
assign 1 133 465
new 0 133 465
assign 1 133 466
nameGet 0 133 466
assign 1 133 467
add 1 133 467
return 1 133 468
assign 1 135 470
nameForVar 1 135 470
return 1 135 471
assign 1 141 596
getLibOutput 0 141 596
assign 1 143 597
new 0 143 597
assign 1 144 598
new 0 144 598
assign 1 145 599
new 0 145 599
assign 1 146 600
new 0 146 600
assign 1 147 601
iteratorGet 0 147 601
assign 1 147 604
hasNextGet 0 147 604
assign 1 149 606
nextGet 0 149 606
assign 1 151 607
new 0 151 607
assign 1 151 608
addValue 1 151 608
assign 1 151 609
addValue 1 151 609
assign 1 151 610
heldGet 0 151 610
assign 1 151 611
namepathGet 0 151 611
assign 1 151 612
toString 0 151 612
assign 1 151 613
addValue 1 151 613
assign 1 151 614
addValue 1 151 614
assign 1 151 615
new 0 151 615
assign 1 151 616
addValue 1 151 616
assign 1 151 617
heldGet 0 151 617
assign 1 151 618
namepathGet 0 151 618
assign 1 151 619
getClassConfig 1 151 619
assign 1 151 620
libNameGet 0 151 620
assign 1 151 621
relEmitName 1 151 621
assign 1 151 622
addValue 1 151 622
assign 1 151 623
new 0 151 623
assign 1 151 624
addValue 1 151 624
addValue 1 151 625
assign 1 153 626
heldGet 0 153 626
assign 1 153 627
synGet 0 153 627
assign 1 153 628
hasDefaultGet 0 153 628
assign 1 155 630
new 0 155 630
assign 1 155 631
heldGet 0 155 631
assign 1 155 632
namepathGet 0 155 632
assign 1 155 633
getClassConfig 1 155 633
assign 1 155 634
libNameGet 0 155 634
assign 1 155 635
relEmitName 1 155 635
assign 1 155 636
add 1 155 636
assign 1 155 637
new 0 155 637
assign 1 155 638
add 1 155 638
assign 1 161 639
new 0 161 639
assign 1 161 640
addValue 1 161 640
assign 1 161 641
addValue 1 161 641
assign 1 161 642
new 0 161 642
assign 1 161 643
addValue 1 161 643
addValue 1 161 644
assign 1 162 645
heldGet 0 162 645
assign 1 162 646
synGet 0 162 646
assign 1 162 647
hasDefaultGet 0 162 647
assign 1 163 649
new 0 163 649
assign 1 163 650
addValue 1 163 650
assign 1 163 651
addValue 1 163 651
assign 1 163 652
new 0 163 652
assign 1 163 653
addValue 1 163 653
addValue 1 163 654
assign 1 169 662
new 0 169 662
assign 1 171 663
keysGet 0 171 663
assign 1 171 664
iteratorGet 0 0 664
assign 1 171 667
hasNextGet 0 171 667
assign 1 171 669
nextGet 0 171 669
assign 1 173 670
new 0 173 670
assign 1 173 671
addValue 1 173 671
assign 1 173 672
new 0 173 672
assign 1 173 673
quoteGet 0 173 673
assign 1 173 674
addValue 1 173 674
assign 1 173 675
addValue 1 173 675
assign 1 173 676
new 0 173 676
assign 1 173 677
quoteGet 0 173 677
assign 1 173 678
addValue 1 173 678
assign 1 173 679
new 0 173 679
assign 1 173 680
addValue 1 173 680
assign 1 173 681
get 1 173 681
assign 1 173 682
addValue 1 173 682
assign 1 173 683
new 0 173 683
assign 1 173 684
addValue 1 173 684
addValue 1 173 685
assign 1 174 686
new 0 174 686
assign 1 174 687
addValue 1 174 687
assign 1 174 688
new 0 174 688
assign 1 174 689
quoteGet 0 174 689
assign 1 174 690
addValue 1 174 690
assign 1 174 691
addValue 1 174 691
assign 1 174 692
new 0 174 692
assign 1 174 693
quoteGet 0 174 693
assign 1 174 694
addValue 1 174 694
assign 1 174 695
new 0 174 695
assign 1 174 696
addValue 1 174 696
assign 1 174 697
get 1 174 697
assign 1 174 698
addValue 1 174 698
assign 1 174 699
new 0 174 699
assign 1 174 700
addValue 1 174 700
addValue 1 174 701
write 1 178 707
write 1 180 708
assign 1 183 709
usedLibrarysGet 0 183 709
assign 1 183 710
sizeGet 0 183 710
assign 1 183 711
new 0 183 711
assign 1 183 712
equals 1 183 717
assign 1 184 718
new 0 184 718
assign 1 184 719
addValue 1 184 719
addValue 1 184 720
assign 1 185 721
new 0 185 721
assign 1 185 722
addValue 1 185 722
addValue 1 185 723
assign 1 186 724
new 0 186 724
assign 1 186 725
addValue 1 186 725
addValue 1 186 726
write 1 189 728
write 1 190 729
assign 1 193 730
new 0 193 730
assign 1 194 731
mainNameGet 0 194 731
fromString 1 194 732
assign 1 195 733
getClassConfig 1 195 733
assign 1 197 734
new 0 197 734
assign 1 198 735
new 0 198 735
assign 1 198 736
addValue 1 198 736
assign 1 198 737
fullEmitNameGet 0 198 737
assign 1 198 738
addValue 1 198 738
assign 1 198 739
new 0 198 739
assign 1 198 740
addValue 1 198 740
addValue 1 198 741
assign 1 199 742
ownProcessGet 0 199 742
assign 1 200 744
new 0 200 744
assign 1 200 745
addValue 1 200 745
addValue 1 200 746
assign 1 202 748
new 0 202 748
assign 1 202 749
addValue 1 202 749
assign 1 202 750
outputPlatformGet 0 202 750
assign 1 202 751
nameGet 0 202 751
assign 1 202 752
addValue 1 202 752
assign 1 202 753
new 0 202 753
assign 1 202 754
addValue 1 202 754
addValue 1 202 755
write 1 203 756
assign 1 204 757
new 0 204 757
write 1 205 758
write 1 206 759
assign 1 207 760
ownProcessGet 0 207 760
assign 1 208 762
new 0 208 762
assign 1 208 763
addValue 1 208 763
addValue 1 208 764
assign 1 209 765
new 0 209 765
assign 1 209 766
addValue 1 209 766
addValue 1 209 767
write 1 211 769
finishLibOutput 1 213 770
assign 1 215 771
saveSynsGet 0 215 771
saveSyns 0 216 773
assign 1 222 783
isPropertyGet 0 222 783
assign 1 225 787
isArgGet 0 225 787
assign 1 225 788
not 0 225 793
assign 1 226 794
new 0 226 794
addValue 1 226 795
assign 1 228 797
nameForVar 1 228 797
addValue 1 228 798
assign 1 233 804
new 0 233 804
return 1 233 805
assign 1 237 813
new 0 237 813
assign 1 237 814
add 1 237 814
assign 1 237 815
new 0 237 815
assign 1 237 816
add 1 237 816
assign 1 237 817
add 1 237 817
return 1 237 818
assign 1 241 822
new 0 241 822
return 1 241 823
assign 1 246 837
emitNameGet 0 246 837
assign 1 246 838
new 0 246 838
assign 1 246 839
add 1 246 839
assign 1 246 840
add 1 246 840
assign 1 246 841
new 0 246 841
assign 1 246 842
add 1 246 842
assign 1 246 843
addValue 1 246 843
assign 1 247 844
emitNameGet 0 247 844
assign 1 247 845
add 1 247 845
assign 1 247 846
new 0 247 846
assign 1 247 847
add 1 247 847
assign 1 247 848
addValue 1 247 848
return 1 248 849
assign 1 252 863
new 0 252 863
assign 1 252 864
libNameGet 0 252 864
assign 1 252 865
relEmitName 1 252 865
assign 1 252 866
add 1 252 866
assign 1 252 867
new 0 252 867
assign 1 252 868
add 1 252 868
assign 1 252 869
heldGet 0 252 869
assign 1 252 870
literalValueGet 0 252 870
assign 1 252 871
add 1 252 871
assign 1 252 872
new 0 252 872
assign 1 252 873
add 1 252 873
return 1 252 874
assign 1 256 888
new 0 256 888
assign 1 256 889
libNameGet 0 256 889
assign 1 256 890
relEmitName 1 256 890
assign 1 256 891
add 1 256 891
assign 1 256 892
new 0 256 892
assign 1 256 893
add 1 256 893
assign 1 256 894
heldGet 0 256 894
assign 1 256 895
literalValueGet 0 256 895
assign 1 256 896
add 1 256 896
assign 1 256 897
new 0 256 897
assign 1 256 898
add 1 256 898
return 1 256 899
assign 1 261 935
new 0 261 935
assign 1 261 936
libNameGet 0 261 936
assign 1 261 937
relEmitName 1 261 937
assign 1 261 938
add 1 261 938
assign 1 261 939
new 0 261 939
assign 1 261 940
add 1 261 940
assign 1 261 941
emitNameGet 0 261 941
assign 1 261 942
add 1 261 942
assign 1 261 943
new 0 261 943
assign 1 261 944
add 1 261 944
assign 1 261 945
add 1 261 945
assign 1 261 946
new 0 261 946
assign 1 261 947
add 1 261 947
assign 1 261 948
add 1 261 948
assign 1 261 949
new 0 261 949
assign 1 261 950
add 1 261 950
return 1 261 951
assign 1 263 953
new 0 263 953
assign 1 263 954
libNameGet 0 263 954
assign 1 263 955
relEmitName 1 263 955
assign 1 263 956
add 1 263 956
assign 1 263 957
new 0 263 957
assign 1 263 958
add 1 263 958
assign 1 263 959
emitNameGet 0 263 959
assign 1 263 960
add 1 263 960
assign 1 263 961
new 0 263 961
assign 1 263 962
add 1 263 962
assign 1 263 963
add 1 263 963
assign 1 263 964
new 0 263 964
assign 1 263 965
add 1 263 965
assign 1 263 966
add 1 263 966
assign 1 263 967
new 0 263 967
assign 1 263 968
add 1 263 968
return 1 263 969
assign 1 267 984
def 1 267 989
assign 1 268 990
libNameGet 0 268 990
assign 1 268 991
relEmitName 1 268 991
assign 1 268 992
extend 1 268 992
assign 1 270 995
new 0 270 995
assign 1 270 996
extend 1 270 996
assign 1 272 998
new 0 272 998
assign 1 272 999
emitNameGet 0 272 999
assign 1 272 1000
addValue 1 272 1000
assign 1 272 1001
new 0 272 1001
assign 1 272 1002
addValue 1 272 1002
assign 1 280 1003
new 0 280 1003
assign 1 280 1004
addValue 1 280 1004
addValue 1 280 1005
addValue 1 281 1006
return 1 282 1007
assign 1 286 1020
heldGet 0 286 1020
assign 1 286 1021
superCallGet 0 286 1021
assign 1 287 1023
new 0 287 1023
assign 1 287 1024
heldGet 0 287 1024
assign 1 287 1025
nameGet 0 287 1025
assign 1 287 1026
add 1 287 1026
return 1 287 1027
assign 1 289 1029
new 0 289 1029
assign 1 289 1030
heldGet 0 289 1030
assign 1 289 1031
nameGet 0 289 1031
assign 1 289 1032
add 1 289 1032
return 1 289 1033
assign 1 293 1062
new 0 293 1062
assign 1 294 1063
iteratorGet 0 0 1063
assign 1 294 1066
hasNextGet 0 294 1066
assign 1 294 1068
nextGet 0 294 1068
assign 1 295 1069
emitNameGet 0 295 1069
assign 1 295 1070
new 0 295 1070
assign 1 295 1071
add 1 295 1071
assign 1 295 1072
new 0 295 1072
assign 1 295 1073
add 1 295 1073
assign 1 295 1074
heldGet 0 295 1074
assign 1 295 1075
nameGet 0 295 1075
assign 1 295 1076
add 1 295 1076
assign 1 295 1077
new 0 295 1077
assign 1 295 1078
add 1 295 1078
assign 1 295 1079
emitNameGet 0 295 1079
assign 1 295 1080
add 1 295 1080
assign 1 295 1081
new 0 295 1081
assign 1 295 1082
add 1 295 1082
assign 1 295 1083
new 0 295 1083
assign 1 295 1084
add 1 295 1084
assign 1 295 1085
heldGet 0 295 1085
assign 1 295 1086
nameGet 0 295 1086
assign 1 295 1087
add 1 295 1087
assign 1 295 1088
new 0 295 1088
assign 1 295 1089
add 1 295 1089
assign 1 295 1090
add 1 295 1090
addValue 1 295 1091
return 1 297 1097
assign 1 304 1102
undef 1 304 1107
assign 1 305 1108
new 0 305 1108
addValue 1 307 1110
assign 1 308 1111
new 0 308 1111
return 1 308 1112
assign 1 313 1116
getLibOutput 0 313 1116
return 1 313 1117
assign 1 321 1148
undef 1 321 1153
assign 1 322 1154
new 0 322 1154
assign 1 323 1155
parentGet 0 323 1155
assign 1 323 1156
fileGet 0 323 1156
assign 1 323 1157
existsGet 0 323 1157
assign 1 323 1158
not 0 323 1163
assign 1 324 1164
parentGet 0 324 1164
assign 1 324 1165
fileGet 0 324 1165
makeDirs 0 324 1166
assign 1 326 1168
fileGet 0 326 1168
assign 1 326 1169
writerGet 0 326 1169
assign 1 326 1170
open 0 326 1170
assign 1 328 1171
paramsGet 0 328 1171
assign 1 328 1172
new 0 328 1172
assign 1 328 1173
has 1 328 1173
assign 1 329 1175
paramsGet 0 329 1175
assign 1 329 1176
new 0 329 1176
assign 1 329 1177
get 1 329 1177
assign 1 329 1178
iteratorGet 0 0 1178
assign 1 329 1181
hasNextGet 0 329 1181
assign 1 329 1183
nextGet 0 329 1183
assign 1 330 1184
apNew 1 330 1184
assign 1 330 1185
fileGet 0 330 1185
assign 1 331 1186
readerGet 0 331 1186
assign 1 331 1187
open 0 331 1187
assign 1 331 1188
readString 0 331 1188
assign 1 332 1189
readerGet 0 332 1189
close 0 332 1190
assign 1 333 1191
countLines 1 333 1191
addValue 1 333 1192
write 1 334 1193
return 1 340 1201
close 0 344 1204
assign 1 345 1205
assign 1 350 1210
new 0 350 1210
return 1 350 1211
assign 1 354 1215
new 0 354 1215
return 1 354 1216
assign 1 358 1220
new 0 358 1220
return 1 358 1221
assign 1 362 1225
new 0 362 1225
return 1 362 1226
assign 1 366 1230
new 0 366 1230
return 1 366 1231
assign 1 370 1235
new 0 370 1235
return 1 370 1236
assign 1 374 1240
new 0 374 1240
return 1 374 1241
assign 1 379 1245
new 0 379 1245
return 1 379 1246
assign 1 384 1250
new 0 384 1250
return 1 384 1251
assign 1 388 1259
new 0 388 1259
assign 1 388 1260
add 1 388 1260
assign 1 388 1261
new 0 388 1261
assign 1 388 1262
add 1 388 1262
assign 1 388 1263
add 1 388 1263
return 1 388 1264
assign 1 392 1268
new 0 392 1268
return 1 392 1269
assign 1 396 1276
libNameGet 0 396 1276
assign 1 396 1277
relEmitName 1 396 1277
assign 1 396 1278
new 0 396 1278
assign 1 396 1279
add 1 396 1279
return 1 396 1280
assign 1 401 1289
emitNameGet 0 401 1289
assign 1 401 1290
new 0 401 1290
assign 1 401 1291
add 1 401 1291
assign 1 401 1292
new 0 401 1292
assign 1 401 1293
add 1 401 1293
assign 1 401 1294
add 1 401 1294
return 1 401 1295
assign 1 406 1306
emitNameGet 0 406 1306
assign 1 406 1307
addValue 1 406 1307
assign 1 406 1308
new 0 406 1308
assign 1 406 1309
addValue 1 406 1309
assign 1 406 1310
addValue 1 406 1310
assign 1 406 1311
new 0 406 1311
addValue 1 406 1312
addValue 1 408 1313
assign 1 410 1314
new 0 410 1314
assign 1 410 1315
addValue 1 410 1315
addValue 1 410 1316
assign 1 415 1321
new 0 415 1321
return 1 415 1322
assign 1 419 1326
new 0 419 1326
return 1 419 1327
assign 1 423 1333
new 0 423 1333
assign 1 423 1334
add 1 423 1334
assign 1 423 1335
add 1 423 1335
return 1 423 1336
assign 1 428 1340
new 0 428 1340
return 1 428 1341
assign 1 432 1346
getClassConfig 1 432 1346
assign 1 433 1347
fullEmitNameGet 0 433 1347
emitNameSet 1 433 1348
return 1 434 1349
assign 1 438 1354
getLocalClassConfig 1 438 1354
assign 1 439 1355
fullEmitNameGet 0 439 1355
emitNameSet 1 439 1356
return 1 440 1357
return 1 0 1360
assign 1 0 1363
return 1 0 1367
assign 1 0 1370
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1503484208: return bem_instanceNotEqualGet_0();
case -231629009: return bem_methodCallsGet_0();
case -1707168997: return bem_buildCreate_0();
case -2046784533: return bem_echo_0();
case -1877971222: return bem_trueValueGet_0();
case -2056440002: return bem_fullLibEmitNameGet_0();
case -537857901: return bem_iteratorGet_0();
case 1249959235: return bem_fileExtGet_0();
case -1521916035: return bem_boolNpGet_0();
case -1976511455: return bem_libEmitPathGet_0();
case -1470298977: return bem_qGet_0();
case 262158621: return bem_returnTypeGet_0();
case -1732022465: return bem_classCallsGet_0();
case 717158289: return bem_fieldIteratorGet_0();
case -684212702: return bem_invpGet_0();
case 1067577432: return bem_falseValueGet_0();
case -593331488: return bem_onceCountGet_0();
case -173186399: return bem_toAny_0();
case 982670532: return bem_useDynMethodsGet_0();
case 1265204951: return bem_nlGet_0();
case 675544141: return bem_buildInitial_0();
case -2036656062: return bem_lastMethodBodyLinesGet_0();
case 814639632: return bem_new_0();
case 242412997: return bem_superCallsGet_0();
case -1088042789: return bem_classEndGet_0();
case 1973131926: return bem_serializeToString_0();
case 34035866: return bem_classNameGet_0();
case -125946934: return bem_serializeContents_0();
case 1819860805: return bem_lineCountGet_0();
case 974730599: return bem_allOnceDecsGet_0();
case -506929281: return bem_emitLangGet_0();
case -448175942: return bem_methodsGet_0();
case -167610447: return bem_mnodeGet_0();
case -2089907154: return bem_create_0();
case -268247078: return bem_maxSpillArgsLenGet_0();
case 567511740: return bem_onceDecsGet_0();
case 2035877017: return bem_spropDecGet_0();
case -711989776: return bem_maxDynArgsGet_0();
case -91555152: return bem_methodCatchGet_0();
case -65469198: return bem_instOfGet_0();
case 1066959966: return bem_synEmitPathGet_0();
case -2129255989: return bem_hashGet_0();
case -52063515: return bem_lastMethodsLinesGet_0();
case 648165913: return bem_print_0();
case -1488537594: return bem_buildPropList_0();
case -860519417: return bem_propertyDecsGet_0();
case -109602708: return bem_toString_0();
case -750932870: return bem_overrideMtdDecGet_0();
case 299265439: return bem_endNs_0();
case -1801022076: return bem_mainEndGet_0();
case -78785953: return bem_scvpGet_0();
case 1511689560: return bem_doEmit_0();
case 1597303537: return bem_ccCacheGet_0();
case -360332104: return bem_nativeCSlotsGet_0();
case 2142243846: return bem_runtimeInitGet_0();
case 586793704: return bem_lastCallGet_0();
case -851007084: return bem_lastMethodsSizeGet_0();
case -1462205898: return bem_coanyiantReturnsGet_0();
case 2093378029: return bem_stringNpGet_0();
case 477041164: return bem_classConfGet_0();
case 1688910336: return bem_mainStartGet_0();
case 1350896394: return bem_inFilePathedGet_0();
case 250550410: return bem_csynGet_0();
case -2049991627: return bem_once_0();
case 1905184732: return bem_lastMethodBodySizeGet_0();
case 1536433852: return bem_getClassOutput_0();
case -1556753014: return bem_buildGet_0();
case 790512409: return bem_smnlcsGet_0();
case -91772231: return bem_constGet_0();
case 99641680: return bem_sourceFileNameGet_0();
case 1414766518: return bem_cnodeGet_0();
case 2036051133: return bem_tagGet_0();
case -1407415064: return bem_buildClassInfo_0();
case -2081773815: return bem_dynMethodsGet_0();
case -759830880: return bem_intNpGet_0();
case -1723144094: return bem_parentConfGet_0();
case 72890251: return bem_objectCcGet_0();
case -263538214: return bem_propDecGet_0();
case 2101176954: return bem_saveSyns_0();
case 2025472028: return bem_nameToIdGet_0();
case 2082586952: return bem_mainInClassGet_0();
case 239879194: return bem_preClassGet_0();
case -1987363705: return bem_libEmitNameGet_0();
case -937763332: return bem_ccMethodsGet_0();
case 432735873: return bem_deserializeClassNameGet_0();
case -1762064119: return bem_shlibeGet_0();
case -2106654919: return bem_transGet_0();
case 1688142120: return bem_classesInDepthOrderGet_0();
case -1398257774: return bem_boolCcGet_0();
case -1536037533: return bem_mainOutsideNsGet_0();
case -1653307562: return bem_serializationIteratorGet_0();
case 115915646: return bem_callNamesGet_0();
case -1645805502: return bem_beginNs_0();
case 1366168343: return bem_objectNpGet_0();
case 1652623656: return bem_boolTypeGet_0();
case 1412767150: return bem_floatNpGet_0();
case -1678256255: return bem_methodBodyGet_0();
case 529883642: return bem_classEmitsGet_0();
case 2048361265: return bem_many_0();
case -1067206556: return bem_nullValueGet_0();
case -53928550: return bem_smnlecsGet_0();
case 103198629: return bem_instanceEqualGet_0();
case -1925536545: return bem_baseMtdDecGet_0();
case -863950628: return bem_idToNameGet_0();
case 1761088319: return bem_initialDecGet_0();
case -326152805: return bem_copy_0();
case 127581635: return bem_getLibOutput_0();
case 2071176550: return bem_msynGet_0();
case 1434034732: return bem_afterCast_0();
case -1495779104: return bem_exceptDecGet_0();
case 561936341: return bem_randGet_0();
case -498367570: return bem_ntypesGet_0();
case -1651557160: return bem_superNameGet_0();
case -872390382: return bem_baseSmtdDecGet_0();
case -1016545624: return bem_emitLib_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1342987010: return bem_intNpSet_1(bevd_0);
case 345185281: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 15663479: return bem_onceDecsSet_1(bevd_0);
case -1179462483: return bem_nativeCSlotsSet_1(bevd_0);
case 1320850171: return bem_qSet_1(bevd_0);
case -1166370542: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 569199667: return bem_undefined_1(bevd_0);
case -152093488: return bem_ccMethodsSet_1(bevd_0);
case 1121176884: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -1979054185: return bem_instanceNotEqualSet_1(bevd_0);
case 1897699399: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case 1102414111: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -691602395: return bem_onceCountSet_1(bevd_0);
case 1273545128: return bem_stringNpSet_1(bevd_0);
case -67423391: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -1634298187: return bem_end_1(bevd_0);
case -1535387660: return bem_classConfSet_1(bevd_0);
case -20038017: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -569882115: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 971676873: return bem_randSet_1(bevd_0);
case 1402214618: return bem_superCallsSet_1(bevd_0);
case 20627805: return bem_libEmitPathSet_1(bevd_0);
case -692186155: return bem_trueValueSet_1(bevd_0);
case 291302174: return bem_nameToIdSet_1(bevd_0);
case 549239575: return bem_otherType_1(bevd_0);
case -1421894349: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1887120745: return bem_sameObject_1(bevd_0);
case 1290400575: return bem_undef_1(bevd_0);
case 262136334: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -291644992: return bem_lastMethodsSizeSet_1(bevd_0);
case -420585939: return bem_equals_1(bevd_0);
case -837309337: return bem_instanceEqualSet_1(bevd_0);
case -206409898: return bem_methodBodySet_1(bevd_0);
case -954152305: return bem_objectCcSet_1(bevd_0);
case 1001778547: return bem_callNamesSet_1(bevd_0);
case -323953622: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 237477492: return bem_invpSet_1(bevd_0);
case -1052976456: return bem_begin_1(bevd_0);
case 1637678954: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -2068040715: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1038696049: return bem_transSet_1(bevd_0);
case -2096802344: return bem_smnlcsSet_1(bevd_0);
case 1093363744: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case -24051681: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 38983543: return bem_idToNameSet_1(bevd_0);
case 1940516897: return bem_sameClass_1(bevd_0);
case 1249371582: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 1371169171: return bem_preClassSet_1(bevd_0);
case -1241357762: return bem_dynMethodsSet_1(bevd_0);
case 586466215: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -258046467: return bem_floatNpSet_1(bevd_0);
case 181207960: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1340333252: return bem_ccCacheSet_1(bevd_0);
case 1977925330: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case -1442729113: return bem_cnodeSet_1(bevd_0);
case -1087214764: return bem_inFilePathedSet_1(bevd_0);
case -1980404261: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 1114510022: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 755365358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1957594462: return bem_ntypesSet_1(bevd_0);
case 668704089: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 2124446865: return bem_objectNpSet_1(bevd_0);
case 2050633623: return bem_propertyDecsSet_1(bevd_0);
case -744292434: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 217239677: return bem_emitLangSet_1(bevd_0);
case -1840995531: return bem_classesInDepthOrderSet_1(bevd_0);
case -1242762805: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1725813495: return bem_buildSet_1(bevd_0);
case 209247596: return bem_methodCatchSet_1(bevd_0);
case 634346029: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case -1692946273: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 1359485455: return bem_csynSet_1(bevd_0);
case 1523133504: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 2142188146: return bem_lastMethodBodySizeSet_1(bevd_0);
case 902325492: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -241371051: return bem_scvpSet_1(bevd_0);
case -1455830815: return bem_smnlecsSet_1(bevd_0);
case -1220227899: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -853375001: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1587074662: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1996549809: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 630759147: return bem_returnTypeSet_1(bevd_0);
case 1646332760: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1453009437: return bem_exceptDecSet_1(bevd_0);
case -1752920764: return bem_methodsSet_1(bevd_0);
case -1106126350: return bem_shlibeSet_1(bevd_0);
case 1250199733: return bem_fileExtSet_1(bevd_0);
case -1629045646: return bem_classEmitsSet_1(bevd_0);
case 1359155512: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -587630873: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 2020721234: return bem_boolNpSet_1(bevd_0);
case 1884868747: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 1795432183: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 484096285: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1045464186: return bem_allOnceDecsSet_1(bevd_0);
case 786369211: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 1051082549: return bem_synEmitPathSet_1(bevd_0);
case 2141765988: return bem_lastMethodsLinesSet_1(bevd_0);
case -1039512526: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -169401475: return bem_otherClass_1(bevd_0);
case 1994260011: return bem_nlSet_1(bevd_0);
case -160591275: return bem_maxDynArgsSet_1(bevd_0);
case 478132461: return bem_fullLibEmitNameSet_1(bevd_0);
case -1854724553: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -908917157: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -15986989: return bem_lastCallSet_1(bevd_0);
case 1226495395: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1342415374: return bem_constSet_1(bevd_0);
case 991182700: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1611450524: return bem_instOfSet_1(bevd_0);
case -1369439027: return bem_notEquals_1(bevd_0);
case -2031862922: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 496157614: return bem_boolCcSet_1(bevd_0);
case -491345013: return bem_sameType_1(bevd_0);
case -1808237618: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 2126649322: return bem_mnodeSet_1(bevd_0);
case -143017218: return bem_copyTo_1(bevd_0);
case 1341260987: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case -1785998917: return bem_falseValueSet_1(bevd_0);
case -1091318965: return bem_defined_1(bevd_0);
case -815875225: return bem_classCallsSet_1(bevd_0);
case 161057711: return bem_libEmitNameSet_1(bevd_0);
case -774932373: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case 1201802784: return bem_nullValueSet_1(bevd_0);
case -1673221667: return bem_parentConfSet_1(bevd_0);
case -897961761: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -64660111: return bem_lineCountSet_1(bevd_0);
case -1528518624: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case -645976199: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -1393267925: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1492255674: return bem_def_1(bevd_0);
case -96286522: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1003410755: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 5463926: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 922062179: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -140353519: return bem_methodCallsSet_1(bevd_0);
case 1162113479: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 207708785: return bem_msynSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1008056884: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1549801515: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1792455468: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -888732535: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 1279097513: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1151786117: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1823742306: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -529079079: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 55863465: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 466148991: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1682274963: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case -50371904: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 967378502: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1422666964: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -18185071: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 951303004: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1770740990: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1294864810: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case 1208056759: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1111196990: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 251127387: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 126250000: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -777564197: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1604232586: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case 1492297133: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -2128692013: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
}
}
