namespace be {
/* IO:File: source/build/JSEmitter.be */
public sealed class BEC_2_5_9_BuildJSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
static BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_34, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_38, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_39, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x29,0x3B};
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_64, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_65, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 17));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x28,0x29,0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 38));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_70, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_71, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_72, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_73, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 23));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_76, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_77, 27));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_78, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_79, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_80 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_80, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_81 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_81, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_82 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_82, 32));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_83 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_83, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_84 = {0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_84, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_85 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_85, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_86 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_87 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_88 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_89 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_90 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_90, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_91 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_91, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_92 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_93 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_93, 11));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_94 = {0x62,0x65,0x6D,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_94, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_95 = {0x20,0x3D,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_95, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_96 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_96, 11));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_97 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_97, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_98 = {0x3B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_98, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_99 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_100 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_101 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_102 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_103 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_104 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_105 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_106 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_107 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_108 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_109 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_110 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_111 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_111, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_112 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_112, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_113 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_114 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_114, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_115 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_115, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_116 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_116, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_117 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_118 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_119 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_120 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_121 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_121, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_122 = {0x62,0x65};
public static new BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static new BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formTarg_1(beva_node);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_invp);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-310442460);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-1119301627);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1249959892);
bevt_9_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold );
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(306370764);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 82 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 82 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(901258413);
if (bevl_first.bevi_bool) /* Line: 83 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 84 */
 else  /* Line: 85 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 86 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 88 */
 else  /* Line: 82 */ {
break;
} /* Line: 82 */
} /* Line: 82 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1249959892);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_31));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 132 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 133 */
bevt_4_tmpany_phold = base.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 149 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 149 */ {
bevl_clnode = bevl_ci.bemd_0(901258413);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_35));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(967076058);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-1249959892);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1028683886);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_36));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(967076058);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(-1249959892);
bevt_15_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold );
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(967076058);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(306370764);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(-2120440864);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 155 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(967076058);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-1249959892);
bevt_26_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold );
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(967076058);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(306370764);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(-2120440864);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 164 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 165 */
} /* Line: 164 */
} /* Line: 155 */
 else  /* Line: 149 */ {
break;
} /* Line: 149 */
} /* Line: 149 */
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 173 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 173 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(901258413);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 176 */
 else  /* Line: 173 */ {
break;
} /* Line: 173 */
} /* Line: 173 */
bevl_libe.bem_write_1(bevl_smap);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 183 */ {
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 186 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_53));
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_54));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 199 */ {
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_56));
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 200 */
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_57));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(1724631906);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_58));
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_59));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 207 */ {
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_60));
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_tmpany_phold);
bevt_104_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_61));
bevt_106_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_107_tmpany_phold);
bevt_106_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 209 */
bevl_libe.bem_write_1(bevl_main);
bem_finishLibOutput_1(bevl_libe);
bevt_108_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 215 */ {
bem_saveSyns_0();
} /* Line: 216 */
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_2(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 222 */ {
} /* Line: 222 */
 else  /* Line: 224 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_62));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 226 */
bevt_4_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 228 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_66));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1505320625);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_2(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1505320625);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 260 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 261 */
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 267 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 268 */
 else  /* Line: 269 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_86));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 270 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_87));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_88));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_89));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_2_4_6_TextString bem_emitNameForCall_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-2145131392);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 286 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
bevt_5_tmpany_phold = beva_node.bem_heldGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_0(1724631906);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
return bevt_2_tmpany_phold;
} /* Line: 287 */
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1724631906);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
return bevt_6_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
BEC_2_5_4_BuildNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_92));
bevt_0_tmpany_loop = bevp_superCalls.bem_iteratorGet_0();
while (true)
 /* Line: 294 */ {
bevt_1_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 294 */ {
bevl_node = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(901258413);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_16_tmpany_phold = bevl_node.bem_heldGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(1724631906);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_17_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_17_tmpany_phold);
bevt_18_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_18_tmpany_phold);
bevt_19_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_19_tmpany_phold);
bevt_20_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_20_tmpany_phold);
bevt_22_tmpany_phold = bevl_node.bem_heldGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(1724631906);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_23_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_nl);
bevl_end.bem_addValue_1(bevt_2_tmpany_phold);
} /* Line: 295 */
 else  /* Line: 294 */ {
break;
} /* Line: 294 */
} /* Line: 294 */
return bevl_end;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevp_allOnceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 305 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 324 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(-998358226);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_99));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_100));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 329 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(901258413);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-998358226);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(-683252426);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(-1721645741);
bevt_21_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 334 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 328 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_101));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_102));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_103));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_104));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_105));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_106));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_107));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_108));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_109));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_110));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_113));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_117));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_118));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_119));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_120));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_43;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_122));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {17, 18, 19, 23, 25, 26, 28, 29, 33, 33, 33, 37, 37, 37, 37, 41, 41, 41, 41, 45, 45, 45, 45, 45, 45, 45, 45, 49, 49, 49, 50, 51, 51, 51, 51, 51, 51, 56, 56, 56, 56, 56, 56, 56, 56, 56, 56, 64, 64, 64, 64, 64, 64, 64, 68, 68, 68, 68, 68, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 71, 71, 71, 76, 76, 77, 79, 79, 79, 79, 81, 82, 0, 82, 82, 84, 86, 86, 88, 88, 88, 88, 88, 88, 92, 92, 92, 97, 97, 97, 98, 100, 100, 100, 100, 100, 103, 103, 103, 103, 105, 105, 105, 107, 107, 107, 107, 107, 110, 110, 110, 110, 110, 110, 112, 112, 112, 114, 119, 120, 121, 127, 127, 127, 132, 133, 133, 133, 133, 135, 135, 144, 146, 147, 148, 149, 149, 151, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 153, 155, 155, 155, 157, 157, 157, 157, 157, 157, 157, 157, 157, 163, 163, 163, 163, 163, 163, 164, 164, 164, 165, 165, 165, 165, 165, 165, 171, 173, 173, 0, 173, 173, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 176, 180, 183, 183, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 189, 190, 193, 194, 194, 195, 197, 198, 198, 198, 198, 198, 198, 198, 199, 200, 200, 200, 202, 202, 202, 202, 202, 202, 202, 202, 203, 204, 205, 206, 207, 208, 208, 208, 209, 209, 209, 211, 213, 215, 216, 222, 225, 225, 225, 226, 226, 228, 228, 233, 233, 237, 237, 237, 237, 237, 237, 241, 241, 246, 246, 246, 246, 246, 246, 246, 247, 247, 247, 247, 247, 248, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 252, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 263, 267, 267, 268, 268, 268, 270, 270, 272, 272, 272, 272, 272, 280, 280, 280, 281, 282, 286, 286, 287, 287, 287, 287, 287, 289, 289, 289, 289, 289, 293, 294, 0, 294, 294, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 295, 297, 304, 304, 305, 307, 308, 308, 313, 313, 321, 321, 322, 323, 323, 323, 323, 323, 324, 324, 324, 326, 326, 326, 328, 328, 328, 329, 329, 329, 329, 0, 329, 329, 330, 330, 331, 331, 331, 332, 332, 333, 333, 334, 340, 344, 345, 350, 350, 354, 354, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 379, 379, 385, 385, 390, 390, 394, 394, 394, 394, 394, 394, 398, 398, 402, 402, 402, 402, 402, 407, 407, 407, 407, 407, 407, 407, 412, 412, 412, 412, 412, 412, 412, 414, 416, 416, 416, 421, 421, 425, 425, 429, 429, 429, 429, 434, 434, 438, 439, 439, 440, 444, 445, 445, 446, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {182, 183, 184, 185, 186, 187, 188, 189, 195, 196, 197, 203, 204, 205, 206, 212, 213, 214, 215, 225, 226, 227, 228, 229, 230, 231, 232, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 285, 286, 287, 288, 289, 290, 291, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 351, 352, 353, 354, 355, 356, 357, 358, 359, 359, 362, 364, 366, 369, 370, 372, 373, 374, 375, 376, 377, 383, 384, 385, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 448, 449, 450, 456, 457, 458, 467, 469, 470, 471, 472, 474, 475, 602, 603, 604, 605, 606, 609, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 654, 655, 656, 657, 658, 659, 667, 668, 669, 669, 672, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 712, 713, 714, 715, 716, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 748, 749, 750, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 766, 767, 768, 769, 770, 771, 773, 774, 775, 777, 787, 791, 792, 797, 798, 799, 801, 802, 808, 809, 817, 818, 819, 820, 821, 822, 826, 827, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 988, 993, 994, 995, 996, 999, 1000, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1024, 1025, 1027, 1028, 1029, 1030, 1031, 1033, 1034, 1035, 1036, 1037, 1066, 1067, 1067, 1070, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1101, 1106, 1111, 1112, 1114, 1115, 1116, 1120, 1121, 1152, 1157, 1158, 1159, 1160, 1161, 1162, 1167, 1168, 1169, 1170, 1172, 1173, 1174, 1175, 1176, 1177, 1179, 1180, 1181, 1182, 1182, 1185, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1205, 1208, 1209, 1214, 1215, 1219, 1220, 1224, 1225, 1229, 1230, 1234, 1235, 1239, 1240, 1244, 1245, 1249, 1250, 1254, 1255, 1259, 1260, 1268, 1269, 1270, 1271, 1272, 1273, 1277, 1278, 1285, 1286, 1287, 1288, 1289, 1298, 1299, 1300, 1301, 1302, 1303, 1304, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323, 1324, 1325, 1330, 1331, 1335, 1336, 1342, 1343, 1344, 1345, 1349, 1350, 1355, 1356, 1357, 1358, 1363, 1364, 1365, 1366, 1369, 1372, 1376, 1379};
/* BEGIN LINEINFO 
assign 1 17 182
new 0 17 182
assign 1 18 183
new 0 18 183
assign 1 19 184
new 0 19 184
new 1 23 185
assign 1 25 186
new 0 25 186
assign 1 26 187
new 0 26 187
assign 1 28 188
new 0 28 188
assign 1 29 189
new 0 29 189
assign 1 33 195
formTarg 1 33 195
assign 1 33 196
add 1 33 196
return 1 33 197
assign 1 37 203
formCallTarg 1 37 203
assign 1 37 204
new 0 37 204
assign 1 37 205
add 1 37 205
return 1 37 206
assign 1 41 212
formCallTarg 1 41 212
assign 1 41 213
new 0 41 213
assign 1 41 214
add 1 41 214
return 1 41 215
assign 1 45 225
new 0 45 225
assign 1 45 226
addValue 1 45 226
assign 1 45 227
secondGet 0 45 227
assign 1 45 228
formTarg 1 45 228
assign 1 45 229
addValue 1 45 229
assign 1 45 230
new 0 45 230
assign 1 45 231
addValue 1 45 231
addValue 1 45 232
assign 1 49 253
new 0 49 253
assign 1 49 254
toString 0 49 254
assign 1 49 255
add 1 49 255
incrementValue 0 50 256
assign 1 51 257
new 0 51 257
assign 1 51 258
addValue 1 51 258
assign 1 51 259
addValue 1 51 259
assign 1 51 260
new 0 51 260
assign 1 51 261
addValue 1 51 261
addValue 1 51 262
assign 1 56 263
containedGet 0 56 263
assign 1 56 264
firstGet 0 56 264
assign 1 56 265
containedGet 0 56 265
assign 1 56 266
firstGet 0 56 266
assign 1 56 267
new 0 56 267
assign 1 56 268
add 1 56 268
assign 1 56 269
new 0 56 269
assign 1 56 270
add 1 56 270
assign 1 56 271
finalAssign 4 56 271
addValue 1 56 272
assign 1 64 285
emitNameGet 0 64 285
assign 1 64 286
addValue 1 64 286
assign 1 64 287
new 0 64 287
assign 1 64 288
addValue 1 64 288
assign 1 64 289
addValue 1 64 289
assign 1 64 290
new 0 64 290
addValue 1 64 291
assign 1 68 311
emitNameGet 0 68 311
assign 1 68 312
addValue 1 68 312
assign 1 68 313
new 0 68 313
assign 1 68 314
addValue 1 68 314
addValue 1 68 315
assign 1 69 316
new 0 69 316
assign 1 69 317
addValue 1 69 317
assign 1 69 318
heldGet 0 69 318
assign 1 69 319
namepathGet 0 69 319
assign 1 69 320
getClassConfig 1 69 320
assign 1 69 321
libNameGet 0 69 321
assign 1 69 322
relEmitName 1 69 322
assign 1 69 323
addValue 1 69 323
assign 1 69 324
new 0 69 324
assign 1 69 325
addValue 1 69 325
addValue 1 69 326
assign 1 71 327
new 0 71 327
assign 1 71 328
addValue 1 71 328
addValue 1 71 329
assign 1 76 351
heldGet 0 76 351
assign 1 76 352
synGet 0 76 352
assign 1 77 353
ptyListGet 0 77 353
assign 1 79 354
emitNameGet 0 79 354
assign 1 79 355
addValue 1 79 355
assign 1 79 356
new 0 79 356
addValue 1 79 357
assign 1 81 358
new 0 81 358
assign 1 82 359
iteratorGet 0 0 359
assign 1 82 362
hasNextGet 0 82 362
assign 1 82 364
nextGet 0 82 364
assign 1 84 366
new 0 84 366
assign 1 86 369
new 0 86 369
addValue 1 86 370
assign 1 88 372
addValue 1 88 372
assign 1 88 373
new 0 88 373
assign 1 88 374
addValue 1 88 374
assign 1 88 375
nameGet 0 88 375
assign 1 88 376
addValue 1 88 376
addValue 1 88 377
assign 1 92 383
new 0 92 383
assign 1 92 384
addValue 1 92 384
addValue 1 92 385
assign 1 97 413
heldGet 0 97 413
assign 1 97 414
namepathGet 0 97 414
assign 1 97 415
getClassConfig 1 97 415
assign 1 98 416
getInitialInst 1 98 416
assign 1 100 417
emitNameGet 0 100 417
assign 1 100 418
addValue 1 100 418
assign 1 100 419
new 0 100 419
assign 1 100 420
addValue 1 100 420
addValue 1 100 421
assign 1 103 422
addValue 1 103 422
assign 1 103 423
new 0 103 423
assign 1 103 424
addValue 1 103 424
addValue 1 103 425
assign 1 105 426
new 0 105 426
assign 1 105 427
addValue 1 105 427
addValue 1 105 428
assign 1 107 429
emitNameGet 0 107 429
assign 1 107 430
addValue 1 107 430
assign 1 107 431
new 0 107 431
assign 1 107 432
addValue 1 107 432
addValue 1 107 433
assign 1 110 434
new 0 110 434
assign 1 110 435
addValue 1 110 435
assign 1 110 436
addValue 1 110 436
assign 1 110 437
new 0 110 437
assign 1 110 438
addValue 1 110 438
addValue 1 110 439
assign 1 112 440
new 0 112 440
assign 1 112 441
addValue 1 112 441
addValue 1 112 442
buildPropList 0 114 443
getCode 2 119 448
assign 1 120 449
toString 0 120 449
addValue 1 121 450
assign 1 127 456
new 0 127 456
assign 1 127 457
addValue 1 127 457
addValue 1 127 458
assign 1 132 467
isPropertyGet 0 132 467
assign 1 133 469
new 0 133 469
assign 1 133 470
nameGet 0 133 470
assign 1 133 471
add 1 133 471
return 1 133 472
assign 1 135 474
nameForVar 1 135 474
return 1 135 475
assign 1 144 602
getLibOutput 0 144 602
assign 1 146 603
new 0 146 603
assign 1 147 604
new 0 147 604
assign 1 148 605
new 0 148 605
assign 1 149 606
iteratorGet 0 149 606
assign 1 149 609
hasNextGet 0 149 609
assign 1 151 611
nextGet 0 151 611
assign 1 153 612
new 0 153 612
assign 1 153 613
addValue 1 153 613
assign 1 153 614
addValue 1 153 614
assign 1 153 615
heldGet 0 153 615
assign 1 153 616
namepathGet 0 153 616
assign 1 153 617
toString 0 153 617
assign 1 153 618
addValue 1 153 618
assign 1 153 619
addValue 1 153 619
assign 1 153 620
new 0 153 620
assign 1 153 621
addValue 1 153 621
assign 1 153 622
heldGet 0 153 622
assign 1 153 623
namepathGet 0 153 623
assign 1 153 624
getClassConfig 1 153 624
assign 1 153 625
libNameGet 0 153 625
assign 1 153 626
relEmitName 1 153 626
assign 1 153 627
addValue 1 153 627
assign 1 153 628
new 0 153 628
assign 1 153 629
addValue 1 153 629
addValue 1 153 630
assign 1 155 631
heldGet 0 155 631
assign 1 155 632
synGet 0 155 632
assign 1 155 633
hasDefaultGet 0 155 633
assign 1 157 635
new 0 157 635
assign 1 157 636
heldGet 0 157 636
assign 1 157 637
namepathGet 0 157 637
assign 1 157 638
getClassConfig 1 157 638
assign 1 157 639
libNameGet 0 157 639
assign 1 157 640
relEmitName 1 157 640
assign 1 157 641
add 1 157 641
assign 1 157 642
new 0 157 642
assign 1 157 643
add 1 157 643
assign 1 163 644
new 0 163 644
assign 1 163 645
addValue 1 163 645
assign 1 163 646
addValue 1 163 646
assign 1 163 647
new 0 163 647
assign 1 163 648
addValue 1 163 648
addValue 1 163 649
assign 1 164 650
heldGet 0 164 650
assign 1 164 651
synGet 0 164 651
assign 1 164 652
hasDefaultGet 0 164 652
assign 1 165 654
new 0 165 654
assign 1 165 655
addValue 1 165 655
assign 1 165 656
addValue 1 165 656
assign 1 165 657
new 0 165 657
assign 1 165 658
addValue 1 165 658
addValue 1 165 659
assign 1 171 667
new 0 171 667
assign 1 173 668
keysGet 0 173 668
assign 1 173 669
iteratorGet 0 0 669
assign 1 173 672
hasNextGet 0 173 672
assign 1 173 674
nextGet 0 173 674
assign 1 175 675
new 0 175 675
assign 1 175 676
addValue 1 175 676
assign 1 175 677
new 0 175 677
assign 1 175 678
quoteGet 0 175 678
assign 1 175 679
addValue 1 175 679
assign 1 175 680
addValue 1 175 680
assign 1 175 681
new 0 175 681
assign 1 175 682
quoteGet 0 175 682
assign 1 175 683
addValue 1 175 683
assign 1 175 684
new 0 175 684
assign 1 175 685
addValue 1 175 685
assign 1 175 686
get 1 175 686
assign 1 175 687
addValue 1 175 687
assign 1 175 688
new 0 175 688
assign 1 175 689
addValue 1 175 689
addValue 1 175 690
assign 1 176 691
new 0 176 691
assign 1 176 692
addValue 1 176 692
assign 1 176 693
new 0 176 693
assign 1 176 694
quoteGet 0 176 694
assign 1 176 695
addValue 1 176 695
assign 1 176 696
addValue 1 176 696
assign 1 176 697
new 0 176 697
assign 1 176 698
quoteGet 0 176 698
assign 1 176 699
addValue 1 176 699
assign 1 176 700
new 0 176 700
assign 1 176 701
addValue 1 176 701
assign 1 176 702
get 1 176 702
assign 1 176 703
addValue 1 176 703
assign 1 176 704
new 0 176 704
assign 1 176 705
addValue 1 176 705
addValue 1 176 706
write 1 180 712
assign 1 183 713
usedLibrarysGet 0 183 713
assign 1 183 714
sizeGet 0 183 714
assign 1 183 715
new 0 183 715
assign 1 183 716
equals 1 183 721
assign 1 184 722
new 0 184 722
assign 1 184 723
addValue 1 184 723
addValue 1 184 724
assign 1 185 725
new 0 185 725
assign 1 185 726
addValue 1 185 726
addValue 1 185 727
assign 1 186 728
new 0 186 728
assign 1 186 729
addValue 1 186 729
addValue 1 186 730
write 1 189 732
write 1 190 733
assign 1 193 734
new 0 193 734
assign 1 194 735
mainNameGet 0 194 735
fromString 1 194 736
assign 1 195 737
getClassConfig 1 195 737
assign 1 197 738
new 0 197 738
assign 1 198 739
new 0 198 739
assign 1 198 740
addValue 1 198 740
assign 1 198 741
fullEmitNameGet 0 198 741
assign 1 198 742
addValue 1 198 742
assign 1 198 743
new 0 198 743
assign 1 198 744
addValue 1 198 744
addValue 1 198 745
assign 1 199 746
ownProcessGet 0 199 746
assign 1 200 748
new 0 200 748
assign 1 200 749
addValue 1 200 749
addValue 1 200 750
assign 1 202 752
new 0 202 752
assign 1 202 753
addValue 1 202 753
assign 1 202 754
outputPlatformGet 0 202 754
assign 1 202 755
nameGet 0 202 755
assign 1 202 756
addValue 1 202 756
assign 1 202 757
new 0 202 757
assign 1 202 758
addValue 1 202 758
addValue 1 202 759
write 1 203 760
assign 1 204 761
new 0 204 761
write 1 205 762
write 1 206 763
assign 1 207 764
ownProcessGet 0 207 764
assign 1 208 766
new 0 208 766
assign 1 208 767
addValue 1 208 767
addValue 1 208 768
assign 1 209 769
new 0 209 769
assign 1 209 770
addValue 1 209 770
addValue 1 209 771
write 1 211 773
finishLibOutput 1 213 774
assign 1 215 775
saveSynsGet 0 215 775
saveSyns 0 216 777
assign 1 222 787
isPropertyGet 0 222 787
assign 1 225 791
isArgGet 0 225 791
assign 1 225 792
not 0 225 797
assign 1 226 798
new 0 226 798
addValue 1 226 799
assign 1 228 801
nameForVar 1 228 801
addValue 1 228 802
assign 1 233 808
new 0 233 808
return 1 233 809
assign 1 237 817
new 0 237 817
assign 1 237 818
add 1 237 818
assign 1 237 819
new 0 237 819
assign 1 237 820
add 1 237 820
assign 1 237 821
add 1 237 821
return 1 237 822
assign 1 241 826
new 0 241 826
return 1 241 827
assign 1 246 841
emitNameGet 0 246 841
assign 1 246 842
new 0 246 842
assign 1 246 843
add 1 246 843
assign 1 246 844
add 1 246 844
assign 1 246 845
new 0 246 845
assign 1 246 846
add 1 246 846
assign 1 246 847
addValue 1 246 847
assign 1 247 848
emitNameGet 0 247 848
assign 1 247 849
add 1 247 849
assign 1 247 850
new 0 247 850
assign 1 247 851
add 1 247 851
assign 1 247 852
addValue 1 247 852
return 1 248 853
assign 1 252 867
new 0 252 867
assign 1 252 868
libNameGet 0 252 868
assign 1 252 869
relEmitName 1 252 869
assign 1 252 870
add 1 252 870
assign 1 252 871
new 0 252 871
assign 1 252 872
add 1 252 872
assign 1 252 873
heldGet 0 252 873
assign 1 252 874
literalValueGet 0 252 874
assign 1 252 875
add 1 252 875
assign 1 252 876
new 0 252 876
assign 1 252 877
add 1 252 877
return 1 252 878
assign 1 256 892
new 0 256 892
assign 1 256 893
libNameGet 0 256 893
assign 1 256 894
relEmitName 1 256 894
assign 1 256 895
add 1 256 895
assign 1 256 896
new 0 256 896
assign 1 256 897
add 1 256 897
assign 1 256 898
heldGet 0 256 898
assign 1 256 899
literalValueGet 0 256 899
assign 1 256 900
add 1 256 900
assign 1 256 901
new 0 256 901
assign 1 256 902
add 1 256 902
return 1 256 903
assign 1 261 939
new 0 261 939
assign 1 261 940
libNameGet 0 261 940
assign 1 261 941
relEmitName 1 261 941
assign 1 261 942
add 1 261 942
assign 1 261 943
new 0 261 943
assign 1 261 944
add 1 261 944
assign 1 261 945
emitNameGet 0 261 945
assign 1 261 946
add 1 261 946
assign 1 261 947
new 0 261 947
assign 1 261 948
add 1 261 948
assign 1 261 949
add 1 261 949
assign 1 261 950
new 0 261 950
assign 1 261 951
add 1 261 951
assign 1 261 952
add 1 261 952
assign 1 261 953
new 0 261 953
assign 1 261 954
add 1 261 954
return 1 261 955
assign 1 263 957
new 0 263 957
assign 1 263 958
libNameGet 0 263 958
assign 1 263 959
relEmitName 1 263 959
assign 1 263 960
add 1 263 960
assign 1 263 961
new 0 263 961
assign 1 263 962
add 1 263 962
assign 1 263 963
emitNameGet 0 263 963
assign 1 263 964
add 1 263 964
assign 1 263 965
new 0 263 965
assign 1 263 966
add 1 263 966
assign 1 263 967
add 1 263 967
assign 1 263 968
new 0 263 968
assign 1 263 969
add 1 263 969
assign 1 263 970
add 1 263 970
assign 1 263 971
new 0 263 971
assign 1 263 972
add 1 263 972
return 1 263 973
assign 1 267 988
def 1 267 993
assign 1 268 994
libNameGet 0 268 994
assign 1 268 995
relEmitName 1 268 995
assign 1 268 996
extend 1 268 996
assign 1 270 999
new 0 270 999
assign 1 270 1000
extend 1 270 1000
assign 1 272 1002
new 0 272 1002
assign 1 272 1003
emitNameGet 0 272 1003
assign 1 272 1004
addValue 1 272 1004
assign 1 272 1005
new 0 272 1005
assign 1 272 1006
addValue 1 272 1006
assign 1 280 1007
new 0 280 1007
assign 1 280 1008
addValue 1 280 1008
addValue 1 280 1009
addValue 1 281 1010
return 1 282 1011
assign 1 286 1024
heldGet 0 286 1024
assign 1 286 1025
superCallGet 0 286 1025
assign 1 287 1027
new 0 287 1027
assign 1 287 1028
heldGet 0 287 1028
assign 1 287 1029
nameGet 0 287 1029
assign 1 287 1030
add 1 287 1030
return 1 287 1031
assign 1 289 1033
new 0 289 1033
assign 1 289 1034
heldGet 0 289 1034
assign 1 289 1035
nameGet 0 289 1035
assign 1 289 1036
add 1 289 1036
return 1 289 1037
assign 1 293 1066
new 0 293 1066
assign 1 294 1067
iteratorGet 0 0 1067
assign 1 294 1070
hasNextGet 0 294 1070
assign 1 294 1072
nextGet 0 294 1072
assign 1 295 1073
emitNameGet 0 295 1073
assign 1 295 1074
new 0 295 1074
assign 1 295 1075
add 1 295 1075
assign 1 295 1076
new 0 295 1076
assign 1 295 1077
add 1 295 1077
assign 1 295 1078
heldGet 0 295 1078
assign 1 295 1079
nameGet 0 295 1079
assign 1 295 1080
add 1 295 1080
assign 1 295 1081
new 0 295 1081
assign 1 295 1082
add 1 295 1082
assign 1 295 1083
emitNameGet 0 295 1083
assign 1 295 1084
add 1 295 1084
assign 1 295 1085
new 0 295 1085
assign 1 295 1086
add 1 295 1086
assign 1 295 1087
new 0 295 1087
assign 1 295 1088
add 1 295 1088
assign 1 295 1089
heldGet 0 295 1089
assign 1 295 1090
nameGet 0 295 1090
assign 1 295 1091
add 1 295 1091
assign 1 295 1092
new 0 295 1092
assign 1 295 1093
add 1 295 1093
assign 1 295 1094
add 1 295 1094
addValue 1 295 1095
return 1 297 1101
assign 1 304 1106
undef 1 304 1111
assign 1 305 1112
new 0 305 1112
addValue 1 307 1114
assign 1 308 1115
new 0 308 1115
return 1 308 1116
assign 1 313 1120
getLibOutput 0 313 1120
return 1 313 1121
assign 1 321 1152
undef 1 321 1157
assign 1 322 1158
new 0 322 1158
assign 1 323 1159
parentGet 0 323 1159
assign 1 323 1160
fileGet 0 323 1160
assign 1 323 1161
existsGet 0 323 1161
assign 1 323 1162
not 0 323 1167
assign 1 324 1168
parentGet 0 324 1168
assign 1 324 1169
fileGet 0 324 1169
makeDirs 0 324 1170
assign 1 326 1172
fileGet 0 326 1172
assign 1 326 1173
writerGet 0 326 1173
assign 1 326 1174
open 0 326 1174
assign 1 328 1175
paramsGet 0 328 1175
assign 1 328 1176
new 0 328 1176
assign 1 328 1177
has 1 328 1177
assign 1 329 1179
paramsGet 0 329 1179
assign 1 329 1180
new 0 329 1180
assign 1 329 1181
get 1 329 1181
assign 1 329 1182
iteratorGet 0 0 1182
assign 1 329 1185
hasNextGet 0 329 1185
assign 1 329 1187
nextGet 0 329 1187
assign 1 330 1188
apNew 1 330 1188
assign 1 330 1189
fileGet 0 330 1189
assign 1 331 1190
readerGet 0 331 1190
assign 1 331 1191
open 0 331 1191
assign 1 331 1192
readString 0 331 1192
assign 1 332 1193
readerGet 0 332 1193
close 0 332 1194
assign 1 333 1195
countLines 1 333 1195
addValue 1 333 1196
write 1 334 1197
return 1 340 1205
close 0 344 1208
assign 1 345 1209
assign 1 350 1214
new 0 350 1214
return 1 350 1215
assign 1 354 1219
new 0 354 1219
return 1 354 1220
assign 1 358 1224
new 0 358 1224
return 1 358 1225
assign 1 362 1229
new 0 362 1229
return 1 362 1230
assign 1 366 1234
new 0 366 1234
return 1 366 1235
assign 1 370 1239
new 0 370 1239
return 1 370 1240
assign 1 374 1244
new 0 374 1244
return 1 374 1245
assign 1 379 1249
new 0 379 1249
return 1 379 1250
assign 1 385 1254
new 0 385 1254
return 1 385 1255
assign 1 390 1259
new 0 390 1259
return 1 390 1260
assign 1 394 1268
new 0 394 1268
assign 1 394 1269
add 1 394 1269
assign 1 394 1270
new 0 394 1270
assign 1 394 1271
add 1 394 1271
assign 1 394 1272
add 1 394 1272
return 1 394 1273
assign 1 398 1277
new 0 398 1277
return 1 398 1278
assign 1 402 1285
libNameGet 0 402 1285
assign 1 402 1286
relEmitName 1 402 1286
assign 1 402 1287
new 0 402 1287
assign 1 402 1288
add 1 402 1288
return 1 402 1289
assign 1 407 1298
emitNameGet 0 407 1298
assign 1 407 1299
new 0 407 1299
assign 1 407 1300
add 1 407 1300
assign 1 407 1301
new 0 407 1301
assign 1 407 1302
add 1 407 1302
assign 1 407 1303
add 1 407 1303
return 1 407 1304
assign 1 412 1315
emitNameGet 0 412 1315
assign 1 412 1316
addValue 1 412 1316
assign 1 412 1317
new 0 412 1317
assign 1 412 1318
addValue 1 412 1318
assign 1 412 1319
addValue 1 412 1319
assign 1 412 1320
new 0 412 1320
addValue 1 412 1321
addValue 1 414 1322
assign 1 416 1323
new 0 416 1323
assign 1 416 1324
addValue 1 416 1324
addValue 1 416 1325
assign 1 421 1330
new 0 421 1330
return 1 421 1331
assign 1 425 1335
new 0 425 1335
return 1 425 1336
assign 1 429 1342
new 0 429 1342
assign 1 429 1343
add 1 429 1343
assign 1 429 1344
add 1 429 1344
return 1 429 1345
assign 1 434 1349
new 0 434 1349
return 1 434 1350
assign 1 438 1355
getClassConfig 1 438 1355
assign 1 439 1356
fullEmitNameGet 0 439 1356
emitNameSet 1 439 1357
return 1 440 1358
assign 1 444 1363
getLocalClassConfig 1 444 1363
assign 1 445 1364
fullEmitNameGet 0 445 1364
emitNameSet 1 445 1365
return 1 446 1366
return 1 0 1369
assign 1 0 1372
return 1 0 1376
assign 1 0 1379
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -58708803: return bem_synEmitPathGet_0();
case -689601423: return bem_overrideMtdDecGet_0();
case 947823193: return bem_allOnceDecsGet_0();
case -1929389596: return bem_nlGet_0();
case 470087279: return bem_mainOutsideNsGet_0();
case -1057001629: return bem_copy_0();
case -1134903192: return bem_methodCallsGet_0();
case 454941595: return bem_coanyiantReturnsGet_0();
case 1118189495: return bem_boolCcGet_0();
case 1028683886: return bem_toString_0();
case -1164488953: return bem_intNpGet_0();
case 603399214: return bem_emitLib_0();
case -627723721: return bem_typeDecGet_0();
case -971467287: return bem_inFilePathedGet_0();
case 2120178754: return bem_methodsGet_0();
case -427482859: return bem_constGet_0();
case 1741915096: return bem_baseMtdDecGet_0();
case 1705017025: return bem_classCallsGet_0();
case 1196555427: return bem_invpGet_0();
case -1874213289: return bem_tagGet_0();
case -612968092: return bem_initialDecGet_0();
case -354590014: return bem_print_0();
case -495356309: return bem_preClassGet_0();
case 1048772166: return bem_echo_0();
case -551298753: return bem_sourceFileNameGet_0();
case 335676847: return bem_nativeCSlotsGet_0();
case -1760956476: return bem_doEmit_0();
case 466719663: return bem_superNameGet_0();
case 1352532356: return bem_exceptDecGet_0();
case -1092911617: return bem_nullValueGet_0();
case 1836947478: return bem_serializeContents_0();
case -1217069994: return bem_maxDynArgsGet_0();
case -218755143: return bem_randGet_0();
case 374630880: return bem_superCallsGet_0();
case 1487472184: return bem_nameToIdGet_0();
case 1436235215: return bem_emitLangGet_0();
case -1192237086: return bem_buildInitial_0();
case -134370284: return bem_ntypesGet_0();
case 841168590: return bem_fullLibEmitNameGet_0();
case 356660348: return bem_idToNameGet_0();
case 1007931546: return bem_buildCreate_0();
case -1010470598: return bem_classEndGet_0();
case 1074625397: return bem_fileExtGet_0();
case 291071915: return bem_lastMethodBodySizeGet_0();
case 714392359: return bem_classNameGet_0();
case 678048517: return bem_methodCatchGet_0();
case -386157741: return bem_serializeToString_0();
case -454910570: return bem_create_0();
case -1036233638: return bem_new_0();
case -394608595: return bem_callNamesGet_0();
case -1826133160: return bem_baseSmtdDecGet_0();
case -354093047: return bem_serializationIteratorGet_0();
case -1575166913: return bem_csynGet_0();
case -923229393: return bem_writeBET_0();
case -1960550314: return bem_buildGet_0();
case 90930628: return bem_spropDecGet_0();
case 1509455310: return bem_lastMethodBodyLinesGet_0();
case 1212656998: return bem_qGet_0();
case 2096871783: return bem_objectCcGet_0();
case -1493103250: return bem_many_0();
case 1321762822: return bem_trueValueGet_0();
case 324385906: return bem_lineCountGet_0();
case 1070123927: return bem_shlibeGet_0();
case 1090358814: return bem_smnlcsGet_0();
case 2023802052: return bem_methodBodyGet_0();
case -1126262142: return bem_returnTypeGet_0();
case -1380642209: return bem_ccMethodsGet_0();
case 533263970: return bem_mainInClassGet_0();
case 566800355: return bem_mainStartGet_0();
case 2014801778: return bem_floatNpGet_0();
case -818685613: return bem_runtimeInitGet_0();
case 391742966: return bem_buildClassInfo_0();
case -271004735: return bem_parentConfGet_0();
case -1532641526: return bem_dynMethodsGet_0();
case -1686496133: return bem_cnodeGet_0();
case -1499600957: return bem_libEmitNameGet_0();
case 194480094: return bem_mnodeGet_0();
case -1687876207: return bem_propertyDecsGet_0();
case 769256670: return bem_mainEndGet_0();
case -55540799: return bem_endNs_0();
case 2041400176: return bem_boolNpGet_0();
case 1783372633: return bem_useDynMethodsGet_0();
case 654084467: return bem_iteratorGet_0();
case -1319880873: return bem_ccCacheGet_0();
case 1413390842: return bem_classEmitsGet_0();
case 993957917: return bem_classConfGet_0();
case -1825426158: return bem_buildPropList_0();
case -76505233: return bem_once_0();
case -1963468660: return bem_fieldIteratorGet_0();
case 236937973: return bem_lastCallGet_0();
case 660866322: return bem_onceDecsGet_0();
case 863669946: return bem_toAny_0();
case -362321661: return bem_deserializeClassNameGet_0();
case -1762972061: return bem_transGet_0();
case -910220512: return bem_getLibOutput_0();
case -384329842: return bem_lastMethodsSizeGet_0();
case -1952630545: return bem_instOfGet_0();
case -271976105: return bem_falseValueGet_0();
case -800041082: return bem_onceCountGet_0();
case -1149729591: return bem_instanceEqualGet_0();
case -48236567: return bem_saveSyns_0();
case -1897675065: return bem_libEmitPathGet_0();
case -1624996001: return bem_classesInDepthOrderGet_0();
case 62970256: return bem_beginNs_0();
case -1312519804: return bem_hashGet_0();
case -199411662: return bem_propDecGet_0();
case -159624029: return bem_lastMethodsLinesGet_0();
case -527813717: return bem_maxSpillArgsLenGet_0();
case -104360673: return bem_scvpGet_0();
case 1270032197: return bem_objectNpGet_0();
case -1483063021: return bem_afterCast_0();
case 1807236459: return bem_smnlecsGet_0();
case -179442235: return bem_stringNpGet_0();
case -1234106865: return bem_boolTypeGet_0();
case -451270257: return bem_msynGet_0();
case -1523971807: return bem_getClassOutput_0();
case 1333395990: return bem_instanceNotEqualGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1863006581: return bem_objectNpSet_1(bevd_0);
case 1209078914: return bem_ccCacheSet_1(bevd_0);
case 783724546: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1847687787: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 81260575: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 989858769: return bem_lastMethodsSizeSet_1(bevd_0);
case 1754894191: return bem_lineCountSet_1(bevd_0);
case -1226977628: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1737759530: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -400877040: return bem_scvpSet_1(bevd_0);
case 769964914: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1475207948: return bem_transSet_1(bevd_0);
case -586003741: return bem_classCallsSet_1(bevd_0);
case -1978731115: return bem_sameType_1(bevd_0);
case -2118810015: return bem_idToNameSet_1(bevd_0);
case 1613310748: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -612622253: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 967342022: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1463346588: return bem_dynMethodsSet_1(bevd_0);
case 1092337066: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -412662272: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case -836456000: return bem_methodBodySet_1(bevd_0);
case 2095964872: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 406453854: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case 553760376: return bem_msynSet_1(bevd_0);
case -63411882: return bem_stringNpSet_1(bevd_0);
case 183832281: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case 564529470: return bem_parentConfSet_1(bevd_0);
case -722880481: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -747350143: return bem_undef_1(bevd_0);
case -1184340301: return bem_otherClass_1(bevd_0);
case 1901648523: return bem_nativeCSlotsSet_1(bevd_0);
case 1494127502: return bem_randSet_1(bevd_0);
case -1373187411: return bem_preClassSet_1(bevd_0);
case -884710817: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 325940335: return bem_emitLangSet_1(bevd_0);
case -450067141: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case 1875514074: return bem_instanceEqualSet_1(bevd_0);
case -1680427486: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 1782921206: return bem_otherType_1(bevd_0);
case -1858718648: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case 1279791754: return bem_buildSet_1(bevd_0);
case 861758359: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -952230432: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 938340021: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -1080522635: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 774485445: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -829027934: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case 505775158: return bem_instanceNotEqualSet_1(bevd_0);
case -1933853301: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -2138321066: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1963700542: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 1891716884: return bem_fileExtSet_1(bevd_0);
case -487865698: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -1782898049: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case -2088479333: return bem_libEmitPathSet_1(bevd_0);
case -1976481575: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 824179568: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case -970073248: return bem_lastMethodBodySizeSet_1(bevd_0);
case 1098976971: return bem_libEmitNameSet_1(bevd_0);
case 1257541167: return bem_onceDecsSet_1(bevd_0);
case -403482348: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -504315826: return bem_sameObject_1(bevd_0);
case -1492682375: return bem_floatNpSet_1(bevd_0);
case 311729742: return bem_returnTypeSet_1(bevd_0);
case 604922157: return bem_equals_1(bevd_0);
case 61216877: return bem_onceCountSet_1(bevd_0);
case 1653434348: return bem_objectCcSet_1(bevd_0);
case -1966977691: return bem_classConfSet_1(bevd_0);
case -1374275511: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1226688933: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case 1162200516: return bem_maxDynArgsSet_1(bevd_0);
case -2128173101: return bem_lastMethodsLinesSet_1(bevd_0);
case 1063291838: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1335246413: return bem_boolCcSet_1(bevd_0);
case 700530675: return bem_methodCatchSet_1(bevd_0);
case 702024445: return bem_nullValueSet_1(bevd_0);
case 1665628794: return bem_invpSet_1(bevd_0);
case 1301577712: return bem_sameClass_1(bevd_0);
case 1672825312: return bem_notEquals_1(bevd_0);
case -1756276719: return bem_nlSet_1(bevd_0);
case -1164162703: return bem_superCallsSet_1(bevd_0);
case 744663562: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 989996527: return bem_synEmitPathSet_1(bevd_0);
case -601973698: return bem_qSet_1(bevd_0);
case -1748915312: return bem_mnodeSet_1(bevd_0);
case -558198774: return bem_def_1(bevd_0);
case 1527795284: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -263324333: return bem_csynSet_1(bevd_0);
case 1053755231: return bem_lastCallSet_1(bevd_0);
case -1219764883: return bem_classEmitsSet_1(bevd_0);
case 929774730: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case 691373757: return bem_callNamesSet_1(bevd_0);
case -999936361: return bem_defined_1(bevd_0);
case 638216154: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1385914620: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1845217826: return bem_propertyDecsSet_1(bevd_0);
case -217769429: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 231379770: return bem_instOfSet_1(bevd_0);
case -1434226907: return bem_emitNameForCall_1((BEC_2_5_4_BuildNode) bevd_0);
case 1890634426: return bem_nameToIdSet_1(bevd_0);
case -1005625203: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 1308114736: return bem_methodsSet_1(bevd_0);
case 729561267: return bem_copyTo_1(bevd_0);
case -1501505332: return bem_methodCallsSet_1(bevd_0);
case -1171513527: return bem_inFilePathedSet_1(bevd_0);
case 632286409: return bem_trueValueSet_1(bevd_0);
case -2006049248: return bem_end_1(bevd_0);
case -613807362: return bem_smnlcsSet_1(bevd_0);
case -658729095: return bem_classesInDepthOrderSet_1(bevd_0);
case 894175245: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -212566352: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case -1151886224: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case -783493914: return bem_fullLibEmitNameSet_1(bevd_0);
case -291321785: return bem_begin_1(bevd_0);
case 351722599: return bem_exceptDecSet_1(bevd_0);
case -1596144507: return bem_intNpSet_1(bevd_0);
case 925024598: return bem_ntypesSet_1(bevd_0);
case 348383451: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 604200760: return bem_cnodeSet_1(bevd_0);
case 159373062: return bem_lastMethodBodyLinesSet_1(bevd_0);
case 872151766: return bem_shlibeSet_1(bevd_0);
case -1649576053: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case -321855271: return bem_ccMethodsSet_1(bevd_0);
case 986289069: return bem_maxSpillArgsLenSet_1(bevd_0);
case -883964957: return bem_allOnceDecsSet_1(bevd_0);
case -1188536421: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -965306462: return bem_undefined_1(bevd_0);
case -539535073: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1533563890: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 787365424: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 966065804: return bem_falseValueSet_1(bevd_0);
case 1348337682: return bem_constSet_1(bevd_0);
case 81946645: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -793066655: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case -218124700: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -991489383: return bem_smnlecsSet_1(bevd_0);
case -974340708: return bem_boolNpSet_1(bevd_0);
case -1916332226: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case 508124234: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 478589859: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -926115556: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 106441735: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1690761416: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1655666515: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -608983707: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -546378747: return bem_lintConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -63703999: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -225429636: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 754080424: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2045713194: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1172284175: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -212511412: return bem_lfloatConstruct_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1);
case -249962556: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -702689439: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -1192068648: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1514565291: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 913536943: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1129127418: return bem_decForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 1135998263: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 2084392130: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case 4657729: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -973091309: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case -1326942310: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case 1065089232: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
case -108826727: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
}
