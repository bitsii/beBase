namespace be {
/* IO:File: source/build/JSEmitter.be */
public sealed class BEC_2_5_9_BuildJSEmitter : BEC_2_5_10_BuildEmitCommon {
public BEC_2_5_9_BuildJSEmitter() { }
static BEC_2_5_9_BuildJSEmitter() { }
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72};
private static byte[] becc_BEC_2_5_9_BuildJSEmitter_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4A,0x53,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_0 = {0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_1 = {0x2E,0x6A,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_2 = {};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_3 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_4 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_5 = {0x20,0x3D,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_6 = {0x20,0x21,0x3D,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_7 = {0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_7, 8));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_8 = {0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_8, 9));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_9 = {0x74,0x68,0x72,0x6F,0x77,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_10 = {0x2C,0x20,0x6E,0x65,0x77,0x20,0x45,0x72,0x72,0x6F,0x72,0x28,0x29,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_11 = {0x62,0x65,0x76,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_11, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_12 = {0x20,0x63,0x61,0x74,0x63,0x68,0x20,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_13 = {0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_14 = {0x28,0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x54,0x68,0x72,0x6F,0x77,0x42,0x61,0x63,0x6B,0x5F,0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x68,0x72,0x6F,0x77,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_14, 31));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_15 = {0x29,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_15, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_16 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_17 = {0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_18 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x63,0x72,0x65,0x61,0x74,0x65,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_19 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_20 = {0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_21 = {0x7D};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_22 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x70,0x6E,0x5F,0x70,0x6E,0x61,0x6D,0x65,0x73,0x20,0x3D,0x20,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_23 = {0x2C,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_24 = {0x62,0x65,0x76,0x70,0x5F};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_25 = {0x5D,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_26 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x73,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_27 = {0x20,0x3D,0x20,0x20,0x62,0x65,0x63,0x63,0x5F,0x69,0x6E,0x73,0x74,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_28 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x63,0x5F,0x67,0x65,0x74,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_29 = {0x72,0x65,0x74,0x75,0x72,0x6E,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_30 = {0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_31 = {0x74,0x68,0x69,0x73,0x2E,0x62,0x65,0x76,0x70,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_31, 10));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_32 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x74,0x79,0x70,0x65,0x52,0x65,0x66,0x73,0x5B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_33 = {0x5D,0x20,0x3D,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_34 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_35 = {0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_36 = {0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_36, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_37 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x43,0x6F,0x6E,0x73,0x74,0x72,0x75,0x63,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_38 = {0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_39 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x6F,0x74,0x4E,0x75,0x6C,0x6C,0x49,0x6E,0x69,0x74,0x44,0x65,0x66,0x61,0x75,0x6C,0x74,0x5F,0x31,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_40 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_41 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x75,0x74,0x4E,0x6C,0x65,0x63,0x53,0x6F,0x75,0x72,0x63,0x65,0x4D,0x61,0x70,0x28};
private static BEC_2_4_3_MathInt bece_BEC_2_5_9_BuildJSEmitter_bevo_8 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_42 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x54,0x72,0x75,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x74,0x72,0x75,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_43 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x6F,0x6F,0x6C,0x46,0x61,0x6C,0x73,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x35,0x5F,0x34,0x5F,0x4C,0x6F,0x67,0x69,0x63,0x42,0x6F,0x6F,0x6C,0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x6F,0x6F,0x6C,0x28,0x66,0x61,0x6C,0x73,0x65,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_44 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x69,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20,0x62,0x65,0x5F,0x42,0x45,0x43,0x5F,0x32,0x5F,0x36,0x5F,0x31,0x31,0x5F,0x53,0x79,0x73,0x74,0x65,0x6D,0x49,0x6E,0x69,0x74,0x69,0x61,0x6C,0x69,0x7A,0x65,0x72,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_45 = {0x76,0x61,0x72,0x20,0x6D,0x63,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_46 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x61,0x72,0x67,0x73,0x20,0x3D,0x20,0x70,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x61,0x72,0x67,0x76,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_47 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x52,0x75,0x6E,0x74,0x69,0x6D,0x65,0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D,0x4E,0x61,0x6D,0x65,0x20,0x3D,0x20,0x22};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_48 = {0x22,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_49 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6E,0x65,0x77,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_50 = {0x6D,0x63,0x2E,0x62,0x65,0x6D,0x5F,0x6D,0x61,0x69,0x6E,0x5F,0x30,0x28,0x29,0x3B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_51 = {0x76,0x61,0x72,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_52 = {0x62,0x6F,0x6F,0x6C,0x65,0x61,0x6E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_53 = {0x70,0x75,0x62,0x6C,0x69,0x63,0x20,0x73,0x74,0x61,0x74,0x69,0x63,0x20,0x76,0x6F,0x69,0x64,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_53, 25));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_54 = {0x20,0x7B};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_54, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_55 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_56 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x20,0x3D,0x20,0x6E,0x65,0x77,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_56, 17));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_20, 3));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_57 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B,0x20,0x7D};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_57, 38));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_58 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x69,0x6E,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_58, 21));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_59 = {0x29};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_60 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x66,0x6C,0x6F,0x61,0x74,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_60, 23));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_61 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_61, 27));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_35, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_62 = {0x28,0x29,0x2E,0x62,0x65,0x6D,0x6C,0x5F,0x73,0x65,0x74,0x5F,0x62,0x65,0x76,0x69,0x5F,0x62,0x79,0x74,0x65,0x73,0x5F,0x6C,0x65,0x6E,0x5F,0x63,0x6F,0x70,0x79,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_62, 32));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_23, 2));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_63 = {0x62,0x65,0x5F,0x42,0x45,0x43,0x53,0x5F,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_64 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28,0x29,0x20,0x7B};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_65 = {0x74,0x68,0x69,0x73,0x2C,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_65, 6));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_66 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_66, 15));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_67 = {0x2E,0x63,0x61,0x6C,0x6C,0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_67, 6));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_68 = {0x62,0x65,0x6D,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_68, 4));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_69 = {0x28};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_69, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_59, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_70 = {0x6A,0x73,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_71 = {0x65,0x78,0x70,0x6F,0x72,0x74,0x20,0x63,0x6C,0x61,0x73,0x73,0x20};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_72 = {0x73,0x74,0x61,0x74,0x69,0x63,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_72, 7));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_73 = {0x3A,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_73, 2));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_74 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E,0x62,0x65,0x63,0x73,0x5F,0x69,0x6E,0x73,0x74,0x73,0x2E,0x62,0x65,0x76,0x73,0x5F,0x69,0x6E,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_74, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_16, 22));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_75 = {0x62,0x65,0x76,0x6F,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_75, 5));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_76 = {0x2E,0x70,0x72,0x6F,0x74,0x6F,0x74,0x79,0x70,0x65,0x2E};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_77 = {0x20,0x3D,0x20,0x66,0x75,0x6E,0x63,0x74,0x69,0x6F,0x6E,0x28};
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_78 = {0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_9_BuildJSEmitter_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_9_BuildJSEmitter_bels_78, 1));
private static byte[] bece_BEC_2_5_9_BuildJSEmitter_bels_79 = {0x62,0x65};
public static new BEC_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;

public static new BET_2_5_9_BuildJSEmitter bece_BEC_2_5_9_BuildJSEmitter_bevs_type;

public BEC_2_4_6_TextString bevp_allOnceDecs;
public BEC_3_2_4_6_IOFileWriter bevp_shlibe;
public override BEC_2_5_10_BuildEmitCommon bem_new_1(BEC_2_5_5_BuildBuild beva__build) {
bevp_emitLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_0));
bevp_fileExt = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_1));
bevp_exceptDec = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
base.bem_new_1(beva__build);
bevp_trueValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_2_5_9_BuildJSEmitter_bels_3));
bevp_falseValue = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_4));
bevp_instanceEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_5));
bevp_instanceNotEqual = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_6));
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCallTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formTarg_1(beva_node);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_invp);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formIntTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_0;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_formBoolTarg_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bem_formCallTarg_1(beva_node);
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptThrow_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(28, bece_BEC_2_5_9_BuildJSEmitter_bels_9));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_3_tmpany_phold);
bevt_5_tmpany_phold = beva_node.bem_secondGet_0();
bevt_4_tmpany_phold = bem_formTarg_1(bevt_5_tmpany_phold);
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_10));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_acceptCatch_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_4_6_TextString bevl_catchVar = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_2;
bevt_1_tmpany_phold = bevp_methodCatch.bem_toString_0();
bevl_catchVar = bevt_0_tmpany_phold.bem_add_1(bevt_1_tmpany_phold);
bevp_methodCatch.bevi_int++;
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_9_BuildJSEmitter_bels_12));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevp_methodBody.bem_addValue_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevl_catchVar);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_11_tmpany_phold = beva_node.bem_containedGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_firstGet_0();
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(-12868923);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1206759967);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_3;
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_add_1(bevl_catchVar);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_4;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
bevt_7_tmpany_phold = bem_finalAssign_4((BEC_2_5_4_BuildNode) bevt_8_tmpany_phold , bevt_12_tmpany_phold, null, null);
bevp_methodBody.bem_addValue_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildClassInfoMethod_3(BEC_2_4_6_TextString beva_bemBase, BEC_2_4_6_TextString beva_belsBase, BEC_2_4_3_MathInt beva_len) {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringStart_2(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_belsName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(22, bece_BEC_2_5_9_BuildJSEmitter_bels_16));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_belsName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_17));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildCreate_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(37, bece_BEC_2_5_9_BuildJSEmitter_bels_18));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_19));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_11_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(-1117649733);
bevt_9_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_10_tmpany_phold );
bevt_12_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_relEmitName_1(bevt_12_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_4_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_15_tmpany_phold);
bevt_14_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_buildPropList_0() {
BEC_2_5_8_BuildClassSyn bevl_syn = null;
BEC_2_9_4_ContainerList bevl_ptyList = null;
BEC_2_5_4_LogicBool bevl_first = null;
BEC_2_5_6_BuildPtySyn bevl_ptySyn = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevl_syn = (BEC_2_5_8_BuildClassSyn) bevt_1_tmpany_phold.bemd_0(-184726534);
bevl_ptyList = bevl_syn.bem_ptyListGet_0();
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(26, bece_BEC_2_5_9_BuildJSEmitter_bels_22));
bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_0_tmpany_loop = bevl_ptyList.bem_iteratorGet_0();
while (true)
 /* Line: 81 */ {
bevt_5_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 81 */ {
bevl_ptySyn = (BEC_2_5_6_BuildPtySyn) bevt_0_tmpany_loop.bemd_0(-1738265524);
if (bevl_first.bevi_bool) /* Line: 82 */ {
bevl_first = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
} /* Line: 83 */
 else  /* Line: 84 */ {
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevp_ccMethods.bem_addValue_1(bevt_6_tmpany_phold);
} /* Line: 85 */
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevp_q);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_9_BuildJSEmitter_bels_24));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevt_9_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_11_tmpany_phold = bevl_ptySyn.bem_nameGet_0();
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevt_11_tmpany_phold);
bevt_7_tmpany_phold.bem_addValue_1(bevp_q);
} /* Line: 87 */
 else  /* Line: 81 */ {
break;
} /* Line: 81 */
} /* Line: 81 */
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_12_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_buildInitial_0() {
BEC_2_5_11_BuildClassConfig bevl_newcc = null;
BEC_2_4_6_TextString bevl_stinst = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_cnode.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-1117649733);
bevl_newcc = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_0_tmpany_phold );
bevl_stinst = bem_getInitialInst_1(bevl_newcc);
bevt_4_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(50, bece_BEC_2_5_9_BuildJSEmitter_bels_26));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevl_stinst);
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_27));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_8_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_10_tmpany_phold);
bevt_9_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_13_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_13_tmpany_phold);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(41, bece_BEC_2_5_9_BuildJSEmitter_bels_28));
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_11_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_29));
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_18_tmpany_phold);
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) bevt_17_tmpany_phold.bem_addValue_1(bevl_stinst);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_30));
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_15_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_20_tmpany_phold = (BEC_2_4_6_TextString) bevp_ccMethods.bem_addValue_1(bevt_21_tmpany_phold);
bevt_20_tmpany_phold.bem_addValue_1(bevp_nl);
bem_buildPropList_0();
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringByte_5(BEC_2_4_6_TextString beva_sdec, BEC_2_4_6_TextString beva_lival, BEC_2_4_3_MathInt beva_lipos, BEC_2_4_3_MathInt beva_bcode, BEC_2_4_6_TextString beva_hs) {
BEC_2_4_6_TextString bevl_bc = null;
beva_lival.bem_getCode_2(beva_lipos, beva_bcode);
bevl_bc = beva_bcode.bem_toString_0();
beva_sdec.bem_addValue_1(bevl_bc);
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_lstringEnd_1(BEC_2_4_6_TextString beva_sdec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_25));
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) beva_sdec.bem_addValue_1(bevt_1_tmpany_phold);
bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_nameForVar_1(BEC_2_5_3_BuildVar beva_v) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 131 */ {
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_5;
bevt_3_tmpany_phold = beva_v.bem_nameGet_0();
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_1_tmpany_phold;
} /* Line: 132 */
bevt_4_tmpany_phold = base.bem_nameForVar_1(beva_v);
return bevt_4_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_writeBET_0() {
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_emitLib_0() {
BEC_3_2_4_6_IOFileWriter bevl_libe = null;
BEC_2_4_6_TextString bevl_libInit = null;
BEC_2_4_6_TextString bevl_notNullInitConstruct = null;
BEC_2_4_6_TextString bevl_notNullInitDefault = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_4_6_TextString bevl_nc = null;
BEC_2_4_6_TextString bevl_smap = null;
BEC_2_4_6_TextString bevl_smk = null;
BEC_2_5_8_BuildNamePath bevl_mainClassNp = null;
BEC_2_5_11_BuildClassConfig bevl_maincc = null;
BEC_2_4_6_TextString bevl_main = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_5_11_BuildClassConfig bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_4_6_TextString bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_6_TextString bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_78_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_4_6_TextString bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_6_TextString bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_108_tmpany_phold = null;
bevl_libe = bem_getLibOutput_0();
bevl_libInit = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitConstruct = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_notNullInitDefault = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevl_ci = bevp_classesInDepthOrder.bem_iteratorGet_0();
while (true)
 /* Line: 148 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 148 */ {
bevl_clnode = bevl_ci.bemd_0(-1738265524);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(35, bece_BEC_2_5_9_BuildJSEmitter_bels_32));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) bevt_8_tmpany_phold.bem_addValue_1(bevp_q);
bevt_12_tmpany_phold = bevl_clnode.bemd_0(1721602940);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(-1117649733);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1513233059);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevt_7_tmpany_phold.bem_addValue_1(bevt_10_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_q);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_33));
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_13_tmpany_phold);
bevt_17_tmpany_phold = bevl_clnode.bemd_0(1721602940);
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bemd_0(-1117649733);
bevt_15_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_16_tmpany_phold );
bevt_18_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_relEmitName_1(bevt_18_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_14_tmpany_phold);
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_34));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevt_3_tmpany_phold.bem_addValue_1(bevt_19_tmpany_phold);
bevt_2_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_22_tmpany_phold = bevl_clnode.bemd_0(1721602940);
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_0(-184726534);
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bemd_0(1043727186);
if (((BEC_2_5_4_LogicBool) bevt_20_tmpany_phold).bevi_bool) /* Line: 154 */ {
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_6;
bevt_28_tmpany_phold = bevl_clnode.bemd_0(1721602940);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(-1117649733);
bevt_26_tmpany_phold = bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevt_27_tmpany_phold );
bevt_29_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bem_relEmitName_1(bevt_29_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_7;
bevl_nc = bevt_23_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_34_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_2_5_9_BuildJSEmitter_bels_37));
bevt_33_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitConstruct.bem_addValue_1(bevt_34_tmpany_phold);
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) bevt_33_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) bevt_32_tmpany_phold.bem_addValue_1(bevt_35_tmpany_phold);
bevt_31_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_38_tmpany_phold = bevl_clnode.bemd_0(1721602940);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_0(-184726534);
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bemd_0(1043727186);
if (((BEC_2_5_4_LogicBool) bevt_36_tmpany_phold).bevi_bool) /* Line: 163 */ {
bevt_42_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(63, bece_BEC_2_5_9_BuildJSEmitter_bels_39));
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) bevl_notNullInitDefault.bem_addValue_1(bevt_42_tmpany_phold);
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) bevt_41_tmpany_phold.bem_addValue_1(bevl_nc);
bevt_43_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_39_tmpany_phold = (BEC_2_4_6_TextString) bevt_40_tmpany_phold.bem_addValue_1(bevt_43_tmpany_phold);
bevt_39_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 164 */
} /* Line: 163 */
} /* Line: 154 */
 else  /* Line: 148 */ {
break;
} /* Line: 148 */
} /* Line: 148 */
bevl_smap = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevt_44_tmpany_phold = bevp_smnlcs.bem_keysGet_0();
bevt_0_tmpany_loop = bevt_44_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 172 */ {
bevt_45_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 172 */ {
bevl_smk = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1738265524);
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_40));
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_53_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bem_quoteGet_0();
bevt_51_tmpany_phold = (BEC_2_4_6_TextString) bevt_52_tmpany_phold.bem_addValue_1(bevt_54_tmpany_phold);
bevt_50_tmpany_phold = (BEC_2_4_6_TextString) bevt_51_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_57_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_quoteGet_0();
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) bevt_50_tmpany_phold.bem_addValue_1(bevt_56_tmpany_phold);
bevt_58_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) bevt_49_tmpany_phold.bem_addValue_1(bevt_58_tmpany_phold);
bevt_59_tmpany_phold = bevp_smnlcs.bem_get_1(bevl_smk);
bevt_47_tmpany_phold = (BEC_2_4_6_TextString) bevt_48_tmpany_phold.bem_addValue_1(bevt_59_tmpany_phold);
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_46_tmpany_phold = (BEC_2_4_6_TextString) bevt_47_tmpany_phold.bem_addValue_1(bevt_60_tmpany_phold);
bevt_46_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(43, bece_BEC_2_5_9_BuildJSEmitter_bels_41));
bevt_67_tmpany_phold = (BEC_2_4_6_TextString) bevl_smap.bem_addValue_1(bevt_68_tmpany_phold);
bevt_70_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_quoteGet_0();
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) bevt_67_tmpany_phold.bem_addValue_1(bevt_69_tmpany_phold);
bevt_65_tmpany_phold = (BEC_2_4_6_TextString) bevt_66_tmpany_phold.bem_addValue_1(bevl_smk);
bevt_72_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bem_quoteGet_0();
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) bevt_65_tmpany_phold.bem_addValue_1(bevt_71_tmpany_phold);
bevt_73_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_23));
bevt_63_tmpany_phold = (BEC_2_4_6_TextString) bevt_64_tmpany_phold.bem_addValue_1(bevt_73_tmpany_phold);
bevt_74_tmpany_phold = bevp_smnlecs.bem_get_1(bevl_smk);
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) bevt_63_tmpany_phold.bem_addValue_1(bevt_74_tmpany_phold);
bevt_75_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_38));
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) bevt_62_tmpany_phold.bem_addValue_1(bevt_75_tmpany_phold);
bevt_61_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 175 */
 else  /* Line: 172 */ {
break;
} /* Line: 172 */
} /* Line: 172 */
bevl_libe.bem_write_1(bevl_smap);
bevt_78_tmpany_phold = bevp_build.bem_usedLibrarysGet_0();
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bem_sizeGet_0();
bevt_79_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_8;
if (bevt_77_tmpany_phold.bevi_int == bevt_79_tmpany_phold.bevi_int) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_81_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(91, bece_BEC_2_5_9_BuildJSEmitter_bels_42));
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_81_tmpany_phold);
bevt_80_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_83_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(93, bece_BEC_2_5_9_BuildJSEmitter_bels_43));
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_83_tmpany_phold);
bevt_82_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_85_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(78, bece_BEC_2_5_9_BuildJSEmitter_bels_44));
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) bevl_libInit.bem_addValue_1(bevt_85_tmpany_phold);
bevt_84_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 185 */
bevl_libe.bem_write_1(bevl_libInit);
bevl_libe.bem_write_1(bevl_notNullInitConstruct);
bevl_mainClassNp = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_86_tmpany_phold = bevp_build.bem_mainNameGet_0();
bevl_mainClassNp.bem_fromString_1(bevt_86_tmpany_phold);
bevl_maincc = bem_getClassConfig_1(bevl_mainClassNp);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevt_90_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_45));
bevt_89_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_90_tmpany_phold);
bevt_91_tmpany_phold = bevl_maincc.bem_fullEmitNameGet_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) bevt_89_tmpany_phold.bem_addValue_1(bevt_91_tmpany_phold);
bevt_92_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_20));
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) bevt_88_tmpany_phold.bem_addValue_1(bevt_92_tmpany_phold);
bevt_87_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_93_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_93_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(46, bece_BEC_2_5_9_BuildJSEmitter_bels_46));
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_95_tmpany_phold);
bevt_94_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 199 */
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(42, bece_BEC_2_5_9_BuildJSEmitter_bels_47));
bevt_98_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_99_tmpany_phold);
bevt_101_tmpany_phold = bevp_build.bem_outputPlatformGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(1041439923);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) bevt_98_tmpany_phold.bem_addValue_1(bevt_100_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_48));
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) bevt_97_tmpany_phold.bem_addValue_1(bevt_102_tmpany_phold);
bevt_96_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_libe.bem_write_1(bevl_main);
bevl_main = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
bevl_libe.bem_write_1(bevp_allOnceDecs);
bevl_libe.bem_write_1(bevl_notNullInitDefault);
bevt_103_tmpany_phold = bevp_build.bem_ownProcessGet_0();
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_49));
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_105_tmpany_phold);
bevt_104_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_9_BuildJSEmitter_bels_50));
bevt_106_tmpany_phold = (BEC_2_4_6_TextString) bevl_main.bem_addValue_1(bevt_107_tmpany_phold);
bevt_106_tmpany_phold.bem_addValue_1(bevp_nl);
} /* Line: 208 */
bevl_libe.bem_write_1(bevl_main);
bem_finishLibOutput_1(bevl_libe);
bevt_108_tmpany_phold = bevp_build.bem_saveSynsGet_0();
if (bevt_108_tmpany_phold.bevi_bool) /* Line: 214 */ {
bem_saveSyns_0();
} /* Line: 215 */
return this;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_decForVar_3(BEC_2_4_6_TextString beva_b, BEC_2_5_3_BuildVar beva_v, BEC_2_5_4_LogicBool beva_isArg) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_0_tmpany_phold = beva_v.bem_isPropertyGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 221 */ {
} /* Line: 221 */
 else  /* Line: 223 */ {
bevt_2_tmpany_phold = beva_v.bem_isArgGet_0();
if (bevt_2_tmpany_phold.bevi_bool) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 224 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
beva_b.bem_addValue_1(bevt_3_tmpany_phold);
} /* Line: 225 */
bevt_4_tmpany_phold = bem_nameForVar_1(beva_v);
beva_b.bem_addValue_1(bevt_4_tmpany_phold);
} /* Line: 227 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_boolTypeGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_9_BuildJSEmitter_bels_52));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_mainStartGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_9;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevp_exceptDec);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevp_nl);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_superNameGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_extend_1(BEC_2_4_6_TextString beva_parent) {
BEC_2_4_6_TextString bevl_extstr = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_11;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_parent);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_12;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_0_tmpany_phold.bem_addValue_1(bevp_nl);
bevt_8_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_7_tmpany_phold = bevl_extstr.bem_add_1(bevt_8_tmpany_phold);
bevt_9_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_13;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevl_extstr = (BEC_2_4_6_TextString) bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return bevl_extstr;
} /*method end*/
public override BEC_2_4_6_TextString bem_lintConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_14;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_15;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-670418413);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_16;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lfloatConstruct_3(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_17;
bevt_6_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_5_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_6_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_7_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_18;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = beva_node.bem_heldGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(-670418413);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_8_tmpany_phold);
bevt_10_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_19;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_10_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_lstringConstruct_5(BEC_2_5_11_BuildClassConfig beva_newcc, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_belsName, BEC_2_4_3_MathInt beva_lisz, BEC_2_5_4_LogicBool beva_isOnce) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_4_6_TextString bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
if (beva_isOnce.bevi_bool) /* Line: 258 */ {
bevt_8_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_20;
bevt_10_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_9_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_10_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_9_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_21;
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_12_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_13_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_22;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevt_13_tmpany_phold);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(beva_belsName);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_23;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_lisz);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_24;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_0_tmpany_phold;
} /* Line: 259 */
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_25;
bevt_26_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_25_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
bevt_27_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_26;
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_add_1(bevt_27_tmpany_phold);
bevt_28_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bem_add_1(bevt_28_tmpany_phold);
bevt_29_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_27;
bevt_20_tmpany_phold = bevt_21_tmpany_phold.bem_add_1(bevt_29_tmpany_phold);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(beva_belsName);
bevt_30_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_28;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_30_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_lisz);
bevt_31_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_29;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_31_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classBegin_1(BEC_2_5_8_BuildClassSyn beva_csyn) {
BEC_2_4_6_TextString bevl_extends = null;
BEC_2_4_6_TextString bevl_begin = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
if (bevp_parentConf == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 265 */ {
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = bevp_parentConf.bem_relEmitName_1(bevt_2_tmpany_phold);
bevl_extends = bem_extend_1(bevt_1_tmpany_phold);
} /* Line: 266 */
 else  /* Line: 267 */ {
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_9_BuildJSEmitter_bels_63));
bevl_extends = bem_extend_1(bevt_3_tmpany_phold);
} /* Line: 268 */
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_51));
bevt_6_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) bevt_5_tmpany_phold.bem_addValue_1(bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_9_BuildJSEmitter_bels_64));
bevl_begin = (BEC_2_4_6_TextString) bevt_4_tmpany_phold.bem_addValue_1(bevt_7_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_9_BuildJSEmitter_bels_21));
bevt_8_tmpany_phold = (BEC_2_4_6_TextString) bevl_begin.bem_addValue_1(bevt_9_tmpany_phold);
bevt_8_tmpany_phold.bem_addValue_1(bevp_nl);
bevl_begin.bem_addValue_1(bevl_extends);
return bevl_begin;
} /*method end*/
public override BEC_2_4_6_TextString bem_emitCall_3(BEC_2_4_6_TextString beva_callTarget, BEC_2_5_4_BuildNode beva_node, BEC_2_4_6_TextString beva_callArgs) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
bevt_1_tmpany_phold = beva_node.bem_heldGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_0(-940097872);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 284 */ {
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_notEmpty_1(beva_callArgs);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_30;
beva_callArgs = bevt_4_tmpany_phold.bem_add_1(beva_callArgs);
} /* Line: 286 */
 else  /* Line: 287 */ {
beva_callArgs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_9_BuildJSEmitter_bels_55));
} /* Line: 288 */
bevt_10_tmpany_phold = bevp_parentConf.bem_emitNameGet_0();
bevt_11_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_31;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevt_11_tmpany_phold);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1041439923);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_add_1(bevt_12_tmpany_phold);
bevt_14_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_32;
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_add_1(bevt_14_tmpany_phold);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_add_1(beva_callArgs);
bevt_15_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_33;
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bem_add_1(bevt_15_tmpany_phold);
return bevt_5_tmpany_phold;
} /* Line: 290 */
bevt_21_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_34;
bevt_20_tmpany_phold = beva_callTarget.bem_add_1(bevt_21_tmpany_phold);
bevt_23_tmpany_phold = beva_node.bem_heldGet_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(1041439923);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_add_1(bevt_22_tmpany_phold);
bevt_24_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_35;
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bem_add_1(bevt_24_tmpany_phold);
bevt_17_tmpany_phold = bevt_18_tmpany_phold.bem_add_1(beva_callArgs);
bevt_25_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_36;
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_add_1(bevt_25_tmpany_phold);
return bevt_16_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_classEndGet_0() {
BEC_2_4_6_TextString bevl_end = null;
bevl_end = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevl_end;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_writeOnceDecs_2(BEC_2_6_6_SystemObject beva_cle, BEC_2_6_6_SystemObject beva_onceDecs) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
if (bevp_allOnceDecs == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 304 */ {
bevp_allOnceDecs = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 305 */
bevp_allOnceDecs.bem_addValue_1(beva_onceDecs);
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_1_tmpany_phold;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getClassOutput_0() {
BEC_3_2_4_6_IOFileWriter bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_getLibOutput_0();
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishClassOutput_1(BEC_3_2_4_6_IOFileWriter beva_cle) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_getLibOutput_0() {
BEC_2_4_6_TextString bevl_p = null;
BEC_2_2_4_IOFile bevl_jsi = null;
BEC_2_4_6_TextString bevl_inc = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_5_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_6_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_13_tmpany_phold = null;
BEC_2_6_10_SystemParameters bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
if (bevp_shlibe == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 321 */ {
bevp_lineCount = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_5_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_existsGet_0();
if (bevt_3_tmpany_phold.bevi_bool) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_7_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevp_libEmitPath.bem_parentGet_0();
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bem_fileGet_0();
bevt_6_tmpany_phold.bem_makeDirs_0();
} /* Line: 324 */
bevt_9_tmpany_phold = bevp_libEmitPath.bem_fileGet_0();
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bem_writerGet_0();
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_8_tmpany_phold.bemd_0(-1045111996);
bevt_11_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_12_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bem_has_1(bevt_12_tmpany_phold);
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 328 */ {
bevt_14_tmpany_phold = bevp_build.bem_paramsGet_0();
bevt_15_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_9_BuildJSEmitter_bels_70));
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_get_1(bevt_15_tmpany_phold);
bevt_0_tmpany_loop = bevt_13_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 329 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bemd_0(1660587278);
if (((BEC_2_5_4_LogicBool) bevt_16_tmpany_phold).bevi_bool) /* Line: 329 */ {
bevl_p = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-1738265524);
bevt_17_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevl_p);
bevl_jsi = bevt_17_tmpany_phold.bem_fileGet_0();
bevt_19_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-1045111996);
bevl_inc = (BEC_2_4_6_TextString) bevt_18_tmpany_phold.bemd_0(1103552481);
bevt_20_tmpany_phold = bevl_jsi.bem_readerGet_0();
bevt_20_tmpany_phold.bemd_0(-2056320704);
bevt_21_tmpany_phold = bem_countLines_1(bevl_inc);
bevp_lineCount.bevi_int += bevt_21_tmpany_phold.bevi_int;
bevp_shlibe.bem_write_1(bevl_inc);
} /* Line: 334 */
 else  /* Line: 329 */ {
break;
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 329 */
} /* Line: 328 */
return bevp_shlibe;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_finishLibOutput_1(BEC_3_2_4_6_IOFileWriter beva_libe) {
beva_libe.bem_close_0();
bevp_shlibe = null;
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_beginNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_libNs_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_endNs_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_klassDec_1(BEC_2_5_4_LogicBool beva_isFinal) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_9_BuildJSEmitter_bels_71));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_spropDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_propDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_initialDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_typeDecGet_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_baseSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_overrideSpropDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_37;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(beva_anyName);
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_38;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_typeName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_onceDec_2(BEC_2_4_6_TextString beva_typeName, BEC_2_4_6_TextString beva_anyName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getInitialInst_1(BEC_2_5_11_BuildClassConfig beva_newcc) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bevp_build.bem_libNameGet_0();
bevt_1_tmpany_phold = beva_newcc.bem_relEmitName_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_39;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_onceVarDec_1(BEC_2_4_6_TextString beva_count) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_4_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_40;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_41;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_count);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_10_BuildEmitCommon bem_startMethod_5(BEC_2_4_6_TextString beva_mtdDec, BEC_2_5_11_BuildClassConfig beva_returnType, BEC_2_4_6_TextString beva_mtdName, BEC_2_4_6_TextString beva_argDecs, BEC_2_6_6_SystemObject beva_exceptDec) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevt_3_tmpany_phold = bevp_classConf.bem_emitNameGet_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_9_BuildJSEmitter_bels_76));
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) bevt_2_tmpany_phold.bem_addValue_1(bevt_4_tmpany_phold);
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) bevt_1_tmpany_phold.bem_addValue_1(beva_mtdName);
bevt_5_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_9_BuildJSEmitter_bels_77));
bevt_0_tmpany_phold.bem_addValue_1(bevt_5_tmpany_phold);
bevp_methods.bem_addValue_1(beva_argDecs);
bevt_7_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_9_BuildJSEmitter_bels_13));
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) bevp_methods.bem_addValue_1(bevt_7_tmpany_phold);
bevt_6_tmpany_phold.bem_addValue_1(bevp_nl);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_formCast_2(BEC_2_5_11_BuildClassConfig beva_cc, BEC_2_4_6_TextString beva_type) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_9_BuildJSEmitter_bels_2));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_useDynMethodsGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_getFullEmitName_2(BEC_2_4_6_TextString beva_nameSpace, BEC_2_4_6_TextString beva_emitName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_5_9_BuildJSEmitter_bevo_42;
bevt_1_tmpany_phold = beva_nameSpace.bem_add_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_emitName);
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_4_6_TextString bem_getNameSpace_1(BEC_2_4_6_TextString beva_libName) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(2, bece_BEC_2_5_9_BuildJSEmitter_bels_79));
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public override BEC_2_5_11_BuildClassConfig bem_getLocalClassConfig_1(BEC_2_5_8_BuildNamePath beva_np) {
BEC_2_5_11_BuildClassConfig bevl_cc = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_cc = base.bem_getLocalClassConfig_1(beva_np);
bevt_0_tmpany_phold = bevl_cc.bem_fullEmitNameGet_0();
bevl_cc.bem_emitNameSet_1(bevt_0_tmpany_phold);
return bevl_cc;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGet_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_4_6_TextString bem_allOnceDecsGetDirect_0() {
return bevp_allOnceDecs;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_allOnceDecsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_allOnceDecs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGet_0() {
return bevp_shlibe;
} /*method end*/
public BEC_3_2_4_6_IOFileWriter bem_shlibeGetDirect_0() {
return bevp_shlibe;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildJSEmitter bem_shlibeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_shlibe = (BEC_3_2_4_6_IOFileWriter) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {16, 17, 18, 22, 24, 25, 27, 28, 32, 32, 32, 36, 36, 36, 36, 40, 40, 40, 40, 44, 44, 44, 44, 44, 44, 44, 44, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 55, 55, 55, 55, 55, 55, 55, 55, 55, 55, 63, 63, 63, 63, 63, 63, 63, 67, 67, 67, 67, 67, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 68, 70, 70, 70, 75, 75, 76, 78, 78, 78, 78, 80, 81, 0, 81, 81, 83, 85, 85, 87, 87, 87, 87, 87, 87, 91, 91, 91, 96, 96, 96, 97, 99, 99, 99, 99, 99, 102, 102, 102, 102, 104, 104, 104, 106, 106, 106, 106, 106, 109, 109, 109, 109, 109, 109, 111, 111, 111, 113, 118, 119, 120, 126, 126, 126, 131, 132, 132, 132, 132, 134, 134, 143, 145, 146, 147, 148, 148, 150, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 152, 154, 154, 154, 156, 156, 156, 156, 156, 156, 156, 156, 156, 162, 162, 162, 162, 162, 162, 163, 163, 163, 164, 164, 164, 164, 164, 164, 170, 172, 172, 0, 172, 172, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 179, 182, 182, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 188, 189, 192, 193, 193, 194, 196, 197, 197, 197, 197, 197, 197, 197, 198, 199, 199, 199, 201, 201, 201, 201, 201, 201, 201, 201, 202, 203, 204, 205, 206, 207, 207, 207, 208, 208, 208, 210, 212, 214, 215, 221, 224, 224, 224, 225, 225, 227, 227, 232, 232, 236, 236, 236, 236, 236, 236, 240, 240, 244, 244, 244, 244, 244, 244, 244, 245, 245, 245, 245, 245, 246, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 254, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 259, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 261, 265, 265, 266, 266, 266, 268, 268, 270, 270, 270, 270, 270, 278, 278, 278, 279, 280, 284, 284, 285, 285, 286, 286, 288, 290, 290, 290, 290, 290, 290, 290, 290, 290, 290, 290, 290, 292, 292, 292, 292, 292, 292, 292, 292, 292, 292, 292, 296, 297, 304, 304, 305, 307, 308, 308, 313, 313, 321, 321, 322, 323, 323, 323, 323, 323, 324, 324, 324, 326, 326, 326, 328, 328, 328, 329, 329, 329, 329, 0, 329, 329, 330, 330, 331, 331, 331, 332, 332, 333, 333, 334, 340, 344, 345, 350, 350, 354, 354, 358, 358, 362, 362, 366, 366, 370, 370, 374, 374, 379, 379, 385, 385, 390, 390, 394, 394, 394, 394, 394, 394, 398, 398, 402, 402, 402, 402, 402, 407, 407, 407, 407, 407, 407, 407, 412, 412, 412, 412, 412, 412, 412, 414, 416, 416, 416, 421, 421, 425, 425, 429, 429, 429, 429, 434, 434, 438, 439, 439, 440, 444, 445, 445, 446, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {138, 139, 140, 141, 142, 143, 144, 145, 151, 152, 153, 159, 160, 161, 162, 168, 169, 170, 171, 181, 182, 183, 184, 185, 186, 187, 188, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 241, 242, 243, 244, 245, 246, 247, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 307, 308, 309, 310, 311, 312, 313, 314, 315, 315, 318, 320, 322, 325, 326, 328, 329, 330, 331, 332, 333, 339, 340, 341, 369, 370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 404, 405, 406, 412, 413, 414, 423, 425, 426, 427, 428, 430, 431, 558, 559, 560, 561, 562, 565, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 610, 611, 612, 613, 614, 615, 623, 624, 625, 625, 628, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 668, 669, 670, 671, 672, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 704, 705, 706, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 722, 723, 724, 725, 726, 727, 729, 730, 731, 733, 743, 747, 748, 753, 754, 755, 757, 758, 764, 765, 773, 774, 775, 776, 777, 778, 782, 783, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 944, 949, 950, 951, 952, 955, 956, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 996, 997, 999, 1000, 1002, 1003, 1006, 1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1035, 1036, 1041, 1046, 1047, 1049, 1050, 1051, 1055, 1056, 1087, 1092, 1093, 1094, 1095, 1096, 1097, 1102, 1103, 1104, 1105, 1107, 1108, 1109, 1110, 1111, 1112, 1114, 1115, 1116, 1117, 1117, 1120, 1122, 1123, 1124, 1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1140, 1143, 1144, 1149, 1150, 1154, 1155, 1159, 1160, 1164, 1165, 1169, 1170, 1174, 1175, 1179, 1180, 1184, 1185, 1189, 1190, 1194, 1195, 1203, 1204, 1205, 1206, 1207, 1208, 1212, 1213, 1220, 1221, 1222, 1223, 1224, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1259, 1260, 1265, 1266, 1270, 1271, 1277, 1278, 1279, 1280, 1284, 1285, 1290, 1291, 1292, 1293, 1298, 1299, 1300, 1301, 1304, 1307, 1310, 1314, 1318, 1321, 1324, 1328};
/* BEGIN LINEINFO 
assign 1 16 138
new 0 16 138
assign 1 17 139
new 0 17 139
assign 1 18 140
new 0 18 140
new 1 22 141
assign 1 24 142
new 0 24 142
assign 1 25 143
new 0 25 143
assign 1 27 144
new 0 27 144
assign 1 28 145
new 0 28 145
assign 1 32 151
formTarg 1 32 151
assign 1 32 152
add 1 32 152
return 1 32 153
assign 1 36 159
formCallTarg 1 36 159
assign 1 36 160
new 0 36 160
assign 1 36 161
add 1 36 161
return 1 36 162
assign 1 40 168
formCallTarg 1 40 168
assign 1 40 169
new 0 40 169
assign 1 40 170
add 1 40 170
return 1 40 171
assign 1 44 181
new 0 44 181
assign 1 44 182
addValue 1 44 182
assign 1 44 183
secondGet 0 44 183
assign 1 44 184
formTarg 1 44 184
assign 1 44 185
addValue 1 44 185
assign 1 44 186
new 0 44 186
assign 1 44 187
addValue 1 44 187
addValue 1 44 188
assign 1 48 209
new 0 48 209
assign 1 48 210
toString 0 48 210
assign 1 48 211
add 1 48 211
incrementValue 0 49 212
assign 1 50 213
new 0 50 213
assign 1 50 214
addValue 1 50 214
assign 1 50 215
addValue 1 50 215
assign 1 50 216
new 0 50 216
assign 1 50 217
addValue 1 50 217
addValue 1 50 218
assign 1 55 219
containedGet 0 55 219
assign 1 55 220
firstGet 0 55 220
assign 1 55 221
containedGet 0 55 221
assign 1 55 222
firstGet 0 55 222
assign 1 55 223
new 0 55 223
assign 1 55 224
add 1 55 224
assign 1 55 225
new 0 55 225
assign 1 55 226
add 1 55 226
assign 1 55 227
finalAssign 4 55 227
addValue 1 55 228
assign 1 63 241
emitNameGet 0 63 241
assign 1 63 242
addValue 1 63 242
assign 1 63 243
new 0 63 243
assign 1 63 244
addValue 1 63 244
assign 1 63 245
addValue 1 63 245
assign 1 63 246
new 0 63 246
addValue 1 63 247
assign 1 67 267
emitNameGet 0 67 267
assign 1 67 268
addValue 1 67 268
assign 1 67 269
new 0 67 269
assign 1 67 270
addValue 1 67 270
addValue 1 67 271
assign 1 68 272
new 0 68 272
assign 1 68 273
addValue 1 68 273
assign 1 68 274
heldGet 0 68 274
assign 1 68 275
namepathGet 0 68 275
assign 1 68 276
getClassConfig 1 68 276
assign 1 68 277
libNameGet 0 68 277
assign 1 68 278
relEmitName 1 68 278
assign 1 68 279
addValue 1 68 279
assign 1 68 280
new 0 68 280
assign 1 68 281
addValue 1 68 281
addValue 1 68 282
assign 1 70 283
new 0 70 283
assign 1 70 284
addValue 1 70 284
addValue 1 70 285
assign 1 75 307
heldGet 0 75 307
assign 1 75 308
synGet 0 75 308
assign 1 76 309
ptyListGet 0 76 309
assign 1 78 310
emitNameGet 0 78 310
assign 1 78 311
addValue 1 78 311
assign 1 78 312
new 0 78 312
addValue 1 78 313
assign 1 80 314
new 0 80 314
assign 1 81 315
iteratorGet 0 0 315
assign 1 81 318
hasNextGet 0 81 318
assign 1 81 320
nextGet 0 81 320
assign 1 83 322
new 0 83 322
assign 1 85 325
new 0 85 325
addValue 1 85 326
assign 1 87 328
addValue 1 87 328
assign 1 87 329
new 0 87 329
assign 1 87 330
addValue 1 87 330
assign 1 87 331
nameGet 0 87 331
assign 1 87 332
addValue 1 87 332
addValue 1 87 333
assign 1 91 339
new 0 91 339
assign 1 91 340
addValue 1 91 340
addValue 1 91 341
assign 1 96 369
heldGet 0 96 369
assign 1 96 370
namepathGet 0 96 370
assign 1 96 371
getClassConfig 1 96 371
assign 1 97 372
getInitialInst 1 97 372
assign 1 99 373
emitNameGet 0 99 373
assign 1 99 374
addValue 1 99 374
assign 1 99 375
new 0 99 375
assign 1 99 376
addValue 1 99 376
addValue 1 99 377
assign 1 102 378
addValue 1 102 378
assign 1 102 379
new 0 102 379
assign 1 102 380
addValue 1 102 380
addValue 1 102 381
assign 1 104 382
new 0 104 382
assign 1 104 383
addValue 1 104 383
addValue 1 104 384
assign 1 106 385
emitNameGet 0 106 385
assign 1 106 386
addValue 1 106 386
assign 1 106 387
new 0 106 387
assign 1 106 388
addValue 1 106 388
addValue 1 106 389
assign 1 109 390
new 0 109 390
assign 1 109 391
addValue 1 109 391
assign 1 109 392
addValue 1 109 392
assign 1 109 393
new 0 109 393
assign 1 109 394
addValue 1 109 394
addValue 1 109 395
assign 1 111 396
new 0 111 396
assign 1 111 397
addValue 1 111 397
addValue 1 111 398
buildPropList 0 113 399
getCode 2 118 404
assign 1 119 405
toString 0 119 405
addValue 1 120 406
assign 1 126 412
new 0 126 412
assign 1 126 413
addValue 1 126 413
addValue 1 126 414
assign 1 131 423
isPropertyGet 0 131 423
assign 1 132 425
new 0 132 425
assign 1 132 426
nameGet 0 132 426
assign 1 132 427
add 1 132 427
return 1 132 428
assign 1 134 430
nameForVar 1 134 430
return 1 134 431
assign 1 143 558
getLibOutput 0 143 558
assign 1 145 559
new 0 145 559
assign 1 146 560
new 0 146 560
assign 1 147 561
new 0 147 561
assign 1 148 562
iteratorGet 0 148 562
assign 1 148 565
hasNextGet 0 148 565
assign 1 150 567
nextGet 0 150 567
assign 1 152 568
new 0 152 568
assign 1 152 569
addValue 1 152 569
assign 1 152 570
addValue 1 152 570
assign 1 152 571
heldGet 0 152 571
assign 1 152 572
namepathGet 0 152 572
assign 1 152 573
toString 0 152 573
assign 1 152 574
addValue 1 152 574
assign 1 152 575
addValue 1 152 575
assign 1 152 576
new 0 152 576
assign 1 152 577
addValue 1 152 577
assign 1 152 578
heldGet 0 152 578
assign 1 152 579
namepathGet 0 152 579
assign 1 152 580
getClassConfig 1 152 580
assign 1 152 581
libNameGet 0 152 581
assign 1 152 582
relEmitName 1 152 582
assign 1 152 583
addValue 1 152 583
assign 1 152 584
new 0 152 584
assign 1 152 585
addValue 1 152 585
addValue 1 152 586
assign 1 154 587
heldGet 0 154 587
assign 1 154 588
synGet 0 154 588
assign 1 154 589
hasDefaultGet 0 154 589
assign 1 156 591
new 0 156 591
assign 1 156 592
heldGet 0 156 592
assign 1 156 593
namepathGet 0 156 593
assign 1 156 594
getClassConfig 1 156 594
assign 1 156 595
libNameGet 0 156 595
assign 1 156 596
relEmitName 1 156 596
assign 1 156 597
add 1 156 597
assign 1 156 598
new 0 156 598
assign 1 156 599
add 1 156 599
assign 1 162 600
new 0 162 600
assign 1 162 601
addValue 1 162 601
assign 1 162 602
addValue 1 162 602
assign 1 162 603
new 0 162 603
assign 1 162 604
addValue 1 162 604
addValue 1 162 605
assign 1 163 606
heldGet 0 163 606
assign 1 163 607
synGet 0 163 607
assign 1 163 608
hasDefaultGet 0 163 608
assign 1 164 610
new 0 164 610
assign 1 164 611
addValue 1 164 611
assign 1 164 612
addValue 1 164 612
assign 1 164 613
new 0 164 613
assign 1 164 614
addValue 1 164 614
addValue 1 164 615
assign 1 170 623
new 0 170 623
assign 1 172 624
keysGet 0 172 624
assign 1 172 625
iteratorGet 0 0 625
assign 1 172 628
hasNextGet 0 172 628
assign 1 172 630
nextGet 0 172 630
assign 1 174 631
new 0 174 631
assign 1 174 632
addValue 1 174 632
assign 1 174 633
new 0 174 633
assign 1 174 634
quoteGet 0 174 634
assign 1 174 635
addValue 1 174 635
assign 1 174 636
addValue 1 174 636
assign 1 174 637
new 0 174 637
assign 1 174 638
quoteGet 0 174 638
assign 1 174 639
addValue 1 174 639
assign 1 174 640
new 0 174 640
assign 1 174 641
addValue 1 174 641
assign 1 174 642
get 1 174 642
assign 1 174 643
addValue 1 174 643
assign 1 174 644
new 0 174 644
assign 1 174 645
addValue 1 174 645
addValue 1 174 646
assign 1 175 647
new 0 175 647
assign 1 175 648
addValue 1 175 648
assign 1 175 649
new 0 175 649
assign 1 175 650
quoteGet 0 175 650
assign 1 175 651
addValue 1 175 651
assign 1 175 652
addValue 1 175 652
assign 1 175 653
new 0 175 653
assign 1 175 654
quoteGet 0 175 654
assign 1 175 655
addValue 1 175 655
assign 1 175 656
new 0 175 656
assign 1 175 657
addValue 1 175 657
assign 1 175 658
get 1 175 658
assign 1 175 659
addValue 1 175 659
assign 1 175 660
new 0 175 660
assign 1 175 661
addValue 1 175 661
addValue 1 175 662
write 1 179 668
assign 1 182 669
usedLibrarysGet 0 182 669
assign 1 182 670
sizeGet 0 182 670
assign 1 182 671
new 0 182 671
assign 1 182 672
equals 1 182 677
assign 1 183 678
new 0 183 678
assign 1 183 679
addValue 1 183 679
addValue 1 183 680
assign 1 184 681
new 0 184 681
assign 1 184 682
addValue 1 184 682
addValue 1 184 683
assign 1 185 684
new 0 185 684
assign 1 185 685
addValue 1 185 685
addValue 1 185 686
write 1 188 688
write 1 189 689
assign 1 192 690
new 0 192 690
assign 1 193 691
mainNameGet 0 193 691
fromString 1 193 692
assign 1 194 693
getClassConfig 1 194 693
assign 1 196 694
new 0 196 694
assign 1 197 695
new 0 197 695
assign 1 197 696
addValue 1 197 696
assign 1 197 697
fullEmitNameGet 0 197 697
assign 1 197 698
addValue 1 197 698
assign 1 197 699
new 0 197 699
assign 1 197 700
addValue 1 197 700
addValue 1 197 701
assign 1 198 702
ownProcessGet 0 198 702
assign 1 199 704
new 0 199 704
assign 1 199 705
addValue 1 199 705
addValue 1 199 706
assign 1 201 708
new 0 201 708
assign 1 201 709
addValue 1 201 709
assign 1 201 710
outputPlatformGet 0 201 710
assign 1 201 711
nameGet 0 201 711
assign 1 201 712
addValue 1 201 712
assign 1 201 713
new 0 201 713
assign 1 201 714
addValue 1 201 714
addValue 1 201 715
write 1 202 716
assign 1 203 717
new 0 203 717
write 1 204 718
write 1 205 719
assign 1 206 720
ownProcessGet 0 206 720
assign 1 207 722
new 0 207 722
assign 1 207 723
addValue 1 207 723
addValue 1 207 724
assign 1 208 725
new 0 208 725
assign 1 208 726
addValue 1 208 726
addValue 1 208 727
write 1 210 729
finishLibOutput 1 212 730
assign 1 214 731
saveSynsGet 0 214 731
saveSyns 0 215 733
assign 1 221 743
isPropertyGet 0 221 743
assign 1 224 747
isArgGet 0 224 747
assign 1 224 748
not 0 224 753
assign 1 225 754
new 0 225 754
addValue 1 225 755
assign 1 227 757
nameForVar 1 227 757
addValue 1 227 758
assign 1 232 764
new 0 232 764
return 1 232 765
assign 1 236 773
new 0 236 773
assign 1 236 774
add 1 236 774
assign 1 236 775
new 0 236 775
assign 1 236 776
add 1 236 776
assign 1 236 777
add 1 236 777
return 1 236 778
assign 1 240 782
new 0 240 782
return 1 240 783
assign 1 244 797
emitNameGet 0 244 797
assign 1 244 798
new 0 244 798
assign 1 244 799
add 1 244 799
assign 1 244 800
add 1 244 800
assign 1 244 801
new 0 244 801
assign 1 244 802
add 1 244 802
assign 1 244 803
addValue 1 244 803
assign 1 245 804
emitNameGet 0 245 804
assign 1 245 805
add 1 245 805
assign 1 245 806
new 0 245 806
assign 1 245 807
add 1 245 807
assign 1 245 808
addValue 1 245 808
return 1 246 809
assign 1 250 823
new 0 250 823
assign 1 250 824
libNameGet 0 250 824
assign 1 250 825
relEmitName 1 250 825
assign 1 250 826
add 1 250 826
assign 1 250 827
new 0 250 827
assign 1 250 828
add 1 250 828
assign 1 250 829
heldGet 0 250 829
assign 1 250 830
literalValueGet 0 250 830
assign 1 250 831
add 1 250 831
assign 1 250 832
new 0 250 832
assign 1 250 833
add 1 250 833
return 1 250 834
assign 1 254 848
new 0 254 848
assign 1 254 849
libNameGet 0 254 849
assign 1 254 850
relEmitName 1 254 850
assign 1 254 851
add 1 254 851
assign 1 254 852
new 0 254 852
assign 1 254 853
add 1 254 853
assign 1 254 854
heldGet 0 254 854
assign 1 254 855
literalValueGet 0 254 855
assign 1 254 856
add 1 254 856
assign 1 254 857
new 0 254 857
assign 1 254 858
add 1 254 858
return 1 254 859
assign 1 259 895
new 0 259 895
assign 1 259 896
libNameGet 0 259 896
assign 1 259 897
relEmitName 1 259 897
assign 1 259 898
add 1 259 898
assign 1 259 899
new 0 259 899
assign 1 259 900
add 1 259 900
assign 1 259 901
emitNameGet 0 259 901
assign 1 259 902
add 1 259 902
assign 1 259 903
new 0 259 903
assign 1 259 904
add 1 259 904
assign 1 259 905
add 1 259 905
assign 1 259 906
new 0 259 906
assign 1 259 907
add 1 259 907
assign 1 259 908
add 1 259 908
assign 1 259 909
new 0 259 909
assign 1 259 910
add 1 259 910
return 1 259 911
assign 1 261 913
new 0 261 913
assign 1 261 914
libNameGet 0 261 914
assign 1 261 915
relEmitName 1 261 915
assign 1 261 916
add 1 261 916
assign 1 261 917
new 0 261 917
assign 1 261 918
add 1 261 918
assign 1 261 919
emitNameGet 0 261 919
assign 1 261 920
add 1 261 920
assign 1 261 921
new 0 261 921
assign 1 261 922
add 1 261 922
assign 1 261 923
add 1 261 923
assign 1 261 924
new 0 261 924
assign 1 261 925
add 1 261 925
assign 1 261 926
add 1 261 926
assign 1 261 927
new 0 261 927
assign 1 261 928
add 1 261 928
return 1 261 929
assign 1 265 944
def 1 265 949
assign 1 266 950
libNameGet 0 266 950
assign 1 266 951
relEmitName 1 266 951
assign 1 266 952
extend 1 266 952
assign 1 268 955
new 0 268 955
assign 1 268 956
extend 1 268 956
assign 1 270 958
new 0 270 958
assign 1 270 959
emitNameGet 0 270 959
assign 1 270 960
addValue 1 270 960
assign 1 270 961
new 0 270 961
assign 1 270 962
addValue 1 270 962
assign 1 278 963
new 0 278 963
assign 1 278 964
addValue 1 278 964
addValue 1 278 965
addValue 1 279 966
return 1 280 967
assign 1 284 996
heldGet 0 284 996
assign 1 284 997
superCallGet 0 284 997
assign 1 285 999
new 0 285 999
assign 1 285 1000
notEmpty 1 285 1000
assign 1 286 1002
new 0 286 1002
assign 1 286 1003
add 1 286 1003
assign 1 288 1006
new 0 288 1006
assign 1 290 1008
emitNameGet 0 290 1008
assign 1 290 1009
new 0 290 1009
assign 1 290 1010
add 1 290 1010
assign 1 290 1011
heldGet 0 290 1011
assign 1 290 1012
nameGet 0 290 1012
assign 1 290 1013
add 1 290 1013
assign 1 290 1014
new 0 290 1014
assign 1 290 1015
add 1 290 1015
assign 1 290 1016
add 1 290 1016
assign 1 290 1017
new 0 290 1017
assign 1 290 1018
add 1 290 1018
return 1 290 1019
assign 1 292 1021
new 0 292 1021
assign 1 292 1022
add 1 292 1022
assign 1 292 1023
heldGet 0 292 1023
assign 1 292 1024
nameGet 0 292 1024
assign 1 292 1025
add 1 292 1025
assign 1 292 1026
new 0 292 1026
assign 1 292 1027
add 1 292 1027
assign 1 292 1028
add 1 292 1028
assign 1 292 1029
new 0 292 1029
assign 1 292 1030
add 1 292 1030
return 1 292 1031
assign 1 296 1035
new 0 296 1035
return 1 297 1036
assign 1 304 1041
undef 1 304 1046
assign 1 305 1047
new 0 305 1047
addValue 1 307 1049
assign 1 308 1050
new 0 308 1050
return 1 308 1051
assign 1 313 1055
getLibOutput 0 313 1055
return 1 313 1056
assign 1 321 1087
undef 1 321 1092
assign 1 322 1093
new 0 322 1093
assign 1 323 1094
parentGet 0 323 1094
assign 1 323 1095
fileGet 0 323 1095
assign 1 323 1096
existsGet 0 323 1096
assign 1 323 1097
not 0 323 1102
assign 1 324 1103
parentGet 0 324 1103
assign 1 324 1104
fileGet 0 324 1104
makeDirs 0 324 1105
assign 1 326 1107
fileGet 0 326 1107
assign 1 326 1108
writerGet 0 326 1108
assign 1 326 1109
open 0 326 1109
assign 1 328 1110
paramsGet 0 328 1110
assign 1 328 1111
new 0 328 1111
assign 1 328 1112
has 1 328 1112
assign 1 329 1114
paramsGet 0 329 1114
assign 1 329 1115
new 0 329 1115
assign 1 329 1116
get 1 329 1116
assign 1 329 1117
iteratorGet 0 0 1117
assign 1 329 1120
hasNextGet 0 329 1120
assign 1 329 1122
nextGet 0 329 1122
assign 1 330 1123
apNew 1 330 1123
assign 1 330 1124
fileGet 0 330 1124
assign 1 331 1125
readerGet 0 331 1125
assign 1 331 1126
open 0 331 1126
assign 1 331 1127
readString 0 331 1127
assign 1 332 1128
readerGet 0 332 1128
close 0 332 1129
assign 1 333 1130
countLines 1 333 1130
addValue 1 333 1131
write 1 334 1132
return 1 340 1140
close 0 344 1143
assign 1 345 1144
assign 1 350 1149
new 0 350 1149
return 1 350 1150
assign 1 354 1154
new 0 354 1154
return 1 354 1155
assign 1 358 1159
new 0 358 1159
return 1 358 1160
assign 1 362 1164
new 0 362 1164
return 1 362 1165
assign 1 366 1169
new 0 366 1169
return 1 366 1170
assign 1 370 1174
new 0 370 1174
return 1 370 1175
assign 1 374 1179
new 0 374 1179
return 1 374 1180
assign 1 379 1184
new 0 379 1184
return 1 379 1185
assign 1 385 1189
new 0 385 1189
return 1 385 1190
assign 1 390 1194
new 0 390 1194
return 1 390 1195
assign 1 394 1203
new 0 394 1203
assign 1 394 1204
add 1 394 1204
assign 1 394 1205
new 0 394 1205
assign 1 394 1206
add 1 394 1206
assign 1 394 1207
add 1 394 1207
return 1 394 1208
assign 1 398 1212
new 0 398 1212
return 1 398 1213
assign 1 402 1220
libNameGet 0 402 1220
assign 1 402 1221
relEmitName 1 402 1221
assign 1 402 1222
new 0 402 1222
assign 1 402 1223
add 1 402 1223
return 1 402 1224
assign 1 407 1233
emitNameGet 0 407 1233
assign 1 407 1234
new 0 407 1234
assign 1 407 1235
add 1 407 1235
assign 1 407 1236
new 0 407 1236
assign 1 407 1237
add 1 407 1237
assign 1 407 1238
add 1 407 1238
return 1 407 1239
assign 1 412 1250
emitNameGet 0 412 1250
assign 1 412 1251
addValue 1 412 1251
assign 1 412 1252
new 0 412 1252
assign 1 412 1253
addValue 1 412 1253
assign 1 412 1254
addValue 1 412 1254
assign 1 412 1255
new 0 412 1255
addValue 1 412 1256
addValue 1 414 1257
assign 1 416 1258
new 0 416 1258
assign 1 416 1259
addValue 1 416 1259
addValue 1 416 1260
assign 1 421 1265
new 0 421 1265
return 1 421 1266
assign 1 425 1270
new 0 425 1270
return 1 425 1271
assign 1 429 1277
new 0 429 1277
assign 1 429 1278
add 1 429 1278
assign 1 429 1279
add 1 429 1279
return 1 429 1280
assign 1 434 1284
new 0 434 1284
return 1 434 1285
assign 1 438 1290
getClassConfig 1 438 1290
assign 1 439 1291
fullEmitNameGet 0 439 1291
emitNameSet 1 439 1292
return 1 440 1293
assign 1 444 1298
getLocalClassConfig 1 444 1298
assign 1 445 1299
fullEmitNameGet 0 445 1299
emitNameSet 1 445 1300
return 1 446 1301
return 1 0 1304
return 1 0 1307
assign 1 0 1310
assign 1 0 1314
return 1 0 1318
return 1 0 1321
assign 1 0 1324
assign 1 0 1328
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1578752349: return bem_superCallsGet_0();
case -132394584: return bem_gcMarksGetDirect_0();
case -184536522: return bem_methodCatchGetDirect_0();
case -214204552: return bem_objectCcGetDirect_0();
case 1182573638: return bem_lineCountGet_0();
case -122891338: return bem_lastMethodBodyLinesGet_0();
case 396478404: return bem_nullValueGet_0();
case -1073864238: return bem_buildCreate_0();
case 402341494: return bem_methodBodyGetDirect_0();
case 1402840917: return bem_qGetDirect_0();
case 1076606196: return bem_classConfGetDirect_0();
case 835349186: return bem_lastMethodBodySizeGetDirect_0();
case -478321755: return bem_boolCcGetDirect_0();
case -1868291768: return bem_exceptDecGetDirect_0();
case 773963565: return bem_emitLib_0();
case -1062777262: return bem_boolNpGet_0();
case 1577195459: return bem_serializationIteratorGet_0();
case 14754526: return bem_allOnceDecsGetDirect_0();
case 765877792: return bem_randGet_0();
case -420649750: return bem_libEmitPathGetDirect_0();
case 341575045: return bem_many_0();
case -454237579: return bem_lineCountGetDirect_0();
case -1123278056: return bem_tagGet_0();
case 1507551114: return bem_libEmitNameGetDirect_0();
case -31498839: return bem_falseValueGetDirect_0();
case -336284530: return bem_emitLangGet_0();
case -2082769495: return bem_nlGetDirect_0();
case -813800834: return bem_belslitsGetDirect_0();
case -622702543: return bem_nameToIdPathGetDirect_0();
case -713163994: return bem_toAny_0();
case -1086782351: return bem_print_0();
case 932492845: return bem_parentConfGetDirect_0();
case -369320135: return bem_lastMethodBodyLinesGetDirect_0();
case -1059184096: return bem_inFilePathedGetDirect_0();
case -2099367318: return bem_covariantReturnsGet_0();
case -1266447496: return bem_classNameGet_0();
case 747350866: return bem_nativeCSlotsGetDirect_0();
case -10010145: return bem_copy_0();
case -317018644: return bem_smnlcsGet_0();
case 1747470980: return bem_runtimeInitGet_0();
case 1612580804: return bem_lastCallGet_0();
case -204256404: return bem_typeDecGet_0();
case -1685240182: return bem_shlibeGetDirect_0();
case 44569738: return bem_buildInitial_0();
case -442958039: return bem_onceDecsGetDirect_0();
case -1940333070: return bem_instanceNotEqualGetDirect_0();
case -504842964: return bem_endNs_0();
case -2126174019: return bem_overrideMtdDecGet_0();
case 637264206: return bem_nlGet_0();
case 282905452: return bem_parentConfGet_0();
case -2051518290: return bem_once_0();
case -1216448909: return bem_fullLibEmitNameGet_0();
case -706489572: return bem_spropDecGet_0();
case -1952046034: return bem_beginNs_0();
case 1683842908: return bem_mnodeGet_0();
case 96033137: return bem_serializeToString_0();
case -985646934: return bem_methodsGetDirect_0();
case 1676322853: return bem_preClassGet_0();
case 1111339989: return bem_instanceEqualGetDirect_0();
case -1470044496: return bem_intNpGet_0();
case 1304840881: return bem_classesInDepthOrderGet_0();
case 1801876218: return bem_mainStartGet_0();
case 1162304104: return bem_libEmitNameGet_0();
case 1486588983: return bem_nativeCSlotsGet_0();
case -1765925991: return bem_idToNamePathGetDirect_0();
case -1588104394: return bem_cnodeGetDirect_0();
case 1942283510: return bem_sourceFileNameGet_0();
case -212842115: return bem_smnlecsGetDirect_0();
case 407367788: return bem_onceCountGet_0();
case 1320546996: return bem_preClassOutput_0();
case 1851908877: return bem_hashGet_0();
case 869557719: return bem_propertyDecsGetDirect_0();
case 1193197051: return bem_ntypesGet_0();
case 1006271437: return bem_msynGetDirect_0();
case 209874246: return bem_nameToIdGet_0();
case -370719028: return bem_instOfGet_0();
case -832882259: return bem_scvpGet_0();
case 347266937: return bem_ccCacheGetDirect_0();
case 379656857: return bem_scvpGetDirect_0();
case 732697998: return bem_idToNamePathGet_0();
case 1163216647: return bem_fileExtGet_0();
case 699017196: return bem_boolCcGet_0();
case -1298453047: return bem_buildGet_0();
case -2068363357: return bem_methodCallsGetDirect_0();
case 1541400520: return bem_idToNameGet_0();
case 15402397: return bem_objectNpGetDirect_0();
case -480726674: return bem_csynGetDirect_0();
case 1126288320: return bem_smnlcsGetDirect_0();
case -1999164817: return bem_transGetDirect_0();
case -1444157789: return bem_nullValueGetDirect_0();
case 389653078: return bem_floatNpGet_0();
case 245459276: return bem_newDecGet_0();
case -1053283121: return bem_methodBodyGet_0();
case -1410576775: return bem_superCallsGetDirect_0();
case -1437070352: return bem_libEmitPathGet_0();
case 611670694: return bem_fieldIteratorGet_0();
case 85992302: return bem_gcMarksGet_0();
case 257325317: return bem_lastCallGetDirect_0();
case -1546971192: return bem_invpGetDirect_0();
case -189437710: return bem_buildPropList_0();
case -418642594: return bem_classEndGet_0();
case 1076775546: return bem_preClassGetDirect_0();
case 771723657: return bem_propDecGet_0();
case -44338819: return bem_synEmitPathGetDirect_0();
case 1521848686: return bem_baseMtdDecGet_0();
case -1300057562: return bem_csynGet_0();
case 360251852: return bem_shlibeGet_0();
case 894734870: return bem_inClassGetDirect_0();
case -711116787: return bem_maxDynArgsGet_0();
case 1726004327: return bem_methodCatchGet_0();
case 990360647: return bem_new_0();
case 379358518: return bem_lastMethodsSizeGetDirect_0();
case -1607079592: return bem_smnlecsGet_0();
case 1369882092: return bem_onceCountGetDirect_0();
case -210315029: return bem_lastMethodBodySizeGet_0();
case -1535565120: return bem_nameToIdPathGet_0();
case -87470459: return bem_methodCallsGet_0();
case 887361644: return bem_fullLibEmitNameGetDirect_0();
case -1228184212: return bem_trueValueGet_0();
case 1205271118: return bem_floatNpGetDirect_0();
case 1859124881: return bem_instOfGetDirect_0();
case 2142754364: return bem_classEmitsGet_0();
case 693568227: return bem_lastMethodsLinesGetDirect_0();
case 403157348: return bem_exceptDecGet_0();
case 1001628229: return bem_initialDecGet_0();
case -1312922573: return bem_objectNpGet_0();
case -1909223916: return bem_randGetDirect_0();
case -1171583728: return bem_methodsGet_0();
case -1609070142: return bem_buildClassInfo_0();
case 1576999707: return bem_fileExtGetDirect_0();
case -777448052: return bem_emitLangGetDirect_0();
case 1355561260: return bem_nameToIdGetDirect_0();
case -511820512: return bem_synEmitPathGet_0();
case -1619538614: return bem_saveSyns_0();
case 114962970: return bem_doEmit_0();
case -787237766: return bem_getClassOutput_0();
case -757722908: return bem_classConfGet_0();
case -42869477: return bem_falseValueGet_0();
case -385502167: return bem_classCallsGetDirect_0();
case 1049178746: return bem_qGet_0();
case 1139700098: return bem_transGet_0();
case -1109932284: return bem_mainEndGet_0();
case 731309399: return bem_afterCast_0();
case 1603413876: return bem_msynGet_0();
case 1079791851: return bem_classesInDepthOrderGetDirect_0();
case -2056406479: return bem_stringNpGet_0();
case 144584723: return bem_create_0();
case -816706481: return bem_cnodeGet_0();
case 1179490652: return bem_maxDynArgsGetDirect_0();
case 17847137: return bem_allOnceDecsGet_0();
case 1860736480: return bem_constGetDirect_0();
case -1233955270: return bem_dynMethodsGetDirect_0();
case 502604059: return bem_returnTypeGetDirect_0();
case 44008059: return bem_writeBET_0();
case 984259789: return bem_boolTypeGet_0();
case -610767888: return bem_dynMethodsGet_0();
case 508154468: return bem_instanceEqualGet_0();
case 2039882608: return bem_ccMethodsGet_0();
case 532445272: return bem_inClassGet_0();
case -1993157878: return bem_ntypesGetDirect_0();
case -910988398: return bem_classEmitsGetDirect_0();
case -763786472: return bem_boolNpGetDirect_0();
case 934001470: return bem_objectCcGet_0();
case 1823315786: return bem_ccMethodsGetDirect_0();
case 1271376725: return bem_getLibOutput_0();
case 1647816832: return bem_callNamesGet_0();
case 1194804327: return bem_fieldNamesGet_0();
case -1977352474: return bem_mainOutsideNsGet_0();
case -623366174: return bem_ccCacheGet_0();
case -1894930378: return bem_onceDecsGet_0();
case -1114977715: return bem_constGet_0();
case -116860886: return bem_mnodeGetDirect_0();
case 1315612761: return bem_intNpGetDirect_0();
case -1622521468: return bem_lastMethodsSizeGet_0();
case 1513233059: return bem_toString_0();
case 1327285718: return bem_belslitsGet_0();
case 684312943: return bem_inFilePathedGet_0();
case -1362850090: return bem_serializeContents_0();
case -248170874: return bem_invpGet_0();
case -209472074: return bem_maxSpillArgsLenGetDirect_0();
case 1225278041: return bem_stringNpGetDirect_0();
case 1469223802: return bem_callNamesGetDirect_0();
case -660368452: return bem_classCallsGet_0();
case -104403161: return bem_loadIds_0();
case 1071461198: return bem_echo_0();
case -1061498667: return bem_superNameGet_0();
case -130364354: return bem_idToNameGetDirect_0();
case -414785750: return bem_useDynMethodsGet_0();
case 1308326065: return bem_saveIds_0();
case 1914942654: return bem_deserializeClassNameGet_0();
case 200095578: return bem_trueValueGetDirect_0();
case -449079106: return bem_iteratorGet_0();
case -339817320: return bem_instanceNotEqualGet_0();
case 964129689: return bem_baseSmtdDecGet_0();
case -623500174: return bem_lastMethodsLinesGet_0();
case 443668781: return bem_propertyDecsGet_0();
case 665679587: return bem_returnTypeGet_0();
case 1739543710: return bem_mainInClassGet_0();
case 936251957: return bem_buildGetDirect_0();
case -141585115: return bem_maxSpillArgsLenGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1966059311: return bem_superCallsSet_1(bevd_0);
case 1375494165: return bem_libEmitNameSet_1(bevd_0);
case -765291421: return bem_propertyDecsSetDirect_1(bevd_0);
case 29346616: return bem_lastMethodsLinesSetDirect_1(bevd_0);
case -2129277976: return bem_libEmitPathSet_1(bevd_0);
case -735549421: return bem_returnTypeSet_1(bevd_0);
case -1071001840: return bem_new_1((BEC_2_5_5_BuildBuild) bevd_0);
case 618439670: return bem_preClassSetDirect_1(bevd_0);
case 1673046369: return bem_csynSetDirect_1(bevd_0);
case 1440239300: return bem_belslitsSet_1(bevd_0);
case -19524766: return bem_emitLangSetDirect_1(bevd_0);
case -2093050870: return bem_formBoolTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case -478468566: return bem_scvpSet_1(bevd_0);
case -977770464: return bem_trueValueSetDirect_1(bevd_0);
case 1222154172: return bem_inFilePathedSet_1(bevd_0);
case -1575442379: return bem_floatNpSetDirect_1(bevd_0);
case -918437161: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1839965950: return bem_extend_1((BEC_2_4_6_TextString) bevd_0);
case -390319261: return bem_equals_1(bevd_0);
case -1425015314: return bem_methodBodySetDirect_1(bevd_0);
case -1272792662: return bem_exceptDecSetDirect_1(bevd_0);
case -1436296903: return bem_fullLibEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 2016964848: return bem_libEmitNameSetDirect_1(bevd_0);
case -312679344: return bem_nameForVar_1((BEC_2_5_3_BuildVar) bevd_0);
case 2104655978: return bem_instanceNotEqualSet_1(bevd_0);
case 1523143690: return bem_countLines_1((BEC_2_4_6_TextString) bevd_0);
case -1700487776: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -253694439: return bem_formTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 342584641: return bem_fullLibEmitNameSetDirect_1(bevd_0);
case 2074141809: return bem_acceptIf_1((BEC_2_5_4_BuildNode) bevd_0);
case -72144144: return bem_acceptEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 1579221998: return bem_qSetDirect_1(bevd_0);
case -534989708: return bem_nlSetDirect_1(bevd_0);
case 1165172214: return bem_stringNpSet_1(bevd_0);
case 1185359129: return bem_smnlcsSetDirect_1(bevd_0);
case 1931596767: return bem_startClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -751596479: return bem_instanceEqualSetDirect_1(bevd_0);
case -2129391475: return bem_finishClassOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case 1463568798: return bem_intNpSetDirect_1(bevd_0);
case -1549759476: return bem_fullLibEmitNameSet_1(bevd_0);
case -1938964126: return bem_acceptBraces_1((BEC_2_5_4_BuildNode) bevd_0);
case -1641804421: return bem_sameType_1(bevd_0);
case -1876472922: return bem_smnlecsSet_1(bevd_0);
case 2063174374: return bem_undefined_1(bevd_0);
case -1517889270: return bem_sameObject_1(bevd_0);
case 77336253: return bem_buildStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 873892036: return bem_intNpSet_1(bevd_0);
case -584397764: return bem_csynSet_1(bevd_0);
case -923758196: return bem_boolCcSet_1(bevd_0);
case -1666737542: return bem_getInitialInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -1279482267: return bem_allOnceDecsSet_1(bevd_0);
case -497312533: return bem_scvpSetDirect_1(bevd_0);
case -850839296: return bem_lastCallSet_1(bevd_0);
case -364649010: return bem_addClassHeader_1((BEC_2_4_6_TextString) bevd_0);
case -1204315827: return bem_idToNameSet_1(bevd_0);
case 583073200: return bem_acceptCatch_1((BEC_2_5_4_BuildNode) bevd_0);
case 631470326: return bem_overrideMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case -1485209279: return bem_maxSpillArgsLenSetDirect_1(bevd_0);
case -1160533106: return bem_mnodeSetDirect_1(bevd_0);
case -1137696884: return bem_libEmitName_1((BEC_2_4_6_TextString) bevd_0);
case 139102551: return bem_boolCcSetDirect_1(bevd_0);
case -677011010: return bem_randSetDirect_1(bevd_0);
case -2146317269: return bem_otherType_1(bevd_0);
case -1963646313: return bem_objectCcSet_1(bevd_0);
case 1449340032: return bem_otherClass_1(bevd_0);
case 812295678: return bem_invpSet_1(bevd_0);
case 1799680711: return bem_synEmitPathSetDirect_1(bevd_0);
case 1993008591: return bem_undef_1(bevd_0);
case 1375043096: return bem_allOnceDecsSetDirect_1(bevd_0);
case -608257616: return bem_constSetDirect_1(bevd_0);
case -1413169437: return bem_acceptClass_1((BEC_2_5_4_BuildNode) bevd_0);
case -1944037126: return bem_lastCallSetDirect_1(bevd_0);
case 422384913: return bem_end_1(bevd_0);
case -200065239: return bem_shlibeSet_1(bevd_0);
case -131518903: return bem_nlSet_1(bevd_0);
case 1849958179: return bem_smnlecsSetDirect_1(bevd_0);
case -1387056138: return bem_nameToIdSetDirect_1(bevd_0);
case 1830857400: return bem_isClose_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -655019399: return bem_def_1(bevd_0);
case 795342124: return bem_classesInDepthOrderSetDirect_1(bevd_0);
case -2022144941: return bem_nativeCSlotsSet_1(bevd_0);
case -2099354926: return bem_lastMethodBodySizeSet_1(bevd_0);
case -1968785123: return bem_acceptMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1079597484: return bem_defined_1(bevd_0);
case 602949761: return bem_addStackLines_1((BEC_2_5_4_BuildNode) bevd_0);
case 842590438: return bem_acceptCall_1((BEC_2_5_4_BuildNode) bevd_0);
case -1198311367: return bem_getTypeEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1741923406: return bem_msynSet_1(bevd_0);
case -1758669993: return bem_idToNameSetDirect_1(bevd_0);
case 1146822394: return bem_maxDynArgsSet_1(bevd_0);
case 2021071567: return bem_classBegin_1((BEC_2_5_8_BuildClassSyn) bevd_0);
case 652979225: return bem_copyTo_1(bevd_0);
case -936795051: return bem_lastMethodBodyLinesSet_1(bevd_0);
case -710686604: return bem_methodsSet_1(bevd_0);
case -304264586: return bem_objectNpSetDirect_1(bevd_0);
case 2105862247: return bem_methodCallsSetDirect_1(bevd_0);
case 1527423025: return bem_dynMethodsSetDirect_1(bevd_0);
case 305805845: return bem_lastMethodsSizeSet_1(bevd_0);
case 686048638: return bem_cnodeSetDirect_1(bevd_0);
case 1709566697: return bem_dynMethodsSet_1(bevd_0);
case 340011591: return bem_ccCacheSetDirect_1(bevd_0);
case 1839872882: return bem_transSetDirect_1(bevd_0);
case -1850341448: return bem_exceptDecSet_1(bevd_0);
case -1382897278: return bem_finalAssignTo_1((BEC_2_5_4_BuildNode) bevd_0);
case 77004232: return bem_isOnceAssign_1((BEC_2_5_4_BuildNode) bevd_0);
case -124136354: return bem_lastMethodBodySizeSetDirect_1(bevd_0);
case 611076887: return bem_sameClass_1(bevd_0);
case 2146295869: return bem_nameToIdPathSetDirect_1(bevd_0);
case -2054323176: return bem_classEmitsSetDirect_1(bevd_0);
case 184392637: return bem_nameToIdPathSet_1(bevd_0);
case -1863892649: return bem_parentConfSetDirect_1(bevd_0);
case 949467430: return bem_onceCountSet_1(bevd_0);
case 147917510: return bem_ccCacheSet_1(bevd_0);
case -1855900775: return bem_instOfSetDirect_1(bevd_0);
case 1960529933: return bem_acceptRbraces_1((BEC_2_5_4_BuildNode) bevd_0);
case 1493999205: return bem_mnodeSet_1(bevd_0);
case -1360560319: return bem_gcMarksSetDirect_1(bevd_0);
case 1031200753: return bem_cnodeSet_1(bevd_0);
case 1191176750: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 630607896: return bem_classEmitsSet_1(bevd_0);
case 1901507392: return bem_baseMtdDec_1((BEC_2_5_6_BuildMtdSyn) bevd_0);
case 928759557: return bem_mangleName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -1418139077: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -443806036: return bem_emitNameForMethod_1((BEC_2_5_4_BuildNode) bevd_0);
case -1957177586: return bem_boolNpSet_1(bevd_0);
case -1360356406: return bem_formCallTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1793290425: return bem_classesInDepthOrderSet_1(bevd_0);
case 1853505864: return bem_fileExtSet_1(bevd_0);
case -51145431: return bem_lookatComp_1((BEC_2_5_4_BuildNode) bevd_0);
case -294141752: return bem_methodCatchSetDirect_1(bevd_0);
case 1205927119: return bem_maxSpillArgsLenSet_1(bevd_0);
case -1295096725: return bem_stringNpSetDirect_1(bevd_0);
case 1983758816: return bem_floatNpSet_1(bevd_0);
case -1264667292: return bem_getLocalClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -511690288: return bem_handleTransEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1398203560: return bem_boolNpSetDirect_1(bevd_0);
case 219910861: return bem_ccMethodsSet_1(bevd_0);
case -708408320: return bem_falseValueSetDirect_1(bevd_0);
case -319046774: return bem_lastMethodBodyLinesSetDirect_1(bevd_0);
case -84334328: return bem_inFilePathedSetDirect_1(bevd_0);
case 123364704: return bem_instanceNotEqualSetDirect_1(bevd_0);
case -1744479301: return bem_ntypesSetDirect_1(bevd_0);
case 750565179: return bem_methodCatchSet_1(bevd_0);
case -990161917: return bem_parentConfSet_1(bevd_0);
case -2113255311: return bem_nullValueSet_1(bevd_0);
case 1776359002: return bem_lastMethodsSizeSetDirect_1(bevd_0);
case 1735530030: return bem_begin_1(bevd_0);
case 320114125: return bem_smnlcsSet_1(bevd_0);
case 723576085: return bem_objectNpSet_1(bevd_0);
case 486324193: return bem_preClassSet_1(bevd_0);
case 651721249: return bem_classCallsSet_1(bevd_0);
case 512729489: return bem_getNativeCSlots_1((BEC_2_4_6_TextString) bevd_0);
case 1183675069: return bem_objectCcSetDirect_1(bevd_0);
case -2023906935: return bem_randSet_1(bevd_0);
case 1486679654: return bem_libEmitPathSetDirect_1(bevd_0);
case -565659437: return bem_getCallId_1((BEC_2_4_6_TextString) bevd_0);
case 1309580499: return bem_onceVarDec_1((BEC_2_4_6_TextString) bevd_0);
case 548799924: return bem_callNamesSet_1(bevd_0);
case -467578317: return bem_synEmitPathSet_1(bevd_0);
case -570110629: return bem_emitLangSet_1(bevd_0);
case -1226089433: return bem_lineCountSetDirect_1(bevd_0);
case 423208573: return bem_instanceEqualSet_1(bevd_0);
case -548395035: return bem_getTraceInfo_1((BEC_2_5_4_BuildNode) bevd_0);
case -2018762290: return bem_lastMethodsLinesSet_1(bevd_0);
case 631726084: return bem_constSet_1(bevd_0);
case -1192919647: return bem_inClassSet_1(bevd_0);
case -171721339: return bem_methodCallsSet_1(bevd_0);
case -559761381: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1634721353: return bem_finishLibOutput_1((BEC_3_2_4_6_IOFileWriter) bevd_0);
case -1832189577: return bem_handleClassEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case 43803970: return bem_returnTypeSetDirect_1(bevd_0);
case -258320110: return bem_falseValueSet_1(bevd_0);
case 99361175: return bem_emitting_1((BEC_2_4_6_TextString) bevd_0);
case 1918339483: return bem_nullValueSetDirect_1(bevd_0);
case 1492826074: return bem_fileExtSetDirect_1(bevd_0);
case 1575573273: return bem_onceDecsSet_1(bevd_0);
case 1073870044: return bem_nameToIdSet_1(bevd_0);
case 930474266: return bem_transSet_1(bevd_0);
case 1246242002: return bem_inClassSetDirect_1(bevd_0);
case 1901451751: return bem_gcMarksSet_1(bevd_0);
case 1285868748: return bem_methodsSetDirect_1(bevd_0);
case -1564260397: return bem_onceDecsSetDirect_1(bevd_0);
case 7733892: return bem_getClassConfig_1((BEC_2_5_8_BuildNamePath) bevd_0);
case -953998008: return bem_lstringEnd_1((BEC_2_4_6_TextString) bevd_0);
case 1569285955: return bem_belslitsSetDirect_1(bevd_0);
case -675741355: return bem_getTypeInst_1((BEC_2_5_11_BuildClassConfig) bevd_0);
case -873696112: return bem_onceCountSetDirect_1(bevd_0);
case -1590226241: return bem_msynSetDirect_1(bevd_0);
case -1093394748: return bem_complete_1((BEC_2_5_4_BuildNode) bevd_0);
case -52621632: return bem_qSet_1(bevd_0);
case -574329750: return bem_propertyDecsSet_1(bevd_0);
case -209888717: return bem_buildSet_1(bevd_0);
case -1800539309: return bem_acceptIfEmit_1((BEC_2_5_4_BuildNode) bevd_0);
case -1048585607: return bem_beginNs_1((BEC_2_4_6_TextString) bevd_0);
case -94059682: return bem_lineCountSet_1(bevd_0);
case 893650928: return bem_superCallsSetDirect_1(bevd_0);
case 1130752158: return bem_emitReplace_1((BEC_2_4_6_TextString) bevd_0);
case -1192003470: return bem_nativeCSlotsSetDirect_1(bevd_0);
case -187300612: return bem_ntypesSet_1(bevd_0);
case -524369573: return bem_methodBodySet_1(bevd_0);
case 1115669322: return bem_trueValueSet_1(bevd_0);
case 1045644519: return bem_classCallsSetDirect_1(bevd_0);
case 303889411: return bem_classConfSetDirect_1(bevd_0);
case 2070101211: return bem_idToNamePathSetDirect_1(bevd_0);
case 1936866364: return bem_shlibeSetDirect_1(bevd_0);
case -1046683637: return bem_notEquals_1(bevd_0);
case 330963390: return bem_libNs_1((BEC_2_4_6_TextString) bevd_0);
case 142328325: return bem_buildSetDirect_1(bevd_0);
case -571897364: return bem_doInitializeIt_1((BEC_2_4_6_TextString) bevd_0);
case 906276201: return bem_maxDynArgsSetDirect_1(bevd_0);
case -749046838: return bem_instOfSet_1(bevd_0);
case 64324229: return bem_invpSetDirect_1(bevd_0);
case 164383017: return bem_ccMethodsSetDirect_1(bevd_0);
case 1364246935: return bem_getNameSpace_1((BEC_2_4_6_TextString) bevd_0);
case 1708846361: return bem_acceptThrow_1((BEC_2_5_4_BuildNode) bevd_0);
case -2064510787: return bem_formIntTarg_1((BEC_2_5_4_BuildNode) bevd_0);
case 1426031916: return bem_classConfSet_1(bevd_0);
case 2069548891: return bem_klassDec_1((BEC_2_5_4_LogicBool) bevd_0);
case 536018729: return bem_callNamesSetDirect_1(bevd_0);
case 1661036335: return bem_getEmitName_1((BEC_2_5_8_BuildNamePath) bevd_0);
case 2029492180: return bem_idToNamePathSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1859644135: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -645292326: return bem_writeOnceDecs_2(bevd_0, bevd_1);
case 1956483522: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1687973462: return bem_formCast_2((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 37078669: return bem_countLines_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1491746542: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -190693014: return bem_getFullEmitName_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 671177669: return bem_typeDecForVar_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1);
case 822570235: return bem_overrideSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 76975565: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -820599406: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1274029020: return bem_baseSpropDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 2132898740: return bem_lstringStart_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case -716768877: return bem_onceDec_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1006458993: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1935143208: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case 720307412: return bem_lfloatConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 859116931: return bem_buildClassInfoMethod_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
case -1053239201: return bem_lintConstruct_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case -1310199708: return bem_decForVar_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_3_BuildVar) bevd_1, (BEC_2_5_4_LogicBool) bevd_2);
case 951835725: return bem_formCast_3((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case 607073871: return bem_emitCall_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2);
case -1359310400: return bem_buildClassInfo_3((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1216628463: return bem_finalAssign_4((BEC_2_5_4_BuildNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_5_8_BuildNamePath) bevd_2, (BEC_2_4_6_TextString) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_6_6_SystemObject bemd_5(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3, BEC_2_6_6_SystemObject bevd_4) {
switch (callId) {
case 1330495313: return bem_lstringByte_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_4_6_TextString) bevd_4);
case -1651528258: return bem_startMethod_5((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_11_BuildClassConfig) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_6_TextString) bevd_3, bevd_4);
case -451352603: return bem_lstringConstruct_5((BEC_2_5_11_BuildClassConfig) bevd_0, (BEC_2_5_4_BuildNode) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3, (BEC_2_5_4_LogicBool) bevd_4);
}
return base.bemd_5(callId, bevd_0, bevd_1, bevd_2, bevd_3, bevd_4);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildJSEmitter_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildJSEmitter_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildJSEmitter();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst = (BEC_2_5_9_BuildJSEmitter) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildJSEmitter.bece_BEC_2_5_9_BuildJSEmitter_bevs_type;
}
}
}
