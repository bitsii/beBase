namespace be {
/* IO:File: source/base/LinkedList.be */
public class BEC_2_9_4_ContainerPair : BEC_2_6_6_SystemObject {
public BEC_2_9_4_ContainerPair() { }
static BEC_2_9_4_ContainerPair() { }
private static byte[] becc_BEC_2_9_4_ContainerPair_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x50,0x61,0x69,0x72};
private static byte[] becc_BEC_2_9_4_ContainerPair_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4C,0x69,0x6E,0x6B,0x65,0x64,0x4C,0x69,0x73,0x74,0x2E,0x62,0x65};
public static new BEC_2_9_4_ContainerPair bece_BEC_2_9_4_ContainerPair_bevs_inst;

public static new BET_2_9_4_ContainerPair bece_BEC_2_9_4_ContainerPair_bevs_type;

public BEC_2_6_6_SystemObject bevp_first;
public BEC_2_6_6_SystemObject bevp_second;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_new_2(BEC_2_6_6_SystemObject beva__first, BEC_2_6_6_SystemObject beva__second) {
bevp_first = beva__first;
bevp_second = beva__second;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_firstGet_0() {
return bevp_first;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_firstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_first = bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_secondGet_0() {
return bevp_second;
} /*method end*/
public virtual BEC_2_9_4_ContainerPair bem_secondSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_second = bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {32, 33, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {18, 19, 23, 26, 30, 33};
/* BEGIN LINEINFO 
assign 1 32 18
assign 1 33 19
return 1 0 23
assign 1 0 26
return 1 0 30
assign 1 0 33
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -448225060: return bem_secondGet_0();
case 1048772166: return bem_echo_0();
case 714392359: return bem_classNameGet_0();
case -1874213289: return bem_tagGet_0();
case 1028683886: return bem_toString_0();
case -354093047: return bem_serializationIteratorGet_0();
case -1312519804: return bem_hashGet_0();
case -551298753: return bem_sourceFileNameGet_0();
case -1036233638: return bem_new_0();
case -386157741: return bem_serializeToString_0();
case -76505233: return bem_once_0();
case -1963468660: return bem_fieldIteratorGet_0();
case 1836947478: return bem_serializeContents_0();
case -1057001629: return bem_copy_0();
case -454910570: return bem_create_0();
case -1493103250: return bem_many_0();
case 654084467: return bem_iteratorGet_0();
case 863669946: return bem_toAny_0();
case -1119301627: return bem_firstGet_0();
case -362321661: return bem_deserializeClassNameGet_0();
case -354590014: return bem_print_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1939955550: return bem_firstSet_1(bevd_0);
case -1978731115: return bem_sameType_1(bevd_0);
case 685919600: return bem_secondSet_1(bevd_0);
case 729561267: return bem_copyTo_1(bevd_0);
case 604922157: return bem_equals_1(bevd_0);
case 2095964872: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -965306462: return bem_undefined_1(bevd_0);
case -1374275511: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -558198774: return bem_def_1(bevd_0);
case -999936361: return bem_defined_1(bevd_0);
case 1782921206: return bem_otherType_1(bevd_0);
case -403482348: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1301577712: return bem_sameClass_1(bevd_0);
case -1184340301: return bem_otherClass_1(bevd_0);
case -747350143: return bem_undef_1(bevd_0);
case 1672825312: return bem_notEquals_1(bevd_0);
case -504315826: return bem_sameObject_1(bevd_0);
case -1188536421: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 300820890: return bem_new_2(bevd_0, bevd_1);
case -249962556: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -608983707: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 913536943: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1192068648: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1655666515: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 478589859: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2045713194: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(14, becc_BEC_2_9_4_ContainerPair_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_9_4_ContainerPair_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_9_4_ContainerPair();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_inst = (BEC_2_9_4_ContainerPair) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_9_4_ContainerPair.bece_BEC_2_9_4_ContainerPair_bevs_type;
}
}
}
