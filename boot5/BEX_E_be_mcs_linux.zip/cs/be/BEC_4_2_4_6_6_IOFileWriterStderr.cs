namespace be {

using System.IO;
//using System;
    /* IO:File: source/extended/FileReadWrite.be */
public sealed class BEC_4_2_4_6_6_IOFileWriterStderr : BEC_3_2_4_6_IOFileWriter {
public BEC_4_2_4_6_6_IOFileWriterStderr() { }
static BEC_4_2_4_6_6_IOFileWriterStderr() { }
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStderr_clname = {0x49,0x4F,0x3A,0x46,0x69,0x6C,0x65,0x3A,0x57,0x72,0x69,0x74,0x65,0x72,0x3A,0x53,0x74,0x64,0x65,0x72,0x72};
private static byte[] becc_BEC_4_2_4_6_6_IOFileWriterStderr_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x46,0x69,0x6C,0x65,0x52,0x65,0x61,0x64,0x57,0x72,0x69,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_4_2_4_6_6_IOFileWriterStderr bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public BEC_4_2_4_6_6_IOFileWriterStderr bem_default_0() {
bevp_isClosed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return this;
} /*method end*/
public override BEC_2_6_6_SystemObject bem_create_0() {
return this;
} /*method end*/
public override BEC_2_5_4_LogicBool bem_isClosedGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_0_tmpany_phold;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_isClosedSet_1(BEC_2_6_6_SystemObject beva__isClosed) {
return this;
} /*method end*/
public override BEC_3_2_4_6_IOFileWriter bem_open_0() {
return this;
} /*method end*/
public override BEC_2_2_6_IOWriter bem_close_0() {
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {640, 645, 645};
public static new int[] bevs_smnlec
 = new int[] {16, 24, 25};
/* BEGIN LINEINFO 
assign 1 640 16
new 0 640 16
assign 1 645 24
new 0 645 24
return 1 645 25
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 835587929: return bem_isClosedGet_0();
case 695265136: return bem_open_0();
case 746061642: return bem_openTruncate_0();
case -717031112: return bem_pathGet_0();
case 210264567: return bem_print_0();
case 2043795865: return bem_echo_0();
case 1165489654: return bem_sourceFileNameGet_0();
case -1966087610: return bem_openAppend_0();
case -1233972717: return bem_create_0();
case 212191548: return bem_tagGet_0();
case -590451146: return bem_serializeToString_0();
case -1569136637: return bem_default_0();
case -315420442: return bem_once_0();
case -1533121038: return bem_new_0();
case 607966049: return bem_serializationIteratorGet_0();
case 662608902: return bem_extOpen_0();
case -849438140: return bem_vfileGet_0();
case -827921680: return bem_copy_0();
case -1151697421: return bem_close_0();
case 466290922: return bem_iteratorGet_0();
case 247385301: return bem_toString_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -853598946: return bem_serializeContents_0();
case -1802544452: return bem_many_0();
case 460304834: return bem_fieldIteratorGet_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 1307328857: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 172009000: return bem_otherType_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -1521662514: return bem_open_1((BEC_2_4_6_TextString) bevd_0);
case -1618817401: return bem_pathSet_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case -52664134: return bem_vfileSet_1(bevd_0);
case -1546683637: return bem_write_1((BEC_2_4_6_TextString) bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case -1287998003: return bem_new_1(bevd_0);
case -1739035680: return bem_isClosedSet_1(bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(21, becc_BEC_4_2_4_6_6_IOFileWriterStderr_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(32, becc_BEC_4_2_4_6_6_IOFileWriterStderr_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_4_2_4_6_6_IOFileWriterStderr();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst = (BEC_4_2_4_6_6_IOFileWriterStderr) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_4_2_4_6_6_IOFileWriterStderr.bece_BEC_4_2_4_6_6_IOFileWriterStderr_bevs_inst;
}
}
}
