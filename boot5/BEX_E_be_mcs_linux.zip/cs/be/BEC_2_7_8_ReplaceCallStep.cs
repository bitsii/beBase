namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_7_8_ReplaceCallStep : BEC_2_6_6_SystemObject {
public BEC_2_7_8_ReplaceCallStep() { }
static BEC_2_7_8_ReplaceCallStep() { }
private static byte[] becc_BEC_2_7_8_ReplaceCallStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x43,0x61,0x6C,0x6C,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_8_ReplaceCallStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_7_8_ReplaceCallStep_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_7_8_ReplaceCallStep_bevo_1 = (new BEC_2_4_3_MathInt(1));
public static new BEC_2_7_8_ReplaceCallStep bece_BEC_2_7_8_ReplaceCallStep_bevs_inst;

public static new BET_2_7_8_ReplaceCallStep bece_BEC_2_7_8_ReplaceCallStep_bevs_type;

public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_callArgs;
public virtual BEC_2_7_8_ReplaceCallStep bem_new_1(BEC_2_9_10_ContainerLinkedList beva_payloads) {
BEC_2_4_3_MathInt bevl_pi = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_callName = (BEC_2_4_6_TextString) beva_payloads.bem_get_1(bevt_0_tmpany_phold);
bevt_2_tmpany_phold = beva_payloads.bem_lengthGet_0();
bevt_3_tmpany_phold = bece_BEC_2_7_8_ReplaceCallStep_bevo_0;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_subtract_1(bevt_3_tmpany_phold);
bevp_callArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_tmpany_phold);
bevl_pi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
 /* Line: 24 */ {
bevt_5_tmpany_phold = beva_payloads.bem_lengthGet_0();
if (bevl_pi.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_7_tmpany_phold = bece_BEC_2_7_8_ReplaceCallStep_bevo_1;
bevt_6_tmpany_phold = bevl_pi.bem_subtract_1(bevt_7_tmpany_phold);
bevt_8_tmpany_phold = beva_payloads.bem_get_1(bevl_pi);
bevp_callArgs.bem_put_2(bevt_6_tmpany_phold, bevt_8_tmpany_phold);
bevl_pi = bevl_pi.bem_increment_0();
} /* Line: 24 */
 else  /* Line: 24 */ {
break;
} /* Line: 24 */
} /* Line: 24 */
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_r.bemd_2(-214435591, bevp_callName, bevp_callArgs);
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public BEC_2_4_6_TextString bem_callNameGetDirect_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_7_8_ReplaceCallStep bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_7_8_ReplaceCallStep bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_callArgsGet_0() {
return bevp_callArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_callArgsGetDirect_0() {
return bevp_callArgs;
} /*method end*/
public virtual BEC_2_7_8_ReplaceCallStep bem_callArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_7_8_ReplaceCallStep bem_callArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_callArgs = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {20, 20, 21, 21, 21, 21, 24, 24, 24, 24, 25, 25, 25, 25, 24, 31, 31, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {27, 28, 29, 30, 31, 32, 33, 36, 37, 42, 43, 44, 45, 46, 47, 57, 58, 61, 64, 67, 71, 75, 78, 81, 85};
/* BEGIN LINEINFO 
assign 1 20 27
new 0 20 27
assign 1 20 28
get 1 20 28
assign 1 21 29
lengthGet 0 21 29
assign 1 21 30
new 0 21 30
assign 1 21 31
subtract 1 21 31
assign 1 21 32
new 1 21 32
assign 1 24 33
new 0 24 33
assign 1 24 36
lengthGet 0 24 36
assign 1 24 37
lesser 1 24 42
assign 1 25 43
new 0 25 43
assign 1 25 44
subtract 1 25 44
assign 1 25 45
get 1 25 45
put 2 25 46
assign 1 24 47
increment 0 24 47
assign 1 31 57
invoke 2 31 57
return 1 31 58
return 1 0 61
return 1 0 64
assign 1 0 67
assign 1 0 71
return 1 0 75
return 1 0 78
assign 1 0 81
assign 1 0 85
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1131385505: return bem_toAny_0();
case 131226213: return bem_toString_0();
case 1279906777: return bem_serializeToString_0();
case 2063546474: return bem_classNameGet_0();
case -1485517163: return bem_copy_0();
case 431618869: return bem_once_0();
case 343375430: return bem_create_0();
case -1574932366: return bem_print_0();
case -928163909: return bem_fieldIteratorGet_0();
case -825084265: return bem_hashGet_0();
case 421749162: return bem_iteratorGet_0();
case 1637201686: return bem_callNameGet_0();
case 2061421621: return bem_many_0();
case -1350223734: return bem_callArgsGetDirect_0();
case -1846550974: return bem_serializeContents_0();
case 1368838510: return bem_callArgsGet_0();
case 916294969: return bem_sourceFileNameGet_0();
case -1031399474: return bem_echo_0();
case 1253953314: return bem_serializationIteratorGet_0();
case 911313117: return bem_tagGet_0();
case -957769093: return bem_deserializeClassNameGet_0();
case -2051799514: return bem_new_0();
case -964451557: return bem_callNameGetDirect_0();
case 1970758688: return bem_fieldNamesGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 747155616: return bem_notEquals_1(bevd_0);
case -2119476488: return bem_callArgsSet_1(bevd_0);
case 1889683305: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -1551421646: return bem_copyTo_1(bevd_0);
case 192530319: return bem_otherType_1(bevd_0);
case -628476976: return bem_otherClass_1(bevd_0);
case -436556280: return bem_undef_1(bevd_0);
case 1555616281: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1866476286: return bem_handle_1(bevd_0);
case -1655018142: return bem_sameType_1(bevd_0);
case -1181240679: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -989659144: return bem_callNameSetDirect_1(bevd_0);
case 2057641877: return bem_callNameSet_1(bevd_0);
case 1768644351: return bem_sameClass_1(bevd_0);
case -1065536512: return bem_equals_1(bevd_0);
case 1383324451: return bem_sameObject_1(bevd_0);
case -1809169317: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -680693256: return bem_callArgsSetDirect_1(bevd_0);
case 1147111468: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1928047187: return bem_undefined_1(bevd_0);
case 1044863323: return bem_defined_1(bevd_0);
case -2018944701: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1990600260: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1260241587: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -598891548: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1655882914: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1041029455: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -214435591: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -40143354: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_7_8_ReplaceCallStep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_8_ReplaceCallStep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_7_8_ReplaceCallStep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_inst = (BEC_2_7_8_ReplaceCallStep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_type;
}
}
}
