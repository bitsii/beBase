namespace be {
/* IO:File: source/extended/Template.be */
public class BEC_2_7_8_ReplaceCallStep : BEC_2_6_6_SystemObject {
public BEC_2_7_8_ReplaceCallStep() { }
static BEC_2_7_8_ReplaceCallStep() { }
private static byte[] becc_BEC_2_7_8_ReplaceCallStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x43,0x61,0x6C,0x6C,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_8_ReplaceCallStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static new BEC_2_7_8_ReplaceCallStep bece_BEC_2_7_8_ReplaceCallStep_bevs_inst;

public static new BET_2_7_8_ReplaceCallStep bece_BEC_2_7_8_ReplaceCallStep_bevs_type;

public BEC_2_4_6_TextString bevp_callName;
public BEC_2_9_4_ContainerList bevp_callArgs;
public virtual BEC_2_7_8_ReplaceCallStep bem_new_1(BEC_2_9_10_ContainerLinkedList beva_payloads) {
BEC_2_4_3_MathInt bevl_pi = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevp_callName = (BEC_2_4_6_TextString) beva_payloads.bem_get_1(bevt_0_ta_ph);
bevt_2_ta_ph = beva_payloads.bem_lengthGet_0();
bevt_3_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = bevt_2_ta_ph.bem_subtract_1(bevt_3_ta_ph);
bevp_callArgs = (BEC_2_9_4_ContainerList) (new BEC_2_9_4_ContainerList()).bem_new_1(bevt_1_ta_ph);
bevl_pi = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
while (true)
/* Line: 23*/ {
bevt_5_ta_ph = beva_payloads.bem_lengthGet_0();
if (bevl_pi.bevi_int < bevt_5_ta_ph.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 23*/ {
bevt_7_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_6_ta_ph = bevl_pi.bem_subtract_1(bevt_7_ta_ph);
bevt_8_ta_ph = beva_payloads.bem_get_1(bevl_pi);
bevp_callArgs.bem_put_2(bevt_6_ta_ph, bevt_8_ta_ph);
bevl_pi = bevl_pi.bem_increment_0();
} /* Line: 23*/
 else /* Line: 23*/ {
break;
} /* Line: 23*/
} /* Line: 23*/
return this;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_r.bemd_2(-1452102248, bevp_callName, bevp_callArgs);
return (BEC_2_4_6_TextString) bevt_0_ta_ph;
} /*method end*/
public virtual BEC_2_4_6_TextString bem_callNameGet_0() {
return bevp_callName;
} /*method end*/
public BEC_2_4_6_TextString bem_callNameGetDirect_0() {
return bevp_callName;
} /*method end*/
public virtual BEC_2_7_8_ReplaceCallStep bem_callNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_8_ReplaceCallStep bem_callNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_callName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_9_4_ContainerList bem_callArgsGet_0() {
return bevp_callArgs;
} /*method end*/
public BEC_2_9_4_ContainerList bem_callArgsGetDirect_0() {
return bevp_callArgs;
} /*method end*/
public virtual BEC_2_7_8_ReplaceCallStep bem_callArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_callArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_7_8_ReplaceCallStep bem_callArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_callArgs = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {19, 19, 20, 20, 20, 20, 23, 23, 23, 23, 24, 24, 24, 24, 23, 30, 30, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {25, 26, 27, 28, 29, 30, 31, 34, 35, 40, 41, 42, 43, 44, 45, 55, 56, 59, 62, 65, 69, 73, 76, 79, 83};
/* BEGIN LINEINFO 
assign 1 19 25
new 0 19 25
assign 1 19 26
get 1 19 26
assign 1 20 27
lengthGet 0 20 27
assign 1 20 28
new 0 20 28
assign 1 20 29
subtract 1 20 29
assign 1 20 30
new 1 20 30
assign 1 23 31
new 0 23 31
assign 1 23 34
lengthGet 0 23 34
assign 1 23 35
lesser 1 23 40
assign 1 24 41
new 0 24 41
assign 1 24 42
subtract 1 24 42
assign 1 24 43
get 1 24 43
put 2 24 44
assign 1 23 45
increment 0 23 45
assign 1 30 55
invoke 2 30 55
return 1 30 56
return 1 0 59
return 1 0 62
assign 1 0 65
assign 1 0 69
return 1 0 73
return 1 0 76
assign 1 0 79
assign 1 0 83
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -75446614: return bem_callArgsGet_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case -1076915155: return bem_serializeToString_0();
case 1834246217: return bem_classNameGet_0();
case 946360922: return bem_serializationIteratorGet_0();
case -2118708930: return bem_new_0();
case 1153344161: return bem_serializeContents_0();
case 1156690025: return bem_callNameGet_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -193582610: return bem_tagGet_0();
case 1974505938: return bem_hashGet_0();
case 2081363871: return bem_copy_0();
case -975498393: return bem_fieldNamesGet_0();
case -1457474206: return bem_callNameGetDirect_0();
case 954703233: return bem_create_0();
case -893093197: return bem_toString_0();
case -556240650: return bem_callArgsGetDirect_0();
case -40905183: return bem_echo_0();
case -1653939165: return bem_iteratorGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1220213109: return bem_otherClass_1(bevd_0);
case -105257161: return bem_callArgsSetDirect_1(bevd_0);
case 59504167: return bem_new_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case 841515414: return bem_callArgsSet_1(bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case 177409367: return bem_otherType_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case -613804981: return bem_handle_1(bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 764361355: return bem_callNameSetDirect_1(bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -555295690: return bem_callNameSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(16, becc_BEC_2_7_8_ReplaceCallStep_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_8_ReplaceCallStep_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_7_8_ReplaceCallStep();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_inst = (BEC_2_7_8_ReplaceCallStep) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_7_8_ReplaceCallStep.bece_BEC_2_7_8_ReplaceCallStep_bevs_type;
}
}
}
