namespace be {
/* IO:File: source/build/Syns.be */
public sealed class BEC_2_5_6_BuildPtySyn : BEC_2_6_6_SystemObject {
public BEC_2_5_6_BuildPtySyn() { }
static BEC_2_5_6_BuildPtySyn() { }
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x50,0x74,0x79,0x53,0x79,0x6E};
private static byte[] becc_BEC_2_5_6_BuildPtySyn_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x53,0x79,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_0 = {0x70,0x72,0x6F,0x70,0x65,0x72,0x74,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildPtySyn_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildPtySyn_bels_0, 8));
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_1 = {0x6E,0x61,0x6D,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_6_BuildPtySyn_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_6_BuildPtySyn_bels_1, 4));
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_2 = {0x6F,0x72,0x69,0x67,0x69,0x6E};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_3 = {0x6D,0x65,0x6D,0x54,0x79,0x70,0x65};
private static byte[] bece_BEC_2_5_6_BuildPtySyn_bels_4 = {0x61,0x6E,0x79};
public static new BEC_2_5_6_BuildPtySyn bece_BEC_2_5_6_BuildPtySyn_bevs_inst;
public BEC_2_4_3_MathInt bevp_mpos;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_8_BuildNamePath bevp_origin;
public BEC_2_5_6_BuildVarSyn bevp_memSyn;
public BEC_2_5_6_BuildPtySyn bem_new_2(BEC_2_6_6_SystemObject beva_vnode, BEC_2_6_6_SystemObject beva__origin) {
BEC_2_5_3_BuildVar bevl_v = null;
bevl_v = (BEC_2_5_3_BuildVar) beva_vnode.bemd_0(643127393);
bevp_name = bevl_v.bem_nameGet_0();
bevp_origin = (BEC_2_5_8_BuildNamePath) beva__origin;
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) (new BEC_2_5_6_BuildVarSyn()).bem_anyNew_1(bevl_v);
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_nl = null;
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_nl = bevt_0_tmpany_phold.bem_newlineGet_0();
bevt_5_tmpany_phold = bece_BEC_2_5_6_BuildPtySyn_bevo_0;
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_add_1(bevl_nl);
bevt_6_tmpany_phold = bece_BEC_2_5_6_BuildPtySyn_bevo_1;
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_6_tmpany_phold);
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_add_1(bevl_nl);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(bevp_name);
bevl_toRet = bevt_1_tmpany_phold.bem_add_1(bevl_nl);
bevt_10_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_6_BuildPtySyn_bels_2));
bevt_9_tmpany_phold = bevl_toRet.bemd_1(2076166850, bevt_10_tmpany_phold);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_1(2076166850, bevl_nl);
bevt_11_tmpany_phold = bevp_origin.bem_toString_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_1(2076166850, bevt_11_tmpany_phold);
bevl_toRet = bevt_7_tmpany_phold.bemd_1(2076166850, bevl_nl);
bevt_13_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_6_BuildPtySyn_bels_3));
bevt_12_tmpany_phold = bevl_toRet.bemd_1(2076166850, bevt_13_tmpany_phold);
bevl_toRet = bevt_12_tmpany_phold.bemd_1(2076166850, bevl_nl);
bevt_14_tmpany_phold = bevp_memSyn.bem_isTypedGet_0();
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 522 */ {
bevt_17_tmpany_phold = bevp_memSyn.bem_namepathGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_toString_0();
bevt_15_tmpany_phold = bevl_toRet.bemd_1(2076166850, bevt_16_tmpany_phold);
bevl_toRet = bevt_15_tmpany_phold.bemd_1(2076166850, bevl_nl);
} /* Line: 523 */
 else  /* Line: 524 */ {
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_6_BuildPtySyn_bels_4));
bevt_18_tmpany_phold = bevl_toRet.bemd_1(2076166850, bevt_19_tmpany_phold);
bevl_toRet = bevt_18_tmpany_phold.bemd_1(2076166850, bevl_nl);
} /* Line: 525 */
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_4_3_MathInt bem_mposGet_0() {
return bevp_mpos;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_mposSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mpos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() {
return bevp_name;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_name = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_originGet_0() {
return bevp_origin;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_originSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_origin = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildVarSyn bem_memSynGet_0() {
return bevp_memSyn;
} /*method end*/
public BEC_2_5_6_BuildPtySyn bem_memSynSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_memSyn = (BEC_2_5_6_BuildVarSyn) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {507, 511, 512, 513, 518, 518, 519, 519, 519, 519, 519, 519, 519, 520, 520, 520, 520, 520, 520, 521, 521, 521, 522, 523, 523, 523, 523, 525, 525, 525, 527, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {22, 23, 24, 25, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 71, 72, 73, 74, 77, 78, 79, 81, 84, 87, 91, 94, 98, 101, 105, 108};
/* BEGIN LINEINFO 
assign 1 507 22
heldGet 0 507 22
assign 1 511 23
nameGet 0 511 23
assign 1 512 24
assign 1 513 25
anyNew 1 513 25
assign 1 518 51
new 0 518 51
assign 1 518 52
newlineGet 0 518 52
assign 1 519 53
new 0 519 53
assign 1 519 54
add 1 519 54
assign 1 519 55
new 0 519 55
assign 1 519 56
add 1 519 56
assign 1 519 57
add 1 519 57
assign 1 519 58
add 1 519 58
assign 1 519 59
add 1 519 59
assign 1 520 60
new 0 520 60
assign 1 520 61
add 1 520 61
assign 1 520 62
add 1 520 62
assign 1 520 63
toString 0 520 63
assign 1 520 64
add 1 520 64
assign 1 520 65
add 1 520 65
assign 1 521 66
new 0 521 66
assign 1 521 67
add 1 521 67
assign 1 521 68
add 1 521 68
assign 1 522 69
isTypedGet 0 522 69
assign 1 523 71
namepathGet 0 523 71
assign 1 523 72
toString 0 523 72
assign 1 523 73
add 1 523 73
assign 1 523 74
add 1 523 74
assign 1 525 77
new 0 525 77
assign 1 525 78
add 1 525 78
assign 1 525 79
add 1 525 79
return 1 527 81
return 1 0 84
assign 1 0 87
return 1 0 91
assign 1 0 94
return 1 0 98
assign 1 0 101
return 1 0 105
assign 1 0 108
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -173186399: return bem_toAny_0();
case 717158289: return bem_fieldIteratorGet_0();
case -125946934: return bem_serializeContents_0();
case -2046784533: return bem_echo_0();
case 648165913: return bem_print_0();
case 814639632: return bem_new_0();
case -537857901: return bem_iteratorGet_0();
case -2049991627: return bem_once_0();
case 432735873: return bem_deserializeClassNameGet_0();
case -20081513: return bem_nameGet_0();
case 1973131926: return bem_serializeToString_0();
case 34035866: return bem_classNameGet_0();
case -326152805: return bem_copy_0();
case -109602708: return bem_toString_0();
case 2048361265: return bem_many_0();
case -1653307562: return bem_serializationIteratorGet_0();
case -2089907154: return bem_create_0();
case 1524298533: return bem_mposGet_0();
case 57558018: return bem_memSynGet_0();
case 99641680: return bem_sourceFileNameGet_0();
case 2036051133: return bem_tagGet_0();
case -2129255989: return bem_hashGet_0();
case -1487058989: return bem_originGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1091318965: return bem_defined_1(bevd_0);
case 991182700: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 648097328: return bem_nameSet_1(bevd_0);
case 611759068: return bem_originSet_1(bevd_0);
case -1393267925: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 549239575: return bem_otherType_1(bevd_0);
case 755365358: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -143017218: return bem_copyTo_1(bevd_0);
case -420585939: return bem_equals_1(bevd_0);
case -169401475: return bem_otherClass_1(bevd_0);
case 569199667: return bem_undefined_1(bevd_0);
case 1492255674: return bem_def_1(bevd_0);
case 1940516897: return bem_sameClass_1(bevd_0);
case -1369439027: return bem_notEquals_1(bevd_0);
case -2031862922: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -491345013: return bem_sameType_1(bevd_0);
case 367706985: return bem_memSynSet_1(bevd_0);
case 877014814: return bem_mposSet_1(bevd_0);
case -1887120745: return bem_sameObject_1(bevd_0);
case 1290400575: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -1008056884: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1151786117: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -769395961: return bem_new_2(bevd_0, bevd_1);
case -1422666964: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 466148991: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1823742306: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -50371904: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 967378502: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(12, becc_BEC_2_5_6_BuildPtySyn_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(20, becc_BEC_2_5_6_BuildPtySyn_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_6_BuildPtySyn();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst = (BEC_2_5_6_BuildPtySyn) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_6_BuildPtySyn.bece_BEC_2_5_6_BuildPtySyn_bevs_inst;
}
}
}
