namespace be {
/* IO:File: source/build/Pass6.be */
public sealed class BEC_3_5_5_5_BuildVisitPass6 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass6() { }
static BEC_3_5_5_5_BuildVisitPass6() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x36};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass6_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x36,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_5_BuildVisitPass6_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_5_BuildVisitPass6_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_0 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_1 = {0x2C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_2 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_3 = {0x49,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_4 = {0x5F};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_5 = {0x74,0x68,0x69,0x73};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_6 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_7 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass6_bels_8 = {0x73,0x65,0x6C,0x66};
public static new BEC_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass6 bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;

public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_gnext = null;
BEC_2_9_3_ContainerSet bevl_langs = null;
BEC_2_5_4_BuildNode bevl_lang = null;
BEC_2_6_6_SystemObject bevl_doit = null;
BEC_2_6_6_SystemObject bevl_si = null;
BEC_2_6_6_SystemObject bevl_snode = null;
BEC_2_6_6_SystemObject bevl_lnode = null;
BEC_2_6_6_SystemObject bevl_enode = null;
BEC_2_6_6_SystemObject bevl_brnode = null;
BEC_2_6_6_SystemObject bevl_inode = null;
BEC_2_6_6_SystemObject bevl_nxnode = null;
BEC_2_6_6_SystemObject bevl_parens = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_numargs = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_ix = null;
BEC_2_6_6_SystemObject bevl_vid = null;
BEC_2_6_6_SystemObject bevl_vinp = null;
BEC_2_6_6_SystemObject bevl_s = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_25_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_29_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_30_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_38_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_5_4_BuildEmit bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_6_BuildIfEmit bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_66_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_72_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_73_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_74_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_89_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_102_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_103_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_104_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_105_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_108_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_109_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_110_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_111_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_115_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_122_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_123_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_124_tmpany_phold = null;
BEC_2_4_6_TextString bevt_125_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_126_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_127_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_130_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_134_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_135_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_136_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_137_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_138_tmpany_phold = null;
BEC_2_4_6_TextString bevt_139_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_142_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_143_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_144_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_147_tmpany_phold = null;
BEC_2_4_6_TextString bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_151_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_152_tmpany_phold = null;
BEC_2_4_6_TextString bevt_153_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_154_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_155_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_5_3_BuildVar bevt_158_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_159_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_164_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_165_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_166_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_167_tmpany_phold = null;
BEC_2_5_8_BuildNamePath bevt_168_tmpany_phold = null;
BEC_2_4_6_TextString bevt_169_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_170_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_171_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_172_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_173_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_174_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_175_tmpany_phold = null;
beva_node.bem_resolveNp_0();
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_EMITGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 22 */ {
bevl_gnext = beva_node.bem_nextAscendGet_0();
bevt_12_tmpany_phold = beva_node.bem_containedGet_0();
if (bevt_12_tmpany_phold == null) {
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_11_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_15_tmpany_phold = beva_node.bem_containedGet_0();
bevt_14_tmpany_phold = bevt_15_tmpany_phold.bem_lengthGet_0();
bevt_16_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass6_bevo_0;
if (bevt_14_tmpany_phold.bevi_int > bevt_16_tmpany_phold.bevi_int) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_20_tmpany_phold = beva_node.bem_containedGet_0();
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(-310442460);
if (bevt_18_tmpany_phold == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_25_tmpany_phold = beva_node.bem_containedGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bem_firstGet_0();
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_0(-310442460);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bemd_0(-804802935);
bevt_26_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(1762445349, bevt_26_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevt_30_tmpany_phold = beva_node.bem_secondGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_containedGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_lengthGet_0();
bevt_31_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass6_bevo_1;
if (bevt_28_tmpany_phold.bevi_int > bevt_31_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 24 */
 else  /* Line: 24 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 24 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_34_tmpany_phold = beva_node.bem_containedGet_0();
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bemd_0(-310442460);
bevt_0_tmpany_loop = bevt_32_tmpany_phold.bemd_0(654084467);
while (true)
 /* Line: 27 */ {
bevt_35_tmpany_phold = bevt_0_tmpany_loop.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_35_tmpany_phold).bevi_bool) /* Line: 27 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_0_tmpany_loop.bemd_0(901258413);
bevt_36_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_36_tmpany_phold);
} /* Line: 29 */
 else  /* Line: 27 */ {
break;
} /* Line: 27 */
} /* Line: 27 */
bevt_37_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_0));
bevl_langs.bem_delete_1(bevt_37_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
if (((BEC_2_5_4_LogicBool) bevl_doit).bevi_bool) /* Line: 33 */ {
bevl_doit = be.BECS_Runtime.boolFalse;
bevt_39_tmpany_phold = beva_node.bem_secondGet_0();
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_containedGet_0();
bevl_i = bevt_38_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 35 */ {
bevt_40_tmpany_phold = bevl_i.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 35 */ {
bevl_si = bevl_i.bemd_0(901258413);
bevt_42_tmpany_phold = bevl_si.bemd_0(-1264552924);
bevt_43_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bemd_1(604922157, bevt_43_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_41_tmpany_phold).bevi_bool) /* Line: 37 */ {
bevt_44_tmpany_phold = bevl_si.bemd_0(967076058);
beva_node.bem_heldSet_1(bevt_44_tmpany_phold);
bevl_doit = be.BECS_Runtime.boolTrue;
} /* Line: 41 */
} /* Line: 37 */
 else  /* Line: 35 */ {
break;
} /* Line: 35 */
} /* Line: 35 */
} /* Line: 35 */
bevt_45_tmpany_phold = bevl_doit.bemd_0(476813342);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 45 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 47 */
beva_node.bem_containedSet_1(null);
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = (BEC_2_5_4_BuildEmit) (new BEC_2_5_4_BuildEmit()).bem_new_2((BEC_2_4_6_TextString) bevt_47_tmpany_phold , bevl_langs);
beva_node.bem_heldSet_1(bevt_46_tmpany_phold);
} /* Line: 50 */
 else  /* Line: 51 */ {
beva_node.bem_delete_0();
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 53 */
bevl_snode = beva_node.bem_scopeGet_0();
bevt_49_tmpany_phold = bevl_snode.bemd_0(-1264552924);
bevt_50_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bemd_1(604922157, bevt_50_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_48_tmpany_phold).bevi_bool) /* Line: 57 */ {
bevl_snode = null;
} /* Line: 58 */
if (bevl_snode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 61 */ {
beva_node.bem_delete_0();
bevt_52_tmpany_phold = bevl_snode.bemd_0(967076058);
bevt_52_tmpany_phold.bemd_1(740380606, beva_node);
} /* Line: 63 */
return (BEC_2_5_4_BuildNode) bevl_gnext;
} /* Line: 66 */
 else  /* Line: 22 */ {
bevt_54_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_55_tmpany_phold = bevp_ntypes.bem_IFEMITGet_0();
if (bevt_54_tmpany_phold.bevi_int == bevt_55_tmpany_phold.bevi_int) {
bevt_53_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_53_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_53_tmpany_phold.bevi_bool) /* Line: 67 */ {
bevl_langs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_58_tmpany_phold = beva_node.bem_containedGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bem_firstGet_0();
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(-310442460);
bevt_1_tmpany_loop = bevt_56_tmpany_phold.bemd_0(654084467);
while (true)
 /* Line: 70 */ {
bevt_59_tmpany_phold = bevt_1_tmpany_loop.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 70 */ {
bevl_lang = (BEC_2_5_4_BuildNode) bevt_1_tmpany_loop.bemd_0(901258413);
bevt_60_tmpany_phold = bevl_lang.bem_heldGet_0();
bevl_langs.bem_addValue_1(bevt_60_tmpany_phold);
bevl_toremove.bemd_1(742596414, bevl_lang);
} /* Line: 73 */
 else  /* Line: 70 */ {
break;
} /* Line: 70 */
} /* Line: 70 */
bevt_61_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_1));
bevl_langs.bem_delete_1(bevt_61_tmpany_phold);
bevt_63_tmpany_phold = beva_node.bem_heldGet_0();
bevt_62_tmpany_phold = (BEC_2_5_6_BuildIfEmit) (new BEC_2_5_6_BuildIfEmit()).bem_new_2(bevl_langs, (BEC_2_4_6_TextString) bevt_63_tmpany_phold );
beva_node.bem_heldSet_1(bevt_62_tmpany_phold);
bevl_ii = bevl_toremove.bemd_0(654084467);
while (true)
 /* Line: 77 */ {
bevt_64_tmpany_phold = bevl_ii.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 77 */ {
bevl_i = bevl_ii.bemd_0(901258413);
bevl_i.bemd_0(35553437);
} /* Line: 79 */
 else  /* Line: 77 */ {
break;
} /* Line: 77 */
} /* Line: 77 */
} /* Line: 77 */
 else  /* Line: 22 */ {
bevt_66_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_67_tmpany_phold = bevp_ntypes.bem_IFGet_0();
if (bevt_66_tmpany_phold.bevi_int == bevt_67_tmpany_phold.bevi_int) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 81 */ {
if (bevl_nnode == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 82 */ {
bevl_lnode = beva_node;
while (true)
 /* Line: 84 */ {
if (bevl_nnode == null) {
bevt_69_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_69_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_69_tmpany_phold.bevi_bool) /* Line: 84 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(-1264552924);
bevt_72_tmpany_phold = bevp_ntypes.bem_ELIFGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bemd_1(604922157, bevt_72_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_70_tmpany_phold).bevi_bool) /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 84 */
 else  /* Line: 84 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 84 */ {
bevl_enode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevt_73_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevl_enode.bemd_1(954110771, bevt_73_tmpany_phold);
bevl_enode.bemd_1(-2054804955, beva_node);
bevl_brnode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_brnode.bemd_1(-2054804955, beva_node);
bevt_74_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevl_brnode.bemd_1(954110771, bevt_74_tmpany_phold);
bevl_inode = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_inode.bemd_1(-2054804955, beva_node);
bevt_75_tmpany_phold = bevp_ntypes.bem_IFGet_0();
bevl_inode.bemd_1(954110771, bevt_75_tmpany_phold);
bevl_brnode.bemd_1(742596414, bevl_inode);
bevl_enode.bemd_1(742596414, bevl_brnode);
bevt_77_tmpany_phold = bevl_nnode.bemd_0(-310442460);
if (bevt_77_tmpany_phold == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 96 */ {
bevt_78_tmpany_phold = bevl_nnode.bemd_0(-310442460);
bevl_i = bevt_78_tmpany_phold.bemd_0(654084467);
while (true)
 /* Line: 97 */ {
bevt_79_tmpany_phold = bevl_i.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_79_tmpany_phold).bevi_bool) /* Line: 97 */ {
bevt_80_tmpany_phold = bevl_i.bemd_0(901258413);
bevl_inode.bemd_1(742596414, bevt_80_tmpany_phold);
} /* Line: 98 */
 else  /* Line: 97 */ {
break;
} /* Line: 97 */
} /* Line: 97 */
} /* Line: 97 */
bevl_lnode.bemd_1(742596414, bevl_enode);
bevl_lnode = bevl_inode;
bevl_nxnode = bevl_nnode.bemd_0(-1479835857);
bevl_nnode.bemd_0(35553437);
bevl_nnode = bevl_nxnode;
} /* Line: 109 */
 else  /* Line: 84 */ {
break;
} /* Line: 84 */
} /* Line: 84 */
if (bevl_nnode == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 111 */ {
bevt_83_tmpany_phold = bevl_nnode.bemd_0(-1264552924);
bevt_84_tmpany_phold = bevp_ntypes.bem_ELSEGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_1(604922157, bevt_84_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_82_tmpany_phold).bevi_bool) /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 111 */
 else  /* Line: 111 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 111 */ {
bevl_nnode.bemd_0(35553437);
bevl_lnode.bemd_1(742596414, bevl_nnode);
} /* Line: 113 */
} /* Line: 111 */
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 116 */
 else  /* Line: 22 */ {
bevt_87_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_88_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_87_tmpany_phold.bevi_int == bevt_88_tmpany_phold.bevi_int) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 117 */ {
bevt_89_tmpany_phold = beva_node.bem_containedGet_0();
bevl_parens = bevt_89_tmpany_phold.bem_firstGet_0();
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(-2054804955, beva_node);
bevt_90_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevl_nd.bemd_1(954110771, bevt_90_tmpany_phold);
bevt_91_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_2));
bevl_nd.bemd_1(2051313313, bevt_91_tmpany_phold);
bevl_parens.bemd_1(-421881003, bevl_nd);
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_numargs = (new BEC_2_4_3_MathInt(0));
bevt_92_tmpany_phold = bevl_parens.bemd_0(-310442460);
bevl_ii = bevt_92_tmpany_phold.bemd_0(654084467);
while (true)
 /* Line: 126 */ {
bevt_93_tmpany_phold = bevl_ii.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_93_tmpany_phold).bevi_bool) /* Line: 126 */ {
bevl_i = bevl_ii.bemd_0(901258413);
bevl_ix = bevl_i.bemd_0(-1479835857);
bevt_95_tmpany_phold = bevl_i.bemd_0(-1264552924);
bevt_96_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bemd_1(604922157, bevt_96_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_94_tmpany_phold).bevi_bool) /* Line: 131 */ {
bevl_toremove.bemd_1(742596414, bevl_i);
} /* Line: 132 */
 else  /* Line: 131 */ {
bevt_98_tmpany_phold = bevl_i.bemd_0(-1264552924);
bevt_99_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(604922157, bevt_99_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_97_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_100_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(-1524368885, bevt_100_tmpany_phold);
bevl_v = (new BEC_2_5_3_BuildVar()).bem_new_0();
bevt_101_tmpany_phold = bevl_i.bemd_0(967076058);
bevl_v.bemd_1(-2014090818, bevt_101_tmpany_phold);
bevt_102_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_v.bemd_1(15928193, bevt_102_tmpany_phold);
bevl_i.bemd_1(2051313313, bevl_v);
bevt_103_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_i.bemd_1(954110771, bevt_103_tmpany_phold);
bevl_i.bemd_0(-1670792013);
} /* Line: 140 */
 else  /* Line: 131 */ {
bevt_105_tmpany_phold = bevl_i.bemd_0(-1264552924);
bevt_106_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bemd_1(604922157, bevt_106_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_104_tmpany_phold).bevi_bool) /* Line: 141 */ {
bevt_108_tmpany_phold = bevl_ix.bemd_0(-1264552924);
bevt_109_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_107_tmpany_phold = bevt_108_tmpany_phold.bemd_1(604922157, bevt_109_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_107_tmpany_phold).bevi_bool) /* Line: 142 */ {
bevt_110_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_numargs = bevl_numargs.bemd_1(-1524368885, bevt_110_tmpany_phold);
bevt_111_tmpany_phold = bevl_i.bemd_0(967076058);
bevt_112_tmpany_phold = bevl_ix.bemd_0(967076058);
bevt_111_tmpany_phold.bemd_1(-2014090818, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = bevl_i.bemd_0(967076058);
bevt_114_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_113_tmpany_phold.bemd_1(15928193, bevt_114_tmpany_phold);
bevl_i.bemd_0(-1670792013);
bevt_115_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevl_ix.bemd_1(954110771, bevt_115_tmpany_phold);
} /* Line: 147 */
 else  /* Line: 148 */ {
bevt_117_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(30, bece_BEC_3_5_5_5_BuildVisitPass6_bels_3));
bevt_116_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_117_tmpany_phold, bevl_i);
throw new be.BECS_ThrowBack(bevt_116_tmpany_phold);
} /* Line: 149 */
} /* Line: 142 */
} /* Line: 131 */
} /* Line: 131 */
} /* Line: 131 */
 else  /* Line: 126 */ {
break;
} /* Line: 126 */
} /* Line: 126 */
bevl_ii = bevl_toremove.bemd_0(654084467);
while (true)
 /* Line: 153 */ {
bevt_118_tmpany_phold = bevl_ii.bemd_0(-1361309742);
if (((BEC_2_5_4_LogicBool) bevt_118_tmpany_phold).bevi_bool) /* Line: 153 */ {
bevl_i = bevl_ii.bemd_0(901258413);
bevl_i.bemd_0(35553437);
} /* Line: 155 */
 else  /* Line: 153 */ {
break;
} /* Line: 153 */
} /* Line: 153 */
bevl_s = beva_node.bem_heldGet_0();
bevt_120_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_119_tmpany_phold = bevl_numargs.bemd_1(275405729, bevt_120_tmpany_phold);
bevl_s.bemd_1(-325928578, bevt_119_tmpany_phold);
bevt_121_tmpany_phold = bevl_s.bemd_0(1724631906);
bevl_s.bemd_1(-1361764638, bevt_121_tmpany_phold);
bevt_124_tmpany_phold = bevl_s.bemd_0(1724631906);
bevt_125_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_3_5_5_5_BuildVisitPass6_bels_4));
bevt_123_tmpany_phold = bevt_124_tmpany_phold.bemd_1(-1524368885, bevt_125_tmpany_phold);
bevt_127_tmpany_phold = bevl_s.bemd_0(-434729377);
bevt_126_tmpany_phold = bevt_127_tmpany_phold.bemd_0(1028683886);
bevt_122_tmpany_phold = bevt_123_tmpany_phold.bemd_1(-1524368885, bevt_126_tmpany_phold);
bevl_s.bemd_1(-2014090818, bevt_122_tmpany_phold);
bevl_i = beva_node.bem_secondGet_0();
bevt_129_tmpany_phold = bevl_i.bemd_0(-1264552924);
bevt_130_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_128_tmpany_phold = bevt_129_tmpany_phold.bemd_1(604922157, bevt_130_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_128_tmpany_phold).bevi_bool) /* Line: 162 */ {
bevl_i.bemd_0(-1129261706);
bevt_131_tmpany_phold = bevl_i.bemd_0(967076058);
bevl_s.bemd_1(72597, bevt_131_tmpany_phold);
bevt_134_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_133_tmpany_phold = bevt_134_tmpany_phold.bemd_0(-1249959892);
if (bevt_133_tmpany_phold == null) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevl_s.bemd_1(72597, null);
} /* Line: 168 */
 else  /* Line: 166 */ {
bevt_138_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_137_tmpany_phold = bevt_138_tmpany_phold.bemd_0(-1249959892);
bevt_136_tmpany_phold = bevt_137_tmpany_phold.bemd_0(1028683886);
bevt_139_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_5));
bevt_135_tmpany_phold = bevt_136_tmpany_phold.bemd_1(604922157, bevt_139_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_135_tmpany_phold).bevi_bool) /* Line: 169 */ {
bevt_140_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_141_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_140_tmpany_phold.bemd_1(1964919345, bevt_141_tmpany_phold);
bevt_142_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_143_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_142_tmpany_phold.bemd_1(1310041226, bevt_143_tmpany_phold);
bevt_144_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_145_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_144_tmpany_phold.bemd_1(521044993, bevt_145_tmpany_phold);
bevt_147_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_146_tmpany_phold = bevt_147_tmpany_phold.bemd_0(-1249959892);
bevt_148_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_6));
bevt_146_tmpany_phold.bemd_1(312613785, bevt_148_tmpany_phold);
} /* Line: 174 */
 else  /* Line: 166 */ {
bevt_152_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_151_tmpany_phold = bevt_152_tmpany_phold.bemd_0(-1249959892);
bevt_150_tmpany_phold = bevt_151_tmpany_phold.bemd_0(1028683886);
bevt_153_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_7));
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(604922157, bevt_153_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_149_tmpany_phold).bevi_bool) /* Line: 175 */ {
bevt_154_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_155_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_154_tmpany_phold.bemd_1(1964919345, bevt_155_tmpany_phold);
bevt_156_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_157_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_156_tmpany_phold.bemd_1(1310041226, bevt_157_tmpany_phold);
} /* Line: 177 */
} /* Line: 166 */
} /* Line: 166 */
bevl_i.bemd_0(35553437);
} /* Line: 179 */
 else  /* Line: 180 */ {
bevt_158_tmpany_phold = (BEC_2_5_3_BuildVar) (new BEC_2_5_3_BuildVar()).bem_new_0();
bevl_s.bemd_1(72597, bevt_158_tmpany_phold);
bevt_159_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_160_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_159_tmpany_phold.bemd_1(1964919345, bevt_160_tmpany_phold);
bevt_161_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_162_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_161_tmpany_phold.bemd_1(1310041226, bevt_162_tmpany_phold);
bevt_163_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_164_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_163_tmpany_phold.bemd_1(521044993, bevt_164_tmpany_phold);
bevt_165_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_166_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_165_tmpany_phold.bemd_1(-1932283247, bevt_166_tmpany_phold);
bevt_167_tmpany_phold = bevl_s.bemd_0(418521760);
bevt_169_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass6_bels_8));
bevt_168_tmpany_phold = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_1(bevt_169_tmpany_phold);
bevt_167_tmpany_phold.bemd_1(-1303036645, bevt_168_tmpany_phold);
} /* Line: 186 */
bevl_clnode = beva_node.bem_classGet_0();
bevt_171_tmpany_phold = bevl_clnode.bemd_0(967076058);
bevt_170_tmpany_phold = bevt_171_tmpany_phold.bemd_0(2120178754);
bevt_172_tmpany_phold = bevl_s.bemd_0(1724631906);
bevt_170_tmpany_phold.bemd_2(-1579563378, bevt_172_tmpany_phold, beva_node);
bevt_174_tmpany_phold = bevl_clnode.bemd_0(967076058);
bevt_173_tmpany_phold = bevt_174_tmpany_phold.bemd_0(189729917);
bevt_173_tmpany_phold.bemd_1(742596414, beva_node);
} /* Line: 190 */
} /* Line: 22 */
} /* Line: 22 */
} /* Line: 22 */
bevt_175_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_175_tmpany_phold;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {18, 21, 22, 22, 22, 22, 23, 24, 24, 24, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 24, 0, 0, 0, 24, 24, 24, 24, 24, 24, 0, 0, 0, 26, 27, 27, 27, 27, 0, 27, 27, 29, 29, 31, 31, 32, 34, 35, 35, 35, 35, 36, 37, 37, 37, 38, 38, 41, 45, 46, 47, 49, 50, 50, 50, 52, 53, 56, 57, 57, 57, 58, 61, 61, 62, 63, 63, 66, 67, 67, 67, 67, 68, 69, 70, 70, 70, 70, 0, 70, 70, 72, 72, 73, 75, 75, 76, 76, 76, 77, 77, 78, 79, 81, 81, 81, 81, 82, 82, 83, 84, 84, 84, 84, 84, 0, 0, 0, 85, 86, 86, 87, 88, 89, 90, 90, 91, 92, 93, 93, 94, 95, 96, 96, 96, 97, 97, 97, 98, 98, 105, 106, 107, 108, 109, 111, 111, 111, 111, 111, 0, 0, 0, 112, 113, 116, 116, 117, 117, 117, 117, 118, 118, 119, 120, 121, 121, 122, 122, 123, 124, 125, 126, 126, 126, 127, 128, 131, 131, 131, 132, 133, 133, 133, 134, 134, 135, 136, 136, 137, 137, 138, 139, 139, 140, 141, 141, 141, 142, 142, 142, 143, 143, 144, 144, 144, 145, 145, 145, 146, 147, 147, 149, 149, 149, 153, 153, 154, 155, 157, 158, 158, 158, 159, 159, 160, 160, 160, 160, 160, 160, 160, 161, 162, 162, 162, 163, 165, 165, 166, 166, 166, 166, 168, 169, 169, 169, 169, 169, 171, 171, 171, 172, 172, 172, 173, 173, 173, 174, 174, 174, 174, 175, 175, 175, 175, 175, 176, 176, 176, 177, 177, 177, 179, 181, 181, 182, 182, 182, 183, 183, 183, 184, 184, 184, 185, 185, 185, 186, 186, 186, 186, 188, 189, 189, 189, 189, 190, 190, 190, 192, 192};
public static new int[] bevs_smnlec
 = new int[] {224, 225, 226, 227, 228, 233, 234, 235, 236, 241, 242, 243, 244, 245, 250, 251, 254, 258, 261, 262, 263, 264, 269, 270, 273, 277, 280, 281, 282, 283, 284, 285, 287, 290, 294, 297, 298, 299, 300, 301, 306, 307, 310, 314, 317, 318, 319, 320, 321, 321, 324, 326, 327, 328, 334, 335, 336, 338, 339, 340, 341, 344, 346, 347, 348, 349, 351, 352, 353, 361, 363, 364, 366, 367, 368, 369, 372, 373, 375, 376, 377, 378, 380, 382, 387, 388, 389, 390, 392, 395, 396, 397, 402, 403, 404, 405, 406, 407, 408, 408, 411, 413, 414, 415, 416, 422, 423, 424, 425, 426, 427, 430, 432, 433, 441, 442, 443, 448, 449, 454, 455, 458, 463, 464, 465, 466, 468, 471, 475, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 498, 499, 500, 503, 505, 506, 513, 514, 515, 516, 517, 523, 528, 529, 530, 531, 533, 536, 540, 543, 544, 547, 548, 551, 552, 553, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 574, 576, 577, 578, 579, 580, 582, 585, 586, 587, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 602, 603, 604, 606, 607, 608, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 623, 624, 625, 635, 638, 640, 641, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 665, 666, 667, 668, 669, 670, 675, 676, 679, 680, 681, 682, 683, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 700, 701, 702, 703, 704, 706, 707, 708, 709, 710, 711, 715, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 737, 738, 739, 740, 741, 742, 743, 744, 749, 750};
/* BEGIN LINEINFO 
resolveNp 0 18 224
assign 1 21 225
nextPeerGet 0 21 225
assign 1 22 226
typenameGet 0 22 226
assign 1 22 227
EMITGet 0 22 227
assign 1 22 228
equals 1 22 233
assign 1 23 234
nextAscendGet 0 23 234
assign 1 24 235
containedGet 0 24 235
assign 1 24 236
def 1 24 241
assign 1 24 242
containedGet 0 24 242
assign 1 24 243
lengthGet 0 24 243
assign 1 24 244
new 0 24 244
assign 1 24 245
greater 1 24 250
assign 1 0 251
assign 1 0 254
assign 1 0 258
assign 1 24 261
containedGet 0 24 261
assign 1 24 262
firstGet 0 24 262
assign 1 24 263
containedGet 0 24 263
assign 1 24 264
def 1 24 269
assign 1 0 270
assign 1 0 273
assign 1 0 277
assign 1 24 280
containedGet 0 24 280
assign 1 24 281
firstGet 0 24 281
assign 1 24 282
containedGet 0 24 282
assign 1 24 283
lengthGet 0 24 283
assign 1 24 284
new 0 24 284
assign 1 24 285
greater 1 24 285
assign 1 0 287
assign 1 0 290
assign 1 0 294
assign 1 24 297
secondGet 0 24 297
assign 1 24 298
containedGet 0 24 298
assign 1 24 299
lengthGet 0 24 299
assign 1 24 300
new 0 24 300
assign 1 24 301
greater 1 24 306
assign 1 0 307
assign 1 0 310
assign 1 0 314
assign 1 26 317
new 0 26 317
assign 1 27 318
containedGet 0 27 318
assign 1 27 319
firstGet 0 27 319
assign 1 27 320
containedGet 0 27 320
assign 1 27 321
iteratorGet 0 0 321
assign 1 27 324
hasNextGet 0 27 324
assign 1 27 326
nextGet 0 27 326
assign 1 29 327
heldGet 0 29 327
addValue 1 29 328
assign 1 31 334
new 0 31 334
delete 1 31 335
assign 1 32 336
new 0 32 336
assign 1 34 338
new 0 34 338
assign 1 35 339
secondGet 0 35 339
assign 1 35 340
containedGet 0 35 340
assign 1 35 341
iteratorGet 0 35 341
assign 1 35 344
hasNextGet 0 35 344
assign 1 36 346
nextGet 0 36 346
assign 1 37 347
typenameGet 0 37 347
assign 1 37 348
STRINGLGet 0 37 348
assign 1 37 349
equals 1 37 349
assign 1 38 351
heldGet 0 38 351
heldSet 1 38 352
assign 1 41 353
new 0 41 353
assign 1 45 361
not 0 45 361
delete 0 46 363
return 1 47 364
containedSet 1 49 366
assign 1 50 367
heldGet 0 50 367
assign 1 50 368
new 2 50 368
heldSet 1 50 369
delete 0 52 372
return 1 53 373
assign 1 56 375
scopeGet 0 56 375
assign 1 57 376
typenameGet 0 57 376
assign 1 57 377
METHODGet 0 57 377
assign 1 57 378
equals 1 57 378
assign 1 58 380
assign 1 61 382
def 1 61 387
delete 0 62 388
assign 1 63 389
heldGet 0 63 389
addEmit 1 63 390
return 1 66 392
assign 1 67 395
typenameGet 0 67 395
assign 1 67 396
IFEMITGet 0 67 396
assign 1 67 397
equals 1 67 402
assign 1 68 403
new 0 68 403
assign 1 69 404
new 0 69 404
assign 1 70 405
containedGet 0 70 405
assign 1 70 406
firstGet 0 70 406
assign 1 70 407
containedGet 0 70 407
assign 1 70 408
iteratorGet 0 0 408
assign 1 70 411
hasNextGet 0 70 411
assign 1 70 413
nextGet 0 70 413
assign 1 72 414
heldGet 0 72 414
addValue 1 72 415
addValue 1 73 416
assign 1 75 422
new 0 75 422
delete 1 75 423
assign 1 76 424
heldGet 0 76 424
assign 1 76 425
new 2 76 425
heldSet 1 76 426
assign 1 77 427
iteratorGet 0 77 427
assign 1 77 430
hasNextGet 0 77 430
assign 1 78 432
nextGet 0 78 432
delete 0 79 433
assign 1 81 441
typenameGet 0 81 441
assign 1 81 442
IFGet 0 81 442
assign 1 81 443
equals 1 81 448
assign 1 82 449
def 1 82 454
assign 1 83 455
assign 1 84 458
def 1 84 463
assign 1 84 464
typenameGet 0 84 464
assign 1 84 465
ELIFGet 0 84 465
assign 1 84 466
equals 1 84 466
assign 1 0 468
assign 1 0 471
assign 1 0 475
assign 1 85 478
new 1 85 478
assign 1 86 479
ELSEGet 0 86 479
typenameSet 1 86 480
copyLoc 1 87 481
assign 1 88 482
new 1 88 482
copyLoc 1 89 483
assign 1 90 484
BRACESGet 0 90 484
typenameSet 1 90 485
assign 1 91 486
new 1 91 486
copyLoc 1 92 487
assign 1 93 488
IFGet 0 93 488
typenameSet 1 93 489
addValue 1 94 490
addValue 1 95 491
assign 1 96 492
containedGet 0 96 492
assign 1 96 493
def 1 96 498
assign 1 97 499
containedGet 0 97 499
assign 1 97 500
iteratorGet 0 97 500
assign 1 97 503
hasNextGet 0 97 503
assign 1 98 505
nextGet 0 98 505
addValue 1 98 506
addValue 1 105 513
assign 1 106 514
assign 1 107 515
nextPeerGet 0 107 515
delete 0 108 516
assign 1 109 517
assign 1 111 523
def 1 111 528
assign 1 111 529
typenameGet 0 111 529
assign 1 111 530
ELSEGet 0 111 530
assign 1 111 531
equals 1 111 531
assign 1 0 533
assign 1 0 536
assign 1 0 540
delete 0 112 543
addValue 1 113 544
assign 1 116 547
nextDescendGet 0 116 547
return 1 116 548
assign 1 117 551
typenameGet 0 117 551
assign 1 117 552
METHODGet 0 117 552
assign 1 117 553
equals 1 117 558
assign 1 118 559
containedGet 0 118 559
assign 1 118 560
firstGet 0 118 560
assign 1 119 561
new 1 119 561
copyLoc 1 120 562
assign 1 121 563
IDGet 0 121 563
typenameSet 1 121 564
assign 1 122 565
new 0 122 565
heldSet 1 122 566
prepend 1 123 567
assign 1 124 568
new 0 124 568
assign 1 125 569
new 0 125 569
assign 1 126 570
containedGet 0 126 570
assign 1 126 571
iteratorGet 0 126 571
assign 1 126 574
hasNextGet 0 126 574
assign 1 127 576
nextGet 0 127 576
assign 1 128 577
nextPeerGet 0 128 577
assign 1 131 578
typenameGet 0 131 578
assign 1 131 579
COMMAGet 0 131 579
assign 1 131 580
equals 1 131 580
addValue 1 132 582
assign 1 133 585
typenameGet 0 133 585
assign 1 133 586
IDGet 0 133 586
assign 1 133 587
equals 1 133 587
assign 1 134 589
new 0 134 589
assign 1 134 590
add 1 134 590
assign 1 135 591
new 0 135 591
assign 1 136 592
heldGet 0 136 592
nameSet 1 136 593
assign 1 137 594
new 0 137 594
isArgSet 1 137 595
heldSet 1 138 596
assign 1 139 597
VARGet 0 139 597
typenameSet 1 139 598
addVariable 0 140 599
assign 1 141 602
typenameGet 0 141 602
assign 1 141 603
VARGet 0 141 603
assign 1 141 604
equals 1 141 604
assign 1 142 606
typenameGet 0 142 606
assign 1 142 607
IDGet 0 142 607
assign 1 142 608
equals 1 142 608
assign 1 143 610
new 0 143 610
assign 1 143 611
add 1 143 611
assign 1 144 612
heldGet 0 144 612
assign 1 144 613
heldGet 0 144 613
nameSet 1 144 614
assign 1 145 615
heldGet 0 145 615
assign 1 145 616
new 0 145 616
isArgSet 1 145 617
addVariable 0 146 618
assign 1 147 619
COMMAGet 0 147 619
typenameSet 1 147 620
assign 1 149 623
new 0 149 623
assign 1 149 624
new 2 149 624
throw 1 149 625
assign 1 153 635
iteratorGet 0 153 635
assign 1 153 638
hasNextGet 0 153 638
assign 1 154 640
nextGet 0 154 640
delete 0 155 641
assign 1 157 647
heldGet 0 157 647
assign 1 158 648
new 0 158 648
assign 1 158 649
subtract 1 158 649
numargsSet 1 158 650
assign 1 159 651
nameGet 0 159 651
orgNameSet 1 159 652
assign 1 160 653
nameGet 0 160 653
assign 1 160 654
new 0 160 654
assign 1 160 655
add 1 160 655
assign 1 160 656
numargsGet 0 160 656
assign 1 160 657
toString 0 160 657
assign 1 160 658
add 1 160 658
nameSet 1 160 659
assign 1 161 660
secondGet 0 161 660
assign 1 162 661
typenameGet 0 162 661
assign 1 162 662
VARGet 0 162 662
assign 1 162 663
equals 1 162 663
resolveNp 0 163 665
assign 1 165 666
heldGet 0 165 666
rtypeSet 1 165 667
assign 1 166 668
rtypeGet 0 166 668
assign 1 166 669
namepathGet 0 166 669
assign 1 166 670
undef 1 166 675
rtypeSet 1 168 676
assign 1 169 679
rtypeGet 0 169 679
assign 1 169 680
namepathGet 0 169 680
assign 1 169 681
toString 0 169 681
assign 1 169 682
new 0 169 682
assign 1 169 683
equals 1 169 683
assign 1 171 685
rtypeGet 0 171 685
assign 1 171 686
new 0 171 686
isTypedSet 1 171 687
assign 1 172 688
rtypeGet 0 172 688
assign 1 172 689
new 0 172 689
isSelfSet 1 172 690
assign 1 173 691
rtypeGet 0 173 691
assign 1 173 692
new 0 173 692
isThisSet 1 173 693
assign 1 174 694
rtypeGet 0 174 694
assign 1 174 695
namepathGet 0 174 695
assign 1 174 696
new 0 174 696
pathSet 1 174 697
assign 1 175 700
rtypeGet 0 175 700
assign 1 175 701
namepathGet 0 175 701
assign 1 175 702
toString 0 175 702
assign 1 175 703
new 0 175 703
assign 1 175 704
equals 1 175 704
assign 1 176 706
rtypeGet 0 176 706
assign 1 176 707
new 0 176 707
isTypedSet 1 176 708
assign 1 177 709
rtypeGet 0 177 709
assign 1 177 710
new 0 177 710
isSelfSet 1 177 711
delete 0 179 715
assign 1 181 718
new 0 181 718
rtypeSet 1 181 719
assign 1 182 720
rtypeGet 0 182 720
assign 1 182 721
new 0 182 721
isTypedSet 1 182 722
assign 1 183 723
rtypeGet 0 183 723
assign 1 183 724
new 0 183 724
isSelfSet 1 183 725
assign 1 184 726
rtypeGet 0 184 726
assign 1 184 727
new 0 184 727
isThisSet 1 184 728
assign 1 185 729
rtypeGet 0 185 729
assign 1 185 730
new 0 185 730
impliedSet 1 185 731
assign 1 186 732
rtypeGet 0 186 732
assign 1 186 733
new 0 186 733
assign 1 186 734
new 1 186 734
namepathSet 1 186 735
assign 1 188 737
classGet 0 188 737
assign 1 189 738
heldGet 0 189 738
assign 1 189 739
methodsGet 0 189 739
assign 1 189 740
nameGet 0 189 740
put 2 189 741
assign 1 190 742
heldGet 0 190 742
assign 1 190 743
orderedMethodsGet 0 190 743
addValue 1 190 744
assign 1 192 749
nextDescendGet 0 192 749
return 1 192 750
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -386157741: return bem_serializeToString_0();
case 1028683886: return bem_toString_0();
case -1036233638: return bem_new_0();
case -134370284: return bem_ntypesGet_0();
case -1493103250: return bem_many_0();
case -1312519804: return bem_hashGet_0();
case 863669946: return bem_toAny_0();
case -454910570: return bem_create_0();
case -1057001629: return bem_copy_0();
case -354590014: return bem_print_0();
case 1048772166: return bem_echo_0();
case 714392359: return bem_classNameGet_0();
case -1960550314: return bem_buildGet_0();
case -1874213289: return bem_tagGet_0();
case -362321661: return bem_deserializeClassNameGet_0();
case -354093047: return bem_serializationIteratorGet_0();
case -551298753: return bem_sourceFileNameGet_0();
case 654084467: return bem_iteratorGet_0();
case -1762972061: return bem_transGet_0();
case 1836947478: return bem_serializeContents_0();
case -76505233: return bem_once_0();
case -1963468660: return bem_fieldIteratorGet_0();
case -427482859: return bem_constGet_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -403482348: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 729561267: return bem_copyTo_1(bevd_0);
case -1963700542: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1184340301: return bem_otherClass_1(bevd_0);
case -291321785: return bem_begin_1(bevd_0);
case 1279791754: return bem_buildSet_1(bevd_0);
case -504315826: return bem_sameObject_1(bevd_0);
case -999936361: return bem_defined_1(bevd_0);
case -1475207948: return bem_transSet_1(bevd_0);
case -1374275511: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -747350143: return bem_undef_1(bevd_0);
case -2006049248: return bem_end_1(bevd_0);
case 925024598: return bem_ntypesSet_1(bevd_0);
case 1348337682: return bem_constSet_1(bevd_0);
case 2095964872: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -558198774: return bem_def_1(bevd_0);
case 1672825312: return bem_notEquals_1(bevd_0);
case 604922157: return bem_equals_1(bevd_0);
case 1782921206: return bem_otherType_1(bevd_0);
case -1188536421: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1978731115: return bem_sameType_1(bevd_0);
case -965306462: return bem_undefined_1(bevd_0);
case 1301577712: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -249962556: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -608983707: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 913536943: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1192068648: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1655666515: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 478589859: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2045713194: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass6_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass6_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass6();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst = (BEC_3_5_5_5_BuildVisitPass6) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass6.bece_BEC_3_5_5_5_BuildVisitPass6_bevs_type;
}
}
}
