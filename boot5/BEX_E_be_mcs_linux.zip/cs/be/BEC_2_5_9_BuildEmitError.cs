namespace be {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError : BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
static BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static new BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1242864862: return bem_sourceFileNameGet_0();
case -1363935153: return bem_langGetDirect_0();
case 1546600427: return bem_vvGetDirect_0();
case 1388220454: return bem_once_0();
case 1978340744: return bem_copy_0();
case -893140774: return bem_msgGet_0();
case 1267081794: return bem_methodNameGet_0();
case -588447981: return bem_emitLangGet_0();
case -485032950: return bem_print_0();
case 1076431645: return bem_lineNumberGetDirect_0();
case 1139687182: return bem_serializeToString_0();
case -1666892197: return bem_translateEmittedException_0();
case 2117688255: return bem_nodeGet_0();
case -1191467783: return bem_framesGetDirect_0();
case -1936404363: return bem_create_0();
case -533304425: return bem_framesTextGet_0();
case -1461089031: return bem_translatedGetDirect_0();
case 1115941233: return bem_hashGet_0();
case 1976427553: return bem_klassNameGetDirect_0();
case 347445468: return bem_deserializeClassNameGet_0();
case 1397900268: return bem_msgGetDirect_0();
case 1809234022: return bem_framesTextGetDirect_0();
case -380774728: return bem_serializationIteratorGet_0();
case 1044385788: return bem_new_0();
case 600528685: return bem_lineNumberGet_0();
case 1339527550: return bem_klassNameGet_0();
case 876979386: return bem_iteratorGet_0();
case 262448459: return bem_fieldNamesGet_0();
case 1846641427: return bem_classNameGet_0();
case 1222284310: return bem_translateEmittedExceptionInner_0();
case 1663093821: return bem_nodeGetDirect_0();
case -888974938: return bem_descriptionGet_0();
case -139211751: return bem_framesGet_0();
case 1109517661: return bem_emitLangGetDirect_0();
case -1718750264: return bem_tagGet_0();
case 1023220234: return bem_translatedGet_0();
case -1287291624: return bem_toString_0();
case -1030747721: return bem_methodNameGetDirect_0();
case -1820718044: return bem_echo_0();
case 1039576783: return bem_vvGet_0();
case 1348460493: return bem_fileNameGetDirect_0();
case -1889562117: return bem_descriptionGetDirect_0();
case -1283336034: return bem_langGet_0();
case 1516511629: return bem_serializeContents_0();
case -418256728: return bem_fileNameGet_0();
case -2113195206: return bem_getFrameText_0();
case -1497387944: return bem_many_0();
case 1739040137: return bem_fieldIteratorGet_0();
case 855089063: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2098981350: return bem_methodNameSetDirect_1(bevd_0);
case -784770856: return bem_framesTextSetDirect_1(bevd_0);
case -2007638939: return bem_otherClass_1(bevd_0);
case -2135475151: return bem_emitLangSetDirect_1(bevd_0);
case 1646230583: return bem_defined_1(bevd_0);
case -1465831844: return bem_new_1(bevd_0);
case 1489007559: return bem_vvSet_1(bevd_0);
case -971916964: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1575911030: return bem_lineNumberSet_1(bevd_0);
case 205689082: return bem_lineNumberSetDirect_1(bevd_0);
case -438440103: return bem_equals_1(bevd_0);
case 1239361667: return bem_methodNameSet_1(bevd_0);
case -627862337: return bem_translatedSetDirect_1(bevd_0);
case -1010984900: return bem_nodeSet_1(bevd_0);
case -630597728: return bem_klassNameSetDirect_1(bevd_0);
case 97106689: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -660834435: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 791565359: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1384332553: return bem_undef_1(bevd_0);
case 1404127527: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1136666389: return bem_emitLangSet_1(bevd_0);
case 2022005382: return bem_descriptionSet_1(bevd_0);
case 301718756: return bem_vvSetDirect_1(bevd_0);
case 383466691: return bem_framesTextSet_1(bevd_0);
case 1388023994: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case -209032796: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -374531694: return bem_notEquals_1(bevd_0);
case 1295661645: return bem_otherType_1(bevd_0);
case -1885890319: return bem_fileNameSet_1(bevd_0);
case -847200836: return bem_def_1(bevd_0);
case -82611809: return bem_msgSetDirect_1(bevd_0);
case 1465976030: return bem_translatedSet_1(bevd_0);
case -2146658960: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 2109739292: return bem_nodeSetDirect_1(bevd_0);
case 1769191019: return bem_langSet_1(bevd_0);
case -730531024: return bem_sameClass_1(bevd_0);
case -178401294: return bem_klassNameSet_1(bevd_0);
case -857760198: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1281786394: return bem_msgSet_1(bevd_0);
case 2051886804: return bem_copyTo_1(bevd_0);
case -1146451068: return bem_sameType_1(bevd_0);
case -621631535: return bem_descriptionSetDirect_1(bevd_0);
case 67916180: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1335269315: return bem_fileNameSetDirect_1(bevd_0);
case 2117320848: return bem_framesSet_1(bevd_0);
case 1460354071: return bem_sameObject_1(bevd_0);
case -1631337922: return bem_framesSetDirect_1(bevd_0);
case 477404510: return bem_undefined_1(bevd_0);
case 1812900623: return bem_langSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -591803181: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1887722661: return bem_new_2(bevd_0, bevd_1);
case 1964080063: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 270145450: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 304620225: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 973582611: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -990881026: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1563706243: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1722657179: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildEmitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
}
