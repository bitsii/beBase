namespace be {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError : BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
static BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static new BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1403688004: return bem_serializationIteratorGet_0();
case -1251058940: return bem_vvGet_0();
case 204598457: return bem_nodeGetDirect_0();
case 93597870: return bem_lineNumberGetDirect_0();
case -550450080: return bem_msgGetDirect_0();
case -1363819567: return bem_new_0();
case 259796548: return bem_framesTextGetDirect_0();
case 1597327951: return bem_create_0();
case -1632157064: return bem_descriptionGetDirect_0();
case -1188922735: return bem_echo_0();
case 741313363: return bem_fileNameGetDirect_0();
case 2048877069: return bem_translateEmittedException_0();
case 1575751651: return bem_methodNameGetDirect_0();
case -447432319: return bem_many_0();
case 95333973: return bem_translatedGet_0();
case -1760538533: return bem_classNameGet_0();
case 1476867902: return bem_framesTextGet_0();
case 371157924: return bem_sourceFileNameGet_0();
case 973952764: return bem_framesGet_0();
case 714512595: return bem_klassNameGet_0();
case -793241295: return bem_iteratorGet_0();
case -196767030: return bem_lineNumberGet_0();
case -1323898541: return bem_toAny_0();
case 1890854002: return bem_tagGet_0();
case 7254011: return bem_fieldIteratorGet_0();
case 1871809739: return bem_nodeGet_0();
case 361458285: return bem_emitLangGetDirect_0();
case -921473949: return bem_fieldNamesGet_0();
case 895193825: return bem_once_0();
case -369490178: return bem_vvGetDirect_0();
case 153051846: return bem_translateEmittedExceptionInner_0();
case 1319388306: return bem_copy_0();
case -39165288: return bem_deserializeClassNameGet_0();
case -581365998: return bem_emitLangGet_0();
case -820066553: return bem_langGet_0();
case -1387831588: return bem_print_0();
case 1343568937: return bem_fileNameGet_0();
case 1092105192: return bem_hashGet_0();
case -467511392: return bem_toString_0();
case -1951322969: return bem_methodNameGet_0();
case -105946774: return bem_serializeToString_0();
case 1656515879: return bem_msgGet_0();
case 1859617256: return bem_langGetDirect_0();
case 1382066941: return bem_getFrameText_0();
case -134328513: return bem_framesGetDirect_0();
case 423200525: return bem_descriptionGet_0();
case 1652521523: return bem_serializeContents_0();
case 177638386: return bem_klassNameGetDirect_0();
case 1894026264: return bem_translatedGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1929898803: return bem_new_1(bevd_0);
case -1334315963: return bem_undefined_1(bevd_0);
case -801423641: return bem_msgSet_1(bevd_0);
case -75378845: return bem_lineNumberSetDirect_1(bevd_0);
case -811261495: return bem_defined_1(bevd_0);
case 1915820953: return bem_langSetDirect_1(bevd_0);
case -257255078: return bem_descriptionSet_1(bevd_0);
case 883456662: return bem_sameObject_1(bevd_0);
case 1625440144: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1513900605: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1698118121: return bem_methodNameSetDirect_1(bevd_0);
case -836682374: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1814775779: return bem_sameType_1(bevd_0);
case -506225488: return bem_langSet_1(bevd_0);
case -225460082: return bem_msgSetDirect_1(bevd_0);
case -317302260: return bem_framesSet_1(bevd_0);
case 1718716940: return bem_framesTextSetDirect_1(bevd_0);
case -1187970594: return bem_methodNameSet_1(bevd_0);
case -526991705: return bem_fileNameSetDirect_1(bevd_0);
case -619345365: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -686810675: return bem_copyTo_1(bevd_0);
case -735992951: return bem_framesSetDirect_1(bevd_0);
case 631154840: return bem_descriptionSetDirect_1(bevd_0);
case -1906955196: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1488511778: return bem_otherType_1(bevd_0);
case -1283793991: return bem_lineNumberSet_1(bevd_0);
case -919397544: return bem_translatedSet_1(bevd_0);
case -1630115170: return bem_vvSetDirect_1(bevd_0);
case 1368699211: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -476285204: return bem_otherClass_1(bevd_0);
case -926817517: return bem_emitLangSet_1(bevd_0);
case -1027010341: return bem_vvSet_1(bevd_0);
case 596540473: return bem_equals_1(bevd_0);
case -376901622: return bem_sameClass_1(bevd_0);
case -795832604: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1519277296: return bem_notEquals_1(bevd_0);
case -1065018030: return bem_undef_1(bevd_0);
case -2139044033: return bem_framesTextSet_1(bevd_0);
case -518653111: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 1366489939: return bem_emitLangSetDirect_1(bevd_0);
case -2028383352: return bem_fileNameSet_1(bevd_0);
case 668613338: return bem_klassNameSetDirect_1(bevd_0);
case -1418727326: return bem_nodeSetDirect_1(bevd_0);
case -1969088166: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1798361106: return bem_def_1(bevd_0);
case -751588768: return bem_nodeSet_1(bevd_0);
case -1893599339: return bem_klassNameSet_1(bevd_0);
case -1576223665: return bem_translatedSetDirect_1(bevd_0);
case 497196599: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 1973904590: return bem_new_2(bevd_0, bevd_1);
case -625270708: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -256440385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -250446434: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1381141557: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 228877529: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 878556511: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1788484463: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case 1828456901: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildEmitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
}
