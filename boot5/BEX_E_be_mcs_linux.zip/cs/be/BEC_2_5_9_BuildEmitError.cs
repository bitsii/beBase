namespace be {
/* IO:File: source/build/CEmitter.be */
public class BEC_2_5_9_BuildEmitError : BEC_2_5_10_BuildVisitError {
public BEC_2_5_9_BuildEmitError() { }
static BEC_2_5_9_BuildEmitError() { }
private static byte[] becc_BEC_2_5_9_BuildEmitError_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x45,0x6D,0x69,0x74,0x45,0x72,0x72,0x6F,0x72};
private static byte[] becc_BEC_2_5_9_BuildEmitError_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x43,0x45,0x6D,0x69,0x74,0x74,0x65,0x72,0x2E,0x62,0x65};
public static new BEC_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_inst;

public static new BET_2_5_9_BuildEmitError bece_BEC_2_5_9_BuildEmitError_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -274497692: return bem_lineNumberGet_0();
case 1068983324: return bem_translateEmittedException_0();
case -405773857: return bem_fileNameGet_0();
case -450936668: return bem_fileNameGetDirect_0();
case 818155452: return bem_framesGet_0();
case 1253470336: return bem_translatedGetDirect_0();
case -1097544184: return bem_framesGetDirect_0();
case 2049921022: return bem_serializeContents_0();
case -444140695: return bem_framesTextGet_0();
case 189629538: return bem_klassNameGetDirect_0();
case 2045071205: return bem_vvGetDirect_0();
case -1636262817: return bem_translateEmittedExceptionInner_0();
case 722156191: return bem_create_0();
case 701763907: return bem_new_0();
case 561389448: return bem_copy_0();
case 561437972: return bem_translatedGet_0();
case -1806005539: return bem_getFrameText_0();
case -1391094119: return bem_tagGet_0();
case -541904629: return bem_langGet_0();
case 73901351: return bem_fieldNamesGet_0();
case 330888852: return bem_nodeGet_0();
case 70409796: return bem_fieldIteratorGet_0();
case -71995998: return bem_lineNumberGetDirect_0();
case -1612673222: return bem_echo_0();
case -512259678: return bem_many_0();
case 1972906959: return bem_msgGet_0();
case -565082084: return bem_methodNameGetDirect_0();
case -374298812: return bem_iteratorGet_0();
case 916593265: return bem_descriptionGetDirect_0();
case -196471174: return bem_toAny_0();
case -1486629671: return bem_methodNameGet_0();
case -808549585: return bem_classNameGet_0();
case -967671249: return bem_langGetDirect_0();
case 441719677: return bem_hashGet_0();
case -939215911: return bem_nodeGetDirect_0();
case -751296258: return bem_toString_0();
case -627661593: return bem_serializationIteratorGet_0();
case -2127113784: return bem_sourceFileNameGet_0();
case 1280430641: return bem_deserializeClassNameGet_0();
case -261585893: return bem_vvGet_0();
case 1934380491: return bem_emitLangGetDirect_0();
case -217231212: return bem_klassNameGet_0();
case -406325503: return bem_emitLangGet_0();
case -796966532: return bem_print_0();
case -2048561494: return bem_framesTextGetDirect_0();
case -1255532337: return bem_descriptionGet_0();
case -69849386: return bem_msgGetDirect_0();
case 1610207827: return bem_serializeToString_0();
case 330207183: return bem_once_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1503125154: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1735788362: return bem_klassNameSetDirect_1(bevd_0);
case 1207689343: return bem_methodNameSetDirect_1(bevd_0);
case 2061365720: return bem_emitLangSetDirect_1(bevd_0);
case 199635822: return bem_nodeSet_1(bevd_0);
case 267625935: return bem_translatedSet_1(bevd_0);
case -99045731: return bem_fileNameSet_1(bevd_0);
case 1008423611: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 680756917: return bem_defined_1(bevd_0);
case -2015640631: return bem_framesSet_1(bevd_0);
case 1587984688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 315140957: return bem_fileNameSetDirect_1(bevd_0);
case 1645946581: return bem_notEquals_1(bevd_0);
case 1635498860: return bem_descriptionSet_1(bevd_0);
case 1669229476: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case 659606736: return bem_langSet_1(bevd_0);
case -993409772: return bem_translatedSetDirect_1(bevd_0);
case -1272706644: return bem_copyTo_1(bevd_0);
case 1426246519: return bem_framesTextSetDirect_1(bevd_0);
case 788956945: return bem_undefined_1(bevd_0);
case -134496889: return bem_langSetDirect_1(bevd_0);
case 1141391902: return bem_klassNameSet_1(bevd_0);
case -812851101: return bem_emitLangSet_1(bevd_0);
case 463890253: return bem_undef_1(bevd_0);
case -496785089: return bem_nodeSetDirect_1(bevd_0);
case -778517295: return bem_framesSetDirect_1(bevd_0);
case 1320952802: return bem_sameClass_1(bevd_0);
case 779318692: return bem_vvSet_1(bevd_0);
case 1381682421: return bem_new_1(bevd_0);
case 1070402416: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 1767827947: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1934236484: return bem_sameType_1(bevd_0);
case -585772176: return bem_msgSetDirect_1(bevd_0);
case 1663832524: return bem_lineNumberSet_1(bevd_0);
case 152562377: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1380437617: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1815800747: return bem_methodNameSet_1(bevd_0);
case -468632472: return bem_msgSet_1(bevd_0);
case -1668696125: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1110748051: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 2013056370: return bem_descriptionSetDirect_1(bevd_0);
case 838018215: return bem_framesTextSet_1(bevd_0);
case -1197345309: return bem_otherType_1(bevd_0);
case -1390184780: return bem_lineNumberSetDirect_1(bevd_0);
case -718076406: return bem_vvSetDirect_1(bevd_0);
case 725850689: return bem_equals_1(bevd_0);
case 1649757588: return bem_sameObject_1(bevd_0);
case 803653343: return bem_otherClass_1(bevd_0);
case -191286971: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 235947300: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2053867671: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1365336246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1806210068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2137630710: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1094925459: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1242672538: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 228296778: return bem_new_2(bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1927350713: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildEmitError_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_9_BuildEmitError_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_9_BuildEmitError();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst = (BEC_2_5_9_BuildEmitError) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_9_BuildEmitError.bece_BEC_2_5_9_BuildEmitError_bevs_type;
}
}
}
