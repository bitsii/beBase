namespace be {
/* IO:File: source/build/Pass7.be */
public sealed class BEC_3_5_5_5_BuildVisitPass7 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
static BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_2 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_3 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_4 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_5 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_6 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_7 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass7_bels_8, 41));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_10 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_12 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_15 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_17 = {0x6E,0x65,0x77};
public static new BEC_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;

public static new BET_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;

public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpany_phold.bemd_0(-832566825);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-585724725);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bemd_0(190764838);
} /* Line: 41 */
if (bevp_inClassNp == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 43 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 45 */
bevt_16_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpany_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass7_bels_0));
bevp_build.bem_buildLiteral_2(beva_node, bevt_18_tmpany_phold);
} /* Line: 48 */
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_1));
bevp_build.bem_buildLiteral_2(beva_node, bevt_22_tmpany_phold);
} /* Line: 51 */
bevt_24_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpany_phold.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_26_tmpany_phold);
} /* Line: 54 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_3));
bevp_build.bem_buildLiteral_2(beva_node, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpany_phold);
} /* Line: 59 */
bevt_33_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpany_phold.bevi_int == bevt_34_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
beva_node.bem_heldSet_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_5));
bevp_build.bem_buildLiteral_2(beva_node, bevt_36_tmpany_phold);
} /* Line: 63 */
bevt_38_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpany_phold.bevi_int == bevt_39_tmpany_phold.bevi_int) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 69 */ {
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_6));
beva_node.bem_heldSet_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_7));
bevp_build.bem_buildLiteral_2(beva_node, bevt_41_tmpany_phold);
} /* Line: 71 */
 else  /* Line: 69 */ {
bevt_43_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpany_phold.bevi_int == bevt_44_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(-534756508);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(-1495172070);
if (((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 73 */ {
bevt_50_tmpany_phold = beva_node.bem_heldGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(1096094931);
if (bevt_49_tmpany_phold == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 74 */ {
if (bevl_nnode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_53_tmpany_phold = bevl_nnode.bemd_0(-1055626123);
bevt_54_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(1255352870, bevt_54_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_52_tmpany_phold).bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_57_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0;
bevt_59_tmpany_phold = beva_node.bem_heldGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(1096094931);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_55_tmpany_phold);
} /* Line: 75 */
 else  /* Line: 76 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = bevl_nnode.bemd_0(-1847189180);
bevt_60_tmpany_phold.bemd_1(228258099, bevt_61_tmpany_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(167394867);
bevt_62_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpany_phold;
} /* Line: 83 */
} /* Line: 74 */
 else  /* Line: 69 */ {
bevt_64_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 85 */ {
if (bevl_nnode == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_68_tmpany_phold = bevl_nnode.bemd_0(-1055626123);
bevt_69_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(449026795, bevt_69_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_67_tmpany_phold).bevi_bool) /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 86 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(249501861);
if (bevt_71_tmpany_phold == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = bevl_nnode.bemd_0(249501861);
bevl_ii = bevt_72_tmpany_phold.bemd_0(-193453355);
while (true)
 /* Line: 89 */ {
bevt_73_tmpany_phold = bevl_ii.bemd_0(395045729);
if (((BEC_2_5_4_LogicBool) bevt_73_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevl_i = bevl_ii.bemd_0(1286644729);
bevt_75_tmpany_phold = bevl_i.bemd_0(-1055626123);
bevt_76_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(449026795, bevt_76_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_toremove.bemd_1(1524541780, bevl_i);
} /* Line: 92 */
} /* Line: 91 */
 else  /* Line: 89 */ {
break;
} /* Line: 89 */
} /* Line: 89 */
bevl_ii = bevl_toremove.bemd_0(-193453355);
while (true)
 /* Line: 95 */ {
bevt_77_tmpany_phold = bevl_ii.bemd_0(395045729);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 95 */ {
bevl_i = bevl_ii.bemd_0(1286644729);
bevl_i.bemd_0(167394867);
} /* Line: 97 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
} /* Line: 95 */
bevl_pc = bevl_nnode;
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(-1822887605, bevt_78_tmpany_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(228258099, bevt_79_tmpany_phold);
bevl_pc.bemd_1(1230752984, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_82_tmpany_phold = bevl_dnode.bemd_0(-1055626123);
bevt_83_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(449026795, bevt_83_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_81_tmpany_phold).bevi_bool) /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(2115027558);
if (bevl_onode == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bece_BEC_3_5_5_5_BuildVisitPass7_bels_9));
bevt_85_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpany_phold);
} /* Line: 111 */
 else  /* Line: 110 */ {
bevt_88_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpany_phold.bevi_int == bevt_89_tmpany_phold.bevi_int) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_91_tmpany_phold = bevl_gc.bemd_0(1096094931);
bevt_90_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpany_phold );
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevt_92_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(599659877, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1203387727, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(834406925, bevt_94_tmpany_phold);
} /* Line: 116 */
 else  /* Line: 117 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 118 */
} /* Line: 113 */
 else  /* Line: 110 */ {
bevt_96_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpany_phold.bevi_int == bevt_97_tmpany_phold.bevi_int) {
bevt_95_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_101_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(-1847189180);
bevt_99_tmpany_phold = bevt_100_tmpany_phold.bemd_0(1325170244);
bevt_102_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bemd_1(-1535130404, bevt_102_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_98_tmpany_phold).bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_105_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_aliasedGet_0();
bevt_106_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpany_phold = bevt_104_tmpany_phold.bem_has_1(bevt_106_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpany_phold = bevl_gc.bemd_0(1096094931);
bevt_109_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpany_phold );
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_111_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(599659877, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1203387727, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(834406925, bevt_113_tmpany_phold);
} /* Line: 129 */
 else  /* Line: 130 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 131 */
} /* Line: 126 */
 else  /* Line: 110 */ {
bevt_115_tmpany_phold = bevl_gc.bemd_0(1096094931);
bevt_116_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass7_bels_10));
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(449026795, bevt_116_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_114_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_118_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(70, bece_BEC_3_5_5_5_BuildVisitPass7_bels_11));
bevt_117_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 134 */
 else  /* Line: 110 */ {
bevt_120_tmpany_phold = bevl_gc.bemd_0(1096094931);
bevt_121_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_12));
bevt_119_tmpany_phold = bevt_120_tmpany_phold.bemd_1(449026795, bevt_121_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_119_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_123_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_3_5_5_5_BuildVisitPass7_bels_13));
bevt_122_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_122_tmpany_phold);
} /* Line: 136 */
} /* Line: 110 */
} /* Line: 110 */
} /* Line: 110 */
} /* Line: 110 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(-1839425160, bevl_onode);
bevl_dnode.bemd_0(167394867);
} /* Line: 141 */
 else  /* Line: 142 */ {
bevt_124_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(1203387727, bevt_124_tmpany_phold);
bevt_125_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(599659877, bevt_125_tmpany_phold);
} /* Line: 144 */
} /* Line: 108 */
} /* Line: 86 */
 else  /* Line: 69 */ {
bevt_127_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpany_phold.bevi_int == bevt_128_tmpany_phold.bevi_int) {
bevt_126_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_131_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_14));
bevt_130_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_130_tmpany_phold);
} /* Line: 153 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpany_phold.bevi_int == bevt_134_tmpany_phold.bevi_int) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevt_136_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(84, bece_BEC_3_5_5_5_BuildVisitPass7_bels_15));
bevt_135_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_135_tmpany_phold);
} /* Line: 158 */
bevt_137_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpany_phold);
} /* Line: 160 */
 else  /* Line: 69 */ {
bevt_139_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpany_phold.bevi_int == bevt_140_tmpany_phold.bevi_int) {
bevt_138_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
if (bevl_onode == null) {
bevt_142_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 166 */ {
bevt_144_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_16));
bevt_143_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpany_phold);
} /* Line: 167 */
bevt_146_tmpany_phold = bevl_nnode.bemd_0(-1055626123);
bevt_147_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(449026795, bevt_147_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_145_tmpany_phold).bevi_bool) /* Line: 169 */ {
bevl_pnode = bevl_nnode.bemd_0(-358266384);
if (bevl_pnode == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_150_tmpany_phold = bevl_pnode.bemd_0(-1055626123);
bevt_151_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(1255352870, bevt_151_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_149_tmpany_phold).bevi_bool) /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 171 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpany_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpany_phold = bevl_nnode.bemd_0(-1847189180);
bevl_ga.bemd_1(228258099, bevt_153_tmpany_phold);
bevl_nnode.bemd_0(167394867);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpany_phold.bevi_int == bevt_156_tmpany_phold.bevi_int) {
bevt_154_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpany_phold.bevi_bool) /* Line: 180 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 181 */
 else  /* Line: 180 */ {
bevt_158_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpany_phold.bevi_int == bevt_159_tmpany_phold.bevi_int) {
bevt_157_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_163_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(-1847189180);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(1325170244);
bevt_164_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_1(-1535130404, bevt_164_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_160_tmpany_phold).bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_167_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bem_aliasedGet_0();
bevt_168_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bem_has_1(bevt_168_tmpany_phold);
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 182 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 182 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 182 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 188 */
} /* Line: 180 */
} /* Line: 180 */
} /* Line: 171 */
} /* Line: 169 */
} /* Line: 69 */
} /* Line: 69 */
} /* Line: 69 */
} /* Line: 69 */
bevt_171_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpany_phold;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpany_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass7_bels_17));
bevl_gnc.bem_nameSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpany_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGetDirect_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGetDirect_0() {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {36, 39, 39, 39, 39, 40, 40, 41, 41, 41, 43, 43, 44, 45, 47, 47, 47, 47, 48, 48, 50, 50, 50, 50, 51, 51, 53, 53, 53, 53, 54, 54, 56, 56, 56, 56, 58, 58, 59, 59, 61, 61, 61, 61, 62, 62, 63, 63, 69, 69, 69, 69, 70, 70, 71, 71, 73, 73, 73, 73, 73, 73, 73, 0, 0, 0, 74, 74, 74, 74, 74, 74, 0, 74, 74, 74, 0, 0, 0, 0, 0, 75, 75, 75, 75, 75, 75, 77, 77, 77, 78, 79, 83, 83, 85, 85, 85, 85, 86, 86, 86, 86, 86, 0, 0, 0, 87, 87, 87, 88, 89, 89, 89, 90, 91, 91, 91, 92, 95, 95, 96, 97, 100, 101, 101, 102, 103, 103, 104, 105, 106, 107, 108, 108, 108, 108, 108, 0, 0, 0, 109, 110, 110, 111, 111, 111, 112, 112, 112, 112, 113, 113, 114, 114, 115, 115, 116, 116, 118, 120, 120, 120, 120, 120, 120, 120, 120, 120, 0, 120, 120, 120, 120, 0, 0, 0, 0, 0, 121, 122, 122, 123, 124, 124, 125, 126, 126, 127, 127, 128, 128, 129, 129, 131, 133, 133, 133, 134, 134, 134, 135, 135, 135, 136, 136, 136, 139, 140, 141, 143, 143, 144, 144, 148, 148, 148, 148, 151, 152, 152, 153, 153, 153, 155, 156, 157, 157, 157, 157, 158, 158, 158, 160, 160, 161, 161, 161, 161, 163, 166, 166, 0, 166, 166, 0, 0, 167, 167, 167, 169, 169, 169, 170, 171, 171, 0, 171, 171, 171, 0, 0, 172, 173, 173, 174, 175, 175, 176, 177, 178, 179, 180, 180, 180, 180, 181, 182, 182, 182, 182, 182, 182, 182, 182, 182, 0, 182, 182, 182, 182, 0, 0, 0, 0, 0, 183, 184, 184, 185, 186, 186, 187, 188, 193, 193, 197, 198, 199, 199, 200, 200, 201, 203, 204, 204, 205, 205, 206, 206, 207, 207, 208, 208, 209, 210, 210, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {223, 224, 225, 226, 231, 232, 233, 234, 235, 236, 238, 243, 244, 245, 247, 248, 249, 254, 255, 256, 258, 259, 260, 265, 266, 267, 269, 270, 271, 276, 277, 278, 280, 281, 282, 287, 288, 289, 290, 291, 293, 294, 295, 300, 301, 302, 303, 304, 306, 307, 308, 313, 314, 315, 316, 317, 320, 321, 322, 327, 328, 329, 330, 332, 335, 339, 342, 343, 344, 349, 350, 355, 356, 359, 360, 361, 363, 366, 370, 373, 377, 380, 381, 382, 383, 384, 385, 388, 389, 390, 391, 392, 393, 394, 398, 399, 400, 405, 406, 411, 412, 413, 414, 416, 419, 423, 426, 427, 432, 433, 434, 435, 438, 440, 441, 442, 443, 445, 452, 455, 457, 458, 465, 466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 480, 481, 482, 483, 485, 488, 492, 495, 496, 501, 502, 503, 504, 507, 508, 509, 514, 515, 516, 518, 519, 520, 521, 522, 523, 526, 530, 531, 532, 537, 538, 539, 540, 541, 542, 544, 547, 548, 549, 550, 552, 555, 559, 562, 566, 569, 570, 571, 572, 573, 574, 575, 576, 577, 579, 580, 581, 582, 583, 584, 587, 591, 592, 593, 595, 596, 597, 600, 601, 602, 604, 605, 606, 612, 613, 614, 617, 618, 619, 620, 625, 626, 627, 632, 633, 634, 639, 640, 641, 642, 644, 645, 646, 647, 648, 653, 654, 655, 656, 658, 659, 662, 663, 664, 669, 670, 671, 676, 677, 680, 685, 686, 689, 693, 694, 695, 697, 698, 699, 701, 702, 707, 708, 711, 712, 713, 715, 718, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 739, 740, 743, 744, 745, 750, 751, 752, 753, 754, 755, 757, 760, 761, 762, 763, 765, 768, 772, 775, 779, 782, 783, 784, 785, 786, 787, 788, 789, 799, 800, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 837, 840, 843, 847, 851, 854, 857, 861};
/* BEGIN LINEINFO 
assign 1 36 223
nextPeerGet 0 36 223
assign 1 39 224
typenameGet 0 39 224
assign 1 39 225
CLASSGet 0 39 225
assign 1 39 226
equals 1 39 231
assign 1 40 232
heldGet 0 40 232
assign 1 40 233
namepathGet 0 40 233
assign 1 41 234
heldGet 0 41 234
assign 1 41 235
fromFileGet 0 41 235
assign 1 41 236
toString 0 41 236
assign 1 43 238
def 1 43 243
inClassNpSet 1 44 244
inFileSet 1 45 245
assign 1 47 247
typenameGet 0 47 247
assign 1 47 248
INTLGet 0 47 248
assign 1 47 249
equals 1 47 254
assign 1 48 255
new 0 48 255
buildLiteral 2 48 256
assign 1 50 258
typenameGet 0 50 258
assign 1 50 259
FLOATLGet 0 50 259
assign 1 50 260
equals 1 50 265
assign 1 51 266
new 0 51 266
buildLiteral 2 51 267
assign 1 53 269
typenameGet 0 53 269
assign 1 53 270
STRINGLGet 0 53 270
assign 1 53 271
equals 1 53 276
assign 1 54 277
new 0 54 277
buildLiteral 2 54 278
assign 1 56 280
typenameGet 0 56 280
assign 1 56 281
WSTRINGLGet 0 56 281
assign 1 56 282
equals 1 56 287
assign 1 58 288
new 0 58 288
buildLiteral 2 58 289
assign 1 59 290
new 0 59 290
wideStringSet 1 59 291
assign 1 61 293
typenameGet 0 61 293
assign 1 61 294
TRUEGet 0 61 294
assign 1 61 295
equals 1 61 300
assign 1 62 301
new 0 62 301
heldSet 1 62 302
assign 1 63 303
new 0 63 303
buildLiteral 2 63 304
assign 1 69 306
typenameGet 0 69 306
assign 1 69 307
FALSEGet 0 69 307
assign 1 69 308
equals 1 69 313
assign 1 70 314
new 0 70 314
heldSet 1 70 315
assign 1 71 316
new 0 71 316
buildLiteral 2 71 317
assign 1 73 320
typenameGet 0 73 320
assign 1 73 321
VARGet 0 73 321
assign 1 73 322
equals 1 73 327
assign 1 73 328
heldGet 0 73 328
assign 1 73 329
isArgGet 0 73 329
assign 1 73 330
not 0 73 330
assign 1 0 332
assign 1 0 335
assign 1 0 339
assign 1 74 342
heldGet 0 74 342
assign 1 74 343
nameGet 0 74 343
assign 1 74 344
undef 1 74 349
assign 1 74 350
undef 1 74 355
assign 1 0 356
assign 1 74 359
typenameGet 0 74 359
assign 1 74 360
IDGet 0 74 360
assign 1 74 361
notEquals 1 74 361
assign 1 0 363
assign 1 0 366
assign 1 0 370
assign 1 0 373
assign 1 0 377
assign 1 75 380
new 0 75 380
assign 1 75 381
heldGet 0 75 381
assign 1 75 382
nameGet 0 75 382
assign 1 75 383
add 1 75 383
assign 1 75 384
new 2 75 384
throw 1 75 385
assign 1 77 388
heldGet 0 77 388
assign 1 77 389
heldGet 0 77 389
nameSet 1 77 390
addVariable 0 78 391
delete 0 79 392
assign 1 83 393
nextDescendGet 0 83 393
return 1 83 394
assign 1 85 398
typenameGet 0 85 398
assign 1 85 399
IDGet 0 85 399
assign 1 85 400
equals 1 85 405
assign 1 86 406
def 1 86 411
assign 1 86 412
typenameGet 0 86 412
assign 1 86 413
PARENSGet 0 86 413
assign 1 86 414
equals 1 86 414
assign 1 0 416
assign 1 0 419
assign 1 0 423
assign 1 87 426
containedGet 0 87 426
assign 1 87 427
def 1 87 432
assign 1 88 433
new 0 88 433
assign 1 89 434
containedGet 0 89 434
assign 1 89 435
iteratorGet 0 89 435
assign 1 89 438
hasNextGet 0 89 438
assign 1 90 440
nextGet 0 90 440
assign 1 91 441
typenameGet 0 91 441
assign 1 91 442
COMMAGet 0 91 442
assign 1 91 443
equals 1 91 443
addValue 1 92 445
assign 1 95 452
iteratorGet 0 95 452
assign 1 95 455
hasNextGet 0 95 455
assign 1 96 457
nextGet 0 96 457
delete 0 97 458
assign 1 100 465
assign 1 101 466
CALLGet 0 101 466
typenameSet 1 101 467
assign 1 102 468
new 0 102 468
assign 1 103 469
heldGet 0 103 469
nameSet 1 103 470
heldSet 1 104 471
delete 0 105 472
assign 1 106 473
assign 1 107 474
priorPeerGet 0 107 474
assign 1 108 475
def 1 108 480
assign 1 108 481
typenameGet 0 108 481
assign 1 108 482
DOTGet 0 108 482
assign 1 108 483
equals 1 108 483
assign 1 0 485
assign 1 0 488
assign 1 0 492
assign 1 109 495
priorPeerGet 0 109 495
assign 1 110 496
undef 1 110 501
assign 1 111 502
new 0 111 502
assign 1 111 503
new 2 111 503
throw 1 111 504
assign 1 112 507
typenameGet 0 112 507
assign 1 112 508
NAMEPATHGet 0 112 508
assign 1 112 509
equals 1 112 514
assign 1 113 515
nameGet 0 113 515
assign 1 113 516
isNewish 1 113 516
assign 1 114 518
new 0 114 518
wasBoundSet 1 114 519
assign 1 115 520
new 0 115 520
boundSet 1 115 521
assign 1 116 522
new 0 116 522
isConstructSet 1 116 523
createImpliedConstruct 2 118 526
assign 1 120 530
typenameGet 0 120 530
assign 1 120 531
IDGet 0 120 531
assign 1 120 532
equals 1 120 537
assign 1 120 538
transUnitGet 0 120 538
assign 1 120 539
heldGet 0 120 539
assign 1 120 540
aliasedGet 0 120 540
assign 1 120 541
heldGet 0 120 541
assign 1 120 542
has 1 120 542
assign 1 0 544
assign 1 120 547
emitDataGet 0 120 547
assign 1 120 548
aliasedGet 0 120 548
assign 1 120 549
heldGet 0 120 549
assign 1 120 550
has 1 120 550
assign 1 0 552
assign 1 0 555
assign 1 0 559
assign 1 0 562
assign 1 0 566
assign 1 121 569
new 0 121 569
assign 1 122 570
heldGet 0 122 570
addStep 1 122 571
heldSet 1 123 572
assign 1 124 573
NAMEPATHGet 0 124 573
typenameSet 1 124 574
resolveNp 0 125 575
assign 1 126 576
nameGet 0 126 576
assign 1 126 577
isNewish 1 126 577
assign 1 127 579
new 0 127 579
wasBoundSet 1 127 580
assign 1 128 581
new 0 128 581
boundSet 1 128 582
assign 1 129 583
new 0 129 583
isConstructSet 1 129 584
createImpliedConstruct 2 131 587
assign 1 133 591
nameGet 0 133 591
assign 1 133 592
new 0 133 592
assign 1 133 593
equals 1 133 593
assign 1 134 595
new 0 134 595
assign 1 134 596
new 2 134 596
throw 1 134 597
assign 1 135 600
nameGet 0 135 600
assign 1 135 601
new 0 135 601
assign 1 135 602
equals 1 135 602
assign 1 136 604
new 0 136 604
assign 1 136 605
new 2 136 605
throw 1 136 606
delete 0 139 612
prepend 1 140 613
delete 0 141 614
assign 1 143 617
new 0 143 617
boundSet 1 143 618
assign 1 144 619
new 0 144 619
wasBoundSet 1 144 620
assign 1 148 625
typenameGet 0 148 625
assign 1 148 626
IDXGet 0 148 626
assign 1 148 627
equals 1 148 632
assign 1 151 633
priorPeerGet 0 151 633
assign 1 152 634
undef 1 152 639
assign 1 153 640
new 0 153 640
assign 1 153 641
new 2 153 641
throw 1 153 642
delete 0 155 644
prepend 1 156 645
assign 1 157 646
typenameGet 0 157 646
assign 1 157 647
NAMEPATHGet 0 157 647
assign 1 157 648
equals 1 157 653
assign 1 158 654
new 0 158 654
assign 1 158 655
new 2 158 655
throw 1 158 656
assign 1 160 658
IDXACCGet 0 160 658
typenameSet 1 160 659
assign 1 161 662
typenameGet 0 161 662
assign 1 161 663
DOTGet 0 161 663
assign 1 161 664
equals 1 161 669
assign 1 163 670
priorPeerGet 0 163 670
assign 1 166 671
undef 1 166 676
assign 1 0 677
assign 1 166 680
undef 1 166 685
assign 1 0 686
assign 1 0 689
assign 1 167 693
new 0 167 693
assign 1 167 694
new 2 167 694
throw 1 167 695
assign 1 169 697
typenameGet 0 169 697
assign 1 169 698
IDGet 0 169 698
assign 1 169 699
equals 1 169 699
assign 1 170 701
nextPeerGet 0 170 701
assign 1 171 702
undef 1 171 707
assign 1 0 708
assign 1 171 711
typenameGet 0 171 711
assign 1 171 712
PARENSGet 0 171 712
assign 1 171 713
notEquals 1 171 713
assign 1 0 715
assign 1 0 718
assign 1 172 722
priorPeerGet 0 172 722
assign 1 173 723
ACCESSORGet 0 173 723
typenameSet 1 173 724
assign 1 174 725
new 0 174 725
assign 1 175 726
heldGet 0 175 726
nameSet 1 175 727
delete 0 176 728
delete 0 177 729
heldSet 1 178 730
addValue 1 179 731
assign 1 180 732
typenameGet 0 180 732
assign 1 180 733
NAMEPATHGet 0 180 733
assign 1 180 734
equals 1 180 739
createImpliedConstruct 2 181 740
assign 1 182 743
typenameGet 0 182 743
assign 1 182 744
IDGet 0 182 744
assign 1 182 745
equals 1 182 750
assign 1 182 751
transUnitGet 0 182 751
assign 1 182 752
heldGet 0 182 752
assign 1 182 753
aliasedGet 0 182 753
assign 1 182 754
heldGet 0 182 754
assign 1 182 755
has 1 182 755
assign 1 0 757
assign 1 182 760
emitDataGet 0 182 760
assign 1 182 761
aliasedGet 0 182 761
assign 1 182 762
heldGet 0 182 762
assign 1 182 763
has 1 182 763
assign 1 0 765
assign 1 0 768
assign 1 0 772
assign 1 0 775
assign 1 0 779
assign 1 183 782
new 0 183 782
assign 1 184 783
heldGet 0 184 783
addStep 1 184 784
heldSet 1 185 785
assign 1 186 786
NAMEPATHGet 0 186 786
typenameSet 1 186 787
resolveNp 0 187 788
createImpliedConstruct 2 188 789
assign 1 193 799
nextDescendGet 0 193 799
return 1 193 800
assign 1 197 813
new 0 197 813
heldSet 1 198 814
assign 1 199 815
NAMEPATHGet 0 199 815
typenameSet 1 199 816
assign 1 200 817
heldGet 0 200 817
heldSet 1 200 818
prepend 1 201 819
assign 1 203 820
new 0 203 820
assign 1 204 821
new 0 204 821
nameSet 1 204 822
assign 1 205 823
new 0 205 823
wasBoundSet 1 205 824
assign 1 206 825
new 0 206 825
boundSet 1 206 826
assign 1 207 827
new 0 207 827
isConstructSet 1 207 828
assign 1 208 829
new 0 208 829
wasImpliedConstructSet 1 208 830
heldSet 1 209 831
assign 1 210 832
CALLGet 0 210 832
typenameSet 1 210 833
return 1 0 837
return 1 0 840
assign 1 0 843
assign 1 0 847
return 1 0 851
return 1 0 854
assign 1 0 857
assign 1 0 861
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1615839398: return bem_echo_0();
case 1614289356: return bem_buildGet_0();
case -1043543071: return bem_create_0();
case -1048585343: return bem_copy_0();
case -1800587860: return bem_serializeToString_0();
case 976768273: return bem_fieldNamesGet_0();
case 595030513: return bem_constGet_0();
case -2011984947: return bem_classNameGet_0();
case -193453355: return bem_iteratorGet_0();
case -1938639516: return bem_inClassNpGetDirect_0();
case -477940854: return bem_hashGet_0();
case 1463816718: return bem_sourceFileNameGet_0();
case -1021558772: return bem_fieldIteratorGet_0();
case -1852647932: return bem_serializeContents_0();
case -135711625: return bem_ntypesGet_0();
case 190764838: return bem_toString_0();
case 795649196: return bem_serializationIteratorGet_0();
case 329087045: return bem_ntypesGetDirect_0();
case 1612397713: return bem_inClassNpGet_0();
case -204986197: return bem_print_0();
case 1853128990: return bem_transGetDirect_0();
case -1017732045: return bem_toAny_0();
case 1809869265: return bem_many_0();
case -24242301: return bem_buildGetDirect_0();
case 2022567405: return bem_tagGet_0();
case -1617258435: return bem_inFileGet_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -1200514874: return bem_once_0();
case 451316734: return bem_new_0();
case -352655218: return bem_constGetDirect_0();
case -427896902: return bem_transGet_0();
case 898910691: return bem_inFileGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 1255352870: return bem_notEquals_1(bevd_0);
case 186986287: return bem_transSet_1(bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case -1722540916: return bem_constSet_1(bevd_0);
case -506913260: return bem_ntypesSet_1(bevd_0);
case 1177011462: return bem_transSetDirect_1(bevd_0);
case -974417776: return bem_undef_1(bevd_0);
case 734054937: return bem_inFileSetDirect_1(bevd_0);
case 897468448: return bem_end_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case -637875306: return bem_ntypesSetDirect_1(bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case -1896627249: return bem_buildSetDirect_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 499229377: return bem_constSetDirect_1(bevd_0);
case -538180832: return bem_buildSet_1(bevd_0);
case -1009189495: return bem_inClassNpSetDirect_1(bevd_0);
case 1585240367: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 934483249: return bem_begin_1(bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
case 181146969: return bem_inFileSet_1(bevd_0);
case -252330168: return bem_def_1(bevd_0);
case -1042922960: return bem_inClassNpSet_1(bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 701123630: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass7_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass7_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst = (BEC_3_5_5_5_BuildVisitPass7) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_type;
}
}
}
