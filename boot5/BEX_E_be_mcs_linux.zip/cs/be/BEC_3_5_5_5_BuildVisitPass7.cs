namespace be {
/* IO:File: source/build/Pass7.be */
public sealed class BEC_3_5_5_5_BuildVisitPass7 : BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_5_BuildVisitPass7() { }
static BEC_3_5_5_5_BuildVisitPass7() { }
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x37};
private static byte[] becc_BEC_3_5_5_5_BuildVisitPass7_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x37,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_0 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_1 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_2 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_3 = {0x54,0x65,0x78,0x74,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_4 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_5 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_6 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_7 = {0x4C,0x6F,0x67,0x69,0x63,0x3A,0x42,0x6F,0x6F,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_8 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x20,0x64,0x65,0x63,0x6C,0x61,0x72,0x61,0x74,0x69,0x6F,0x6E,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x6E,0x61,0x6D,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_5_BuildVisitPass7_bels_8, 41));
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_9 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x6D,0x69,0x73,0x73,0x69,0x6E,0x67,0x20,0x69,0x6E,0x73,0x74,0x61,0x6E,0x63,0x65,0x20,0x66,0x6F,0x72,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_10 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_11 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x72,0x65,0x74,0x75,0x72,0x6E,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x61,0x6E,0x64,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_12 = {0x74,0x68,0x72,0x6F,0x77};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_13 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x74,0x68,0x72,0x6F,0x77,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x62,0x6F,0x75,0x6E,0x64,0x20,0x63,0x61,0x6C,0x6C,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64,0x20,0x6F,0x6E,0x20,0x61,0x6E,0x20,0x6F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_14 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x20,0x77,0x69,0x74,0x68,0x6F,0x75,0x74,0x20,0x63,0x61,0x6C,0x6C};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_15 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x73,0x79,0x6E,0x74,0x61,0x78,0x20,0x66,0x6F,0x72,0x20,0x69,0x6E,0x64,0x65,0x78,0x65,0x64,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x2C,0x20,0x69,0x6E,0x76,0x6F,0x63,0x61,0x74,0x69,0x6F,0x6E,0x20,0x74,0x61,0x72,0x67,0x65,0x74,0x20,0x63,0x61,0x6E,0x6E,0x6F,0x74,0x20,0x62,0x65,0x20,0x61,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_16 = {0x45,0x72,0x72,0x6F,0x72,0x2C,0x20,0x69,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x20,0x63,0x61,0x6C,0x6C,0x20,0x6F,0x72,0x20,0x61,0x63,0x63,0x65,0x73,0x73,0x6F,0x72};
private static byte[] bece_BEC_3_5_5_5_BuildVisitPass7_bels_17 = {0x6E,0x65,0x77};
public static new BEC_3_5_5_5_BuildVisitPass7 bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;
public BEC_2_5_8_BuildNamePath bevp_inClassNp;
public BEC_2_4_6_TextString bevp_inFile;
public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public override BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) {
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_np = null;
BEC_2_6_6_SystemObject bevl_toremove = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_ii = null;
BEC_2_6_6_SystemObject bevl_nnode = null;
BEC_2_6_6_SystemObject bevl_dnode = null;
BEC_2_5_4_BuildNode bevl_onode = null;
BEC_2_6_6_SystemObject bevl_pc = null;
BEC_2_6_6_SystemObject bevl_gc = null;
BEC_2_5_8_BuildNamePath bevl_namepath = null;
BEC_2_6_6_SystemObject bevl_pnode = null;
BEC_2_6_6_SystemObject bevl_ponode = null;
BEC_2_6_6_SystemObject bevl_ga = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_16_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_6_TextString bevt_22_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_23_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_24_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_28_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_47_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_54_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_88_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_92_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_93_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_94_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_95_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_96_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_103_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_104_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_105_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_106_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_107_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_110_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_111_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_114_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_117_tmpany_phold = null;
BEC_2_4_6_TextString bevt_118_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_119_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_122_tmpany_phold = null;
BEC_2_4_6_TextString bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_125_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_126_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_127_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_128_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_129_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_130_tmpany_phold = null;
BEC_2_4_6_TextString bevt_131_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_132_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_133_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_134_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_135_tmpany_phold = null;
BEC_2_4_6_TextString bevt_136_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_137_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_138_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_139_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_140_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_141_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_142_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_143_tmpany_phold = null;
BEC_2_4_6_TextString bevt_144_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_145_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_146_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_147_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_148_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_149_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_150_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_151_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_152_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_153_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_154_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_155_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_156_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_157_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_158_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_159_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_160_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_161_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_162_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_163_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_164_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_165_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_166_tmpany_phold = null;
BEC_2_5_8_BuildEmitData bevt_167_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_168_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_169_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_170_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_171_tmpany_phold = null;
bevl_nnode = beva_node.bem_nextPeerGet_0();
bevt_9_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_10_tmpany_phold = bevp_ntypes.bem_CLASSGet_0();
if (bevt_9_tmpany_phold.bevi_int == bevt_10_tmpany_phold.bevi_int) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 39 */ {
bevt_11_tmpany_phold = beva_node.bem_heldGet_0();
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_11_tmpany_phold.bemd_0(-525406659);
bevt_13_tmpany_phold = beva_node.bem_heldGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-1733341783);
bevp_inFile = (BEC_2_4_6_TextString) bevt_12_tmpany_phold.bemd_0(247385301);
} /* Line: 41 */
if (bevp_inClassNp == null) {
bevt_14_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_14_tmpany_phold.bevi_bool) /* Line: 43 */ {
beva_node.bem_inClassNpSet_1(bevp_inClassNp);
beva_node.bem_inFileSet_1(bevp_inFile);
} /* Line: 45 */
bevt_16_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_17_tmpany_phold = bevp_ntypes.bem_INTLGet_0();
if (bevt_16_tmpany_phold.bevi_int == bevt_17_tmpany_phold.bevi_int) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 47 */ {
bevt_18_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_3_5_5_5_BuildVisitPass7_bels_0));
bevp_build.bem_buildLiteral_2(beva_node, bevt_18_tmpany_phold);
} /* Line: 48 */
bevt_20_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_21_tmpany_phold = bevp_ntypes.bem_FLOATLGet_0();
if (bevt_20_tmpany_phold.bevi_int == bevt_21_tmpany_phold.bevi_int) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 50 */ {
bevt_22_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_1));
bevp_build.bem_buildLiteral_2(beva_node, bevt_22_tmpany_phold);
} /* Line: 51 */
bevt_24_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_25_tmpany_phold = bevp_ntypes.bem_STRINGLGet_0();
if (bevt_24_tmpany_phold.bevi_int == bevt_25_tmpany_phold.bevi_int) {
bevt_23_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_23_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_23_tmpany_phold.bevi_bool) /* Line: 53 */ {
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_2));
bevp_build.bem_buildLiteral_2(beva_node, bevt_26_tmpany_phold);
} /* Line: 54 */
bevt_28_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_29_tmpany_phold = bevp_ntypes.bem_WSTRINGLGet_0();
if (bevt_28_tmpany_phold.bevi_int == bevt_29_tmpany_phold.bevi_int) {
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_27_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_27_tmpany_phold.bevi_bool) /* Line: 56 */ {
bevt_30_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_3_5_5_5_BuildVisitPass7_bels_3));
bevp_build.bem_buildLiteral_2(beva_node, bevt_30_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
beva_node.bem_wideStringSet_1(bevt_31_tmpany_phold);
} /* Line: 59 */
bevt_33_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_34_tmpany_phold = bevp_ntypes.bem_TRUEGet_0();
if (bevt_33_tmpany_phold.bevi_int == bevt_34_tmpany_phold.bevi_int) {
bevt_32_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_32_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_32_tmpany_phold.bevi_bool) /* Line: 61 */ {
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_5_BuildVisitPass7_bels_4));
beva_node.bem_heldSet_1(bevt_35_tmpany_phold);
bevt_36_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_5));
bevp_build.bem_buildLiteral_2(beva_node, bevt_36_tmpany_phold);
} /* Line: 63 */
bevt_38_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_39_tmpany_phold = bevp_ntypes.bem_FALSEGet_0();
if (bevt_38_tmpany_phold.bevi_int == bevt_39_tmpany_phold.bevi_int) {
bevt_37_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_37_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_37_tmpany_phold.bevi_bool) /* Line: 69 */ {
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_6));
beva_node.bem_heldSet_1(bevt_40_tmpany_phold);
bevt_41_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_3_5_5_5_BuildVisitPass7_bels_7));
bevp_build.bem_buildLiteral_2(beva_node, bevt_41_tmpany_phold);
} /* Line: 71 */
 else  /* Line: 69 */ {
bevt_43_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_44_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_43_tmpany_phold.bevi_int == bevt_44_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 73 */ {
bevt_47_tmpany_phold = beva_node.bem_heldGet_0();
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bemd_0(-180849128);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bemd_0(70212490);
if (bevt_45_tmpany_phold != null && bevt_45_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_45_tmpany_phold).bevi_bool) /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 73 */
 else  /* Line: 73 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 73 */ {
bevt_50_tmpany_phold = beva_node.bem_heldGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bemd_0(-585577712);
if (bevt_49_tmpany_phold == null) {
bevt_48_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_48_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_48_tmpany_phold.bevi_bool) /* Line: 74 */ {
if (bevl_nnode == null) {
bevt_51_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_51_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_51_tmpany_phold.bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_53_tmpany_phold = bevl_nnode.bemd_0(-1476823905);
bevt_54_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(1999045680, bevt_54_tmpany_phold);
if (bevt_52_tmpany_phold != null && bevt_52_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_52_tmpany_phold).bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 74 */
 else  /* Line: 74 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 74 */ {
bevt_57_tmpany_phold = bece_BEC_3_5_5_5_BuildVisitPass7_bevo_0;
bevt_59_tmpany_phold = beva_node.bem_heldGet_0();
bevt_58_tmpany_phold = bevt_59_tmpany_phold.bemd_0(-585577712);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bem_add_1(bevt_58_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_56_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_55_tmpany_phold);
} /* Line: 75 */
 else  /* Line: 76 */ {
bevt_60_tmpany_phold = beva_node.bem_heldGet_0();
bevt_61_tmpany_phold = bevl_nnode.bemd_0(498738483);
bevt_60_tmpany_phold.bemd_1(1673152110, bevt_61_tmpany_phold);
beva_node.bem_addVariable_0();
bevl_nnode.bemd_0(23661901);
bevt_62_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_62_tmpany_phold;
} /* Line: 83 */
} /* Line: 74 */
 else  /* Line: 69 */ {
bevt_64_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 85 */ {
if (bevl_nnode == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 86 */ {
bevt_68_tmpany_phold = bevl_nnode.bemd_0(-1476823905);
bevt_69_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_1(-170563302, bevt_69_tmpany_phold);
if (bevt_67_tmpany_phold != null && bevt_67_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_67_tmpany_phold).bevi_bool) /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 86 */
 else  /* Line: 86 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 86 */ {
bevt_71_tmpany_phold = bevl_nnode.bemd_0(2098347484);
if (bevt_71_tmpany_phold == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 87 */ {
bevl_toremove = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_72_tmpany_phold = bevl_nnode.bemd_0(2098347484);
bevl_ii = bevt_72_tmpany_phold.bemd_0(466290922);
while (true)
 /* Line: 89 */ {
bevt_73_tmpany_phold = bevl_ii.bemd_0(-896397486);
if (bevt_73_tmpany_phold != null && bevt_73_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_73_tmpany_phold).bevi_bool) /* Line: 89 */ {
bevl_i = bevl_ii.bemd_0(-1887743737);
bevt_75_tmpany_phold = bevl_i.bemd_0(-1476823905);
bevt_76_tmpany_phold = bevp_ntypes.bem_COMMAGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_1(-170563302, bevt_76_tmpany_phold);
if (bevt_74_tmpany_phold != null && bevt_74_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 91 */ {
bevl_toremove.bemd_1(1990140510, bevl_i);
} /* Line: 92 */
} /* Line: 91 */
 else  /* Line: 89 */ {
break;
} /* Line: 89 */
} /* Line: 89 */
bevl_ii = bevl_toremove.bemd_0(466290922);
while (true)
 /* Line: 95 */ {
bevt_77_tmpany_phold = bevl_ii.bemd_0(-896397486);
if (bevt_77_tmpany_phold != null && bevt_77_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 95 */ {
bevl_i = bevl_ii.bemd_0(-1887743737);
bevl_i.bemd_0(23661901);
} /* Line: 97 */
 else  /* Line: 95 */ {
break;
} /* Line: 95 */
} /* Line: 95 */
} /* Line: 95 */
bevl_pc = bevl_nnode;
bevt_78_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_pc.bemd_1(1123008767, bevt_78_tmpany_phold);
bevl_gc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevl_gc.bemd_1(1673152110, bevt_79_tmpany_phold);
bevl_pc.bemd_1(-641432356, bevl_gc);
beva_node.bem_delete_0();
beva_node = (BEC_2_5_4_BuildNode) bevl_pc;
bevl_dnode = beva_node.bem_priorPeerGet_0();
if (bevl_dnode == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 108 */ {
bevt_82_tmpany_phold = bevl_dnode.bemd_0(-1476823905);
bevt_83_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(-170563302, bevt_83_tmpany_phold);
if (bevt_81_tmpany_phold != null && bevt_81_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_81_tmpany_phold).bevi_bool) /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 108 */
 else  /* Line: 108 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 108 */ {
bevl_onode = (BEC_2_5_4_BuildNode) bevl_dnode.bemd_0(949203328);
if (bevl_onode == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 110 */ {
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(38, bece_BEC_3_5_5_5_BuildVisitPass7_bels_9));
bevt_85_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_86_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_85_tmpany_phold);
} /* Line: 111 */
 else  /* Line: 110 */ {
bevt_88_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_89_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_88_tmpany_phold.bevi_int == bevt_89_tmpany_phold.bevi_int) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 112 */ {
bevt_91_tmpany_phold = bevl_gc.bemd_0(-585577712);
bevt_90_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_91_tmpany_phold );
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 113 */ {
bevt_92_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1663761146, bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1949876941, bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1918622618, bevt_94_tmpany_phold);
} /* Line: 116 */
 else  /* Line: 117 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 118 */
} /* Line: 113 */
 else  /* Line: 110 */ {
bevt_96_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_97_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_96_tmpany_phold.bevi_int == bevt_97_tmpany_phold.bevi_int) {
bevt_95_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_95_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_95_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_101_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_0(498738483);
bevt_99_tmpany_phold = bevt_100_tmpany_phold.bemd_0(-1646579311);
bevt_102_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_98_tmpany_phold = bevt_99_tmpany_phold.bemd_1(-798387133, bevt_102_tmpany_phold);
if (bevt_98_tmpany_phold != null && bevt_98_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_98_tmpany_phold).bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_105_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_104_tmpany_phold = bevt_105_tmpany_phold.bem_aliasedGet_0();
bevt_106_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_103_tmpany_phold = bevt_104_tmpany_phold.bem_has_1(bevt_106_tmpany_phold);
if (bevt_103_tmpany_phold.bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 120 */
 else  /* Line: 120 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 120 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_107_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_107_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_108_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_108_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bevt_110_tmpany_phold = bevl_gc.bemd_0(-585577712);
bevt_109_tmpany_phold = bevp_build.bem_isNewish_1((BEC_2_4_6_TextString) bevt_110_tmpany_phold );
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 126 */ {
bevt_111_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1663761146, bevt_111_tmpany_phold);
bevt_112_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1949876941, bevt_112_tmpany_phold);
bevt_113_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gc.bemd_1(1918622618, bevt_113_tmpany_phold);
} /* Line: 129 */
 else  /* Line: 130 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 131 */
} /* Line: 126 */
 else  /* Line: 110 */ {
bevt_115_tmpany_phold = bevl_gc.bemd_0(-585577712);
bevt_116_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_5_BuildVisitPass7_bels_10));
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bemd_1(-170563302, bevt_116_tmpany_phold);
if (bevt_114_tmpany_phold != null && bevt_114_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_114_tmpany_phold).bevi_bool) /* Line: 133 */ {
bevt_118_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(70, bece_BEC_3_5_5_5_BuildVisitPass7_bels_11));
bevt_117_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_118_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_117_tmpany_phold);
} /* Line: 134 */
 else  /* Line: 110 */ {
bevt_120_tmpany_phold = bevl_gc.bemd_0(-585577712);
bevt_121_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_5_BuildVisitPass7_bels_12));
bevt_119_tmpany_phold = bevt_120_tmpany_phold.bemd_1(-170563302, bevt_121_tmpany_phold);
if (bevt_119_tmpany_phold != null && bevt_119_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_119_tmpany_phold).bevi_bool) /* Line: 135 */ {
bevt_123_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(65, bece_BEC_3_5_5_5_BuildVisitPass7_bels_13));
bevt_122_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_123_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_122_tmpany_phold);
} /* Line: 136 */
} /* Line: 110 */
} /* Line: 110 */
} /* Line: 110 */
} /* Line: 110 */
bevl_onode.bem_delete_0();
bevl_pc.bemd_1(-1846302404, bevl_onode);
bevl_dnode.bemd_0(23661901);
} /* Line: 141 */
 else  /* Line: 142 */ {
bevt_124_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1949876941, bevt_124_tmpany_phold);
bevt_125_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gc.bemd_1(-1663761146, bevt_125_tmpany_phold);
} /* Line: 144 */
} /* Line: 108 */
} /* Line: 86 */
 else  /* Line: 69 */ {
bevt_127_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_128_tmpany_phold = bevp_ntypes.bem_IDXGet_0();
if (bevt_127_tmpany_phold.bevi_int == bevt_128_tmpany_phold.bevi_int) {
bevt_126_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_126_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_126_tmpany_phold.bevi_bool) /* Line: 148 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_onode == null) {
bevt_129_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_129_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_129_tmpany_phold.bevi_bool) /* Line: 152 */ {
bevt_131_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_14));
bevt_130_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_131_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_130_tmpany_phold);
} /* Line: 153 */
bevl_onode.bem_delete_0();
beva_node.bem_prepend_1(bevl_onode);
bevt_133_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_134_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_133_tmpany_phold.bevi_int == bevt_134_tmpany_phold.bevi_int) {
bevt_132_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_132_tmpany_phold.bevi_bool) /* Line: 157 */ {
bevt_136_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(84, bece_BEC_3_5_5_5_BuildVisitPass7_bels_15));
bevt_135_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_136_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_135_tmpany_phold);
} /* Line: 158 */
bevt_137_tmpany_phold = bevp_ntypes.bem_IDXACCGet_0();
beva_node.bem_typenameSet_1(bevt_137_tmpany_phold);
} /* Line: 160 */
 else  /* Line: 69 */ {
bevt_139_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_140_tmpany_phold = bevp_ntypes.bem_DOTGet_0();
if (bevt_139_tmpany_phold.bevi_int == bevt_140_tmpany_phold.bevi_int) {
bevt_138_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_138_tmpany_phold.bevi_bool) /* Line: 161 */ {
bevl_onode = beva_node.bem_priorPeerGet_0();
if (bevl_nnode == null) {
bevt_141_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_141_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_141_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
if (bevl_onode == null) {
bevt_142_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_142_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_142_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 166 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 166 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 166 */ {
bevt_144_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(34, bece_BEC_3_5_5_5_BuildVisitPass7_bels_16));
bevt_143_tmpany_phold = (BEC_2_5_10_BuildVisitError) (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_144_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_143_tmpany_phold);
} /* Line: 167 */
bevt_146_tmpany_phold = bevl_nnode.bemd_0(-1476823905);
bevt_147_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_145_tmpany_phold = bevt_146_tmpany_phold.bemd_1(-170563302, bevt_147_tmpany_phold);
if (bevt_145_tmpany_phold != null && bevt_145_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_145_tmpany_phold).bevi_bool) /* Line: 169 */ {
bevl_pnode = bevl_nnode.bemd_0(821426715);
if (bevl_pnode == null) {
bevt_148_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_148_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_148_tmpany_phold.bevi_bool) /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_150_tmpany_phold = bevl_pnode.bemd_0(-1476823905);
bevt_151_tmpany_phold = bevp_ntypes.bem_PARENSGet_0();
bevt_149_tmpany_phold = bevt_150_tmpany_phold.bemd_1(1999045680, bevt_151_tmpany_phold);
if (bevt_149_tmpany_phold != null && bevt_149_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_149_tmpany_phold).bevi_bool) /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 171 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 171 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 171 */ {
bevl_ponode = bevl_onode.bem_priorPeerGet_0();
bevt_152_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
beva_node.bem_typenameSet_1(bevt_152_tmpany_phold);
bevl_ga = (new BEC_2_5_8_BuildAccessor()).bem_new_0();
bevt_153_tmpany_phold = bevl_nnode.bemd_0(498738483);
bevl_ga.bemd_1(1673152110, bevt_153_tmpany_phold);
bevl_nnode.bemd_0(23661901);
bevl_onode.bem_delete_0();
beva_node.bem_heldSet_1(bevl_ga);
beva_node.bem_addValue_1(bevl_onode);
bevt_155_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_156_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
if (bevt_155_tmpany_phold.bevi_int == bevt_156_tmpany_phold.bevi_int) {
bevt_154_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_154_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_154_tmpany_phold.bevi_bool) /* Line: 180 */ {
bem_createImpliedConstruct_2(bevl_onode, bevl_ga);
} /* Line: 181 */
 else  /* Line: 180 */ {
bevt_158_tmpany_phold = bevl_onode.bem_typenameGet_0();
bevt_159_tmpany_phold = bevp_ntypes.bem_IDGet_0();
if (bevt_158_tmpany_phold.bevi_int == bevt_159_tmpany_phold.bevi_int) {
bevt_157_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_157_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_157_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_163_tmpany_phold = beva_node.bem_transUnitGet_0();
bevt_162_tmpany_phold = bevt_163_tmpany_phold.bemd_0(498738483);
bevt_161_tmpany_phold = bevt_162_tmpany_phold.bemd_0(-1646579311);
bevt_164_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_160_tmpany_phold = bevt_161_tmpany_phold.bemd_1(-798387133, bevt_164_tmpany_phold);
if (bevt_160_tmpany_phold != null && bevt_160_tmpany_phold is BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_160_tmpany_phold).bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_167_tmpany_phold = bevp_build.bem_emitDataGet_0();
bevt_166_tmpany_phold = bevt_167_tmpany_phold.bem_aliasedGet_0();
bevt_168_tmpany_phold = bevl_onode.bem_heldGet_0();
bevt_165_tmpany_phold = bevt_166_tmpany_phold.bem_has_1(bevt_168_tmpany_phold);
if (bevt_165_tmpany_phold.bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 182 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 182 */
 else  /* Line: 182 */ {
bevt_7_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_7_tmpany_anchor.bevi_bool) /* Line: 182 */ {
bevl_namepath = (BEC_2_5_8_BuildNamePath) (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevt_169_tmpany_phold = bevl_onode.bem_heldGet_0();
bevl_namepath.bem_addStep_1(bevt_169_tmpany_phold);
bevl_onode.bem_heldSet_1(bevl_namepath);
bevt_170_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_onode.bem_typenameSet_1(bevt_170_tmpany_phold);
bevl_onode.bem_resolveNp_0();
bem_createImpliedConstruct_2(bevl_onode, bevl_gc);
} /* Line: 188 */
} /* Line: 180 */
} /* Line: 180 */
} /* Line: 171 */
} /* Line: 169 */
} /* Line: 69 */
} /* Line: 69 */
} /* Line: 69 */
} /* Line: 69 */
bevt_171_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_171_tmpany_phold;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_createImpliedConstruct_2(BEC_2_5_4_BuildNode beva_onode, BEC_2_6_6_SystemObject beva_gc) {
BEC_2_5_4_BuildNode bevl_npcnode = null;
BEC_2_5_4_BuildCall bevl_gnc = null;
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
bevl_npcnode = (BEC_2_5_4_BuildNode) (new BEC_2_5_4_BuildNode());
bevl_npcnode.bem_heldSet_1(beva_gc);
bevt_0_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_npcnode.bem_typenameSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = beva_onode.bem_heldGet_0();
bevl_npcnode.bem_heldSet_1(bevt_1_tmpany_phold);
beva_onode.bem_prepend_1(bevl_npcnode);
bevl_gnc = (BEC_2_5_4_BuildCall) (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_3_5_5_5_BuildVisitPass7_bels_17));
bevl_gnc.bem_nameSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_wasBoundSet_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_gnc.bem_boundSet_1(bevt_4_tmpany_phold);
bevt_5_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_isConstructSet_1(bevt_5_tmpany_phold);
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_gnc.bem_wasImpliedConstructSet_1(bevt_6_tmpany_phold);
beva_onode.bem_heldSet_1(bevl_gnc);
bevt_7_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_onode.bem_typenameSet_1(bevt_7_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_inClassNpGet_0() {
return bevp_inClassNp;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inClassNpSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inClassNp = (BEC_2_5_8_BuildNamePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_inFileGet_0() {
return bevp_inFile;
} /*method end*/
public BEC_3_5_5_5_BuildVisitPass7 bem_inFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_inFile = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {36, 39, 39, 39, 39, 40, 40, 41, 41, 41, 43, 43, 44, 45, 47, 47, 47, 47, 48, 48, 50, 50, 50, 50, 51, 51, 53, 53, 53, 53, 54, 54, 56, 56, 56, 56, 58, 58, 59, 59, 61, 61, 61, 61, 62, 62, 63, 63, 69, 69, 69, 69, 70, 70, 71, 71, 73, 73, 73, 73, 73, 73, 73, 0, 0, 0, 74, 74, 74, 74, 74, 74, 0, 74, 74, 74, 0, 0, 0, 0, 0, 75, 75, 75, 75, 75, 75, 77, 77, 77, 78, 79, 83, 83, 85, 85, 85, 85, 86, 86, 86, 86, 86, 0, 0, 0, 87, 87, 87, 88, 89, 89, 89, 90, 91, 91, 91, 92, 95, 95, 96, 97, 100, 101, 101, 102, 103, 103, 104, 105, 106, 107, 108, 108, 108, 108, 108, 0, 0, 0, 109, 110, 110, 111, 111, 111, 112, 112, 112, 112, 113, 113, 114, 114, 115, 115, 116, 116, 118, 120, 120, 120, 120, 120, 120, 120, 120, 120, 0, 120, 120, 120, 120, 0, 0, 0, 0, 0, 121, 122, 122, 123, 124, 124, 125, 126, 126, 127, 127, 128, 128, 129, 129, 131, 133, 133, 133, 134, 134, 134, 135, 135, 135, 136, 136, 136, 139, 140, 141, 143, 143, 144, 144, 148, 148, 148, 148, 151, 152, 152, 153, 153, 153, 155, 156, 157, 157, 157, 157, 158, 158, 158, 160, 160, 161, 161, 161, 161, 163, 166, 166, 0, 166, 166, 0, 0, 167, 167, 167, 169, 169, 169, 170, 171, 171, 0, 171, 171, 171, 0, 0, 172, 173, 173, 174, 175, 175, 176, 177, 178, 179, 180, 180, 180, 180, 181, 182, 182, 182, 182, 182, 182, 182, 182, 182, 0, 182, 182, 182, 182, 0, 0, 0, 0, 0, 183, 184, 184, 185, 186, 186, 187, 188, 193, 193, 197, 198, 199, 199, 200, 200, 201, 203, 204, 204, 205, 205, 206, 206, 207, 207, 208, 208, 209, 210, 210, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {220, 221, 222, 223, 228, 229, 230, 231, 232, 233, 235, 240, 241, 242, 244, 245, 246, 251, 252, 253, 255, 256, 257, 262, 263, 264, 266, 267, 268, 273, 274, 275, 277, 278, 279, 284, 285, 286, 287, 288, 290, 291, 292, 297, 298, 299, 300, 301, 303, 304, 305, 310, 311, 312, 313, 314, 317, 318, 319, 324, 325, 326, 327, 329, 332, 336, 339, 340, 341, 346, 347, 352, 353, 356, 357, 358, 360, 363, 367, 370, 374, 377, 378, 379, 380, 381, 382, 385, 386, 387, 388, 389, 390, 391, 395, 396, 397, 402, 403, 408, 409, 410, 411, 413, 416, 420, 423, 424, 429, 430, 431, 432, 435, 437, 438, 439, 440, 442, 449, 452, 454, 455, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 477, 478, 479, 480, 482, 485, 489, 492, 493, 498, 499, 500, 501, 504, 505, 506, 511, 512, 513, 515, 516, 517, 518, 519, 520, 523, 527, 528, 529, 534, 535, 536, 537, 538, 539, 541, 544, 545, 546, 547, 549, 552, 556, 559, 563, 566, 567, 568, 569, 570, 571, 572, 573, 574, 576, 577, 578, 579, 580, 581, 584, 588, 589, 590, 592, 593, 594, 597, 598, 599, 601, 602, 603, 609, 610, 611, 614, 615, 616, 617, 622, 623, 624, 629, 630, 631, 636, 637, 638, 639, 641, 642, 643, 644, 645, 650, 651, 652, 653, 655, 656, 659, 660, 661, 666, 667, 668, 673, 674, 677, 682, 683, 686, 690, 691, 692, 694, 695, 696, 698, 699, 704, 705, 708, 709, 710, 712, 715, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 736, 737, 740, 741, 742, 747, 748, 749, 750, 751, 752, 754, 757, 758, 759, 760, 762, 765, 769, 772, 776, 779, 780, 781, 782, 783, 784, 785, 786, 796, 797, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 834, 837, 841, 844};
/* BEGIN LINEINFO 
assign 1 36 220
nextPeerGet 0 36 220
assign 1 39 221
typenameGet 0 39 221
assign 1 39 222
CLASSGet 0 39 222
assign 1 39 223
equals 1 39 228
assign 1 40 229
heldGet 0 40 229
assign 1 40 230
namepathGet 0 40 230
assign 1 41 231
heldGet 0 41 231
assign 1 41 232
fromFileGet 0 41 232
assign 1 41 233
toString 0 41 233
assign 1 43 235
def 1 43 240
inClassNpSet 1 44 241
inFileSet 1 45 242
assign 1 47 244
typenameGet 0 47 244
assign 1 47 245
INTLGet 0 47 245
assign 1 47 246
equals 1 47 251
assign 1 48 252
new 0 48 252
buildLiteral 2 48 253
assign 1 50 255
typenameGet 0 50 255
assign 1 50 256
FLOATLGet 0 50 256
assign 1 50 257
equals 1 50 262
assign 1 51 263
new 0 51 263
buildLiteral 2 51 264
assign 1 53 266
typenameGet 0 53 266
assign 1 53 267
STRINGLGet 0 53 267
assign 1 53 268
equals 1 53 273
assign 1 54 274
new 0 54 274
buildLiteral 2 54 275
assign 1 56 277
typenameGet 0 56 277
assign 1 56 278
WSTRINGLGet 0 56 278
assign 1 56 279
equals 1 56 284
assign 1 58 285
new 0 58 285
buildLiteral 2 58 286
assign 1 59 287
new 0 59 287
wideStringSet 1 59 288
assign 1 61 290
typenameGet 0 61 290
assign 1 61 291
TRUEGet 0 61 291
assign 1 61 292
equals 1 61 297
assign 1 62 298
new 0 62 298
heldSet 1 62 299
assign 1 63 300
new 0 63 300
buildLiteral 2 63 301
assign 1 69 303
typenameGet 0 69 303
assign 1 69 304
FALSEGet 0 69 304
assign 1 69 305
equals 1 69 310
assign 1 70 311
new 0 70 311
heldSet 1 70 312
assign 1 71 313
new 0 71 313
buildLiteral 2 71 314
assign 1 73 317
typenameGet 0 73 317
assign 1 73 318
VARGet 0 73 318
assign 1 73 319
equals 1 73 324
assign 1 73 325
heldGet 0 73 325
assign 1 73 326
isArgGet 0 73 326
assign 1 73 327
not 0 73 327
assign 1 0 329
assign 1 0 332
assign 1 0 336
assign 1 74 339
heldGet 0 74 339
assign 1 74 340
nameGet 0 74 340
assign 1 74 341
undef 1 74 346
assign 1 74 347
undef 1 74 352
assign 1 0 353
assign 1 74 356
typenameGet 0 74 356
assign 1 74 357
IDGet 0 74 357
assign 1 74 358
notEquals 1 74 358
assign 1 0 360
assign 1 0 363
assign 1 0 367
assign 1 0 370
assign 1 0 374
assign 1 75 377
new 0 75 377
assign 1 75 378
heldGet 0 75 378
assign 1 75 379
nameGet 0 75 379
assign 1 75 380
add 1 75 380
assign 1 75 381
new 2 75 381
throw 1 75 382
assign 1 77 385
heldGet 0 77 385
assign 1 77 386
heldGet 0 77 386
nameSet 1 77 387
addVariable 0 78 388
delete 0 79 389
assign 1 83 390
nextDescendGet 0 83 390
return 1 83 391
assign 1 85 395
typenameGet 0 85 395
assign 1 85 396
IDGet 0 85 396
assign 1 85 397
equals 1 85 402
assign 1 86 403
def 1 86 408
assign 1 86 409
typenameGet 0 86 409
assign 1 86 410
PARENSGet 0 86 410
assign 1 86 411
equals 1 86 411
assign 1 0 413
assign 1 0 416
assign 1 0 420
assign 1 87 423
containedGet 0 87 423
assign 1 87 424
def 1 87 429
assign 1 88 430
new 0 88 430
assign 1 89 431
containedGet 0 89 431
assign 1 89 432
iteratorGet 0 89 432
assign 1 89 435
hasNextGet 0 89 435
assign 1 90 437
nextGet 0 90 437
assign 1 91 438
typenameGet 0 91 438
assign 1 91 439
COMMAGet 0 91 439
assign 1 91 440
equals 1 91 440
addValue 1 92 442
assign 1 95 449
iteratorGet 0 95 449
assign 1 95 452
hasNextGet 0 95 452
assign 1 96 454
nextGet 0 96 454
delete 0 97 455
assign 1 100 462
assign 1 101 463
CALLGet 0 101 463
typenameSet 1 101 464
assign 1 102 465
new 0 102 465
assign 1 103 466
heldGet 0 103 466
nameSet 1 103 467
heldSet 1 104 468
delete 0 105 469
assign 1 106 470
assign 1 107 471
priorPeerGet 0 107 471
assign 1 108 472
def 1 108 477
assign 1 108 478
typenameGet 0 108 478
assign 1 108 479
DOTGet 0 108 479
assign 1 108 480
equals 1 108 480
assign 1 0 482
assign 1 0 485
assign 1 0 489
assign 1 109 492
priorPeerGet 0 109 492
assign 1 110 493
undef 1 110 498
assign 1 111 499
new 0 111 499
assign 1 111 500
new 2 111 500
throw 1 111 501
assign 1 112 504
typenameGet 0 112 504
assign 1 112 505
NAMEPATHGet 0 112 505
assign 1 112 506
equals 1 112 511
assign 1 113 512
nameGet 0 113 512
assign 1 113 513
isNewish 1 113 513
assign 1 114 515
new 0 114 515
wasBoundSet 1 114 516
assign 1 115 517
new 0 115 517
boundSet 1 115 518
assign 1 116 519
new 0 116 519
isConstructSet 1 116 520
createImpliedConstruct 2 118 523
assign 1 120 527
typenameGet 0 120 527
assign 1 120 528
IDGet 0 120 528
assign 1 120 529
equals 1 120 534
assign 1 120 535
transUnitGet 0 120 535
assign 1 120 536
heldGet 0 120 536
assign 1 120 537
aliasedGet 0 120 537
assign 1 120 538
heldGet 0 120 538
assign 1 120 539
has 1 120 539
assign 1 0 541
assign 1 120 544
emitDataGet 0 120 544
assign 1 120 545
aliasedGet 0 120 545
assign 1 120 546
heldGet 0 120 546
assign 1 120 547
has 1 120 547
assign 1 0 549
assign 1 0 552
assign 1 0 556
assign 1 0 559
assign 1 0 563
assign 1 121 566
new 0 121 566
assign 1 122 567
heldGet 0 122 567
addStep 1 122 568
heldSet 1 123 569
assign 1 124 570
NAMEPATHGet 0 124 570
typenameSet 1 124 571
resolveNp 0 125 572
assign 1 126 573
nameGet 0 126 573
assign 1 126 574
isNewish 1 126 574
assign 1 127 576
new 0 127 576
wasBoundSet 1 127 577
assign 1 128 578
new 0 128 578
boundSet 1 128 579
assign 1 129 580
new 0 129 580
isConstructSet 1 129 581
createImpliedConstruct 2 131 584
assign 1 133 588
nameGet 0 133 588
assign 1 133 589
new 0 133 589
assign 1 133 590
equals 1 133 590
assign 1 134 592
new 0 134 592
assign 1 134 593
new 2 134 593
throw 1 134 594
assign 1 135 597
nameGet 0 135 597
assign 1 135 598
new 0 135 598
assign 1 135 599
equals 1 135 599
assign 1 136 601
new 0 136 601
assign 1 136 602
new 2 136 602
throw 1 136 603
delete 0 139 609
prepend 1 140 610
delete 0 141 611
assign 1 143 614
new 0 143 614
boundSet 1 143 615
assign 1 144 616
new 0 144 616
wasBoundSet 1 144 617
assign 1 148 622
typenameGet 0 148 622
assign 1 148 623
IDXGet 0 148 623
assign 1 148 624
equals 1 148 629
assign 1 151 630
priorPeerGet 0 151 630
assign 1 152 631
undef 1 152 636
assign 1 153 637
new 0 153 637
assign 1 153 638
new 2 153 638
throw 1 153 639
delete 0 155 641
prepend 1 156 642
assign 1 157 643
typenameGet 0 157 643
assign 1 157 644
NAMEPATHGet 0 157 644
assign 1 157 645
equals 1 157 650
assign 1 158 651
new 0 158 651
assign 1 158 652
new 2 158 652
throw 1 158 653
assign 1 160 655
IDXACCGet 0 160 655
typenameSet 1 160 656
assign 1 161 659
typenameGet 0 161 659
assign 1 161 660
DOTGet 0 161 660
assign 1 161 661
equals 1 161 666
assign 1 163 667
priorPeerGet 0 163 667
assign 1 166 668
undef 1 166 673
assign 1 0 674
assign 1 166 677
undef 1 166 682
assign 1 0 683
assign 1 0 686
assign 1 167 690
new 0 167 690
assign 1 167 691
new 2 167 691
throw 1 167 692
assign 1 169 694
typenameGet 0 169 694
assign 1 169 695
IDGet 0 169 695
assign 1 169 696
equals 1 169 696
assign 1 170 698
nextPeerGet 0 170 698
assign 1 171 699
undef 1 171 704
assign 1 0 705
assign 1 171 708
typenameGet 0 171 708
assign 1 171 709
PARENSGet 0 171 709
assign 1 171 710
notEquals 1 171 710
assign 1 0 712
assign 1 0 715
assign 1 172 719
priorPeerGet 0 172 719
assign 1 173 720
ACCESSORGet 0 173 720
typenameSet 1 173 721
assign 1 174 722
new 0 174 722
assign 1 175 723
heldGet 0 175 723
nameSet 1 175 724
delete 0 176 725
delete 0 177 726
heldSet 1 178 727
addValue 1 179 728
assign 1 180 729
typenameGet 0 180 729
assign 1 180 730
NAMEPATHGet 0 180 730
assign 1 180 731
equals 1 180 736
createImpliedConstruct 2 181 737
assign 1 182 740
typenameGet 0 182 740
assign 1 182 741
IDGet 0 182 741
assign 1 182 742
equals 1 182 747
assign 1 182 748
transUnitGet 0 182 748
assign 1 182 749
heldGet 0 182 749
assign 1 182 750
aliasedGet 0 182 750
assign 1 182 751
heldGet 0 182 751
assign 1 182 752
has 1 182 752
assign 1 0 754
assign 1 182 757
emitDataGet 0 182 757
assign 1 182 758
aliasedGet 0 182 758
assign 1 182 759
heldGet 0 182 759
assign 1 182 760
has 1 182 760
assign 1 0 762
assign 1 0 765
assign 1 0 769
assign 1 0 772
assign 1 0 776
assign 1 183 779
new 0 183 779
assign 1 184 780
heldGet 0 184 780
addStep 1 184 781
heldSet 1 185 782
assign 1 186 783
NAMEPATHGet 0 186 783
typenameSet 1 186 784
resolveNp 0 187 785
createImpliedConstruct 2 188 786
assign 1 193 796
nextDescendGet 0 193 796
return 1 193 797
assign 1 197 810
new 0 197 810
heldSet 1 198 811
assign 1 199 812
NAMEPATHGet 0 199 812
typenameSet 1 199 813
assign 1 200 814
heldGet 0 200 814
heldSet 1 200 815
prepend 1 201 816
assign 1 203 817
new 0 203 817
assign 1 204 818
new 0 204 818
nameSet 1 204 819
assign 1 205 820
new 0 205 820
wasBoundSet 1 205 821
assign 1 206 822
new 0 206 822
boundSet 1 206 823
assign 1 207 824
new 0 207 824
isConstructSet 1 207 825
assign 1 208 826
new 0 208 826
wasImpliedConstructSet 1 208 827
heldSet 1 209 828
assign 1 210 829
CALLGet 0 210 829
typenameSet 1 210 830
return 1 0 834
assign 1 0 837
return 1 0 841
assign 1 0 844
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1862907585: return bem_transGet_0();
case -1026573604: return bem_buildGet_0();
case 2062788390: return bem_inFileGet_0();
case -1694731736: return bem_ntypesGet_0();
case 210264567: return bem_print_0();
case 2043795865: return bem_echo_0();
case 1165489654: return bem_sourceFileNameGet_0();
case -1233972717: return bem_create_0();
case 212191548: return bem_tagGet_0();
case -590451146: return bem_serializeToString_0();
case -315420442: return bem_once_0();
case -1533121038: return bem_new_0();
case 607966049: return bem_serializationIteratorGet_0();
case -827921680: return bem_copy_0();
case 1081968352: return bem_constGet_0();
case 466290922: return bem_iteratorGet_0();
case 247385301: return bem_toString_0();
case -463313615: return bem_inClassNpGet_0();
case -711691351: return bem_deserializeClassNameGet_0();
case -853598946: return bem_serializeContents_0();
case -1802544452: return bem_many_0();
case 460304834: return bem_fieldIteratorGet_0();
case -393343811: return bem_hashGet_0();
case 1291623083: return bem_classNameGet_0();
case 1307328857: return bem_toAny_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1644787064: return bem_end_1(bevd_0);
case 172009000: return bem_otherType_1(bevd_0);
case 1070497437: return bem_transSet_1(bevd_0);
case 1388334950: return bem_undef_1(bevd_0);
case 1999045680: return bem_notEquals_1(bevd_0);
case -78548863: return bem_otherClass_1(bevd_0);
case -170563302: return bem_equals_1(bevd_0);
case 346632408: return bem_undefined_1(bevd_0);
case 663623089: return bem_copyTo_1(bevd_0);
case 1531308157: return bem_def_1(bevd_0);
case -6357522: return bem_ntypesSet_1(bevd_0);
case -941597658: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case 256075010: return bem_defined_1(bevd_0);
case 1289711396: return bem_buildSet_1(bevd_0);
case -1200387177: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -552227638: return bem_sameClass_1(bevd_0);
case -1699269513: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -256010896: return bem_constSet_1(bevd_0);
case -430747251: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 524373837: return bem_sameType_1(bevd_0);
case -826585381: return bem_inClassNpSet_1(bevd_0);
case -1800869854: return bem_sameObject_1(bevd_0);
case -496112306: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1174888067: return bem_inFileSet_1(bevd_0);
case -1625639133: return bem_begin_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 955696951: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -198099377: return bem_createImpliedConstruct_2((BEC_2_5_4_BuildNode) bevd_0, bevd_1);
case -1211642612: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1874247655: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1761563228: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1934333596: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 589240848: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 298076524: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(17, becc_BEC_3_5_5_5_BuildVisitPass7_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_3_5_5_5_BuildVisitPass7_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_3_5_5_5_BuildVisitPass7();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst = (BEC_3_5_5_5_BuildVisitPass7) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_3_5_5_5_BuildVisitPass7.bece_BEC_3_5_5_5_BuildVisitPass7_bevs_inst;
}
}
}
