namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_10, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x64,0x6F,0x4D,0x61,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x6C,0x6F,0x61,0x64,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_57, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_61, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_65, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_66, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 41));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 41));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_3, 1));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 31));
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static new BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_9_3_ContainerSet bevp_emitChecks;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_doMain;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_loadIds;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_ta_ph);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_singleCC = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doMain = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_saveIds = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_ta_ph);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
if (beva_name == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_3_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_ta_ph = beva_name.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_5_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_ta_ph = beva_name.bem_ends_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
 else /* Line: 101*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_6_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_ta_ph;
} /* Line: 102*/
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_ta_ph = beva_arg.bem_swap_2(bevt_1_ta_ph, bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_6_7_SystemProcess bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_ta_ph.bem_argsGet_0();
bevt_1_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_ta_ph = bem_main_1(bevl__args);
bevt_1_ta_ph.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_ta_ph );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_ta_ph = bevp_params.bem_get_2(bevt_2_ta_ph, bevt_3_ta_ph);
bevt_0_ta_ph = bevt_1_ta_ph.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_ta_ph);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 120*/ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 120*/ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 120*/
 else /* Line: 120*/ {
break;
} /* Line: 120*/
} /* Line: 120*/
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try /* Line: 129*/ {
bem_config_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 133*/
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(-1275325619);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_ta_ph.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 138*/
if (bevp_printSteps.bevi_bool)/* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 140*/ {
if (bevl_buildFailed.bevi_bool)/* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 140*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 140*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 140*/ {
bevp_buildMessage.bem_print_0();
} /* Line: 141*/
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = bevp_platform.bemd_0(-1986294773);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(1311824436, bevt_2_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 147*/ {
} /* Line: 147*/
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_ec = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_ta_loop = null;
BEC_2_6_6_SystemObject bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_6_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_2_4_IOFile bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_2_2_4_IOFile bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_4_6_TextString bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_2_4_IOFile bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_6_6_SystemObject bevt_33_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_6_15_SystemCurrentPlatform bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_39_ta_ph = null;
BEC_2_4_6_TextString bevt_40_ta_ph = null;
BEC_2_6_6_SystemObject bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_6_6_SystemObject bevt_46_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_6_6_SystemObject bevt_50_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_2_4_6_TextString bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_2_4_6_TextString bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_61_ta_ph = null;
BEC_2_4_6_TextString bevt_62_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_4_6_TextString bevt_65_ta_ph = null;
BEC_2_5_4_LogicBool bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_5_4_LogicBool bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_2_5_4_LogicBool bevt_70_ta_ph = null;
BEC_2_4_6_TextString bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_4_6_TextString bevt_75_ta_ph = null;
BEC_2_5_4_LogicBool bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_5_4_LogicBool bevt_78_ta_ph = null;
BEC_2_4_6_TextString bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_4_6_TextString bevt_81_ta_ph = null;
BEC_2_5_4_LogicBool bevt_82_ta_ph = null;
BEC_2_4_6_TextString bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_6_TextString bevt_87_ta_ph = null;
BEC_2_5_4_LogicBool bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_5_4_LogicBool bevt_94_ta_ph = null;
BEC_2_5_4_LogicBool bevt_95_ta_ph = null;
BEC_2_5_4_LogicBool bevt_96_ta_ph = null;
BEC_2_6_6_SystemObject bevt_97_ta_ph = null;
BEC_2_4_6_TextString bevt_98_ta_ph = null;
BEC_2_4_6_TextString bevt_99_ta_ph = null;
BEC_2_4_6_TextString bevt_100_ta_ph = null;
BEC_2_4_6_TextString bevt_101_ta_ph = null;
BEC_2_4_6_TextString bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_6_TextString bevt_105_ta_ph = null;
BEC_2_5_4_LogicBool bevt_106_ta_ph = null;
BEC_2_6_6_SystemObject bevt_107_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_108_ta_ph = null;
BEC_2_4_6_TextString bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_9_10_ContainerLinkedList bevt_114_ta_ph = null;
BEC_2_4_6_TextString bevt_115_ta_ph = null;
BEC_2_4_6_TextString bevt_116_ta_ph = null;
BEC_2_4_6_TextString bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_4_6_TextString bevt_119_ta_ph = null;
BEC_2_4_6_TextString bevt_120_ta_ph = null;
BEC_2_4_6_TextString bevt_121_ta_ph = null;
BEC_2_6_6_SystemObject bevt_122_ta_ph = null;
BEC_2_5_4_LogicBool bevt_123_ta_ph = null;
BEC_2_9_4_ContainerList bevt_124_ta_ph = null;
BEC_2_4_6_TextString bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_5_4_LogicBool bevt_127_ta_ph = null;
BEC_2_9_4_ContainerList bevt_128_ta_ph = null;
BEC_2_9_4_ContainerList bevt_129_ta_ph = null;
BEC_2_6_6_SystemObject bevt_130_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_5_4_LogicBool bevt_133_ta_ph = null;
BEC_2_2_4_IOFile bevt_134_ta_ph = null;
BEC_2_2_4_IOFile bevt_135_ta_ph = null;
BEC_2_5_4_LogicBool bevt_136_ta_ph = null;
BEC_2_2_4_IOFile bevt_137_ta_ph = null;
BEC_2_6_6_SystemObject bevt_138_ta_ph = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_6_ta_ph = bevp_params.bem_get_1(bevl_bkey);
if (bevt_6_ta_ph == null) {
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 157*/ {
bevt_7_ta_ph = bevp_params.bem_get_1(bevl_bkey);
bevt_0_ta_loop = bevt_7_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 158*/ {
bevt_8_ta_ph = bevt_0_ta_loop.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_8_ta_ph).bevi_bool)/* Line: 158*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(450495808);
bevt_10_ta_ph = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_10_ta_ph.bevi_bool) {
bevt_9_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_9_ta_ph.bevi_bool)/* Line: 159*/ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_11_ta_ph = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_11_ta_ph);
} /* Line: 161*/
} /* Line: 159*/
 else /* Line: 158*/ {
break;
} /* Line: 158*/
} /* Line: 158*/
} /* Line: 158*/
bevt_14_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_13_ta_ph = bevt_14_ta_ph.bem_nameGet_0();
bevt_15_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_12_ta_ph = bevt_13_ta_ph.bem_equals_1(bevt_15_ta_ph);
if (bevt_12_ta_ph.bevi_bool)/* Line: 166*/ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 167*/
bevt_17_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_12));
bevt_16_ta_ph = bevp_params.bem_get_1(bevt_17_ta_ph);
bevp_libName = (BEC_2_4_6_TextString) bevt_16_ta_ph.bem_firstGet_0();
bevt_19_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_18_ta_ph = bevp_params.bem_has_1(bevt_19_ta_ph);
if (bevt_18_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_21_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_20_ta_ph = bevp_params.bem_get_1(bevt_21_ta_ph);
bevp_exeName = (BEC_2_4_6_TextString) bevt_20_ta_ph.bem_firstGet_0();
} /* Line: 171*/
 else /* Line: 172*/ {
bevp_exeName = bevp_libName;
} /* Line: 173*/
bevt_25_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_26_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_24_ta_ph = bevp_params.bem_get_2(bevt_25_ta_ph, bevt_26_ta_ph);
bevt_23_ta_ph = bevt_24_ta_ph.bem_firstGet_0();
bevt_22_ta_ph = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_23_ta_ph);
bevp_buildPath = bevt_22_ta_ph.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_27_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_15));
bevp_buildPath.bem_addStep_1(bevt_27_ta_ph);
bevt_31_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_32_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_30_ta_ph = bevp_params.bem_get_2(bevt_31_ta_ph, bevt_32_ta_ph);
bevt_29_ta_ph = bevt_30_ta_ph.bem_firstGet_0();
bevt_28_ta_ph = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_29_ta_ph);
bevp_includePath = bevt_28_ta_ph.bem_pathGet_0();
bevt_35_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_18));
bevt_37_ta_ph = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_36_ta_ph = bevt_37_ta_ph.bem_nameGet_0();
bevt_34_ta_ph = bevp_params.bem_get_2(bevt_35_ta_ph, bevt_36_ta_ph);
bevt_33_ta_ph = bevt_34_ta_ph.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_33_ta_ph );
bevt_40_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_41_ta_ph = bevp_platform.bemd_0(-1986294773);
bevt_39_ta_ph = bevp_params.bem_get_2(bevt_40_ta_ph, (BEC_2_4_6_TextString) bevt_41_ta_ph );
bevt_38_ta_ph = bevt_39_ta_ph.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_38_ta_ph );
bevt_44_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_45_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_43_ta_ph = bevp_params.bem_get_2(bevt_44_ta_ph, bevt_45_ta_ph);
bevt_42_ta_ph = bevt_43_ta_ph.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_42_ta_ph);
bevt_48_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_49_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_47_ta_ph = bevp_params.bem_get_2(bevt_48_ta_ph, bevt_49_ta_ph);
bevt_46_ta_ph = bevt_47_ta_ph.bem_firstGet_0();
bevp_doMain = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_46_ta_ph);
bevt_52_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_53_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_51_ta_ph = bevp_params.bem_get_2(bevt_52_ta_ph, bevt_53_ta_ph);
bevt_50_ta_ph = bevt_51_ta_ph.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_50_ta_ph);
bevt_56_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_57_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_55_ta_ph = bevp_params.bem_get_2(bevt_56_ta_ph, bevt_57_ta_ph);
bevt_54_ta_ph = bevt_55_ta_ph.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_54_ta_ph);
bevt_58_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_26));
bevp_loadSyns = bevp_params.bem_get_1(bevt_58_ta_ph);
bevt_59_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevp_loadIds = bevp_params.bem_get_1(bevt_59_ta_ph);
bevt_60_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_28));
bevp_initLibs = bevp_params.bem_get_1(bevt_60_ta_ph);
bevt_62_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_29));
bevt_61_ta_ph = bevp_params.bem_get_1(bevt_62_ta_ph);
bevp_mainName = (BEC_2_4_6_TextString) bevt_61_ta_ph.bem_firstGet_0();
bevt_64_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_30));
bevt_63_ta_ph = bevp_params.bem_get_1(bevt_64_ta_ph);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_63_ta_ph.bem_firstGet_0();
bevt_65_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_31));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_65_ta_ph);
if (bevp_usedLibrarysStr == null) {
bevt_66_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_66_ta_ph.bevi_bool)/* Line: 192*/ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 193*/
bevt_67_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_32));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_67_ta_ph);
if (bevp_closeLibrariesStr == null) {
bevt_68_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_68_ta_ph.bevi_bool)/* Line: 196*/ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 197*/
bevt_69_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_69_ta_ph);
if (bevp_deployFilesFrom == null) {
bevt_70_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_70_ta_ph.bevi_bool)/* Line: 200*/ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 201*/
bevt_71_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_71_ta_ph);
if (bevp_deployFilesTo == null) {
bevt_72_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_72_ta_ph.bevi_bool)/* Line: 204*/ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 205*/
bevt_73_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_extIncludes = bevp_params.bem_get_1(bevt_73_ta_ph);
if (bevp_extIncludes == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 208*/ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 209*/
bevt_75_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_75_ta_ph);
if (bevp_ccObjArgs == null) {
bevt_76_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_76_ta_ph.bevi_bool)/* Line: 212*/ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 213*/
bevt_77_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extLibs = bevp_params.bem_get_1(bevt_77_ta_ph);
if (bevp_extLibs == null) {
bevt_78_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_78_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_78_ta_ph.bevi_bool)/* Line: 216*/ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 217*/
bevt_79_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_79_ta_ph);
if (bevp_linkLibArgs == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 220*/ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 221*/
bevt_81_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_81_ta_ph);
if (bevp_extLinkObjects == null) {
bevt_82_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_82_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_82_ta_ph.bevi_bool)/* Line: 224*/ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 225*/
bevt_83_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_83_ta_ph);
if (bevp_emitFileHeader == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 228*/ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-1187553071);
} /* Line: 229*/
bevt_85_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_runArgs = bevp_params.bem_get_1(bevt_85_ta_ph);
if (bevp_runArgs == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 232*/ {
bevp_runArgs = bevp_runArgs.bemd_0(-1187553071);
} /* Line: 233*/
 else /* Line: 234*/ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 235*/
bevt_87_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_42));
bevt_88_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_87_ta_ph, bevt_88_ta_ph);
bevt_89_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_43));
bevt_90_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_89_ta_ph, bevt_90_ta_ph);
bevt_91_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_44));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_91_ta_ph);
bevt_92_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_92_ta_ph);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_93_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_46));
bevl_pacm = bevp_params.bem_get_1(bevt_93_ta_ph);
if (bevl_pacm == null) {
bevt_94_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_94_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_94_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_96_ta_ph = bevl_pacm.bem_isEmptyGet_0();
if (bevt_96_ta_ph.bevi_bool) {
bevt_95_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_95_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_95_ta_ph.bevi_bool)/* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 243*/
 else /* Line: 243*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 243*/ {
bevt_1_ta_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
/* Line: 244*/ {
bevt_97_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_97_ta_ph).bevi_bool)/* Line: 244*/ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 245*/
 else /* Line: 244*/ {
break;
} /* Line: 244*/
} /* Line: 244*/
} /* Line: 244*/
bevt_98_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_98_ta_ph);
bevt_99_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_48));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_99_ta_ph);
bevt_100_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_run = bevp_params.bem_isTrue_1(bevt_100_ta_ph);
bevt_101_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_101_ta_ph);
bevt_102_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_51));
bevt_103_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_102_ta_ph, bevt_103_ta_ph);
bevt_104_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_emitLangs = bevp_params.bem_get_1(bevt_104_ta_ph);
bevt_105_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevp_emitFlags = bevp_params.bem_get_1(bevt_105_ta_ph);
bevp_emitChecks = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (bevp_emitFlags == null) {
bevt_106_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_106_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_106_ta_ph.bevi_bool)/* Line: 256*/ {
bevt_2_ta_loop = bevp_emitFlags.bem_linkedListIteratorGet_0();
while (true)
/* Line: 257*/ {
bevt_107_ta_ph = bevt_2_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_107_ta_ph).bevi_bool)/* Line: 257*/ {
bevl_ec = (BEC_2_4_6_TextString) bevt_2_ta_loop.bem_nextGet_0();
bevp_emitChecks.bem_addValue_1(bevl_ec);
} /* Line: 259*/
 else /* Line: 257*/ {
break;
} /* Line: 257*/
} /* Line: 257*/
} /* Line: 257*/
bevt_109_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevt_110_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_108_ta_ph = bevp_params.bem_get_2(bevt_109_ta_ph, bevt_110_ta_ph);
bevp_compiler = (BEC_2_4_6_TextString) bevt_108_ta_ph.bem_firstGet_0();
bevt_112_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_113_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_111_ta_ph = bevp_params.bem_get_2(bevt_112_ta_ph, bevt_113_ta_ph);
bevp_makeName = (BEC_2_4_6_TextString) bevt_111_ta_ph.bem_firstGet_0();
bevt_116_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_115_ta_ph = bevt_116_ta_ph.bem_add_1(bevp_makeName);
bevt_117_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_114_ta_ph = bevp_params.bem_get_2(bevt_115_ta_ph, bevt_117_ta_ph);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_114_ta_ph.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 272*/ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 273*/
 else /* Line: 274*/ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_59));
} /* Line: 275*/
bevt_121_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_120_ta_ph = bevl_outLang.bem_add_1(bevt_121_ta_ph);
bevt_122_ta_ph = bevp_platform.bemd_0(-1986294773);
bevt_119_ta_ph = bevt_120_ta_ph.bem_add_1(bevt_122_ta_ph);
bevl_platformSources = bevp_params.bem_get_1(bevt_119_ta_ph);
if (bevl_platformSources == null) {
bevt_123_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_123_ta_ph.bevi_bool)/* Line: 283*/ {
bevt_124_ta_ph = bevp_params.bem_orderedGet_0();
bevt_124_ta_ph.bem_addAll_1(bevl_platformSources);
} /* Line: 284*/
bevt_126_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_125_ta_ph = bevl_outLang.bem_add_1(bevt_126_ta_ph);
bevl_langSources = bevp_params.bem_get_1(bevt_125_ta_ph);
if (bevl_langSources == null) {
bevt_127_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_127_ta_ph.bevi_bool)/* Line: 288*/ {
bevt_128_ta_ph = bevp_params.bem_orderedGet_0();
bevt_128_ta_ph.bem_addAll_1(bevl_langSources);
} /* Line: 289*/
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_129_ta_ph = bevp_params.bem_orderedGet_0();
bevt_3_ta_loop = bevt_129_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 293*/ {
bevt_130_ta_ph = bevt_3_ta_loop.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_130_ta_ph).bevi_bool)/* Line: 293*/ {
bevl_istr = (BEC_2_4_6_TextString) bevt_3_ta_loop.bemd_0(450495808);
bevt_131_ta_ph = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_131_ta_ph);
} /* Line: 294*/
 else /* Line: 293*/ {
break;
} /* Line: 293*/
} /* Line: 293*/
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(-879939360);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_134_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_133_ta_ph = bevt_134_ta_ph.bem_existsGet_0();
if (bevt_133_ta_ph.bevi_bool) {
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 301*/ {
bevt_135_ta_ph = bevp_emitPath.bem_fileGet_0();
bevt_135_ta_ph.bem_makeDirs_0();
} /* Line: 302*/
if (bevp_emitFileHeader == null) {
bevt_136_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_136_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_136_ta_ph.bevi_bool)/* Line: 304*/ {
bevt_137_ta_ph = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_137_ta_ph.bem_readerGet_0();
bevt_138_ta_ph = bevl_emr.bemd_0(353438806);
bevp_emitFileHeader = bevt_138_ta_ph.bemd_0(-24113205);
bevl_emr.bemd_0(1986846950);
} /* Line: 307*/
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_ta_ph = bevl_toRet.bemd_1(-1744665665, bevp_nl);
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_62));
bevt_0_ta_ph = bevt_1_ta_ph.bemd_1(-1744665665, bevt_2_ta_ph);
bevt_3_ta_ph = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_ta_ph.bemd_1(-1744665665, bevt_3_ta_ph);
bevt_5_ta_ph = bevl_toRet.bemd_1(-1744665665, bevp_nl);
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_63));
bevt_4_ta_ph = bevt_5_ta_ph.bemd_1(-1744665665, bevt_6_ta_ph);
bevt_7_ta_ph = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_ta_ph.bemd_1(-1744665665, bevt_7_ta_ph);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_ta_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_ta_loop = null;
BEC_2_9_3_ContainerMap bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_9_3_ContainerSet bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_6_6_SystemObject bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 321*/ {
bevt_3_ta_ph = bevl_ci.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 321*/ {
bevl_clnode = bevl_ci.bemd_0(450495808);
bevt_5_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_ta_ph = bevl_clnode.bemd_0(1875047920);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(-1022253086);
bevt_4_ta_ph = bevt_5_ta_ph.bem_has_1(bevt_6_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 323*/ {
bevt_10_ta_ph = bevl_clnode.bemd_0(1875047920);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(-524215985);
bevt_8_ta_ph = bevt_9_ta_ph.bemd_0(-1275325619);
bevl_toEmit.bem_put_1(bevt_8_ta_ph);
bevt_11_ta_ph = bevp_emitData.bem_usedByGet_0();
bevt_14_ta_ph = bevl_clnode.bemd_0(1875047920);
bevt_13_ta_ph = bevt_14_ta_ph.bemd_0(-524215985);
bevt_12_ta_ph = bevt_13_ta_ph.bemd_0(-1275325619);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_ta_ph.bem_get_1(bevt_12_ta_ph);
if (bevl_usedBy == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 326*/ {
bevt_0_ta_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
/* Line: 327*/ {
bevt_16_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_16_ta_ph.bevi_bool)/* Line: 327*/ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 328*/
 else /* Line: 327*/ {
break;
} /* Line: 327*/
} /* Line: 327*/
} /* Line: 327*/
bevt_17_ta_ph = bevp_emitData.bem_subClassesGet_0();
bevt_20_ta_ph = bevl_clnode.bemd_0(1875047920);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-524215985);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-1275325619);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_ta_ph.bem_get_1(bevt_18_ta_ph);
if (bevl_subClasses == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 332*/ {
bevt_1_ta_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
/* Line: 333*/ {
bevt_22_ta_ph = bevt_1_ta_loop.bem_hasNextGet_0();
if (bevt_22_ta_ph.bevi_bool)/* Line: 333*/ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_ta_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 334*/
 else /* Line: 333*/ {
break;
} /* Line: 333*/
} /* Line: 333*/
} /* Line: 333*/
} /* Line: 332*/
} /* Line: 323*/
 else /* Line: 321*/ {
break;
} /* Line: 321*/
} /* Line: 321*/
bevt_23_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 339*/ {
bevt_24_ta_ph = bevl_ci.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 339*/ {
bevl_clnode = bevl_ci.bemd_0(450495808);
bevt_25_ta_ph = bevl_clnode.bemd_0(1875047920);
bevt_29_ta_ph = bevl_clnode.bemd_0(1875047920);
bevt_28_ta_ph = bevt_29_ta_ph.bemd_0(-524215985);
bevt_27_ta_ph = bevt_28_ta_ph.bemd_0(-1275325619);
bevt_26_ta_ph = bevl_toEmit.bem_has_1(bevt_27_ta_ph);
bevt_25_ta_ph.bemd_1(-656634810, bevt_26_ta_ph);
} /* Line: 341*/
 else /* Line: 339*/ {
break;
} /* Line: 339*/
} /* Line: 339*/
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_6_9_SystemException bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
if (bevp_emitCommon == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 352*/ {
return bevp_emitCommon;
} /* Line: 353*/
if (bevp_emitLangs == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 358*/ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_ta_ph = bevl_emitLang.bem_equals_1(bevt_3_ta_ph);
if (bevt_2_ta_ph.bevi_bool)/* Line: 360*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 361*/
 else /* Line: 360*/ {
bevt_5_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_ta_ph = bevl_emitLang.bem_equals_1(bevt_5_ta_ph);
if (bevt_4_ta_ph.bevi_bool)/* Line: 362*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 363*/
 else /* Line: 360*/ {
bevt_7_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_ta_ph = bevl_emitLang.bem_equals_1(bevt_7_ta_ph);
if (bevt_6_ta_ph.bevi_bool)/* Line: 364*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 365*/
 else /* Line: 360*/ {
bevt_9_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_ta_ph = bevl_emitLang.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 366*/ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 367*/
 else /* Line: 370*/ {
bevt_11_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_68));
bevt_10_ta_ph = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_ta_ph);
throw new be.BECS_ThrowBack(bevt_10_ta_ph);
} /* Line: 371*/
} /* Line: 360*/
} /* Line: 360*/
} /* Line: 360*/
return bevp_emitCommon;
} /* Line: 373*/
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_2_4_IOFile bevt_4_ta_ph = null;
BEC_2_6_10_SystemSerializer bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_7_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(beva_lsp);
bevt_0_ta_ph.bem_print_0();
bevt_2_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_ta_ph.bem_now_0();
bevt_4_ta_ph = bevl_synEmitPath.bem_fileGet_0();
bevt_3_ta_ph = bevt_4_ta_ph.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_ta_ph.bemd_0(353438806);
bevt_5_ta_ph = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_ta_ph.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevt_6_ta_ph.bem_addValue_1(bevl_scls);
bevt_8_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_ta_ph = (BEC_2_4_8_TimeInterval) bevt_8_ta_ph.bem_now_0();
bevl_sse = bevt_7_ta_ph.bem_subtract_1(bevl_sst);
bevt_10_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevl_sse);
bevt_9_ta_ph.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_6_6_SystemObject bevt_2_ta_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_ta_loop = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_4_6_TextString bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_22_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_25_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_26_ta_ph = null;
BEC_2_5_10_BuildEmitCommon bevt_27_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_28_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_29_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_30_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_4_6_TextString bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_3_MathInt bevt_38_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_39_ta_ph = null;
BEC_2_6_6_SystemObject bevt_40_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_41_ta_ph = null;
BEC_2_6_6_SystemObject bevt_42_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_43_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_44_ta_ph = null;
BEC_2_5_4_LogicBool bevt_45_ta_ph = null;
BEC_2_4_6_TextString bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_2_4_6_TextString bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_6_6_SystemObject bevt_51_ta_ph = null;
BEC_2_6_6_SystemObject bevt_52_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_53_ta_ph = null;
BEC_2_6_6_SystemObject bevt_54_ta_ph = null;
BEC_2_6_6_SystemObject bevt_55_ta_ph = null;
BEC_2_6_6_SystemObject bevt_56_ta_ph = null;
BEC_2_6_6_SystemObject bevt_57_ta_ph = null;
BEC_2_6_6_SystemObject bevt_58_ta_ph = null;
BEC_2_6_6_SystemObject bevt_59_ta_ph = null;
BEC_2_6_6_SystemObject bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_6_6_SystemObject bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
BEC_2_6_6_SystemObject bevt_65_ta_ph = null;
BEC_2_6_6_SystemObject bevt_66_ta_ph = null;
BEC_2_4_6_TextString bevt_67_ta_ph = null;
BEC_2_4_6_TextString bevt_68_ta_ph = null;
BEC_2_4_6_TextString bevt_69_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_70_ta_ph = null;
BEC_3_2_4_4_IOFilePath bevt_71_ta_ph = null;
BEC_2_4_6_TextString bevt_72_ta_ph = null;
BEC_2_6_6_SystemObject bevt_73_ta_ph = null;
BEC_2_6_6_SystemObject bevt_74_ta_ph = null;
BEC_2_6_6_SystemObject bevt_75_ta_ph = null;
BEC_2_6_6_SystemObject bevt_76_ta_ph = null;
BEC_2_6_6_SystemObject bevt_77_ta_ph = null;
BEC_2_6_6_SystemObject bevt_78_ta_ph = null;
BEC_2_6_6_SystemObject bevt_79_ta_ph = null;
BEC_2_6_6_SystemObject bevt_80_ta_ph = null;
BEC_2_6_6_SystemObject bevt_81_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_82_ta_ph = null;
BEC_2_4_8_TimeInterval bevt_83_ta_ph = null;
BEC_2_5_4_LogicBool bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_4_6_TextString bevt_86_ta_ph = null;
BEC_2_5_4_LogicBool bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_4_6_TextString bevt_89_ta_ph = null;
BEC_2_5_4_LogicBool bevt_90_ta_ph = null;
BEC_2_4_6_TextString bevt_91_ta_ph = null;
BEC_2_4_6_TextString bevt_92_ta_ph = null;
BEC_2_4_6_TextString bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_6_TextString bevt_95_ta_ph = null;
BEC_2_4_6_TextString bevt_96_ta_ph = null;
BEC_2_4_6_TextString bevt_97_ta_ph = null;
BEC_2_4_3_MathInt bevt_98_ta_ph = null;
bevt_5_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_ta_ph.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 396*/ {
bevt_0_ta_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
/* Line: 397*/ {
bevt_7_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_ta_ph).bevi_bool)/* Line: 397*/ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 398*/
 else /* Line: 397*/ {
break;
} /* Line: 397*/
} /* Line: 397*/
} /* Line: 397*/
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_8_ta_ph.bevi_bool)/* Line: 402*/ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool)/* Line: 405*/ {
bevt_10_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_ta_ph = bevt_10_ta_ph.bem_add_1(bevp_libName);
bevt_9_ta_ph.bem_print_0();
} /* Line: 406*/
} /* Line: 405*/
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_ta_loop = bevp_usedLibrarysStr.bemd_0(2045941275);
while (true)
/* Line: 411*/ {
bevt_11_ta_ph = bevt_1_ta_loop.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_11_ta_ph).bevi_bool)/* Line: 411*/ {
bevl_ups = bevt_1_ta_loop.bemd_0(450495808);
bevt_13_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_ta_ph.bevi_bool) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 412*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 415*/
} /* Line: 412*/
 else /* Line: 411*/ {
break;
} /* Line: 411*/
} /* Line: 411*/
bevt_2_ta_loop = bevp_closeLibrariesStr.bemd_0(2045941275);
while (true)
/* Line: 418*/ {
bevt_14_ta_ph = bevt_2_ta_loop.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_14_ta_ph).bevi_bool)/* Line: 418*/ {
bevl_ups = bevt_2_ta_loop.bemd_0(450495808);
bevt_16_ta_ph = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_ta_ph.bevi_bool) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 419*/ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_ta_ph = bevl_pack.bemd_0(1717308312);
bevp_closeLibraries.bem_put_1(bevt_17_ta_ph);
} /* Line: 423*/
} /* Line: 419*/
 else /* Line: 418*/ {
break;
} /* Line: 418*/
} /* Line: 418*/
if (bevp_parse.bevi_bool)/* Line: 426*/ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
/* Line: 429*/ {
bevt_18_ta_ph = bevl_i.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 429*/ {
bevl_tb = bevl_i.bemd_0(450495808);
bevt_20_ta_ph = bevl_tb.bemd_0(-1275325619);
bevt_19_ta_ph = bevl_built.bem_has_1(bevt_20_ta_ph);
if (!(bevt_19_ta_ph.bevi_bool))/* Line: 432*/ {
bevt_21_ta_ph = bevl_tb.bemd_0(-1275325619);
bevl_built.bem_put_1(bevt_21_ta_ph);
bem_doParse_1(bevl_tb);
} /* Line: 434*/
} /* Line: 432*/
 else /* Line: 429*/ {
break;
} /* Line: 429*/
} /* Line: 429*/
bem_buildSyns_1(bevl_em);
} /* Line: 437*/
bevt_23_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_ta_ph = (BEC_2_4_8_TimeInterval) bevt_23_ta_ph.bem_now_0();
bevp_parseTime = bevt_22_ta_ph.bem_subtract_1(bevp_startTime);
bevt_25_ta_ph = bem_emitCommonGet_0();
if (bevt_25_ta_ph == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 443*/ {
bevt_26_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_ta_ph.bem_now_0();
bevt_27_ta_ph = bem_emitCommonGet_0();
bevt_27_ta_ph.bem_doEmit_0();
bevt_29_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_ta_ph = (BEC_2_4_8_TimeInterval) bevt_29_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_28_ta_ph.bem_subtract_1(bevp_startTime);
bevt_31_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_ta_ph = (BEC_2_4_8_TimeInterval) bevt_31_ta_ph.bem_now_0();
bevl_emitTime = bevt_30_ta_ph.bem_subtract_1(bevl_emitStart);
bevt_33_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_32_ta_ph = bevt_33_ta_ph.bem_add_1(bevp_parseTime);
bevt_32_ta_ph.bem_print_0();
bevt_35_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_34_ta_ph = bevt_35_ta_ph.bem_add_1(bevl_emitTime);
bevt_34_ta_ph.bem_print_0();
bevt_37_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_36_ta_ph.bem_print_0();
bevt_38_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_ta_ph;
} /* Line: 452*/
if (bevp_doEmit.bevi_bool)/* Line: 454*/ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(-1080733267);
bevt_39_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 458*/ {
bevt_40_ta_ph = bevl_ci.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_40_ta_ph).bevi_bool)/* Line: 458*/ {
bevl_clnode = bevl_ci.bemd_0(450495808);
bevl_em.bemd_1(-1439343139, bevl_clnode);
} /* Line: 460*/
 else /* Line: 458*/ {
break;
} /* Line: 458*/
} /* Line: 458*/
bevl_em.bemd_0(731246873);
bevl_em.bemd_0(-1537986229);
bevt_41_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 464*/ {
bevt_42_ta_ph = bevl_ci.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_42_ta_ph).bevi_bool)/* Line: 464*/ {
bevl_clnode = bevl_ci.bemd_0(450495808);
bevl_em.bemd_1(-1247234309, bevl_clnode);
} /* Line: 466*/
 else /* Line: 464*/ {
break;
} /* Line: 464*/
} /* Line: 464*/
} /* Line: 464*/
bevt_44_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_ta_ph = (BEC_2_4_8_TimeInterval) bevt_44_ta_ph.bem_now_0();
bevp_parseEmitTime = bevt_43_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_45_ta_ph.bevi_bool)/* Line: 471*/ {
bevt_47_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_46_ta_ph = bevt_47_ta_ph.bem_add_1(bevp_parseTime);
bevt_46_ta_ph.bem_print_0();
} /* Line: 472*/
bevt_49_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_48_ta_ph = bevt_49_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_48_ta_ph.bem_print_0();
if (bevp_prepMake.bevi_bool)/* Line: 475*/ {
bevl_em.bemd_1(-1260444076, bevp_deployLibrary);
} /* Line: 477*/
if (bevp_make.bevi_bool)/* Line: 480*/ {
if (bevp_genOnly.bevi_bool) {
bevt_50_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_50_ta_ph.bevi_bool)/* Line: 481*/ {
bevl_em.bemd_1(935611293, bevp_deployLibrary);
bevl_em.bemd_1(-997496728, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool)/* Line: 484*/ {
bevt_3_ta_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
/* Line: 485*/ {
bevt_51_ta_ph = bevt_3_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_ta_ph).bevi_bool)/* Line: 485*/ {
bevl_bp = bevt_3_ta_loop.bem_nextGet_0();
bevt_52_ta_ph = bevl_bp.bemd_0(-1080733267);
bevl_cpFrom = bevt_52_ta_ph.bemd_0(-1076082735);
bevt_53_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_ta_ph.bem_copy_0();
bevt_55_ta_ph = bevl_cpFrom.bemd_0(1361918892);
bevt_54_ta_ph = bevt_55_ta_ph.bemd_0(-142911972);
bevl_cpTo.bemd_1(2128667968, bevt_54_ta_ph);
bevt_57_ta_ph = bevl_cpTo.bemd_0(2124815106);
bevt_56_ta_ph = bevt_57_ta_ph.bemd_0(804252088);
if (((BEC_2_5_4_LogicBool) bevt_56_ta_ph).bevi_bool)/* Line: 489*/ {
bevt_58_ta_ph = bevl_cpTo.bemd_0(2124815106);
bevt_58_ta_ph.bemd_0(650640643);
} /* Line: 490*/
bevt_61_ta_ph = bevl_cpTo.bemd_0(2124815106);
bevt_60_ta_ph = bevt_61_ta_ph.bemd_0(804252088);
bevt_59_ta_ph = bevt_60_ta_ph.bemd_0(1080161714);
if (((BEC_2_5_4_LogicBool) bevt_59_ta_ph).bevi_bool)/* Line: 492*/ {
bevt_62_ta_ph = bevl_cpFrom.bemd_0(2124815106);
bevt_63_ta_ph = bevl_cpTo.bemd_0(2124815106);
bevl_em.bemd_2(2134113794, bevt_62_ta_ph, bevt_63_ta_ph);
} /* Line: 493*/
} /* Line: 492*/
 else /* Line: 485*/ {
break;
} /* Line: 485*/
} /* Line: 485*/
} /* Line: 485*/
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
/* Line: 500*/ {
bevt_64_ta_ph = bevl_fIter.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_64_ta_ph).bevi_bool)/* Line: 500*/ {
bevt_65_ta_ph = bevl_tIter.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_65_ta_ph).bevi_bool)/* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 500*/
 else /* Line: 500*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 500*/ {
bevt_66_ta_ph = bevl_fIter.bemd_0(450495808);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_ta_ph );
bevt_71_ta_ph = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_ta_ph = (BEC_3_2_4_4_IOFilePath) bevt_71_ta_ph.bem_copy_0();
bevt_69_ta_ph = bevt_70_ta_ph.bem_toString_0();
bevt_72_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_68_ta_ph = bevt_69_ta_ph.bem_add_1(bevt_72_ta_ph);
bevt_73_ta_ph = bevl_tIter.bemd_0(450495808);
bevt_67_ta_ph = bevt_68_ta_ph.bem_add_1(bevt_73_ta_ph);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_ta_ph);
bevt_75_ta_ph = bevl_cpTo.bemd_0(2124815106);
bevt_74_ta_ph = bevt_75_ta_ph.bemd_0(804252088);
if (((BEC_2_5_4_LogicBool) bevt_74_ta_ph).bevi_bool)/* Line: 504*/ {
bevt_76_ta_ph = bevl_cpTo.bemd_0(2124815106);
bevt_76_ta_ph.bemd_0(650640643);
} /* Line: 505*/
bevt_79_ta_ph = bevl_cpTo.bemd_0(2124815106);
bevt_78_ta_ph = bevt_79_ta_ph.bemd_0(804252088);
bevt_77_ta_ph = bevt_78_ta_ph.bemd_0(1080161714);
if (((BEC_2_5_4_LogicBool) bevt_77_ta_ph).bevi_bool)/* Line: 507*/ {
bevt_80_ta_ph = bevl_cpFrom.bemd_0(2124815106);
bevt_81_ta_ph = bevl_cpTo.bemd_0(2124815106);
bevl_em.bemd_2(2134113794, bevt_80_ta_ph, bevt_81_ta_ph);
} /* Line: 508*/
} /* Line: 507*/
 else /* Line: 500*/ {
break;
} /* Line: 500*/
} /* Line: 500*/
} /* Line: 500*/
} /* Line: 481*/
bevt_83_ta_ph = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_ta_ph = (BEC_2_4_8_TimeInterval) bevt_83_ta_ph.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_ta_ph.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_84_ta_ph.bevi_bool)/* Line: 515*/ {
bevt_86_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_85_ta_ph = bevt_86_ta_ph.bem_add_1(bevp_parseTime);
bevt_85_ta_ph.bem_print_0();
} /* Line: 516*/
if (bevp_parseEmitTime == null) {
bevt_87_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_87_ta_ph.bevi_bool)/* Line: 518*/ {
bevt_89_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_88_ta_ph = bevt_89_ta_ph.bem_add_1(bevp_parseEmitTime);
bevt_88_ta_ph.bem_print_0();
} /* Line: 519*/
if (bevp_parseEmitCompileTime == null) {
bevt_90_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_90_ta_ph.bevi_bool)/* Line: 521*/ {
bevt_92_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_91_ta_ph = bevt_92_ta_ph.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_ta_ph.bem_print_0();
} /* Line: 522*/
if (bevp_run.bevi_bool)/* Line: 525*/ {
bevt_93_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_93_ta_ph.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(-105141328, bevp_deployLibrary, bevp_runArgs);
bevt_96_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_95_ta_ph = bevt_96_ta_ph.bem_add_1(bevl_result);
bevt_97_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_94_ta_ph = bevt_95_ta_ph.bem_add_1(bevt_97_ta_ph);
bevt_94_ta_ph.bem_print_0();
return bevl_result;
} /* Line: 529*/
bevt_98_ta_ph = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_ta_ph;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_6_ta_ph = null;
bevt_0_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 535*/ {
bevt_1_ta_ph = bevl_ci.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 535*/ {
bevl_kls = bevl_ci.bemd_0(450495808);
bevt_2_ta_ph = bevl_kls.bemd_0(1875047920);
bevt_2_ta_ph.bemd_1(-2137116247, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-2137116247, bevp_libName);
} /* Line: 539*/
 else /* Line: 535*/ {
break;
} /* Line: 535*/
} /* Line: 535*/
bevt_3_ta_ph = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 541*/ {
bevt_4_ta_ph = bevl_ci.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_4_ta_ph).bevi_bool)/* Line: 541*/ {
bevl_kls = bevl_ci.bemd_0(450495808);
bevt_5_ta_ph = bevl_kls.bemd_0(1875047920);
bevl_syn = bevt_5_ta_ph.bemd_0(-1301900556);
bevl_syn.bemd_2(-1959991600, this, bevl_kls);
bevl_syn.bemd_1(1513631365, this);
} /* Line: 545*/
 else /* Line: 541*/ {
break;
} /* Line: 541*/
} /* Line: 541*/
bevt_6_ta_ph = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_ta_ph);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_6_6_SystemObject bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_6_6_SystemObject bevt_20_ta_ph = null;
bevt_2_ta_ph = beva_klass.bemd_0(1875047920);
bevt_1_ta_ph = bevt_2_ta_ph.bemd_0(-1301900556);
if (bevt_1_ta_ph == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 551*/ {
bevt_4_ta_ph = beva_klass.bemd_0(1875047920);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_0(-1301900556);
return bevt_3_ta_ph;
} /* Line: 552*/
bevt_5_ta_ph = beva_klass.bemd_0(1875047920);
bevt_5_ta_ph.bemd_1(-2137116247, bevp_libName);
bevt_8_ta_ph = beva_klass.bemd_0(1875047920);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(-185753870);
if (bevt_7_ta_ph == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 555*/ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 556*/
 else /* Line: 557*/ {
bevt_9_ta_ph = bevp_emitData.bem_classesGet_0();
bevt_12_ta_ph = beva_klass.bemd_0(1875047920);
bevt_11_ta_ph = bevt_12_ta_ph.bemd_0(-185753870);
bevt_10_ta_ph = bevt_11_ta_ph.bemd_0(-1275325619);
bevl_pklass = bevt_9_ta_ph.bem_get_1(bevt_10_ta_ph);
if (bevl_pklass == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 560*/ {
bevt_14_ta_ph = bevl_pklass.bemd_0(1875047920);
bevt_14_ta_ph.bemd_1(-2137116247, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 562*/
 else /* Line: 563*/ {
bevt_16_ta_ph = beva_klass.bemd_0(1875047920);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_0(-185753870);
bevl_psyn = bem_getSynNp_1(bevt_15_ta_ph);
} /* Line: 566*/
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 568*/
bevt_17_ta_ph = beva_klass.bemd_0(1875047920);
bevt_17_ta_ph.bemd_1(1449090657, bevl_syn);
bevt_20_ta_ph = beva_klass.bemd_0(1875047920);
bevt_19_ta_ph = bevt_20_ta_ph.bemd_0(-524215985);
bevt_18_ta_ph = bevt_19_ta_ph.bemd_0(-1275325619);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_ta_ph , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevl_nps = beva_np.bemd_0(-1275325619);
bevt_0_ta_ph = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_ta_ph.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 578*/ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 579*/
bevt_2_ta_ph = bem_emitterGet_0();
bevl_syn = bevt_2_ta_ph.bemd_1(-489639171, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_sharedEmitter == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 594*/ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 595*/
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_ta_ph = null;
BEC_2_4_6_TextString bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_4_6_TextString bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_4_6_TextString bevt_13_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_ta_ph = null;
BEC_2_4_6_TextString bevt_19_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_ta_ph = null;
BEC_2_4_6_TextString bevt_21_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_ta_ph = null;
BEC_2_4_6_TextString bevt_23_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_ta_ph = null;
BEC_2_4_6_TextString bevt_31_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_ta_ph = null;
BEC_2_4_6_TextString bevt_35_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_ta_ph = null;
BEC_2_4_6_TextString bevt_39_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_ta_ph = null;
BEC_2_4_6_TextString bevt_41_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_ta_ph = null;
BEC_2_4_6_TextString bevt_47_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_ta_ph = null;
BEC_2_4_6_TextString bevt_49_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_ta_ph = null;
BEC_2_4_6_TextString bevt_53_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_4_6_TextString bevt_56_ta_ph = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_ta_ph = null;
BEC_2_4_6_TextString bevt_58_ta_ph = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_ta_ph = null;
BEC_2_9_3_ContainerMap bevt_60_ta_ph = null;
BEC_2_6_6_SystemObject bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_6_6_SystemObject bevt_63_ta_ph = null;
BEC_2_6_6_SystemObject bevt_64_ta_ph = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_ta_ph = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_ta_ph.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool)/* Line: 608*/ {
if (bevp_printSteps.bevi_bool)/* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 609*/ {
if (bevp_printPlaces.bevi_bool)/* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 609*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 609*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 609*/ {
bevt_4_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_5_ta_ph = beva_toParse.bemd_0(-1275325619);
bevt_3_ta_ph = bevt_4_ta_ph.bem_add_1(bevt_5_ta_ph);
bevt_3_ta_ph.bem_print_0();
} /* Line: 610*/
bevp_fromFile = beva_toParse;
bevt_8_ta_ph = beva_toParse.bemd_0(2124815106);
bevt_7_ta_ph = bevt_8_ta_ph.bemd_0(663571840);
bevt_6_ta_ph = bevt_7_ta_ph.bemd_0(353438806);
bevl_src = bevt_6_ta_ph.bemd_1(1856501662, bevp_readBuffer);
bevt_10_ta_ph = beva_toParse.bemd_0(2124815106);
bevt_9_ta_ph = bevt_10_ta_ph.bemd_0(663571840);
bevt_9_ta_ph.bemd_0(1986846950);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool)/* Line: 621*/ {
bevt_11_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_11_ta_ph.bem_echo_0();
} /* Line: 622*/
bevt_12_ta_ph = bevl_trans.bemd_0(2113945966);
bem_nodify_2(bevt_12_ta_ph, bevl_toks);
if (bevp_printAllAst.bevi_bool)/* Line: 625*/ {
bevt_13_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_13_ta_ph.bem_print_0();
bevt_14_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_14_ta_ph);
} /* Line: 627*/
if (bevp_printSteps.bevi_bool)/* Line: 630*/ {
bevt_15_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_15_ta_ph.bem_echo_0();
} /* Line: 631*/
bevt_16_ta_ph = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(45258098, bevt_16_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 634*/ {
bevt_17_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_17_ta_ph.bem_print_0();
bevt_18_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_18_ta_ph);
} /* Line: 636*/
if (bevp_printSteps.bevi_bool)/* Line: 638*/ {
bevt_19_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_19_ta_ph.bem_echo_0();
} /* Line: 639*/
bevt_20_ta_ph = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(45258098, bevt_20_ta_ph);
bevl_trans.bemd_0(-1490383586);
if (bevp_printAllAst.bevi_bool)/* Line: 644*/ {
bevt_21_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_21_ta_ph.bem_print_0();
bevt_22_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_22_ta_ph);
} /* Line: 646*/
if (bevp_printSteps.bevi_bool)/* Line: 649*/ {
bevt_23_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_23_ta_ph.bem_echo_0();
} /* Line: 650*/
bevt_24_ta_ph = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(45258098, bevt_24_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 653*/ {
bevt_25_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_25_ta_ph.bem_print_0();
bevt_26_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_26_ta_ph);
} /* Line: 655*/
if (bevp_printSteps.bevi_bool)/* Line: 658*/ {
bevt_27_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_27_ta_ph.bem_echo_0();
} /* Line: 659*/
bevt_28_ta_ph = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(45258098, bevt_28_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 662*/ {
bevt_29_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_29_ta_ph.bem_print_0();
bevt_30_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_30_ta_ph);
} /* Line: 664*/
if (bevp_printSteps.bevi_bool)/* Line: 667*/ {
bevt_31_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_31_ta_ph.bem_echo_0();
} /* Line: 668*/
bevt_32_ta_ph = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(45258098, bevt_32_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 671*/ {
bevt_33_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_33_ta_ph.bem_print_0();
bevt_34_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_34_ta_ph);
} /* Line: 673*/
if (bevp_printSteps.bevi_bool)/* Line: 676*/ {
bevt_35_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_35_ta_ph.bem_echo_0();
} /* Line: 677*/
bevt_36_ta_ph = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(45258098, bevt_36_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 680*/ {
bevt_37_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_37_ta_ph.bem_print_0();
bevt_38_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_38_ta_ph);
} /* Line: 682*/
if (bevp_printSteps.bevi_bool)/* Line: 685*/ {
bevt_39_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_39_ta_ph.bem_echo_0();
} /* Line: 686*/
bevt_40_ta_ph = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(45258098, bevt_40_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 689*/ {
bevt_41_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_41_ta_ph.bem_print_0();
bevt_42_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_42_ta_ph);
} /* Line: 691*/
if (bevp_printSteps.bevi_bool)/* Line: 694*/ {
bevt_43_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_43_ta_ph.bem_echo_0();
} /* Line: 695*/
bevt_44_ta_ph = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(45258098, bevt_44_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 698*/ {
bevt_45_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_45_ta_ph.bem_print_0();
bevt_46_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_46_ta_ph);
} /* Line: 700*/
if (bevp_printSteps.bevi_bool)/* Line: 703*/ {
bevt_47_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_47_ta_ph.bem_echo_0();
} /* Line: 704*/
bevt_48_ta_ph = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(45258098, bevt_48_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 707*/ {
bevt_49_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_49_ta_ph.bem_print_0();
bevt_50_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_50_ta_ph);
} /* Line: 709*/
if (bevp_printSteps.bevi_bool)/* Line: 711*/ {
bevt_51_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_51_ta_ph.bem_echo_0();
} /* Line: 712*/
bevt_52_ta_ph = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(45258098, bevt_52_ta_ph);
if (bevp_printAllAst.bevi_bool)/* Line: 715*/ {
bevt_53_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_53_ta_ph.bem_print_0();
bevt_54_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_54_ta_ph);
} /* Line: 717*/
if (bevp_printSteps.bevi_bool)/* Line: 720*/ {
bevt_55_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_55_ta_ph.bem_echo_0();
bevt_56_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_56_ta_ph.bem_print_0();
} /* Line: 722*/
bevt_57_ta_ph = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(45258098, bevt_57_ta_ph);
if (bevp_printAst.bevi_bool)/* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 725*/ {
if (bevp_printAllAst.bevi_bool)/* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 725*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 725*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 725*/ {
bevt_58_ta_ph = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_58_ta_ph.bem_print_0();
bevt_59_ta_ph = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(45258098, bevt_59_ta_ph);
} /* Line: 727*/
bevt_60_ta_ph = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_ta_ph.bem_valueIteratorGet_0();
while (true)
/* Line: 729*/ {
bevt_61_ta_ph = bevl_ci.bemd_0(-508298247);
if (((BEC_2_5_4_LogicBool) bevt_61_ta_ph).bevi_bool)/* Line: 729*/ {
bevl_clnode = bevl_ci.bemd_0(450495808);
bevl_tunode = bevl_clnode.bemd_0(26993237);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_ta_ph = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(1131135900, bevt_62_ta_ph);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_ta_ph = bevl_tunode.bemd_0(1875047920);
bevt_63_ta_ph = bevt_64_ta_ph.bemd_0(448580679);
bevl_ntt.bemd_1(-779059288, bevt_63_ta_ph);
bevl_ntunode.bemd_1(-504866291, bevl_ntt);
bevl_clnode.bemd_0(650640643);
bevl_ntunode.bemd_1(-1090877039, bevl_clnode);
bevl_ntunode.bemd_1(266208627, bevl_clnode);
} /* Line: 740*/
 else /* Line: 729*/ {
break;
} /* Line: 729*/
} /* Line: 729*/
} /* Line: 729*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
beva_parnode.bemd_0(1855533583);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(1802316534);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_ta_ph.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
/* Line: 750*/ {
bevt_1_ta_ph = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 750*/ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_ta_ph = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(-504866291, bevt_2_ta_ph);
bevl_node.bemd_1(-546856513, bevl_nlc);
bevt_4_ta_ph = bevl_node.bemd_0(1875047920);
bevt_3_ta_ph = bevt_4_ta_ph.bemd_1(1311824436, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 754*/ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 755*/
bevt_6_ta_ph = bevl_node.bemd_0(1875047920);
bevt_5_ta_ph = bevt_6_ta_ph.bemd_1(-2081456376, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_ta_ph).bevi_bool)/* Line: 757*/ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(771424106, beva_parnode);
} /* Line: 759*/
} /* Line: 757*/
 else /* Line: 750*/ {
break;
} /* Line: 750*/
} /* Line: 750*/
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_4_6_TextString bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_4_6_TextString bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_6_6_SystemObject bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_6_6_SystemObject bevt_21_ta_ph = null;
BEC_2_6_6_SystemObject bevt_22_ta_ph = null;
BEC_2_4_3_MathInt bevt_23_ta_ph = null;
BEC_2_5_4_LogicBool bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_6_6_SystemObject bevt_26_ta_ph = null;
BEC_2_4_3_MathInt bevt_27_ta_ph = null;
BEC_2_6_6_SystemObject bevt_28_ta_ph = null;
BEC_2_6_6_SystemObject bevt_29_ta_ph = null;
BEC_2_4_3_MathInt bevt_30_ta_ph = null;
BEC_2_6_6_SystemObject bevt_31_ta_ph = null;
BEC_2_6_6_SystemObject bevt_32_ta_ph = null;
BEC_2_4_3_MathInt bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_6_6_SystemObject bevt_35_ta_ph = null;
BEC_2_4_3_MathInt bevt_36_ta_ph = null;
BEC_2_6_6_SystemObject bevt_37_ta_ph = null;
BEC_2_6_6_SystemObject bevt_38_ta_ph = null;
BEC_2_6_6_SystemObject bevt_39_ta_ph = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(902067997, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_ta_ph = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(1131135900, bevt_5_ta_ph);
bevl_nlnpn.bemd_1(-504866291, bevl_nlnp);
bevl_nlnpn.bemd_1(266208627, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_1));
bevl_nlc.bemd_1(-2139877418, bevt_6_ta_ph);
bevt_7_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(639440828, bevt_7_ta_ph);
bevt_8_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(1412337774, bevt_8_ta_ph);
bevt_9_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-1662088656, bevt_9_ta_ph);
bevt_10_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1375326744, bevt_10_ta_ph);
bevt_11_ta_ph = beva_node.bemd_0(1875047920);
bevl_nlc.bemd_1(1456732935, bevt_11_ta_ph);
beva_node.bemd_1(-1090877039, bevl_nlnpn);
bevt_12_ta_ph = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(1131135900, bevt_12_ta_ph);
beva_node.bemd_1(-504866291, bevl_nlc);
bevl_nlnpn.bemd_0(-1093531287);
bevt_14_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_105));
bevt_13_ta_ph = beva_tName.bemd_1(1311824436, bevt_14_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_13_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_16_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_106));
bevt_15_ta_ph = beva_tName.bemd_1(1311824436, bevt_16_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 789*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 789*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 789*/ {
bevl_pn = beva_node.bemd_0(-873485523);
if (bevl_pn == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 791*/ {
bevt_19_ta_ph = bevl_pn.bemd_0(1518882614);
bevt_20_ta_ph = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_ta_ph = bevt_19_ta_ph.bemd_1(1311824436, bevt_20_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_18_ta_ph).bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_22_ta_ph = bevl_pn.bemd_0(1518882614);
bevt_23_ta_ph = bevp_ntypes.bem_ADDGet_0();
bevt_21_ta_ph = bevt_22_ta_ph.bemd_1(1311824436, bevt_23_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_21_ta_ph).bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 791*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 791*/
 else /* Line: 791*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 791*/ {
bevl_pn2 = bevl_pn.bemd_0(-873485523);
if (bevl_pn2 == null) {
bevt_24_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_24_ta_ph.bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_26_ta_ph = bevl_pn2.bemd_0(1518882614);
bevt_27_ta_ph = bevp_ntypes.bem_CALLGet_0();
bevt_25_ta_ph = bevt_26_ta_ph.bemd_1(-2081456376, bevt_27_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_25_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_29_ta_ph = bevl_pn2.bemd_0(1518882614);
bevt_30_ta_ph = bevp_ntypes.bem_IDGet_0();
bevt_28_ta_ph = bevt_29_ta_ph.bemd_1(-2081456376, bevt_30_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_28_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_32_ta_ph = bevl_pn2.bemd_0(1518882614);
bevt_33_ta_ph = bevp_ntypes.bem_VARGet_0();
bevt_31_ta_ph = bevt_32_ta_ph.bemd_1(-2081456376, bevt_33_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_31_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_35_ta_ph = bevl_pn2.bemd_0(1518882614);
bevt_36_ta_ph = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_ta_ph = bevt_35_ta_ph.bemd_1(-2081456376, bevt_36_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 793*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 793*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 793*/ {
bevt_38_ta_ph = bevl_pn.bemd_0(1875047920);
bevt_39_ta_ph = bevl_nlc.bemd_0(754700345);
bevt_37_ta_ph = bevt_38_ta_ph.bemd_1(-1744665665, bevt_39_ta_ph);
bevl_nlc.bemd_1(1456732935, bevt_37_ta_ph);
bevl_pn.bemd_0(650640643);
} /* Line: 800*/
} /* Line: 793*/
} /* Line: 791*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGetDirect_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFileHeader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFileHeader = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_fromFile = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_platform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_platform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputPlatform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputPlatform = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLibrary = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLibrary = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedLibrarysStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedLibrarysStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_closeLibrariesStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_closeLibrariesStr = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_runArgs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_runArgs = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGetDirect_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGetDirect_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_includePath = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_includePath = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGetDirect_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGetDirect_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGetDirect_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGetDirect_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGetDirect_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_code = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_code = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGetDirect_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sharedEmitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sharedEmitter = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGetDirect_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGetDirect_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGet_0() {
return bevp_emitChecks;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGetDirect_0() {
return bevp_emitChecks;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGetDirect_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGetDirect_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doMainGet_0() {
return bevp_doMain;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doMainGetDirect_0() {
return bevp_doMain;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doMainSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_doMain = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doMainSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_doMain = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGetDirect_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadIdsGet_0() {
return bevp_loadIds;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadIdsGetDirect_0() {
return bevp_loadIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadIdsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_loadIds = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_loadIds = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 81, 88, 89, 90, 91, 92, 93, 93, 101, 101, 101, 101, 0, 101, 101, 0, 0, 0, 0, 0, 102, 102, 104, 104, 108, 108, 108, 108, 112, 112, 113, 113, 113, 117, 118, 119, 119, 119, 119, 119, 120, 120, 120, 121, 120, 123, 127, 128, 130, 131, 132, 133, 135, 136, 137, 137, 138, 0, 0, 0, 141, 143, 147, 147, 147, 149, 154, 156, 157, 157, 157, 158, 158, 0, 158, 158, 159, 159, 159, 160, 161, 161, 166, 166, 166, 166, 167, 169, 169, 169, 170, 170, 171, 171, 171, 173, 175, 175, 175, 175, 175, 175, 176, 177, 177, 178, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 183, 183, 183, 184, 184, 184, 184, 184, 185, 185, 186, 186, 187, 187, 189, 189, 189, 190, 190, 190, 191, 191, 192, 192, 193, 195, 195, 196, 196, 197, 199, 199, 200, 200, 201, 203, 203, 204, 204, 205, 207, 207, 208, 208, 209, 211, 211, 212, 212, 213, 215, 215, 216, 216, 217, 219, 219, 220, 220, 221, 223, 223, 224, 224, 225, 227, 227, 228, 228, 229, 231, 231, 232, 232, 233, 235, 237, 237, 237, 238, 238, 238, 239, 239, 240, 240, 241, 242, 242, 243, 243, 243, 243, 243, 0, 0, 0, 244, 0, 244, 244, 245, 248, 248, 249, 249, 250, 250, 251, 251, 252, 252, 252, 253, 253, 254, 254, 255, 256, 256, 257, 0, 257, 257, 259, 262, 262, 262, 262, 263, 263, 263, 263, 264, 264, 264, 264, 264, 265, 266, 267, 268, 269, 272, 272, 273, 275, 282, 282, 282, 282, 282, 283, 283, 284, 284, 287, 287, 287, 288, 288, 289, 289, 292, 293, 293, 0, 293, 293, 294, 294, 296, 297, 298, 300, 301, 301, 301, 301, 302, 302, 304, 304, 305, 305, 306, 306, 307, 313, 314, 314, 314, 314, 314, 315, 315, 315, 315, 315, 316, 320, 321, 321, 321, 322, 323, 323, 323, 323, 324, 324, 324, 324, 325, 325, 325, 325, 325, 326, 326, 327, 0, 327, 327, 328, 331, 331, 331, 331, 331, 332, 332, 333, 0, 333, 333, 334, 339, 339, 339, 340, 341, 341, 341, 341, 341, 341, 348, 348, 352, 352, 353, 358, 358, 359, 360, 360, 361, 362, 362, 363, 364, 364, 365, 366, 366, 367, 371, 371, 371, 373, 375, 379, 381, 381, 381, 382, 382, 383, 383, 383, 384, 384, 385, 386, 386, 387, 387, 387, 388, 388, 388, 394, 394, 395, 396, 396, 397, 0, 397, 397, 398, 401, 402, 402, 403, 404, 406, 406, 406, 409, 411, 0, 411, 411, 412, 412, 412, 413, 414, 415, 418, 0, 418, 418, 419, 419, 419, 420, 421, 422, 423, 423, 428, 429, 429, 430, 432, 432, 433, 433, 434, 437, 440, 440, 440, 443, 443, 443, 445, 445, 446, 446, 447, 447, 447, 448, 448, 448, 449, 449, 449, 450, 450, 450, 451, 451, 451, 452, 452, 455, 456, 458, 458, 458, 459, 460, 462, 463, 464, 464, 464, 465, 466, 470, 470, 470, 471, 471, 472, 472, 472, 474, 474, 474, 477, 481, 481, 482, 483, 485, 0, 485, 485, 486, 486, 487, 487, 488, 488, 488, 489, 489, 490, 490, 492, 492, 492, 493, 493, 493, 497, 498, 500, 500, 0, 0, 0, 501, 501, 502, 502, 502, 502, 502, 502, 502, 502, 504, 504, 505, 505, 507, 507, 507, 508, 508, 508, 513, 513, 513, 515, 515, 516, 516, 516, 518, 518, 519, 519, 519, 521, 521, 522, 522, 522, 526, 526, 527, 528, 528, 528, 528, 528, 529, 531, 531, 535, 535, 535, 536, 537, 537, 538, 539, 541, 541, 541, 542, 543, 543, 544, 545, 547, 547, 551, 551, 551, 551, 552, 552, 552, 554, 554, 555, 555, 555, 555, 556, 558, 558, 558, 558, 558, 560, 560, 561, 561, 562, 566, 566, 566, 568, 570, 570, 571, 571, 571, 571, 572, 576, 577, 577, 578, 578, 579, 585, 585, 586, 587, 594, 594, 595, 597, 602, 603, 604, 605, 606, 607, 607, 0, 0, 0, 610, 610, 610, 610, 612, 614, 614, 614, 614, 615, 615, 615, 618, 622, 622, 624, 624, 626, 626, 627, 627, 631, 631, 633, 633, 635, 635, 636, 636, 639, 639, 642, 642, 643, 645, 645, 646, 646, 650, 650, 652, 652, 654, 654, 655, 655, 659, 659, 661, 661, 663, 663, 664, 664, 668, 668, 670, 670, 672, 672, 673, 673, 677, 677, 679, 679, 681, 681, 682, 682, 686, 686, 688, 688, 690, 690, 691, 691, 695, 695, 697, 697, 699, 699, 700, 700, 704, 704, 706, 706, 708, 708, 709, 709, 712, 712, 714, 714, 716, 716, 717, 717, 721, 721, 722, 722, 724, 724, 0, 0, 0, 726, 726, 727, 727, 729, 729, 729, 730, 732, 733, 734, 734, 735, 736, 736, 736, 737, 738, 739, 740, 746, 747, 748, 749, 749, 750, 750, 751, 752, 752, 753, 754, 754, 755, 757, 757, 758, 759, 766, 767, 769, 770, 770, 771, 772, 774, 775, 775, 776, 776, 777, 777, 778, 778, 779, 779, 780, 780, 782, 784, 784, 785, 787, 789, 789, 0, 789, 789, 0, 0, 790, 791, 791, 791, 791, 791, 0, 791, 791, 791, 0, 0, 0, 0, 0, 792, 793, 793, 0, 793, 793, 793, 793, 793, 793, 0, 0, 0, 793, 793, 793, 0, 0, 0, 793, 793, 793, 0, 0, 0, 0, 0, 799, 799, 799, 799, 800, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 290, 295, 296, 297, 299, 302, 303, 305, 308, 312, 315, 319, 322, 323, 325, 326, 332, 333, 334, 335, 342, 343, 344, 345, 346, 358, 359, 360, 361, 362, 363, 364, 365, 368, 373, 374, 375, 381, 389, 390, 392, 393, 394, 395, 399, 400, 401, 402, 403, 406, 410, 413, 417, 419, 425, 426, 427, 430, 582, 583, 584, 585, 590, 591, 592, 592, 595, 597, 598, 599, 604, 605, 606, 607, 615, 616, 617, 618, 620, 622, 623, 624, 625, 626, 628, 629, 630, 633, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 700, 701, 703, 704, 705, 710, 711, 713, 714, 715, 720, 721, 723, 724, 725, 730, 731, 733, 734, 735, 740, 741, 743, 744, 745, 750, 751, 753, 754, 755, 760, 761, 763, 764, 765, 770, 771, 773, 774, 775, 780, 781, 783, 784, 785, 790, 791, 793, 794, 795, 800, 801, 804, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 824, 825, 826, 831, 832, 835, 839, 842, 842, 845, 847, 848, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 876, 877, 877, 880, 882, 883, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 913, 914, 917, 919, 920, 921, 922, 923, 924, 929, 930, 931, 933, 934, 935, 936, 941, 942, 943, 945, 946, 947, 947, 950, 952, 953, 954, 960, 961, 962, 963, 964, 965, 966, 971, 972, 973, 975, 980, 981, 982, 983, 984, 985, 999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1050, 1051, 1052, 1055, 1057, 1058, 1059, 1060, 1061, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1077, 1078, 1078, 1081, 1083, 1084, 1091, 1092, 1093, 1094, 1095, 1096, 1101, 1102, 1102, 1105, 1107, 1108, 1121, 1122, 1125, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1143, 1144, 1160, 1165, 1166, 1168, 1173, 1174, 1175, 1176, 1178, 1181, 1182, 1184, 1187, 1188, 1190, 1193, 1194, 1196, 1199, 1200, 1201, 1206, 1208, 1227, 1228, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1244, 1245, 1246, 1367, 1368, 1369, 1370, 1375, 1376, 1376, 1379, 1381, 1382, 1389, 1390, 1395, 1396, 1397, 1399, 1400, 1401, 1404, 1405, 1405, 1408, 1410, 1411, 1412, 1417, 1418, 1419, 1420, 1427, 1427, 1430, 1432, 1433, 1434, 1439, 1440, 1441, 1442, 1443, 1444, 1452, 1453, 1456, 1458, 1459, 1460, 1462, 1463, 1464, 1471, 1473, 1474, 1475, 1476, 1477, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1502, 1503, 1506, 1507, 1508, 1509, 1512, 1514, 1515, 1521, 1522, 1523, 1524, 1527, 1529, 1530, 1537, 1538, 1539, 1540, 1545, 1546, 1547, 1548, 1550, 1551, 1552, 1554, 1557, 1562, 1563, 1564, 1566, 1566, 1569, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1582, 1583, 1585, 1586, 1587, 1589, 1590, 1591, 1599, 1600, 1603, 1605, 1607, 1610, 1614, 1617, 1618, 1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1630, 1631, 1633, 1634, 1635, 1637, 1638, 1639, 1648, 1649, 1650, 1651, 1656, 1657, 1658, 1659, 1661, 1666, 1667, 1668, 1669, 1671, 1676, 1677, 1678, 1679, 1682, 1683, 1684, 1685, 1686, 1687, 1688, 1689, 1690, 1692, 1693, 1706, 1707, 1710, 1712, 1713, 1714, 1715, 1716, 1722, 1723, 1726, 1728, 1729, 1730, 1731, 1732, 1738, 1739, 1767, 1768, 1769, 1774, 1775, 1776, 1777, 1779, 1780, 1781, 1782, 1783, 1788, 1789, 1792, 1793, 1794, 1795, 1796, 1797, 1802, 1803, 1804, 1805, 1808, 1809, 1810, 1812, 1814, 1815, 1816, 1817, 1818, 1819, 1820, 1828, 1829, 1830, 1831, 1836, 1837, 1839, 1840, 1841, 1842, 1846, 1851, 1852, 1854, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1942, 1946, 1949, 1953, 1954, 1955, 1956, 1958, 1959, 1960, 1961, 1962, 1963, 1964, 1965, 1966, 1968, 1969, 1971, 1972, 1974, 1975, 1976, 1977, 1980, 1981, 1983, 1984, 1986, 1987, 1988, 1989, 1992, 1993, 1995, 1996, 1997, 1999, 2000, 2001, 2002, 2005, 2006, 2008, 2009, 2011, 2012, 2013, 2014, 2017, 2018, 2020, 2021, 2023, 2024, 2025, 2026, 2029, 2030, 2032, 2033, 2035, 2036, 2037, 2038, 2041, 2042, 2044, 2045, 2047, 2048, 2049, 2050, 2053, 2054, 2056, 2057, 2059, 2060, 2061, 2062, 2065, 2066, 2068, 2069, 2071, 2072, 2073, 2074, 2077, 2078, 2080, 2081, 2083, 2084, 2085, 2086, 2089, 2090, 2092, 2093, 2095, 2096, 2097, 2098, 2101, 2102, 2103, 2104, 2106, 2107, 2109, 2113, 2116, 2120, 2121, 2122, 2123, 2125, 2126, 2129, 2131, 2132, 2133, 2134, 2135, 2136, 2137, 2138, 2139, 2140, 2141, 2142, 2143, 2165, 2166, 2167, 2168, 2169, 2170, 2173, 2175, 2176, 2177, 2178, 2179, 2180, 2182, 2184, 2185, 2187, 2188, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2252, 2253, 2254, 2255, 2256, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268, 2269, 2271, 2274, 2275, 2277, 2280, 2284, 2285, 2290, 2291, 2292, 2293, 2295, 2298, 2299, 2300, 2302, 2305, 2309, 2312, 2316, 2319, 2320, 2325, 2326, 2329, 2330, 2331, 2333, 2334, 2335, 2337, 2340, 2344, 2347, 2348, 2349, 2351, 2354, 2358, 2361, 2362, 2363, 2365, 2368, 2372, 2375, 2378, 2382, 2383, 2384, 2385, 2386, 2393, 2396, 2399, 2403, 2407, 2410, 2413, 2417, 2421, 2424, 2427, 2431, 2435, 2438, 2441, 2445, 2449, 2452, 2455, 2459, 2463, 2466, 2469, 2473, 2477, 2480, 2483, 2487, 2491, 2494, 2497, 2501, 2505, 2508, 2511, 2515, 2519, 2522, 2525, 2529, 2533, 2536, 2539, 2543, 2547, 2550, 2553, 2557, 2561, 2564, 2567, 2571, 2575, 2578, 2581, 2585, 2589, 2592, 2595, 2599, 2603, 2606, 2609, 2613, 2617, 2620, 2623, 2627, 2631, 2634, 2637, 2641, 2645, 2648, 2651, 2655, 2659, 2662, 2665, 2669, 2673, 2676, 2679, 2683, 2687, 2690, 2693, 2697, 2701, 2704, 2707, 2711, 2715, 2718, 2721, 2725, 2729, 2732, 2735, 2739, 2743, 2746, 2749, 2753, 2757, 2760, 2763, 2767, 2771, 2774, 2777, 2781, 2785, 2788, 2791, 2795, 2799, 2802, 2805, 2809, 2813, 2816, 2819, 2823, 2827, 2830, 2833, 2837, 2841, 2844, 2847, 2851, 2855, 2858, 2861, 2865, 2869, 2872, 2875, 2879, 2883, 2886, 2889, 2893, 2897, 2900, 2903, 2907, 2911, 2914, 2917, 2921, 2925, 2928, 2931, 2935, 2939, 2942, 2945, 2949, 2953, 2956, 2959, 2963, 2967, 2970, 2973, 2977, 2981, 2984, 2987, 2991, 2995, 2998, 3001, 3005, 3009, 3012, 3015, 3019, 3023, 3026, 3029, 3033, 3037, 3040, 3043, 3047, 3051, 3054, 3057, 3061, 3065, 3068, 3071, 3075, 3079, 3082, 3085, 3089, 3093, 3096, 3099, 3103, 3107, 3110, 3113, 3117, 3121, 3124, 3127, 3131, 3135, 3138, 3141, 3145, 3149, 3152, 3155, 3159, 3163, 3166, 3169, 3173, 3177, 3180, 3183, 3187, 3191, 3194, 3197, 3201, 3205, 3208, 3211, 3215, 3219, 3222, 3225, 3229, 3233, 3236, 3239, 3243, 3247, 3250, 3253, 3257, 3261, 3264, 3267, 3271, 3275, 3278, 3281, 3285, 3289, 3292, 3295, 3299, 3303, 3306, 3309, 3313, 3317, 3320, 3323, 3327, 3331, 3334, 3337, 3341, 3345, 3348, 3351, 3355, 3359, 3362, 3365, 3369, 3373, 3376, 3379, 3383, 3387, 3390, 3393, 3397, 3401, 3404, 3407, 3411, 3415, 3418, 3421, 3425, 3429, 3432, 3435, 3439, 3443, 3446, 3450};
/* BEGIN LINEINFO 
assign 1 51 250
new 0 51 250
assign 1 53 251
new 0 53 251
assign 1 54 252
new 0 54 252
assign 1 55 253
new 0 55 253
assign 1 56 254
new 0 56 254
assign 1 58 255
new 0 58 255
assign 1 59 256
new 0 59 256
assign 1 60 257
new 0 60 257
assign 1 61 258
new 0 61 258
assign 1 62 259
new 0 62 259
assign 1 63 260
new 0 63 260
assign 1 64 261
new 0 64 261
assign 1 68 262
new 0 68 262
assign 1 70 263
new 1 70 263
assign 1 71 264
ntypesGet 0 71 264
assign 1 72 265
twtokGet 0 72 265
assign 1 73 266
new 0 73 266
assign 1 73 267
new 1 73 267
assign 1 76 268
new 0 76 268
assign 1 79 269
new 0 79 269
assign 1 80 270
new 0 80 270
assign 1 81 271
new 0 81 271
assign 1 88 272
new 0 88 272
assign 1 89 273
new 0 89 273
assign 1 90 274
new 0 90 274
assign 1 91 275
new 0 91 275
assign 1 92 276
new 0 92 276
assign 1 93 277
new 0 93 277
assign 1 93 278
new 1 93 278
assign 1 101 290
def 1 101 295
assign 1 101 296
new 0 101 296
assign 1 101 297
equals 1 101 297
assign 1 0 299
assign 1 101 302
new 0 101 302
assign 1 101 303
ends 1 101 303
assign 1 0 305
assign 1 0 308
assign 1 0 312
assign 1 0 315
assign 1 0 319
assign 1 102 322
new 0 102 322
return 1 102 323
assign 1 104 325
new 0 104 325
return 1 104 326
assign 1 108 332
new 0 108 332
assign 1 108 333
new 0 108 333
assign 1 108 334
swap 2 108 334
return 1 108 335
assign 1 112 342
new 0 112 342
assign 1 112 343
argsGet 0 112 343
assign 1 113 344
new 0 113 344
assign 1 113 345
main 1 113 345
exit 1 113 346
assign 1 117 358
assign 1 118 359
new 1 118 359
assign 1 119 360
new 0 119 360
assign 1 119 361
new 0 119 361
assign 1 119 362
get 2 119 362
assign 1 119 363
firstGet 0 119 363
assign 1 119 364
new 1 119 364
assign 1 120 365
new 0 120 365
assign 1 120 368
lesser 1 120 373
assign 1 121 374
go 0 121 374
incrementValue 0 120 375
return 1 123 381
assign 1 127 389
new 0 127 389
assign 1 128 390
new 0 128 390
config 0 130 392
assign 1 131 393
new 0 131 393
assign 1 132 394
doWhat 0 132 394
assign 1 133 395
new 0 133 395
assign 1 135 399
toString 0 135 399
assign 1 136 400
new 0 136 400
assign 1 137 401
new 0 137 401
assign 1 137 402
add 1 137 402
assign 1 138 403
new 0 138 403
assign 1 0 406
assign 1 0 410
assign 1 0 413
print 0 141 417
return 1 143 419
assign 1 147 425
nameGet 0 147 425
assign 1 147 426
new 0 147 426
assign 1 147 427
equals 1 147 427
return 1 149 430
assign 1 154 582
new 0 154 582
assign 1 156 583
new 0 156 583
assign 1 157 584
get 1 157 584
assign 1 157 585
def 1 157 590
assign 1 158 591
get 1 158 591
assign 1 158 592
iteratorGet 0 0 592
assign 1 158 595
hasNextGet 0 158 595
assign 1 158 597
nextGet 0 158 597
assign 1 159 598
has 1 159 598
assign 1 159 599
not 0 159 604
put 1 160 605
assign 1 161 606
new 1 161 606
addFile 1 161 607
assign 1 166 615
new 0 166 615
assign 1 166 616
nameGet 0 166 616
assign 1 166 617
new 0 166 617
assign 1 166 618
equals 1 166 618
preProcessorSet 1 167 620
assign 1 169 622
new 0 169 622
assign 1 169 623
get 1 169 623
assign 1 169 624
firstGet 0 169 624
assign 1 170 625
new 0 170 625
assign 1 170 626
has 1 170 626
assign 1 171 628
new 0 171 628
assign 1 171 629
get 1 171 629
assign 1 171 630
firstGet 0 171 630
assign 1 173 633
assign 1 175 635
new 0 175 635
assign 1 175 636
new 0 175 636
assign 1 175 637
get 2 175 637
assign 1 175 638
firstGet 0 175 638
assign 1 175 639
new 1 175 639
assign 1 175 640
pathGet 0 175 640
addStep 1 176 641
assign 1 177 642
new 0 177 642
addStep 1 177 643
assign 1 178 644
new 0 178 644
assign 1 178 645
new 0 178 645
assign 1 178 646
get 2 178 646
assign 1 178 647
firstGet 0 178 647
assign 1 178 648
new 1 178 648
assign 1 178 649
pathGet 0 178 649
assign 1 179 650
new 0 179 650
assign 1 179 651
new 0 179 651
assign 1 179 652
nameGet 0 179 652
assign 1 179 653
get 2 179 653
assign 1 179 654
firstGet 0 179 654
assign 1 179 655
new 1 179 655
assign 1 180 656
new 0 180 656
assign 1 180 657
nameGet 0 180 657
assign 1 180 658
get 2 180 658
assign 1 180 659
firstGet 0 180 659
assign 1 180 660
new 1 180 660
assign 1 181 661
new 0 181 661
assign 1 181 662
new 0 181 662
assign 1 181 663
get 2 181 663
assign 1 181 664
firstGet 0 181 664
assign 1 181 665
new 1 181 665
assign 1 182 666
new 0 182 666
assign 1 182 667
new 0 182 667
assign 1 182 668
get 2 182 668
assign 1 182 669
firstGet 0 182 669
assign 1 182 670
new 1 182 670
assign 1 183 671
new 0 183 671
assign 1 183 672
new 0 183 672
assign 1 183 673
get 2 183 673
assign 1 183 674
firstGet 0 183 674
assign 1 183 675
new 1 183 675
assign 1 184 676
new 0 184 676
assign 1 184 677
new 0 184 677
assign 1 184 678
get 2 184 678
assign 1 184 679
firstGet 0 184 679
assign 1 184 680
new 1 184 680
assign 1 185 681
new 0 185 681
assign 1 185 682
get 1 185 682
assign 1 186 683
new 0 186 683
assign 1 186 684
get 1 186 684
assign 1 187 685
new 0 187 685
assign 1 187 686
get 1 187 686
assign 1 189 687
new 0 189 687
assign 1 189 688
get 1 189 688
assign 1 189 689
firstGet 0 189 689
assign 1 190 690
new 0 190 690
assign 1 190 691
get 1 190 691
assign 1 190 692
firstGet 0 190 692
assign 1 191 693
new 0 191 693
assign 1 191 694
get 1 191 694
assign 1 192 695
undef 1 192 700
assign 1 193 701
new 0 193 701
assign 1 195 703
new 0 195 703
assign 1 195 704
get 1 195 704
assign 1 196 705
undef 1 196 710
assign 1 197 711
new 0 197 711
assign 1 199 713
new 0 199 713
assign 1 199 714
get 1 199 714
assign 1 200 715
undef 1 200 720
assign 1 201 721
new 0 201 721
assign 1 203 723
new 0 203 723
assign 1 203 724
get 1 203 724
assign 1 204 725
undef 1 204 730
assign 1 205 731
new 0 205 731
assign 1 207 733
new 0 207 733
assign 1 207 734
get 1 207 734
assign 1 208 735
undef 1 208 740
assign 1 209 741
new 0 209 741
assign 1 211 743
new 0 211 743
assign 1 211 744
get 1 211 744
assign 1 212 745
undef 1 212 750
assign 1 213 751
new 0 213 751
assign 1 215 753
new 0 215 753
assign 1 215 754
get 1 215 754
assign 1 216 755
undef 1 216 760
assign 1 217 761
new 0 217 761
assign 1 219 763
new 0 219 763
assign 1 219 764
get 1 219 764
assign 1 220 765
undef 1 220 770
assign 1 221 771
new 0 221 771
assign 1 223 773
new 0 223 773
assign 1 223 774
get 1 223 774
assign 1 224 775
undef 1 224 780
assign 1 225 781
new 0 225 781
assign 1 227 783
new 0 227 783
assign 1 227 784
get 1 227 784
assign 1 228 785
def 1 228 790
assign 1 229 791
firstGet 0 229 791
assign 1 231 793
new 0 231 793
assign 1 231 794
get 1 231 794
assign 1 232 795
def 1 232 800
assign 1 233 801
firstGet 0 233 801
assign 1 235 804
new 0 235 804
assign 1 237 806
new 0 237 806
assign 1 237 807
new 0 237 807
assign 1 237 808
isTrue 2 237 808
assign 1 238 809
new 0 238 809
assign 1 238 810
new 0 238 810
assign 1 238 811
isTrue 2 238 811
assign 1 239 812
new 0 239 812
assign 1 239 813
isTrue 1 239 813
assign 1 240 814
new 0 240 814
assign 1 240 815
isTrue 1 240 815
assign 1 241 816
new 0 241 816
assign 1 242 817
new 0 242 817
assign 1 242 818
get 1 242 818
assign 1 243 819
def 1 243 824
assign 1 243 825
isEmptyGet 0 243 825
assign 1 243 826
not 0 243 831
assign 1 0 832
assign 1 0 835
assign 1 0 839
assign 1 244 842
linkedListIteratorGet 0 0 842
assign 1 244 845
hasNextGet 0 244 845
assign 1 244 847
nextGet 0 244 847
put 1 245 848
assign 1 248 855
new 0 248 855
assign 1 248 856
isTrue 1 248 856
assign 1 249 857
new 0 249 857
assign 1 249 858
isTrue 1 249 858
assign 1 250 859
new 0 250 859
assign 1 250 860
isTrue 1 250 860
assign 1 251 861
new 0 251 861
assign 1 251 862
isTrue 1 251 862
assign 1 252 863
new 0 252 863
assign 1 252 864
new 0 252 864
assign 1 252 865
isTrue 2 252 865
assign 1 253 866
new 0 253 866
assign 1 253 867
get 1 253 867
assign 1 254 868
new 0 254 868
assign 1 254 869
get 1 254 869
assign 1 255 870
new 0 255 870
assign 1 256 871
def 1 256 876
assign 1 257 877
linkedListIteratorGet 0 0 877
assign 1 257 880
hasNextGet 0 257 880
assign 1 257 882
nextGet 0 257 882
addValue 1 259 883
assign 1 262 890
new 0 262 890
assign 1 262 891
new 0 262 891
assign 1 262 892
get 2 262 892
assign 1 262 893
firstGet 0 262 893
assign 1 263 894
new 0 263 894
assign 1 263 895
new 0 263 895
assign 1 263 896
get 2 263 896
assign 1 263 897
firstGet 0 263 897
assign 1 264 898
new 0 264 898
assign 1 264 899
add 1 264 899
assign 1 264 900
new 0 264 900
assign 1 264 901
get 2 264 901
assign 1 264 902
firstGet 0 264 902
assign 1 265 903
new 0 265 903
assign 1 266 904
new 0 266 904
assign 1 267 905
new 0 267 905
assign 1 268 906
new 0 268 906
assign 1 269 907
new 0 269 907
assign 1 272 908
def 1 272 913
assign 1 273 914
firstGet 0 273 914
assign 1 275 917
new 0 275 917
assign 1 282 919
new 0 282 919
assign 1 282 920
add 1 282 920
assign 1 282 921
nameGet 0 282 921
assign 1 282 922
add 1 282 922
assign 1 282 923
get 1 282 923
assign 1 283 924
def 1 283 929
assign 1 284 930
orderedGet 0 284 930
addAll 1 284 931
assign 1 287 933
new 0 287 933
assign 1 287 934
add 1 287 934
assign 1 287 935
get 1 287 935
assign 1 288 936
def 1 288 941
assign 1 289 942
orderedGet 0 289 942
addAll 1 289 943
assign 1 292 945
new 0 292 945
assign 1 293 946
orderedGet 0 293 946
assign 1 293 947
iteratorGet 0 0 947
assign 1 293 950
hasNextGet 0 293 950
assign 1 293 952
nextGet 0 293 952
assign 1 294 953
new 1 294 953
addValue 1 294 954
assign 1 296 960
newlineGet 0 296 960
assign 1 297 961
assign 1 298 962
new 1 298 962
assign 1 300 963
copy 0 300 963
assign 1 301 964
fileGet 0 301 964
assign 1 301 965
existsGet 0 301 965
assign 1 301 966
not 0 301 971
assign 1 302 972
fileGet 0 302 972
makeDirs 0 302 973
assign 1 304 975
def 1 304 980
assign 1 305 981
new 1 305 981
assign 1 305 982
readerGet 0 305 982
assign 1 306 983
open 0 306 983
assign 1 306 984
readString 0 306 984
close 0 307 985
assign 1 313 999
classNameGet 0 313 999
assign 1 314 1000
add 1 314 1000
assign 1 314 1001
new 0 314 1001
assign 1 314 1002
add 1 314 1002
assign 1 314 1003
toString 0 314 1003
assign 1 314 1004
add 1 314 1004
assign 1 315 1005
add 1 315 1005
assign 1 315 1006
new 0 315 1006
assign 1 315 1007
add 1 315 1007
assign 1 315 1008
toString 0 315 1008
assign 1 315 1009
add 1 315 1009
return 1 316 1010
assign 1 320 1050
new 0 320 1050
assign 1 321 1051
classesGet 0 321 1051
assign 1 321 1052
valueIteratorGet 0 321 1052
assign 1 321 1055
hasNextGet 0 321 1055
assign 1 322 1057
nextGet 0 322 1057
assign 1 323 1058
shouldEmitGet 0 323 1058
assign 1 323 1059
heldGet 0 323 1059
assign 1 323 1060
fromFileGet 0 323 1060
assign 1 323 1061
has 1 323 1061
assign 1 324 1063
heldGet 0 324 1063
assign 1 324 1064
namepathGet 0 324 1064
assign 1 324 1065
toString 0 324 1065
put 1 324 1066
assign 1 325 1067
usedByGet 0 325 1067
assign 1 325 1068
heldGet 0 325 1068
assign 1 325 1069
namepathGet 0 325 1069
assign 1 325 1070
toString 0 325 1070
assign 1 325 1071
get 1 325 1071
assign 1 326 1072
def 1 326 1077
assign 1 327 1078
setIteratorGet 0 0 1078
assign 1 327 1081
hasNextGet 0 327 1081
assign 1 327 1083
nextGet 0 327 1083
put 1 328 1084
assign 1 331 1091
subClassesGet 0 331 1091
assign 1 331 1092
heldGet 0 331 1092
assign 1 331 1093
namepathGet 0 331 1093
assign 1 331 1094
toString 0 331 1094
assign 1 331 1095
get 1 331 1095
assign 1 332 1096
def 1 332 1101
assign 1 333 1102
setIteratorGet 0 0 1102
assign 1 333 1105
hasNextGet 0 333 1105
assign 1 333 1107
nextGet 0 333 1107
put 1 334 1108
assign 1 339 1121
classesGet 0 339 1121
assign 1 339 1122
valueIteratorGet 0 339 1122
assign 1 339 1125
hasNextGet 0 339 1125
assign 1 340 1127
nextGet 0 340 1127
assign 1 341 1128
heldGet 0 341 1128
assign 1 341 1129
heldGet 0 341 1129
assign 1 341 1130
namepathGet 0 341 1130
assign 1 341 1131
toString 0 341 1131
assign 1 341 1132
has 1 341 1132
shouldWriteSet 1 341 1133
assign 1 348 1143
new 0 348 1143
return 1 348 1144
assign 1 352 1160
def 1 352 1165
return 1 353 1166
assign 1 358 1168
def 1 358 1173
assign 1 359 1174
firstGet 0 359 1174
assign 1 360 1175
new 0 360 1175
assign 1 360 1176
equals 1 360 1176
assign 1 361 1178
new 1 361 1178
assign 1 362 1181
new 0 362 1181
assign 1 362 1182
equals 1 362 1182
assign 1 363 1184
new 1 363 1184
assign 1 364 1187
new 0 364 1187
assign 1 364 1188
equals 1 364 1188
assign 1 365 1190
new 1 365 1190
assign 1 366 1193
new 0 366 1193
assign 1 366 1194
equals 1 366 1194
assign 1 367 1196
new 1 367 1196
assign 1 371 1199
new 0 371 1199
assign 1 371 1200
new 1 371 1200
throw 1 371 1201
return 1 373 1206
return 1 375 1208
assign 1 379 1227
apNew 1 379 1227
assign 1 381 1228
new 0 381 1228
assign 1 381 1229
add 1 381 1229
print 0 381 1230
assign 1 382 1231
new 0 382 1231
assign 1 382 1232
now 0 382 1232
assign 1 383 1233
fileGet 0 383 1233
assign 1 383 1234
readerGet 0 383 1234
assign 1 383 1235
open 0 383 1235
assign 1 384 1236
new 0 384 1236
assign 1 384 1237
deserialize 1 384 1237
close 0 385 1238
assign 1 386 1239
synClassesGet 0 386 1239
addValue 1 386 1240
assign 1 387 1241
new 0 387 1241
assign 1 387 1242
now 0 387 1242
assign 1 387 1243
subtract 1 387 1243
assign 1 388 1244
new 0 388 1244
assign 1 388 1245
add 1 388 1245
print 0 388 1246
assign 1 394 1367
new 0 394 1367
assign 1 394 1368
now 0 394 1368
assign 1 395 1369
new 0 395 1369
assign 1 396 1370
def 1 396 1375
assign 1 397 1376
linkedListIteratorGet 0 0 1376
assign 1 397 1379
hasNextGet 0 397 1379
assign 1 397 1381
nextGet 0 397 1381
loadSyns 1 398 1382
assign 1 401 1389
emitterGet 0 401 1389
assign 1 402 1390
def 1 402 1395
assign 1 403 1396
new 4 403 1396
put 1 404 1397
assign 1 406 1399
new 0 406 1399
assign 1 406 1400
add 1 406 1400
print 0 406 1401
assign 1 409 1404
new 0 409 1404
assign 1 411 1405
iteratorGet 0 0 1405
assign 1 411 1408
hasNextGet 0 411 1408
assign 1 411 1410
nextGet 0 411 1410
assign 1 412 1411
has 1 412 1411
assign 1 412 1412
not 0 412 1417
put 1 413 1418
assign 1 414 1419
new 2 414 1419
addValue 1 415 1420
assign 1 418 1427
iteratorGet 0 0 1427
assign 1 418 1430
hasNextGet 0 418 1430
assign 1 418 1432
nextGet 0 418 1432
assign 1 419 1433
has 1 419 1433
assign 1 419 1434
not 0 419 1439
put 1 420 1440
assign 1 421 1441
new 2 421 1441
addValue 1 422 1442
assign 1 423 1443
libNameGet 0 423 1443
put 1 423 1444
assign 1 428 1452
new 0 428 1452
assign 1 429 1453
iteratorGet 0 429 1453
assign 1 429 1456
hasNextGet 0 429 1456
assign 1 430 1458
nextGet 0 430 1458
assign 1 432 1459
toString 0 432 1459
assign 1 432 1460
has 1 432 1460
assign 1 433 1462
toString 0 433 1462
put 1 433 1463
doParse 1 434 1464
buildSyns 1 437 1471
assign 1 440 1473
new 0 440 1473
assign 1 440 1474
now 0 440 1474
assign 1 440 1475
subtract 1 440 1475
assign 1 443 1476
emitCommonGet 0 443 1476
assign 1 443 1477
def 1 443 1482
assign 1 445 1483
new 0 445 1483
assign 1 445 1484
now 0 445 1484
assign 1 446 1485
emitCommonGet 0 446 1485
doEmit 0 446 1486
assign 1 447 1487
new 0 447 1487
assign 1 447 1488
now 0 447 1488
assign 1 447 1489
subtract 1 447 1489
assign 1 448 1490
new 0 448 1490
assign 1 448 1491
now 0 448 1491
assign 1 448 1492
subtract 1 448 1492
assign 1 449 1493
new 0 449 1493
assign 1 449 1494
add 1 449 1494
print 0 449 1495
assign 1 450 1496
new 0 450 1496
assign 1 450 1497
add 1 450 1497
print 0 450 1498
assign 1 451 1499
new 0 451 1499
assign 1 451 1500
add 1 451 1500
print 0 451 1501
assign 1 452 1502
new 0 452 1502
return 1 452 1503
setClassesToWrite 0 455 1506
libnameInfoGet 0 456 1507
assign 1 458 1508
classesGet 0 458 1508
assign 1 458 1509
valueIteratorGet 0 458 1509
assign 1 458 1512
hasNextGet 0 458 1512
assign 1 459 1514
nextGet 0 459 1514
doEmit 1 460 1515
emitMain 0 462 1521
emitCUInit 0 463 1522
assign 1 464 1523
classesGet 0 464 1523
assign 1 464 1524
valueIteratorGet 0 464 1524
assign 1 464 1527
hasNextGet 0 464 1527
assign 1 465 1529
nextGet 0 465 1529
emitSyn 1 466 1530
assign 1 470 1537
new 0 470 1537
assign 1 470 1538
now 0 470 1538
assign 1 470 1539
subtract 1 470 1539
assign 1 471 1540
def 1 471 1545
assign 1 472 1546
new 0 472 1546
assign 1 472 1547
add 1 472 1547
print 0 472 1548
assign 1 474 1550
new 0 474 1550
assign 1 474 1551
add 1 474 1551
print 0 474 1552
prepMake 1 477 1554
assign 1 481 1557
not 0 481 1562
make 1 482 1563
deployLibrary 1 483 1564
assign 1 485 1566
linkedListIteratorGet 0 0 1566
assign 1 485 1569
hasNextGet 0 485 1569
assign 1 485 1571
nextGet 0 485 1571
assign 1 486 1572
libnameInfoGet 0 486 1572
assign 1 486 1573
unitShlibGet 0 486 1573
assign 1 487 1574
emitPathGet 0 487 1574
assign 1 487 1575
copy 0 487 1575
assign 1 488 1576
stepsGet 0 488 1576
assign 1 488 1577
lastGet 0 488 1577
addStep 1 488 1578
assign 1 489 1579
fileGet 0 489 1579
assign 1 489 1580
existsGet 0 489 1580
assign 1 490 1582
fileGet 0 490 1582
delete 0 490 1583
assign 1 492 1585
fileGet 0 492 1585
assign 1 492 1586
existsGet 0 492 1586
assign 1 492 1587
not 0 492 1587
assign 1 493 1589
fileGet 0 493 1589
assign 1 493 1590
fileGet 0 493 1590
deployFile 2 493 1591
assign 1 497 1599
iteratorGet 0 497 1599
assign 1 498 1600
iteratorGet 0 498 1600
assign 1 500 1603
hasNextGet 0 500 1603
assign 1 500 1605
hasNextGet 0 500 1605
assign 1 0 1607
assign 1 0 1610
assign 1 0 1614
assign 1 501 1617
nextGet 0 501 1617
assign 1 501 1618
apNew 1 501 1618
assign 1 502 1619
emitPathGet 0 502 1619
assign 1 502 1620
copy 0 502 1620
assign 1 502 1621
toString 0 502 1621
assign 1 502 1622
new 0 502 1622
assign 1 502 1623
add 1 502 1623
assign 1 502 1624
nextGet 0 502 1624
assign 1 502 1625
add 1 502 1625
assign 1 502 1626
apNew 1 502 1626
assign 1 504 1627
fileGet 0 504 1627
assign 1 504 1628
existsGet 0 504 1628
assign 1 505 1630
fileGet 0 505 1630
delete 0 505 1631
assign 1 507 1633
fileGet 0 507 1633
assign 1 507 1634
existsGet 0 507 1634
assign 1 507 1635
not 0 507 1635
assign 1 508 1637
fileGet 0 508 1637
assign 1 508 1638
fileGet 0 508 1638
deployFile 2 508 1639
assign 1 513 1648
new 0 513 1648
assign 1 513 1649
now 0 513 1649
assign 1 513 1650
subtract 1 513 1650
assign 1 515 1651
def 1 515 1656
assign 1 516 1657
new 0 516 1657
assign 1 516 1658
add 1 516 1658
print 0 516 1659
assign 1 518 1661
def 1 518 1666
assign 1 519 1667
new 0 519 1667
assign 1 519 1668
add 1 519 1668
print 0 519 1669
assign 1 521 1671
def 1 521 1676
assign 1 522 1677
new 0 522 1677
assign 1 522 1678
add 1 522 1678
print 0 522 1679
assign 1 526 1682
new 0 526 1682
print 0 526 1683
assign 1 527 1684
run 2 527 1684
assign 1 528 1685
new 0 528 1685
assign 1 528 1686
add 1 528 1686
assign 1 528 1687
new 0 528 1687
assign 1 528 1688
add 1 528 1688
print 0 528 1689
return 1 529 1690
assign 1 531 1692
new 0 531 1692
return 1 531 1693
assign 1 535 1706
justParsedGet 0 535 1706
assign 1 535 1707
valueIteratorGet 0 535 1707
assign 1 535 1710
hasNextGet 0 535 1710
assign 1 536 1712
nextGet 0 536 1712
assign 1 537 1713
heldGet 0 537 1713
libNameSet 1 537 1714
assign 1 538 1715
getSyn 2 538 1715
libNameSet 1 539 1716
assign 1 541 1722
justParsedGet 0 541 1722
assign 1 541 1723
valueIteratorGet 0 541 1723
assign 1 541 1726
hasNextGet 0 541 1726
assign 1 542 1728
nextGet 0 542 1728
assign 1 543 1729
heldGet 0 543 1729
assign 1 543 1730
synGet 0 543 1730
checkInheritance 2 544 1731
integrate 1 545 1732
assign 1 547 1738
new 0 547 1738
justParsedSet 1 547 1739
assign 1 551 1767
heldGet 0 551 1767
assign 1 551 1768
synGet 0 551 1768
assign 1 551 1769
def 1 551 1774
assign 1 552 1775
heldGet 0 552 1775
assign 1 552 1776
synGet 0 552 1776
return 1 552 1777
assign 1 554 1779
heldGet 0 554 1779
libNameSet 1 554 1780
assign 1 555 1781
heldGet 0 555 1781
assign 1 555 1782
extendsGet 0 555 1782
assign 1 555 1783
undef 1 555 1788
assign 1 556 1789
new 1 556 1789
assign 1 558 1792
classesGet 0 558 1792
assign 1 558 1793
heldGet 0 558 1793
assign 1 558 1794
extendsGet 0 558 1794
assign 1 558 1795
toString 0 558 1795
assign 1 558 1796
get 1 558 1796
assign 1 560 1797
def 1 560 1802
assign 1 561 1803
heldGet 0 561 1803
libNameSet 1 561 1804
assign 1 562 1805
getSyn 2 562 1805
assign 1 566 1808
heldGet 0 566 1808
assign 1 566 1809
extendsGet 0 566 1809
assign 1 566 1810
getSynNp 1 566 1810
assign 1 568 1812
new 2 568 1812
assign 1 570 1814
heldGet 0 570 1814
synSet 1 570 1815
assign 1 571 1816
heldGet 0 571 1816
assign 1 571 1817
namepathGet 0 571 1817
assign 1 571 1818
toString 0 571 1818
addSynClass 2 571 1819
return 1 572 1820
assign 1 576 1828
toString 0 576 1828
assign 1 577 1829
synClassesGet 0 577 1829
assign 1 577 1830
get 1 577 1830
assign 1 578 1831
def 1 578 1836
return 1 579 1837
assign 1 585 1839
emitterGet 0 585 1839
assign 1 585 1840
loadSyn 1 585 1840
addSynClass 2 586 1841
return 1 587 1842
assign 1 594 1846
undef 1 594 1851
assign 1 595 1852
new 1 595 1852
return 1 597 1854
assign 1 602 1933
new 1 602 1933
assign 1 603 1934
new 0 603 1934
assign 1 604 1935
emitterGet 0 604 1935
assign 1 605 1936
assign 1 606 1937
new 0 606 1937
assign 1 607 1938
shouldEmitGet 0 607 1938
put 1 607 1939
assign 1 0 1942
assign 1 0 1946
assign 1 0 1949
assign 1 610 1953
new 0 610 1953
assign 1 610 1954
toString 0 610 1954
assign 1 610 1955
add 1 610 1955
print 0 610 1956
assign 1 612 1958
assign 1 614 1959
fileGet 0 614 1959
assign 1 614 1960
readerGet 0 614 1960
assign 1 614 1961
open 0 614 1961
assign 1 614 1962
readBuffer 1 614 1962
assign 1 615 1963
fileGet 0 615 1963
assign 1 615 1964
readerGet 0 615 1964
close 0 615 1965
assign 1 618 1966
tokenize 1 618 1966
assign 1 622 1968
new 0 622 1968
echo 0 622 1969
assign 1 624 1971
outermostGet 0 624 1971
nodify 2 624 1972
assign 1 626 1974
new 0 626 1974
print 0 626 1975
assign 1 627 1976
new 2 627 1976
traverse 1 627 1977
assign 1 631 1980
new 0 631 1980
echo 0 631 1981
assign 1 633 1983
new 0 633 1983
traverse 1 633 1984
assign 1 635 1986
new 0 635 1986
print 0 635 1987
assign 1 636 1988
new 2 636 1988
traverse 1 636 1989
assign 1 639 1992
new 0 639 1992
echo 0 639 1993
assign 1 642 1995
new 0 642 1995
traverse 1 642 1996
contain 0 643 1997
assign 1 645 1999
new 0 645 1999
print 0 645 2000
assign 1 646 2001
new 2 646 2001
traverse 1 646 2002
assign 1 650 2005
new 0 650 2005
echo 0 650 2006
assign 1 652 2008
new 0 652 2008
traverse 1 652 2009
assign 1 654 2011
new 0 654 2011
print 0 654 2012
assign 1 655 2013
new 2 655 2013
traverse 1 655 2014
assign 1 659 2017
new 0 659 2017
echo 0 659 2018
assign 1 661 2020
new 0 661 2020
traverse 1 661 2021
assign 1 663 2023
new 0 663 2023
print 0 663 2024
assign 1 664 2025
new 2 664 2025
traverse 1 664 2026
assign 1 668 2029
new 0 668 2029
echo 0 668 2030
assign 1 670 2032
new 0 670 2032
traverse 1 670 2033
assign 1 672 2035
new 0 672 2035
print 0 672 2036
assign 1 673 2037
new 2 673 2037
traverse 1 673 2038
assign 1 677 2041
new 0 677 2041
echo 0 677 2042
assign 1 679 2044
new 0 679 2044
traverse 1 679 2045
assign 1 681 2047
new 0 681 2047
print 0 681 2048
assign 1 682 2049
new 2 682 2049
traverse 1 682 2050
assign 1 686 2053
new 0 686 2053
echo 0 686 2054
assign 1 688 2056
new 0 688 2056
traverse 1 688 2057
assign 1 690 2059
new 0 690 2059
print 0 690 2060
assign 1 691 2061
new 2 691 2061
traverse 1 691 2062
assign 1 695 2065
new 0 695 2065
echo 0 695 2066
assign 1 697 2068
new 0 697 2068
traverse 1 697 2069
assign 1 699 2071
new 0 699 2071
print 0 699 2072
assign 1 700 2073
new 2 700 2073
traverse 1 700 2074
assign 1 704 2077
new 0 704 2077
echo 0 704 2078
assign 1 706 2080
new 0 706 2080
traverse 1 706 2081
assign 1 708 2083
new 0 708 2083
print 0 708 2084
assign 1 709 2085
new 2 709 2085
traverse 1 709 2086
assign 1 712 2089
new 0 712 2089
echo 0 712 2090
assign 1 714 2092
new 0 714 2092
traverse 1 714 2093
assign 1 716 2095
new 0 716 2095
print 0 716 2096
assign 1 717 2097
new 2 717 2097
traverse 1 717 2098
assign 1 721 2101
new 0 721 2101
echo 0 721 2102
assign 1 722 2103
new 0 722 2103
print 0 722 2104
assign 1 724 2106
new 0 724 2106
traverse 1 724 2107
assign 1 0 2109
assign 1 0 2113
assign 1 0 2116
assign 1 726 2120
new 0 726 2120
print 0 726 2121
assign 1 727 2122
new 2 727 2122
traverse 1 727 2123
assign 1 729 2125
classesGet 0 729 2125
assign 1 729 2126
valueIteratorGet 0 729 2126
assign 1 729 2129
hasNextGet 0 729 2129
assign 1 730 2131
nextGet 0 730 2131
assign 1 732 2132
transUnitGet 0 732 2132
assign 1 733 2133
new 1 733 2133
assign 1 734 2134
TRANSUNITGet 0 734 2134
typenameSet 1 734 2135
assign 1 735 2136
new 0 735 2136
assign 1 736 2137
heldGet 0 736 2137
assign 1 736 2138
emitsGet 0 736 2138
emitsSet 1 736 2139
heldSet 1 737 2140
delete 0 738 2141
addValue 1 739 2142
copyLoc 1 740 2143
reInitContained 0 746 2165
assign 1 747 2166
containedGet 0 747 2166
assign 1 748 2167
new 0 748 2167
assign 1 749 2168
new 0 749 2168
assign 1 749 2169
crGet 0 749 2169
assign 1 750 2170
linkedListIteratorGet 0 750 2170
assign 1 750 2173
hasNextGet 0 750 2173
assign 1 751 2175
new 1 751 2175
assign 1 752 2176
nextGet 0 752 2176
heldSet 1 752 2177
nlcSet 1 753 2178
assign 1 754 2179
heldGet 0 754 2179
assign 1 754 2180
equals 1 754 2180
assign 1 755 2182
increment 0 755 2182
assign 1 757 2184
heldGet 0 757 2184
assign 1 757 2185
notEquals 1 757 2185
addValue 1 758 2187
containerSet 1 759 2188
assign 1 766 2243
new 0 766 2243
fromString 1 767 2244
assign 1 769 2245
new 1 769 2245
assign 1 770 2246
NAMEPATHGet 0 770 2246
typenameSet 1 770 2247
heldSet 1 771 2248
copyLoc 1 772 2249
assign 1 774 2250
new 0 774 2250
assign 1 775 2251
new 0 775 2251
nameSet 1 775 2252
assign 1 776 2253
new 0 776 2253
wasBoundSet 1 776 2254
assign 1 777 2255
new 0 777 2255
boundSet 1 777 2256
assign 1 778 2257
new 0 778 2257
isConstructSet 1 778 2258
assign 1 779 2259
new 0 779 2259
isLiteralSet 1 779 2260
assign 1 780 2261
heldGet 0 780 2261
literalValueSet 1 780 2262
addValue 1 782 2263
assign 1 784 2264
CALLGet 0 784 2264
typenameSet 1 784 2265
heldSet 1 785 2266
resolveNp 0 787 2267
assign 1 789 2268
new 0 789 2268
assign 1 789 2269
equals 1 789 2269
assign 1 0 2271
assign 1 789 2274
new 0 789 2274
assign 1 789 2275
equals 1 789 2275
assign 1 0 2277
assign 1 0 2280
assign 1 790 2284
priorPeerGet 0 790 2284
assign 1 791 2285
def 1 791 2290
assign 1 791 2291
typenameGet 0 791 2291
assign 1 791 2292
SUBTRACTGet 0 791 2292
assign 1 791 2293
equals 1 791 2293
assign 1 0 2295
assign 1 791 2298
typenameGet 0 791 2298
assign 1 791 2299
ADDGet 0 791 2299
assign 1 791 2300
equals 1 791 2300
assign 1 0 2302
assign 1 0 2305
assign 1 0 2309
assign 1 0 2312
assign 1 0 2316
assign 1 792 2319
priorPeerGet 0 792 2319
assign 1 793 2320
undef 1 793 2325
assign 1 0 2326
assign 1 793 2329
typenameGet 0 793 2329
assign 1 793 2330
CALLGet 0 793 2330
assign 1 793 2331
notEquals 1 793 2331
assign 1 793 2333
typenameGet 0 793 2333
assign 1 793 2334
IDGet 0 793 2334
assign 1 793 2335
notEquals 1 793 2335
assign 1 0 2337
assign 1 0 2340
assign 1 0 2344
assign 1 793 2347
typenameGet 0 793 2347
assign 1 793 2348
VARGet 0 793 2348
assign 1 793 2349
notEquals 1 793 2349
assign 1 0 2351
assign 1 0 2354
assign 1 0 2358
assign 1 793 2361
typenameGet 0 793 2361
assign 1 793 2362
ACCESSORGet 0 793 2362
assign 1 793 2363
notEquals 1 793 2363
assign 1 0 2365
assign 1 0 2368
assign 1 0 2372
assign 1 0 2375
assign 1 0 2378
assign 1 799 2382
heldGet 0 799 2382
assign 1 799 2383
literalValueGet 0 799 2383
assign 1 799 2384
add 1 799 2384
literalValueSet 1 799 2385
delete 0 800 2386
return 1 0 2393
return 1 0 2396
assign 1 0 2399
assign 1 0 2403
return 1 0 2407
return 1 0 2410
assign 1 0 2413
assign 1 0 2417
return 1 0 2421
return 1 0 2424
assign 1 0 2427
assign 1 0 2431
return 1 0 2435
return 1 0 2438
assign 1 0 2441
assign 1 0 2445
return 1 0 2449
return 1 0 2452
assign 1 0 2455
assign 1 0 2459
return 1 0 2463
return 1 0 2466
assign 1 0 2469
assign 1 0 2473
return 1 0 2477
return 1 0 2480
assign 1 0 2483
assign 1 0 2487
return 1 0 2491
return 1 0 2494
assign 1 0 2497
assign 1 0 2501
return 1 0 2505
return 1 0 2508
assign 1 0 2511
assign 1 0 2515
return 1 0 2519
return 1 0 2522
assign 1 0 2525
assign 1 0 2529
return 1 0 2533
return 1 0 2536
assign 1 0 2539
assign 1 0 2543
return 1 0 2547
return 1 0 2550
assign 1 0 2553
assign 1 0 2557
return 1 0 2561
return 1 0 2564
assign 1 0 2567
assign 1 0 2571
return 1 0 2575
return 1 0 2578
assign 1 0 2581
assign 1 0 2585
return 1 0 2589
return 1 0 2592
assign 1 0 2595
assign 1 0 2599
return 1 0 2603
return 1 0 2606
assign 1 0 2609
assign 1 0 2613
return 1 0 2617
return 1 0 2620
assign 1 0 2623
assign 1 0 2627
return 1 0 2631
return 1 0 2634
assign 1 0 2637
assign 1 0 2641
return 1 0 2645
return 1 0 2648
assign 1 0 2651
assign 1 0 2655
return 1 0 2659
return 1 0 2662
assign 1 0 2665
assign 1 0 2669
return 1 0 2673
return 1 0 2676
assign 1 0 2679
assign 1 0 2683
return 1 0 2687
return 1 0 2690
assign 1 0 2693
assign 1 0 2697
return 1 0 2701
return 1 0 2704
assign 1 0 2707
assign 1 0 2711
return 1 0 2715
return 1 0 2718
assign 1 0 2721
assign 1 0 2725
return 1 0 2729
return 1 0 2732
assign 1 0 2735
assign 1 0 2739
return 1 0 2743
return 1 0 2746
assign 1 0 2749
assign 1 0 2753
return 1 0 2757
return 1 0 2760
assign 1 0 2763
assign 1 0 2767
return 1 0 2771
return 1 0 2774
assign 1 0 2777
assign 1 0 2781
return 1 0 2785
return 1 0 2788
assign 1 0 2791
assign 1 0 2795
return 1 0 2799
return 1 0 2802
assign 1 0 2805
assign 1 0 2809
return 1 0 2813
return 1 0 2816
assign 1 0 2819
assign 1 0 2823
return 1 0 2827
return 1 0 2830
assign 1 0 2833
assign 1 0 2837
return 1 0 2841
return 1 0 2844
assign 1 0 2847
assign 1 0 2851
return 1 0 2855
return 1 0 2858
assign 1 0 2861
assign 1 0 2865
return 1 0 2869
return 1 0 2872
assign 1 0 2875
assign 1 0 2879
return 1 0 2883
return 1 0 2886
assign 1 0 2889
assign 1 0 2893
return 1 0 2897
return 1 0 2900
assign 1 0 2903
assign 1 0 2907
return 1 0 2911
return 1 0 2914
assign 1 0 2917
assign 1 0 2921
return 1 0 2925
return 1 0 2928
assign 1 0 2931
assign 1 0 2935
return 1 0 2939
return 1 0 2942
assign 1 0 2945
assign 1 0 2949
return 1 0 2953
return 1 0 2956
assign 1 0 2959
assign 1 0 2963
return 1 0 2967
return 1 0 2970
assign 1 0 2973
assign 1 0 2977
return 1 0 2981
return 1 0 2984
assign 1 0 2987
assign 1 0 2991
return 1 0 2995
return 1 0 2998
assign 1 0 3001
assign 1 0 3005
return 1 0 3009
return 1 0 3012
assign 1 0 3015
assign 1 0 3019
return 1 0 3023
return 1 0 3026
assign 1 0 3029
assign 1 0 3033
return 1 0 3037
return 1 0 3040
assign 1 0 3043
assign 1 0 3047
return 1 0 3051
return 1 0 3054
assign 1 0 3057
assign 1 0 3061
return 1 0 3065
return 1 0 3068
assign 1 0 3071
assign 1 0 3075
return 1 0 3079
return 1 0 3082
assign 1 0 3085
assign 1 0 3089
return 1 0 3093
return 1 0 3096
assign 1 0 3099
assign 1 0 3103
return 1 0 3107
return 1 0 3110
assign 1 0 3113
assign 1 0 3117
return 1 0 3121
return 1 0 3124
assign 1 0 3127
assign 1 0 3131
return 1 0 3135
return 1 0 3138
assign 1 0 3141
assign 1 0 3145
return 1 0 3149
return 1 0 3152
assign 1 0 3155
assign 1 0 3159
return 1 0 3163
return 1 0 3166
assign 1 0 3169
assign 1 0 3173
return 1 0 3177
return 1 0 3180
assign 1 0 3183
assign 1 0 3187
return 1 0 3191
return 1 0 3194
assign 1 0 3197
assign 1 0 3201
return 1 0 3205
return 1 0 3208
assign 1 0 3211
assign 1 0 3215
return 1 0 3219
return 1 0 3222
assign 1 0 3225
assign 1 0 3229
return 1 0 3233
return 1 0 3236
assign 1 0 3239
assign 1 0 3243
return 1 0 3247
return 1 0 3250
assign 1 0 3253
assign 1 0 3257
return 1 0 3261
return 1 0 3264
assign 1 0 3267
assign 1 0 3271
return 1 0 3275
return 1 0 3278
assign 1 0 3281
assign 1 0 3285
return 1 0 3289
return 1 0 3292
assign 1 0 3295
assign 1 0 3299
return 1 0 3303
return 1 0 3306
assign 1 0 3309
assign 1 0 3313
return 1 0 3317
return 1 0 3320
assign 1 0 3323
assign 1 0 3327
return 1 0 3331
return 1 0 3334
assign 1 0 3337
assign 1 0 3341
return 1 0 3345
return 1 0 3348
assign 1 0 3351
assign 1 0 3355
return 1 0 3359
return 1 0 3362
assign 1 0 3365
assign 1 0 3369
return 1 0 3373
return 1 0 3376
assign 1 0 3379
assign 1 0 3383
return 1 0 3387
return 1 0 3390
assign 1 0 3393
assign 1 0 3397
return 1 0 3401
return 1 0 3404
assign 1 0 3407
assign 1 0 3411
return 1 0 3415
return 1 0 3418
assign 1 0 3421
assign 1 0 3425
return 1 0 3429
return 1 0 3432
assign 1 0 3435
assign 1 0 3439
return 1 0 3443
assign 1 0 3446
assign 1 0 3450
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1362297290: return bem_nlGetDirect_0();
case 1427687908: return bem_toBuildGet_0();
case 2028463615: return bem_loadIdsGet_0();
case -1094925190: return bem_ccObjArgsGetDirect_0();
case -1951340717: return bem_emitDataGetDirect_0();
case -504915835: return bem_extLinkObjectsGet_0();
case -1101465499: return bem_makeGet_0();
case 564663995: return bem_parseEmitTimeGet_0();
case -1868208490: return bem_readBufferGetDirect_0();
case 1345704315: return bem_serializationIteratorGet_0();
case -1159973728: return bem_estrGet_0();
case -678541085: return bem_classNameGet_0();
case -1806142987: return bem_argsGet_0();
case -639297756: return bem_toAny_0();
case -945227452: return bem_linkLibArgsGet_0();
case -1473446857: return bem_emitLangsGet_0();
case 1022263689: return bem_buildMessageGetDirect_0();
case 1804313297: return bem_emitFileHeaderGet_0();
case 1191085488: return bem_makeNameGetDirect_0();
case 1578679935: return bem_outputPlatformGet_0();
case -1596636743: return bem_constantsGetDirect_0();
case -830571804: return bem_extIncludesGet_0();
case -225870373: return bem_serializeToString_0();
case 1747054380: return bem_sharedEmitterGetDirect_0();
case -1583672278: return bem_echo_0();
case 195243242: return bem_makeArgsGet_0();
case -1475550710: return bem_create_0();
case 240350473: return bem_ownProcessGetDirect_0();
case -500592509: return bem_extIncludesGetDirect_0();
case 1142702911: return bem_runArgsGet_0();
case 427773067: return bem_emitterGet_0();
case -1595472812: return bem_deployFilesToGetDirect_0();
case -2131535931: return bem_printAstGet_0();
case 990967988: return bem_buildPathGetDirect_0();
case -449592155: return bem_startTimeGet_0();
case -1022253086: return bem_fromFileGet_0();
case -420144562: return bem_emitLangsGetDirect_0();
case 442084370: return bem_linkLibArgsGetDirect_0();
case 1722452207: return bem_exeNameGetDirect_0();
case 1528459943: return bem_saveIdsGet_0();
case -2023485577: return bem_ntypesGet_0();
case -570320716: return bem_closeLibrariesStrGet_0();
case -1562122786: return bem_emitLibraryGetDirect_0();
case 888518330: return bem_prepMakeGetDirect_0();
case -193001934: return bem_usedLibrarysGetDirect_0();
case 833592198: return bem_putLineNumbersInTraceGetDirect_0();
case 1396884634: return bem_buildSucceededGet_0();
case 1251581629: return bem_emitDebugGetDirect_0();
case -1782725205: return bem_estrGetDirect_0();
case 1362890581: return bem_fromFileGetDirect_0();
case -1664033859: return bem_prepMakeGet_0();
case -879939360: return bem_newlineGet_0();
case 1717308312: return bem_libNameGet_0();
case -1866476689: return bem_makeArgsGetDirect_0();
case -229407875: return bem_includePathGetDirect_0();
case -1005119995: return bem_many_0();
case -390638300: return bem_makeGetDirect_0();
case 442454505: return bem_deployPathGetDirect_0();
case 1743870490: return bem_twtokGetDirect_0();
case -2068000052: return bem_deserializeClassNameGet_0();
case 563385869: return bem_printAllAstGet_0();
case -1825180832: return bem_emitLibraryGet_0();
case -1522653655: return bem_printAstGetDirect_0();
case 1196171179: return bem_hashGet_0();
case 2098351775: return bem_constantsGet_0();
case -15088989: return bem_emitFlagsGetDirect_0();
case -1646185647: return bem_readBufferGet_0();
case 90899214: return bem_initLibsGet_0();
case 1672798880: return bem_singleCCGet_0();
case -1140087201: return bem_putLineNumbersInTraceGet_0();
case -1281750921: return bem_compilerGet_0();
case -763704989: return bem_compilerGetDirect_0();
case -2018427105: return bem_printPlacesGet_0();
case -2017009146: return bem_new_0();
case -901760286: return bem_doEmitGet_0();
case -385454305: return bem_saveIdsGetDirect_0();
case 2045941275: return bem_iteratorGet_0();
case -984903392: return bem_printStepsGet_0();
case -879586760: return bem_doMainGet_0();
case 1019262813: return bem_emitFlagsGet_0();
case -571638509: return bem_emitChecksGetDirect_0();
case 1810013742: return bem_doEmitGetDirect_0();
case 912698516: return bem_makeNameGet_0();
case -1303070068: return bem_lctokGetDirect_0();
case 1609882132: return bem_loadIdsGetDirect_0();
case 1786125032: return bem_emitCommonGet_0();
case -1591114185: return bem_platformGetDirect_0();
case 1350198953: return bem_printAstElementsGetDirect_0();
case 1445487658: return bem_mainNameGet_0();
case 673780267: return bem_parseEmitCompileTimeGet_0();
case 227858745: return bem_extLinkObjectsGetDirect_0();
case -231041436: return bem_mainNameGetDirect_0();
case -991932974: return bem_lctokGet_0();
case -22815319: return bem_main_0();
case 192485408: return bem_exeNameGet_0();
case -23473221: return bem_runGetDirect_0();
case -610525910: return bem_emitPathGetDirect_0();
case 653616038: return bem_paramsGet_0();
case 548900032: return bem_genOnlyGetDirect_0();
case -1245066599: return bem_deployUsedLibrariesGet_0();
case 559892397: return bem_newlineGetDirect_0();
case -527673875: return bem_singleCCGetDirect_0();
case 140820961: return bem_runGet_0();
case -956180433: return bem_printAllAstGetDirect_0();
case 1439258603: return bem_printPlacesGetDirect_0();
case -875894967: return bem_startTimeGetDirect_0();
case 2059508155: return bem_nlGet_0();
case -1777461030: return bem_deployPathGet_0();
case 1858235681: return bem_usedLibrarysStrGetDirect_0();
case 1880238957: return bem_saveSynsGet_0();
case 1279489582: return bem_parseEmitCompileTimeGetDirect_0();
case -1852591693: return bem_usedLibrarysGet_0();
case -180220732: return bem_compilerProfileGetDirect_0();
case 577488623: return bem_platformGet_0();
case -1940708509: return bem_ntypesGetDirect_0();
case 289594681: return bem_sharedEmitterGet_0();
case -545556484: return bem_once_0();
case -972819965: return bem_printAstElementsGet_0();
case -1878164696: return bem_initLibsGetDirect_0();
case 824133064: return bem_codeGet_0();
case -1700349054: return bem_parseTimeGetDirect_0();
case 1749957827: return bem_usedLibrarysStrGet_0();
case 563369387: return bem_closeLibrariesGet_0();
case -611492075: return bem_extLibsGetDirect_0();
case 1073178435: return bem_outputPlatformGetDirect_0();
case -1340810631: return bem_argsGetDirect_0();
case 632198166: return bem_paramsGetDirect_0();
case -366465402: return bem_closeLibrariesGetDirect_0();
case -1494567308: return bem_doWhat_0();
case -1275325619: return bem_toString_0();
case -1009249204: return bem_emitFileHeaderGetDirect_0();
case -1445147433: return bem_setClassesToWrite_0();
case 155651055: return bem_toBuildGetDirect_0();
case 119461913: return bem_tagGet_0();
case 516626084: return bem_twtokGet_0();
case 695876745: return bem_emitChecksGet_0();
case -1302536404: return bem_saveSynsGetDirect_0();
case 1977348307: return bem_buildSucceededGetDirect_0();
case -48846816: return bem_buildPathGet_0();
case -1754478112: return bem_print_0();
case -1514696008: return bem_deployFilesFromGetDirect_0();
case 326719016: return bem_parseGet_0();
case 1300407960: return bem_compilerProfileGet_0();
case 1268116693: return bem_emitPathGet_0();
case 914412633: return bem_buildMessageGet_0();
case 793800213: return bem_runArgsGetDirect_0();
case -744679096: return bem_fieldNamesGet_0();
case 1937509082: return bem_loadSynsGetDirect_0();
case 381002822: return bem_emitCommonGetDirect_0();
case 321824333: return bem_libNameGetDirect_0();
case -200357424: return bem_printStepsGetDirect_0();
case -914282646: return bem_loadSynsGet_0();
case 1068915473: return bem_emitDataGet_0();
case 611702865: return bem_copy_0();
case 281444821: return bem_fieldIteratorGet_0();
case -1653632272: return bem_parseEmitTimeGetDirect_0();
case 501088997: return bem_sourceFileNameGet_0();
case -1200800477: return bem_parseTimeGet_0();
case -267293013: return bem_deployLibraryGetDirect_0();
case 1017701501: return bem_ownProcessGet_0();
case -1058740531: return bem_doMainGetDirect_0();
case -71223346: return bem_emitCs_0();
case 1411257286: return bem_builtGetDirect_0();
case -820161231: return bem_ccObjArgsGet_0();
case -356916042: return bem_emitDebugGet_0();
case -1486279572: return bem_serializeContents_0();
case -965685632: return bem_deployFilesFromGet_0();
case 1151770716: return bem_codeGetDirect_0();
case -1773747841: return bem_extLibsGet_0();
case 1649392360: return bem_includePathGet_0();
case 541355667: return bem_closeLibrariesStrGetDirect_0();
case 1007308331: return bem_parseGetDirect_0();
case -356027579: return bem_deployLibraryGet_0();
case 677754622: return bem_deployFilesToGet_0();
case 1962942925: return bem_go_0();
case 1558185817: return bem_genOnlyGet_0();
case 673887726: return bem_deployUsedLibrariesGetDirect_0();
case 235175242: return bem_builtGet_0();
case 1611271402: return bem_config_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -362495330: return bem_deployFilesToSetDirect_1(bevd_0);
case -1942849490: return bem_lctokSetDirect_1(bevd_0);
case 1884655627: return bem_usedLibrarysSet_1(bevd_0);
case -1416640675: return bem_outputPlatformSetDirect_1(bevd_0);
case 266847875: return bem_paramsSet_1(bevd_0);
case 1033749398: return bem_buildSucceededSetDirect_1(bevd_0);
case 1958144237: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1601906062: return bem_compilerSet_1(bevd_0);
case -1058598091: return bem_usedLibrarysStrSet_1(bevd_0);
case -2109827710: return bem_argsSet_1(bevd_0);
case -703687891: return bem_undef_1(bevd_0);
case 772390260: return bem_platformSet_1(bevd_0);
case -2006725760: return bem_readBufferSet_1(bevd_0);
case 1168519739: return bem_mainNameSet_1(bevd_0);
case -871701988: return bem_printAstSet_1(bevd_0);
case 761791120: return bem_doParse_1(bevd_0);
case 2018288623: return bem_putLineNumbersInTraceSet_1(bevd_0);
case -193102676: return bem_closeLibrariesStrSet_1(bevd_0);
case 703440479: return bem_outputPlatformSet_1(bevd_0);
case -1173694855: return bem_saveSynsSet_1(bevd_0);
case 108552321: return bem_toBuildSet_1(bevd_0);
case 822150683: return bem_loadIdsSet_1(bevd_0);
case 1453046149: return bem_sameClass_1(bevd_0);
case 1685929353: return bem_sharedEmitterSetDirect_1(bevd_0);
case 2097588683: return bem_copyTo_1(bevd_0);
case 917267977: return bem_ntypesSetDirect_1(bevd_0);
case -1298407118: return bem_fromFileSetDirect_1(bevd_0);
case -1314253592: return bem_emitCommonSet_1(bevd_0);
case -1838327557: return bem_singleCCSet_1(bevd_0);
case 1033592789: return bem_emitDebugSetDirect_1(bevd_0);
case -1300795630: return bem_extIncludesSetDirect_1(bevd_0);
case -2081456376: return bem_notEquals_1(bevd_0);
case -284829419: return bem_printPlacesSetDirect_1(bevd_0);
case -1150506253: return bem_buildPathSet_1(bevd_0);
case 909284865: return bem_buildMessageSetDirect_1(bevd_0);
case 2108976390: return bem_prepMakeSetDirect_1(bevd_0);
case 2133394723: return bem_printStepsSet_1(bevd_0);
case 1340087556: return bem_extLinkObjectsSetDirect_1(bevd_0);
case -1325535252: return bem_sharedEmitterSet_1(bevd_0);
case 431663703: return bem_deployUsedLibrariesSet_1(bevd_0);
case -369690328: return bem_parseEmitTimeSetDirect_1(bevd_0);
case 822977773: return bem_makeNameSet_1(bevd_0);
case 368356232: return bem_ccObjArgsSet_1(bevd_0);
case -139885811: return bem_emitFileHeaderSet_1(bevd_0);
case 1814785474: return bem_runSet_1(bevd_0);
case -874086154: return bem_startTimeSet_1(bevd_0);
case 1486493055: return bem_saveSynsSetDirect_1(bevd_0);
case 1896390985: return bem_printPlacesSet_1(bevd_0);
case 1848476565: return bem_doMainSetDirect_1(bevd_0);
case 1305059465: return bem_closeLibrariesSet_1(bevd_0);
case -1008867274: return bem_ccObjArgsSetDirect_1(bevd_0);
case 1584190967: return bem_extIncludesSet_1(bevd_0);
case -637815502: return bem_platformSetDirect_1(bevd_0);
case 2056689370: return bem_printAstElementsSetDirect_1(bevd_0);
case -2061713836: return bem_doMainSet_1(bevd_0);
case -1953227766: return bem_emitLangsSet_1(bevd_0);
case 83496493: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case 1398180203: return bem_initLibsSetDirect_1(bevd_0);
case -112278359: return bem_makeArgsSetDirect_1(bevd_0);
case -770636958: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -1628977686: return bem_printAstSetDirect_1(bevd_0);
case 702752303: return bem_emitLibrarySetDirect_1(bevd_0);
case -1248491830: return bem_def_1(bevd_0);
case 22061128: return bem_buildMessageSet_1(bevd_0);
case 95273051: return bem_parseSet_1(bevd_0);
case -1677230304: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case 322181925: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case 362062467: return bem_makeSetDirect_1(bevd_0);
case -1504957225: return bem_estrSet_1(bevd_0);
case 976160065: return bem_printAllAstSet_1(bevd_0);
case -800388761: return bem_constantsSet_1(bevd_0);
case -183121894: return bem_extLinkObjectsSet_1(bevd_0);
case 1533769874: return bem_buildSucceededSet_1(bevd_0);
case 108028698: return bem_constantsSetDirect_1(bevd_0);
case -1105403376: return bem_runSetDirect_1(bevd_0);
case 1103827954: return bem_emitLangsSetDirect_1(bevd_0);
case 1293207873: return bem_mainNameSetDirect_1(bevd_0);
case 1993335984: return bem_makeNameSetDirect_1(bevd_0);
case 509474695: return bem_sameObject_1(bevd_0);
case 211674801: return bem_parseSetDirect_1(bevd_0);
case 1791872187: return bem_readBufferSetDirect_1(bevd_0);
case 704168030: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case 1075138364: return bem_printStepsSetDirect_1(bevd_0);
case -274183080: return bem_codeSetDirect_1(bevd_0);
case 1679406851: return bem_loadSynsSetDirect_1(bevd_0);
case -508302003: return bem_linkLibArgsSet_1(bevd_0);
case -1039805828: return bem_genOnlySet_1(bevd_0);
case -2137116247: return bem_libNameSet_1(bevd_0);
case -1335052784: return bem_loadIdsSetDirect_1(bevd_0);
case -1524933773: return bem_exeNameSet_1(bevd_0);
case 1994001586: return bem_closeLibrariesSetDirect_1(bevd_0);
case -1784722133: return bem_newlineSetDirect_1(bevd_0);
case -1336612874: return bem_saveIdsSetDirect_1(bevd_0);
case 1097803038: return bem_loadSynsSet_1(bevd_0);
case 1301181976: return bem_includePathSet_1(bevd_0);
case 1557816403: return bem_initLibsSet_1(bevd_0);
case -958601586: return bem_twtokSetDirect_1(bevd_0);
case 1934833294: return bem_deployPathSetDirect_1(bevd_0);
case -1088813168: return bem_deployFilesFromSet_1(bevd_0);
case -344948211: return bem_deployFilesFromSetDirect_1(bevd_0);
case 655385354: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 878877453: return bem_startTimeSetDirect_1(bevd_0);
case 921433910: return bem_emitChecksSet_1(bevd_0);
case -1037213055: return bem_emitFileHeaderSetDirect_1(bevd_0);
case -790859624: return bem_emitLibrarySet_1(bevd_0);
case -8419053: return bem_sameType_1(bevd_0);
case 626342249: return bem_builtSetDirect_1(bevd_0);
case 1914769394: return bem_emitDebugSet_1(bevd_0);
case -1225398780: return bem_parseTimeSetDirect_1(bevd_0);
case 2126030063: return bem_printAstElementsSet_1(bevd_0);
case -1173013214: return bem_makeSet_1(bevd_0);
case -915587237: return bem_emitPathSetDirect_1(bevd_0);
case -379307970: return bem_parseTimeSet_1(bevd_0);
case -438942034: return bem_paramsSetDirect_1(bevd_0);
case -395460342: return bem_singleCCSetDirect_1(bevd_0);
case -1078392496: return bem_ownProcessSetDirect_1(bevd_0);
case -1305030836: return bem_compilerProfileSet_1(bevd_0);
case -1146441646: return bem_extLibsSet_1(bevd_0);
case 1311824436: return bem_equals_1(bevd_0);
case 433078501: return bem_codeSet_1(bevd_0);
case -869478913: return bem_compilerSetDirect_1(bevd_0);
case -1913038896: return bem_newlineSet_1(bevd_0);
case 754975496: return bem_estrSetDirect_1(bevd_0);
case -1328139712: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case 1017173873: return bem_emitFlagsSetDirect_1(bevd_0);
case 454728732: return bem_emitCommonSetDirect_1(bevd_0);
case -875261161: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case -591906003: return bem_emitDataSetDirect_1(bevd_0);
case 1286121276: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 1403827810: return bem_emitPathSet_1(bevd_0);
case -605001290: return bem_nlSet_1(bevd_0);
case -1370336607: return bem_linkLibArgsSetDirect_1(bevd_0);
case -2026066926: return bem_deployLibrarySet_1(bevd_0);
case 507138973: return bem_defined_1(bevd_0);
case 545413348: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -1344173810: return bem_libNameSetDirect_1(bevd_0);
case -1695667267: return bem_lctokSet_1(bevd_0);
case 818848730: return bem_twtokSet_1(bevd_0);
case 558834440: return bem_usedLibrarysSetDirect_1(bevd_0);
case -647823669: return bem_toBuildSetDirect_1(bevd_0);
case 1267723438: return bem_runArgsSetDirect_1(bevd_0);
case 857345991: return bem_buildSyns_1(bevd_0);
case -16322650: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1795616867: return bem_ownProcessSet_1(bevd_0);
case 1133448068: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 302284583: return bem_emitChecksSetDirect_1(bevd_0);
case 723865244: return bem_otherClass_1(bevd_0);
case -473352720: return bem_otherType_1(bevd_0);
case 824117657: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 485951530: return bem_extLibsSetDirect_1(bevd_0);
case -377579197: return bem_makeArgsSet_1(bevd_0);
case 1115592810: return bem_exeNameSetDirect_1(bevd_0);
case 712251740: return bem_emitFlagsSet_1(bevd_0);
case 70772496: return bem_printAllAstSetDirect_1(bevd_0);
case -881529242: return bem_fromFileSet_1(bevd_0);
case -532459636: return bem_undefined_1(bevd_0);
case -575258946: return bem_runArgsSet_1(bevd_0);
case 844545957: return bem_genOnlySetDirect_1(bevd_0);
case 798117811: return bem_buildPathSetDirect_1(bevd_0);
case 1145495187: return bem_saveIdsSet_1(bevd_0);
case -1311050082: return bem_deployLibrarySetDirect_1(bevd_0);
case 458702136: return bem_nlSetDirect_1(bevd_0);
case -1035950167: return bem_parseEmitTimeSet_1(bevd_0);
case -971196372: return bem_emitDataSet_1(bevd_0);
case 2098155515: return bem_doEmitSetDirect_1(bevd_0);
case 2009049500: return bem_doEmitSet_1(bevd_0);
case 304368972: return bem_includePathSetDirect_1(bevd_0);
case 944152909: return bem_deployPathSet_1(bevd_0);
case 861048872: return bem_compilerProfileSetDirect_1(bevd_0);
case -1631231888: return bem_builtSet_1(bevd_0);
case -773363036: return bem_argsSetDirect_1(bevd_0);
case -1301808230: return bem_deployFilesToSet_1(bevd_0);
case -2015423498: return bem_getSynNp_1(bevd_0);
case 1896393607: return bem_prepMakeSet_1(bevd_0);
case -1031858778: return bem_ntypesSet_1(bevd_0);
case -180549840: return bem_usedLibrarysStrSetDirect_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -56289535: return bem_getSyn_2(bevd_0, bevd_1);
case 795884988: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -2085762202: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 794475622: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 884104461: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1281040416: return bem_buildLiteral_2(bevd_0, bevd_1);
case -945985211: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 420118938: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1341848080: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -118325799: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
}
