namespace be {
/* IO:File: source/build/Build.be */
public sealed class BEC_2_5_5_BuildBuild : BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
static BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x49,0x64,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x73,0x69,0x6E,0x67,0x6C,0x65,0x43,0x43};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_60, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_64, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_70, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_112, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_115 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static new BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;

public static new BET_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_type;

public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_5_4_LogicBool bevp_singleCC;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_9_3_ContainerSet bevp_emitChecks;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_5_4_LogicBool bevp_saveIds;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public override BEC_2_6_6_SystemObject bem_new_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printPlaces = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printAllAst = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_genOnly = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_estr = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (BEC_2_5_9_BuildConstants) (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (BEC_2_4_9_TextTokenizer) (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_singleCC = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_ownProcess = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_saveSyns = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_saveIds = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 100 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 100 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 100 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 100 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 100 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 100 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 100 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 100 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 100 */
 else  /* Line: 100 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 100 */ {
bevt_6_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 101 */
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (BEC_2_6_10_SystemParameters) (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 119 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 119 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 119 */
 else  /* Line: 119 */ {
break;
} /* Line: 119 */
} /* Line: 119 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
try  /* Line: 128 */ {
bem_config_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 132 */
 catch (System.Exception beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(621276181);
bevl_buildFailed = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
} /* Line: 137 */
if (bevp_printSteps.bevi_bool) /* Line: 139 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 139 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 139 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 139 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 139 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 140 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(1269786805);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-1255083521, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 146 */ {
} /* Line: 146 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_ec = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_2_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_33_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_39_tmpany_phold = null;
BEC_2_4_6_TextString bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_46_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_50_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_56_tmpany_phold = null;
BEC_2_4_6_TextString bevt_57_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_4_6_TextString bevt_60_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_61_tmpany_phold = null;
BEC_2_4_6_TextString bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_6_TextString bevt_64_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_65_tmpany_phold = null;
BEC_2_4_6_TextString bevt_66_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_69_tmpany_phold = null;
BEC_2_4_6_TextString bevt_70_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_73_tmpany_phold = null;
BEC_2_4_6_TextString bevt_74_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_77_tmpany_phold = null;
BEC_2_4_6_TextString bevt_78_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_79_tmpany_phold = null;
BEC_2_4_6_TextString bevt_80_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_81_tmpany_phold = null;
BEC_2_4_6_TextString bevt_82_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_98_tmpany_phold = null;
BEC_2_4_6_TextString bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_101_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_102_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_4_6_TextString bevt_105_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_113_tmpany_phold = null;
BEC_2_4_6_TextString bevt_114_tmpany_phold = null;
BEC_2_4_6_TextString bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_117_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_119_tmpany_phold = null;
BEC_2_4_6_TextString bevt_120_tmpany_phold = null;
BEC_2_4_6_TextString bevt_121_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_122_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_123_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_124_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_125_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_126_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_127_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_128_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_129_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_130_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_131_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_132_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_133_tmpany_phold = null;
bevl_bfiles = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_6_tmpany_phold == null) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 156 */ {
bevt_7_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_7_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 157 */ {
bevt_8_tmpany_phold = bevt_0_tmpany_loop.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 157 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(-682526974);
bevt_10_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_10_tmpany_phold.bevi_bool) {
bevt_9_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_9_tmpany_phold.bevi_bool) /* Line: 158 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_11_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_11_tmpany_phold);
} /* Line: 160 */
} /* Line: 158 */
 else  /* Line: 157 */ {
break;
} /* Line: 157 */
} /* Line: 157 */
} /* Line: 157 */
bevt_14_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_nameGet_0();
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_equals_1(bevt_15_tmpany_phold);
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 165 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 166 */
bevt_17_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_16_tmpany_phold = bevp_params.bem_get_1(bevt_17_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_16_tmpany_phold.bem_firstGet_0();
bevt_19_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_18_tmpany_phold = bevp_params.bem_has_1(bevt_19_tmpany_phold);
if (bevt_18_tmpany_phold.bevi_bool) /* Line: 169 */ {
bevt_21_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_20_tmpany_phold = bevp_params.bem_get_1(bevt_21_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_20_tmpany_phold.bem_firstGet_0();
} /* Line: 170 */
 else  /* Line: 171 */ {
bevp_exeName = bevp_libName;
} /* Line: 172 */
bevt_25_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_26_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_24_tmpany_phold = bevp_params.bem_get_2(bevt_25_tmpany_phold, bevt_26_tmpany_phold);
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bem_firstGet_0();
bevt_22_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_23_tmpany_phold);
bevp_buildPath = bevt_22_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_27_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_27_tmpany_phold);
bevt_31_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_32_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_30_tmpany_phold = bevp_params.bem_get_2(bevt_31_tmpany_phold, bevt_32_tmpany_phold);
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bem_firstGet_0();
bevt_28_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevt_29_tmpany_phold);
bevp_includePath = bevt_28_tmpany_phold.bem_pathGet_0();
bevt_35_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_37_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_nameGet_0();
bevt_34_tmpany_phold = bevp_params.bem_get_2(bevt_35_tmpany_phold, bevt_36_tmpany_phold);
bevt_33_tmpany_phold = bevt_34_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_33_tmpany_phold );
bevt_40_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_41_tmpany_phold = bevp_platform.bemd_0(1269786805);
bevt_39_tmpany_phold = bevp_params.bem_get_2(bevt_40_tmpany_phold, (BEC_2_4_6_TextString) bevt_41_tmpany_phold );
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_38_tmpany_phold );
bevt_44_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_45_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_43_tmpany_phold = bevp_params.bem_get_2(bevt_44_tmpany_phold, bevt_45_tmpany_phold);
bevt_42_tmpany_phold = bevt_43_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_42_tmpany_phold);
bevt_48_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_49_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_47_tmpany_phold = bevp_params.bem_get_2(bevt_48_tmpany_phold, bevt_49_tmpany_phold);
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_46_tmpany_phold);
bevt_52_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_53_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_51_tmpany_phold = bevp_params.bem_get_2(bevt_52_tmpany_phold, bevt_53_tmpany_phold);
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_firstGet_0();
bevp_saveIds = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_50_tmpany_phold);
bevt_54_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_55_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_55_tmpany_phold);
bevt_57_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_56_tmpany_phold = bevp_params.bem_get_1(bevt_57_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_56_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_58_tmpany_phold = bevp_params.bem_get_1(bevt_59_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_58_tmpany_phold.bem_firstGet_0();
bevt_60_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_60_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_61_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_61_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_61_tmpany_phold.bevi_bool) /* Line: 189 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 190 */
bevt_62_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_62_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 193 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 194 */
bevt_64_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_64_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_65_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_65_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_65_tmpany_phold.bevi_bool) /* Line: 197 */ {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 198 */
bevt_66_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_66_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_67_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_67_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_67_tmpany_phold.bevi_bool) /* Line: 201 */ {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 202 */
bevt_68_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_68_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_69_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_69_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_69_tmpany_phold.bevi_bool) /* Line: 205 */ {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 206 */
bevt_70_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_70_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_71_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_71_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_71_tmpany_phold.bevi_bool) /* Line: 209 */ {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 210 */
bevt_72_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_72_tmpany_phold);
if (bevp_extLibs == null) {
bevt_73_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_73_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_73_tmpany_phold.bevi_bool) /* Line: 213 */ {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 214 */
bevt_74_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_74_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_75_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_75_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_75_tmpany_phold.bevi_bool) /* Line: 217 */ {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 218 */
bevt_76_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_76_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_77_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_77_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_77_tmpany_phold.bevi_bool) /* Line: 221 */ {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 222 */
bevt_78_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_78_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_79_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_79_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_79_tmpany_phold.bevi_bool) /* Line: 225 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-292208502);
} /* Line: 226 */
bevt_80_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_80_tmpany_phold);
if (bevp_runArgs == null) {
bevt_81_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_81_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_81_tmpany_phold.bevi_bool) /* Line: 229 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-292208502);
} /* Line: 230 */
 else  /* Line: 231 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 232 */
bevt_82_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_83_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_82_tmpany_phold, bevt_83_tmpany_phold);
bevt_84_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_85_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_84_tmpany_phold, bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevt_87_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_87_tmpany_phold);
bevp_printAstElements = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_88_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_88_tmpany_phold);
if (bevl_pacm == null) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_91_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_91_tmpany_phold.bevi_bool) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 240 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 240 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 240 */
 else  /* Line: 240 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 240 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 241 */ {
bevt_92_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 241 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 242 */
 else  /* Line: 241 */ {
break;
} /* Line: 241 */
} /* Line: 241 */
} /* Line: 241 */
bevt_93_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_95_tmpany_phold);
bevt_96_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_52));
bevp_singleCC = bevp_params.bem_isTrue_1(bevt_96_tmpany_phold);
bevt_97_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_53));
bevt_98_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_97_tmpany_phold, bevt_98_tmpany_phold);
bevt_99_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitLangs = bevp_params.bem_get_1(bevt_99_tmpany_phold);
bevt_100_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevp_emitFlags = bevp_params.bem_get_1(bevt_100_tmpany_phold);
bevp_emitChecks = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
if (bevp_emitFlags == null) {
bevt_101_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_101_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_101_tmpany_phold.bevi_bool) /* Line: 253 */ {
bevt_2_tmpany_loop = bevp_emitFlags.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 254 */ {
bevt_102_tmpany_phold = bevt_2_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_102_tmpany_phold).bevi_bool) /* Line: 254 */ {
bevl_ec = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bem_nextGet_0();
bevp_emitChecks.bem_addValue_1(bevl_ec);
} /* Line: 256 */
 else  /* Line: 254 */ {
break;
} /* Line: 254 */
} /* Line: 254 */
} /* Line: 254 */
bevt_104_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_105_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_103_tmpany_phold = bevp_params.bem_get_2(bevt_104_tmpany_phold, bevt_105_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_103_tmpany_phold.bem_firstGet_0();
bevt_107_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_108_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_59));
bevt_106_tmpany_phold = bevp_params.bem_get_2(bevt_107_tmpany_phold, bevt_108_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_106_tmpany_phold.bem_firstGet_0();
bevt_111_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_110_tmpany_phold = bevt_111_tmpany_phold.bem_add_1(bevp_makeName);
bevt_112_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_61));
bevt_109_tmpany_phold = bevp_params.bem_get_2(bevt_110_tmpany_phold, bevt_112_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_109_tmpany_phold.bem_firstGet_0();
bevp_parse = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_emitDebug = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_doEmit = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_prepMake = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevp_make = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_113_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_113_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_113_tmpany_phold.bevi_bool) /* Line: 269 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 270 */
 else  /* Line: 271 */ {
bevl_outLang = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_62));
} /* Line: 272 */
bevt_116_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_115_tmpany_phold = bevl_outLang.bem_add_1(bevt_116_tmpany_phold);
bevt_117_tmpany_phold = bevp_platform.bemd_0(1269786805);
bevt_114_tmpany_phold = bevt_115_tmpany_phold.bem_add_1(bevt_117_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_114_tmpany_phold);
if (bevl_platformSources == null) {
bevt_118_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_118_tmpany_phold.bevi_bool) /* Line: 280 */ {
bevt_119_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_119_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 281 */
bevt_121_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_120_tmpany_phold = bevl_outLang.bem_add_1(bevt_121_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_120_tmpany_phold);
if (bevl_langSources == null) {
bevt_122_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_122_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_122_tmpany_phold.bevi_bool) /* Line: 285 */ {
bevt_123_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_123_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 286 */
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_124_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_3_tmpany_loop = bevt_124_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 290 */ {
bevt_125_tmpany_phold = bevt_3_tmpany_loop.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_125_tmpany_phold).bevi_bool) /* Line: 290 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_3_tmpany_loop.bemd_0(-682526974);
bevt_126_tmpany_phold = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_126_tmpany_phold);
} /* Line: 291 */
 else  /* Line: 290 */ {
break;
} /* Line: 290 */
} /* Line: 290 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(725434561);
bevp_nl = bevp_newline;
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevp_buildPath.bem_copy_0();
bevt_129_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_128_tmpany_phold = bevt_129_tmpany_phold.bem_existsGet_0();
if (bevt_128_tmpany_phold.bevi_bool) {
bevt_127_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_127_tmpany_phold.bevi_bool) /* Line: 298 */ {
bevt_130_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_130_tmpany_phold.bem_makeDirs_0();
} /* Line: 299 */
if (bevp_emitFileHeader == null) {
bevt_131_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_131_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_131_tmpany_phold.bevi_bool) /* Line: 301 */ {
bevt_132_tmpany_phold = (BEC_2_2_4_IOFile) (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_132_tmpany_phold.bem_readerGet_0();
bevt_133_tmpany_phold = bevl_emr.bemd_0(-1041760951);
bevp_emitFileHeader = bevt_133_tmpany_phold.bemd_0(-1611356520);
bevl_emr.bemd_0(-1081610686);
} /* Line: 304 */
return this;
} /*method end*/
public override BEC_2_4_6_TextString bem_toString_0() {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(1341810503, bevp_nl);
bevt_2_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(1341810503, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(1341810503, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(1341810503, bevp_nl);
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_66));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(1341810503, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(1341810503, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 318 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 318 */ {
bevl_clnode = bevl_ci.bemd_0(-682526974);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(1603673665);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1851765321);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 320 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(1603673665);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(639694305);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(621276181);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(1603673665);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(639694305);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(621276181);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 323 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 324 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 324 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 325 */
 else  /* Line: 324 */ {
break;
} /* Line: 324 */
} /* Line: 324 */
} /* Line: 324 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(1603673665);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(639694305);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(621276181);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 329 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 330 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 330 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 331 */
 else  /* Line: 330 */ {
break;
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 330 */
} /* Line: 329 */
} /* Line: 320 */
 else  /* Line: 318 */ {
break;
} /* Line: 318 */
} /* Line: 318 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 336 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 336 */ {
bevl_clnode = bevl_ci.bemd_0(-682526974);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(1603673665);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(1603673665);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(639694305);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(621276181);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(357988318, bevt_26_tmpany_phold);
} /* Line: 338 */
 else  /* Line: 336 */ {
break;
} /* Line: 336 */
} /* Line: 336 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 349 */ {
return bevp_emitCommon;
} /* Line: 350 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 355 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 357 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 358 */
 else  /* Line: 357 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 359 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 360 */
 else  /* Line: 357 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 361 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 362 */
 else  /* Line: 357 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 363 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 364 */
 else  /* Line: 367 */ {
bevt_11_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_71));
bevt_10_tmpany_phold = (BEC_2_6_9_SystemException) (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 368 */
} /* Line: 357 */
} /* Line: 357 */
} /* Line: 357 */
return bevp_emitCommon;
} /* Line: 370 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (BEC_3_2_4_4_IOFilePath) (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = (BEC_2_4_8_TimeInterval) bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(-1041760951);
bevt_5_tmpany_phold = (BEC_2_6_10_SystemSerializer) (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (BEC_2_5_8_BuildEmitData) (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 393 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 394 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 394 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 395 */
 else  /* Line: 394 */ {
break;
} /* Line: 394 */
} /* Line: 394 */
} /* Line: 394 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 399 */ {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 402 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 403 */
} /* Line: 402 */
bevl_ulibs = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(-2120499139);
while (true)
 /* Line: 408 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 408 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(-682526974);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 409 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 412 */
} /* Line: 409 */
 else  /* Line: 408 */ {
break;
} /* Line: 408 */
} /* Line: 408 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(-2120499139);
while (true)
 /* Line: 415 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 415 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(-682526974);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 416 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(2094922617);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 420 */
} /* Line: 416 */
 else  /* Line: 415 */ {
break;
} /* Line: 415 */
} /* Line: 415 */
if (bevp_parse.bevi_bool) /* Line: 423 */ {
bevl_built = (BEC_2_9_3_ContainerSet) (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 426 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 426 */ {
bevl_tb = bevl_i.bemd_0(-682526974);
bevt_20_tmpany_phold = bevl_tb.bemd_0(621276181);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 429 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(621276181);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 431 */
} /* Line: 429 */
 else  /* Line: 426 */ {
break;
} /* Line: 426 */
} /* Line: 426 */
bem_buildSyns_1(bevl_em);
} /* Line: 434 */
bevt_23_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 440 */ {
bevt_26_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = (BEC_2_4_8_TimeInterval) bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 449 */
if (bevp_doEmit.bevi_bool) /* Line: 451 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(1357178129);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 455 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 455 */ {
bevl_clnode = bevl_ci.bemd_0(-682526974);
bevl_em.bemd_1(-115266932, bevl_clnode);
} /* Line: 457 */
 else  /* Line: 455 */ {
break;
} /* Line: 455 */
} /* Line: 455 */
bevl_em.bemd_0(686687951);
bevl_em.bemd_0(-915337606);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 461 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 461 */ {
bevl_clnode = bevl_ci.bemd_0(-682526974);
bevl_em.bemd_1(-1771655071, bevl_clnode);
} /* Line: 463 */
 else  /* Line: 461 */ {
break;
} /* Line: 461 */
} /* Line: 461 */
} /* Line: 461 */
bevt_44_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 468 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 469 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 472 */ {
bevl_em.bemd_1(1511753488, bevp_deployLibrary);
} /* Line: 474 */
if (bevp_make.bevi_bool) /* Line: 477 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 478 */ {
bevl_em.bemd_1(-580385099, bevp_deployLibrary);
bevl_em.bemd_1(316288158, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 481 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 482 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 482 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(1357178129);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(-832920867);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(18463950);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(-733443081);
bevl_cpTo.bemd_1(1110373860, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(1498494438);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(2038996237);
if (((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 486 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(1498494438);
bevt_58_tmpany_phold.bemd_0(-1154476723);
} /* Line: 487 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(1498494438);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(2038996237);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(-458902099);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(1498494438);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(1498494438);
bevl_em.bemd_2(-1933997794, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 490 */
} /* Line: 489 */
 else  /* Line: 482 */ {
break;
} /* Line: 482 */
} /* Line: 482 */
} /* Line: 482 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 497 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 497 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 497 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 497 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 497 */
 else  /* Line: 497 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 497 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(-682526974);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = (BEC_3_2_4_4_IOFilePath) bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(-682526974);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(1498494438);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(2038996237);
if (((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 501 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(1498494438);
bevt_76_tmpany_phold.bemd_0(-1154476723);
} /* Line: 502 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(1498494438);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(2038996237);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(-458902099);
if (((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 504 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(1498494438);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(1498494438);
bevl_em.bemd_2(-1933997794, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 505 */
} /* Line: 504 */
 else  /* Line: 497 */ {
break;
} /* Line: 497 */
} /* Line: 497 */
} /* Line: 497 */
} /* Line: 478 */
bevt_83_tmpany_phold = (BEC_2_4_8_TimeInterval) (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = (BEC_2_4_8_TimeInterval) bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 512 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 513 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 515 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 516 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 518 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 519 */
if (bevp_run.bevi_bool) /* Line: 522 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(1651159125, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 526 */
bevt_98_tmpany_phold = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 532 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 532 */ {
bevl_kls = bevl_ci.bemd_0(-682526974);
bevt_2_tmpany_phold = bevl_kls.bemd_0(1603673665);
bevt_2_tmpany_phold.bemd_1(-938525113, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-938525113, bevp_libName);
} /* Line: 536 */
 else  /* Line: 532 */ {
break;
} /* Line: 532 */
} /* Line: 532 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 538 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 538 */ {
bevl_kls = bevl_ci.bemd_0(-682526974);
bevt_5_tmpany_phold = bevl_kls.bemd_0(1603673665);
bevl_syn = bevt_5_tmpany_phold.bemd_0(1535249621);
bevl_syn.bemd_2(-673782956, this, bevl_kls);
bevl_syn.bemd_1(1626218937, this);
} /* Line: 542 */
 else  /* Line: 538 */ {
break;
} /* Line: 538 */
} /* Line: 538 */
bevt_6_tmpany_phold = (BEC_2_9_3_ContainerMap) (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(1603673665);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1535249621);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 548 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(1603673665);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1535249621);
return bevt_3_tmpany_phold;
} /* Line: 549 */
bevt_5_tmpany_phold = beva_klass.bemd_0(1603673665);
bevt_5_tmpany_phold.bemd_1(-938525113, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(1603673665);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(486541015);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 552 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 553 */
 else  /* Line: 554 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(1603673665);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(486541015);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(621276181);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 557 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(1603673665);
bevt_14_tmpany_phold.bemd_1(-938525113, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 559 */
 else  /* Line: 560 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(1603673665);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(486541015);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 563 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 565 */
bevt_17_tmpany_phold = beva_klass.bemd_0(1603673665);
bevt_17_tmpany_phold.bemd_1(-1906606954, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(1603673665);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(639694305);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(621276181);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(621276181);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 575 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 576 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(114752030, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 591 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 592 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 605 */ {
if (bevp_printSteps.bevi_bool) /* Line: 606 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 606 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 606 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 606 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 606 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 606 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_5_tmpany_phold = beva_toParse.bemd_0(621276181);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 607 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(1498494438);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(326068259);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1041760951);
bevl_src = bevt_6_tmpany_phold.bemd_1(-293891811, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(1498494438);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(326068259);
bevt_9_tmpany_phold.bemd_0(-1081610686);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 618 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 619 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(-1034939595);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 622 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_14_tmpany_phold);
} /* Line: 624 */
if (bevp_printSteps.bevi_bool) /* Line: 627 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 628 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(108689940, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 631 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_18_tmpany_phold);
} /* Line: 633 */
if (bevp_printSteps.bevi_bool) /* Line: 635 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 636 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(108689940, bevt_20_tmpany_phold);
bevl_trans.bemd_0(-175490614);
if (bevp_printAllAst.bevi_bool) /* Line: 641 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_22_tmpany_phold);
} /* Line: 643 */
if (bevp_printSteps.bevi_bool) /* Line: 646 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 647 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(108689940, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 650 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_26_tmpany_phold);
} /* Line: 652 */
if (bevp_printSteps.bevi_bool) /* Line: 655 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 656 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(108689940, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 659 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_30_tmpany_phold);
} /* Line: 661 */
if (bevp_printSteps.bevi_bool) /* Line: 664 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 665 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(108689940, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 668 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_34_tmpany_phold);
} /* Line: 670 */
if (bevp_printSteps.bevi_bool) /* Line: 673 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 674 */
bevt_36_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass7) (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(108689940, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 677 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_38_tmpany_phold);
} /* Line: 679 */
if (bevp_printSteps.bevi_bool) /* Line: 682 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 683 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(108689940, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 686 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_42_tmpany_phold);
} /* Line: 688 */
if (bevp_printSteps.bevi_bool) /* Line: 691 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 692 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(108689940, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 695 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_46_tmpany_phold);
} /* Line: 697 */
if (bevp_printSteps.bevi_bool) /* Line: 700 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 701 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(108689940, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 704 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_50_tmpany_phold);
} /* Line: 706 */
if (bevp_printSteps.bevi_bool) /* Line: 708 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 709 */
bevt_52_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass11) (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(108689940, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 712 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_54_tmpany_phold);
} /* Line: 714 */
if (bevp_printSteps.bevi_bool) /* Line: 717 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 719 */
bevt_57_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass12) (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(108689940, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 722 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 722 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 722 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 722 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 722 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 722 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(108689940, bevt_59_tmpany_phold);
} /* Line: 724 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 726 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(942482233);
if (((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 726 */ {
bevl_clnode = bevl_ci.bemd_0(-682526974);
bevl_tunode = bevl_clnode.bemd_0(1535663953);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(1512892421, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(1603673665);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-1248404777);
bevl_ntt.bemd_1(-1418778389, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(2087881938, bevl_ntt);
bevl_clnode.bemd_0(-1154476723);
bevl_ntunode.bemd_1(-1110681556, bevl_clnode);
bevl_ntunode.bemd_1(-1477317082, bevl_clnode);
} /* Line: 737 */
 else  /* Line: 726 */ {
break;
} /* Line: 726 */
} /* Line: 726 */
} /* Line: 726 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(-1401613311);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(98792468);
bevl_nlc = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 747 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 747 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(2087881938, bevt_2_tmpany_phold);
bevl_node.bemd_1(704613330, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(1603673665);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(-1255083521, bevp_nl);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 751 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 752 */
bevt_6_tmpany_phold = bevl_node.bemd_0(1603673665);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(976985770, bevl_cr);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 754 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(-1239399152, beva_parnode);
} /* Line: 756 */
} /* Line: 754 */
 else  /* Line: 747 */ {
break;
} /* Line: 747 */
} /* Line: 747 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(856292650, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(1512892421, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(2087881938, bevl_nlnp);
bevl_nlnpn.bemd_1(-1477317082, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_113));
bevl_nlc.bemd_1(-567888750, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(752465239, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-219181520, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(-1171077695, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1264099048, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(1603673665);
bevl_nlc.bemd_1(1028367826, bevt_11_tmpany_phold);
beva_node.bemd_1(-1110681556, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(1512892421, bevt_12_tmpany_phold);
beva_node.bemd_1(2087881938, bevl_nlc);
bevl_nlnpn.bemd_0(1360570902);
bevt_14_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_114));
bevt_13_tmpany_phold = beva_tName.bemd_1(-1255083521, bevt_14_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 786 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 786 */ {
bevt_16_tmpany_phold = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_115));
bevt_15_tmpany_phold = beva_tName.bemd_1(-1255083521, bevt_16_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 786 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 786 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 786 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 786 */ {
bevl_pn = beva_node.bemd_0(-167347416);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 788 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-1438707007);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(-1255083521, bevt_20_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 788 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 788 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-1438707007);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(-1255083521, bevt_23_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 788 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 788 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 788 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 788 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 788 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 788 */
 else  /* Line: 788 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 788 */ {
bevl_pn2 = bevl_pn.bemd_0(-167347416);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 790 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 790 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-1438707007);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(976985770, bevt_27_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 790 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-1438707007);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(976985770, bevt_30_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 790 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 790 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 790 */
 else  /* Line: 790 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 790 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-1438707007);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(976985770, bevt_33_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 790 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 790 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 790 */
 else  /* Line: 790 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 790 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-1438707007);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(976985770, bevt_36_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 790 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 790 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 790 */
 else  /* Line: 790 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 790 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 790 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 790 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 790 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(1603673665);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(-508614761);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(1341810503, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(1028367826, bevt_37_tmpany_phold);
bevl_pn.bemd_0(-1154476723);
} /* Line: 797 */
} /* Line: 790 */
} /* Line: 788 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGetDirect_0() {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() {
return bevp_libName;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGetDirect_0() {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGetDirect_0() {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGetDirect_0() {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGetDirect_0() {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGetDirect_0() {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGetDirect_0() {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGetDirect_0() {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGetDirect_0() {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGetDirect_0() {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() {
return bevp_platform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGetDirect_0() {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGetDirect_0() {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGetDirect_0() {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGetDirect_0() {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGetDirect_0() {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGetDirect_0() {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGetDirect_0() {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() {
return bevp_nl;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGetDirect_0() {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() {
return bevp_newline;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGetDirect_0() {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGetDirect_0() {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGetDirect_0() {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() {
return bevp_args;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGetDirect_0() {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() {
return bevp_params;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGetDirect_0() {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGetDirect_0() {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGetDirect_0() {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGetDirect_0() {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGetDirect_0() {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGetDirect_0() {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGetDirect_0() {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() {
return bevp_buildPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGetDirect_0() {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGetDirect_0() {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() {
return bevp_built;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGetDirect_0() {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGetDirect_0() {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGetDirect_0() {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGetDirect_0() {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGetDirect_0() {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGetDirect_0() {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGetDirect_0() {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGetDirect_0() {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGetDirect_0() {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGetDirect_0() {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGetDirect_0() {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGetDirect_0() {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGetDirect_0() {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGetDirect_0() {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGetDirect_0() {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() {
return bevp_emitPath;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGetDirect_0() {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() {
return bevp_code;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGetDirect_0() {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() {
return bevp_estr;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGetDirect_0() {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGetDirect_0() {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGetDirect_0() {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGetDirect_0() {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGetDirect_0() {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGetDirect_0() {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGetDirect_0() {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGetDirect_0() {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGetDirect_0() {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGetDirect_0() {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGet_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_4_LogicBool bem_singleCCGetDirect_0() {
return bevp_singleCC;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_singleCCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_singleCC = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGetDirect_0() {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGetDirect_0() {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGetDirect_0() {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGet_0() {
return bevp_emitChecks;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_emitChecksGetDirect_0() {
return bevp_emitChecks;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitChecksSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitChecks = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGetDirect_0() {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGetDirect_0() {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGetDirect_0() {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGetDirect_0() {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGetDirect_0() {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGet_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveIdsGetDirect_0() {
return bevp_saveIds;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveIdsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_saveIds = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGetDirect_0() {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGetDirect_0() {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGetDirect_0() {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGetDirect_0() {
return bevp_emitCommon;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {52, 54, 55, 56, 57, 59, 60, 61, 62, 63, 64, 65, 69, 71, 72, 73, 74, 74, 77, 80, 81, 82, 89, 90, 91, 92, 93, 93, 100, 100, 100, 100, 0, 100, 100, 0, 0, 0, 0, 0, 101, 101, 103, 103, 107, 107, 107, 107, 111, 111, 112, 112, 112, 116, 117, 118, 118, 118, 118, 118, 119, 119, 119, 120, 119, 122, 126, 127, 129, 130, 131, 132, 134, 135, 136, 136, 137, 0, 0, 0, 140, 142, 146, 146, 146, 148, 153, 155, 156, 156, 156, 157, 157, 0, 157, 157, 158, 158, 158, 159, 160, 160, 165, 165, 165, 165, 166, 168, 168, 168, 169, 169, 170, 170, 170, 172, 174, 174, 174, 174, 174, 174, 175, 176, 176, 177, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 180, 180, 180, 181, 181, 181, 181, 181, 182, 182, 182, 182, 182, 183, 183, 184, 184, 186, 186, 186, 187, 187, 187, 188, 188, 189, 189, 190, 192, 192, 193, 193, 194, 196, 196, 197, 197, 198, 200, 200, 201, 201, 202, 204, 204, 205, 205, 206, 208, 208, 209, 209, 210, 212, 212, 213, 213, 214, 216, 216, 217, 217, 218, 220, 220, 221, 221, 222, 224, 224, 225, 225, 226, 228, 228, 229, 229, 230, 232, 234, 234, 234, 235, 235, 235, 236, 236, 237, 237, 238, 239, 239, 240, 240, 240, 240, 240, 0, 0, 0, 241, 0, 241, 241, 242, 245, 245, 246, 246, 247, 247, 248, 248, 249, 249, 249, 250, 250, 251, 251, 252, 253, 253, 254, 0, 254, 254, 256, 259, 259, 259, 259, 260, 260, 260, 260, 261, 261, 261, 261, 261, 262, 263, 264, 265, 266, 269, 269, 270, 272, 279, 279, 279, 279, 279, 280, 280, 281, 281, 284, 284, 284, 285, 285, 286, 286, 289, 290, 290, 0, 290, 290, 291, 291, 293, 294, 295, 297, 298, 298, 298, 298, 299, 299, 301, 301, 302, 302, 303, 303, 304, 310, 311, 311, 311, 311, 311, 312, 312, 312, 312, 312, 313, 317, 318, 318, 318, 319, 320, 320, 320, 320, 321, 321, 321, 321, 322, 322, 322, 322, 322, 323, 323, 324, 0, 324, 324, 325, 328, 328, 328, 328, 328, 329, 329, 330, 0, 330, 330, 331, 336, 336, 336, 337, 338, 338, 338, 338, 338, 338, 345, 345, 349, 349, 350, 355, 355, 356, 357, 357, 358, 359, 359, 360, 361, 361, 362, 363, 363, 364, 368, 368, 368, 370, 372, 376, 378, 378, 378, 379, 379, 380, 380, 380, 381, 381, 382, 383, 383, 384, 384, 384, 385, 385, 385, 391, 391, 392, 393, 393, 394, 0, 394, 394, 395, 398, 399, 399, 400, 401, 403, 403, 403, 406, 408, 0, 408, 408, 409, 409, 409, 410, 411, 412, 415, 0, 415, 415, 416, 416, 416, 417, 418, 419, 420, 420, 425, 426, 426, 427, 429, 429, 430, 430, 431, 434, 437, 437, 437, 440, 440, 440, 442, 442, 443, 443, 444, 444, 444, 445, 445, 445, 446, 446, 446, 447, 447, 447, 448, 448, 448, 449, 449, 452, 453, 455, 455, 455, 456, 457, 459, 460, 461, 461, 461, 462, 463, 467, 467, 467, 468, 468, 469, 469, 469, 471, 471, 471, 474, 478, 478, 479, 480, 482, 0, 482, 482, 483, 483, 484, 484, 485, 485, 485, 486, 486, 487, 487, 489, 489, 489, 490, 490, 490, 494, 495, 497, 497, 0, 0, 0, 498, 498, 499, 499, 499, 499, 499, 499, 499, 499, 501, 501, 502, 502, 504, 504, 504, 505, 505, 505, 510, 510, 510, 512, 512, 513, 513, 513, 515, 515, 516, 516, 516, 518, 518, 519, 519, 519, 523, 523, 524, 525, 525, 525, 525, 525, 526, 528, 528, 532, 532, 532, 533, 534, 534, 535, 536, 538, 538, 538, 539, 540, 540, 541, 542, 544, 544, 548, 548, 548, 548, 549, 549, 549, 551, 551, 552, 552, 552, 552, 553, 555, 555, 555, 555, 555, 557, 557, 558, 558, 559, 563, 563, 563, 565, 567, 567, 568, 568, 568, 568, 569, 573, 574, 574, 575, 575, 576, 582, 582, 583, 584, 591, 591, 592, 594, 599, 600, 601, 602, 603, 604, 604, 0, 0, 0, 607, 607, 607, 607, 609, 611, 611, 611, 611, 612, 612, 612, 615, 619, 619, 621, 621, 623, 623, 624, 624, 628, 628, 630, 630, 632, 632, 633, 633, 636, 636, 639, 639, 640, 642, 642, 643, 643, 647, 647, 649, 649, 651, 651, 652, 652, 656, 656, 658, 658, 660, 660, 661, 661, 665, 665, 667, 667, 669, 669, 670, 670, 674, 674, 676, 676, 678, 678, 679, 679, 683, 683, 685, 685, 687, 687, 688, 688, 692, 692, 694, 694, 696, 696, 697, 697, 701, 701, 703, 703, 705, 705, 706, 706, 709, 709, 711, 711, 713, 713, 714, 714, 718, 718, 719, 719, 721, 721, 0, 0, 0, 723, 723, 724, 724, 726, 726, 726, 727, 729, 730, 731, 731, 732, 733, 733, 733, 734, 735, 736, 737, 743, 744, 745, 746, 746, 747, 747, 748, 749, 749, 750, 751, 751, 752, 754, 754, 755, 756, 763, 764, 766, 767, 767, 768, 769, 771, 772, 772, 773, 773, 774, 774, 775, 775, 776, 776, 777, 777, 779, 781, 781, 782, 784, 786, 786, 0, 786, 786, 0, 0, 787, 788, 788, 788, 788, 788, 0, 788, 788, 788, 0, 0, 0, 0, 0, 789, 790, 790, 0, 790, 790, 790, 790, 790, 790, 0, 0, 0, 790, 790, 790, 0, 0, 0, 790, 790, 790, 0, 0, 0, 0, 0, 796, 796, 796, 796, 797, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 296, 301, 302, 303, 305, 308, 309, 311, 314, 318, 321, 325, 328, 329, 331, 332, 338, 339, 340, 341, 348, 349, 350, 351, 352, 364, 365, 366, 367, 368, 369, 370, 371, 374, 379, 380, 381, 387, 395, 396, 398, 399, 400, 401, 405, 406, 407, 408, 409, 412, 416, 419, 423, 425, 431, 432, 433, 436, 583, 584, 585, 586, 591, 592, 593, 593, 596, 598, 599, 600, 605, 606, 607, 608, 616, 617, 618, 619, 621, 623, 624, 625, 626, 627, 629, 630, 631, 634, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 694, 695, 697, 698, 699, 704, 705, 707, 708, 709, 714, 715, 717, 718, 719, 724, 725, 727, 728, 729, 734, 735, 737, 738, 739, 744, 745, 747, 748, 749, 754, 755, 757, 758, 759, 764, 765, 767, 768, 769, 774, 775, 777, 778, 779, 784, 785, 787, 788, 789, 794, 795, 798, 800, 801, 802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 818, 819, 820, 825, 826, 829, 833, 836, 836, 839, 841, 842, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 870, 871, 871, 874, 876, 877, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 907, 908, 911, 913, 914, 915, 916, 917, 918, 923, 924, 925, 927, 928, 929, 930, 935, 936, 937, 939, 940, 941, 941, 944, 946, 947, 948, 954, 955, 956, 957, 958, 959, 960, 965, 966, 967, 969, 974, 975, 976, 977, 978, 979, 993, 994, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1003, 1004, 1044, 1045, 1046, 1049, 1051, 1052, 1053, 1054, 1055, 1057, 1058, 1059, 1060, 1061, 1062, 1063, 1064, 1065, 1066, 1071, 1072, 1072, 1075, 1077, 1078, 1085, 1086, 1087, 1088, 1089, 1090, 1095, 1096, 1096, 1099, 1101, 1102, 1115, 1116, 1119, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1137, 1138, 1154, 1159, 1160, 1162, 1167, 1168, 1169, 1170, 1172, 1175, 1176, 1178, 1181, 1182, 1184, 1187, 1188, 1190, 1193, 1194, 1195, 1200, 1202, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1228, 1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1361, 1362, 1363, 1364, 1369, 1370, 1370, 1373, 1375, 1376, 1383, 1384, 1389, 1390, 1391, 1393, 1394, 1395, 1398, 1399, 1399, 1402, 1404, 1405, 1406, 1411, 1412, 1413, 1414, 1421, 1421, 1424, 1426, 1427, 1428, 1433, 1434, 1435, 1436, 1437, 1438, 1446, 1447, 1450, 1452, 1453, 1454, 1456, 1457, 1458, 1465, 1467, 1468, 1469, 1470, 1471, 1476, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1497, 1500, 1501, 1502, 1503, 1506, 1508, 1509, 1515, 1516, 1517, 1518, 1521, 1523, 1524, 1531, 1532, 1533, 1534, 1539, 1540, 1541, 1542, 1544, 1545, 1546, 1548, 1551, 1556, 1557, 1558, 1560, 1560, 1563, 1565, 1566, 1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1576, 1577, 1579, 1580, 1581, 1583, 1584, 1585, 1593, 1594, 1597, 1599, 1601, 1604, 1608, 1611, 1612, 1613, 1614, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1622, 1624, 1625, 1627, 1628, 1629, 1631, 1632, 1633, 1642, 1643, 1644, 1645, 1650, 1651, 1652, 1653, 1655, 1660, 1661, 1662, 1663, 1665, 1670, 1671, 1672, 1673, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1684, 1686, 1687, 1700, 1701, 1704, 1706, 1707, 1708, 1709, 1710, 1716, 1717, 1720, 1722, 1723, 1724, 1725, 1726, 1732, 1733, 1761, 1762, 1763, 1768, 1769, 1770, 1771, 1773, 1774, 1775, 1776, 1777, 1782, 1783, 1786, 1787, 1788, 1789, 1790, 1791, 1796, 1797, 1798, 1799, 1802, 1803, 1804, 1806, 1808, 1809, 1810, 1811, 1812, 1813, 1814, 1822, 1823, 1824, 1825, 1830, 1831, 1833, 1834, 1835, 1836, 1840, 1845, 1846, 1848, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1936, 1940, 1943, 1947, 1948, 1949, 1950, 1952, 1953, 1954, 1955, 1956, 1957, 1958, 1959, 1960, 1962, 1963, 1965, 1966, 1968, 1969, 1970, 1971, 1974, 1975, 1977, 1978, 1980, 1981, 1982, 1983, 1986, 1987, 1989, 1990, 1991, 1993, 1994, 1995, 1996, 1999, 2000, 2002, 2003, 2005, 2006, 2007, 2008, 2011, 2012, 2014, 2015, 2017, 2018, 2019, 2020, 2023, 2024, 2026, 2027, 2029, 2030, 2031, 2032, 2035, 2036, 2038, 2039, 2041, 2042, 2043, 2044, 2047, 2048, 2050, 2051, 2053, 2054, 2055, 2056, 2059, 2060, 2062, 2063, 2065, 2066, 2067, 2068, 2071, 2072, 2074, 2075, 2077, 2078, 2079, 2080, 2083, 2084, 2086, 2087, 2089, 2090, 2091, 2092, 2095, 2096, 2097, 2098, 2100, 2101, 2103, 2107, 2110, 2114, 2115, 2116, 2117, 2119, 2120, 2123, 2125, 2126, 2127, 2128, 2129, 2130, 2131, 2132, 2133, 2134, 2135, 2136, 2137, 2159, 2160, 2161, 2162, 2163, 2164, 2167, 2169, 2170, 2171, 2172, 2173, 2174, 2176, 2178, 2179, 2181, 2182, 2237, 2238, 2239, 2240, 2241, 2242, 2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2252, 2253, 2254, 2255, 2256, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2265, 2268, 2269, 2271, 2274, 2278, 2279, 2284, 2285, 2286, 2287, 2289, 2292, 2293, 2294, 2296, 2299, 2303, 2306, 2310, 2313, 2314, 2319, 2320, 2323, 2324, 2325, 2327, 2328, 2329, 2331, 2334, 2338, 2341, 2342, 2343, 2345, 2348, 2352, 2355, 2356, 2357, 2359, 2362, 2366, 2369, 2372, 2376, 2377, 2378, 2379, 2380, 2387, 2390, 2393, 2397, 2401, 2404, 2407, 2411, 2415, 2418, 2421, 2425, 2429, 2432, 2435, 2439, 2443, 2446, 2449, 2453, 2457, 2460, 2463, 2467, 2471, 2474, 2477, 2481, 2485, 2488, 2491, 2495, 2499, 2502, 2505, 2509, 2513, 2516, 2519, 2523, 2527, 2530, 2533, 2537, 2541, 2544, 2547, 2551, 2555, 2558, 2561, 2565, 2569, 2572, 2575, 2579, 2583, 2586, 2589, 2593, 2597, 2600, 2603, 2607, 2611, 2614, 2617, 2621, 2625, 2628, 2631, 2635, 2639, 2642, 2645, 2649, 2653, 2656, 2659, 2663, 2667, 2670, 2673, 2677, 2681, 2684, 2687, 2691, 2695, 2698, 2701, 2705, 2709, 2712, 2715, 2719, 2723, 2726, 2729, 2733, 2737, 2740, 2743, 2747, 2751, 2754, 2757, 2761, 2765, 2768, 2771, 2775, 2779, 2782, 2785, 2789, 2793, 2796, 2799, 2803, 2807, 2810, 2813, 2817, 2821, 2824, 2827, 2831, 2835, 2838, 2841, 2845, 2849, 2852, 2855, 2859, 2863, 2866, 2869, 2873, 2877, 2880, 2883, 2887, 2891, 2894, 2897, 2901, 2905, 2908, 2911, 2915, 2919, 2922, 2925, 2929, 2933, 2936, 2939, 2943, 2947, 2950, 2953, 2957, 2961, 2964, 2967, 2971, 2975, 2978, 2981, 2985, 2989, 2992, 2995, 2999, 3003, 3006, 3009, 3013, 3017, 3020, 3023, 3027, 3031, 3034, 3037, 3041, 3045, 3048, 3051, 3055, 3059, 3062, 3065, 3069, 3073, 3076, 3079, 3083, 3087, 3090, 3093, 3097, 3101, 3104, 3107, 3111, 3115, 3118, 3121, 3125, 3129, 3132, 3135, 3139, 3143, 3146, 3149, 3153, 3157, 3160, 3163, 3167, 3171, 3174, 3177, 3181, 3185, 3188, 3191, 3195, 3199, 3202, 3205, 3209, 3213, 3216, 3219, 3223, 3227, 3230, 3233, 3237, 3241, 3244, 3247, 3251, 3255, 3258, 3261, 3265, 3269, 3272, 3275, 3279, 3283, 3286, 3289, 3293, 3297, 3300, 3303, 3307, 3311, 3314, 3317, 3321, 3325, 3328, 3331, 3335, 3339, 3342, 3345, 3349, 3353, 3356, 3359, 3363, 3367, 3370, 3373, 3377, 3381, 3384, 3387, 3391, 3395, 3398, 3401, 3405, 3409, 3412, 3416};
/* BEGIN LINEINFO 
assign 1 52 257
new 0 52 257
assign 1 54 258
new 0 54 258
assign 1 55 259
new 0 55 259
assign 1 56 260
new 0 56 260
assign 1 57 261
new 0 57 261
assign 1 59 262
new 0 59 262
assign 1 60 263
new 0 60 263
assign 1 61 264
new 0 61 264
assign 1 62 265
new 0 62 265
assign 1 63 266
new 0 63 266
assign 1 64 267
new 0 64 267
assign 1 65 268
new 0 65 268
assign 1 69 269
new 0 69 269
assign 1 71 270
new 1 71 270
assign 1 72 271
ntypesGet 0 72 271
assign 1 73 272
twtokGet 0 73 272
assign 1 74 273
new 0 74 273
assign 1 74 274
new 1 74 274
assign 1 77 275
new 0 77 275
assign 1 80 276
new 0 80 276
assign 1 81 277
new 0 81 277
assign 1 82 278
new 0 82 278
assign 1 89 279
new 0 89 279
assign 1 90 280
new 0 90 280
assign 1 91 281
new 0 91 281
assign 1 92 282
new 0 92 282
assign 1 93 283
new 0 93 283
assign 1 93 284
new 1 93 284
assign 1 100 296
def 1 100 301
assign 1 100 302
new 0 100 302
assign 1 100 303
equals 1 100 303
assign 1 0 305
assign 1 100 308
new 0 100 308
assign 1 100 309
ends 1 100 309
assign 1 0 311
assign 1 0 314
assign 1 0 318
assign 1 0 321
assign 1 0 325
assign 1 101 328
new 0 101 328
return 1 101 329
assign 1 103 331
new 0 103 331
return 1 103 332
assign 1 107 338
new 0 107 338
assign 1 107 339
new 0 107 339
assign 1 107 340
swap 2 107 340
return 1 107 341
assign 1 111 348
new 0 111 348
assign 1 111 349
argsGet 0 111 349
assign 1 112 350
new 0 112 350
assign 1 112 351
main 1 112 351
exit 1 112 352
assign 1 116 364
assign 1 117 365
new 1 117 365
assign 1 118 366
new 0 118 366
assign 1 118 367
new 0 118 367
assign 1 118 368
get 2 118 368
assign 1 118 369
firstGet 0 118 369
assign 1 118 370
new 1 118 370
assign 1 119 371
new 0 119 371
assign 1 119 374
lesser 1 119 379
assign 1 120 380
go 0 120 380
incrementValue 0 119 381
return 1 122 387
assign 1 126 395
new 0 126 395
assign 1 127 396
new 0 127 396
config 0 129 398
assign 1 130 399
new 0 130 399
assign 1 131 400
doWhat 0 131 400
assign 1 132 401
new 0 132 401
assign 1 134 405
toString 0 134 405
assign 1 135 406
new 0 135 406
assign 1 136 407
new 0 136 407
assign 1 136 408
add 1 136 408
assign 1 137 409
new 0 137 409
assign 1 0 412
assign 1 0 416
assign 1 0 419
print 0 140 423
return 1 142 425
assign 1 146 431
nameGet 0 146 431
assign 1 146 432
new 0 146 432
assign 1 146 433
equals 1 146 433
return 1 148 436
assign 1 153 583
new 0 153 583
assign 1 155 584
new 0 155 584
assign 1 156 585
get 1 156 585
assign 1 156 586
def 1 156 591
assign 1 157 592
get 1 157 592
assign 1 157 593
iteratorGet 0 0 593
assign 1 157 596
hasNextGet 0 157 596
assign 1 157 598
nextGet 0 157 598
assign 1 158 599
has 1 158 599
assign 1 158 600
not 0 158 605
put 1 159 606
assign 1 160 607
new 1 160 607
addFile 1 160 608
assign 1 165 616
new 0 165 616
assign 1 165 617
nameGet 0 165 617
assign 1 165 618
new 0 165 618
assign 1 165 619
equals 1 165 619
preProcessorSet 1 166 621
assign 1 168 623
new 0 168 623
assign 1 168 624
get 1 168 624
assign 1 168 625
firstGet 0 168 625
assign 1 169 626
new 0 169 626
assign 1 169 627
has 1 169 627
assign 1 170 629
new 0 170 629
assign 1 170 630
get 1 170 630
assign 1 170 631
firstGet 0 170 631
assign 1 172 634
assign 1 174 636
new 0 174 636
assign 1 174 637
new 0 174 637
assign 1 174 638
get 2 174 638
assign 1 174 639
firstGet 0 174 639
assign 1 174 640
new 1 174 640
assign 1 174 641
pathGet 0 174 641
addStep 1 175 642
assign 1 176 643
new 0 176 643
addStep 1 176 644
assign 1 177 645
new 0 177 645
assign 1 177 646
new 0 177 646
assign 1 177 647
get 2 177 647
assign 1 177 648
firstGet 0 177 648
assign 1 177 649
new 1 177 649
assign 1 177 650
pathGet 0 177 650
assign 1 178 651
new 0 178 651
assign 1 178 652
new 0 178 652
assign 1 178 653
nameGet 0 178 653
assign 1 178 654
get 2 178 654
assign 1 178 655
firstGet 0 178 655
assign 1 178 656
new 1 178 656
assign 1 179 657
new 0 179 657
assign 1 179 658
nameGet 0 179 658
assign 1 179 659
get 2 179 659
assign 1 179 660
firstGet 0 179 660
assign 1 179 661
new 1 179 661
assign 1 180 662
new 0 180 662
assign 1 180 663
new 0 180 663
assign 1 180 664
get 2 180 664
assign 1 180 665
firstGet 0 180 665
assign 1 180 666
new 1 180 666
assign 1 181 667
new 0 181 667
assign 1 181 668
new 0 181 668
assign 1 181 669
get 2 181 669
assign 1 181 670
firstGet 0 181 670
assign 1 181 671
new 1 181 671
assign 1 182 672
new 0 182 672
assign 1 182 673
new 0 182 673
assign 1 182 674
get 2 182 674
assign 1 182 675
firstGet 0 182 675
assign 1 182 676
new 1 182 676
assign 1 183 677
new 0 183 677
assign 1 183 678
get 1 183 678
assign 1 184 679
new 0 184 679
assign 1 184 680
get 1 184 680
assign 1 186 681
new 0 186 681
assign 1 186 682
get 1 186 682
assign 1 186 683
firstGet 0 186 683
assign 1 187 684
new 0 187 684
assign 1 187 685
get 1 187 685
assign 1 187 686
firstGet 0 187 686
assign 1 188 687
new 0 188 687
assign 1 188 688
get 1 188 688
assign 1 189 689
undef 1 189 694
assign 1 190 695
new 0 190 695
assign 1 192 697
new 0 192 697
assign 1 192 698
get 1 192 698
assign 1 193 699
undef 1 193 704
assign 1 194 705
new 0 194 705
assign 1 196 707
new 0 196 707
assign 1 196 708
get 1 196 708
assign 1 197 709
undef 1 197 714
assign 1 198 715
new 0 198 715
assign 1 200 717
new 0 200 717
assign 1 200 718
get 1 200 718
assign 1 201 719
undef 1 201 724
assign 1 202 725
new 0 202 725
assign 1 204 727
new 0 204 727
assign 1 204 728
get 1 204 728
assign 1 205 729
undef 1 205 734
assign 1 206 735
new 0 206 735
assign 1 208 737
new 0 208 737
assign 1 208 738
get 1 208 738
assign 1 209 739
undef 1 209 744
assign 1 210 745
new 0 210 745
assign 1 212 747
new 0 212 747
assign 1 212 748
get 1 212 748
assign 1 213 749
undef 1 213 754
assign 1 214 755
new 0 214 755
assign 1 216 757
new 0 216 757
assign 1 216 758
get 1 216 758
assign 1 217 759
undef 1 217 764
assign 1 218 765
new 0 218 765
assign 1 220 767
new 0 220 767
assign 1 220 768
get 1 220 768
assign 1 221 769
undef 1 221 774
assign 1 222 775
new 0 222 775
assign 1 224 777
new 0 224 777
assign 1 224 778
get 1 224 778
assign 1 225 779
def 1 225 784
assign 1 226 785
firstGet 0 226 785
assign 1 228 787
new 0 228 787
assign 1 228 788
get 1 228 788
assign 1 229 789
def 1 229 794
assign 1 230 795
firstGet 0 230 795
assign 1 232 798
new 0 232 798
assign 1 234 800
new 0 234 800
assign 1 234 801
new 0 234 801
assign 1 234 802
isTrue 2 234 802
assign 1 235 803
new 0 235 803
assign 1 235 804
new 0 235 804
assign 1 235 805
isTrue 2 235 805
assign 1 236 806
new 0 236 806
assign 1 236 807
isTrue 1 236 807
assign 1 237 808
new 0 237 808
assign 1 237 809
isTrue 1 237 809
assign 1 238 810
new 0 238 810
assign 1 239 811
new 0 239 811
assign 1 239 812
get 1 239 812
assign 1 240 813
def 1 240 818
assign 1 240 819
isEmptyGet 0 240 819
assign 1 240 820
not 0 240 825
assign 1 0 826
assign 1 0 829
assign 1 0 833
assign 1 241 836
linkedListIteratorGet 0 0 836
assign 1 241 839
hasNextGet 0 241 839
assign 1 241 841
nextGet 0 241 841
put 1 242 842
assign 1 245 849
new 0 245 849
assign 1 245 850
isTrue 1 245 850
assign 1 246 851
new 0 246 851
assign 1 246 852
isTrue 1 246 852
assign 1 247 853
new 0 247 853
assign 1 247 854
isTrue 1 247 854
assign 1 248 855
new 0 248 855
assign 1 248 856
isTrue 1 248 856
assign 1 249 857
new 0 249 857
assign 1 249 858
new 0 249 858
assign 1 249 859
isTrue 2 249 859
assign 1 250 860
new 0 250 860
assign 1 250 861
get 1 250 861
assign 1 251 862
new 0 251 862
assign 1 251 863
get 1 251 863
assign 1 252 864
new 0 252 864
assign 1 253 865
def 1 253 870
assign 1 254 871
linkedListIteratorGet 0 0 871
assign 1 254 874
hasNextGet 0 254 874
assign 1 254 876
nextGet 0 254 876
addValue 1 256 877
assign 1 259 884
new 0 259 884
assign 1 259 885
new 0 259 885
assign 1 259 886
get 2 259 886
assign 1 259 887
firstGet 0 259 887
assign 1 260 888
new 0 260 888
assign 1 260 889
new 0 260 889
assign 1 260 890
get 2 260 890
assign 1 260 891
firstGet 0 260 891
assign 1 261 892
new 0 261 892
assign 1 261 893
add 1 261 893
assign 1 261 894
new 0 261 894
assign 1 261 895
get 2 261 895
assign 1 261 896
firstGet 0 261 896
assign 1 262 897
new 0 262 897
assign 1 263 898
new 0 263 898
assign 1 264 899
new 0 264 899
assign 1 265 900
new 0 265 900
assign 1 266 901
new 0 266 901
assign 1 269 902
def 1 269 907
assign 1 270 908
firstGet 0 270 908
assign 1 272 911
new 0 272 911
assign 1 279 913
new 0 279 913
assign 1 279 914
add 1 279 914
assign 1 279 915
nameGet 0 279 915
assign 1 279 916
add 1 279 916
assign 1 279 917
get 1 279 917
assign 1 280 918
def 1 280 923
assign 1 281 924
orderedGet 0 281 924
addAll 1 281 925
assign 1 284 927
new 0 284 927
assign 1 284 928
add 1 284 928
assign 1 284 929
get 1 284 929
assign 1 285 930
def 1 285 935
assign 1 286 936
orderedGet 0 286 936
addAll 1 286 937
assign 1 289 939
new 0 289 939
assign 1 290 940
orderedGet 0 290 940
assign 1 290 941
iteratorGet 0 0 941
assign 1 290 944
hasNextGet 0 290 944
assign 1 290 946
nextGet 0 290 946
assign 1 291 947
new 1 291 947
addValue 1 291 948
assign 1 293 954
newlineGet 0 293 954
assign 1 294 955
assign 1 295 956
new 1 295 956
assign 1 297 957
copy 0 297 957
assign 1 298 958
fileGet 0 298 958
assign 1 298 959
existsGet 0 298 959
assign 1 298 960
not 0 298 965
assign 1 299 966
fileGet 0 299 966
makeDirs 0 299 967
assign 1 301 969
def 1 301 974
assign 1 302 975
new 1 302 975
assign 1 302 976
readerGet 0 302 976
assign 1 303 977
open 0 303 977
assign 1 303 978
readString 0 303 978
close 0 304 979
assign 1 310 993
classNameGet 0 310 993
assign 1 311 994
add 1 311 994
assign 1 311 995
new 0 311 995
assign 1 311 996
add 1 311 996
assign 1 311 997
toString 0 311 997
assign 1 311 998
add 1 311 998
assign 1 312 999
add 1 312 999
assign 1 312 1000
new 0 312 1000
assign 1 312 1001
add 1 312 1001
assign 1 312 1002
toString 0 312 1002
assign 1 312 1003
add 1 312 1003
return 1 313 1004
assign 1 317 1044
new 0 317 1044
assign 1 318 1045
classesGet 0 318 1045
assign 1 318 1046
valueIteratorGet 0 318 1046
assign 1 318 1049
hasNextGet 0 318 1049
assign 1 319 1051
nextGet 0 319 1051
assign 1 320 1052
shouldEmitGet 0 320 1052
assign 1 320 1053
heldGet 0 320 1053
assign 1 320 1054
fromFileGet 0 320 1054
assign 1 320 1055
has 1 320 1055
assign 1 321 1057
heldGet 0 321 1057
assign 1 321 1058
namepathGet 0 321 1058
assign 1 321 1059
toString 0 321 1059
put 1 321 1060
assign 1 322 1061
usedByGet 0 322 1061
assign 1 322 1062
heldGet 0 322 1062
assign 1 322 1063
namepathGet 0 322 1063
assign 1 322 1064
toString 0 322 1064
assign 1 322 1065
get 1 322 1065
assign 1 323 1066
def 1 323 1071
assign 1 324 1072
setIteratorGet 0 0 1072
assign 1 324 1075
hasNextGet 0 324 1075
assign 1 324 1077
nextGet 0 324 1077
put 1 325 1078
assign 1 328 1085
subClassesGet 0 328 1085
assign 1 328 1086
heldGet 0 328 1086
assign 1 328 1087
namepathGet 0 328 1087
assign 1 328 1088
toString 0 328 1088
assign 1 328 1089
get 1 328 1089
assign 1 329 1090
def 1 329 1095
assign 1 330 1096
setIteratorGet 0 0 1096
assign 1 330 1099
hasNextGet 0 330 1099
assign 1 330 1101
nextGet 0 330 1101
put 1 331 1102
assign 1 336 1115
classesGet 0 336 1115
assign 1 336 1116
valueIteratorGet 0 336 1116
assign 1 336 1119
hasNextGet 0 336 1119
assign 1 337 1121
nextGet 0 337 1121
assign 1 338 1122
heldGet 0 338 1122
assign 1 338 1123
heldGet 0 338 1123
assign 1 338 1124
namepathGet 0 338 1124
assign 1 338 1125
toString 0 338 1125
assign 1 338 1126
has 1 338 1126
shouldWriteSet 1 338 1127
assign 1 345 1137
new 0 345 1137
return 1 345 1138
assign 1 349 1154
def 1 349 1159
return 1 350 1160
assign 1 355 1162
def 1 355 1167
assign 1 356 1168
firstGet 0 356 1168
assign 1 357 1169
new 0 357 1169
assign 1 357 1170
equals 1 357 1170
assign 1 358 1172
new 1 358 1172
assign 1 359 1175
new 0 359 1175
assign 1 359 1176
equals 1 359 1176
assign 1 360 1178
new 1 360 1178
assign 1 361 1181
new 0 361 1181
assign 1 361 1182
equals 1 361 1182
assign 1 362 1184
new 1 362 1184
assign 1 363 1187
new 0 363 1187
assign 1 363 1188
equals 1 363 1188
assign 1 364 1190
new 1 364 1190
assign 1 368 1193
new 0 368 1193
assign 1 368 1194
new 1 368 1194
throw 1 368 1195
return 1 370 1200
return 1 372 1202
assign 1 376 1221
apNew 1 376 1221
assign 1 378 1222
new 0 378 1222
assign 1 378 1223
add 1 378 1223
print 0 378 1224
assign 1 379 1225
new 0 379 1225
assign 1 379 1226
now 0 379 1226
assign 1 380 1227
fileGet 0 380 1227
assign 1 380 1228
readerGet 0 380 1228
assign 1 380 1229
open 0 380 1229
assign 1 381 1230
new 0 381 1230
assign 1 381 1231
deserialize 1 381 1231
close 0 382 1232
assign 1 383 1233
synClassesGet 0 383 1233
addValue 1 383 1234
assign 1 384 1235
new 0 384 1235
assign 1 384 1236
now 0 384 1236
assign 1 384 1237
subtract 1 384 1237
assign 1 385 1238
new 0 385 1238
assign 1 385 1239
add 1 385 1239
print 0 385 1240
assign 1 391 1361
new 0 391 1361
assign 1 391 1362
now 0 391 1362
assign 1 392 1363
new 0 392 1363
assign 1 393 1364
def 1 393 1369
assign 1 394 1370
linkedListIteratorGet 0 0 1370
assign 1 394 1373
hasNextGet 0 394 1373
assign 1 394 1375
nextGet 0 394 1375
loadSyns 1 395 1376
assign 1 398 1383
emitterGet 0 398 1383
assign 1 399 1384
def 1 399 1389
assign 1 400 1390
new 4 400 1390
put 1 401 1391
assign 1 403 1393
new 0 403 1393
assign 1 403 1394
add 1 403 1394
print 0 403 1395
assign 1 406 1398
new 0 406 1398
assign 1 408 1399
iteratorGet 0 0 1399
assign 1 408 1402
hasNextGet 0 408 1402
assign 1 408 1404
nextGet 0 408 1404
assign 1 409 1405
has 1 409 1405
assign 1 409 1406
not 0 409 1411
put 1 410 1412
assign 1 411 1413
new 2 411 1413
addValue 1 412 1414
assign 1 415 1421
iteratorGet 0 0 1421
assign 1 415 1424
hasNextGet 0 415 1424
assign 1 415 1426
nextGet 0 415 1426
assign 1 416 1427
has 1 416 1427
assign 1 416 1428
not 0 416 1433
put 1 417 1434
assign 1 418 1435
new 2 418 1435
addValue 1 419 1436
assign 1 420 1437
libNameGet 0 420 1437
put 1 420 1438
assign 1 425 1446
new 0 425 1446
assign 1 426 1447
iteratorGet 0 426 1447
assign 1 426 1450
hasNextGet 0 426 1450
assign 1 427 1452
nextGet 0 427 1452
assign 1 429 1453
toString 0 429 1453
assign 1 429 1454
has 1 429 1454
assign 1 430 1456
toString 0 430 1456
put 1 430 1457
doParse 1 431 1458
buildSyns 1 434 1465
assign 1 437 1467
new 0 437 1467
assign 1 437 1468
now 0 437 1468
assign 1 437 1469
subtract 1 437 1469
assign 1 440 1470
emitCommonGet 0 440 1470
assign 1 440 1471
def 1 440 1476
assign 1 442 1477
new 0 442 1477
assign 1 442 1478
now 0 442 1478
assign 1 443 1479
emitCommonGet 0 443 1479
doEmit 0 443 1480
assign 1 444 1481
new 0 444 1481
assign 1 444 1482
now 0 444 1482
assign 1 444 1483
subtract 1 444 1483
assign 1 445 1484
new 0 445 1484
assign 1 445 1485
now 0 445 1485
assign 1 445 1486
subtract 1 445 1486
assign 1 446 1487
new 0 446 1487
assign 1 446 1488
add 1 446 1488
print 0 446 1489
assign 1 447 1490
new 0 447 1490
assign 1 447 1491
add 1 447 1491
print 0 447 1492
assign 1 448 1493
new 0 448 1493
assign 1 448 1494
add 1 448 1494
print 0 448 1495
assign 1 449 1496
new 0 449 1496
return 1 449 1497
setClassesToWrite 0 452 1500
libnameInfoGet 0 453 1501
assign 1 455 1502
classesGet 0 455 1502
assign 1 455 1503
valueIteratorGet 0 455 1503
assign 1 455 1506
hasNextGet 0 455 1506
assign 1 456 1508
nextGet 0 456 1508
doEmit 1 457 1509
emitMain 0 459 1515
emitCUInit 0 460 1516
assign 1 461 1517
classesGet 0 461 1517
assign 1 461 1518
valueIteratorGet 0 461 1518
assign 1 461 1521
hasNextGet 0 461 1521
assign 1 462 1523
nextGet 0 462 1523
emitSyn 1 463 1524
assign 1 467 1531
new 0 467 1531
assign 1 467 1532
now 0 467 1532
assign 1 467 1533
subtract 1 467 1533
assign 1 468 1534
def 1 468 1539
assign 1 469 1540
new 0 469 1540
assign 1 469 1541
add 1 469 1541
print 0 469 1542
assign 1 471 1544
new 0 471 1544
assign 1 471 1545
add 1 471 1545
print 0 471 1546
prepMake 1 474 1548
assign 1 478 1551
not 0 478 1556
make 1 479 1557
deployLibrary 1 480 1558
assign 1 482 1560
linkedListIteratorGet 0 0 1560
assign 1 482 1563
hasNextGet 0 482 1563
assign 1 482 1565
nextGet 0 482 1565
assign 1 483 1566
libnameInfoGet 0 483 1566
assign 1 483 1567
unitShlibGet 0 483 1567
assign 1 484 1568
emitPathGet 0 484 1568
assign 1 484 1569
copy 0 484 1569
assign 1 485 1570
stepsGet 0 485 1570
assign 1 485 1571
lastGet 0 485 1571
addStep 1 485 1572
assign 1 486 1573
fileGet 0 486 1573
assign 1 486 1574
existsGet 0 486 1574
assign 1 487 1576
fileGet 0 487 1576
delete 0 487 1577
assign 1 489 1579
fileGet 0 489 1579
assign 1 489 1580
existsGet 0 489 1580
assign 1 489 1581
not 0 489 1581
assign 1 490 1583
fileGet 0 490 1583
assign 1 490 1584
fileGet 0 490 1584
deployFile 2 490 1585
assign 1 494 1593
iteratorGet 0 494 1593
assign 1 495 1594
iteratorGet 0 495 1594
assign 1 497 1597
hasNextGet 0 497 1597
assign 1 497 1599
hasNextGet 0 497 1599
assign 1 0 1601
assign 1 0 1604
assign 1 0 1608
assign 1 498 1611
nextGet 0 498 1611
assign 1 498 1612
apNew 1 498 1612
assign 1 499 1613
emitPathGet 0 499 1613
assign 1 499 1614
copy 0 499 1614
assign 1 499 1615
toString 0 499 1615
assign 1 499 1616
new 0 499 1616
assign 1 499 1617
add 1 499 1617
assign 1 499 1618
nextGet 0 499 1618
assign 1 499 1619
add 1 499 1619
assign 1 499 1620
apNew 1 499 1620
assign 1 501 1621
fileGet 0 501 1621
assign 1 501 1622
existsGet 0 501 1622
assign 1 502 1624
fileGet 0 502 1624
delete 0 502 1625
assign 1 504 1627
fileGet 0 504 1627
assign 1 504 1628
existsGet 0 504 1628
assign 1 504 1629
not 0 504 1629
assign 1 505 1631
fileGet 0 505 1631
assign 1 505 1632
fileGet 0 505 1632
deployFile 2 505 1633
assign 1 510 1642
new 0 510 1642
assign 1 510 1643
now 0 510 1643
assign 1 510 1644
subtract 1 510 1644
assign 1 512 1645
def 1 512 1650
assign 1 513 1651
new 0 513 1651
assign 1 513 1652
add 1 513 1652
print 0 513 1653
assign 1 515 1655
def 1 515 1660
assign 1 516 1661
new 0 516 1661
assign 1 516 1662
add 1 516 1662
print 0 516 1663
assign 1 518 1665
def 1 518 1670
assign 1 519 1671
new 0 519 1671
assign 1 519 1672
add 1 519 1672
print 0 519 1673
assign 1 523 1676
new 0 523 1676
print 0 523 1677
assign 1 524 1678
run 2 524 1678
assign 1 525 1679
new 0 525 1679
assign 1 525 1680
add 1 525 1680
assign 1 525 1681
new 0 525 1681
assign 1 525 1682
add 1 525 1682
print 0 525 1683
return 1 526 1684
assign 1 528 1686
new 0 528 1686
return 1 528 1687
assign 1 532 1700
justParsedGet 0 532 1700
assign 1 532 1701
valueIteratorGet 0 532 1701
assign 1 532 1704
hasNextGet 0 532 1704
assign 1 533 1706
nextGet 0 533 1706
assign 1 534 1707
heldGet 0 534 1707
libNameSet 1 534 1708
assign 1 535 1709
getSyn 2 535 1709
libNameSet 1 536 1710
assign 1 538 1716
justParsedGet 0 538 1716
assign 1 538 1717
valueIteratorGet 0 538 1717
assign 1 538 1720
hasNextGet 0 538 1720
assign 1 539 1722
nextGet 0 539 1722
assign 1 540 1723
heldGet 0 540 1723
assign 1 540 1724
synGet 0 540 1724
checkInheritance 2 541 1725
integrate 1 542 1726
assign 1 544 1732
new 0 544 1732
justParsedSet 1 544 1733
assign 1 548 1761
heldGet 0 548 1761
assign 1 548 1762
synGet 0 548 1762
assign 1 548 1763
def 1 548 1768
assign 1 549 1769
heldGet 0 549 1769
assign 1 549 1770
synGet 0 549 1770
return 1 549 1771
assign 1 551 1773
heldGet 0 551 1773
libNameSet 1 551 1774
assign 1 552 1775
heldGet 0 552 1775
assign 1 552 1776
extendsGet 0 552 1776
assign 1 552 1777
undef 1 552 1782
assign 1 553 1783
new 1 553 1783
assign 1 555 1786
classesGet 0 555 1786
assign 1 555 1787
heldGet 0 555 1787
assign 1 555 1788
extendsGet 0 555 1788
assign 1 555 1789
toString 0 555 1789
assign 1 555 1790
get 1 555 1790
assign 1 557 1791
def 1 557 1796
assign 1 558 1797
heldGet 0 558 1797
libNameSet 1 558 1798
assign 1 559 1799
getSyn 2 559 1799
assign 1 563 1802
heldGet 0 563 1802
assign 1 563 1803
extendsGet 0 563 1803
assign 1 563 1804
getSynNp 1 563 1804
assign 1 565 1806
new 2 565 1806
assign 1 567 1808
heldGet 0 567 1808
synSet 1 567 1809
assign 1 568 1810
heldGet 0 568 1810
assign 1 568 1811
namepathGet 0 568 1811
assign 1 568 1812
toString 0 568 1812
addSynClass 2 568 1813
return 1 569 1814
assign 1 573 1822
toString 0 573 1822
assign 1 574 1823
synClassesGet 0 574 1823
assign 1 574 1824
get 1 574 1824
assign 1 575 1825
def 1 575 1830
return 1 576 1831
assign 1 582 1833
emitterGet 0 582 1833
assign 1 582 1834
loadSyn 1 582 1834
addSynClass 2 583 1835
return 1 584 1836
assign 1 591 1840
undef 1 591 1845
assign 1 592 1846
new 1 592 1846
return 1 594 1848
assign 1 599 1927
new 1 599 1927
assign 1 600 1928
new 0 600 1928
assign 1 601 1929
emitterGet 0 601 1929
assign 1 602 1930
assign 1 603 1931
new 0 603 1931
assign 1 604 1932
shouldEmitGet 0 604 1932
put 1 604 1933
assign 1 0 1936
assign 1 0 1940
assign 1 0 1943
assign 1 607 1947
new 0 607 1947
assign 1 607 1948
toString 0 607 1948
assign 1 607 1949
add 1 607 1949
print 0 607 1950
assign 1 609 1952
assign 1 611 1953
fileGet 0 611 1953
assign 1 611 1954
readerGet 0 611 1954
assign 1 611 1955
open 0 611 1955
assign 1 611 1956
readBuffer 1 611 1956
assign 1 612 1957
fileGet 0 612 1957
assign 1 612 1958
readerGet 0 612 1958
close 0 612 1959
assign 1 615 1960
tokenize 1 615 1960
assign 1 619 1962
new 0 619 1962
echo 0 619 1963
assign 1 621 1965
outermostGet 0 621 1965
nodify 2 621 1966
assign 1 623 1968
new 0 623 1968
print 0 623 1969
assign 1 624 1970
new 2 624 1970
traverse 1 624 1971
assign 1 628 1974
new 0 628 1974
echo 0 628 1975
assign 1 630 1977
new 0 630 1977
traverse 1 630 1978
assign 1 632 1980
new 0 632 1980
print 0 632 1981
assign 1 633 1982
new 2 633 1982
traverse 1 633 1983
assign 1 636 1986
new 0 636 1986
echo 0 636 1987
assign 1 639 1989
new 0 639 1989
traverse 1 639 1990
contain 0 640 1991
assign 1 642 1993
new 0 642 1993
print 0 642 1994
assign 1 643 1995
new 2 643 1995
traverse 1 643 1996
assign 1 647 1999
new 0 647 1999
echo 0 647 2000
assign 1 649 2002
new 0 649 2002
traverse 1 649 2003
assign 1 651 2005
new 0 651 2005
print 0 651 2006
assign 1 652 2007
new 2 652 2007
traverse 1 652 2008
assign 1 656 2011
new 0 656 2011
echo 0 656 2012
assign 1 658 2014
new 0 658 2014
traverse 1 658 2015
assign 1 660 2017
new 0 660 2017
print 0 660 2018
assign 1 661 2019
new 2 661 2019
traverse 1 661 2020
assign 1 665 2023
new 0 665 2023
echo 0 665 2024
assign 1 667 2026
new 0 667 2026
traverse 1 667 2027
assign 1 669 2029
new 0 669 2029
print 0 669 2030
assign 1 670 2031
new 2 670 2031
traverse 1 670 2032
assign 1 674 2035
new 0 674 2035
echo 0 674 2036
assign 1 676 2038
new 0 676 2038
traverse 1 676 2039
assign 1 678 2041
new 0 678 2041
print 0 678 2042
assign 1 679 2043
new 2 679 2043
traverse 1 679 2044
assign 1 683 2047
new 0 683 2047
echo 0 683 2048
assign 1 685 2050
new 0 685 2050
traverse 1 685 2051
assign 1 687 2053
new 0 687 2053
print 0 687 2054
assign 1 688 2055
new 2 688 2055
traverse 1 688 2056
assign 1 692 2059
new 0 692 2059
echo 0 692 2060
assign 1 694 2062
new 0 694 2062
traverse 1 694 2063
assign 1 696 2065
new 0 696 2065
print 0 696 2066
assign 1 697 2067
new 2 697 2067
traverse 1 697 2068
assign 1 701 2071
new 0 701 2071
echo 0 701 2072
assign 1 703 2074
new 0 703 2074
traverse 1 703 2075
assign 1 705 2077
new 0 705 2077
print 0 705 2078
assign 1 706 2079
new 2 706 2079
traverse 1 706 2080
assign 1 709 2083
new 0 709 2083
echo 0 709 2084
assign 1 711 2086
new 0 711 2086
traverse 1 711 2087
assign 1 713 2089
new 0 713 2089
print 0 713 2090
assign 1 714 2091
new 2 714 2091
traverse 1 714 2092
assign 1 718 2095
new 0 718 2095
echo 0 718 2096
assign 1 719 2097
new 0 719 2097
print 0 719 2098
assign 1 721 2100
new 0 721 2100
traverse 1 721 2101
assign 1 0 2103
assign 1 0 2107
assign 1 0 2110
assign 1 723 2114
new 0 723 2114
print 0 723 2115
assign 1 724 2116
new 2 724 2116
traverse 1 724 2117
assign 1 726 2119
classesGet 0 726 2119
assign 1 726 2120
valueIteratorGet 0 726 2120
assign 1 726 2123
hasNextGet 0 726 2123
assign 1 727 2125
nextGet 0 727 2125
assign 1 729 2126
transUnitGet 0 729 2126
assign 1 730 2127
new 1 730 2127
assign 1 731 2128
TRANSUNITGet 0 731 2128
typenameSet 1 731 2129
assign 1 732 2130
new 0 732 2130
assign 1 733 2131
heldGet 0 733 2131
assign 1 733 2132
emitsGet 0 733 2132
emitsSet 1 733 2133
heldSet 1 734 2134
delete 0 735 2135
addValue 1 736 2136
copyLoc 1 737 2137
reInitContained 0 743 2159
assign 1 744 2160
containedGet 0 744 2160
assign 1 745 2161
new 0 745 2161
assign 1 746 2162
new 0 746 2162
assign 1 746 2163
crGet 0 746 2163
assign 1 747 2164
linkedListIteratorGet 0 747 2164
assign 1 747 2167
hasNextGet 0 747 2167
assign 1 748 2169
new 1 748 2169
assign 1 749 2170
nextGet 0 749 2170
heldSet 1 749 2171
nlcSet 1 750 2172
assign 1 751 2173
heldGet 0 751 2173
assign 1 751 2174
equals 1 751 2174
assign 1 752 2176
increment 0 752 2176
assign 1 754 2178
heldGet 0 754 2178
assign 1 754 2179
notEquals 1 754 2179
addValue 1 755 2181
containerSet 1 756 2182
assign 1 763 2237
new 0 763 2237
fromString 1 764 2238
assign 1 766 2239
new 1 766 2239
assign 1 767 2240
NAMEPATHGet 0 767 2240
typenameSet 1 767 2241
heldSet 1 768 2242
copyLoc 1 769 2243
assign 1 771 2244
new 0 771 2244
assign 1 772 2245
new 0 772 2245
nameSet 1 772 2246
assign 1 773 2247
new 0 773 2247
wasBoundSet 1 773 2248
assign 1 774 2249
new 0 774 2249
boundSet 1 774 2250
assign 1 775 2251
new 0 775 2251
isConstructSet 1 775 2252
assign 1 776 2253
new 0 776 2253
isLiteralSet 1 776 2254
assign 1 777 2255
heldGet 0 777 2255
literalValueSet 1 777 2256
addValue 1 779 2257
assign 1 781 2258
CALLGet 0 781 2258
typenameSet 1 781 2259
heldSet 1 782 2260
resolveNp 0 784 2261
assign 1 786 2262
new 0 786 2262
assign 1 786 2263
equals 1 786 2263
assign 1 0 2265
assign 1 786 2268
new 0 786 2268
assign 1 786 2269
equals 1 786 2269
assign 1 0 2271
assign 1 0 2274
assign 1 787 2278
priorPeerGet 0 787 2278
assign 1 788 2279
def 1 788 2284
assign 1 788 2285
typenameGet 0 788 2285
assign 1 788 2286
SUBTRACTGet 0 788 2286
assign 1 788 2287
equals 1 788 2287
assign 1 0 2289
assign 1 788 2292
typenameGet 0 788 2292
assign 1 788 2293
ADDGet 0 788 2293
assign 1 788 2294
equals 1 788 2294
assign 1 0 2296
assign 1 0 2299
assign 1 0 2303
assign 1 0 2306
assign 1 0 2310
assign 1 789 2313
priorPeerGet 0 789 2313
assign 1 790 2314
undef 1 790 2319
assign 1 0 2320
assign 1 790 2323
typenameGet 0 790 2323
assign 1 790 2324
CALLGet 0 790 2324
assign 1 790 2325
notEquals 1 790 2325
assign 1 790 2327
typenameGet 0 790 2327
assign 1 790 2328
IDGet 0 790 2328
assign 1 790 2329
notEquals 1 790 2329
assign 1 0 2331
assign 1 0 2334
assign 1 0 2338
assign 1 790 2341
typenameGet 0 790 2341
assign 1 790 2342
VARGet 0 790 2342
assign 1 790 2343
notEquals 1 790 2343
assign 1 0 2345
assign 1 0 2348
assign 1 0 2352
assign 1 790 2355
typenameGet 0 790 2355
assign 1 790 2356
ACCESSORGet 0 790 2356
assign 1 790 2357
notEquals 1 790 2357
assign 1 0 2359
assign 1 0 2362
assign 1 0 2366
assign 1 0 2369
assign 1 0 2372
assign 1 796 2376
heldGet 0 796 2376
assign 1 796 2377
literalValueGet 0 796 2377
assign 1 796 2378
add 1 796 2378
literalValueSet 1 796 2379
delete 0 797 2380
return 1 0 2387
return 1 0 2390
assign 1 0 2393
assign 1 0 2397
return 1 0 2401
return 1 0 2404
assign 1 0 2407
assign 1 0 2411
return 1 0 2415
return 1 0 2418
assign 1 0 2421
assign 1 0 2425
return 1 0 2429
return 1 0 2432
assign 1 0 2435
assign 1 0 2439
return 1 0 2443
return 1 0 2446
assign 1 0 2449
assign 1 0 2453
return 1 0 2457
return 1 0 2460
assign 1 0 2463
assign 1 0 2467
return 1 0 2471
return 1 0 2474
assign 1 0 2477
assign 1 0 2481
return 1 0 2485
return 1 0 2488
assign 1 0 2491
assign 1 0 2495
return 1 0 2499
return 1 0 2502
assign 1 0 2505
assign 1 0 2509
return 1 0 2513
return 1 0 2516
assign 1 0 2519
assign 1 0 2523
return 1 0 2527
return 1 0 2530
assign 1 0 2533
assign 1 0 2537
return 1 0 2541
return 1 0 2544
assign 1 0 2547
assign 1 0 2551
return 1 0 2555
return 1 0 2558
assign 1 0 2561
assign 1 0 2565
return 1 0 2569
return 1 0 2572
assign 1 0 2575
assign 1 0 2579
return 1 0 2583
return 1 0 2586
assign 1 0 2589
assign 1 0 2593
return 1 0 2597
return 1 0 2600
assign 1 0 2603
assign 1 0 2607
return 1 0 2611
return 1 0 2614
assign 1 0 2617
assign 1 0 2621
return 1 0 2625
return 1 0 2628
assign 1 0 2631
assign 1 0 2635
return 1 0 2639
return 1 0 2642
assign 1 0 2645
assign 1 0 2649
return 1 0 2653
return 1 0 2656
assign 1 0 2659
assign 1 0 2663
return 1 0 2667
return 1 0 2670
assign 1 0 2673
assign 1 0 2677
return 1 0 2681
return 1 0 2684
assign 1 0 2687
assign 1 0 2691
return 1 0 2695
return 1 0 2698
assign 1 0 2701
assign 1 0 2705
return 1 0 2709
return 1 0 2712
assign 1 0 2715
assign 1 0 2719
return 1 0 2723
return 1 0 2726
assign 1 0 2729
assign 1 0 2733
return 1 0 2737
return 1 0 2740
assign 1 0 2743
assign 1 0 2747
return 1 0 2751
return 1 0 2754
assign 1 0 2757
assign 1 0 2761
return 1 0 2765
return 1 0 2768
assign 1 0 2771
assign 1 0 2775
return 1 0 2779
return 1 0 2782
assign 1 0 2785
assign 1 0 2789
return 1 0 2793
return 1 0 2796
assign 1 0 2799
assign 1 0 2803
return 1 0 2807
return 1 0 2810
assign 1 0 2813
assign 1 0 2817
return 1 0 2821
return 1 0 2824
assign 1 0 2827
assign 1 0 2831
return 1 0 2835
return 1 0 2838
assign 1 0 2841
assign 1 0 2845
return 1 0 2849
return 1 0 2852
assign 1 0 2855
assign 1 0 2859
return 1 0 2863
return 1 0 2866
assign 1 0 2869
assign 1 0 2873
return 1 0 2877
return 1 0 2880
assign 1 0 2883
assign 1 0 2887
return 1 0 2891
return 1 0 2894
assign 1 0 2897
assign 1 0 2901
return 1 0 2905
return 1 0 2908
assign 1 0 2911
assign 1 0 2915
return 1 0 2919
return 1 0 2922
assign 1 0 2925
assign 1 0 2929
return 1 0 2933
return 1 0 2936
assign 1 0 2939
assign 1 0 2943
return 1 0 2947
return 1 0 2950
assign 1 0 2953
assign 1 0 2957
return 1 0 2961
return 1 0 2964
assign 1 0 2967
assign 1 0 2971
return 1 0 2975
return 1 0 2978
assign 1 0 2981
assign 1 0 2985
return 1 0 2989
return 1 0 2992
assign 1 0 2995
assign 1 0 2999
return 1 0 3003
return 1 0 3006
assign 1 0 3009
assign 1 0 3013
return 1 0 3017
return 1 0 3020
assign 1 0 3023
assign 1 0 3027
return 1 0 3031
return 1 0 3034
assign 1 0 3037
assign 1 0 3041
return 1 0 3045
return 1 0 3048
assign 1 0 3051
assign 1 0 3055
return 1 0 3059
return 1 0 3062
assign 1 0 3065
assign 1 0 3069
return 1 0 3073
return 1 0 3076
assign 1 0 3079
assign 1 0 3083
return 1 0 3087
return 1 0 3090
assign 1 0 3093
assign 1 0 3097
return 1 0 3101
return 1 0 3104
assign 1 0 3107
assign 1 0 3111
return 1 0 3115
return 1 0 3118
assign 1 0 3121
assign 1 0 3125
return 1 0 3129
return 1 0 3132
assign 1 0 3135
assign 1 0 3139
return 1 0 3143
return 1 0 3146
assign 1 0 3149
assign 1 0 3153
return 1 0 3157
return 1 0 3160
assign 1 0 3163
assign 1 0 3167
return 1 0 3171
return 1 0 3174
assign 1 0 3177
assign 1 0 3181
return 1 0 3185
return 1 0 3188
assign 1 0 3191
assign 1 0 3195
return 1 0 3199
return 1 0 3202
assign 1 0 3205
assign 1 0 3209
return 1 0 3213
return 1 0 3216
assign 1 0 3219
assign 1 0 3223
return 1 0 3227
return 1 0 3230
assign 1 0 3233
assign 1 0 3237
return 1 0 3241
return 1 0 3244
assign 1 0 3247
assign 1 0 3251
return 1 0 3255
return 1 0 3258
assign 1 0 3261
assign 1 0 3265
return 1 0 3269
return 1 0 3272
assign 1 0 3275
assign 1 0 3279
return 1 0 3283
return 1 0 3286
assign 1 0 3289
assign 1 0 3293
return 1 0 3297
return 1 0 3300
assign 1 0 3303
assign 1 0 3307
return 1 0 3311
return 1 0 3314
assign 1 0 3317
assign 1 0 3321
return 1 0 3325
return 1 0 3328
assign 1 0 3331
assign 1 0 3335
return 1 0 3339
return 1 0 3342
assign 1 0 3345
assign 1 0 3349
return 1 0 3353
return 1 0 3356
assign 1 0 3359
assign 1 0 3363
return 1 0 3367
return 1 0 3370
assign 1 0 3373
assign 1 0 3377
return 1 0 3381
return 1 0 3384
assign 1 0 3387
assign 1 0 3391
return 1 0 3395
return 1 0 3398
assign 1 0 3401
assign 1 0 3405
return 1 0 3409
assign 1 0 3412
assign 1 0 3416
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1545053031: return bem_printStepsGetDirect_0();
case -1263371501: return bem_ownProcessGetDirect_0();
case -1040366024: return bem_doEmitGetDirect_0();
case 1664580497: return bem_ownProcessGet_0();
case 1848778931: return bem_extLibsGetDirect_0();
case 1258397105: return bem_compilerProfileGetDirect_0();
case 786989266: return bem_buildSucceededGet_0();
case 2001566410: return bem_includePathGetDirect_0();
case 1352610911: return bem_usedLibrarysGetDirect_0();
case 39926910: return bem_deployFilesFromGet_0();
case 1970632184: return bem_printAllAstGetDirect_0();
case 187983040: return bem_emitDataGet_0();
case 173568352: return bem_printStepsGet_0();
case -1826651607: return bem_emitFlagsGetDirect_0();
case -966798796: return bem_ntypesGetDirect_0();
case -692273414: return bem_lctokGet_0();
case 1862323670: return bem_exeNameGetDirect_0();
case -2021077271: return bem_constantsGet_0();
case -499357781: return bem_closeLibrariesGet_0();
case 384939193: return bem_startTimeGetDirect_0();
case 500586256: return bem_setClassesToWrite_0();
case -1656269813: return bem_singleCCGet_0();
case 770693881: return bem_includePathGet_0();
case -2120499139: return bem_iteratorGet_0();
case 707011394: return bem_deployFilesToGetDirect_0();
case -1710080282: return bem_makeArgsGetDirect_0();
case 243620310: return bem_deployPathGetDirect_0();
case -1533207614: return bem_closeLibrariesStrGetDirect_0();
case 487297769: return bem_singleCCGetDirect_0();
case -1604814040: return bem_parseEmitTimeGet_0();
case 725434561: return bem_newlineGet_0();
case 1354530727: return bem_readBufferGet_0();
case 1804773996: return bem_create_0();
case 1532833406: return bem_twtokGetDirect_0();
case 1521995245: return bem_parseGetDirect_0();
case -1811386409: return bem_genOnlyGetDirect_0();
case -163824638: return bem_platformGet_0();
case -1393456271: return bem_compilerGet_0();
case -1467023684: return bem_putLineNumbersInTraceGetDirect_0();
case -612938684: return bem_makeNameGetDirect_0();
case 372172385: return bem_genOnlyGet_0();
case -73436994: return bem_new_0();
case 959038598: return bem_echo_0();
case -1658202448: return bem_emitPathGet_0();
case 1191212451: return bem_usedLibrarysStrGet_0();
case 42211632: return bem_ccObjArgsGet_0();
case -1778497682: return bem_serializeToString_0();
case -1309984938: return bem_linkLibArgsGet_0();
case 1116109559: return bem_newlineGetDirect_0();
case 1610537419: return bem_printAstGet_0();
case 1867388328: return bem_emitDebugGetDirect_0();
case -1077715184: return bem_platformGetDirect_0();
case -2023771464: return bem_prepMakeGetDirect_0();
case -1688282737: return bem_emitLangsGet_0();
case 655543194: return bem_buildSucceededGetDirect_0();
case -1878111426: return bem_argsGet_0();
case -1166605847: return bem_extLinkObjectsGet_0();
case -889985154: return bem_paramsGet_0();
case -1110105210: return bem_saveSynsGet_0();
case -1681920063: return bem_doEmitGet_0();
case 1339387159: return bem_deployUsedLibrariesGet_0();
case 581048216: return bem_toBuildGetDirect_0();
case -1072030744: return bem_sourceFileNameGet_0();
case -1181318200: return bem_usedLibrarysStrGetDirect_0();
case 406949075: return bem_closeLibrariesGetDirect_0();
case -385346233: return bem_sharedEmitterGet_0();
case 447745953: return bem_main_0();
case -974413362: return bem_extIncludesGetDirect_0();
case 1850238783: return bem_mainNameGetDirect_0();
case -420922452: return bem_makeNameGet_0();
case 596678716: return bem_readBufferGetDirect_0();
case -427243686: return bem_extLibsGet_0();
case 1961439300: return bem_emitChecksGetDirect_0();
case 1140041672: return bem_printAllAstGet_0();
case 891303512: return bem_printPlacesGetDirect_0();
case -1631827244: return bem_deployUsedLibrariesGetDirect_0();
case -1204143349: return bem_config_0();
case 222683774: return bem_closeLibrariesStrGet_0();
case -2060966738: return bem_saveIdsGet_0();
case -1187163089: return bem_argsGetDirect_0();
case 1752391201: return bem_prepMakeGet_0();
case 1926573562: return bem_saveIdsGetDirect_0();
case 1884730678: return bem_emitCs_0();
case -1280817060: return bem_makeArgsGet_0();
case -1962210537: return bem_makeGetDirect_0();
case 1239767584: return bem_codeGetDirect_0();
case -111953736: return bem_initLibsGet_0();
case -538972258: return bem_putLineNumbersInTraceGet_0();
case -1540124906: return bem_compilerProfileGet_0();
case -631861648: return bem_parseEmitCompileTimeGet_0();
case 621276181: return bem_toString_0();
case -1334710786: return bem_parseEmitTimeGetDirect_0();
case -1018278508: return bem_codeGet_0();
case 1538976540: return bem_constantsGetDirect_0();
case -1960297657: return bem_fieldIteratorGet_0();
case 749082680: return bem_emitterGet_0();
case 1846665995: return bem_emitFileHeaderGetDirect_0();
case 1417184304: return bem_deployPathGet_0();
case 1125656244: return bem_printPlacesGet_0();
case 39810102: return bem_tagGet_0();
case 591484053: return bem_buildPathGet_0();
case -297374401: return bem_hashGet_0();
case -1851765321: return bem_fromFileGet_0();
case -1799416909: return bem_serializationIteratorGet_0();
case -1628372783: return bem_classNameGet_0();
case -1282352959: return bem_loadSynsGet_0();
case 232236485: return bem_outputPlatformGetDirect_0();
case 761184748: return bem_ntypesGet_0();
case 653349672: return bem_copy_0();
case -1893019773: return bem_parseTimeGet_0();
case 1341908849: return bem_twtokGet_0();
case -1134546487: return bem_extIncludesGet_0();
case 62971073: return bem_loadSynsGetDirect_0();
case -1600468075: return bem_runGet_0();
case -170927798: return bem_runGetDirect_0();
case -2051146466: return bem_deployLibraryGetDirect_0();
case 2977123: return bem_emitPathGetDirect_0();
case -282774461: return bem_emitFileHeaderGet_0();
case -1889421046: return bem_buildMessageGetDirect_0();
case 743244947: return bem_deployFilesToGet_0();
case 1999268321: return bem_emitDebugGet_0();
case 636340778: return bem_emitLibraryGet_0();
case 1616386441: return bem_deployLibraryGet_0();
case -1019852930: return bem_mainNameGet_0();
case 623429655: return bem_runArgsGetDirect_0();
case 575265560: return bem_libNameGetDirect_0();
case 1639486488: return bem_extLinkObjectsGetDirect_0();
case -1071008216: return bem_serializeContents_0();
case 1562662552: return bem_many_0();
case 2078107829: return bem_startTimeGet_0();
case -1788719897: return bem_parseTimeGetDirect_0();
case -1064498309: return bem_printAstElementsGetDirect_0();
case 354086792: return bem_ccObjArgsGetDirect_0();
case 1254813232: return bem_toAny_0();
case 1769468354: return bem_fieldNamesGet_0();
case -425728423: return bem_outputPlatformGet_0();
case 2029390344: return bem_lctokGetDirect_0();
case 481090376: return bem_usedLibrarysGet_0();
case -1531648451: return bem_compilerGetDirect_0();
case -1257110299: return bem_initLibsGetDirect_0();
case 1682401359: return bem_fromFileGetDirect_0();
case 1378381237: return bem_buildMessageGet_0();
case -803789661: return bem_emitDataGetDirect_0();
case -2019041788: return bem_printAstElementsGet_0();
case -615832446: return bem_estrGet_0();
case -1014616592: return bem_saveSynsGetDirect_0();
case -391281905: return bem_parseGet_0();
case 1678841030: return bem_emitLangsGetDirect_0();
case 1980439578: return bem_emitFlagsGet_0();
case 1908868369: return bem_buildPathGetDirect_0();
case -495786914: return bem_paramsGetDirect_0();
case 1445086976: return bem_builtGetDirect_0();
case -1700885416: return bem_estrGetDirect_0();
case -220199513: return bem_makeGet_0();
case -458790538: return bem_runArgsGet_0();
case 1638776879: return bem_emitCommonGet_0();
case -115368300: return bem_go_0();
case 167710369: return bem_print_0();
case -2005315164: return bem_emitLibraryGetDirect_0();
case 905166318: return bem_printAstGetDirect_0();
case -1883340563: return bem_deserializeClassNameGet_0();
case 359727296: return bem_sharedEmitterGetDirect_0();
case -1067704397: return bem_once_0();
case 499709172: return bem_builtGet_0();
case 1338333442: return bem_exeNameGet_0();
case -1388103499: return bem_emitChecksGet_0();
case 1593581681: return bem_toBuildGet_0();
case 175346629: return bem_nlGet_0();
case 2094922617: return bem_libNameGet_0();
case -197205439: return bem_doWhat_0();
case 1095705380: return bem_deployFilesFromGetDirect_0();
case -984213863: return bem_emitCommonGetDirect_0();
case -1741909847: return bem_parseEmitCompileTimeGetDirect_0();
case -694694809: return bem_linkLibArgsGetDirect_0();
case 1725403033: return bem_nlGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -1324724519: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case -1909462562: return bem_parseSet_1(bevd_0);
case -954243126: return bem_makeSet_1(bevd_0);
case 1730473026: return bem_def_1(bevd_0);
case -56729769: return bem_ownProcessSetDirect_1(bevd_0);
case 1018002596: return bem_extLinkObjectsSet_1(bevd_0);
case 1093434664: return bem_platformSetDirect_1(bevd_0);
case 118967097: return bem_usedLibrarysStrSet_1(bevd_0);
case 135320986: return bem_closeLibrariesSet_1(bevd_0);
case -1088309954: return bem_constantsSetDirect_1(bevd_0);
case -1645551099: return bem_platformSet_1(bevd_0);
case 2066606744: return bem_usedLibrarysSet_1(bevd_0);
case 1977386422: return bem_exeNameSet_1(bevd_0);
case -279905256: return bem_parseTimeSet_1(bevd_0);
case 97045008: return bem_saveSynsSetDirect_1(bevd_0);
case 720378168: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 1399008149: return bem_emitFileHeaderSet_1(bevd_0);
case 345087861: return bem_compilerSet_1(bevd_0);
case 2115885479: return bem_deployPathSet_1(bevd_0);
case -891588174: return bem_ownProcessSet_1(bevd_0);
case -1244831897: return bem_emitDataSetDirect_1(bevd_0);
case 976985770: return bem_notEquals_1(bevd_0);
case -1824087779: return bem_runArgsSetDirect_1(bevd_0);
case -395218614: return bem_nlSetDirect_1(bevd_0);
case 1909561928: return bem_deployUsedLibrariesSetDirect_1(bevd_0);
case -1337776218: return bem_estrSetDirect_1(bevd_0);
case 2081279238: return bem_otherType_1(bevd_0);
case -1861719297: return bem_emitLangsSet_1(bevd_0);
case 1605683037: return bem_compilerSetDirect_1(bevd_0);
case -1228510029: return bem_deployLibrarySetDirect_1(bevd_0);
case 1138495137: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1049648124: return bem_buildMessageSetDirect_1(bevd_0);
case 433839407: return bem_argsSet_1(bevd_0);
case -287235294: return bem_deployFilesToSetDirect_1(bevd_0);
case -1903661905: return bem_readBufferSet_1(bevd_0);
case 1287387271: return bem_printAstElementsSet_1(bevd_0);
case 1980281028: return bem_ntypesSet_1(bevd_0);
case -2110106892: return bem_buildSucceededSetDirect_1(bevd_0);
case 478108249: return bem_printAllAstSet_1(bevd_0);
case -290365798: return bem_emitPathSetDirect_1(bevd_0);
case 977889095: return bem_buildPathSet_1(bevd_0);
case 1056173909: return bem_printPlacesSetDirect_1(bevd_0);
case 783120044: return bem_builtSet_1(bevd_0);
case -1049172860: return bem_defined_1(bevd_0);
case -207789135: return bem_outputPlatformSet_1(bevd_0);
case -1779385356: return bem_initLibsSetDirect_1(bevd_0);
case -1143597754: return bem_builtSetDirect_1(bevd_0);
case -828537601: return bem_copyTo_1(bevd_0);
case 962313895: return bem_runSet_1(bevd_0);
case 1614844678: return bem_emitChecksSet_1(bevd_0);
case -1047287043: return bem_compilerProfileSetDirect_1(bevd_0);
case -1657367966: return bem_mainNameSetDirect_1(bevd_0);
case -1311195540: return bem_saveIdsSetDirect_1(bevd_0);
case 2031397861: return bem_toBuildSet_1(bevd_0);
case -788040714: return bem_lctokSetDirect_1(bevd_0);
case 573848042: return bem_ntypesSetDirect_1(bevd_0);
case -938525113: return bem_libNameSet_1(bevd_0);
case 1407177792: return bem_printAllAstSetDirect_1(bevd_0);
case -1982256662: return bem_loadSynsSetDirect_1(bevd_0);
case 306949753: return bem_constantsSet_1(bevd_0);
case 1010070667: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -302552604: return bem_singleCCSetDirect_1(bevd_0);
case -1219231194: return bem_extIncludesSetDirect_1(bevd_0);
case 2110621094: return bem_sameClass_1(bevd_0);
case -2048090351: return bem_makeSetDirect_1(bevd_0);
case 1154712482: return bem_genOnlySetDirect_1(bevd_0);
case -693140734: return bem_singleCCSet_1(bevd_0);
case 1331672645: return bem_compilerProfileSet_1(bevd_0);
case -1986175471: return bem_ccObjArgsSet_1(bevd_0);
case -2083373337: return bem_sharedEmitterSet_1(bevd_0);
case 154311733: return bem_includePathSet_1(bevd_0);
case -700630090: return bem_extLibsSetDirect_1(bevd_0);
case 1530130555: return bem_doEmitSetDirect_1(bevd_0);
case 176115880: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1288565503: return bem_fromFileSetDirect_1(bevd_0);
case 2069125609: return bem_prepMakeSetDirect_1(bevd_0);
case -1784079993: return bem_doEmitSet_1(bevd_0);
case -930841747: return bem_genOnlySet_1(bevd_0);
case -1776431228: return bem_doParse_1(bevd_0);
case 892958209: return bem_runArgsSet_1(bevd_0);
case 888417462: return bem_argsSetDirect_1(bevd_0);
case 743877945: return bem_usedLibrarysStrSetDirect_1(bevd_0);
case -1337132718: return bem_mainNameSet_1(bevd_0);
case -650110440: return bem_loadSynsSet_1(bevd_0);
case -1418442629: return bem_otherClass_1(bevd_0);
case -81924193: return bem_emitLangsSetDirect_1(bevd_0);
case 1904610638: return bem_parseEmitTimeSetDirect_1(bevd_0);
case 1492218570: return bem_parseSetDirect_1(bevd_0);
case -1413665766: return bem_twtokSet_1(bevd_0);
case -2123050604: return bem_printAstSetDirect_1(bevd_0);
case -1063453569: return bem_estrSet_1(bevd_0);
case 924437671: return bem_codeSetDirect_1(bevd_0);
case 961740462: return bem_emitLibrarySetDirect_1(bevd_0);
case 1120878829: return bem_nlSet_1(bevd_0);
case -327676034: return bem_closeLibrariesStrSet_1(bevd_0);
case 145779487: return bem_deployFilesFromSet_1(bevd_0);
case 2007447187: return bem_emitCommonSet_1(bevd_0);
case 1837555195: return bem_initLibsSet_1(bevd_0);
case 1621173487: return bem_emitDebugSetDirect_1(bevd_0);
case -224421766: return bem_startTimeSet_1(bevd_0);
case -1486570791: return bem_emitFileHeaderSetDirect_1(bevd_0);
case 1317897739: return bem_deployUsedLibrariesSet_1(bevd_0);
case 605012422: return bem_getSynNp_1(bevd_0);
case 1999670913: return bem_emitCommonSetDirect_1(bevd_0);
case 2119473822: return bem_putLineNumbersInTraceSetDirect_1(bevd_0);
case 1617906062: return bem_startTimeSetDirect_1(bevd_0);
case 205167419: return bem_parseEmitCompileTimeSetDirect_1(bevd_0);
case -1957568919: return bem_undef_1(bevd_0);
case 60280133: return bem_sharedEmitterSetDirect_1(bevd_0);
case 257751991: return bem_prepMakeSet_1(bevd_0);
case 905454791: return bem_printPlacesSet_1(bevd_0);
case -275675840: return bem_makeArgsSetDirect_1(bevd_0);
case 295428139: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 36070057: return bem_includePathSetDirect_1(bevd_0);
case 308019868: return bem_saveIdsSet_1(bevd_0);
case -1557229363: return bem_readBufferSetDirect_1(bevd_0);
case 1346779749: return bem_deployLibrarySet_1(bevd_0);
case -1373593724: return bem_closeLibrariesStrSetDirect_1(bevd_0);
case 1854601881: return bem_buildSucceededSet_1(bevd_0);
case -1529968730: return bem_extIncludesSet_1(bevd_0);
case -2146916671: return bem_parseEmitTimeSet_1(bevd_0);
case -438924354: return bem_undefined_1(bevd_0);
case 1093632: return bem_ccObjArgsSetDirect_1(bevd_0);
case -1176093254: return bem_sameType_1(bevd_0);
case -351736714: return bem_printStepsSetDirect_1(bevd_0);
case 147799914: return bem_linkLibArgsSet_1(bevd_0);
case -1002199747: return bem_parseTimeSetDirect_1(bevd_0);
case -1240372807: return bem_newlineSet_1(bevd_0);
case -192103794: return bem_usedLibrarysSetDirect_1(bevd_0);
case -1438218031: return bem_outputPlatformSetDirect_1(bevd_0);
case 195029963: return bem_makeNameSetDirect_1(bevd_0);
case 988239186: return bem_buildSyns_1(bevd_0);
case -1919015620: return bem_closeLibrariesSetDirect_1(bevd_0);
case 917287327: return bem_fromFileSet_1(bevd_0);
case -1129370770: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -872715456: return bem_newlineSetDirect_1(bevd_0);
case -596828008: return bem_twtokSetDirect_1(bevd_0);
case 665389853: return bem_emitFlagsSetDirect_1(bevd_0);
case 892110407: return bem_paramsSet_1(bevd_0);
case -425142667: return bem_codeSet_1(bevd_0);
case -307477752: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -1255083521: return bem_equals_1(bevd_0);
case 180807863: return bem_emitDebugSet_1(bevd_0);
case 558373428: return bem_buildPathSetDirect_1(bevd_0);
case -718995615: return bem_lctokSet_1(bevd_0);
case 1269810101: return bem_emitFlagsSet_1(bevd_0);
case 203160963: return bem_exeNameSetDirect_1(bevd_0);
case -1413114795: return bem_sameObject_1(bevd_0);
case -377552350: return bem_deployFilesToSet_1(bevd_0);
case 1637601700: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1806766187: return bem_emitLibrarySet_1(bevd_0);
case -1455022270: return bem_toBuildSetDirect_1(bevd_0);
case 382910099: return bem_printStepsSet_1(bevd_0);
case 1298312283: return bem_printAstElementsSetDirect_1(bevd_0);
case 426949111: return bem_runSetDirect_1(bevd_0);
case 1158147621: return bem_deployFilesFromSetDirect_1(bevd_0);
case -1878806333: return bem_saveSynsSet_1(bevd_0);
case -221327580: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1969670104: return bem_libNameSetDirect_1(bevd_0);
case -410617715: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -347295528: return bem_extLinkObjectsSetDirect_1(bevd_0);
case 983820255: return bem_buildMessageSet_1(bevd_0);
case 1421631844: return bem_emitPathSet_1(bevd_0);
case -1328151521: return bem_emitChecksSetDirect_1(bevd_0);
case -172786155: return bem_extLibsSet_1(bevd_0);
case -46543855: return bem_deployPathSetDirect_1(bevd_0);
case 41409539: return bem_emitDataSet_1(bevd_0);
case -1432857855: return bem_paramsSetDirect_1(bevd_0);
case 841313469: return bem_makeNameSet_1(bevd_0);
case 984487258: return bem_linkLibArgsSetDirect_1(bevd_0);
case -2021367645: return bem_makeArgsSet_1(bevd_0);
case 1083883757: return bem_printAstSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 348542496: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 594108915: return bem_buildLiteral_2(bevd_0, bevd_1);
case -1187618045: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2047726278: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case -785001391: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1575715113: return bem_getSyn_2(bevd_0, bevd_1);
case -1475941932: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -833246029: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1796207897: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1708725526: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_5_5_BuildBuild();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_type;
}
}
}
