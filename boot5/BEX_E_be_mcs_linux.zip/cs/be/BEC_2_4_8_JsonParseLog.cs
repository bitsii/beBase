namespace be {
/* IO:File: source/extended/Json.be */
public class BEC_2_4_8_JsonParseLog : BEC_2_6_6_SystemObject {
public BEC_2_4_8_JsonParseLog() { }
static BEC_2_4_8_JsonParseLog() { }
private static byte[] becc_BEC_2_4_8_JsonParseLog_clname = {0x4A,0x73,0x6F,0x6E,0x3A,0x50,0x61,0x72,0x73,0x65,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_4_8_JsonParseLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4A,0x73,0x6F,0x6E,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_0 = {0x47,0x6F,0x74,0x20,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_0, 12));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_1 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_1, 1));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_2 = {0x62,0x65,0x67,0x69,0x6E,0x4D,0x61,0x70};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_2, 8));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_3 = {0x65,0x6E,0x64,0x4D,0x61,0x70};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_3, 6));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_4 = {0x6B,0x76,0x4D,0x69,0x64};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_4, 5));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_5 = {0x62,0x65,0x67,0x69,0x6E,0x4C,0x69,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_5, 9));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_6 = {0x65,0x6E,0x64,0x4C,0x69,0x73,0x74};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_6, 7));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_7 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x54,0x72,0x75,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_7, 10));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_8 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x46,0x61,0x6C,0x73,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_8, 11));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_9 = {0x68,0x61,0x6E,0x64,0x6C,0x65,0x4E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_9, 10));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_10 = {0x47,0x6F,0x74,0x20,0x49,0x6E,0x74,0x65,0x67,0x65,0x72,0x20,0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_10, 13));
private static byte[] bece_BEC_2_4_8_JsonParseLog_bels_11 = {0x7C};
private static BEC_2_4_6_TextString bece_BEC_2_4_8_JsonParseLog_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_4_8_JsonParseLog_bels_11, 1));
public static new BEC_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_inst;

public static new BET_2_4_8_JsonParseLog bece_BEC_2_4_8_JsonParseLog_bevs_type;

public override BEC_2_6_6_SystemObject bem_new_0() {
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleString_1(BEC_2_4_6_TextString beva_str) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_0;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_str);
bevt_3_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_1;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_beginMap_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_2;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_endMap_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_3;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_kvMid_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_4;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_beginList_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_5;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_endList_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_6;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleTrue_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_7;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleFalse_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_8;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleNull_0() {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_9;
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public virtual BEC_2_4_8_JsonParseLog bem_handleInteger_1(BEC_2_4_3_MathInt beva_int) {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_10;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_add_1(beva_int);
bevt_3_tmpany_phold = bece_BEC_2_4_8_JsonParseLog_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(bevt_3_tmpany_phold);
bevt_0_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {581, 581, 581, 581, 581, 585, 585, 589, 589, 593, 593, 597, 597, 601, 601, 605, 605, 609, 609, 613, 613, 617, 617, 617, 617, 617};
public static new int[] bevs_smnlec
 = new int[] {44, 45, 46, 47, 48, 53, 54, 59, 60, 65, 66, 71, 72, 77, 78, 83, 84, 89, 90, 95, 96, 104, 105, 106, 107, 108};
/* BEGIN LINEINFO 
assign 1 581 44
new 0 581 44
assign 1 581 45
add 1 581 45
assign 1 581 46
new 0 581 46
assign 1 581 47
add 1 581 47
print 0 581 48
assign 1 585 53
new 0 585 53
print 0 585 54
assign 1 589 59
new 0 589 59
print 0 589 60
assign 1 593 65
new 0 593 65
print 0 593 66
assign 1 597 71
new 0 597 71
print 0 597 72
assign 1 601 77
new 0 601 77
print 0 601 78
assign 1 605 83
new 0 605 83
print 0 605 84
assign 1 609 89
new 0 609 89
print 0 609 90
assign 1 613 95
new 0 613 95
print 0 613 96
assign 1 617 104
new 0 617 104
assign 1 617 105
add 1 617 105
assign 1 617 106
new 0 617 106
assign 1 617 107
add 1 617 107
print 0 617 108
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1615839398: return bem_echo_0();
case -1043543071: return bem_create_0();
case 198424425: return bem_endList_0();
case -1048585343: return bem_copy_0();
case -1800587860: return bem_serializeToString_0();
case 976768273: return bem_fieldNamesGet_0();
case 1114451637: return bem_handleFalse_0();
case -2011984947: return bem_classNameGet_0();
case -1082080720: return bem_kvMid_0();
case -193453355: return bem_iteratorGet_0();
case -477940854: return bem_hashGet_0();
case 1463816718: return bem_sourceFileNameGet_0();
case -1021558772: return bem_fieldIteratorGet_0();
case -1852647932: return bem_serializeContents_0();
case 190764838: return bem_toString_0();
case 795649196: return bem_serializationIteratorGet_0();
case 861614979: return bem_handleTrue_0();
case -204986197: return bem_print_0();
case -565876640: return bem_endMap_0();
case -1017732045: return bem_toAny_0();
case 1101194098: return bem_beginMap_0();
case 1809869265: return bem_many_0();
case -1777892367: return bem_handleNull_0();
case -186488753: return bem_beginList_0();
case 2022567405: return bem_tagGet_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -1200514874: return bem_once_0();
case 451316734: return bem_new_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -974417776: return bem_undef_1(bevd_0);
case 1255352870: return bem_notEquals_1(bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case -1638486910: return bem_handleInteger_1((BEC_2_4_3_MathInt) bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1930613688: return bem_handleString_1((BEC_2_4_6_TextString) bevd_0);
case -252330168: return bem_def_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(13, becc_BEC_2_4_8_JsonParseLog_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_8_JsonParseLog_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_4_8_JsonParseLog();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst = (BEC_2_4_8_JsonParseLog) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_4_8_JsonParseLog.bece_BEC_2_4_8_JsonParseLog_bevs_type;
}
}
}
