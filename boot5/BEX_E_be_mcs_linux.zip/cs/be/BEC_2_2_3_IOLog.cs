namespace be {
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog : BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
static BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x45,0x72,0x72,0x6F,0x72,0x20,0x6C,0x6F,0x67,0x67,0x65,0x64,0x20};
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x20};
public static new BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static new BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public BEC_2_6_6_SystemObject bevp_sink;
public virtual BEC_2_2_3_IOLog bem_new_3(BEC_2_6_6_SystemObject beva__sink, BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
bevp_sink = beva__sink;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_0() {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 145*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 146*/
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 152*/ {
bevt_1_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_ta_ph;
} /* Line: 153*/
bevt_2_ta_ph = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_ta_ph;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_out_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
if (beva_msg == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 159*/ {
beva_msg = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(4, bece_BEC_2_2_3_IOLog_bels_0));
} /* Line: 160*/
if (bevp_sink == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 162*/ {
bevp_sink.bemd_1(372747232, beva_msg);
} /* Line: 163*/
 else /* Line: 164*/ {
beva_msg.bem_print_0();
} /* Line: 165*/
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_elog_1(BEC_2_6_6_SystemObject beva_e) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(13, bece_BEC_2_2_3_IOLog_bels_1));
bem_elog_2(bevt_0_ta_ph, beva_e);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_elog_2(BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_10_SystemExceptions bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_2_3_IOLog_bels_2));
bevt_1_ta_ph = beva_msg.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_ta_ph = bevt_4_ta_ph.bem_tS_1(beva_e);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_log_1(bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 178*/ {
bem_out_1(beva_msg);
} /* Line: 179*/
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_elog_3(BEC_2_4_3_MathInt beva_level, BEC_2_4_6_TextString beva_msg, BEC_2_6_6_SystemObject beva_e) {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_10_SystemExceptions bevt_4_ta_ph = null;
bevt_2_ta_ph = (BEC_2_4_6_TextString) (new BEC_2_4_6_TextString(1, bece_BEC_2_2_3_IOLog_bels_2));
bevt_1_ta_ph = beva_msg.bem_add_1(bevt_2_ta_ph);
bevt_4_ta_ph = (BEC_2_6_10_SystemExceptions) (new BEC_2_6_10_SystemExceptions());
bevt_3_ta_ph = bevt_4_ta_ph.bem_tS_1(beva_e);
bevt_0_ta_ph = bevt_1_ta_ph.bem_add_1(bevt_3_ta_ph);
bem_log_2(beva_level, bevt_0_ta_ph);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 188*/ {
bem_out_1(beva_msg);
} /* Line: 189*/
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_debug_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(400));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_info_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(300));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_warn_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(200));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_error_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(100));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_fatal_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = (BEC_2_4_3_MathInt) (new BEC_2_4_3_MathInt(0));
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) {
bem_out_1(beva_msg);
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_outputLevelGet_0() {
return bevp_outputLevel;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGetDirect_0() {
return bevp_outputLevel;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_levelGet_0() {
return bevp_level;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGetDirect_0() {
return bevp_level;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public virtual BEC_2_6_6_SystemObject bem_sinkGet_0() {
return bevp_sink;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sinkGetDirect_0() {
return bevp_sink;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_sinkSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_sinkSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) {
bevp_sink = bevt_0_ta_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {138, 139, 140, 145, 145, 146, 146, 148, 148, 152, 152, 153, 153, 155, 155, 159, 159, 160, 162, 162, 163, 165, 170, 170, 174, 174, 174, 174, 174, 174, 178, 178, 179, 184, 184, 184, 184, 184, 184, 188, 188, 189, 194, 195, 199, 200, 204, 205, 209, 210, 214, 215, 219, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {19, 20, 21, 28, 33, 34, 35, 37, 38, 44, 49, 50, 51, 53, 54, 59, 64, 65, 67, 72, 73, 76, 82, 83, 92, 93, 94, 95, 96, 97, 102, 107, 108, 118, 119, 120, 121, 122, 123, 128, 133, 134, 140, 141, 146, 147, 152, 153, 158, 159, 164, 165, 169, 173, 176, 179, 183, 187, 190, 193, 197, 201, 204, 207, 211};
/* BEGIN LINEINFO 
assign 1 138 19
assign 1 139 20
assign 1 140 21
assign 1 145 28
lesserEquals 1 145 33
assign 1 146 34
new 0 146 34
return 1 146 35
assign 1 148 37
new 0 148 37
return 1 148 38
assign 1 152 44
lesserEquals 1 152 49
assign 1 153 50
new 0 153 50
return 1 153 51
assign 1 155 53
new 0 155 53
return 1 155 54
assign 1 159 59
undef 1 159 64
assign 1 160 65
new 0 160 65
assign 1 162 67
def 1 162 72
out 1 163 73
print 0 165 76
assign 1 170 82
new 0 170 82
elog 2 170 83
assign 1 174 92
new 0 174 92
assign 1 174 93
add 1 174 93
assign 1 174 94
new 0 174 94
assign 1 174 95
tS 1 174 95
assign 1 174 96
add 1 174 96
log 1 174 97
assign 1 178 102
lesserEquals 1 178 107
out 1 179 108
assign 1 184 118
new 0 184 118
assign 1 184 119
add 1 184 119
assign 1 184 120
new 0 184 120
assign 1 184 121
tS 1 184 121
assign 1 184 122
add 1 184 122
log 2 184 123
assign 1 188 128
lesserEquals 1 188 133
out 1 189 134
assign 1 194 140
new 0 194 140
log 2 195 141
assign 1 199 146
new 0 199 146
log 2 200 147
assign 1 204 152
new 0 204 152
log 2 205 153
assign 1 209 158
new 0 209 158
log 2 210 159
assign 1 214 164
new 0 214 164
log 2 215 165
out 1 219 169
return 1 0 173
return 1 0 176
assign 1 0 179
assign 1 0 183
return 1 0 187
return 1 0 190
assign 1 0 193
assign 1 0 197
return 1 0 201
return 1 0 204
assign 1 0 207
assign 1 0 211
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -431154242: return bem_sinkGet_0();
case 1931705863: return bem_sourceFileNameGet_0();
case -893093197: return bem_toString_0();
case 1974505938: return bem_hashGet_0();
case -1076915155: return bem_serializeToString_0();
case 1809906740: return bem_deserializeClassNameGet_0();
case 421177749: return bem_print_0();
case 946360922: return bem_serializationIteratorGet_0();
case 1693225181: return bem_outputLevelGet_0();
case 954703233: return bem_create_0();
case -487222211: return bem_levelGetDirect_0();
case 1586815430: return bem_fieldIteratorGet_0();
case 1834246217: return bem_classNameGet_0();
case -193582610: return bem_tagGet_0();
case -986611923: return bem_will_0();
case -975498393: return bem_fieldNamesGet_0();
case 1078916697: return bem_sinkGetDirect_0();
case -40905183: return bem_echo_0();
case 2081363871: return bem_copy_0();
case 1153344161: return bem_serializeContents_0();
case -2118708930: return bem_new_0();
case 287278262: return bem_levelGet_0();
case -1653939165: return bem_iteratorGet_0();
case 1927874877: return bem_outputLevelGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 177409367: return bem_otherType_1(bevd_0);
case 372747232: return bem_out_1((BEC_2_4_6_TextString) bevd_0);
case -708261487: return bem_elog_1(bevd_0);
case -111398538: return bem_undef_1(bevd_0);
case -575162425: return bem_equals_1(bevd_0);
case 906682978: return bem_sameClass_1(bevd_0);
case 1487285833: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case -136621623: return bem_error_1((BEC_2_4_6_TextString) bevd_0);
case 491733441: return bem_outputLevelSet_1(bevd_0);
case 1052888087: return bem_def_1(bevd_0);
case -856520238: return bem_outputLevelSetDirect_1(bevd_0);
case -1220213109: return bem_otherClass_1(bevd_0);
case -1706693479: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case -1325785469: return bem_sinkSetDirect_1(bevd_0);
case -703305481: return bem_sinkSet_1(bevd_0);
case -1903067231: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1625437141: return bem_fatal_1((BEC_2_4_6_TextString) bevd_0);
case -1923927524: return bem_levelSetDirect_1(bevd_0);
case -846997646: return bem_notEquals_1(bevd_0);
case 1423017230: return bem_info_1((BEC_2_4_6_TextString) bevd_0);
case -1501370764: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2045348082: return bem_copyTo_1(bevd_0);
case -426347158: return bem_sameType_1(bevd_0);
case -1077919578: return bem_debug_1((BEC_2_4_6_TextString) bevd_0);
case 402422079: return bem_warn_1((BEC_2_4_6_TextString) bevd_0);
case 356172186: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1884214414: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case -260432710: return bem_sameObject_1(bevd_0);
case 313121896: return bem_levelSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case -213325399: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1452102248: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1475232972: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1429486514: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -579721422: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
case 1617612246: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 760072761: return bem_elog_2((BEC_2_4_6_TextString) bevd_0, bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) {
switch (callId) {
case -90158817: return bem_elog_3((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1, bevd_2);
case 1473011759: return bem_new_3(bevd_0, bevd_1, bevd_2);
}
return base.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_3_IOLog();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
}
