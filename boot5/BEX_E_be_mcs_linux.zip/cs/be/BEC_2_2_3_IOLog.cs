namespace be {
/* IO:File: source/extended/Log.be */
public class BEC_2_2_3_IOLog : BEC_2_6_6_SystemObject {
public BEC_2_2_3_IOLog() { }
static BEC_2_2_3_IOLog() { }
private static byte[] becc_BEC_2_2_3_IOLog_clname = {0x49,0x4F,0x3A,0x4C,0x6F,0x67};
private static byte[] becc_BEC_2_2_3_IOLog_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x4C,0x6F,0x67,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_2_3_IOLog_bels_0 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_0, 4));
private static byte[] bece_BEC_2_2_3_IOLog_bels_1 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_1, 4));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_2 = (new BEC_2_4_3_MathInt(400));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_3 = (new BEC_2_4_3_MathInt(300));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_4 = (new BEC_2_4_3_MathInt(200));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_5 = (new BEC_2_4_3_MathInt(100));
private static BEC_2_4_3_MathInt bece_BEC_2_2_3_IOLog_bevo_6 = (new BEC_2_4_3_MathInt(0));
private static byte[] bece_BEC_2_2_3_IOLog_bels_2 = {0x6E,0x75,0x6C,0x6C};
private static BEC_2_4_6_TextString bece_BEC_2_2_3_IOLog_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_2_3_IOLog_bels_2, 4));
public static new BEC_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_inst;

public static new BET_2_2_3_IOLog bece_BEC_2_2_3_IOLog_bevs_type;

public BEC_2_4_3_MathInt bevp_outputLevel;
public BEC_2_4_3_MathInt bevp_level;
public virtual BEC_2_2_3_IOLog bem_new_2(BEC_2_6_6_SystemObject beva__outputLevel, BEC_2_6_6_SystemObject beva__level) {
bevp_outputLevel = (BEC_2_4_3_MathInt) beva__outputLevel;
bevp_level = (BEC_2_4_3_MathInt) beva__level;
return this;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_0() {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 136 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 137 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_5_4_LogicBool bem_will_1(BEC_2_4_3_MathInt beva__level) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 143 */ {
bevt_1_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolTrue;
return bevt_1_tmpany_phold;
} /* Line: 144 */
bevt_2_tmpany_phold = (BEC_2_5_4_LogicBool) be.BECS_Runtime.boolFalse;
return bevt_2_tmpany_phold;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_log_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (bevp_level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 150 */ {
if (beva_msg == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 151 */ {
beva_msg.bem_print_0();
} /* Line: 152 */
 else  /* Line: 153 */ {
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_0;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 154 */
} /* Line: 151 */
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_log_2(BEC_2_4_3_MathInt beva__level, BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
if (beva__level.bevi_int <= bevp_outputLevel.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 160 */ {
if (beva_msg == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 161 */ {
beva_msg.bem_print_0();
} /* Line: 162 */
 else  /* Line: 163 */ {
bevt_2_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_1;
bevt_2_tmpany_phold.bem_print_0();
} /* Line: 164 */
} /* Line: 161 */
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_debug_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_2;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_info_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_3;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_warn_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_4;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_error_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_5;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_fatal_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_4_3_MathInt bevl_lev = null;
bevl_lev = bece_BEC_2_2_3_IOLog_bevo_6;
bem_log_2(bevl_lev, beva_msg);
return this;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_output_1(BEC_2_4_6_TextString beva_msg) {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
if (beva_msg == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 195 */ {
beva_msg.bem_print_0();
} /* Line: 196 */
 else  /* Line: 197 */ {
bevt_1_tmpany_phold = bece_BEC_2_2_3_IOLog_bevo_7;
bevt_1_tmpany_phold.bem_print_0();
} /* Line: 198 */
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_outputLevelGet_0() {
return bevp_outputLevel;
} /*method end*/
public BEC_2_4_3_MathInt bem_outputLevelGetDirect_0() {
return bevp_outputLevel;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_outputLevelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_outputLevelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_outputLevel = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public virtual BEC_2_4_3_MathInt bem_levelGet_0() {
return bevp_level;
} /*method end*/
public BEC_2_4_3_MathInt bem_levelGetDirect_0() {
return bevp_level;
} /*method end*/
public virtual BEC_2_2_3_IOLog bem_levelSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_2_3_IOLog bem_levelSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) {
bevp_level = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static new int[] bevs_smnlc
 = new int[] {130, 131, 136, 136, 137, 137, 139, 139, 143, 143, 144, 144, 146, 146, 150, 150, 151, 151, 152, 154, 154, 160, 160, 161, 161, 162, 164, 164, 170, 171, 175, 176, 180, 181, 185, 186, 190, 191, 195, 195, 196, 198, 198, 0, 0, 0, 0, 0, 0, 0, 0};
public static new int[] bevs_smnlec
 = new int[] {26, 27, 34, 39, 40, 41, 43, 44, 50, 55, 56, 57, 59, 60, 66, 71, 72, 77, 78, 81, 82, 91, 96, 97, 102, 103, 106, 107, 114, 115, 120, 121, 126, 127, 132, 133, 138, 139, 145, 150, 151, 154, 155, 160, 163, 166, 170, 174, 177, 180, 184};
/* BEGIN LINEINFO 
assign 1 130 26
assign 1 131 27
assign 1 136 34
lesserEquals 1 136 39
assign 1 137 40
new 0 137 40
return 1 137 41
assign 1 139 43
new 0 139 43
return 1 139 44
assign 1 143 50
lesserEquals 1 143 55
assign 1 144 56
new 0 144 56
return 1 144 57
assign 1 146 59
new 0 146 59
return 1 146 60
assign 1 150 66
lesserEquals 1 150 71
assign 1 151 72
def 1 151 77
print 0 152 78
assign 1 154 81
new 0 154 81
print 0 154 82
assign 1 160 91
lesserEquals 1 160 96
assign 1 161 97
def 1 161 102
print 0 162 103
assign 1 164 106
new 0 164 106
print 0 164 107
assign 1 170 114
new 0 170 114
log 2 171 115
assign 1 175 120
new 0 175 120
log 2 176 121
assign 1 180 126
new 0 180 126
log 2 181 127
assign 1 185 132
new 0 185 132
log 2 186 133
assign 1 190 138
new 0 190 138
log 2 191 139
assign 1 195 145
def 1 195 150
print 0 196 151
assign 1 198 154
new 0 198 154
print 0 198 155
return 1 0 160
return 1 0 163
assign 1 0 166
assign 1 0 170
return 1 0 174
return 1 0 177
assign 1 0 180
assign 1 0 184
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -1253246070: return bem_create_0();
case 1014225644: return bem_echo_0();
case -1882364243: return bem_many_0();
case -628560707: return bem_toAny_0();
case -2123848647: return bem_fieldNamesGet_0();
case 770834928: return bem_serializeContents_0();
case 1297175099: return bem_fieldIteratorGet_0();
case -463127622: return bem_levelGetDirect_0();
case -753894116: return bem_new_0();
case -1074341902: return bem_print_0();
case 1668541846: return bem_sourceFileNameGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -612092018: return bem_outputLevelGet_0();
case -1138072028: return bem_tagGet_0();
case 844225351: return bem_classNameGet_0();
case -2083934905: return bem_copy_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 80244442: return bem_toString_0();
case -2131387379: return bem_iteratorGet_0();
case 522915968: return bem_will_0();
case -1625648722: return bem_once_0();
case -1194289304: return bem_serializeToString_0();
case 1246958352: return bem_levelGet_0();
case 1165329653: return bem_hashGet_0();
case -1134189428: return bem_outputLevelGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -2123962629: return bem_warn_1((BEC_2_4_6_TextString) bevd_0);
case -842569103: return bem_info_1((BEC_2_4_6_TextString) bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1992487237: return bem_outputLevelSetDirect_1(bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case -90716975: return bem_debug_1((BEC_2_4_6_TextString) bevd_0);
case 855398368: return bem_outputLevelSet_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
case -1067876265: return bem_log_1((BEC_2_4_6_TextString) bevd_0);
case -61802659: return bem_error_1((BEC_2_4_6_TextString) bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case 259033926: return bem_will_1((BEC_2_4_3_MathInt) bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1935030772: return bem_fatal_1((BEC_2_4_6_TextString) bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case -1644206749: return bem_levelSetDirect_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case 585855915: return bem_notEquals_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -636442813: return bem_def_1(bevd_0);
case 86156497: return bem_output_1((BEC_2_4_6_TextString) bevd_0);
case 876965848: return bem_levelSet_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1551438146: return bem_new_2(bevd_0, bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -224124534: return bem_log_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_6_TextString) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(6, becc_BEC_2_2_3_IOLog_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(22, becc_BEC_2_2_3_IOLog_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_2_3_IOLog();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst = (BEC_2_2_3_IOLog) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_2_3_IOLog.bece_BEC_2_2_3_IOLog_bevs_type;
}
}
}
