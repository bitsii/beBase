namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemMethodNotDefined : BEC_2_6_9_SystemException {
public BEC_2_6_16_SystemMethodNotDefined() { }
static BEC_2_6_16_SystemMethodNotDefined() { }
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;

public static new BET_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case -120998597: return bem_methodNameGet_0();
case 844225351: return bem_classNameGet_0();
case 307804617: return bem_serializationIteratorGet_0();
case -670232268: return bem_framesTextGetDirect_0();
case 45695630: return bem_translatedGet_0();
case 1668541846: return bem_sourceFileNameGet_0();
case -260145238: return bem_klassNameGet_0();
case 353149464: return bem_getFrameText_0();
case -848367768: return bem_vvGet_0();
case 813299739: return bem_klassNameGetDirect_0();
case 1846326563: return bem_methodNameGetDirect_0();
case -600964263: return bem_descriptionGet_0();
case 740238184: return bem_framesTextGet_0();
case 1014225644: return bem_echo_0();
case 770834928: return bem_serializeContents_0();
case -1208225713: return bem_translateEmittedExceptionInner_0();
case 1165329653: return bem_hashGet_0();
case -1253246070: return bem_create_0();
case 1297175099: return bem_fieldIteratorGet_0();
case 1717801792: return bem_descriptionGetDirect_0();
case 1066616132: return bem_emitLangGetDirect_0();
case 1036192591: return bem_lineNumberGetDirect_0();
case -379634769: return bem_emitLangGet_0();
case -1625648722: return bem_once_0();
case -1882364243: return bem_many_0();
case -1138072028: return bem_tagGet_0();
case -1582864052: return bem_deserializeClassNameGet_0();
case 1442290101: return bem_vvGetDirect_0();
case -2083934905: return bem_copy_0();
case 1122444795: return bem_langGet_0();
case -628560707: return bem_toAny_0();
case -2123848647: return bem_fieldNamesGet_0();
case -1074341902: return bem_print_0();
case 1049614990: return bem_framesGet_0();
case -1194289304: return bem_serializeToString_0();
case 80244442: return bem_toString_0();
case 597948058: return bem_translatedGetDirect_0();
case -1526443165: return bem_lineNumberGet_0();
case -753894116: return bem_new_0();
case 1862316843: return bem_fileNameGet_0();
case -141634928: return bem_fileNameGetDirect_0();
case 2052957490: return bem_framesGetDirect_0();
case -2131387379: return bem_iteratorGet_0();
case -345892982: return bem_langGetDirect_0();
case -552679100: return bem_translateEmittedException_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case 585855915: return bem_notEquals_1(bevd_0);
case -525574269: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1226826744: return bem_defined_1(bevd_0);
case -802617076: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 970211116: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 322534726: return bem_new_1(bevd_0);
case -636442813: return bem_def_1(bevd_0);
case -1282505685: return bem_sameClass_1(bevd_0);
case 2042588562: return bem_methodNameSetDirect_1(bevd_0);
case 1958592570: return bem_emitLangSetDirect_1(bevd_0);
case 882831231: return bem_lineNumberSet_1(bevd_0);
case -1131266419: return bem_langSetDirect_1(bevd_0);
case 1641362040: return bem_translatedSet_1(bevd_0);
case 895757692: return bem_framesSetDirect_1(bevd_0);
case 502943200: return bem_fileNameSetDirect_1(bevd_0);
case 1665646633: return bem_emitLangSet_1(bevd_0);
case 1518593876: return bem_copyTo_1(bevd_0);
case -493706568: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1836130728: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1757225540: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -379916501: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1087078162: return bem_klassNameSet_1(bevd_0);
case -897488318: return bem_vvSet_1(bevd_0);
case 1204560526: return bem_translatedSetDirect_1(bevd_0);
case -872086611: return bem_otherType_1(bevd_0);
case -1661721663: return bem_klassNameSetDirect_1(bevd_0);
case 113893679: return bem_methodNameSet_1(bevd_0);
case 1063402486: return bem_lineNumberSetDirect_1(bevd_0);
case -1716858999: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -851909776: return bem_descriptionSetDirect_1(bevd_0);
case -166692085: return bem_undefined_1(bevd_0);
case -1375896684: return bem_sameObject_1(bevd_0);
case 1215159307: return bem_descriptionSet_1(bevd_0);
case -1672211684: return bem_sameType_1(bevd_0);
case -1665718180: return bem_framesTextSet_1(bevd_0);
case 1565462907: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1660267174: return bem_fileNameSet_1(bevd_0);
case 1590149619: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -1395654484: return bem_vvSetDirect_1(bevd_0);
case -1997835258: return bem_langSet_1(bevd_0);
case 750955320: return bem_framesTextSetDirect_1(bevd_0);
case 1184566416: return bem_framesSet_1(bevd_0);
case 1005923450: return bem_otherClass_1(bevd_0);
case 1422372228: return bem_equals_1(bevd_0);
case -2110045488: return bem_undef_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 650364606: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1863847527: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1705163769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 202220951: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1314102777: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2060254404: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -97694057: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -603395415: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemMethodNotDefined_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemMethodNotDefined_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemMethodNotDefined();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst = (BEC_2_6_16_SystemMethodNotDefined) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;
}
}
}
