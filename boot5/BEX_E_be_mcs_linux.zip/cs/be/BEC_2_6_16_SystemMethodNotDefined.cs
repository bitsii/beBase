namespace be {
/* IO:File: source/base/Exceptions.be */
public sealed class BEC_2_6_16_SystemMethodNotDefined : BEC_2_6_9_SystemException {
public BEC_2_6_16_SystemMethodNotDefined() { }
static BEC_2_6_16_SystemMethodNotDefined() { }
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x4E,0x6F,0x74,0x44,0x65,0x66,0x69,0x6E,0x65,0x64};
private static byte[] becc_BEC_2_6_16_SystemMethodNotDefined_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
public static new BEC_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;

public static new BET_2_6_16_SystemMethodNotDefined bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;

public static new int[] bevs_smnlc
 = new int[] {};
public static new int[] bevs_smnlec
 = new int[] {};
/* BEGIN LINEINFO 
END LINEINFO */
public override BEC_2_6_6_SystemObject bemd_0(int callId) {
switch (callId) {
case 1733994801: return bem_emitLangGet_0();
case -1615839398: return bem_echo_0();
case -246868884: return bem_descriptionGet_0();
case -1043543071: return bem_create_0();
case 1032842558: return bem_vvGet_0();
case 2054171308: return bem_klassNameGetDirect_0();
case -1048585343: return bem_copy_0();
case 1376915081: return bem_translatedGetDirect_0();
case -1800587860: return bem_serializeToString_0();
case 1349337545: return bem_framesTextGet_0();
case 366313482: return bem_translateEmittedExceptionInner_0();
case 976768273: return bem_fieldNamesGet_0();
case -699303155: return bem_klassNameGet_0();
case -2011984947: return bem_classNameGet_0();
case -193453355: return bem_iteratorGet_0();
case -1601759347: return bem_framesGet_0();
case 2118260959: return bem_methodNameGet_0();
case 482260421: return bem_langGetDirect_0();
case -477940854: return bem_hashGet_0();
case -1970304376: return bem_methodNameGetDirect_0();
case -348114434: return bem_translatedGet_0();
case -1451050467: return bem_framesGetDirect_0();
case 977861454: return bem_vvGetDirect_0();
case 1463816718: return bem_sourceFileNameGet_0();
case -1021558772: return bem_fieldIteratorGet_0();
case -1852647932: return bem_serializeContents_0();
case 554825450: return bem_fileNameGet_0();
case 465593981: return bem_lineNumberGet_0();
case 190764838: return bem_toString_0();
case 795649196: return bem_serializationIteratorGet_0();
case 790003424: return bem_emitLangGetDirect_0();
case -204986197: return bem_print_0();
case 1677431513: return bem_framesTextGetDirect_0();
case -1017732045: return bem_toAny_0();
case 1809869265: return bem_many_0();
case 274572318: return bem_getFrameText_0();
case -1642760932: return bem_lineNumberGetDirect_0();
case 2022567405: return bem_tagGet_0();
case 604648320: return bem_fileNameGetDirect_0();
case -535880350: return bem_deserializeClassNameGet_0();
case -2047120798: return bem_translateEmittedException_0();
case -1200514874: return bem_once_0();
case -214764845: return bem_langGet_0();
case 451316734: return bem_new_0();
case 1548745299: return bem_descriptionGetDirect_0();
}
return base.bemd_0(callId);
}
public override BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) {
switch (callId) {
case -974417776: return bem_undef_1(bevd_0);
case 338652953: return bem_translatedSet_1(bevd_0);
case 525066903: return bem_methodNameSetDirect_1(bevd_0);
case -1405218070: return bem_fileNameSet_1(bevd_0);
case 449026795: return bem_equals_1(bevd_0);
case 1827918801: return bem_otherClass_1(bevd_0);
case 1255352870: return bem_notEquals_1(bevd_0);
case 649325163: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 649695446: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -766207612: return bem_sameObject_1(bevd_0);
case -1568620158: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 624590933: return bem_klassNameSetDirect_1(bevd_0);
case -1118699589: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 2145495702: return bem_descriptionSet_1(bevd_0);
case 662872972: return bem_lineNumberSetDirect_1(bevd_0);
case -1732342438: return bem_framesSetDirect_1(bevd_0);
case 143558124: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 381291994: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 110774735: return bem_sameType_1(bevd_0);
case -1518485395: return bem_framesSet_1(bevd_0);
case 1154055418: return bem_defined_1(bevd_0);
case -398663771: return bem_fileNameSetDirect_1(bevd_0);
case 1504651095: return bem_framesTextSet_1(bevd_0);
case 604637912: return bem_vvSet_1(bevd_0);
case -1184845164: return bem_klassNameSet_1(bevd_0);
case 1606463207: return bem_emitLangSetDirect_1(bevd_0);
case -204228929: return bem_langSet_1(bevd_0);
case 1317898590: return bem_new_1(bevd_0);
case -194126676: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case 226958950: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1641812003: return bem_descriptionSetDirect_1(bevd_0);
case 1395114855: return bem_vvSetDirect_1(bevd_0);
case -252330168: return bem_def_1(bevd_0);
case 1091332885: return bem_emitLangSet_1(bevd_0);
case -1494084791: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1229298038: return bem_lineNumberSet_1(bevd_0);
case 2121470516: return bem_langSetDirect_1(bevd_0);
case -248988725: return bem_framesTextSetDirect_1(bevd_0);
case -1021702482: return bem_otherType_1(bevd_0);
case -1407469734: return bem_methodNameSet_1(bevd_0);
case 1644097477: return bem_undefined_1(bevd_0);
case -984018743: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 915283682: return bem_translatedSetDirect_1(bevd_0);
case 1264098694: return bem_copyTo_1(bevd_0);
case -2113423029: return bem_sameClass_1(bevd_0);
}
return base.bemd_1(callId, bevd_0);
}
public override BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) {
switch (callId) {
case 2027545450: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 747590509: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1062769401: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 953897274: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 178951471: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1908358044: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1235279536: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return base.bemd_2(callId, bevd_0, bevd_1);
}
public override BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) {
switch (callId) {
case -1852196403: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return base.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public override BEC_2_4_6_TextString bemc_clnames() {
return new BEC_2_4_6_TextString(23, becc_BEC_2_6_16_SystemMethodNotDefined_clname);
}
public override BEC_2_4_6_TextString bemc_clfiles() {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_16_SystemMethodNotDefined_clfile);
}
public override BEC_2_6_6_SystemObject bemc_create() {
return new BEC_2_6_16_SystemMethodNotDefined();
}
public override void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) {
BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst = (BEC_2_6_16_SystemMethodNotDefined) becc_inst;
}
public override BEC_2_6_6_SystemObject bemc_getInitial() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_inst;
}
public override BETS_Object bemc_getType() {
return BEC_2_6_16_SystemMethodNotDefined.bece_BEC_2_6_16_SystemMethodNotDefined_bevs_type;
}
}
}
