package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_3_6_NetSocket extends BEC_2_6_6_SystemObject {
public BEC_2_3_6_NetSocket() { }

  public Socket bevi_socket;
  private static byte[] becc_BEC_2_3_6_NetSocket_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74};
private static byte[] becc_BEC_2_3_6_NetSocket_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_3_6_NetSocket bece_BEC_2_3_6_NetSocket_bevs_inst;
public BEC_3_3_6_6_NetSocketReader bem_readerGet_0() throws Throwable {
BEC_3_3_6_6_NetSocketReader bevl_sr = null;
bevl_sr = (BEC_3_3_6_6_NetSocketReader) (new BEC_3_3_6_6_NetSocketReader()).bem_new_0();

    bevl_sr.bevi_is = bevi_socket.getInputStream();
    bevl_sr.bem_extOpen_0();
return bevl_sr;
} /*method end*/
public BEC_3_3_6_6_NetSocketWriter bem_writerGet_0() throws Throwable {
BEC_3_3_6_6_NetSocketWriter bevl_sw = null;
bevl_sw = (BEC_3_3_6_6_NetSocketWriter) (new BEC_3_3_6_6_NetSocketWriter()).bem_new_0();

    bevl_sw.bevi_os = bevi_socket.getOutputStream();
    bevl_sw.bem_extOpen_0();
return bevl_sw;
} /*method end*/
public BEC_2_3_6_NetSocket bem_new_2(BEC_2_4_6_TextString beva_host, BEC_2_4_3_MathInt beva_port) throws Throwable {

    bevi_socket = new Socket(beva_host.bems_toJvString(), beva_port.bevi_int);
    return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {675, 686, 687, 691, 702, 703};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 17, 18, 22, 25, 26};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 675 14
new 0 675 14
extOpen 0 686 17
return 1 687 18
assign 1 691 22
new 0 691 22
extOpen 0 702 25
return 1 703 26
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callCase) throws Throwable {
switch (callCase) {
case -1409637413: return bem_readerGet_0();
case -1436664914: return bem_print_0();
case -373295708: return bem_serializeContents_0();
case -180143514: return bem_serializationIteratorGet_0();
case -1860146814: return bem_tagGet_0();
case -2116220804: return bem_new_0();
case -268338848: return bem_fieldIteratorGet_0();
case -454647513: return bem_once_0();
case -1021276807: return bem_copy_0();
case -633190672: return bem_writerGet_0();
case -453378259: return bem_deserializeClassNameGet_0();
case -2006878754: return bem_create_0();
case -1274969629: return bem_iteratorGet_0();
case 810650310: return bem_serializeToString_0();
case -1329156032: return bem_echo_0();
case 1737839713: return bem_toString_0();
case -1682959242: return bem_many_0();
case -681406586: return bem_hashGet_0();
case -605259456: return bem_toAny_0();
case -1250381101: return bem_classNameGet_0();
case -416881840: return bem_sourceFileNameGet_0();
}
return super.bemd_0(callCase);
}
public BEC_2_6_6_SystemObject bemd_1(int callCase, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callCase) {
case 14292419: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1468796062: return bem_sameType_1(bevd_0);
case -461593490: return bem_copyTo_1(bevd_0);
case -1196486530: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1688597634: return bem_sameClass_1(bevd_0);
case -935094060: return bem_undefined_1(bevd_0);
case -1480218954: return bem_def_1(bevd_0);
case -888403607: return bem_sameObject_1(bevd_0);
case -1728638213: return bem_otherClass_1(bevd_0);
case 1096308396: return bem_notEquals_1(bevd_0);
case -417583753: return bem_defined_1(bevd_0);
case 434478091: return bem_equals_1(bevd_0);
case 312688457: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -779433144: return bem_undef_1(bevd_0);
case 1922760127: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 98957888: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callCase, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callCase, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callCase) {
case 811659277: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -140724102: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 565033879: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1767747865: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 2047096971: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 656540134: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1888103: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1908857807: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callCase, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_3_6_NetSocket_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_3_6_NetSocket_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_6_NetSocket();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_inst = (BEC_2_3_6_NetSocket) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_inst;
}
}
