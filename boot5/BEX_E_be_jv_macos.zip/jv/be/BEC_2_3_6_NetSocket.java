package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public class BEC_2_3_6_NetSocket extends BEC_2_6_6_SystemObject {
public BEC_2_3_6_NetSocket() { }

  public Socket bevi_socket;
  private static byte[] becc_BEC_2_3_6_NetSocket_clname = {0x4E,0x65,0x74,0x3A,0x53,0x6F,0x63,0x6B,0x65,0x74};
private static byte[] becc_BEC_2_3_6_NetSocket_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_3_6_NetSocket bece_BEC_2_3_6_NetSocket_bevs_inst;

public static BET_2_3_6_NetSocket bece_BEC_2_3_6_NetSocket_bevs_type;

public BEC_3_3_6_6_NetSocketReader bem_readerGet_0() throws Throwable {
BEC_3_3_6_6_NetSocketReader bevl_sr = null;
bevl_sr = (BEC_3_3_6_6_NetSocketReader) (new BEC_3_3_6_6_NetSocketReader()).bem_new_0();

    bevl_sr.bevi_is = bevi_socket.getInputStream();
    bevl_sr.bem_extOpen_0();
return bevl_sr;
} /*method end*/
public BEC_3_3_6_6_NetSocketWriter bem_writerGet_0() throws Throwable {
BEC_3_3_6_6_NetSocketWriter bevl_sw = null;
bevl_sw = (BEC_3_3_6_6_NetSocketWriter) (new BEC_3_3_6_6_NetSocketWriter()).bem_new_0();

    bevl_sw.bevi_os = bevi_socket.getOutputStream();
    bevl_sw.bem_extOpen_0();
return bevl_sw;
} /*method end*/
public BEC_2_3_6_NetSocket bem_new_2(BEC_2_4_6_TextString beva_host, BEC_2_4_3_MathInt beva_port) throws Throwable {

    bevi_socket = new Socket(beva_host.bems_toJvString(), beva_port.bevi_int);
    return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {906, 917, 918, 922, 933, 934};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 20, 21, 25, 28, 29};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 906 17
new 0 906 17
extOpen 0 917 20
return 1 918 21
assign 1 922 25
new 0 922 25
extOpen 0 933 28
return 1 934 29
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -219220521: return bem_print_0();
case 1883566187: return bem_create_0();
case -1864159119: return bem_toString_0();
case -692315498: return bem_readerGet_0();
case -2014043122: return bem_hashGet_0();
case 1552604533: return bem_new_0();
case 48460261: return bem_writerGet_0();
case 312077991: return bem_copy_0();
case 1603058826: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1547701265: return bem_notEquals_1(bevd_0);
case 648644612: return bem_copyTo_1(bevd_0);
case -1373106803: return bem_print_1(bevd_0);
case -1474886087: return bem_equals_1(bevd_0);
case 1342301914: return bem_undef_1(bevd_0);
case 647518055: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 2141539312: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -827585189: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1135235556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -654018121: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 281117957: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(10, becc_BEC_2_3_6_NetSocket_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_3_6_NetSocket_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_6_NetSocket();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_inst = (BEC_2_3_6_NetSocket) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_6_NetSocket.bece_BEC_2_3_6_NetSocket_bevs_type;
}
}
