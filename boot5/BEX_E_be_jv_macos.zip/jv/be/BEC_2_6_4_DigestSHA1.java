package be;

import java.security.MessageDigest;
/* IO:File: source/base/Encode.be */
public class BEC_2_6_4_DigestSHA1 extends BEC_2_6_6_SystemObject {
public BEC_2_6_4_DigestSHA1() { }

   
    public MessageDigest bevi_md;
    
   private static byte[] becc_BEC_2_6_4_DigestSHA1_clname = {0x44,0x69,0x67,0x65,0x73,0x74,0x3A,0x53,0x48,0x41,0x31};
private static byte[] becc_BEC_2_6_4_DigestSHA1_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x6E,0x63,0x6F,0x64,0x65,0x2E,0x62,0x65};
public static BEC_2_6_4_DigestSHA1 bece_BEC_2_6_4_DigestSHA1_bevs_inst;

public static BET_2_6_4_DigestSHA1 bece_BEC_2_6_4_DigestSHA1_bevs_type;

public BEC_2_6_4_DigestSHA1 bem_new_0() throws Throwable {

        bevi_md = MessageDigest.getInstance("SHA-1");
        return this;
} /*method end*/
public BEC_2_4_6_TextString bem_digest_1(BEC_2_4_6_TextString beva_with) throws Throwable {
BEC_2_4_6_TextString bevl_res = null;
bem_new_0();

        bevi_md.update(beva_with.bevi_bytes, 0, beva_with.bevp_size.bevi_int);
        bevl_res = new BEC_2_4_6_TextString(bevi_md.digest());
        return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_digestToHex_1(BEC_2_4_6_TextString beva_input) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_6_3_EncodeHex bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_3_EncodeHex) BEC_2_6_3_EncodeHex.bece_BEC_2_6_3_EncodeHex_bevs_inst;
bevt_2_ta_ph = bem_digest_1(beva_input);
bevt_0_ta_ph = bevt_1_ta_ph.bem_encode_1(bevt_2_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {102, 117, 121, 121, 121, 121};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {24, 28, 34, 35, 36, 37};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
new 0 102 24
return 1 117 28
assign 1 121 34
new 0 121 34
assign 1 121 35
digest 1 121 35
assign 1 121 36
encode 1 121 36
return 1 121 37
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1005443364: return bem_create_0();
case 350812655: return bem_copy_0();
case -281350604: return bem_serializeContents_0();
case 2113534779: return bem_hashGet_0();
case 239077256: return bem_print_0();
case 2071875109: return bem_sourceFileNameGet_0();
case -157777737: return bem_fieldIteratorGet_0();
case 1393634620: return bem_serializeToString_0();
case 566573794: return bem_tagGet_0();
case 785161348: return bem_fieldNamesGet_0();
case 1587133120: return bem_classNameGet_0();
case 1645989341: return bem_iteratorGet_0();
case -2131640624: return bem_new_0();
case 873828646: return bem_deserializeClassNameGet_0();
case 969994032: return bem_serializationIteratorGet_0();
case 1464527658: return bem_toString_0();
case 1864861581: return bem_echo_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1835065603: return bem_digest_1((BEC_2_4_6_TextString) bevd_0);
case -396283576: return bem_undef_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case -744132660: return bem_digestToHex_1((BEC_2_4_6_TextString) bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_6_4_DigestSHA1_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_4_DigestSHA1_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_4_DigestSHA1();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_4_DigestSHA1.bece_BEC_2_6_4_DigestSHA1_bevs_inst = (BEC_2_6_4_DigestSHA1) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_4_DigestSHA1.bece_BEC_2_6_4_DigestSHA1_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_4_DigestSHA1.bece_BEC_2_6_4_DigestSHA1_bevs_type;
}
}
