package be;

import java.net.*;
/* IO:File: source/extended/EcPlat.be */
public final class BEC_2_6_11_SystemEnvironment extends BEC_2_6_6_SystemObject {
public BEC_2_6_11_SystemEnvironment() { }
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x6E,0x76,0x69,0x72,0x6F,0x6E,0x6D,0x65,0x6E,0x74};
private static byte[] becc_BEC_2_6_11_SystemEnvironment_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x45,0x63,0x50,0x6C,0x61,0x74,0x2E,0x62,0x65};
public static BEC_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_inst;

public static BET_2_6_11_SystemEnvironment bece_BEC_2_6_11_SystemEnvironment_bevs_type;

public BEC_2_4_6_TextString bem_getVariable_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevl_value = null;

            String value = System.getenv().get(beva_name.bems_toJvString());
            if (value != null) {
                bevl_value = new BEC_2_4_6_TextString(value);
            }
        return bevl_value;
} /*method end*/
public BEC_2_4_6_TextString bem_getVar_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_getVariable_1(beva_name);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {581, 585, 585};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {20, 24, 25};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
return 1 581 20
assign 1 585 24
getVariable 1 585 24
return 1 585 25
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 478950400: return bem_print_0();
case -1747597055: return bem_create_0();
case 2036051475: return bem_iteratorGet_0();
case 67700549: return bem_classNameGet_0();
case -1812965558: return bem_fieldIteratorGet_0();
case -1564975844: return bem_serializeContents_0();
case 1609612359: return bem_echo_0();
case 138302413: return bem_new_0();
case 556090396: return bem_sourceFileNameGet_0();
case 712783465: return bem_hashGet_0();
case 1267631579: return bem_serializationIteratorGet_0();
case 432179744: return bem_fieldNamesGet_0();
case -2106036149: return bem_deserializeClassNameGet_0();
case 1132429880: return bem_tagGet_0();
case 178019168: return bem_toString_0();
case -1627734356: return bem_serializeToString_0();
case -811046848: return bem_copy_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 257683973: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 2059692827: return bem_sameObject_1(bevd_0);
case -1084952852: return bem_undef_1(bevd_0);
case -60802666: return bem_otherClass_1(bevd_0);
case 399670111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -225795861: return bem_sameType_1(bevd_0);
case 465594002: return bem_def_1(bevd_0);
case -301008142: return bem_equals_1(bevd_0);
case 1964074985: return bem_otherType_1(bevd_0);
case -411756938: return bem_getVariable_1((BEC_2_4_6_TextString) bevd_0);
case 2036322012: return bem_getVar_1((BEC_2_4_6_TextString) bevd_0);
case 1951774795: return bem_copyTo_1(bevd_0);
case 606870566: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1184247111: return bem_sameClass_1(bevd_0);
case 2107311680: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1035176912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1679235980: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1107212100: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 471675441: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1306506121: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_6_11_SystemEnvironment_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_11_SystemEnvironment_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_11_SystemEnvironment();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst = (BEC_2_6_11_SystemEnvironment) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_11_SystemEnvironment.bece_BEC_2_6_11_SystemEnvironment_bevs_type;
}
}
