package be;
/* IO:File: source/build/Pass11.be */
public final class BEC_3_5_5_6_BuildVisitPass11 extends BEC_3_5_5_7_BuildVisitVisitor {
public BEC_3_5_5_6_BuildVisitPass11() { }
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass11_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x50,0x61,0x73,0x73,0x31,0x31};
private static byte[] becc_BEC_3_5_5_6_BuildVisitPass11_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x50,0x61,0x73,0x73,0x31,0x31,0x2E,0x62,0x65};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_0 = {0x73,0x65,0x6C,0x66};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_1 = {0x72,0x65,0x74,0x75,0x72,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_2 = {0x74,0x68,0x72,0x6F,0x77};
private static BEC_2_4_3_MathInt bece_BEC_3_5_5_6_BuildVisitPass11_bevo_0 = (new BEC_2_4_3_MathInt(2));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_3 = {0x54,0x68,0x69,0x73,0x20,0x74,0x79,0x70,0x65,0x20,0x6D,0x75,0x73,0x74,0x20,0x68,0x61,0x76,0x65,0x20,0x65,0x78,0x61,0x63,0x74,0x6C,0x79,0x20,0x6F,0x6E,0x65,0x20,0x61,0x6E,0x79,0x69,0x61,0x62,0x6C,0x65,0x2C,0x20,0x6E,0x6F,0x74,0x20};
private static BEC_2_4_6_TextString bece_BEC_3_5_5_6_BuildVisitPass11_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_3_5_5_6_BuildVisitPass11_bels_3, 46));
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_4 = {0x61,0x73,0x73,0x69,0x67,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_5 = {0x43,0x61,0x6C,0x6C,0x20,0x6E,0x6F,0x74,0x20,0x69,0x6E,0x20,0x63,0x6F,0x72,0x72,0x65,0x63,0x74,0x20,0x70,0x6F,0x73,0x69,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_3_5_5_6_BuildVisitPass11_bels_6 = {0x70,0x68,0x6F,0x6C,0x64};
public static BEC_3_5_5_6_BuildVisitPass11 bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst;

public static BET_3_5_5_6_BuildVisitPass11 bece_BEC_3_5_5_6_BuildVisitPass11_bevs_type;

public BEC_2_5_4_BuildNode bevp_inMtd;
public BEC_3_5_5_6_BuildVisitPass11 bem_new_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevl_fnode = null;
BEC_2_6_6_SystemObject bevl_it = null;
BEC_2_5_4_BuildNode bevl_inode = null;
BEC_2_5_3_BuildVar bevl_ts = null;
BEC_2_5_4_BuildNode bevl_nsc = null;
BEC_2_6_6_SystemObject bevl_nd = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_2_6_6_SystemObject bevl_unwind = null;
BEC_2_6_6_SystemObject bevl_c0 = null;
BEC_2_6_6_SystemObject bevl_cnode = null;
BEC_2_6_6_SystemObject bevl_lastStep = null;
BEC_2_6_6_SystemObject bevl_pholdv = null;
BEC_2_6_6_SystemObject bevl_phold = null;
BEC_2_6_6_SystemObject bevl_prc = null;
BEC_2_6_6_SystemObject bevl_prcc = null;
BEC_2_6_6_SystemObject bevl_phold2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_20_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_21_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_22_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_30_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_31_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_42_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_43_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_44_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_45_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_50_tmpany_phold = null;
BEC_2_9_8_ContainerNodeList bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_63_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_64_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_67_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_70_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_71_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_4_6_TextString bevt_76_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_82_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_83_tmpany_phold = null;
BEC_2_4_6_TextString bevt_84_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_85_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_86_tmpany_phold = null;
BEC_2_5_10_BuildVisitError bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_89_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_90_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_91_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_92_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_93_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_97_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_98_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_99_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_100_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_101_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_104_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_107_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_108_tmpany_phold = null;
BEC_2_5_4_BuildNode bevt_109_tmpany_phold = null;
bevt_8_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_9_tmpany_phold = bevp_ntypes.bem_EXPRGet_0();
if (bevt_8_tmpany_phold.bevi_int == bevt_9_tmpany_phold.bevi_int) {
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 22 */ {
bevl_fnode = null;
bevt_14_tmpany_phold = beva_node.bem_containedGet_0();
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bem_firstGet_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(-908528997);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(1788571792);
if (bevt_11_tmpany_phold == null) {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_10_tmpany_phold.bevi_bool) /* Line: 24 */ {
bevl_fnode = beva_node.bem_nextDescendGet_0();
} /* Line: 25 */
bevt_17_tmpany_phold = beva_node.bem_containedGet_0();
bevt_16_tmpany_phold = bevt_17_tmpany_phold.bem_firstGet_0();
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(-908528997);
bevl_it = bevt_15_tmpany_phold.bemd_0(-1019129421);
while (true)
 /* Line: 27 */ {
bevt_18_tmpany_phold = bevl_it.bemd_0(1239585548);
if (((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 27 */ {
bevl_inode = (BEC_2_5_4_BuildNode) bevl_it.bemd_0(-1161084880);
if (bevl_fnode == null) {
bevt_19_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_19_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_19_tmpany_phold.bevi_bool) /* Line: 29 */ {
bevl_fnode = bevl_inode;
} /* Line: 30 */
beva_node.bem_beforeInsert_1(bevl_inode);
} /* Line: 32 */
 else  /* Line: 27 */ {
break;
} /* Line: 27 */
} /* Line: 27 */
beva_node.bem_delete_0();
return bevl_fnode;
} /* Line: 35 */
bevt_21_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_22_tmpany_phold = bevp_ntypes.bem_METHODGet_0();
if (bevt_21_tmpany_phold.bevi_int == bevt_22_tmpany_phold.bevi_int) {
bevt_20_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_20_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_20_tmpany_phold.bevi_bool) /* Line: 37 */ {
bevp_inMtd = beva_node;
bevt_25_tmpany_phold = beva_node.bem_heldGet_0();
bevt_24_tmpany_phold = bevt_25_tmpany_phold.bemd_0(-49898240);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_0));
bevt_23_tmpany_phold = bevt_24_tmpany_phold.bemd_1(-1289225920, bevt_26_tmpany_phold);
bevl_ts = (BEC_2_5_3_BuildVar) bevt_23_tmpany_phold.bemd_0(-1151582682);
bevt_27_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_ts.bem_isTypedSet_1(bevt_27_tmpany_phold);
bevt_30_tmpany_phold = beva_node.bem_classGet_0();
bevt_29_tmpany_phold = bevt_30_tmpany_phold.bemd_0(-1151582682);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(-480409067);
bevl_ts.bem_namepathSet_1(bevt_28_tmpany_phold);
} /* Line: 41 */
bevt_32_tmpany_phold = beva_node.bem_typenameGet_0();
bevt_33_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
if (bevt_32_tmpany_phold.bevi_int == bevt_33_tmpany_phold.bevi_int) {
bevt_31_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_31_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_31_tmpany_phold.bevi_bool) /* Line: 46 */ {
bevt_36_tmpany_phold = beva_node.bem_heldGet_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bemd_0(1020075506);
bevt_37_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_1));
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1149328783, bevt_37_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_40_tmpany_phold = beva_node.bem_heldGet_0();
bevt_39_tmpany_phold = bevt_40_tmpany_phold.bemd_0(1020075506);
bevt_41_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_6_BuildVisitPass11_bels_2));
bevt_38_tmpany_phold = bevt_39_tmpany_phold.bemd_1(1149328783, bevt_41_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_38_tmpany_phold).bevi_bool) /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevt_44_tmpany_phold = beva_node.bem_containedGet_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_lengthGet_0();
bevt_45_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass11_bevo_0;
if (bevt_43_tmpany_phold.bevi_int > bevt_45_tmpany_phold.bevi_int) {
bevt_42_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_42_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_42_tmpany_phold.bevi_bool) /* Line: 48 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 48 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 48 */
 else  /* Line: 48 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 48 */ {
bevt_48_tmpany_phold = bece_BEC_3_5_5_6_BuildVisitPass11_bevo_1;
bevt_51_tmpany_phold = beva_node.bem_containedGet_0();
bevt_50_tmpany_phold = bevt_51_tmpany_phold.bem_lengthGet_0();
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_toString_0();
bevt_47_tmpany_phold = bevt_48_tmpany_phold.bem_add_1(bevt_49_tmpany_phold);
bevt_46_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_47_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_46_tmpany_phold);
} /* Line: 49 */
bevt_54_tmpany_phold = beva_node.bem_heldGet_0();
bevt_53_tmpany_phold = bevt_54_tmpany_phold.bemd_0(1020075506);
bevt_55_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_1));
bevt_52_tmpany_phold = bevt_53_tmpany_phold.bemd_1(1149328783, bevt_55_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_52_tmpany_phold).bevi_bool) /* Line: 51 */ {
bevt_58_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_57_tmpany_phold = bevt_58_tmpany_phold.bemd_0(57785363);
if (bevt_57_tmpany_phold == null) {
bevt_56_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_56_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_56_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_61_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(57785363);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(568839147);
if (((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 52 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 52 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 52 */
 else  /* Line: 52 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 52 */ {
bevl_nsc = beva_node.bem_firstGet_0();
if (bevl_nsc == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_64_tmpany_phold = bevl_nsc.bem_typenameGet_0();
bevt_65_tmpany_phold = bevp_ntypes.bem_VARGet_0();
if (bevt_64_tmpany_phold.bevi_int == bevt_65_tmpany_phold.bevi_int) {
bevt_63_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_63_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_63_tmpany_phold.bevi_bool) /* Line: 60 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 60 */ {
bevt_68_tmpany_phold = bevl_nsc.bem_heldGet_0();
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bemd_0(1020075506);
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_0));
bevt_66_tmpany_phold = bevt_67_tmpany_phold.bemd_1(1149328783, bevt_69_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_66_tmpany_phold).bevi_bool) /* Line: 60 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 60 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 60 */
 else  /* Line: 60 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 60 */ {
} /* Line: 60 */
 else  /* Line: 62 */ {
bevt_70_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_70_tmpany_phold.bemd_1(-1850707785, null);
} /* Line: 64 */
} /* Line: 60 */
} /* Line: 52 */
bevt_73_tmpany_phold = beva_node.bem_heldGet_0();
bevt_72_tmpany_phold = bevt_73_tmpany_phold.bemd_0(855944002);
bevt_71_tmpany_phold = bevt_72_tmpany_phold.bemd_0(353891216);
if (((BEC_2_5_4_LogicBool) bevt_71_tmpany_phold).bevi_bool) /* Line: 68 */ {
bevl_nd = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_nd.bemd_1(-95960093, beva_node);
bevt_75_tmpany_phold = bevp_inMtd.bem_heldGet_0();
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(-49898240);
bevt_76_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_3_5_5_6_BuildVisitPass11_bels_0));
bevl_v = bevt_74_tmpany_phold.bemd_1(-1289225920, bevt_76_tmpany_phold);
bevt_77_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_nd.bemd_1(-446321038, bevt_77_tmpany_phold);
bevt_78_tmpany_phold = bevl_v.bemd_0(-1151582682);
bevl_nd.bemd_1(-2008008050, bevt_78_tmpany_phold);
bevt_79_tmpany_phold = beva_node.bem_heldGet_0();
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
bevt_79_tmpany_phold.bemd_1(-783006561, bevt_80_tmpany_phold);
beva_node.bem_prepend_1((BEC_2_5_4_BuildNode) bevl_nd );
} /* Line: 75 */
bevt_83_tmpany_phold = beva_node.bem_heldGet_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bemd_0(1020075506);
bevt_84_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_4));
bevt_81_tmpany_phold = bevt_82_tmpany_phold.bemd_1(1149328783, bevt_84_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_81_tmpany_phold).bevi_bool) /* Line: 78 */ {
bevt_85_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_85_tmpany_phold;
} /* Line: 79 */
bevl_unwind = be.BECS_Runtime.boolTrue;
bevl_c0 = beva_node.bem_containerGet_0();
if (bevl_c0 == null) {
bevt_86_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_86_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_86_tmpany_phold.bevi_bool) /* Line: 83 */ {
bevt_88_tmpany_phold = (new BEC_2_4_6_TextString(28, bece_BEC_3_5_5_6_BuildVisitPass11_bels_5));
bevt_87_tmpany_phold = (new BEC_2_5_10_BuildVisitError()).bem_new_2(bevt_88_tmpany_phold, beva_node);
throw new be.BECS_ThrowBack(bevt_87_tmpany_phold);
} /* Line: 84 */
bevt_90_tmpany_phold = bevl_c0.bemd_0(1216430283);
bevt_91_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_89_tmpany_phold = bevt_90_tmpany_phold.bemd_1(1149328783, bevt_91_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_89_tmpany_phold).bevi_bool) /* Line: 88 */ {
bevt_94_tmpany_phold = bevl_c0.bemd_0(-1151582682);
bevt_93_tmpany_phold = bevt_94_tmpany_phold.bemd_0(1020075506);
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_4));
bevt_92_tmpany_phold = bevt_93_tmpany_phold.bemd_1(1149328783, bevt_95_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_92_tmpany_phold).bevi_bool) /* Line: 88 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
 else  /* Line: 88 */ {
bevt_6_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_6_tmpany_anchor.bevi_bool) /* Line: 88 */ {
bevt_96_tmpany_phold = beva_node.bem_isSecondGet_0();
if (bevt_96_tmpany_phold.bevi_bool) /* Line: 88 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 88 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 88 */
 else  /* Line: 88 */ {
bevt_5_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_5_tmpany_anchor.bevi_bool) /* Line: 88 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 89 */
 else  /* Line: 88 */ {
bevt_98_tmpany_phold = bevl_c0.bemd_0(1216430283);
bevt_99_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_97_tmpany_phold = bevt_98_tmpany_phold.bemd_1(1149328783, bevt_99_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_97_tmpany_phold).bevi_bool) /* Line: 90 */ {
bevl_unwind = be.BECS_Runtime.boolFalse;
} /* Line: 91 */
} /* Line: 88 */
if (((BEC_2_5_4_LogicBool) bevl_unwind).bevi_bool) /* Line: 93 */ {
bevl_cnode = bevl_c0;
bevl_lastStep = null;
while (true)
 /* Line: 98 */ {
bevt_101_tmpany_phold = bevl_cnode.bemd_0(1216430283);
bevt_102_tmpany_phold = bevp_ntypes.bem_BRACESGet_0();
bevt_100_tmpany_phold = bevt_101_tmpany_phold.bemd_1(-62499290, bevt_102_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_100_tmpany_phold).bevi_bool) /* Line: 98 */ {
bevl_lastStep = bevl_cnode;
bevl_cnode = bevl_cnode.bemd_0(-556996160);
} /* Line: 101 */
 else  /* Line: 98 */ {
break;
} /* Line: 98 */
} /* Line: 98 */
bevt_103_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_3_5_5_6_BuildVisitPass11_bels_6));
bevl_pholdv = bevl_lastStep.bemd_2(1574665469, bevt_103_tmpany_phold, bevp_build);
bevl_phold = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold.bemd_1(-95960093, beva_node);
bevt_104_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold.bemd_1(-446321038, bevt_104_tmpany_phold);
bevl_phold.bemd_1(-2008008050, bevl_pholdv);
beva_node.bem_replaceWith_1((BEC_2_5_4_BuildNode) bevl_phold );
bevl_phold.bemd_0(504596941);
bevl_prc = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_prc.bemd_1(-95960093, beva_node);
bevt_105_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevl_prc.bemd_1(-446321038, bevt_105_tmpany_phold);
bevl_prcc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_106_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_3_5_5_6_BuildVisitPass11_bels_4));
bevl_prcc.bemd_1(-2131506732, bevt_106_tmpany_phold);
bevl_prc.bemd_1(-2008008050, bevl_prcc);
bevl_phold2 = (new BEC_2_5_4_BuildNode()).bem_new_1(bevp_build);
bevl_phold2.bemd_1(-95960093, beva_node);
bevt_107_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevl_phold2.bemd_1(-446321038, bevt_107_tmpany_phold);
bevl_phold2.bemd_1(-2008008050, bevl_pholdv);
bevl_prc.bemd_1(-416017260, bevl_phold2);
bevl_prc.bemd_1(-416017260, beva_node);
bevl_lastStep.bemd_1(1082371513, bevl_prc);
bevt_108_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_108_tmpany_phold;
} /* Line: 126 */
} /* Line: 93 */
bevt_109_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_109_tmpany_phold;
} /*method end*/
public BEC_2_5_4_BuildNode bem_inMtdGet_0() throws Throwable {
return bevp_inMtd;
} /*method end*/
public final BEC_2_5_4_BuildNode bem_inMtdGetDirect_0() throws Throwable {
return bevp_inMtd;
} /*method end*/
public BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_6_BuildVisitPass11 bem_inMtdSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_inMtd = (BEC_2_5_4_BuildNode) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {22, 22, 22, 22, 23, 24, 24, 24, 24, 24, 24, 25, 27, 27, 27, 27, 27, 28, 29, 29, 30, 32, 34, 35, 37, 37, 37, 37, 38, 39, 39, 39, 39, 39, 40, 40, 41, 41, 41, 41, 46, 46, 46, 46, 48, 48, 48, 48, 0, 48, 48, 48, 48, 0, 0, 48, 48, 48, 48, 48, 0, 0, 0, 49, 49, 49, 49, 49, 49, 49, 51, 51, 51, 51, 52, 52, 52, 52, 52, 52, 52, 0, 0, 0, 59, 60, 60, 60, 60, 60, 60, 0, 0, 0, 60, 60, 60, 60, 0, 0, 0, 64, 64, 68, 68, 68, 69, 70, 71, 71, 71, 71, 72, 72, 73, 73, 74, 74, 74, 75, 78, 78, 78, 78, 79, 79, 81, 82, 83, 83, 84, 84, 84, 88, 88, 88, 88, 88, 88, 88, 0, 0, 0, 88, 0, 0, 0, 89, 90, 90, 90, 91, 94, 95, 98, 98, 98, 100, 101, 106, 106, 107, 108, 109, 109, 110, 111, 112, 113, 114, 115, 115, 116, 117, 117, 118, 119, 120, 121, 121, 122, 123, 124, 125, 126, 126, 129, 129, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {151, 152, 153, 158, 159, 160, 161, 162, 163, 164, 169, 170, 172, 173, 174, 175, 178, 180, 181, 186, 187, 189, 195, 196, 198, 199, 200, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 219, 220, 221, 226, 227, 228, 229, 230, 232, 235, 236, 237, 238, 240, 243, 247, 248, 249, 250, 255, 256, 259, 263, 266, 267, 268, 269, 270, 271, 272, 274, 275, 276, 277, 279, 280, 281, 286, 287, 288, 289, 291, 294, 298, 301, 302, 307, 308, 309, 310, 315, 316, 319, 323, 326, 327, 328, 329, 331, 334, 338, 343, 344, 348, 349, 350, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 367, 368, 369, 370, 372, 373, 375, 376, 377, 382, 383, 384, 385, 387, 388, 389, 391, 392, 393, 394, 396, 399, 403, 406, 408, 411, 415, 418, 421, 422, 423, 425, 429, 430, 433, 434, 435, 437, 438, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 473, 474, 477, 480, 483, 487};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 22 151
typenameGet 0 22 151
assign 1 22 152
EXPRGet 0 22 152
assign 1 22 153
equals 1 22 158
assign 1 23 159
assign 1 24 160
containedGet 0 24 160
assign 1 24 161
firstGet 0 24 161
assign 1 24 162
containedGet 0 24 162
assign 1 24 163
firstNodeGet 0 24 163
assign 1 24 164
undef 1 24 169
assign 1 25 170
nextDescendGet 0 25 170
assign 1 27 172
containedGet 0 27 172
assign 1 27 173
firstGet 0 27 173
assign 1 27 174
containedGet 0 27 174
assign 1 27 175
iteratorGet 0 27 175
assign 1 27 178
hasNextGet 0 27 178
assign 1 28 180
nextGet 0 28 180
assign 1 29 181
undef 1 29 186
assign 1 30 187
beforeInsert 1 32 189
delete 0 34 195
return 1 35 196
assign 1 37 198
typenameGet 0 37 198
assign 1 37 199
METHODGet 0 37 199
assign 1 37 200
equals 1 37 205
assign 1 38 206
assign 1 39 207
heldGet 0 39 207
assign 1 39 208
anyMapGet 0 39 208
assign 1 39 209
new 0 39 209
assign 1 39 210
get 1 39 210
assign 1 39 211
heldGet 0 39 211
assign 1 40 212
new 0 40 212
isTypedSet 1 40 213
assign 1 41 214
classGet 0 41 214
assign 1 41 215
heldGet 0 41 215
assign 1 41 216
namepathGet 0 41 216
namepathSet 1 41 217
assign 1 46 219
typenameGet 0 46 219
assign 1 46 220
CALLGet 0 46 220
assign 1 46 221
equals 1 46 226
assign 1 48 227
heldGet 0 48 227
assign 1 48 228
nameGet 0 48 228
assign 1 48 229
new 0 48 229
assign 1 48 230
equals 1 48 230
assign 1 0 232
assign 1 48 235
heldGet 0 48 235
assign 1 48 236
nameGet 0 48 236
assign 1 48 237
new 0 48 237
assign 1 48 238
equals 1 48 238
assign 1 0 240
assign 1 0 243
assign 1 48 247
containedGet 0 48 247
assign 1 48 248
lengthGet 0 48 248
assign 1 48 249
new 0 48 249
assign 1 48 250
greater 1 48 255
assign 1 0 256
assign 1 0 259
assign 1 0 263
assign 1 49 266
new 0 49 266
assign 1 49 267
containedGet 0 49 267
assign 1 49 268
lengthGet 0 49 268
assign 1 49 269
toString 0 49 269
assign 1 49 270
add 1 49 270
assign 1 49 271
new 2 49 271
throw 1 49 272
assign 1 51 274
heldGet 0 51 274
assign 1 51 275
nameGet 0 51 275
assign 1 51 276
new 0 51 276
assign 1 51 277
equals 1 51 277
assign 1 52 279
heldGet 0 52 279
assign 1 52 280
rtypeGet 0 52 280
assign 1 52 281
def 1 52 286
assign 1 52 287
heldGet 0 52 287
assign 1 52 288
rtypeGet 0 52 288
assign 1 52 289
impliedGet 0 52 289
assign 1 0 291
assign 1 0 294
assign 1 0 298
assign 1 59 301
firstGet 0 59 301
assign 1 60 302
def 1 60 307
assign 1 60 308
typenameGet 0 60 308
assign 1 60 309
VARGet 0 60 309
assign 1 60 310
equals 1 60 315
assign 1 0 316
assign 1 0 319
assign 1 0 323
assign 1 60 326
heldGet 0 60 326
assign 1 60 327
nameGet 0 60 327
assign 1 60 328
new 0 60 328
assign 1 60 329
equals 1 60 329
assign 1 0 331
assign 1 0 334
assign 1 0 338
assign 1 64 343
heldGet 0 64 343
rtypeSet 1 64 344
assign 1 68 348
heldGet 0 68 348
assign 1 68 349
boundGet 0 68 349
assign 1 68 350
not 0 68 350
assign 1 69 352
new 1 69 352
copyLoc 1 70 353
assign 1 71 354
heldGet 0 71 354
assign 1 71 355
anyMapGet 0 71 355
assign 1 71 356
new 0 71 356
assign 1 71 357
get 1 71 357
assign 1 72 358
VARGet 0 72 358
typenameSet 1 72 359
assign 1 73 360
heldGet 0 73 360
heldSet 1 73 361
assign 1 74 362
heldGet 0 74 362
assign 1 74 363
new 0 74 363
boundSet 1 74 364
prepend 1 75 365
assign 1 78 367
heldGet 0 78 367
assign 1 78 368
nameGet 0 78 368
assign 1 78 369
new 0 78 369
assign 1 78 370
equals 1 78 370
assign 1 79 372
nextDescendGet 0 79 372
return 1 79 373
assign 1 81 375
new 0 81 375
assign 1 82 376
containerGet 0 82 376
assign 1 83 377
undef 1 83 382
assign 1 84 383
new 0 84 383
assign 1 84 384
new 2 84 384
throw 1 84 385
assign 1 88 387
typenameGet 0 88 387
assign 1 88 388
CALLGet 0 88 388
assign 1 88 389
equals 1 88 389
assign 1 88 391
heldGet 0 88 391
assign 1 88 392
nameGet 0 88 392
assign 1 88 393
new 0 88 393
assign 1 88 394
equals 1 88 394
assign 1 0 396
assign 1 0 399
assign 1 0 403
assign 1 88 406
isSecondGet 0 88 406
assign 1 0 408
assign 1 0 411
assign 1 0 415
assign 1 89 418
new 0 89 418
assign 1 90 421
typenameGet 0 90 421
assign 1 90 422
BRACESGet 0 90 422
assign 1 90 423
equals 1 90 423
assign 1 91 425
new 0 91 425
assign 1 94 429
assign 1 95 430
assign 1 98 433
typenameGet 0 98 433
assign 1 98 434
BRACESGet 0 98 434
assign 1 98 435
notEquals 1 98 435
assign 1 100 437
assign 1 101 438
containerGet 0 101 438
assign 1 106 444
new 0 106 444
assign 1 106 445
tmpVar 2 106 445
assign 1 107 446
new 1 107 446
copyLoc 1 108 447
assign 1 109 448
VARGet 0 109 448
typenameSet 1 109 449
heldSet 1 110 450
replaceWith 1 111 451
addVariable 0 112 452
assign 1 113 453
new 1 113 453
copyLoc 1 114 454
assign 1 115 455
CALLGet 0 115 455
typenameSet 1 115 456
assign 1 116 457
new 0 116 457
assign 1 117 458
new 0 117 458
nameSet 1 117 459
heldSet 1 118 460
assign 1 119 461
new 1 119 461
copyLoc 1 120 462
assign 1 121 463
VARGet 0 121 463
typenameSet 1 121 464
heldSet 1 122 465
addValue 1 123 466
addValue 1 124 467
beforeInsert 1 125 468
assign 1 126 469
nextDescendGet 0 126 469
return 1 126 470
assign 1 129 473
nextDescendGet 0 129 473
return 1 129 474
return 1 0 477
return 1 0 480
assign 1 0 483
assign 1 0 487
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1544637441: return bem_fieldIteratorGet_0();
case -916808790: return bem_serializeToString_0();
case 166740524: return bem_transGet_0();
case -1440519528: return bem_new_0();
case 1516528362: return bem_copy_0();
case -352222734: return bem_echo_0();
case -1857169421: return bem_print_0();
case -1019129421: return bem_iteratorGet_0();
case 1256493526: return bem_create_0();
case 1966604989: return bem_deserializeClassNameGet_0();
case 415444144: return bem_many_0();
case -723794363: return bem_inMtdGet_0();
case 1977268733: return bem_toAny_0();
case -424925403: return bem_buildGet_0();
case 1640160430: return bem_serializationIteratorGet_0();
case -2074213292: return bem_constGetDirect_0();
case 989509404: return bem_inMtdGetDirect_0();
case 1051978438: return bem_transGetDirect_0();
case 1812683690: return bem_ntypesGetDirect_0();
case -1459660688: return bem_once_0();
case 764111846: return bem_classNameGet_0();
case -2027075098: return bem_sourceFileNameGet_0();
case 1464556610: return bem_serializeContents_0();
case 647733846: return bem_hashGet_0();
case 239286271: return bem_constGet_0();
case -1322750582: return bem_fieldNamesGet_0();
case 810516096: return bem_tagGet_0();
case 1088817237: return bem_buildGetDirect_0();
case -2042019182: return bem_toString_0();
case 1812206078: return bem_ntypesGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1451816788: return bem_otherType_1(bevd_0);
case -1066262854: return bem_copyTo_1(bevd_0);
case -2113151813: return bem_otherClass_1(bevd_0);
case -1430240100: return bem_begin_1(bevd_0);
case 1686689499: return bem_sameType_1(bevd_0);
case 129664577: return bem_undefined_1(bevd_0);
case 858949566: return bem_sameObject_1(bevd_0);
case -299542469: return bem_inMtdSet_1(bevd_0);
case 1149328783: return bem_equals_1(bevd_0);
case -1157915379: return bem_transSetDirect_1(bevd_0);
case -1103921791: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1726382580: return bem_undef_1(bevd_0);
case 1429656082: return bem_constSet_1(bevd_0);
case -62499290: return bem_notEquals_1(bevd_0);
case 173437066: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1884560238: return bem_sameClass_1(bevd_0);
case -1886199591: return bem_constSetDirect_1(bevd_0);
case -1452535812: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1693595005: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 603933893: return bem_end_1(bevd_0);
case -1180569389: return bem_buildSet_1(bevd_0);
case 1303995883: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1529930548: return bem_def_1(bevd_0);
case -459023737: return bem_transSet_1(bevd_0);
case -1444423298: return bem_buildSetDirect_1(bevd_0);
case 456604916: return bem_defined_1(bevd_0);
case 1736506620: return bem_inMtdSetDirect_1(bevd_0);
case 2135906393: return bem_ntypesSet_1(bevd_0);
case -250840679: return bem_ntypesSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -840184945: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 2113325337: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1732137967: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1058450326: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1752849240: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1337367239: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 572204899: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_3_5_5_6_BuildVisitPass11_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_3_5_5_6_BuildVisitPass11_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_6_BuildVisitPass11();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst = (BEC_3_5_5_6_BuildVisitPass11) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_6_BuildVisitPass11.bece_BEC_3_5_5_6_BuildVisitPass11_bevs_type;
}
}
