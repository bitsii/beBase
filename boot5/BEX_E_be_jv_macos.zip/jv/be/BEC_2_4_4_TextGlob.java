package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_4_4_TextGlob extends BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
private static byte[] becc_BEC_2_4_4_TextGlob_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_BEC_2_4_4_TextGlob_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_0 = {0x2A,0x3F};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_1 = {0x2A};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_2 = {0x3F};
public static BEC_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_inst;

public static BET_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_type;

public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
bem_globSet_1(beva__glob);
return this;
} /*method end*/
public BEC_2_4_4_TextGlob bem_globSet_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_4_TextGlob_bels_0));
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tok = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_ph.bemd_0(-1627672635);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = bem_caseMatch_4(bevl_node, beva_input, bevt_2_ta_ph, null);
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) throws Throwable {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
if (beva_node == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1013*/ {
bevt_2_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1014*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1015*/
 else /* Line: 1016*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 1017*/
} /* Line: 1014*/
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_4_TextGlob_bels_1));
bevt_5_ta_ph = bevl_val.bem_equals_1(bevt_6_ta_ph);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1021*/ {
bevt_7_ta_ph = bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_ta_ph;
} /* Line: 1022*/
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_4_TextGlob_bels_2));
bevt_8_ta_ph = bevl_val.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 1024*/ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1026*/ {
bevt_13_ta_ph = beva_node.bem_nextGet_0();
bevt_12_ta_ph = bem_caseMatch_4(bevt_13_ta_ph, beva_input, beva_pos, null);
return bevt_12_ta_ph;
} /* Line: 1026*/
 else /* Line: 1026*/ {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_14_ta_ph;
} /* Line: 1026*/
} /* Line: 1026*/
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 1029*/ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 1030*/ {
bevt_18_ta_ph = beva_node.bem_nextGet_0();
bevt_20_ta_ph = bevl_val.bem_sizeGet_0();
bevt_19_ta_ph = beva_pos.bem_add_1(bevt_20_ta_ph);
bevt_17_ta_ph = bem_caseMatch_4(bevt_18_ta_ph, beva_input, bevt_19_ta_ph, null);
return bevt_17_ta_ph;
} /* Line: 1031*/
 else /* Line: 1032*/ {
if (beva_lpos == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 1033*/ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 1034*/
} /* Line: 1033*/
} /* Line: 1030*/
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_22_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
/* Line: 1045*/ {
bevt_1_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1045*/ {
bevl_ok = bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool)/* Line: 1047*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1047*/
bevt_4_ta_ph = bevl_lpos.bem_firstGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1048*/ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 1050*/
 else /* Line: 1051*/ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 1052*/
} /* Line: 1048*/
 else /* Line: 1045*/ {
break;
} /* Line: 1045*/
} /* Line: 1045*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_globGet_0() throws Throwable {
return bevp_glob;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() throws Throwable {
return bevp_splits;
} /*method end*/
public BEC_2_4_4_TextGlob bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {990, 994, 994, 994, 995, 997, 998, 1008, 1008, 1009, 1009, 1009, 1013, 1013, 1014, 1014, 1014, 1015, 1015, 1017, 1017, 1020, 1021, 1021, 1022, 1022, 1024, 1024, 1025, 1026, 1026, 1026, 1026, 1026, 1026, 1026, 1026, 1028, 1029, 1029, 1030, 1030, 1031, 1031, 1031, 1031, 1031, 1033, 1033, 1034, 1038, 1038, 1042, 1043, 1045, 1045, 1045, 1046, 1047, 1047, 1048, 1048, 1048, 1049, 1050, 1052, 1055, 1055, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 27, 28, 29, 30, 31, 32, 40, 41, 42, 43, 44, 72, 77, 78, 79, 84, 85, 86, 89, 90, 93, 94, 95, 97, 98, 100, 101, 103, 104, 105, 110, 111, 112, 113, 116, 117, 120, 121, 126, 127, 132, 133, 134, 135, 136, 137, 140, 145, 146, 150, 151, 163, 164, 167, 168, 173, 174, 176, 177, 179, 180, 185, 186, 187, 190, 197, 198, 201, 204, 207};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
globSet 1 990 19
assign 1 994 27
new 0 994 27
assign 1 994 28
new 0 994 28
assign 1 994 29
new 2 994 29
assign 1 995 30
tokenize 1 995 30
assign 1 997 31
assign 1 998 32
assign 1 1008 40
iteratorGet 0 1008 40
assign 1 1008 41
nextNodeGet 0 1008 41
assign 1 1009 42
new 0 1009 42
assign 1 1009 43
caseMatch 4 1009 43
return 1 1009 44
assign 1 1013 72
undef 1 1013 77
assign 1 1014 78
sizeGet 0 1014 78
assign 1 1014 79
equals 1 1014 84
assign 1 1015 85
new 0 1015 85
return 1 1015 86
assign 1 1017 89
new 0 1017 89
return 1 1017 90
assign 1 1020 93
heldGet 0 1020 93
assign 1 1021 94
new 0 1021 94
assign 1 1021 95
equals 1 1021 95
assign 1 1022 97
starMatch 3 1022 97
return 1 1022 98
assign 1 1024 100
new 0 1024 100
assign 1 1024 101
equals 1 1024 101
assign 1 1025 103
increment 0 1025 103
assign 1 1026 104
sizeGet 0 1026 104
assign 1 1026 105
lesserEquals 1 1026 110
assign 1 1026 111
nextGet 0 1026 111
assign 1 1026 112
caseMatch 4 1026 112
return 1 1026 113
assign 1 1026 116
new 0 1026 116
return 1 1026 117
assign 1 1028 120
find 2 1028 120
assign 1 1029 121
def 1 1029 126
assign 1 1030 127
equals 1 1030 132
assign 1 1031 133
nextGet 0 1031 133
assign 1 1031 134
sizeGet 0 1031 134
assign 1 1031 135
add 1 1031 135
assign 1 1031 136
caseMatch 4 1031 136
return 1 1031 137
assign 1 1033 140
def 1 1033 145
firstSet 1 1034 146
assign 1 1038 150
new 0 1038 150
return 1 1038 151
assign 1 1042 163
nextGet 0 1042 163
assign 1 1043 164
new 0 1043 164
assign 1 1045 167
sizeGet 0 1045 167
assign 1 1045 168
lesserEquals 1 1045 173
assign 1 1046 174
caseMatch 4 1046 174
assign 1 1047 176
new 0 1047 176
return 1 1047 177
assign 1 1048 179
firstGet 0 1048 179
assign 1 1048 180
def 1 1048 185
assign 1 1049 186
firstGet 0 1049 186
firstSet 1 1050 187
assign 1 1052 190
increment 0 1052 190
assign 1 1055 197
new 0 1055 197
return 1 1055 198
return 1 0 201
return 1 0 204
assign 1 0 207
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 49169285: return bem_create_0();
case -7476103: return bem_hashGet_0();
case 1631198925: return bem_print_0();
case -2129238938: return bem_fieldNamesGet_0();
case 2115475884: return bem_new_0();
case -234716928: return bem_globGet_0();
case -854129615: return bem_classNameGet_0();
case 744789579: return bem_tagGet_0();
case 956564530: return bem_toString_0();
case -6785712: return bem_copy_0();
case -1058462742: return bem_splitsGet_0();
case 235554219: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1005385637: return bem_copyTo_1(bevd_0);
case 13716396: return bem_splitsSet_1(bevd_0);
case -76922352: return bem_equals_1(bevd_0);
case -2052423771: return bem_notEquals_1(bevd_0);
case -1554337727: return bem_sameObject_1(bevd_0);
case -1184273709: return bem_undef_1(bevd_0);
case -2142487980: return bem_sameType_1(bevd_0);
case -268082121: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1338190085: return bem_def_1(bevd_0);
case -927463284: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case -1256020058: return bem_otherType_1(bevd_0);
case -231576531: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
case 1149746123: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -829590487: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -744751889: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1116067959: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -383996467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1363599577: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1273616576: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -423018349: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_TextGlob_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_4_4_TextGlob_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_4_TextGlob();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst = (BEC_2_4_4_TextGlob) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_type;
}
}
