package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_4_4_TextGlob extends BEC_2_6_6_SystemObject {
public BEC_2_4_4_TextGlob() { }
private static byte[] becc_BEC_2_4_4_TextGlob_clname = {0x54,0x65,0x78,0x74,0x3A,0x47,0x6C,0x6F,0x62};
private static byte[] becc_BEC_2_4_4_TextGlob_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_0 = {0x2A,0x3F};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_1 = {0x2A};
private static byte[] bece_BEC_2_4_4_TextGlob_bels_2 = {0x3F};
public static BEC_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_inst;

public static BET_2_4_4_TextGlob bece_BEC_2_4_4_TextGlob_bevs_type;

public BEC_2_4_6_TextString bevp_glob;
public BEC_2_9_10_ContainerLinkedList bevp_splits;
public BEC_2_4_4_TextGlob bem_new_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
bem_globSet_1(beva__glob);
return this;
} /*method end*/
public BEC_2_4_4_TextGlob bem_globSet_1(BEC_2_4_6_TextString beva__glob) throws Throwable {
BEC_2_4_9_TextTokenizer bevl_tok = null;
BEC_2_9_10_ContainerLinkedList bevl__splits = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_4_4_TextGlob_bels_0));
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevl_tok = (new BEC_2_4_9_TextTokenizer()).bem_new_2(bevt_0_ta_ph, bevt_1_ta_ph);
bevl__splits = (BEC_2_9_10_ContainerLinkedList) bevl_tok.bem_tokenize_1(beva__glob);
bevp_glob = beva__glob;
bevp_splits = bevl__splits;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_match_1(BEC_2_4_6_TextString beva_input) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_node = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_0_ta_ph = bevp_splits.bem_iteratorGet_0();
bevl_node = (BEC_3_9_10_4_ContainerLinkedListNode) bevt_0_ta_ph.bemd_0(410292015);
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_1_ta_ph = bem_caseMatch_4(bevl_node, beva_input, bevt_2_ta_ph, null);
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_caseMatch_4(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos, BEC_2_9_6_ContainerSingle beva_lpos) throws Throwable {
BEC_2_4_6_TextString bevl_val = null;
BEC_2_4_3_MathInt bevl_found = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_3_9_10_4_ContainerLinkedListNode bevt_18_ta_ph = null;
BEC_2_4_3_MathInt bevt_19_ta_ph = null;
BEC_2_4_3_MathInt bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
if (beva_node == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1016*/ {
bevt_2_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int == bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1017*/ {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_3_ta_ph;
} /* Line: 1018*/
 else /* Line: 1019*/ {
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_4_ta_ph;
} /* Line: 1020*/
} /* Line: 1017*/
bevl_val = (BEC_2_4_6_TextString) beva_node.bem_heldGet_0();
bevt_6_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_4_TextGlob_bels_1));
bevt_5_ta_ph = bevl_val.bem_equals_1(bevt_6_ta_ph);
if (bevt_5_ta_ph.bevi_bool)/* Line: 1024*/ {
bevt_7_ta_ph = bem_starMatch_3(beva_node, beva_input, beva_pos);
return bevt_7_ta_ph;
} /* Line: 1025*/
bevt_9_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_4_4_TextGlob_bels_2));
bevt_8_ta_ph = bevl_val.bem_equals_1(bevt_9_ta_ph);
if (bevt_8_ta_ph.bevi_bool)/* Line: 1027*/ {
beva_pos = beva_pos.bem_increment_0();
bevt_11_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_11_ta_ph.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1029*/ {
bevt_13_ta_ph = beva_node.bem_nextGet_0();
bevt_12_ta_ph = bem_caseMatch_4(bevt_13_ta_ph, beva_input, beva_pos, null);
return bevt_12_ta_ph;
} /* Line: 1029*/
 else /* Line: 1029*/ {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_14_ta_ph;
} /* Line: 1029*/
} /* Line: 1029*/
bevl_found = beva_input.bem_find_2(bevl_val, beva_pos);
if (bevl_found == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 1032*/ {
if (bevl_found.bevi_int == beva_pos.bevi_int) {
bevt_16_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_16_ta_ph.bevi_bool)/* Line: 1033*/ {
bevt_18_ta_ph = beva_node.bem_nextGet_0();
bevt_20_ta_ph = bevl_val.bem_sizeGet_0();
bevt_19_ta_ph = beva_pos.bem_add_1(bevt_20_ta_ph);
bevt_17_ta_ph = bem_caseMatch_4(bevt_18_ta_ph, beva_input, bevt_19_ta_ph, null);
return bevt_17_ta_ph;
} /* Line: 1034*/
 else /* Line: 1035*/ {
if (beva_lpos == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 1036*/ {
beva_lpos.bem_firstSet_1(bevl_found);
} /* Line: 1037*/
} /* Line: 1036*/
} /* Line: 1033*/
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_22_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_starMatch_3(BEC_3_9_10_4_ContainerLinkedListNode beva_node, BEC_2_4_6_TextString beva_input, BEC_2_4_3_MathInt beva_pos) throws Throwable {
BEC_3_9_10_4_ContainerLinkedListNode bevl_nx = null;
BEC_2_9_6_ContainerSingle bevl_lpos = null;
BEC_2_5_4_LogicBool bevl_ok = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
bevl_nx = beva_node.bem_nextGet_0();
bevl_lpos = (new BEC_2_9_6_ContainerSingle()).bem_new_0();
while (true)
/* Line: 1048*/ {
bevt_1_ta_ph = beva_input.bem_sizeGet_0();
if (beva_pos.bevi_int <= bevt_1_ta_ph.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1048*/ {
bevl_ok = bem_caseMatch_4(bevl_nx, beva_input, beva_pos, bevl_lpos);
if (bevl_ok.bevi_bool)/* Line: 1050*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1050*/
bevt_4_ta_ph = bevl_lpos.bem_firstGet_0();
if (bevt_4_ta_ph == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1051*/ {
beva_pos = (BEC_2_4_3_MathInt) bevl_lpos.bem_firstGet_0();
bevl_lpos.bem_firstSet_1(null);
} /* Line: 1053*/
 else /* Line: 1054*/ {
beva_pos = beva_pos.bem_increment_0();
} /* Line: 1055*/
} /* Line: 1051*/
 else /* Line: 1048*/ {
break;
} /* Line: 1048*/
} /* Line: 1048*/
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_5_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_globGet_0() throws Throwable {
return bevp_glob;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_splitsGet_0() throws Throwable {
return bevp_splits;
} /*method end*/
public BEC_2_4_4_TextGlob bem_splitsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_splits = (BEC_2_9_10_ContainerLinkedList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {993, 997, 997, 997, 998, 1000, 1001, 1011, 1011, 1012, 1012, 1012, 1016, 1016, 1017, 1017, 1017, 1018, 1018, 1020, 1020, 1023, 1024, 1024, 1025, 1025, 1027, 1027, 1028, 1029, 1029, 1029, 1029, 1029, 1029, 1029, 1029, 1031, 1032, 1032, 1033, 1033, 1034, 1034, 1034, 1034, 1034, 1036, 1036, 1037, 1041, 1041, 1045, 1046, 1048, 1048, 1048, 1049, 1050, 1050, 1051, 1051, 1051, 1052, 1053, 1055, 1058, 1058, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 27, 28, 29, 30, 31, 32, 40, 41, 42, 43, 44, 72, 77, 78, 79, 84, 85, 86, 89, 90, 93, 94, 95, 97, 98, 100, 101, 103, 104, 105, 110, 111, 112, 113, 116, 117, 120, 121, 126, 127, 132, 133, 134, 135, 136, 137, 140, 145, 146, 150, 151, 163, 164, 167, 168, 173, 174, 176, 177, 179, 180, 185, 186, 187, 190, 197, 198, 201, 204, 207};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
globSet 1 993 19
assign 1 997 27
new 0 997 27
assign 1 997 28
new 0 997 28
assign 1 997 29
new 2 997 29
assign 1 998 30
tokenize 1 998 30
assign 1 1000 31
assign 1 1001 32
assign 1 1011 40
iteratorGet 0 1011 40
assign 1 1011 41
nextNodeGet 0 1011 41
assign 1 1012 42
new 0 1012 42
assign 1 1012 43
caseMatch 4 1012 43
return 1 1012 44
assign 1 1016 72
undef 1 1016 77
assign 1 1017 78
sizeGet 0 1017 78
assign 1 1017 79
equals 1 1017 84
assign 1 1018 85
new 0 1018 85
return 1 1018 86
assign 1 1020 89
new 0 1020 89
return 1 1020 90
assign 1 1023 93
heldGet 0 1023 93
assign 1 1024 94
new 0 1024 94
assign 1 1024 95
equals 1 1024 95
assign 1 1025 97
starMatch 3 1025 97
return 1 1025 98
assign 1 1027 100
new 0 1027 100
assign 1 1027 101
equals 1 1027 101
assign 1 1028 103
increment 0 1028 103
assign 1 1029 104
sizeGet 0 1029 104
assign 1 1029 105
lesserEquals 1 1029 110
assign 1 1029 111
nextGet 0 1029 111
assign 1 1029 112
caseMatch 4 1029 112
return 1 1029 113
assign 1 1029 116
new 0 1029 116
return 1 1029 117
assign 1 1031 120
find 2 1031 120
assign 1 1032 121
def 1 1032 126
assign 1 1033 127
equals 1 1033 132
assign 1 1034 133
nextGet 0 1034 133
assign 1 1034 134
sizeGet 0 1034 134
assign 1 1034 135
add 1 1034 135
assign 1 1034 136
caseMatch 4 1034 136
return 1 1034 137
assign 1 1036 140
def 1 1036 145
firstSet 1 1037 146
assign 1 1041 150
new 0 1041 150
return 1 1041 151
assign 1 1045 163
nextGet 0 1045 163
assign 1 1046 164
new 0 1046 164
assign 1 1048 167
sizeGet 0 1048 167
assign 1 1048 168
lesserEquals 1 1048 173
assign 1 1049 174
caseMatch 4 1049 174
assign 1 1050 176
new 0 1050 176
return 1 1050 177
assign 1 1051 179
firstGet 0 1051 179
assign 1 1051 180
def 1 1051 185
assign 1 1052 186
firstGet 0 1052 186
firstSet 1 1053 187
assign 1 1055 190
increment 0 1055 190
assign 1 1058 197
new 0 1058 197
return 1 1058 198
return 1 0 201
return 1 0 204
assign 1 0 207
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 680360862: return bem_toString_0();
case 147706186: return bem_globGet_0();
case 773827023: return bem_hashGet_0();
case 257293855: return bem_copy_0();
case 1458462738: return bem_new_0();
case -1737511526: return bem_splitsGet_0();
case 1481144265: return bem_iteratorGet_0();
case -639717510: return bem_create_0();
case 1168727565: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1738126633: return bem_copyTo_1(bevd_0);
case -1831694135: return bem_def_1(bevd_0);
case -904839726: return bem_globSet_1((BEC_2_4_6_TextString) bevd_0);
case 1995371181: return bem_equals_1(bevd_0);
case 1146571155: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 485019580: return bem_notEquals_1(bevd_0);
case 54614002: return bem_splitsSet_1(bevd_0);
case -496366080: return bem_undef_1(bevd_0);
case 724876209: return bem_match_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1960185659: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2002366118: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 147231706: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -208746106: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_3(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2) throws Throwable {
switch (callId) {
case 1590940983: return bem_starMatch_3((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2);
}
return super.bemd_3(callId, bevd_0, bevd_1, bevd_2);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1656306711: return bem_caseMatch_4((BEC_3_9_10_4_ContainerLinkedListNode) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_3_MathInt) bevd_2, (BEC_2_9_6_ContainerSingle) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(9, becc_BEC_2_4_4_TextGlob_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_4_4_TextGlob_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_4_TextGlob();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst = (BEC_2_4_4_TextGlob) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_4_TextGlob.bece_BEC_2_4_4_TextGlob_bevs_type;
}
}
