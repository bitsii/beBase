package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemThread extends BEC_2_6_10_SystemThinThread {
public BEC_2_6_6_SystemThread() { }
private static byte[] becc_BEC_2_6_6_SystemThread_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x54,0x68,0x72,0x65,0x61,0x64};
private static byte[] becc_BEC_2_6_6_SystemThread_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
public static BEC_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_inst;

public static BET_2_6_6_SystemThread bece_BEC_2_6_6_SystemThread_bevs_type;

public BEC_3_6_6_12_SystemThreadObjectLocker bevp_started;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_finished;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_threwException;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_returned;
public BEC_3_6_6_12_SystemThreadObjectLocker bevp_exception;
public BEC_2_6_6_SystemThread bem_new_1(BEC_2_6_6_SystemObject beva__toRun) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_started = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_finished = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_1(bevt_1_tmpany_phold);
bevp_threwException = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_returned = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
bevp_exception = (new BEC_3_6_6_12_SystemThreadObjectLocker()).bem_new_0();
super.bem_new_1(beva__toRun);
return this;
} /*method end*/
public BEC_2_6_6_SystemThread bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
try  /* Line: 788 */ {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_started.bem_oSet_1(bevt_0_tmpany_phold);
bevt_1_tmpany_phold = bevp_toRun.bemd_0(1491742830);
bevp_returned.bem_oSet_1(bevt_1_tmpany_phold);
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_threwException.bem_oSet_1(bevt_2_tmpany_phold);
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_3_tmpany_phold);
} /* Line: 792 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_threwException.bem_oSet_1(bevt_4_tmpany_phold);
bevp_exception.bem_oSet_1(bevl_e);
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_finished.bem_oSet_1(bevt_5_tmpany_phold);
} /* Line: 796 */
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGet_0() throws Throwable {
return bevp_started;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_startedGetDirect_0() throws Throwable {
return bevp_started;
} /*method end*/
public BEC_2_6_6_SystemThread bem_startedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemThread bem_startedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_started = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGet_0() throws Throwable {
return bevp_finished;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_finishedGetDirect_0() throws Throwable {
return bevp_finished;
} /*method end*/
public BEC_2_6_6_SystemThread bem_finishedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemThread bem_finishedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_finished = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGet_0() throws Throwable {
return bevp_threwException;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_threwExceptionGetDirect_0() throws Throwable {
return bevp_threwException;
} /*method end*/
public BEC_2_6_6_SystemThread bem_threwExceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemThread bem_threwExceptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_threwException = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGet_0() throws Throwable {
return bevp_returned;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_returnedGetDirect_0() throws Throwable {
return bevp_returned;
} /*method end*/
public BEC_2_6_6_SystemThread bem_returnedSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemThread bem_returnedSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_returned = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGet_0() throws Throwable {
return bevp_exception;
} /*method end*/
public final BEC_3_6_6_12_SystemThreadObjectLocker bem_exceptionGetDirect_0() throws Throwable {
return bevp_exception;
} /*method end*/
public BEC_2_6_6_SystemThread bem_exceptionSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_6_SystemThread bem_exceptionSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exception = (BEC_3_6_6_12_SystemThreadObjectLocker) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {777, 777, 778, 778, 779, 780, 781, 783, 789, 789, 790, 790, 791, 791, 792, 792, 794, 794, 795, 796, 796, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 22, 23, 24, 25, 26, 27, 28, 40, 41, 42, 43, 44, 45, 46, 47, 51, 52, 53, 54, 55, 60, 63, 66, 70, 74, 77, 80, 84, 88, 91, 94, 98, 102, 105, 108, 112, 116, 119, 122, 126};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 777 21
new 0 777 21
assign 1 777 22
new 1 777 22
assign 1 778 23
new 0 778 23
assign 1 778 24
new 1 778 24
assign 1 779 25
new 0 779 25
assign 1 780 26
new 0 780 26
assign 1 781 27
new 0 781 27
new 1 783 28
assign 1 789 40
new 0 789 40
oSet 1 789 41
assign 1 790 42
main 0 790 42
oSet 1 790 43
assign 1 791 44
new 0 791 44
oSet 1 791 45
assign 1 792 46
new 0 792 46
oSet 1 792 47
assign 1 794 51
new 0 794 51
oSet 1 794 52
oSet 1 795 53
assign 1 796 54
new 0 796 54
oSet 1 796 55
return 1 0 60
return 1 0 63
assign 1 0 66
assign 1 0 70
return 1 0 74
return 1 0 77
assign 1 0 80
assign 1 0 84
return 1 0 88
return 1 0 91
assign 1 0 94
assign 1 0 98
return 1 0 102
return 1 0 105
assign 1 0 108
assign 1 0 112
return 1 0 116
return 1 0 119
assign 1 0 122
assign 1 0 126
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -54877035: return bem_toRunGetDirect_0();
case 640960113: return bem_finishedGet_0();
case -1894090923: return bem_toString_0();
case -808123537: return bem_hashGet_0();
case -1706743432: return bem_iteratorGet_0();
case -1602615308: return bem_fieldIteratorGet_0();
case 1170696256: return bem_threwExceptionGetDirect_0();
case 1606613844: return bem_echo_0();
case 1377047095: return bem_serializeToString_0();
case 259951008: return bem_startedGetDirect_0();
case -1442653865: return bem_serializationIteratorGet_0();
case -295553573: return bem_new_0();
case -788715099: return bem_threwExceptionGet_0();
case 1331025874: return bem_startedGet_0();
case -1460543860: return bem_fieldNamesGet_0();
case -493975186: return bem_create_0();
case -41381797: return bem_copy_0();
case -802767414: return bem_deserializeClassNameGet_0();
case 389587791: return bem_exceptionGetDirect_0();
case -2041049726: return bem_exceptionGet_0();
case -1396413274: return bem_classNameGet_0();
case 899896295: return bem_print_0();
case 931827777: return bem_toRunGet_0();
case -2071452709: return bem_serializeContents_0();
case 397363170: return bem_returnedGetDirect_0();
case 85669346: return bem_once_0();
case 1412443787: return bem_finishedGetDirect_0();
case 874569701: return bem_toAny_0();
case -1794506213: return bem_many_0();
case -1333837278: return bem_tagGet_0();
case 1491742830: return bem_main_0();
case 1523861211: return bem_sourceFileNameGet_0();
case 1570796346: return bem_wait_0();
case -1971272639: return bem_returnedGet_0();
case -703827217: return bem_start_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 53407038: return bem_equals_1(bevd_0);
case 852041450: return bem_toRunSet_1(bevd_0);
case 1361735841: return bem_startedSet_1(bevd_0);
case -319164445: return bem_undefined_1(bevd_0);
case 314415044: return bem_returnedSet_1(bevd_0);
case -920243169: return bem_sameObject_1(bevd_0);
case -666596898: return bem_new_1(bevd_0);
case -1989300932: return bem_sameClass_1(bevd_0);
case 1328285078: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 720389572: return bem_finishedSetDirect_1(bevd_0);
case -1573190823: return bem_finishedSet_1(bevd_0);
case 1025349154: return bem_threwExceptionSetDirect_1(bevd_0);
case -794252146: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 966131902: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 284248916: return bem_defined_1(bevd_0);
case -1359496216: return bem_returnedSetDirect_1(bevd_0);
case 1136071104: return bem_exceptionSet_1(bevd_0);
case -194482552: return bem_sameType_1(bevd_0);
case 1829433968: return bem_otherClass_1(bevd_0);
case -1106537979: return bem_startedSetDirect_1(bevd_0);
case 1483748848: return bem_toRunSetDirect_1(bevd_0);
case 1213137777: return bem_undef_1(bevd_0);
case -2123613587: return bem_notEquals_1(bevd_0);
case 391192402: return bem_copyTo_1(bevd_0);
case -1496010513: return bem_exceptionSetDirect_1(bevd_0);
case 652115224: return bem_def_1(bevd_0);
case -1656832533: return bem_threwExceptionSet_1(bevd_0);
case -467808258: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 251588443: return bem_otherType_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1874085610: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1865862746: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1736065910: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1057911785: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1158884482: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1126000923: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1221539498: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemThread_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemThread_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemThread();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst = (BEC_2_6_6_SystemThread) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemThread.bece_BEC_2_6_6_SystemThread_bevs_type;
}
}
