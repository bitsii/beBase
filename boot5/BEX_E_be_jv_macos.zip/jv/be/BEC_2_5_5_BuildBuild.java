package be;
/* IO:File: source/build/Build.be */
public final class BEC_2_5_5_BuildBuild extends BEC_2_6_6_SystemObject {
public BEC_2_5_5_BuildBuild() { }
private static byte[] becc_BEC_2_5_5_BuildBuild_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x42,0x75,0x69,0x6C,0x64};
private static byte[] becc_BEC_2_5_5_BuildBuild_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x42,0x75,0x69,0x6C,0x64,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_0 = {0x2C,0x0D,0x0A};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_1 = {0x6E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_0 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_1, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_2 = {0x4E,0x65,0x77};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_1 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_2, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_3 = {0x2F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_4 = {0x5C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_5 = {0x68,0x6F,0x77,0x4D,0x61,0x6E,0x79,0x54,0x69,0x6D,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_6 = {0x31};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_7 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x49,0x6E,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_8 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x43,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_9 = {0x42,0x75,0x69,0x6C,0x64,0x20,0x46,0x61,0x69,0x6C,0x65,0x64,0x20,0x77,0x69,0x74,0x68,0x20,0x65,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_2 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_9, 28));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_10 = {0x6D,0x73,0x77,0x69,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_11 = {0x62,0x75,0x69,0x6C,0x64,0x46,0x69,0x6C,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_12 = {0x6D,0x73,0x77,0x69,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_3 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_12, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_13 = {0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_14 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_15 = {0x65,0x78,0x65,0x4E,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_16 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_17 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_18 = {0x74,0x61,0x72,0x67,0x65,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_19 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_20 = {0x69,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_21 = {0x70,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_22 = {0x6F,0x75,0x74,0x70,0x75,0x74,0x50,0x6C,0x61,0x74,0x66,0x6F,0x72,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_23 = {0x64,0x79,0x6E,0x43,0x6F,0x6E,0x64,0x69,0x74,0x69,0x6F,0x6E,0x73,0x41,0x6C,0x6C};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_24 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_25 = {0x6F,0x77,0x6E,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_26 = {0x74,0x72,0x75,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_27 = {0x73,0x61,0x76,0x65,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_28 = {0x66,0x61,0x6C,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_29 = {0x6C,0x6F,0x61,0x64,0x53,0x79,0x6E,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_30 = {0x69,0x6E,0x69,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_31 = {0x6D,0x61,0x69,0x6E,0x43,0x6C,0x61,0x73,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_32 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x50,0x61,0x74,0x68};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_33 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_34 = {0x75,0x73,0x65,0x4C,0x69,0x62,0x72,0x61,0x72,0x79,0x43,0x6C,0x6F,0x73,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_35 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x46,0x72,0x6F,0x6D};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_36 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x46,0x69,0x6C,0x65,0x54,0x6F};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_37 = {0x65,0x78,0x74,0x49,0x6E,0x63,0x6C,0x75,0x64,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_38 = {0x63,0x63,0x4F,0x62,0x6A,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_39 = {0x65,0x78,0x74,0x4C,0x69,0x62};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_40 = {0x6C,0x69,0x6E,0x6B,0x4C,0x69,0x62,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_41 = {0x65,0x78,0x74,0x4C,0x69,0x6E,0x6B,0x4F,0x62,0x6A,0x65,0x63,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_42 = {0x65,0x6D,0x69,0x74,0x46,0x69,0x6C,0x65,0x48,0x65,0x61,0x64,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_43 = {0x72,0x75,0x6E,0x41,0x72,0x67,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_44 = {0x70,0x72,0x69,0x6E,0x74,0x53,0x74,0x65,0x70,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_45 = {0x70,0x72,0x69,0x6E,0x74,0x50,0x6C,0x61,0x63,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_46 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_47 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x6C,0x6C,0x41,0x73,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_48 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x45,0x6C,0x65,0x6D,0x65,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_49 = {0x67,0x65,0x6E,0x4F,0x6E,0x6C,0x79};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_50 = {0x64,0x65,0x70,0x6C,0x6F,0x79,0x55,0x73,0x65,0x64,0x4C,0x69,0x62,0x72,0x61,0x72,0x69,0x65,0x73};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_51 = {0x72,0x75,0x6E};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_52 = {0x70,0x75,0x74,0x4C,0x69,0x6E,0x65,0x4E,0x75,0x6D,0x62,0x65,0x72,0x73,0x49,0x6E,0x54,0x72,0x61,0x63,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_53 = {0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_54 = {0x65,0x6D,0x69,0x74,0x46,0x6C,0x61,0x67};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_55 = {0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x72};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_56 = {0x67,0x63,0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_57 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_58 = {0x6D,0x61,0x6B,0x65};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_59 = {0x6D,0x61,0x6B,0x65,0x41,0x72,0x67,0x73,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_4 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_59, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_60 = {};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_61 = {0x63};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_62 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65,0x5F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_5 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_62, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_63 = {0x5F,0x73,0x6F,0x75,0x72,0x63,0x65};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_6 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_63, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_64 = {0x62,0x75,0x69,0x6C,0x64,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_65 = {0x65,0x6D,0x69,0x74,0x50,0x61,0x74,0x68,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_66 = {0x6A,0x76};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_7 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_66, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_67 = {0x63,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_8 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_67, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_68 = {0x63,0x63};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_9 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_68, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_69 = {0x6A,0x73};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_10 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_69, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_70 = {0x55,0x6E,0x6B,0x6E,0x6F,0x77,0x6E,0x20,0x65,0x6D,0x69,0x74,0x4C,0x61,0x6E,0x67,0x2C,0x20,0x73,0x75,0x70,0x70,0x6F,0x72,0x74,0x65,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x6C,0x61,0x6E,0x67,0x73,0x20,0x61,0x72,0x65,0x20,0x63,0x73,0x2C,0x20,0x6A,0x76};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_71 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_11 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_71, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_72 = {0x4C,0x6F,0x61,0x64,0x69,0x6E,0x67,0x20,0x53,0x79,0x6E,0x73,0x20,0x74,0x6F,0x6F,0x6B,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_12 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_72, 18));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_73 = {0x41,0x64,0x64,0x65,0x64,0x20,0x63,0x6C,0x6F,0x73,0x65,0x6C,0x69,0x62,0x72,0x61,0x72,0x79,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_13 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_73, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_74 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_14 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_74, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_75 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x45,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_15 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_75, 30));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_76 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_16 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_76, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_77 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_17 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_77, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_78 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_18 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_78, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_79 = {0x2F};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_19 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_79, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_80 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_20 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_80, 31));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_81 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x20,0x61,0x6E,0x64,0x20,0x65,0x6D,0x69,0x74,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_21 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_81, 41));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_82 = {0x54,0x49,0x4D,0x45,0x3A,0x20,0x50,0x61,0x72,0x73,0x65,0x2C,0x20,0x65,0x6D,0x69,0x74,0x2C,0x20,0x61,0x6E,0x64,0x20,0x63,0x6F,0x6D,0x70,0x69,0x6C,0x65,0x20,0x70,0x68,0x61,0x73,0x65,0x73,0x20,0x63,0x6F,0x6D,0x70,0x6C,0x65,0x74,0x65,0x64,0x20,0x69,0x6E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_22 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_82, 51));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_83 = {0x53,0x68,0x6F,0x75,0x6C,0x64,0x20,0x6E,0x6F,0x77,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_23 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_83, 14));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_84 = {0x52,0x65,0x63,0x65,0x69,0x76,0x65,0x64,0x20,0x65,0x78,0x69,0x74,0x20,0x63,0x6F,0x64,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_24 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_84, 19));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_85 = {0x20,0x66,0x72,0x6F,0x6D,0x20,0x72,0x75,0x6E};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_25 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_85, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_86 = {0x50,0x61,0x72,0x73,0x69,0x6E,0x67,0x20,0x66,0x69,0x6C,0x65,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_26 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_86, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_87 = {0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_27 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_87, 2));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_88 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x20,0x6E,0x6F,0x64,0x69,0x66,0x79};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_28 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_88, 22));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_89 = {0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_29 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_89, 3));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_90 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_30 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_90, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_91 = {0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_31 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_91, 4));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_92 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x33};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_32 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_92, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_93 = {0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_33 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_93, 5));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_94 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x34};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_34 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_94, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_95 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_35 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_95, 6));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_96 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x35};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_36 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_96, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_97 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_37 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_97, 7));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_98 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x36};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_38 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_98, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_99 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_39 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_99, 8));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_100 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x37};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_40 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_100, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_101 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_41 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_101, 9));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_102 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x38};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_42 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_102, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_103 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_43 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_103, 10));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_104 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x39};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_44 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_104, 15));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_105 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_45 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_105, 11));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_106 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x30};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_46 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_106, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_107 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_47 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_107, 12));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_108 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x31};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_48 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_108, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_109 = {0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x2E,0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_49 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_109, 13));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_110 = {0x20};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_50 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_110, 1));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_111 = {0x70,0x72,0x69,0x6E,0x74,0x41,0x73,0x74,0x20,0x70,0x6F,0x73,0x74,0x20,0x31,0x32};
private static BEC_2_4_6_TextString bece_BEC_2_5_5_BuildBuild_bevo_51 = (new BEC_2_4_6_TextString(bece_BEC_2_5_5_BuildBuild_bels_111, 16));
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_112 = {0x6E,0x65,0x77};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_113 = {0x4D,0x61,0x74,0x68,0x3A,0x49,0x6E,0x74};
private static byte[] bece_BEC_2_5_5_BuildBuild_bels_114 = {0x4D,0x61,0x74,0x68,0x3A,0x46,0x6C,0x6F,0x61,0x74};
public static BEC_2_5_5_BuildBuild bece_BEC_2_5_5_BuildBuild_bevs_inst;
public BEC_2_4_6_TextString bevp_mainName;
public BEC_2_4_6_TextString bevp_libName;
public BEC_2_4_6_TextString bevp_exeName;
public BEC_2_6_6_SystemObject bevp_emitFileHeader;
public BEC_2_9_10_ContainerLinkedList bevp_extIncludes;
public BEC_2_9_10_ContainerLinkedList bevp_ccObjArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLibs;
public BEC_2_9_10_ContainerLinkedList bevp_linkLibArgs;
public BEC_2_9_10_ContainerLinkedList bevp_extLinkObjects;
public BEC_2_6_6_SystemObject bevp_fromFile;
public BEC_2_6_6_SystemObject bevp_platform;
public BEC_2_6_6_SystemObject bevp_outputPlatform;
public BEC_2_6_6_SystemObject bevp_emitLibrary;
public BEC_2_6_6_SystemObject bevp_usedLibrarysStr;
public BEC_2_6_6_SystemObject bevp_closeLibrariesStr;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesFrom;
public BEC_2_9_10_ContainerLinkedList bevp_deployFilesTo;
public BEC_2_4_6_TextString bevp_nl;
public BEC_2_4_6_TextString bevp_newline;
public BEC_2_6_6_SystemObject bevp_runArgs;
public BEC_2_5_15_BuildCompilerProfile bevp_compilerProfile;
public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_10_SystemParameters bevp_params;
public BEC_2_5_4_LogicBool bevp_buildSucceeded;
public BEC_2_4_6_TextString bevp_buildMessage;
public BEC_2_4_8_TimeInterval bevp_startTime;
public BEC_2_4_8_TimeInterval bevp_parseTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitTime;
public BEC_2_4_8_TimeInterval bevp_parseEmitCompileTime;
public BEC_3_2_4_4_IOFilePath bevp_buildPath;
public BEC_2_6_6_SystemObject bevp_includePath;
public BEC_2_9_3_ContainerMap bevp_built;
public BEC_2_9_10_ContainerLinkedList bevp_toBuild;
public BEC_2_5_4_LogicBool bevp_printSteps;
public BEC_2_5_4_LogicBool bevp_printPlaces;
public BEC_2_5_4_LogicBool bevp_printAst;
public BEC_2_5_4_LogicBool bevp_printAllAst;
public BEC_2_9_3_ContainerSet bevp_printAstElements;
public BEC_2_5_4_LogicBool bevp_doEmit;
public BEC_2_5_4_LogicBool bevp_emitDebug;
public BEC_2_5_4_LogicBool bevp_parse;
public BEC_2_5_4_LogicBool bevp_prepMake;
public BEC_2_5_4_LogicBool bevp_make;
public BEC_2_5_4_LogicBool bevp_genOnly;
public BEC_2_5_4_LogicBool bevp_deployUsedLibraries;
public BEC_2_5_8_BuildEmitData bevp_emitData;
public BEC_3_2_4_4_IOFilePath bevp_emitPath;
public BEC_2_6_6_SystemObject bevp_code;
public BEC_2_4_6_TextString bevp_estr;
public BEC_2_6_6_SystemObject bevp_sharedEmitter;
public BEC_2_5_9_BuildConstants bevp_constants;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_2_4_9_TextTokenizer bevp_twtok;
public BEC_2_4_9_TextTokenizer bevp_lctok;
public BEC_2_5_7_BuildLibrary bevp_deployLibrary;
public BEC_2_4_6_TextString bevp_deployPath;
public BEC_2_9_10_ContainerLinkedList bevp_usedLibrarys;
public BEC_2_9_3_ContainerSet bevp_closeLibraries;
public BEC_2_5_4_LogicBool bevp_run;
public BEC_2_4_6_TextString bevp_compiler;
public BEC_2_9_10_ContainerLinkedList bevp_emitLangs;
public BEC_2_9_10_ContainerLinkedList bevp_emitFlags;
public BEC_2_4_6_TextString bevp_makeName;
public BEC_2_4_6_TextString bevp_makeArgs;
public BEC_2_5_4_LogicBool bevp_putLineNumbersInTrace;
public BEC_2_5_4_LogicBool bevp_dynConditionsAll;
public BEC_2_5_4_LogicBool bevp_ownProcess;
public BEC_2_5_4_LogicBool bevp_saveSyns;
public BEC_2_4_6_TextString bevp_readBuffer;
public BEC_2_9_10_ContainerLinkedList bevp_loadSyns;
public BEC_2_9_10_ContainerLinkedList bevp_initLibs;
public BEC_2_5_10_BuildEmitCommon bevp_emitCommon;
public BEC_2_5_5_BuildBuild bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevp_built = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_printSteps = be.BECS_Runtime.boolFalse;
bevp_printPlaces = be.BECS_Runtime.boolFalse;
bevp_printAst = be.BECS_Runtime.boolFalse;
bevp_printAllAst = be.BECS_Runtime.boolFalse;
bevp_doEmit = be.BECS_Runtime.boolFalse;
bevp_emitDebug = be.BECS_Runtime.boolFalse;
bevp_parse = be.BECS_Runtime.boolFalse;
bevp_prepMake = be.BECS_Runtime.boolFalse;
bevp_make = be.BECS_Runtime.boolFalse;
bevp_genOnly = be.BECS_Runtime.boolFalse;
bevp_deployUsedLibraries = be.BECS_Runtime.boolFalse;
bevp_estr = (new BEC_2_4_6_TextString()).bem_new_0();
bevp_constants = (new BEC_2_5_9_BuildConstants()).bem_new_1(this);
bevp_ntypes = bevp_constants.bem_ntypesGet_0();
bevp_twtok = bevp_constants.bem_twtokGet_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_0));
bevp_lctok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_0_tmpany_phold);
bevp_usedLibrarys = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevp_closeLibraries = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevp_run = be.BECS_Runtime.boolFalse;
bevp_putLineNumbersInTrace = be.BECS_Runtime.boolFalse;
bevp_dynConditionsAll = be.BECS_Runtime.boolFalse;
bevp_ownProcess = be.BECS_Runtime.boolTrue;
bevp_saveSyns = be.BECS_Runtime.boolFalse;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt(4096));
bevp_readBuffer = (new BEC_2_4_6_TextString()).bem_new_1(bevt_1_tmpany_phold);
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isNewish_1(BEC_2_4_6_TextString beva_name) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_name == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_0;
bevt_2_tmpany_phold = beva_name.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_1;
bevt_4_tmpany_phold = beva_name.bem_ends_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 97 */
 else  /* Line: 97 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 97 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_6_tmpany_phold;
} /* Line: 98 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_process_1(BEC_2_4_6_TextString beva_arg) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_3));
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_4));
bevt_0_tmpany_phold = beva_arg.bem_swap_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_main_0() throws Throwable {
BEC_2_9_4_ContainerList bevl__args = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_6_7_SystemProcess bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevl__args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_1_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevt_2_tmpany_phold = bem_main_1(bevl__args);
bevt_1_tmpany_phold.bem_exit_1((BEC_2_4_3_MathInt) bevt_2_tmpany_phold );
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_1(BEC_2_9_4_ContainerList beva__args) throws Throwable {
BEC_2_4_3_MathInt bevl_times = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevp_args = beva__args;
bevp_params = (new BEC_2_6_10_SystemParameters()).bem_new_1(bevp_args);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_5));
bevt_3_tmpany_phold = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_6));
bevt_1_tmpany_phold = bevp_params.bem_get_2(bevt_2_tmpany_phold, bevt_3_tmpany_phold);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
bevl_times = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_0_tmpany_phold);
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 116 */ {
if (bevl_i.bevi_int < bevl_times.bevi_int) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 116 */ {
bevl_res = bem_go_0();
bevl_i.bevi_int++;
} /* Line: 116 */
 else  /* Line: 116 */ {
break;
} /* Line: 116 */
} /* Line: 116 */
return bevl_res;
} /*method end*/
public BEC_2_6_6_SystemObject bem_go_0() throws Throwable {
BEC_2_4_3_MathInt bevl_whatResult = null;
BEC_2_5_4_LogicBool bevl_buildFailed = null;
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
bem_config_0();
bevl_buildFailed = be.BECS_Runtime.boolFalse;
try  /* Line: 126 */ {
bevp_buildMessage = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_7));
bevl_whatResult = bem_doWhat_0();
bevp_buildMessage = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_8));
} /* Line: 129 */
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_buildMessage = (BEC_2_4_6_TextString) bevl_e.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevl_buildFailed = be.BECS_Runtime.boolTrue;
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_2;
bevp_buildMessage = bevt_1_tmpany_phold.bem_add_1(bevp_buildMessage);
bevl_whatResult = (new BEC_2_4_3_MathInt(1));
} /* Line: 134 */
if (bevp_printSteps.bevi_bool) /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
if (bevl_buildFailed.bevi_bool) /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 136 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 136 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 136 */ {
bevp_buildMessage.bem_print_0();
} /* Line: 137 */
return bevl_whatResult;
} /*method end*/
public BEC_2_4_6_TextString bem_dllhead_1(BEC_2_4_6_TextString beva_addTo) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_platform.bemd_0(1211273660, BEX_E.bevn_nameGet_0);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_10));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(581408689, BEX_E.bevn_equals_1, bevt_2_tmpany_phold);
if (bevt_0_tmpany_phold != null && bevt_0_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 143 */ {
} /* Line: 143 */
return beva_addTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_config_0() throws Throwable {
BEC_2_4_6_TextString bevl_istr = null;
BEC_2_9_3_ContainerSet bevl_bfiles = null;
BEC_2_4_6_TextString bevl_bkey = null;
BEC_2_9_10_ContainerLinkedList bevl_pacm = null;
BEC_2_4_6_TextString bevl_pa = null;
BEC_2_4_6_TextString bevl_outLang = null;
BEC_2_6_6_SystemObject bevl_platformSources = null;
BEC_2_6_6_SystemObject bevl_langSources = null;
BEC_2_6_6_SystemObject bevl_emr = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_5_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
BEC_2_4_6_TextString bevt_12_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_4_6_TextString bevt_18_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_19_tmpany_phold = null;
BEC_2_4_6_TextString bevt_20_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_23_tmpany_phold = null;
BEC_2_4_6_TextString bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_2_4_6_TextString bevt_26_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_29_tmpany_phold = null;
BEC_2_4_6_TextString bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_6_15_SystemCurrentPlatform bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_41_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_2_4_6_TextString bevt_44_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_45_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_49_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_2_4_6_TextString bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_2_4_6_TextString bevt_54_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_2_4_6_TextString bevt_59_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_60_tmpany_phold = null;
BEC_2_4_6_TextString bevt_61_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_62_tmpany_phold = null;
BEC_2_4_6_TextString bevt_63_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_64_tmpany_phold = null;
BEC_2_4_6_TextString bevt_65_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_70_tmpany_phold = null;
BEC_2_4_6_TextString bevt_71_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_72_tmpany_phold = null;
BEC_2_4_6_TextString bevt_73_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_74_tmpany_phold = null;
BEC_2_4_6_TextString bevt_75_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_76_tmpany_phold = null;
BEC_2_4_6_TextString bevt_77_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_78_tmpany_phold = null;
BEC_2_4_6_TextString bevt_79_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_80_tmpany_phold = null;
BEC_2_4_6_TextString bevt_81_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_82_tmpany_phold = null;
BEC_2_4_6_TextString bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_4_6_TextString bevt_87_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_88_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_6_TextString bevt_98_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_99_tmpany_phold = null;
BEC_2_4_6_TextString bevt_100_tmpany_phold = null;
BEC_2_4_6_TextString bevt_101_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_102_tmpany_phold = null;
BEC_2_4_6_TextString bevt_103_tmpany_phold = null;
BEC_2_4_6_TextString bevt_104_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_105_tmpany_phold = null;
BEC_2_4_6_TextString bevt_106_tmpany_phold = null;
BEC_2_4_6_TextString bevt_107_tmpany_phold = null;
BEC_2_4_6_TextString bevt_108_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_109_tmpany_phold = null;
BEC_2_4_6_TextString bevt_110_tmpany_phold = null;
BEC_2_4_6_TextString bevt_111_tmpany_phold = null;
BEC_2_4_6_TextString bevt_112_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_113_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_114_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_115_tmpany_phold = null;
BEC_2_4_6_TextString bevt_116_tmpany_phold = null;
BEC_2_4_6_TextString bevt_117_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_118_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_119_tmpany_phold = null;
BEC_2_9_4_ContainerList bevt_120_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_121_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_122_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_123_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_124_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_125_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_126_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_127_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_128_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_129_tmpany_phold = null;
bevl_bfiles = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_bkey = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_11));
bevt_5_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
if (bevt_5_tmpany_phold == null) {
bevt_4_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_4_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 153 */ {
bevt_6_tmpany_phold = bevp_params.bem_get_1(bevl_bkey);
bevt_0_tmpany_loop = bevt_6_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 154 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 154 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_9_tmpany_phold = bevl_bfiles.bem_has_1(bevl_istr);
if (bevt_9_tmpany_phold.bevi_bool) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 155 */ {
bevl_bfiles.bem_put_1(bevl_istr);
bevt_10_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevl_istr);
bevp_params.bem_addFile_1(bevt_10_tmpany_phold);
} /* Line: 157 */
} /* Line: 155 */
 else  /* Line: 154 */ {
break;
} /* Line: 154 */
} /* Line: 154 */
} /* Line: 154 */
bevt_13_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bem_nameGet_0();
bevt_14_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_3;
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bem_equals_1(bevt_14_tmpany_phold);
if (bevt_11_tmpany_phold.bevi_bool) /* Line: 162 */ {
bevp_params.bem_preProcessorSet_1(this);
} /* Line: 163 */
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_13));
bevt_15_tmpany_phold = bevp_params.bem_get_1(bevt_16_tmpany_phold);
bevp_libName = (BEC_2_4_6_TextString) bevt_15_tmpany_phold.bem_firstGet_0();
bevt_18_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_14));
bevt_17_tmpany_phold = bevp_params.bem_has_1(bevt_18_tmpany_phold);
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 166 */ {
bevt_20_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_15));
bevt_19_tmpany_phold = bevp_params.bem_get_1(bevt_20_tmpany_phold);
bevp_exeName = (BEC_2_4_6_TextString) bevt_19_tmpany_phold.bem_firstGet_0();
} /* Line: 167 */
 else  /* Line: 168 */ {
bevp_exeName = bevp_libName;
} /* Line: 169 */
bevt_24_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_16));
bevt_25_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_17));
bevt_23_tmpany_phold = bevp_params.bem_get_2(bevt_24_tmpany_phold, bevt_25_tmpany_phold);
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_firstGet_0();
bevt_21_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_22_tmpany_phold);
bevp_buildPath = bevt_21_tmpany_phold.bem_pathGet_0();
bevp_buildPath.bem_addStep_1(bevp_libName);
bevt_26_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_18));
bevp_buildPath.bem_addStep_1(bevt_26_tmpany_phold);
bevt_30_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_19));
bevt_31_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_20));
bevt_29_tmpany_phold = bevp_params.bem_get_2(bevt_30_tmpany_phold, bevt_31_tmpany_phold);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_firstGet_0();
bevt_27_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevt_28_tmpany_phold);
bevp_includePath = bevt_27_tmpany_phold.bem_pathGet_0();
bevt_34_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_21));
bevt_36_tmpany_phold = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bevt_35_tmpany_phold = bevt_36_tmpany_phold.bem_nameGet_0();
bevt_33_tmpany_phold = bevp_params.bem_get_2(bevt_34_tmpany_phold, bevt_35_tmpany_phold);
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_firstGet_0();
bevp_platform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_32_tmpany_phold );
bevt_39_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_22));
bevt_40_tmpany_phold = bevp_platform.bemd_0(1211273660, BEX_E.bevn_nameGet_0);
bevt_38_tmpany_phold = bevp_params.bem_get_2(bevt_39_tmpany_phold, (BEC_2_4_6_TextString) bevt_40_tmpany_phold );
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bem_firstGet_0();
bevp_outputPlatform = (new BEC_2_6_8_SystemPlatform()).bem_new_1((BEC_2_4_6_TextString) bevt_37_tmpany_phold );
bevt_43_tmpany_phold = (new BEC_2_4_6_TextString(16, bece_BEC_2_5_5_BuildBuild_bels_23));
bevt_44_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_24));
bevt_42_tmpany_phold = bevp_params.bem_get_2(bevt_43_tmpany_phold, bevt_44_tmpany_phold);
bevt_41_tmpany_phold = bevt_42_tmpany_phold.bem_firstGet_0();
bevp_dynConditionsAll = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_41_tmpany_phold);
bevt_47_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_25));
bevt_48_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_26));
bevt_46_tmpany_phold = bevp_params.bem_get_2(bevt_47_tmpany_phold, bevt_48_tmpany_phold);
bevt_45_tmpany_phold = bevt_46_tmpany_phold.bem_firstGet_0();
bevp_ownProcess = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_45_tmpany_phold);
bevt_51_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_27));
bevt_52_tmpany_phold = (new BEC_2_4_6_TextString(5, bece_BEC_2_5_5_BuildBuild_bels_28));
bevt_50_tmpany_phold = bevp_params.bem_get_2(bevt_51_tmpany_phold, bevt_52_tmpany_phold);
bevt_49_tmpany_phold = bevt_50_tmpany_phold.bem_firstGet_0();
bevp_saveSyns = (new BEC_2_5_4_LogicBool()).bem_new_1(bevt_49_tmpany_phold);
bevt_53_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_29));
bevp_loadSyns = bevp_params.bem_get_1(bevt_53_tmpany_phold);
bevt_54_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_30));
bevp_initLibs = bevp_params.bem_get_1(bevt_54_tmpany_phold);
bevt_56_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_31));
bevt_55_tmpany_phold = bevp_params.bem_get_1(bevt_56_tmpany_phold);
bevp_mainName = (BEC_2_4_6_TextString) bevt_55_tmpany_phold.bem_firstGet_0();
bevt_58_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_32));
bevt_57_tmpany_phold = bevp_params.bem_get_1(bevt_58_tmpany_phold);
bevp_deployPath = (BEC_2_4_6_TextString) bevt_57_tmpany_phold.bem_firstGet_0();
bevt_59_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_33));
bevp_usedLibrarysStr = bevp_params.bem_get_1(bevt_59_tmpany_phold);
if (bevp_usedLibrarysStr == null) {
bevt_60_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_60_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_60_tmpany_phold.bevi_bool) /* Line: 186 */ {
bevp_usedLibrarysStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 187 */
bevt_61_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_34));
bevp_closeLibrariesStr = bevp_params.bem_get_1(bevt_61_tmpany_phold);
if (bevp_closeLibrariesStr == null) {
bevt_62_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_62_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_62_tmpany_phold.bevi_bool) /* Line: 190 */ {
bevp_closeLibrariesStr = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 191 */
bevt_63_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_35));
bevp_deployFilesFrom = bevp_params.bem_get_1(bevt_63_tmpany_phold);
if (bevp_deployFilesFrom == null) {
bevt_64_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_64_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_64_tmpany_phold.bevi_bool) /* Line: 194 */ {
bevp_deployFilesFrom = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 195 */
bevt_65_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_36));
bevp_deployFilesTo = bevp_params.bem_get_1(bevt_65_tmpany_phold);
if (bevp_deployFilesTo == null) {
bevt_66_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_66_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_66_tmpany_phold.bevi_bool) /* Line: 198 */ {
bevp_deployFilesTo = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 199 */
bevt_67_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_37));
bevp_extIncludes = bevp_params.bem_get_1(bevt_67_tmpany_phold);
if (bevp_extIncludes == null) {
bevt_68_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_68_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_68_tmpany_phold.bevi_bool) /* Line: 202 */ {
bevp_extIncludes = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 203 */
bevt_69_tmpany_phold = (new BEC_2_4_6_TextString(9, bece_BEC_2_5_5_BuildBuild_bels_38));
bevp_ccObjArgs = bevp_params.bem_get_1(bevt_69_tmpany_phold);
if (bevp_ccObjArgs == null) {
bevt_70_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_70_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_70_tmpany_phold.bevi_bool) /* Line: 206 */ {
bevp_ccObjArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 207 */
bevt_71_tmpany_phold = (new BEC_2_4_6_TextString(6, bece_BEC_2_5_5_BuildBuild_bels_39));
bevp_extLibs = bevp_params.bem_get_1(bevt_71_tmpany_phold);
if (bevp_extLibs == null) {
bevt_72_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_72_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_72_tmpany_phold.bevi_bool) /* Line: 210 */ {
bevp_extLibs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 211 */
bevt_73_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_40));
bevp_linkLibArgs = bevp_params.bem_get_1(bevt_73_tmpany_phold);
if (bevp_linkLibArgs == null) {
bevt_74_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_74_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_74_tmpany_phold.bevi_bool) /* Line: 214 */ {
bevp_linkLibArgs = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 215 */
bevt_75_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_41));
bevp_extLinkObjects = bevp_params.bem_get_1(bevt_75_tmpany_phold);
if (bevp_extLinkObjects == null) {
bevt_76_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_76_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_76_tmpany_phold.bevi_bool) /* Line: 218 */ {
bevp_extLinkObjects = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
} /* Line: 219 */
bevt_77_tmpany_phold = (new BEC_2_4_6_TextString(14, bece_BEC_2_5_5_BuildBuild_bels_42));
bevp_emitFileHeader = bevp_params.bem_get_1(bevt_77_tmpany_phold);
if (bevp_emitFileHeader == null) {
bevt_78_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_78_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_78_tmpany_phold.bevi_bool) /* Line: 222 */ {
bevp_emitFileHeader = bevp_emitFileHeader.bemd_0(-183400265, BEX_E.bevn_firstGet_0);
} /* Line: 223 */
bevt_79_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_43));
bevp_runArgs = bevp_params.bem_get_1(bevt_79_tmpany_phold);
if (bevp_runArgs == null) {
bevt_80_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_80_tmpany_phold.bevi_bool) /* Line: 226 */ {
bevp_runArgs = bevp_runArgs.bemd_0(-183400265, BEX_E.bevn_firstGet_0);
} /* Line: 227 */
 else  /* Line: 228 */ {
bevp_runArgs = (new BEC_2_4_6_TextString()).bem_new_0();
} /* Line: 229 */
bevt_81_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_44));
bevt_82_tmpany_phold = be.BECS_Runtime.boolFalse;
bevp_printSteps = bevp_params.bem_isTrue_2(bevt_81_tmpany_phold, bevt_82_tmpany_phold);
bevt_83_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_45));
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_printPlaces = bevp_params.bem_isTrue_2(bevt_83_tmpany_phold, bevt_84_tmpany_phold);
bevt_85_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_46));
bevp_printAst = bevp_params.bem_isTrue_1(bevt_85_tmpany_phold);
bevt_86_tmpany_phold = (new BEC_2_4_6_TextString(11, bece_BEC_2_5_5_BuildBuild_bels_47));
bevp_printAllAst = bevp_params.bem_isTrue_1(bevt_86_tmpany_phold);
bevp_printAstElements = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_87_tmpany_phold = (new BEC_2_4_6_TextString(15, bece_BEC_2_5_5_BuildBuild_bels_48));
bevl_pacm = bevp_params.bem_get_1(bevt_87_tmpany_phold);
if (bevl_pacm == null) {
bevt_88_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_88_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_88_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_90_tmpany_phold = bevl_pacm.bem_isEmptyGet_0();
if (bevt_90_tmpany_phold.bevi_bool) {
bevt_89_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_89_tmpany_phold.bevi_bool) /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 237 */
 else  /* Line: 237 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 237 */ {
bevt_1_tmpany_loop = bevl_pacm.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 238 */ {
bevt_91_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_91_tmpany_phold != null && bevt_91_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_91_tmpany_phold).bevi_bool) /* Line: 238 */ {
bevl_pa = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevp_printAstElements.bem_put_1(bevl_pa);
} /* Line: 239 */
 else  /* Line: 238 */ {
break;
} /* Line: 238 */
} /* Line: 238 */
} /* Line: 238 */
bevt_92_tmpany_phold = (new BEC_2_4_6_TextString(7, bece_BEC_2_5_5_BuildBuild_bels_49));
bevp_genOnly = bevp_params.bem_isTrue_1(bevt_92_tmpany_phold);
bevt_93_tmpany_phold = (new BEC_2_4_6_TextString(19, bece_BEC_2_5_5_BuildBuild_bels_50));
bevp_deployUsedLibraries = bevp_params.bem_isTrue_1(bevt_93_tmpany_phold);
bevt_94_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_51));
bevp_run = bevp_params.bem_isTrue_1(bevt_94_tmpany_phold);
bevt_95_tmpany_phold = (new BEC_2_4_6_TextString(21, bece_BEC_2_5_5_BuildBuild_bels_52));
bevt_96_tmpany_phold = be.BECS_Runtime.boolTrue;
bevp_putLineNumbersInTrace = bevp_params.bem_isTrue_2(bevt_95_tmpany_phold, bevt_96_tmpany_phold);
bevt_97_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_53));
bevp_emitLangs = bevp_params.bem_get_1(bevt_97_tmpany_phold);
bevt_98_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_54));
bevp_emitFlags = bevp_params.bem_get_1(bevt_98_tmpany_phold);
bevt_100_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_55));
bevt_101_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_56));
bevt_99_tmpany_phold = bevp_params.bem_get_2(bevt_100_tmpany_phold, bevt_101_tmpany_phold);
bevp_compiler = (BEC_2_4_6_TextString) bevt_99_tmpany_phold.bem_firstGet_0();
bevt_103_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_57));
bevt_104_tmpany_phold = (new BEC_2_4_6_TextString(4, bece_BEC_2_5_5_BuildBuild_bels_58));
bevt_102_tmpany_phold = bevp_params.bem_get_2(bevt_103_tmpany_phold, bevt_104_tmpany_phold);
bevp_makeName = (BEC_2_4_6_TextString) bevt_102_tmpany_phold.bem_firstGet_0();
bevt_107_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_4;
bevt_106_tmpany_phold = bevt_107_tmpany_phold.bem_add_1(bevp_makeName);
bevt_108_tmpany_phold = (new BEC_2_4_6_TextString(0, bece_BEC_2_5_5_BuildBuild_bels_60));
bevt_105_tmpany_phold = bevp_params.bem_get_2(bevt_106_tmpany_phold, bevt_108_tmpany_phold);
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_105_tmpany_phold.bem_firstGet_0();
bevp_parse = be.BECS_Runtime.boolTrue;
bevp_emitDebug = be.BECS_Runtime.boolTrue;
bevp_doEmit = be.BECS_Runtime.boolTrue;
bevp_prepMake = be.BECS_Runtime.boolTrue;
bevp_make = be.BECS_Runtime.boolTrue;
if (bevp_emitLangs == null) {
bevt_109_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_109_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_109_tmpany_phold.bevi_bool) /* Line: 258 */ {
bevl_outLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
} /* Line: 259 */
 else  /* Line: 260 */ {
bevl_outLang = (new BEC_2_4_6_TextString(1, bece_BEC_2_5_5_BuildBuild_bels_61));
} /* Line: 261 */
bevt_112_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_5;
bevt_111_tmpany_phold = bevl_outLang.bem_add_1(bevt_112_tmpany_phold);
bevt_113_tmpany_phold = bevp_platform.bemd_0(1211273660, BEX_E.bevn_nameGet_0);
bevt_110_tmpany_phold = bevt_111_tmpany_phold.bem_add_1(bevt_113_tmpany_phold);
bevl_platformSources = bevp_params.bem_get_1(bevt_110_tmpany_phold);
if (bevl_platformSources == null) {
bevt_114_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_114_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_114_tmpany_phold.bevi_bool) /* Line: 269 */ {
bevt_115_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_115_tmpany_phold.bem_addAll_1(bevl_platformSources);
} /* Line: 270 */
bevt_117_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_6;
bevt_116_tmpany_phold = bevl_outLang.bem_add_1(bevt_117_tmpany_phold);
bevl_langSources = bevp_params.bem_get_1(bevt_116_tmpany_phold);
if (bevl_langSources == null) {
bevt_118_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_118_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_118_tmpany_phold.bevi_bool) /* Line: 274 */ {
bevt_119_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_119_tmpany_phold.bem_addAll_1(bevl_langSources);
} /* Line: 275 */
bevp_toBuild = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevt_120_tmpany_phold = bevp_params.bem_orderedGet_0();
bevt_2_tmpany_loop = bevt_120_tmpany_phold.bem_iteratorGet_0();
while (true)
 /* Line: 279 */ {
bevt_121_tmpany_phold = bevt_2_tmpany_loop.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_121_tmpany_phold != null && bevt_121_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_121_tmpany_phold).bevi_bool) /* Line: 279 */ {
bevl_istr = (BEC_2_4_6_TextString) bevt_2_tmpany_loop.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_122_tmpany_phold = (new BEC_3_2_4_4_IOFilePath()).bem_new_1(bevl_istr);
bevp_toBuild.bem_addValue_1(bevt_122_tmpany_phold);
} /* Line: 280 */
 else  /* Line: 279 */ {
break;
} /* Line: 279 */
} /* Line: 279 */
bevp_newline = (BEC_2_4_6_TextString) bevp_platform.bemd_0(776765523, BEX_E.bevn_newlineGet_0);
bevp_nl = bevp_newline;
bevp_compilerProfile = (new BEC_2_5_15_BuildCompilerProfile()).bem_new_1(this);
bevp_emitPath = bevp_buildPath.bem_copy_0();
bevt_125_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_124_tmpany_phold = bevt_125_tmpany_phold.bem_existsGet_0();
if (bevt_124_tmpany_phold.bevi_bool) {
bevt_123_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_123_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_123_tmpany_phold.bevi_bool) /* Line: 287 */ {
bevt_126_tmpany_phold = bevp_emitPath.bem_fileGet_0();
bevt_126_tmpany_phold.bem_makeDirs_0();
} /* Line: 288 */
if (bevp_emitFileHeader == null) {
bevt_127_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_127_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_127_tmpany_phold.bevi_bool) /* Line: 290 */ {
bevt_128_tmpany_phold = (new BEC_2_2_4_IOFile()).bem_new_1(bevp_emitFileHeader);
bevl_emr = bevt_128_tmpany_phold.bem_readerGet_0();
bevt_129_tmpany_phold = bevl_emr.bemd_0(-1010579589, BEX_E.bevn_open_0);
bevp_emitFileHeader = bevt_129_tmpany_phold.bemd_0(347960120, BEX_E.bevn_readString_0);
bevl_emr.bemd_0(866536361, BEX_E.bevn_close_0);
} /* Line: 293 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_toRet = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
bevl_toRet = bem_classNameGet_0();
bevt_1_tmpany_phold = bevl_toRet.bemd_1(92659731, BEX_E.bevn_add_1, bevp_nl);
bevt_2_tmpany_phold = (new BEC_2_4_6_TextString(13, bece_BEC_2_5_5_BuildBuild_bels_64));
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(92659731, BEX_E.bevn_add_1, bevt_2_tmpany_phold);
bevt_3_tmpany_phold = bevp_buildPath.bem_toString_0();
bevl_toRet = bevt_0_tmpany_phold.bemd_1(92659731, BEX_E.bevn_add_1, bevt_3_tmpany_phold);
bevt_5_tmpany_phold = bevl_toRet.bemd_1(92659731, BEX_E.bevn_add_1, bevp_nl);
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(12, bece_BEC_2_5_5_BuildBuild_bels_65));
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bemd_1(92659731, BEX_E.bevn_add_1, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = bevp_emitPath.bem_toString_0();
bevl_toRet = bevt_4_tmpany_phold.bemd_1(92659731, BEX_E.bevn_add_1, bevt_7_tmpany_phold);
return (BEC_2_4_6_TextString) bevl_toRet;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_setClassesToWrite_0() throws Throwable {
BEC_2_9_3_ContainerSet bevl_toEmit = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_9_3_ContainerSet bevl_usedBy = null;
BEC_2_4_6_TextString bevl_ub = null;
BEC_2_9_3_ContainerSet bevl_subClasses = null;
BEC_2_4_6_TextString bevl_sc = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_0_tmpany_loop = null;
BEC_3_9_3_11_ContainerSetKeyIterator bevt_1_tmpany_loop = null;
BEC_2_9_3_ContainerMap bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_9_3_ContainerSet bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_21_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_22_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_23_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_26_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
bevl_toEmit = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_2_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_2_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 307 */ {
bevt_3_tmpany_phold = bevl_ci.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 307 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_5_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_7_tmpany_phold = bevl_clnode.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(795036897, BEX_E.bevn_fromFileGet_0);
bevt_4_tmpany_phold = bevt_5_tmpany_phold.bem_has_1(bevt_6_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 309 */ {
bevt_10_tmpany_phold = bevl_clnode.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(354142775, BEX_E.bevn_namepathGet_0);
bevt_8_tmpany_phold = bevt_9_tmpany_phold.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevl_toEmit.bem_put_1(bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bevp_emitData.bem_usedByGet_0();
bevt_14_tmpany_phold = bevl_clnode.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_13_tmpany_phold = bevt_14_tmpany_phold.bemd_0(354142775, BEX_E.bevn_namepathGet_0);
bevt_12_tmpany_phold = bevt_13_tmpany_phold.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevl_usedBy = (BEC_2_9_3_ContainerSet) bevt_11_tmpany_phold.bem_get_1(bevt_12_tmpany_phold);
if (bevl_usedBy == null) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 312 */ {
bevt_0_tmpany_loop = bevl_usedBy.bem_setIteratorGet_0();
while (true)
 /* Line: 313 */ {
bevt_16_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_16_tmpany_phold.bevi_bool) /* Line: 313 */ {
bevl_ub = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_ub);
} /* Line: 314 */
 else  /* Line: 313 */ {
break;
} /* Line: 313 */
} /* Line: 313 */
} /* Line: 313 */
bevt_17_tmpany_phold = bevp_emitData.bem_subClassesGet_0();
bevt_20_tmpany_phold = bevl_clnode.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(354142775, BEX_E.bevn_namepathGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevl_subClasses = (BEC_2_9_3_ContainerSet) bevt_17_tmpany_phold.bem_get_1(bevt_18_tmpany_phold);
if (bevl_subClasses == null) {
bevt_21_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_21_tmpany_phold.bevi_bool) /* Line: 318 */ {
bevt_1_tmpany_loop = bevl_subClasses.bem_setIteratorGet_0();
while (true)
 /* Line: 319 */ {
bevt_22_tmpany_phold = bevt_1_tmpany_loop.bem_hasNextGet_0();
if (bevt_22_tmpany_phold.bevi_bool) /* Line: 319 */ {
bevl_sc = (BEC_2_4_6_TextString) bevt_1_tmpany_loop.bem_nextGet_0();
bevl_toEmit.bem_put_1(bevl_sc);
} /* Line: 320 */
 else  /* Line: 319 */ {
break;
} /* Line: 319 */
} /* Line: 319 */
} /* Line: 319 */
} /* Line: 318 */
} /* Line: 309 */
 else  /* Line: 307 */ {
break;
} /* Line: 307 */
} /* Line: 307 */
bevt_23_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_23_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 325 */ {
bevt_24_tmpany_phold = bevl_ci.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_24_tmpany_phold != null && bevt_24_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_24_tmpany_phold).bevi_bool) /* Line: 325 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_25_tmpany_phold = bevl_clnode.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_29_tmpany_phold = bevl_clnode.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_0(354142775, BEX_E.bevn_namepathGet_0);
bevt_27_tmpany_phold = bevt_28_tmpany_phold.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevt_26_tmpany_phold = bevl_toEmit.bem_has_1(bevt_27_tmpany_phold);
bevt_25_tmpany_phold.bemd_1(2134225160, BEX_E.bevn_shouldWriteSet_1, bevt_26_tmpany_phold);
} /* Line: 327 */
 else  /* Line: 325 */ {
break;
} /* Line: 325 */
} /* Line: 325 */
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_emitCs_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_10_BuildEmitCommon bem_emitCommonGet_0() throws Throwable {
BEC_2_4_6_TextString bevl_emitLang = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_4_6_TextString bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_6_TextString bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_6_9_SystemException bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
if (bevp_emitCommon == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 338 */ {
return bevp_emitCommon;
} /* Line: 339 */
if (bevp_emitLangs == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 344 */ {
bevl_emitLang = (BEC_2_4_6_TextString) bevp_emitLangs.bem_firstGet_0();
bevt_3_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_7;
bevt_2_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_3_tmpany_phold);
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 346 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJVEmitter()).bem_new_1(this);
} /* Line: 347 */
 else  /* Line: 346 */ {
bevt_5_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_8;
bevt_4_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 348 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCSEmitter()).bem_new_1(this);
} /* Line: 349 */
 else  /* Line: 346 */ {
bevt_7_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_9;
bevt_6_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_7_tmpany_phold);
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 350 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildCCEmitter()).bem_new_1(this);
} /* Line: 351 */
 else  /* Line: 346 */ {
bevt_9_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_10;
bevt_8_tmpany_phold = bevl_emitLang.bem_equals_1(bevt_9_tmpany_phold);
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 352 */ {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) (new BEC_2_5_9_BuildJSEmitter()).bem_new_1(this);
} /* Line: 353 */
 else  /* Line: 354 */ {
bevt_11_tmpany_phold = (new BEC_2_4_6_TextString(49, bece_BEC_2_5_5_BuildBuild_bels_70));
bevt_10_tmpany_phold = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_11_tmpany_phold);
throw new be.BECS_ThrowBack(bevt_10_tmpany_phold);
} /* Line: 355 */
} /* Line: 346 */
} /* Line: 346 */
} /* Line: 346 */
bevp_emitCommon.bem_dynConditionsAllSet_1(bevp_dynConditionsAll);
return bevp_emitCommon;
} /* Line: 358 */
return null;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSyns_1(BEC_2_4_6_TextString beva_lsp) throws Throwable {
BEC_3_2_4_4_IOFilePath bevl_synEmitPath = null;
BEC_2_4_8_TimeInterval bevl_sst = null;
BEC_3_2_4_6_IOFileReader bevl_syne = null;
BEC_2_9_3_ContainerMap bevl_scls = null;
BEC_2_4_8_TimeInterval bevl_sse = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_2_4_IOFile bevt_4_tmpany_phold = null;
BEC_2_6_10_SystemSerializer bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_7_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
bevl_synEmitPath = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(beva_lsp);
bevt_1_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_11;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_add_1(beva_lsp);
bevt_0_tmpany_phold.bem_print_0();
bevt_2_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_sst = bevt_2_tmpany_phold.bem_now_0();
bevt_4_tmpany_phold = bevl_synEmitPath.bem_fileGet_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_readerGet_0();
bevl_syne = (BEC_3_2_4_6_IOFileReader) bevt_3_tmpany_phold.bemd_0(-1010579589, BEX_E.bevn_open_0);
bevt_5_tmpany_phold = (new BEC_2_6_10_SystemSerializer()).bem_new_0();
bevl_scls = (BEC_2_9_3_ContainerMap) bevt_5_tmpany_phold.bem_deserialize_1(bevl_syne);
bevl_syne.bem_close_0();
bevt_6_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevt_6_tmpany_phold.bem_addValue_1(bevl_scls);
bevt_8_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_now_0();
bevl_sse = bevt_7_tmpany_phold.bem_subtract_1(bevl_sst);
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_12;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevl_sse);
bevt_9_tmpany_phold.bem_print_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_doWhat_0() throws Throwable {
BEC_2_4_6_TextString bevl_lsp = null;
BEC_2_6_6_SystemObject bevl_em = null;
BEC_2_9_3_ContainerSet bevl_ulibs = null;
BEC_2_6_6_SystemObject bevl_ups = null;
BEC_2_6_6_SystemObject bevl_pack = null;
BEC_2_9_3_ContainerSet bevl_built = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_tb = null;
BEC_2_4_8_TimeInterval bevl_emitStart = null;
BEC_2_4_8_TimeInterval bevl_emitTime = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_bp = null;
BEC_2_6_6_SystemObject bevl_cpFrom = null;
BEC_2_6_6_SystemObject bevl_cpTo = null;
BEC_2_6_6_SystemObject bevl_fIter = null;
BEC_2_6_6_SystemObject bevl_tIter = null;
BEC_2_4_3_MathInt bevl_result = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_loop = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_loop = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_3_tmpany_loop = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_8_TimeInterval bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_4_6_TextString bevt_9_tmpany_phold = null;
BEC_2_4_6_TextString bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_15_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_22_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_25_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_26_tmpany_phold = null;
BEC_2_5_10_BuildEmitCommon bevt_27_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_28_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_29_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_30_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_31_tmpany_phold = null;
BEC_2_4_6_TextString bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_2_4_6_TextString bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_2_4_6_TextString bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_38_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_39_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_40_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_41_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_42_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_43_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_44_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_45_tmpany_phold = null;
BEC_2_4_6_TextString bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_2_4_6_TextString bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_50_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_51_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_52_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_53_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_54_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_55_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_56_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_57_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_58_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_59_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_65_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_66_tmpany_phold = null;
BEC_2_4_6_TextString bevt_67_tmpany_phold = null;
BEC_2_4_6_TextString bevt_68_tmpany_phold = null;
BEC_2_4_6_TextString bevt_69_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_70_tmpany_phold = null;
BEC_3_2_4_4_IOFilePath bevt_71_tmpany_phold = null;
BEC_2_4_6_TextString bevt_72_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_73_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_74_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_75_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_76_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_77_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_78_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_79_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_80_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_81_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_82_tmpany_phold = null;
BEC_2_4_8_TimeInterval bevt_83_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_84_tmpany_phold = null;
BEC_2_4_6_TextString bevt_85_tmpany_phold = null;
BEC_2_4_6_TextString bevt_86_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_87_tmpany_phold = null;
BEC_2_4_6_TextString bevt_88_tmpany_phold = null;
BEC_2_4_6_TextString bevt_89_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_90_tmpany_phold = null;
BEC_2_4_6_TextString bevt_91_tmpany_phold = null;
BEC_2_4_6_TextString bevt_92_tmpany_phold = null;
BEC_2_4_6_TextString bevt_93_tmpany_phold = null;
BEC_2_4_6_TextString bevt_94_tmpany_phold = null;
BEC_2_4_6_TextString bevt_95_tmpany_phold = null;
BEC_2_4_6_TextString bevt_96_tmpany_phold = null;
BEC_2_4_6_TextString bevt_97_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_98_tmpany_phold = null;
bevt_5_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevp_startTime = bevt_5_tmpany_phold.bem_now_0();
bevp_emitData = (new BEC_2_5_8_BuildEmitData()).bem_new_0();
if (bevp_loadSyns == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 381 */ {
bevt_0_tmpany_loop = bevp_loadSyns.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 382 */ {
bevt_7_tmpany_phold = bevt_0_tmpany_loop.bem_hasNextGet_0();
if (bevt_7_tmpany_phold != null && bevt_7_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_7_tmpany_phold).bevi_bool) /* Line: 382 */ {
bevl_lsp = (BEC_2_4_6_TextString) bevt_0_tmpany_loop.bem_nextGet_0();
bem_loadSyns_1(bevl_lsp);
} /* Line: 383 */
 else  /* Line: 382 */ {
break;
} /* Line: 382 */
} /* Line: 382 */
} /* Line: 382 */
bevl_em = bem_emitterGet_0();
if (bevp_deployPath == null) {
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_8_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_8_tmpany_phold.bevi_bool) /* Line: 387 */ {
bevp_deployLibrary = (new BEC_2_5_7_BuildLibrary()).bem_new_4(bevp_deployPath, this, bevp_libName, bevp_exeName);
bevp_closeLibraries.bem_put_1(bevp_libName);
if (bevp_printSteps.bevi_bool) /* Line: 390 */ {
bevt_10_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_13;
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bem_add_1(bevp_libName);
bevt_9_tmpany_phold.bem_print_0();
} /* Line: 391 */
} /* Line: 390 */
bevl_ulibs = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevt_1_tmpany_loop = bevp_usedLibrarysStr.bemd_0(-845792839, BEX_E.bevn_iteratorGet_0);
while (true)
 /* Line: 396 */ {
bevt_11_tmpany_phold = bevt_1_tmpany_loop.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_11_tmpany_phold != null && bevt_11_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_11_tmpany_phold).bevi_bool) /* Line: 396 */ {
bevl_ups = bevt_1_tmpany_loop.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_13_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_13_tmpany_phold.bevi_bool) {
bevt_12_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_12_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
} /* Line: 400 */
} /* Line: 397 */
 else  /* Line: 396 */ {
break;
} /* Line: 396 */
} /* Line: 396 */
bevt_2_tmpany_loop = bevp_closeLibrariesStr.bemd_0(-845792839, BEX_E.bevn_iteratorGet_0);
while (true)
 /* Line: 403 */ {
bevt_14_tmpany_phold = bevt_2_tmpany_loop.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_14_tmpany_phold != null && bevt_14_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_14_tmpany_phold).bevi_bool) /* Line: 403 */ {
bevl_ups = bevt_2_tmpany_loop.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_16_tmpany_phold = bevl_ulibs.bem_has_1(bevl_ups);
if (bevt_16_tmpany_phold.bevi_bool) {
bevt_15_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_15_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_15_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevl_ulibs.bem_put_1(bevl_ups);
bevl_pack = (new BEC_2_5_7_BuildLibrary()).bem_new_2((BEC_2_4_6_TextString) bevl_ups , this);
bevp_usedLibrarys.bem_addValue_1(bevl_pack);
bevt_17_tmpany_phold = bevl_pack.bemd_0(-1803479881, BEX_E.bevn_libNameGet_0);
bevp_closeLibraries.bem_put_1(bevt_17_tmpany_phold);
} /* Line: 408 */
} /* Line: 404 */
 else  /* Line: 403 */ {
break;
} /* Line: 403 */
} /* Line: 403 */
if (bevp_parse.bevi_bool) /* Line: 411 */ {
bevl_built = (new BEC_2_9_3_ContainerSet()).bem_new_0();
bevl_i = bevp_toBuild.bem_iteratorGet_0();
while (true)
 /* Line: 414 */ {
bevt_18_tmpany_phold = bevl_i.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 414 */ {
bevl_tb = bevl_i.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_20_tmpany_phold = bevl_tb.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevt_19_tmpany_phold = bevl_built.bem_has_1(bevt_20_tmpany_phold);
if (!(bevt_19_tmpany_phold.bevi_bool)) /* Line: 417 */ {
bevt_21_tmpany_phold = bevl_tb.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevl_built.bem_put_1(bevt_21_tmpany_phold);
bem_doParse_1(bevl_tb);
} /* Line: 419 */
} /* Line: 417 */
 else  /* Line: 414 */ {
break;
} /* Line: 414 */
} /* Line: 414 */
bem_buildSyns_1(bevl_em);
} /* Line: 422 */
bevt_23_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_22_tmpany_phold = bevt_23_tmpany_phold.bem_now_0();
bevp_parseTime = bevt_22_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_25_tmpany_phold = bem_emitCommonGet_0();
if (bevt_25_tmpany_phold == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 428 */ {
bevt_26_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevl_emitStart = bevt_26_tmpany_phold.bem_now_0();
bevt_27_tmpany_phold = bem_emitCommonGet_0();
bevt_27_tmpany_phold.bem_doEmit_0();
bevt_29_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_28_tmpany_phold.bem_subtract_1(bevp_startTime);
bevt_31_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_30_tmpany_phold = bevt_31_tmpany_phold.bem_now_0();
bevl_emitTime = bevt_30_tmpany_phold.bem_subtract_1(bevl_emitStart);
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_14;
bevt_32_tmpany_phold = bevt_33_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_32_tmpany_phold.bem_print_0();
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_15;
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bem_add_1(bevl_emitTime);
bevt_34_tmpany_phold.bem_print_0();
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_16;
bevt_36_tmpany_phold = bevt_37_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_36_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_38_tmpany_phold;
} /* Line: 437 */
if (bevp_doEmit.bevi_bool) /* Line: 439 */ {
bem_setClassesToWrite_0();
bevl_em.bemd_0(1743271113, BEX_E.bevn_libnameInfoGet_0);
bevt_39_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_39_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 443 */ {
bevt_40_tmpany_phold = bevl_ci.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_40_tmpany_phold != null && bevt_40_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_40_tmpany_phold).bevi_bool) /* Line: 443 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevl_em.bemd_1(-4647120, BEX_E.bevn_doEmit_1, bevl_clnode);
} /* Line: 445 */
 else  /* Line: 443 */ {
break;
} /* Line: 443 */
} /* Line: 443 */
bevl_em.bemd_0(-1632069411, BEX_E.bevn_emitMain_0);
bevl_em.bemd_0(315216038, BEX_E.bevn_emitCUInit_0);
bevt_41_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_41_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 449 */ {
bevt_42_tmpany_phold = bevl_ci.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_42_tmpany_phold != null && bevt_42_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_42_tmpany_phold).bevi_bool) /* Line: 449 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevl_em.bemd_1(923444327, BEX_E.bevn_emitSyn_1, bevl_clnode);
} /* Line: 451 */
 else  /* Line: 449 */ {
break;
} /* Line: 449 */
} /* Line: 449 */
} /* Line: 449 */
bevt_44_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_43_tmpany_phold = bevt_44_tmpany_phold.bem_now_0();
bevp_parseEmitTime = bevt_43_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_45_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_45_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_45_tmpany_phold.bevi_bool) /* Line: 456 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_17;
bevt_46_tmpany_phold = bevt_47_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_46_tmpany_phold.bem_print_0();
} /* Line: 457 */
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_18;
bevt_48_tmpany_phold = bevt_49_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_48_tmpany_phold.bem_print_0();
if (bevp_prepMake.bevi_bool) /* Line: 460 */ {
bevl_em.bemd_1(-1877358931, BEX_E.bevn_prepMake_1, bevp_deployLibrary);
} /* Line: 462 */
if (bevp_make.bevi_bool) /* Line: 465 */ {
if (bevp_genOnly.bevi_bool) {
bevt_50_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_50_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_50_tmpany_phold.bevi_bool) /* Line: 466 */ {
bevl_em.bemd_1(-1081520608, BEX_E.bevn_make_1, bevp_deployLibrary);
bevl_em.bemd_1(2084483206, BEX_E.bevn_deployLibrary_1, bevp_deployLibrary);
if (bevp_deployUsedLibraries.bevi_bool) /* Line: 469 */ {
bevt_3_tmpany_loop = bevp_usedLibrarys.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 470 */ {
bevt_51_tmpany_phold = bevt_3_tmpany_loop.bem_hasNextGet_0();
if (bevt_51_tmpany_phold != null && bevt_51_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_51_tmpany_phold).bevi_bool) /* Line: 470 */ {
bevl_bp = bevt_3_tmpany_loop.bem_nextGet_0();
bevt_52_tmpany_phold = bevl_bp.bemd_0(1743271113, BEX_E.bevn_libnameInfoGet_0);
bevl_cpFrom = bevt_52_tmpany_phold.bemd_0(-159064069, BEX_E.bevn_unitShlibGet_0);
bevt_53_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevl_cpTo = bevt_53_tmpany_phold.bem_copy_0();
bevt_55_tmpany_phold = bevl_cpFrom.bemd_0(-723109216, BEX_E.bevn_stepsGet_0);
bevt_54_tmpany_phold = bevt_55_tmpany_phold.bemd_0(1990707345, BEX_E.bevn_lastGet_0);
bevl_cpTo.bemd_1(472959, BEX_E.bevn_addStep_1, bevt_54_tmpany_phold);
bevt_57_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_56_tmpany_phold = bevt_57_tmpany_phold.bemd_0(2072547979, BEX_E.bevn_existsGet_0);
if (bevt_56_tmpany_phold != null && bevt_56_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_56_tmpany_phold).bevi_bool) /* Line: 474 */ {
bevt_58_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_58_tmpany_phold.bemd_0(819712668, BEX_E.bevn_delete_0);
} /* Line: 475 */
bevt_61_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_60_tmpany_phold = bevt_61_tmpany_phold.bemd_0(2072547979, BEX_E.bevn_existsGet_0);
bevt_59_tmpany_phold = bevt_60_tmpany_phold.bemd_0(105008580, BEX_E.bevn_not_0);
if (bevt_59_tmpany_phold != null && bevt_59_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_59_tmpany_phold).bevi_bool) /* Line: 477 */ {
bevt_62_tmpany_phold = bevl_cpFrom.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_63_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEX_E.bevn_deployFile_2, bevt_62_tmpany_phold, bevt_63_tmpany_phold);
} /* Line: 478 */
} /* Line: 477 */
 else  /* Line: 470 */ {
break;
} /* Line: 470 */
} /* Line: 470 */
} /* Line: 470 */
bevl_fIter = bevp_deployFilesFrom.bem_iteratorGet_0();
bevl_tIter = bevp_deployFilesTo.bem_iteratorGet_0();
while (true)
 /* Line: 485 */ {
bevt_64_tmpany_phold = bevl_fIter.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_64_tmpany_phold != null && bevt_64_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_64_tmpany_phold).bevi_bool) /* Line: 485 */ {
bevt_65_tmpany_phold = bevl_tIter.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_65_tmpany_phold != null && bevt_65_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_65_tmpany_phold).bevi_bool) /* Line: 485 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 485 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 485 */
 else  /* Line: 485 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 485 */ {
bevt_66_tmpany_phold = bevl_fIter.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevl_cpFrom = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_66_tmpany_phold );
bevt_71_tmpany_phold = bevp_deployLibrary.bem_emitPathGet_0();
bevt_70_tmpany_phold = bevt_71_tmpany_phold.bem_copy_0();
bevt_69_tmpany_phold = bevt_70_tmpany_phold.bem_toString_0();
bevt_72_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_19;
bevt_68_tmpany_phold = bevt_69_tmpany_phold.bem_add_1(bevt_72_tmpany_phold);
bevt_73_tmpany_phold = bevl_tIter.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_67_tmpany_phold = bevt_68_tmpany_phold.bem_add_1(bevt_73_tmpany_phold);
bevl_cpTo = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1(bevt_67_tmpany_phold);
bevt_75_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_74_tmpany_phold = bevt_75_tmpany_phold.bemd_0(2072547979, BEX_E.bevn_existsGet_0);
if (bevt_74_tmpany_phold != null && bevt_74_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_74_tmpany_phold).bevi_bool) /* Line: 489 */ {
bevt_76_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_76_tmpany_phold.bemd_0(819712668, BEX_E.bevn_delete_0);
} /* Line: 490 */
bevt_79_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_78_tmpany_phold = bevt_79_tmpany_phold.bemd_0(2072547979, BEX_E.bevn_existsGet_0);
bevt_77_tmpany_phold = bevt_78_tmpany_phold.bemd_0(105008580, BEX_E.bevn_not_0);
if (bevt_77_tmpany_phold != null && bevt_77_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_77_tmpany_phold).bevi_bool) /* Line: 492 */ {
bevt_80_tmpany_phold = bevl_cpFrom.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_81_tmpany_phold = bevl_cpTo.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevl_em.bemd_2(-1249810954, BEX_E.bevn_deployFile_2, bevt_80_tmpany_phold, bevt_81_tmpany_phold);
} /* Line: 493 */
} /* Line: 492 */
 else  /* Line: 485 */ {
break;
} /* Line: 485 */
} /* Line: 485 */
} /* Line: 485 */
} /* Line: 466 */
bevt_83_tmpany_phold = (new BEC_2_4_8_TimeInterval()).bem_new_0();
bevt_82_tmpany_phold = bevt_83_tmpany_phold.bem_now_0();
bevp_parseEmitCompileTime = bevt_82_tmpany_phold.bem_subtract_1(bevp_startTime);
if (bevp_parseTime == null) {
bevt_84_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_84_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_84_tmpany_phold.bevi_bool) /* Line: 500 */ {
bevt_86_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_20;
bevt_85_tmpany_phold = bevt_86_tmpany_phold.bem_add_1(bevp_parseTime);
bevt_85_tmpany_phold.bem_print_0();
} /* Line: 501 */
if (bevp_parseEmitTime == null) {
bevt_87_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_87_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_87_tmpany_phold.bevi_bool) /* Line: 503 */ {
bevt_89_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_21;
bevt_88_tmpany_phold = bevt_89_tmpany_phold.bem_add_1(bevp_parseEmitTime);
bevt_88_tmpany_phold.bem_print_0();
} /* Line: 504 */
if (bevp_parseEmitCompileTime == null) {
bevt_90_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_90_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_90_tmpany_phold.bevi_bool) /* Line: 506 */ {
bevt_92_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_22;
bevt_91_tmpany_phold = bevt_92_tmpany_phold.bem_add_1(bevp_parseEmitCompileTime);
bevt_91_tmpany_phold.bem_print_0();
} /* Line: 507 */
if (bevp_run.bevi_bool) /* Line: 510 */ {
bevt_93_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_23;
bevt_93_tmpany_phold.bem_print_0();
bevl_result = (BEC_2_4_3_MathInt) bevl_em.bemd_2(108875646, BEX_E.bevn_run_2, bevp_deployLibrary, bevp_runArgs);
bevt_96_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_24;
bevt_95_tmpany_phold = bevt_96_tmpany_phold.bem_add_1(bevl_result);
bevt_97_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_25;
bevt_94_tmpany_phold = bevt_95_tmpany_phold.bem_add_1(bevt_97_tmpany_phold);
bevt_94_tmpany_phold.bem_print_0();
return bevl_result;
} /* Line: 514 */
bevt_98_tmpany_phold = (new BEC_2_4_3_MathInt(0));
return bevt_98_tmpany_phold;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSyns_1(BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_kls = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_6_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_0_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 520 */ {
bevt_1_tmpany_phold = bevl_ci.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 520 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_2_tmpany_phold = bevl_kls.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_2_tmpany_phold.bemd_1(-1792397628, BEX_E.bevn_libNameSet_1, bevp_libName);
bevl_syn = bem_getSyn_2(bevl_kls, beva_em);
bevl_syn.bemd_1(-1792397628, BEX_E.bevn_libNameSet_1, bevp_libName);
} /* Line: 524 */
 else  /* Line: 520 */ {
break;
} /* Line: 520 */
} /* Line: 520 */
bevt_3_tmpany_phold = bevp_emitData.bem_justParsedGet_0();
bevl_ci = bevt_3_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 526 */ {
bevt_4_tmpany_phold = bevl_ci.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_4_tmpany_phold != null && bevt_4_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_4_tmpany_phold).bevi_bool) /* Line: 526 */ {
bevl_kls = bevl_ci.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevt_5_tmpany_phold = bevl_kls.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevl_syn = bevt_5_tmpany_phold.bemd_0(1791388575, BEX_E.bevn_synGet_0);
bevl_syn.bemd_2(1694832085, BEX_E.bevn_checkInheritance_2, this, bevl_kls);
bevl_syn.bemd_1(1156342947, BEX_E.bevn_integrate_1, this);
} /* Line: 530 */
 else  /* Line: 526 */ {
break;
} /* Line: 526 */
} /* Line: 526 */
bevt_6_tmpany_phold = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevp_emitData.bem_justParsedSet_1(bevt_6_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_getSyn_2(BEC_2_6_6_SystemObject beva_klass, BEC_2_6_6_SystemObject beva_em) throws Throwable {
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_6_6_SystemObject bevl_pklass = null;
BEC_2_6_6_SystemObject bevl_psyn = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_13_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_16_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_20_tmpany_phold = null;
bevt_2_tmpany_phold = beva_klass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bemd_0(1791388575, BEX_E.bevn_synGet_0);
if (bevt_1_tmpany_phold == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 536 */ {
bevt_4_tmpany_phold = beva_klass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_0(1791388575, BEX_E.bevn_synGet_0);
return bevt_3_tmpany_phold;
} /* Line: 537 */
bevt_5_tmpany_phold = beva_klass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_5_tmpany_phold.bemd_1(-1792397628, BEX_E.bevn_libNameSet_1, bevp_libName);
bevt_8_tmpany_phold = beva_klass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(429326446, BEX_E.bevn_extendsGet_0);
if (bevt_7_tmpany_phold == null) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 540 */ {
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_1(beva_klass);
} /* Line: 541 */
 else  /* Line: 542 */ {
bevt_9_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevt_12_tmpany_phold = beva_klass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_11_tmpany_phold = bevt_12_tmpany_phold.bemd_0(429326446, BEX_E.bevn_extendsGet_0);
bevt_10_tmpany_phold = bevt_11_tmpany_phold.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevl_pklass = bevt_9_tmpany_phold.bem_get_1(bevt_10_tmpany_phold);
if (bevl_pklass == null) {
bevt_13_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_13_tmpany_phold.bevi_bool) /* Line: 545 */ {
bevt_14_tmpany_phold = bevl_pklass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_14_tmpany_phold.bemd_1(-1792397628, BEX_E.bevn_libNameSet_1, bevp_libName);
bevl_psyn = bem_getSyn_2(bevl_pklass, beva_em);
} /* Line: 547 */
 else  /* Line: 548 */ {
bevt_16_tmpany_phold = beva_klass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_15_tmpany_phold = bevt_16_tmpany_phold.bemd_0(429326446, BEX_E.bevn_extendsGet_0);
bevl_psyn = bem_getSynNp_1(bevt_15_tmpany_phold);
} /* Line: 551 */
bevl_syn = (new BEC_2_5_8_BuildClassSyn()).bem_new_2(beva_klass, bevl_psyn);
} /* Line: 553 */
bevt_17_tmpany_phold = beva_klass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_17_tmpany_phold.bemd_1(1802470828, BEX_E.bevn_synSet_1, bevl_syn);
bevt_20_tmpany_phold = beva_klass.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_19_tmpany_phold = bevt_20_tmpany_phold.bemd_0(354142775, BEX_E.bevn_namepathGet_0);
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevt_18_tmpany_phold , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return bevl_syn;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_getSynNp_1(BEC_2_6_6_SystemObject beva_np) throws Throwable {
BEC_2_6_6_SystemObject bevl_nps = null;
BEC_2_6_6_SystemObject bevl_syn = null;
BEC_2_9_3_ContainerMap bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
bevl_nps = beva_np.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevt_0_tmpany_phold = bevp_emitData.bem_synClassesGet_0();
bevl_syn = bevt_0_tmpany_phold.bem_get_1(bevl_nps);
if (bevl_syn == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 563 */ {
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /* Line: 564 */
bevt_2_tmpany_phold = bem_emitterGet_0();
bevl_syn = bevt_2_tmpany_phold.bemd_1(1378657076, BEX_E.bevn_loadSyn_1, beva_np);
bevp_emitData.bem_addSynClass_2((BEC_2_4_6_TextString) bevl_nps , (BEC_2_5_8_BuildClassSyn) bevl_syn );
return (BEC_2_5_8_BuildClassSyn) bevl_syn;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitterGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
if (bevp_sharedEmitter == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 579 */ {
bevp_sharedEmitter = (new BEC_2_5_8_BuildCEmitter()).bem_new_1(this);
} /* Line: 580 */
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doParse_1(BEC_2_6_6_SystemObject beva_toParse) throws Throwable {
BEC_2_6_6_SystemObject bevl_trans = null;
BEC_2_6_6_SystemObject bevl_blank = null;
BEC_2_6_6_SystemObject bevl_emitter = null;
BEC_2_5_4_LogicBool bevl_parseThis = null;
BEC_2_6_6_SystemObject bevl_src = null;
BEC_2_9_10_ContainerLinkedList bevl_toks = null;
BEC_2_6_6_SystemObject bevl_ci = null;
BEC_2_6_6_SystemObject bevl_clnode = null;
BEC_2_6_6_SystemObject bevl_tunode = null;
BEC_2_6_6_SystemObject bevl_ntunode = null;
BEC_2_6_6_SystemObject bevl_ntt = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_9_3_ContainerSet bevt_2_tmpany_phold = null;
BEC_2_4_6_TextString bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_9_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_10_tmpany_phold = null;
BEC_2_4_6_TextString bevt_11_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_12_tmpany_phold = null;
BEC_2_4_6_TextString bevt_13_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_14_tmpany_phold = null;
BEC_2_4_6_TextString bevt_15_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass2 bevt_16_tmpany_phold = null;
BEC_2_4_6_TextString bevt_17_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_18_tmpany_phold = null;
BEC_2_4_6_TextString bevt_19_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass3 bevt_20_tmpany_phold = null;
BEC_2_4_6_TextString bevt_21_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_22_tmpany_phold = null;
BEC_2_4_6_TextString bevt_23_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass4 bevt_24_tmpany_phold = null;
BEC_2_4_6_TextString bevt_25_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_26_tmpany_phold = null;
BEC_2_4_6_TextString bevt_27_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass5 bevt_28_tmpany_phold = null;
BEC_2_4_6_TextString bevt_29_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_30_tmpany_phold = null;
BEC_2_4_6_TextString bevt_31_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass6 bevt_32_tmpany_phold = null;
BEC_2_4_6_TextString bevt_33_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_34_tmpany_phold = null;
BEC_2_4_6_TextString bevt_35_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass7 bevt_36_tmpany_phold = null;
BEC_2_4_6_TextString bevt_37_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_38_tmpany_phold = null;
BEC_2_4_6_TextString bevt_39_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass8 bevt_40_tmpany_phold = null;
BEC_2_4_6_TextString bevt_41_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_42_tmpany_phold = null;
BEC_2_4_6_TextString bevt_43_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass9 bevt_44_tmpany_phold = null;
BEC_2_4_6_TextString bevt_45_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_46_tmpany_phold = null;
BEC_2_4_6_TextString bevt_47_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass10 bevt_48_tmpany_phold = null;
BEC_2_4_6_TextString bevt_49_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_50_tmpany_phold = null;
BEC_2_4_6_TextString bevt_51_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass11 bevt_52_tmpany_phold = null;
BEC_2_4_6_TextString bevt_53_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_54_tmpany_phold = null;
BEC_2_4_6_TextString bevt_55_tmpany_phold = null;
BEC_2_4_6_TextString bevt_56_tmpany_phold = null;
BEC_3_5_5_6_BuildVisitPass12 bevt_57_tmpany_phold = null;
BEC_2_4_6_TextString bevt_58_tmpany_phold = null;
BEC_3_5_5_5_BuildVisitPass1 bevt_59_tmpany_phold = null;
BEC_2_9_3_ContainerMap bevt_60_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_61_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_62_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_63_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_64_tmpany_phold = null;
bevl_trans = (new BEC_2_5_9_BuildTransport()).bem_new_1(this);
bevl_blank = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_emitter = bem_emitterGet_0();
bevp_code = null;
bevl_parseThis = be.BECS_Runtime.boolTrue;
bevt_2_tmpany_phold = bevp_emitData.bem_shouldEmitGet_0();
bevt_2_tmpany_phold.bem_put_1(beva_toParse);
if (bevl_parseThis.bevi_bool) /* Line: 593 */ {
if (bevp_printSteps.bevi_bool) /* Line: 594 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 594 */ {
if (bevp_printPlaces.bevi_bool) /* Line: 594 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 594 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 594 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 594 */ {
bevt_4_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_26;
bevt_5_tmpany_phold = beva_toParse.bemd_0(1774940957, BEX_E.bevn_toString_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_add_1(bevt_5_tmpany_phold);
bevt_3_tmpany_phold.bem_print_0();
} /* Line: 595 */
bevp_fromFile = beva_toParse;
bevt_8_tmpany_phold = beva_toParse.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bemd_0(371906180, BEX_E.bevn_readerGet_0);
bevt_6_tmpany_phold = bevt_7_tmpany_phold.bemd_0(-1010579589, BEX_E.bevn_open_0);
bevl_src = bevt_6_tmpany_phold.bemd_1(1325881256, BEX_E.bevn_readBuffer_1, bevp_readBuffer);
bevt_10_tmpany_phold = beva_toParse.bemd_0(-1338882709, BEX_E.bevn_fileGet_0);
bevt_9_tmpany_phold = bevt_10_tmpany_phold.bemd_0(371906180, BEX_E.bevn_readerGet_0);
bevt_9_tmpany_phold.bemd_0(866536361, BEX_E.bevn_close_0);
bevl_toks = (BEC_2_9_10_ContainerLinkedList) bevp_twtok.bem_tokenize_1(bevl_src);
if (bevp_printSteps.bevi_bool) /* Line: 604 */ {
bevt_11_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_27;
bevt_11_tmpany_phold.bem_echo_0();
} /* Line: 605 */
bevt_12_tmpany_phold = bevl_trans.bemd_0(-1380522583, BEX_E.bevn_outermostGet_0);
bem_nodify_2(bevt_12_tmpany_phold, bevl_toks);
if (bevp_printAllAst.bevi_bool) /* Line: 608 */ {
bevt_13_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_28;
bevt_13_tmpany_phold.bem_print_0();
bevt_14_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_14_tmpany_phold);
} /* Line: 610 */
if (bevp_printSteps.bevi_bool) /* Line: 613 */ {
bevt_15_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_29;
bevt_15_tmpany_phold.bem_echo_0();
} /* Line: 614 */
bevt_16_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass2) (new BEC_3_5_5_5_BuildVisitPass2());
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_16_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 617 */ {
bevt_17_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_30;
bevt_17_tmpany_phold.bem_print_0();
bevt_18_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_18_tmpany_phold);
} /* Line: 619 */
if (bevp_printSteps.bevi_bool) /* Line: 621 */ {
bevt_19_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_31;
bevt_19_tmpany_phold.bem_echo_0();
} /* Line: 622 */
bevt_20_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass3) (new BEC_3_5_5_5_BuildVisitPass3());
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_20_tmpany_phold);
bevl_trans.bemd_0(-410956923, BEX_E.bevn_contain_0);
if (bevp_printAllAst.bevi_bool) /* Line: 627 */ {
bevt_21_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_32;
bevt_21_tmpany_phold.bem_print_0();
bevt_22_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_22_tmpany_phold);
} /* Line: 629 */
if (bevp_printSteps.bevi_bool) /* Line: 632 */ {
bevt_23_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_33;
bevt_23_tmpany_phold.bem_echo_0();
} /* Line: 633 */
bevt_24_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass4) (new BEC_3_5_5_5_BuildVisitPass4());
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_24_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 636 */ {
bevt_25_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_34;
bevt_25_tmpany_phold.bem_print_0();
bevt_26_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_26_tmpany_phold);
} /* Line: 638 */
if (bevp_printSteps.bevi_bool) /* Line: 641 */ {
bevt_27_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_35;
bevt_27_tmpany_phold.bem_echo_0();
} /* Line: 642 */
bevt_28_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass5) (new BEC_3_5_5_5_BuildVisitPass5());
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_28_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 645 */ {
bevt_29_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_36;
bevt_29_tmpany_phold.bem_print_0();
bevt_30_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_30_tmpany_phold);
} /* Line: 647 */
if (bevp_printSteps.bevi_bool) /* Line: 650 */ {
bevt_31_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_37;
bevt_31_tmpany_phold.bem_echo_0();
} /* Line: 651 */
bevt_32_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass6) (new BEC_3_5_5_5_BuildVisitPass6());
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_32_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 654 */ {
bevt_33_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_38;
bevt_33_tmpany_phold.bem_print_0();
bevt_34_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_34_tmpany_phold);
} /* Line: 656 */
if (bevp_printSteps.bevi_bool) /* Line: 659 */ {
bevt_35_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_39;
bevt_35_tmpany_phold.bem_echo_0();
} /* Line: 660 */
bevt_36_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass7()).bem_new_0();
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_36_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 663 */ {
bevt_37_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_40;
bevt_37_tmpany_phold.bem_print_0();
bevt_38_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_38_tmpany_phold);
} /* Line: 665 */
if (bevp_printSteps.bevi_bool) /* Line: 668 */ {
bevt_39_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_41;
bevt_39_tmpany_phold.bem_echo_0();
} /* Line: 669 */
bevt_40_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass8) (new BEC_3_5_5_5_BuildVisitPass8());
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_40_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 672 */ {
bevt_41_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_42;
bevt_41_tmpany_phold.bem_print_0();
bevt_42_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_42_tmpany_phold);
} /* Line: 674 */
if (bevp_printSteps.bevi_bool) /* Line: 677 */ {
bevt_43_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_43;
bevt_43_tmpany_phold.bem_echo_0();
} /* Line: 678 */
bevt_44_tmpany_phold = (BEC_3_5_5_5_BuildVisitPass9) (new BEC_3_5_5_5_BuildVisitPass9());
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_44_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 681 */ {
bevt_45_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_44;
bevt_45_tmpany_phold.bem_print_0();
bevt_46_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_46_tmpany_phold);
} /* Line: 683 */
if (bevp_printSteps.bevi_bool) /* Line: 686 */ {
bevt_47_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_45;
bevt_47_tmpany_phold.bem_echo_0();
} /* Line: 687 */
bevt_48_tmpany_phold = (BEC_3_5_5_6_BuildVisitPass10) (new BEC_3_5_5_6_BuildVisitPass10());
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_48_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 690 */ {
bevt_49_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_46;
bevt_49_tmpany_phold.bem_print_0();
bevt_50_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_50_tmpany_phold);
} /* Line: 692 */
if (bevp_printSteps.bevi_bool) /* Line: 694 */ {
bevt_51_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_47;
bevt_51_tmpany_phold.bem_echo_0();
} /* Line: 695 */
bevt_52_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass11()).bem_new_0();
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_52_tmpany_phold);
if (bevp_printAllAst.bevi_bool) /* Line: 698 */ {
bevt_53_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_48;
bevt_53_tmpany_phold.bem_print_0();
bevt_54_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_54_tmpany_phold);
} /* Line: 700 */
if (bevp_printSteps.bevi_bool) /* Line: 703 */ {
bevt_55_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_49;
bevt_55_tmpany_phold.bem_echo_0();
bevt_56_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_50;
bevt_56_tmpany_phold.bem_print_0();
} /* Line: 705 */
bevt_57_tmpany_phold = (new BEC_3_5_5_6_BuildVisitPass12()).bem_new_0();
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_57_tmpany_phold);
if (bevp_printAst.bevi_bool) /* Line: 708 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 708 */ {
if (bevp_printAllAst.bevi_bool) /* Line: 708 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 708 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 708 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 708 */ {
bevt_58_tmpany_phold = bece_BEC_2_5_5_BuildBuild_bevo_51;
bevt_58_tmpany_phold.bem_print_0();
bevt_59_tmpany_phold = (new BEC_3_5_5_5_BuildVisitPass1()).bem_new_2(bevp_printAstElements, null);
bevl_trans.bemd_1(688372900, BEX_E.bevn_traverse_1, bevt_59_tmpany_phold);
} /* Line: 710 */
bevt_60_tmpany_phold = bevp_emitData.bem_classesGet_0();
bevl_ci = bevt_60_tmpany_phold.bem_valueIteratorGet_0();
while (true)
 /* Line: 712 */ {
bevt_61_tmpany_phold = bevl_ci.bemd_0(108485850, BEX_E.bevn_hasNextGet_0);
if (bevt_61_tmpany_phold != null && bevt_61_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_61_tmpany_phold).bevi_bool) /* Line: 712 */ {
bevl_clnode = bevl_ci.bemd_0(1194623572, BEX_E.bevn_nextGet_0);
bevl_tunode = bevl_clnode.bemd_0(-1973596005, BEX_E.bevn_transUnitGet_0);
bevl_ntunode = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_62_tmpany_phold = bevp_ntypes.bem_TRANSUNITGet_0();
bevl_ntunode.bemd_1(-2076598833, BEX_E.bevn_typenameSet_1, bevt_62_tmpany_phold);
bevl_ntt = (new BEC_2_5_9_BuildTransUnit()).bem_new_0();
bevt_64_tmpany_phold = bevl_tunode.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_63_tmpany_phold = bevt_64_tmpany_phold.bemd_0(-568286617, BEX_E.bevn_emitsGet_0);
bevl_ntt.bemd_1(-557204364, BEX_E.bevn_emitsSet_1, bevt_63_tmpany_phold);
bevl_ntunode.bemd_1(942322015, BEX_E.bevn_heldSet_1, bevl_ntt);
bevl_clnode.bemd_0(819712668, BEX_E.bevn_delete_0);
bevl_ntunode.bemd_1(2139839746, BEX_E.bevn_addValue_1, bevl_clnode);
bevl_ntunode.bemd_1(1487970429, BEX_E.bevn_copyLoc_1, bevl_clnode);
} /* Line: 723 */
 else  /* Line: 712 */ {
break;
} /* Line: 712 */
} /* Line: 712 */
} /* Line: 712 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nodify_2(BEC_2_6_6_SystemObject beva_parnode, BEC_2_9_10_ContainerLinkedList beva_toks) throws Throwable {
BEC_2_9_8_ContainerNodeList bevl_con = null;
BEC_2_4_3_MathInt bevl_nlc = null;
BEC_2_4_6_TextString bevl_cr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_node = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
beva_parnode.bemd_0(1461034369, BEX_E.bevn_reInitContained_0);
bevl_con = (BEC_2_9_8_ContainerNodeList) beva_parnode.bemd_0(432255188, BEX_E.bevn_containedGet_0);
bevl_nlc = (new BEC_2_4_3_MathInt(1));
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_cr = bevt_0_tmpany_phold.bem_crGet_0();
bevl_i = beva_toks.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 733 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (bevt_1_tmpany_phold != null && bevt_1_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 733 */ {
bevl_node = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_2_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_node.bemd_1(942322015, BEX_E.bevn_heldSet_1, bevt_2_tmpany_phold);
bevl_node.bemd_1(-1584180177, BEX_E.bevn_nlcSet_1, bevl_nlc);
bevt_4_tmpany_phold = bevl_node.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bemd_1(581408689, BEX_E.bevn_equals_1, bevp_nl);
if (bevt_3_tmpany_phold != null && bevt_3_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 737 */ {
bevl_nlc = bevl_nlc.bem_increment_0();
} /* Line: 738 */
bevt_6_tmpany_phold = bevl_node.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_5_tmpany_phold = bevt_6_tmpany_phold.bemd_1(1000416164, BEX_E.bevn_notEquals_1, bevl_cr);
if (bevt_5_tmpany_phold != null && bevt_5_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 740 */ {
bevl_con.bem_addValue_1(bevl_node);
bevl_node.bemd_1(844145555, BEX_E.bevn_containerSet_1, beva_parnode);
} /* Line: 742 */
} /* Line: 740 */
 else  /* Line: 733 */ {
break;
} /* Line: 733 */
} /* Line: 733 */
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildLiteral_2(BEC_2_6_6_SystemObject beva_node, BEC_2_6_6_SystemObject beva_tName) throws Throwable {
BEC_2_6_6_SystemObject bevl_nlnp = null;
BEC_2_6_6_SystemObject bevl_nlnpn = null;
BEC_2_6_6_SystemObject bevl_nlc = null;
BEC_2_6_6_SystemObject bevl_pn = null;
BEC_2_6_6_SystemObject bevl_pn2 = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_anchor = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_4_6_TextString bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_8_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_13_tmpany_phold = null;
BEC_2_4_6_TextString bevt_14_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_15_tmpany_phold = null;
BEC_2_4_6_TextString bevt_16_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_17_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_18_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_19_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_20_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_21_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_22_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_23_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_24_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_25_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_26_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_27_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_28_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_29_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_30_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_31_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_32_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_33_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_34_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_35_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_36_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_37_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_38_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_39_tmpany_phold = null;
bevl_nlnp = (new BEC_2_5_8_BuildNamePath()).bem_new_0();
bevl_nlnp.bemd_1(-630006451, BEX_E.bevn_fromString_1, beva_tName);
bevl_nlnpn = (new BEC_2_5_4_BuildNode()).bem_new_1(this);
bevt_5_tmpany_phold = bevp_ntypes.bem_NAMEPATHGet_0();
bevl_nlnpn.bemd_1(-2076598833, BEX_E.bevn_typenameSet_1, bevt_5_tmpany_phold);
bevl_nlnpn.bemd_1(942322015, BEX_E.bevn_heldSet_1, bevl_nlnp);
bevl_nlnpn.bemd_1(1487970429, BEX_E.bevn_copyLoc_1, beva_node);
bevl_nlc = (new BEC_2_5_4_BuildCall()).bem_new_0();
bevt_6_tmpany_phold = (new BEC_2_4_6_TextString(3, bece_BEC_2_5_5_BuildBuild_bels_112));
bevl_nlc.bemd_1(1222355913, BEX_E.bevn_nameSet_1, bevt_6_tmpany_phold);
bevt_7_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-724818817, BEX_E.bevn_wasBoundSet_1, bevt_7_tmpany_phold);
bevt_8_tmpany_phold = be.BECS_Runtime.boolFalse;
bevl_nlc.bemd_1(-1308209994, BEX_E.bevn_boundSet_1, bevt_8_tmpany_phold);
bevt_9_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(213400007, BEX_E.bevn_isConstructSet_1, bevt_9_tmpany_phold);
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
bevl_nlc.bemd_1(1580478063, BEX_E.bevn_isLiteralSet_1, bevt_10_tmpany_phold);
bevt_11_tmpany_phold = beva_node.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevl_nlc.bemd_1(1098588850, BEX_E.bevn_literalValueSet_1, bevt_11_tmpany_phold);
beva_node.bemd_1(2139839746, BEX_E.bevn_addValue_1, bevl_nlnpn);
bevt_12_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
beva_node.bemd_1(-2076598833, BEX_E.bevn_typenameSet_1, bevt_12_tmpany_phold);
beva_node.bemd_1(942322015, BEX_E.bevn_heldSet_1, bevl_nlc);
bevl_nlnpn.bemd_0(1952633087, BEX_E.bevn_resolveNp_0);
bevt_14_tmpany_phold = (new BEC_2_4_6_TextString(8, bece_BEC_2_5_5_BuildBuild_bels_113));
bevt_13_tmpany_phold = beva_tName.bemd_1(581408689, BEX_E.bevn_equals_1, bevt_14_tmpany_phold);
if (bevt_13_tmpany_phold != null && bevt_13_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_13_tmpany_phold).bevi_bool) /* Line: 772 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 772 */ {
bevt_16_tmpany_phold = (new BEC_2_4_6_TextString(10, bece_BEC_2_5_5_BuildBuild_bels_114));
bevt_15_tmpany_phold = beva_tName.bemd_1(581408689, BEX_E.bevn_equals_1, bevt_16_tmpany_phold);
if (bevt_15_tmpany_phold != null && bevt_15_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_15_tmpany_phold).bevi_bool) /* Line: 772 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 772 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 772 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 772 */ {
bevl_pn = beva_node.bemd_0(2110470555, BEX_E.bevn_priorPeerGet_0);
if (bevl_pn == null) {
bevt_17_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_17_tmpany_phold.bevi_bool) /* Line: 774 */ {
bevt_19_tmpany_phold = bevl_pn.bemd_0(-2087681086, BEX_E.bevn_typenameGet_0);
bevt_20_tmpany_phold = bevp_ntypes.bem_SUBTRACTGet_0();
bevt_18_tmpany_phold = bevt_19_tmpany_phold.bemd_1(581408689, BEX_E.bevn_equals_1, bevt_20_tmpany_phold);
if (bevt_18_tmpany_phold != null && bevt_18_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_18_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_22_tmpany_phold = bevl_pn.bemd_0(-2087681086, BEX_E.bevn_typenameGet_0);
bevt_23_tmpany_phold = bevp_ntypes.bem_ADDGet_0();
bevt_21_tmpany_phold = bevt_22_tmpany_phold.bemd_1(581408689, BEX_E.bevn_equals_1, bevt_23_tmpany_phold);
if (bevt_21_tmpany_phold != null && bevt_21_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_21_tmpany_phold).bevi_bool) /* Line: 774 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 774 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 774 */
 else  /* Line: 774 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 774 */ {
bevl_pn2 = bevl_pn.bemd_0(2110470555, BEX_E.bevn_priorPeerGet_0);
if (bevl_pn2 == null) {
bevt_24_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_24_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_24_tmpany_phold.bevi_bool) /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_26_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEX_E.bevn_typenameGet_0);
bevt_27_tmpany_phold = bevp_ntypes.bem_CALLGet_0();
bevt_25_tmpany_phold = bevt_26_tmpany_phold.bemd_1(1000416164, BEX_E.bevn_notEquals_1, bevt_27_tmpany_phold);
if (bevt_25_tmpany_phold != null && bevt_25_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_25_tmpany_phold).bevi_bool) /* Line: 776 */ {
bevt_29_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEX_E.bevn_typenameGet_0);
bevt_30_tmpany_phold = bevp_ntypes.bem_IDGet_0();
bevt_28_tmpany_phold = bevt_29_tmpany_phold.bemd_1(1000416164, BEX_E.bevn_notEquals_1, bevt_30_tmpany_phold);
if (bevt_28_tmpany_phold != null && bevt_28_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_28_tmpany_phold).bevi_bool) /* Line: 776 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
 else  /* Line: 776 */ {
bevt_4_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_4_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_32_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEX_E.bevn_typenameGet_0);
bevt_33_tmpany_phold = bevp_ntypes.bem_VARGet_0();
bevt_31_tmpany_phold = bevt_32_tmpany_phold.bemd_1(1000416164, BEX_E.bevn_notEquals_1, bevt_33_tmpany_phold);
if (bevt_31_tmpany_phold != null && bevt_31_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_31_tmpany_phold).bevi_bool) /* Line: 776 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
 else  /* Line: 776 */ {
bevt_3_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_3_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_35_tmpany_phold = bevl_pn2.bemd_0(-2087681086, BEX_E.bevn_typenameGet_0);
bevt_36_tmpany_phold = bevp_ntypes.bem_ACCESSORGet_0();
bevt_34_tmpany_phold = bevt_35_tmpany_phold.bemd_1(1000416164, BEX_E.bevn_notEquals_1, bevt_36_tmpany_phold);
if (bevt_34_tmpany_phold != null && bevt_34_tmpany_phold instanceof BEC_2_5_4_LogicBool && ((BEC_2_5_4_LogicBool) bevt_34_tmpany_phold).bevi_bool) /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
 else  /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 776 */ {
bevt_2_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 776 */
if (bevt_2_tmpany_anchor.bevi_bool) /* Line: 776 */ {
bevt_38_tmpany_phold = bevl_pn.bemd_0(931239762, BEX_E.bevn_heldGet_0);
bevt_39_tmpany_phold = bevl_nlc.bemd_0(1087506597, BEX_E.bevn_literalValueGet_0);
bevt_37_tmpany_phold = bevt_38_tmpany_phold.bemd_1(92659731, BEX_E.bevn_add_1, bevt_39_tmpany_phold);
bevl_nlc.bemd_1(1098588850, BEX_E.bevn_literalValueSet_1, bevt_37_tmpany_phold);
bevl_pn.bemd_0(819712668, BEX_E.bevn_delete_0);
} /* Line: 783 */
} /* Line: 776 */
} /* Line: 774 */
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_mainNameGet_0() throws Throwable {
return bevp_mainName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_mainNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_mainName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_libNameGet_0() throws Throwable {
return bevp_libName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_libNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_libName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_exeNameGet_0() throws Throwable {
return bevp_exeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_exeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_exeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitFileHeaderGet_0() throws Throwable {
return bevp_emitFileHeader;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFileHeaderSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFileHeader = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extIncludesGet_0() throws Throwable {
return bevp_extIncludes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extIncludesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extIncludes = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_ccObjArgsGet_0() throws Throwable {
return bevp_ccObjArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ccObjArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ccObjArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLibsGet_0() throws Throwable {
return bevp_extLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_linkLibArgsGet_0() throws Throwable {
return bevp_linkLibArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_linkLibArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_linkLibArgs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_extLinkObjectsGet_0() throws Throwable {
return bevp_extLinkObjects;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_extLinkObjectsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_extLinkObjects = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fromFileGet_0() throws Throwable {
return bevp_fromFile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_fromFileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_fromFile = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_platform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_outputPlatformGet_0() throws Throwable {
return bevp_outputPlatform;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_outputPlatformSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_outputPlatform = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_emitLibraryGet_0() throws Throwable {
return bevp_emitLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLibrary = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_usedLibrarysStrGet_0() throws Throwable {
return bevp_usedLibrarysStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarysStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_closeLibrariesStrGet_0() throws Throwable {
return bevp_closeLibrariesStr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesStrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibrariesStr = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesFromGet_0() throws Throwable {
return bevp_deployFilesFrom;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesFromSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesFrom = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_deployFilesToGet_0() throws Throwable {
return bevp_deployFilesTo;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployFilesToSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployFilesTo = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nlGet_0() throws Throwable {
return bevp_nl;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_nlSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_nl = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_newlineGet_0() throws Throwable {
return bevp_newline;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_newlineSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_newline = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_runArgsGet_0() throws Throwable {
return bevp_runArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_runArgs = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_15_BuildCompilerProfile bem_compilerProfileGet_0() throws Throwable {
return bevp_compilerProfile;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerProfileSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compilerProfile = (BEC_2_5_15_BuildCompilerProfile) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_10_SystemParameters bem_paramsGet_0() throws Throwable {
return bevp_params;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_paramsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_params = (BEC_2_6_10_SystemParameters) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_buildSucceededGet_0() throws Throwable {
return bevp_buildSucceeded;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildSucceededSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildSucceeded = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_buildMessageGet_0() throws Throwable {
return bevp_buildMessage;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildMessageSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildMessage = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_startTimeGet_0() throws Throwable {
return bevp_startTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_startTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_startTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseTimeGet_0() throws Throwable {
return bevp_parseTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitTimeGet_0() throws Throwable {
return bevp_parseEmitTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_8_TimeInterval bem_parseEmitCompileTimeGet_0() throws Throwable {
return bevp_parseEmitCompileTime;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseEmitCompileTimeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parseEmitCompileTime = (BEC_2_4_8_TimeInterval) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_buildPathGet_0() throws Throwable {
return bevp_buildPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_buildPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_includePathGet_0() throws Throwable {
return bevp_includePath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_includePathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_includePath = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_builtGet_0() throws Throwable {
return bevp_built;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_builtSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_built = (BEC_2_9_3_ContainerMap) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_toBuildGet_0() throws Throwable {
return bevp_toBuild;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_toBuildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_toBuild = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printStepsGet_0() throws Throwable {
return bevp_printSteps;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printStepsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printSteps = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printPlacesGet_0() throws Throwable {
return bevp_printPlaces;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printPlacesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printPlaces = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAstGet_0() throws Throwable {
return bevp_printAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_printAllAstGet_0() throws Throwable {
return bevp_printAllAst;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAllAstSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAllAst = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_printAstElementsGet_0() throws Throwable {
return bevp_printAstElements;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_printAstElementsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_printAstElements = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_doEmitGet_0() throws Throwable {
return bevp_doEmit;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_doEmitSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_doEmit = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_emitDebugGet_0() throws Throwable {
return bevp_emitDebug;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDebugSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitDebug = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_parseGet_0() throws Throwable {
return bevp_parse;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_parseSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_parse = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_prepMakeGet_0() throws Throwable {
return bevp_prepMake;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_prepMakeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_prepMake = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_makeGet_0() throws Throwable {
return bevp_make;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_make = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_genOnlyGet_0() throws Throwable {
return bevp_genOnly;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_genOnlySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_genOnly = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_deployUsedLibrariesGet_0() throws Throwable {
return bevp_deployUsedLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployUsedLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployUsedLibraries = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildEmitData bem_emitDataGet_0() throws Throwable {
return bevp_emitData;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitDataSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitData = (BEC_2_5_8_BuildEmitData) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_emitPathGet_0() throws Throwable {
return bevp_emitPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitPath = (BEC_3_2_4_4_IOFilePath) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_codeGet_0() throws Throwable {
return bevp_code;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_codeSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_code = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_estrGet_0() throws Throwable {
return bevp_estr;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_estrSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_estr = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_sharedEmitterGet_0() throws Throwable {
return bevp_sharedEmitter;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_sharedEmitterSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_sharedEmitter = bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constantsGet_0() throws Throwable {
return bevp_constants;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_constantsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_constants = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_twtokGet_0() throws Throwable {
return bevp_twtok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_twtokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_twtok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_lctokGet_0() throws Throwable {
return bevp_lctok;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_lctokSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_lctok = (BEC_2_4_9_TextTokenizer) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_7_BuildLibrary bem_deployLibraryGet_0() throws Throwable {
return bevp_deployLibrary;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployLibrarySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployLibrary = (BEC_2_5_7_BuildLibrary) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_deployPathGet_0() throws Throwable {
return bevp_deployPath;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_deployPathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_deployPath = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_usedLibrarysGet_0() throws Throwable {
return bevp_usedLibrarys;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_usedLibrarysSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_usedLibrarys = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_3_ContainerSet bem_closeLibrariesGet_0() throws Throwable {
return bevp_closeLibraries;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_closeLibrariesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_closeLibraries = (BEC_2_9_3_ContainerSet) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_runGet_0() throws Throwable {
return bevp_run;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_runSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_run = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_compilerGet_0() throws Throwable {
return bevp_compiler;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_compilerSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_compiler = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitLangsGet_0() throws Throwable {
return bevp_emitLangs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitLangsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitLangs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_emitFlagsGet_0() throws Throwable {
return bevp_emitFlags;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitFlagsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitFlags = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeNameGet_0() throws Throwable {
return bevp_makeName;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeNameSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeName = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_makeArgsGet_0() throws Throwable {
return bevp_makeArgs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_makeArgsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_makeArgs = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_putLineNumbersInTraceGet_0() throws Throwable {
return bevp_putLineNumbersInTrace;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_putLineNumbersInTraceSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_putLineNumbersInTrace = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_dynConditionsAllGet_0() throws Throwable {
return bevp_dynConditionsAll;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_dynConditionsAllSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_dynConditionsAll = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_ownProcessGet_0() throws Throwable {
return bevp_ownProcess;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_ownProcessSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ownProcess = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_saveSynsGet_0() throws Throwable {
return bevp_saveSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_saveSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_saveSyns = (BEC_2_5_4_LogicBool) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_readBufferGet_0() throws Throwable {
return bevp_readBuffer;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_readBufferSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_readBuffer = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_loadSynsGet_0() throws Throwable {
return bevp_loadSyns;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_loadSynsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_loadSyns = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_initLibsGet_0() throws Throwable {
return bevp_initLibs;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_initLibsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_initLibs = (BEC_2_9_10_ContainerLinkedList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_emitCommonSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_emitCommon = (BEC_2_5_10_BuildEmitCommon) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {51, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 68, 70, 71, 72, 73, 73, 76, 79, 80, 86, 87, 88, 89, 90, 90, 97, 97, 97, 97, 0, 97, 97, 0, 0, 0, 0, 0, 98, 98, 100, 100, 104, 104, 104, 104, 108, 108, 109, 109, 109, 113, 114, 115, 115, 115, 115, 115, 116, 116, 116, 117, 116, 119, 123, 124, 125, 127, 128, 129, 131, 132, 133, 133, 134, 0, 0, 0, 137, 139, 143, 143, 143, 145, 150, 152, 153, 153, 153, 154, 154, 0, 154, 154, 155, 155, 155, 156, 157, 157, 162, 162, 162, 162, 163, 165, 165, 165, 166, 166, 167, 167, 167, 169, 171, 171, 171, 171, 171, 171, 172, 173, 173, 174, 174, 174, 174, 174, 174, 175, 175, 175, 175, 175, 175, 176, 176, 176, 176, 176, 177, 177, 177, 177, 177, 178, 178, 178, 178, 178, 179, 179, 179, 179, 179, 180, 180, 181, 181, 183, 183, 183, 184, 184, 184, 185, 185, 186, 186, 187, 189, 189, 190, 190, 191, 193, 193, 194, 194, 195, 197, 197, 198, 198, 199, 201, 201, 202, 202, 203, 205, 205, 206, 206, 207, 209, 209, 210, 210, 211, 213, 213, 214, 214, 215, 217, 217, 218, 218, 219, 221, 221, 222, 222, 223, 225, 225, 226, 226, 227, 229, 231, 231, 231, 232, 232, 232, 233, 233, 234, 234, 235, 236, 236, 237, 237, 237, 237, 237, 0, 0, 0, 238, 0, 238, 238, 239, 242, 242, 243, 243, 244, 244, 245, 245, 245, 246, 246, 247, 247, 248, 248, 248, 248, 249, 249, 249, 249, 250, 250, 250, 250, 250, 251, 252, 253, 254, 255, 258, 258, 259, 261, 268, 268, 268, 268, 268, 269, 269, 270, 270, 273, 273, 273, 274, 274, 275, 275, 278, 279, 279, 0, 279, 279, 280, 280, 282, 283, 284, 286, 287, 287, 287, 287, 288, 288, 290, 290, 291, 291, 292, 292, 293, 299, 300, 300, 300, 300, 300, 301, 301, 301, 301, 301, 302, 306, 307, 307, 307, 308, 309, 309, 309, 309, 310, 310, 310, 310, 311, 311, 311, 311, 311, 312, 312, 313, 0, 313, 313, 314, 317, 317, 317, 317, 317, 318, 318, 319, 0, 319, 319, 320, 325, 325, 325, 326, 327, 327, 327, 327, 327, 327, 334, 334, 338, 338, 339, 344, 344, 345, 346, 346, 347, 348, 348, 349, 350, 350, 351, 352, 352, 353, 355, 355, 355, 357, 358, 360, 364, 366, 366, 366, 367, 367, 368, 368, 368, 369, 369, 370, 371, 371, 372, 372, 372, 373, 373, 373, 379, 379, 380, 381, 381, 382, 0, 382, 382, 383, 386, 387, 387, 388, 389, 391, 391, 391, 394, 396, 0, 396, 396, 397, 397, 397, 398, 399, 400, 403, 0, 403, 403, 404, 404, 404, 405, 406, 407, 408, 408, 413, 414, 414, 415, 417, 417, 418, 418, 419, 422, 425, 425, 425, 428, 428, 428, 430, 430, 431, 431, 432, 432, 432, 433, 433, 433, 434, 434, 434, 435, 435, 435, 436, 436, 436, 437, 437, 440, 441, 443, 443, 443, 444, 445, 447, 448, 449, 449, 449, 450, 451, 455, 455, 455, 456, 456, 457, 457, 457, 459, 459, 459, 462, 466, 466, 467, 468, 470, 0, 470, 470, 471, 471, 472, 472, 473, 473, 473, 474, 474, 475, 475, 477, 477, 477, 478, 478, 478, 482, 483, 485, 485, 0, 0, 0, 486, 486, 487, 487, 487, 487, 487, 487, 487, 487, 489, 489, 490, 490, 492, 492, 492, 493, 493, 493, 498, 498, 498, 500, 500, 501, 501, 501, 503, 503, 504, 504, 504, 506, 506, 507, 507, 507, 511, 511, 512, 513, 513, 513, 513, 513, 514, 516, 516, 520, 520, 520, 521, 522, 522, 523, 524, 526, 526, 526, 527, 528, 528, 529, 530, 532, 532, 536, 536, 536, 536, 537, 537, 537, 539, 539, 540, 540, 540, 540, 541, 543, 543, 543, 543, 543, 545, 545, 546, 546, 547, 551, 551, 551, 553, 555, 555, 556, 556, 556, 556, 557, 561, 562, 562, 563, 563, 564, 570, 570, 571, 572, 579, 579, 580, 582, 587, 588, 589, 590, 591, 592, 592, 0, 0, 0, 595, 595, 595, 595, 597, 599, 599, 599, 599, 600, 600, 600, 601, 605, 605, 607, 607, 609, 609, 610, 610, 614, 614, 616, 616, 618, 618, 619, 619, 622, 622, 625, 625, 626, 628, 628, 629, 629, 633, 633, 635, 635, 637, 637, 638, 638, 642, 642, 644, 644, 646, 646, 647, 647, 651, 651, 653, 653, 655, 655, 656, 656, 660, 660, 662, 662, 664, 664, 665, 665, 669, 669, 671, 671, 673, 673, 674, 674, 678, 678, 680, 680, 682, 682, 683, 683, 687, 687, 689, 689, 691, 691, 692, 692, 695, 695, 697, 697, 699, 699, 700, 700, 704, 704, 705, 705, 707, 707, 0, 0, 0, 709, 709, 710, 710, 712, 712, 712, 713, 715, 716, 717, 717, 718, 719, 719, 719, 720, 721, 722, 723, 729, 730, 731, 732, 732, 733, 733, 734, 735, 735, 736, 737, 737, 738, 740, 740, 741, 742, 749, 750, 752, 753, 753, 754, 755, 757, 758, 758, 759, 759, 760, 760, 761, 761, 762, 762, 763, 763, 765, 767, 767, 768, 770, 772, 772, 0, 772, 772, 0, 0, 773, 774, 774, 774, 774, 774, 0, 774, 774, 774, 0, 0, 0, 0, 0, 775, 776, 776, 0, 776, 776, 776, 776, 776, 776, 0, 0, 0, 776, 776, 776, 0, 0, 0, 776, 776, 776, 0, 0, 0, 0, 0, 782, 782, 782, 782, 783, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 288, 293, 294, 295, 297, 300, 301, 303, 306, 310, 313, 317, 320, 321, 323, 324, 330, 331, 332, 333, 340, 341, 342, 343, 344, 356, 357, 358, 359, 360, 361, 362, 363, 366, 371, 372, 373, 379, 387, 388, 389, 391, 392, 393, 397, 398, 399, 400, 401, 404, 408, 411, 415, 417, 423, 424, 425, 428, 570, 571, 572, 573, 578, 579, 580, 580, 583, 585, 586, 587, 592, 593, 594, 595, 603, 604, 605, 606, 608, 610, 611, 612, 613, 614, 616, 617, 618, 621, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 681, 682, 684, 685, 686, 691, 692, 694, 695, 696, 701, 702, 704, 705, 706, 711, 712, 714, 715, 716, 721, 722, 724, 725, 726, 731, 732, 734, 735, 736, 741, 742, 744, 745, 746, 751, 752, 754, 755, 756, 761, 762, 764, 765, 766, 771, 772, 774, 775, 776, 781, 782, 785, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 805, 806, 807, 812, 813, 816, 820, 823, 823, 826, 828, 829, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 872, 873, 876, 878, 879, 880, 881, 882, 883, 888, 889, 890, 892, 893, 894, 895, 900, 901, 902, 904, 905, 906, 906, 909, 911, 912, 913, 919, 920, 921, 922, 923, 924, 925, 930, 931, 932, 934, 939, 940, 941, 942, 943, 944, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 1009, 1010, 1011, 1014, 1016, 1017, 1018, 1019, 1020, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1036, 1037, 1037, 1040, 1042, 1043, 1050, 1051, 1052, 1053, 1054, 1055, 1060, 1061, 1061, 1064, 1066, 1067, 1080, 1081, 1084, 1086, 1087, 1088, 1089, 1090, 1091, 1092, 1102, 1103, 1119, 1124, 1125, 1127, 1132, 1133, 1134, 1135, 1137, 1140, 1141, 1143, 1146, 1147, 1149, 1152, 1153, 1155, 1158, 1159, 1160, 1165, 1166, 1168, 1187, 1188, 1189, 1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206, 1327, 1328, 1329, 1330, 1335, 1336, 1336, 1339, 1341, 1342, 1349, 1350, 1355, 1356, 1357, 1359, 1360, 1361, 1364, 1365, 1365, 1368, 1370, 1371, 1372, 1377, 1378, 1379, 1380, 1387, 1387, 1390, 1392, 1393, 1394, 1399, 1400, 1401, 1402, 1403, 1404, 1412, 1413, 1416, 1418, 1419, 1420, 1422, 1423, 1424, 1431, 1433, 1434, 1435, 1436, 1437, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462, 1463, 1466, 1467, 1468, 1469, 1472, 1474, 1475, 1481, 1482, 1483, 1484, 1487, 1489, 1490, 1497, 1498, 1499, 1500, 1505, 1506, 1507, 1508, 1510, 1511, 1512, 1514, 1517, 1522, 1523, 1524, 1526, 1526, 1529, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1542, 1543, 1545, 1546, 1547, 1549, 1550, 1551, 1559, 1560, 1563, 1565, 1567, 1570, 1574, 1577, 1578, 1579, 1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1590, 1591, 1593, 1594, 1595, 1597, 1598, 1599, 1608, 1609, 1610, 1611, 1616, 1617, 1618, 1619, 1621, 1626, 1627, 1628, 1629, 1631, 1636, 1637, 1638, 1639, 1642, 1643, 1644, 1645, 1646, 1647, 1648, 1649, 1650, 1652, 1653, 1666, 1667, 1670, 1672, 1673, 1674, 1675, 1676, 1682, 1683, 1686, 1688, 1689, 1690, 1691, 1692, 1698, 1699, 1727, 1728, 1729, 1734, 1735, 1736, 1737, 1739, 1740, 1741, 1742, 1743, 1748, 1749, 1752, 1753, 1754, 1755, 1756, 1757, 1762, 1763, 1764, 1765, 1768, 1769, 1770, 1772, 1774, 1775, 1776, 1777, 1778, 1779, 1780, 1788, 1789, 1790, 1791, 1796, 1797, 1799, 1800, 1801, 1802, 1806, 1811, 1812, 1814, 1893, 1894, 1895, 1896, 1897, 1898, 1899, 1902, 1906, 1909, 1913, 1914, 1915, 1916, 1918, 1919, 1920, 1921, 1922, 1923, 1924, 1925, 1926, 1928, 1929, 1931, 1932, 1934, 1935, 1936, 1937, 1940, 1941, 1943, 1944, 1946, 1947, 1948, 1949, 1952, 1953, 1955, 1956, 1957, 1959, 1960, 1961, 1962, 1965, 1966, 1968, 1969, 1971, 1972, 1973, 1974, 1977, 1978, 1980, 1981, 1983, 1984, 1985, 1986, 1989, 1990, 1992, 1993, 1995, 1996, 1997, 1998, 2001, 2002, 2004, 2005, 2007, 2008, 2009, 2010, 2013, 2014, 2016, 2017, 2019, 2020, 2021, 2022, 2025, 2026, 2028, 2029, 2031, 2032, 2033, 2034, 2037, 2038, 2040, 2041, 2043, 2044, 2045, 2046, 2049, 2050, 2052, 2053, 2055, 2056, 2057, 2058, 2061, 2062, 2063, 2064, 2066, 2067, 2069, 2073, 2076, 2080, 2081, 2082, 2083, 2085, 2086, 2089, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2101, 2102, 2103, 2125, 2126, 2127, 2128, 2129, 2130, 2133, 2135, 2136, 2137, 2138, 2139, 2140, 2142, 2144, 2145, 2147, 2148, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2231, 2234, 2235, 2237, 2240, 2244, 2245, 2250, 2251, 2252, 2253, 2255, 2258, 2259, 2260, 2262, 2265, 2269, 2272, 2276, 2279, 2280, 2285, 2286, 2289, 2290, 2291, 2293, 2294, 2295, 2297, 2300, 2304, 2307, 2308, 2309, 2311, 2314, 2318, 2321, 2322, 2323, 2325, 2328, 2332, 2335, 2338, 2342, 2343, 2344, 2345, 2346, 2353, 2356, 2360, 2363, 2367, 2370, 2374, 2377, 2381, 2384, 2388, 2391, 2395, 2398, 2402, 2405, 2409, 2412, 2416, 2419, 2423, 2426, 2430, 2433, 2437, 2440, 2444, 2447, 2451, 2454, 2458, 2461, 2465, 2468, 2472, 2475, 2479, 2482, 2486, 2489, 2493, 2496, 2500, 2503, 2507, 2510, 2514, 2517, 2521, 2524, 2528, 2531, 2535, 2538, 2542, 2545, 2549, 2552, 2556, 2559, 2563, 2566, 2570, 2573, 2577, 2580, 2584, 2587, 2591, 2594, 2598, 2601, 2605, 2608, 2612, 2615, 2619, 2622, 2626, 2629, 2633, 2636, 2640, 2643, 2647, 2650, 2654, 2657, 2661, 2664, 2668, 2671, 2675, 2678, 2682, 2685, 2689, 2692, 2696, 2699, 2703, 2706, 2710, 2713, 2717, 2720, 2724, 2727, 2731, 2734, 2738, 2741, 2745, 2748, 2752, 2755, 2759, 2762, 2766, 2769, 2773, 2776, 2780, 2783, 2787, 2790, 2794, 2797, 2801, 2804, 2808, 2811, 2815, 2818, 2822, 2825, 2829, 2832, 2836, 2839, 2843, 2846, 2850};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 51 250
new 0 51 250
assign 1 53 251
new 0 53 251
assign 1 54 252
new 0 54 252
assign 1 55 253
new 0 55 253
assign 1 56 254
new 0 56 254
assign 1 58 255
new 0 58 255
assign 1 59 256
new 0 59 256
assign 1 60 257
new 0 60 257
assign 1 61 258
new 0 61 258
assign 1 62 259
new 0 62 259
assign 1 63 260
new 0 63 260
assign 1 64 261
new 0 64 261
assign 1 68 262
new 0 68 262
assign 1 70 263
new 1 70 263
assign 1 71 264
ntypesGet 0 71 264
assign 1 72 265
twtokGet 0 72 265
assign 1 73 266
new 0 73 266
assign 1 73 267
new 1 73 267
assign 1 76 268
new 0 76 268
assign 1 79 269
new 0 79 269
assign 1 80 270
new 0 80 270
assign 1 86 271
new 0 86 271
assign 1 87 272
new 0 87 272
assign 1 88 273
new 0 88 273
assign 1 89 274
new 0 89 274
assign 1 90 275
new 0 90 275
assign 1 90 276
new 1 90 276
assign 1 97 288
def 1 97 293
assign 1 97 294
new 0 97 294
assign 1 97 295
equals 1 97 295
assign 1 0 297
assign 1 97 300
new 0 97 300
assign 1 97 301
ends 1 97 301
assign 1 0 303
assign 1 0 306
assign 1 0 310
assign 1 0 313
assign 1 0 317
assign 1 98 320
new 0 98 320
return 1 98 321
assign 1 100 323
new 0 100 323
return 1 100 324
assign 1 104 330
new 0 104 330
assign 1 104 331
new 0 104 331
assign 1 104 332
swap 2 104 332
return 1 104 333
assign 1 108 340
new 0 108 340
assign 1 108 341
argsGet 0 108 341
assign 1 109 342
new 0 109 342
assign 1 109 343
main 1 109 343
exit 1 109 344
assign 1 113 356
assign 1 114 357
new 1 114 357
assign 1 115 358
new 0 115 358
assign 1 115 359
new 0 115 359
assign 1 115 360
get 2 115 360
assign 1 115 361
firstGet 0 115 361
assign 1 115 362
new 1 115 362
assign 1 116 363
new 0 116 363
assign 1 116 366
lesser 1 116 371
assign 1 117 372
go 0 117 372
incrementValue 0 116 373
return 1 119 379
assign 1 123 387
new 0 123 387
config 0 124 388
assign 1 125 389
new 0 125 389
assign 1 127 391
new 0 127 391
assign 1 128 392
doWhat 0 128 392
assign 1 129 393
new 0 129 393
assign 1 131 397
toString 0 131 397
assign 1 132 398
new 0 132 398
assign 1 133 399
new 0 133 399
assign 1 133 400
add 1 133 400
assign 1 134 401
new 0 134 401
assign 1 0 404
assign 1 0 408
assign 1 0 411
print 0 137 415
return 1 139 417
assign 1 143 423
nameGet 0 143 423
assign 1 143 424
new 0 143 424
assign 1 143 425
equals 1 143 425
return 1 145 428
assign 1 150 570
new 0 150 570
assign 1 152 571
new 0 152 571
assign 1 153 572
get 1 153 572
assign 1 153 573
def 1 153 578
assign 1 154 579
get 1 154 579
assign 1 154 580
iteratorGet 0 0 580
assign 1 154 583
hasNextGet 0 154 583
assign 1 154 585
nextGet 0 154 585
assign 1 155 586
has 1 155 586
assign 1 155 587
not 0 155 592
put 1 156 593
assign 1 157 594
new 1 157 594
addFile 1 157 595
assign 1 162 603
new 0 162 603
assign 1 162 604
nameGet 0 162 604
assign 1 162 605
new 0 162 605
assign 1 162 606
equals 1 162 606
preProcessorSet 1 163 608
assign 1 165 610
new 0 165 610
assign 1 165 611
get 1 165 611
assign 1 165 612
firstGet 0 165 612
assign 1 166 613
new 0 166 613
assign 1 166 614
has 1 166 614
assign 1 167 616
new 0 167 616
assign 1 167 617
get 1 167 617
assign 1 167 618
firstGet 0 167 618
assign 1 169 621
assign 1 171 623
new 0 171 623
assign 1 171 624
new 0 171 624
assign 1 171 625
get 2 171 625
assign 1 171 626
firstGet 0 171 626
assign 1 171 627
new 1 171 627
assign 1 171 628
pathGet 0 171 628
addStep 1 172 629
assign 1 173 630
new 0 173 630
addStep 1 173 631
assign 1 174 632
new 0 174 632
assign 1 174 633
new 0 174 633
assign 1 174 634
get 2 174 634
assign 1 174 635
firstGet 0 174 635
assign 1 174 636
new 1 174 636
assign 1 174 637
pathGet 0 174 637
assign 1 175 638
new 0 175 638
assign 1 175 639
new 0 175 639
assign 1 175 640
nameGet 0 175 640
assign 1 175 641
get 2 175 641
assign 1 175 642
firstGet 0 175 642
assign 1 175 643
new 1 175 643
assign 1 176 644
new 0 176 644
assign 1 176 645
nameGet 0 176 645
assign 1 176 646
get 2 176 646
assign 1 176 647
firstGet 0 176 647
assign 1 176 648
new 1 176 648
assign 1 177 649
new 0 177 649
assign 1 177 650
new 0 177 650
assign 1 177 651
get 2 177 651
assign 1 177 652
firstGet 0 177 652
assign 1 177 653
new 1 177 653
assign 1 178 654
new 0 178 654
assign 1 178 655
new 0 178 655
assign 1 178 656
get 2 178 656
assign 1 178 657
firstGet 0 178 657
assign 1 178 658
new 1 178 658
assign 1 179 659
new 0 179 659
assign 1 179 660
new 0 179 660
assign 1 179 661
get 2 179 661
assign 1 179 662
firstGet 0 179 662
assign 1 179 663
new 1 179 663
assign 1 180 664
new 0 180 664
assign 1 180 665
get 1 180 665
assign 1 181 666
new 0 181 666
assign 1 181 667
get 1 181 667
assign 1 183 668
new 0 183 668
assign 1 183 669
get 1 183 669
assign 1 183 670
firstGet 0 183 670
assign 1 184 671
new 0 184 671
assign 1 184 672
get 1 184 672
assign 1 184 673
firstGet 0 184 673
assign 1 185 674
new 0 185 674
assign 1 185 675
get 1 185 675
assign 1 186 676
undef 1 186 681
assign 1 187 682
new 0 187 682
assign 1 189 684
new 0 189 684
assign 1 189 685
get 1 189 685
assign 1 190 686
undef 1 190 691
assign 1 191 692
new 0 191 692
assign 1 193 694
new 0 193 694
assign 1 193 695
get 1 193 695
assign 1 194 696
undef 1 194 701
assign 1 195 702
new 0 195 702
assign 1 197 704
new 0 197 704
assign 1 197 705
get 1 197 705
assign 1 198 706
undef 1 198 711
assign 1 199 712
new 0 199 712
assign 1 201 714
new 0 201 714
assign 1 201 715
get 1 201 715
assign 1 202 716
undef 1 202 721
assign 1 203 722
new 0 203 722
assign 1 205 724
new 0 205 724
assign 1 205 725
get 1 205 725
assign 1 206 726
undef 1 206 731
assign 1 207 732
new 0 207 732
assign 1 209 734
new 0 209 734
assign 1 209 735
get 1 209 735
assign 1 210 736
undef 1 210 741
assign 1 211 742
new 0 211 742
assign 1 213 744
new 0 213 744
assign 1 213 745
get 1 213 745
assign 1 214 746
undef 1 214 751
assign 1 215 752
new 0 215 752
assign 1 217 754
new 0 217 754
assign 1 217 755
get 1 217 755
assign 1 218 756
undef 1 218 761
assign 1 219 762
new 0 219 762
assign 1 221 764
new 0 221 764
assign 1 221 765
get 1 221 765
assign 1 222 766
def 1 222 771
assign 1 223 772
firstGet 0 223 772
assign 1 225 774
new 0 225 774
assign 1 225 775
get 1 225 775
assign 1 226 776
def 1 226 781
assign 1 227 782
firstGet 0 227 782
assign 1 229 785
new 0 229 785
assign 1 231 787
new 0 231 787
assign 1 231 788
new 0 231 788
assign 1 231 789
isTrue 2 231 789
assign 1 232 790
new 0 232 790
assign 1 232 791
new 0 232 791
assign 1 232 792
isTrue 2 232 792
assign 1 233 793
new 0 233 793
assign 1 233 794
isTrue 1 233 794
assign 1 234 795
new 0 234 795
assign 1 234 796
isTrue 1 234 796
assign 1 235 797
new 0 235 797
assign 1 236 798
new 0 236 798
assign 1 236 799
get 1 236 799
assign 1 237 800
def 1 237 805
assign 1 237 806
isEmptyGet 0 237 806
assign 1 237 807
not 0 237 812
assign 1 0 813
assign 1 0 816
assign 1 0 820
assign 1 238 823
linkedListIteratorGet 0 0 823
assign 1 238 826
hasNextGet 0 238 826
assign 1 238 828
nextGet 0 238 828
put 1 239 829
assign 1 242 836
new 0 242 836
assign 1 242 837
isTrue 1 242 837
assign 1 243 838
new 0 243 838
assign 1 243 839
isTrue 1 243 839
assign 1 244 840
new 0 244 840
assign 1 244 841
isTrue 1 244 841
assign 1 245 842
new 0 245 842
assign 1 245 843
new 0 245 843
assign 1 245 844
isTrue 2 245 844
assign 1 246 845
new 0 246 845
assign 1 246 846
get 1 246 846
assign 1 247 847
new 0 247 847
assign 1 247 848
get 1 247 848
assign 1 248 849
new 0 248 849
assign 1 248 850
new 0 248 850
assign 1 248 851
get 2 248 851
assign 1 248 852
firstGet 0 248 852
assign 1 249 853
new 0 249 853
assign 1 249 854
new 0 249 854
assign 1 249 855
get 2 249 855
assign 1 249 856
firstGet 0 249 856
assign 1 250 857
new 0 250 857
assign 1 250 858
add 1 250 858
assign 1 250 859
new 0 250 859
assign 1 250 860
get 2 250 860
assign 1 250 861
firstGet 0 250 861
assign 1 251 862
new 0 251 862
assign 1 252 863
new 0 252 863
assign 1 253 864
new 0 253 864
assign 1 254 865
new 0 254 865
assign 1 255 866
new 0 255 866
assign 1 258 867
def 1 258 872
assign 1 259 873
firstGet 0 259 873
assign 1 261 876
new 0 261 876
assign 1 268 878
new 0 268 878
assign 1 268 879
add 1 268 879
assign 1 268 880
nameGet 0 268 880
assign 1 268 881
add 1 268 881
assign 1 268 882
get 1 268 882
assign 1 269 883
def 1 269 888
assign 1 270 889
orderedGet 0 270 889
addAll 1 270 890
assign 1 273 892
new 0 273 892
assign 1 273 893
add 1 273 893
assign 1 273 894
get 1 273 894
assign 1 274 895
def 1 274 900
assign 1 275 901
orderedGet 0 275 901
addAll 1 275 902
assign 1 278 904
new 0 278 904
assign 1 279 905
orderedGet 0 279 905
assign 1 279 906
iteratorGet 0 0 906
assign 1 279 909
hasNextGet 0 279 909
assign 1 279 911
nextGet 0 279 911
assign 1 280 912
new 1 280 912
addValue 1 280 913
assign 1 282 919
newlineGet 0 282 919
assign 1 283 920
assign 1 284 921
new 1 284 921
assign 1 286 922
copy 0 286 922
assign 1 287 923
fileGet 0 287 923
assign 1 287 924
existsGet 0 287 924
assign 1 287 925
not 0 287 930
assign 1 288 931
fileGet 0 288 931
makeDirs 0 288 932
assign 1 290 934
def 1 290 939
assign 1 291 940
new 1 291 940
assign 1 291 941
readerGet 0 291 941
assign 1 292 942
open 0 292 942
assign 1 292 943
readString 0 292 943
close 0 293 944
assign 1 299 958
classNameGet 0 299 958
assign 1 300 959
add 1 300 959
assign 1 300 960
new 0 300 960
assign 1 300 961
add 1 300 961
assign 1 300 962
toString 0 300 962
assign 1 300 963
add 1 300 963
assign 1 301 964
add 1 301 964
assign 1 301 965
new 0 301 965
assign 1 301 966
add 1 301 966
assign 1 301 967
toString 0 301 967
assign 1 301 968
add 1 301 968
return 1 302 969
assign 1 306 1009
new 0 306 1009
assign 1 307 1010
classesGet 0 307 1010
assign 1 307 1011
valueIteratorGet 0 307 1011
assign 1 307 1014
hasNextGet 0 307 1014
assign 1 308 1016
nextGet 0 308 1016
assign 1 309 1017
shouldEmitGet 0 309 1017
assign 1 309 1018
heldGet 0 309 1018
assign 1 309 1019
fromFileGet 0 309 1019
assign 1 309 1020
has 1 309 1020
assign 1 310 1022
heldGet 0 310 1022
assign 1 310 1023
namepathGet 0 310 1023
assign 1 310 1024
toString 0 310 1024
put 1 310 1025
assign 1 311 1026
usedByGet 0 311 1026
assign 1 311 1027
heldGet 0 311 1027
assign 1 311 1028
namepathGet 0 311 1028
assign 1 311 1029
toString 0 311 1029
assign 1 311 1030
get 1 311 1030
assign 1 312 1031
def 1 312 1036
assign 1 313 1037
setIteratorGet 0 0 1037
assign 1 313 1040
hasNextGet 0 313 1040
assign 1 313 1042
nextGet 0 313 1042
put 1 314 1043
assign 1 317 1050
subClassesGet 0 317 1050
assign 1 317 1051
heldGet 0 317 1051
assign 1 317 1052
namepathGet 0 317 1052
assign 1 317 1053
toString 0 317 1053
assign 1 317 1054
get 1 317 1054
assign 1 318 1055
def 1 318 1060
assign 1 319 1061
setIteratorGet 0 0 1061
assign 1 319 1064
hasNextGet 0 319 1064
assign 1 319 1066
nextGet 0 319 1066
put 1 320 1067
assign 1 325 1080
classesGet 0 325 1080
assign 1 325 1081
valueIteratorGet 0 325 1081
assign 1 325 1084
hasNextGet 0 325 1084
assign 1 326 1086
nextGet 0 326 1086
assign 1 327 1087
heldGet 0 327 1087
assign 1 327 1088
heldGet 0 327 1088
assign 1 327 1089
namepathGet 0 327 1089
assign 1 327 1090
toString 0 327 1090
assign 1 327 1091
has 1 327 1091
shouldWriteSet 1 327 1092
assign 1 334 1102
new 0 334 1102
return 1 334 1103
assign 1 338 1119
def 1 338 1124
return 1 339 1125
assign 1 344 1127
def 1 344 1132
assign 1 345 1133
firstGet 0 345 1133
assign 1 346 1134
new 0 346 1134
assign 1 346 1135
equals 1 346 1135
assign 1 347 1137
new 1 347 1137
assign 1 348 1140
new 0 348 1140
assign 1 348 1141
equals 1 348 1141
assign 1 349 1143
new 1 349 1143
assign 1 350 1146
new 0 350 1146
assign 1 350 1147
equals 1 350 1147
assign 1 351 1149
new 1 351 1149
assign 1 352 1152
new 0 352 1152
assign 1 352 1153
equals 1 352 1153
assign 1 353 1155
new 1 353 1155
assign 1 355 1158
new 0 355 1158
assign 1 355 1159
new 1 355 1159
throw 1 355 1160
dynConditionsAllSet 1 357 1165
return 1 358 1166
return 1 360 1168
assign 1 364 1187
apNew 1 364 1187
assign 1 366 1188
new 0 366 1188
assign 1 366 1189
add 1 366 1189
print 0 366 1190
assign 1 367 1191
new 0 367 1191
assign 1 367 1192
now 0 367 1192
assign 1 368 1193
fileGet 0 368 1193
assign 1 368 1194
readerGet 0 368 1194
assign 1 368 1195
open 0 368 1195
assign 1 369 1196
new 0 369 1196
assign 1 369 1197
deserialize 1 369 1197
close 0 370 1198
assign 1 371 1199
synClassesGet 0 371 1199
addValue 1 371 1200
assign 1 372 1201
new 0 372 1201
assign 1 372 1202
now 0 372 1202
assign 1 372 1203
subtract 1 372 1203
assign 1 373 1204
new 0 373 1204
assign 1 373 1205
add 1 373 1205
print 0 373 1206
assign 1 379 1327
new 0 379 1327
assign 1 379 1328
now 0 379 1328
assign 1 380 1329
new 0 380 1329
assign 1 381 1330
def 1 381 1335
assign 1 382 1336
linkedListIteratorGet 0 0 1336
assign 1 382 1339
hasNextGet 0 382 1339
assign 1 382 1341
nextGet 0 382 1341
loadSyns 1 383 1342
assign 1 386 1349
emitterGet 0 386 1349
assign 1 387 1350
def 1 387 1355
assign 1 388 1356
new 4 388 1356
put 1 389 1357
assign 1 391 1359
new 0 391 1359
assign 1 391 1360
add 1 391 1360
print 0 391 1361
assign 1 394 1364
new 0 394 1364
assign 1 396 1365
iteratorGet 0 0 1365
assign 1 396 1368
hasNextGet 0 396 1368
assign 1 396 1370
nextGet 0 396 1370
assign 1 397 1371
has 1 397 1371
assign 1 397 1372
not 0 397 1377
put 1 398 1378
assign 1 399 1379
new 2 399 1379
addValue 1 400 1380
assign 1 403 1387
iteratorGet 0 0 1387
assign 1 403 1390
hasNextGet 0 403 1390
assign 1 403 1392
nextGet 0 403 1392
assign 1 404 1393
has 1 404 1393
assign 1 404 1394
not 0 404 1399
put 1 405 1400
assign 1 406 1401
new 2 406 1401
addValue 1 407 1402
assign 1 408 1403
libNameGet 0 408 1403
put 1 408 1404
assign 1 413 1412
new 0 413 1412
assign 1 414 1413
iteratorGet 0 414 1413
assign 1 414 1416
hasNextGet 0 414 1416
assign 1 415 1418
nextGet 0 415 1418
assign 1 417 1419
toString 0 417 1419
assign 1 417 1420
has 1 417 1420
assign 1 418 1422
toString 0 418 1422
put 1 418 1423
doParse 1 419 1424
buildSyns 1 422 1431
assign 1 425 1433
new 0 425 1433
assign 1 425 1434
now 0 425 1434
assign 1 425 1435
subtract 1 425 1435
assign 1 428 1436
emitCommonGet 0 428 1436
assign 1 428 1437
def 1 428 1442
assign 1 430 1443
new 0 430 1443
assign 1 430 1444
now 0 430 1444
assign 1 431 1445
emitCommonGet 0 431 1445
doEmit 0 431 1446
assign 1 432 1447
new 0 432 1447
assign 1 432 1448
now 0 432 1448
assign 1 432 1449
subtract 1 432 1449
assign 1 433 1450
new 0 433 1450
assign 1 433 1451
now 0 433 1451
assign 1 433 1452
subtract 1 433 1452
assign 1 434 1453
new 0 434 1453
assign 1 434 1454
add 1 434 1454
print 0 434 1455
assign 1 435 1456
new 0 435 1456
assign 1 435 1457
add 1 435 1457
print 0 435 1458
assign 1 436 1459
new 0 436 1459
assign 1 436 1460
add 1 436 1460
print 0 436 1461
assign 1 437 1462
new 0 437 1462
return 1 437 1463
setClassesToWrite 0 440 1466
libnameInfoGet 0 441 1467
assign 1 443 1468
classesGet 0 443 1468
assign 1 443 1469
valueIteratorGet 0 443 1469
assign 1 443 1472
hasNextGet 0 443 1472
assign 1 444 1474
nextGet 0 444 1474
doEmit 1 445 1475
emitMain 0 447 1481
emitCUInit 0 448 1482
assign 1 449 1483
classesGet 0 449 1483
assign 1 449 1484
valueIteratorGet 0 449 1484
assign 1 449 1487
hasNextGet 0 449 1487
assign 1 450 1489
nextGet 0 450 1489
emitSyn 1 451 1490
assign 1 455 1497
new 0 455 1497
assign 1 455 1498
now 0 455 1498
assign 1 455 1499
subtract 1 455 1499
assign 1 456 1500
def 1 456 1505
assign 1 457 1506
new 0 457 1506
assign 1 457 1507
add 1 457 1507
print 0 457 1508
assign 1 459 1510
new 0 459 1510
assign 1 459 1511
add 1 459 1511
print 0 459 1512
prepMake 1 462 1514
assign 1 466 1517
not 0 466 1522
make 1 467 1523
deployLibrary 1 468 1524
assign 1 470 1526
linkedListIteratorGet 0 0 1526
assign 1 470 1529
hasNextGet 0 470 1529
assign 1 470 1531
nextGet 0 470 1531
assign 1 471 1532
libnameInfoGet 0 471 1532
assign 1 471 1533
unitShlibGet 0 471 1533
assign 1 472 1534
emitPathGet 0 472 1534
assign 1 472 1535
copy 0 472 1535
assign 1 473 1536
stepsGet 0 473 1536
assign 1 473 1537
lastGet 0 473 1537
addStep 1 473 1538
assign 1 474 1539
fileGet 0 474 1539
assign 1 474 1540
existsGet 0 474 1540
assign 1 475 1542
fileGet 0 475 1542
delete 0 475 1543
assign 1 477 1545
fileGet 0 477 1545
assign 1 477 1546
existsGet 0 477 1546
assign 1 477 1547
not 0 477 1547
assign 1 478 1549
fileGet 0 478 1549
assign 1 478 1550
fileGet 0 478 1550
deployFile 2 478 1551
assign 1 482 1559
iteratorGet 0 482 1559
assign 1 483 1560
iteratorGet 0 483 1560
assign 1 485 1563
hasNextGet 0 485 1563
assign 1 485 1565
hasNextGet 0 485 1565
assign 1 0 1567
assign 1 0 1570
assign 1 0 1574
assign 1 486 1577
nextGet 0 486 1577
assign 1 486 1578
apNew 1 486 1578
assign 1 487 1579
emitPathGet 0 487 1579
assign 1 487 1580
copy 0 487 1580
assign 1 487 1581
toString 0 487 1581
assign 1 487 1582
new 0 487 1582
assign 1 487 1583
add 1 487 1583
assign 1 487 1584
nextGet 0 487 1584
assign 1 487 1585
add 1 487 1585
assign 1 487 1586
apNew 1 487 1586
assign 1 489 1587
fileGet 0 489 1587
assign 1 489 1588
existsGet 0 489 1588
assign 1 490 1590
fileGet 0 490 1590
delete 0 490 1591
assign 1 492 1593
fileGet 0 492 1593
assign 1 492 1594
existsGet 0 492 1594
assign 1 492 1595
not 0 492 1595
assign 1 493 1597
fileGet 0 493 1597
assign 1 493 1598
fileGet 0 493 1598
deployFile 2 493 1599
assign 1 498 1608
new 0 498 1608
assign 1 498 1609
now 0 498 1609
assign 1 498 1610
subtract 1 498 1610
assign 1 500 1611
def 1 500 1616
assign 1 501 1617
new 0 501 1617
assign 1 501 1618
add 1 501 1618
print 0 501 1619
assign 1 503 1621
def 1 503 1626
assign 1 504 1627
new 0 504 1627
assign 1 504 1628
add 1 504 1628
print 0 504 1629
assign 1 506 1631
def 1 506 1636
assign 1 507 1637
new 0 507 1637
assign 1 507 1638
add 1 507 1638
print 0 507 1639
assign 1 511 1642
new 0 511 1642
print 0 511 1643
assign 1 512 1644
run 2 512 1644
assign 1 513 1645
new 0 513 1645
assign 1 513 1646
add 1 513 1646
assign 1 513 1647
new 0 513 1647
assign 1 513 1648
add 1 513 1648
print 0 513 1649
return 1 514 1650
assign 1 516 1652
new 0 516 1652
return 1 516 1653
assign 1 520 1666
justParsedGet 0 520 1666
assign 1 520 1667
valueIteratorGet 0 520 1667
assign 1 520 1670
hasNextGet 0 520 1670
assign 1 521 1672
nextGet 0 521 1672
assign 1 522 1673
heldGet 0 522 1673
libNameSet 1 522 1674
assign 1 523 1675
getSyn 2 523 1675
libNameSet 1 524 1676
assign 1 526 1682
justParsedGet 0 526 1682
assign 1 526 1683
valueIteratorGet 0 526 1683
assign 1 526 1686
hasNextGet 0 526 1686
assign 1 527 1688
nextGet 0 527 1688
assign 1 528 1689
heldGet 0 528 1689
assign 1 528 1690
synGet 0 528 1690
checkInheritance 2 529 1691
integrate 1 530 1692
assign 1 532 1698
new 0 532 1698
justParsedSet 1 532 1699
assign 1 536 1727
heldGet 0 536 1727
assign 1 536 1728
synGet 0 536 1728
assign 1 536 1729
def 1 536 1734
assign 1 537 1735
heldGet 0 537 1735
assign 1 537 1736
synGet 0 537 1736
return 1 537 1737
assign 1 539 1739
heldGet 0 539 1739
libNameSet 1 539 1740
assign 1 540 1741
heldGet 0 540 1741
assign 1 540 1742
extendsGet 0 540 1742
assign 1 540 1743
undef 1 540 1748
assign 1 541 1749
new 1 541 1749
assign 1 543 1752
classesGet 0 543 1752
assign 1 543 1753
heldGet 0 543 1753
assign 1 543 1754
extendsGet 0 543 1754
assign 1 543 1755
toString 0 543 1755
assign 1 543 1756
get 1 543 1756
assign 1 545 1757
def 1 545 1762
assign 1 546 1763
heldGet 0 546 1763
libNameSet 1 546 1764
assign 1 547 1765
getSyn 2 547 1765
assign 1 551 1768
heldGet 0 551 1768
assign 1 551 1769
extendsGet 0 551 1769
assign 1 551 1770
getSynNp 1 551 1770
assign 1 553 1772
new 2 553 1772
assign 1 555 1774
heldGet 0 555 1774
synSet 1 555 1775
assign 1 556 1776
heldGet 0 556 1776
assign 1 556 1777
namepathGet 0 556 1777
assign 1 556 1778
toString 0 556 1778
addSynClass 2 556 1779
return 1 557 1780
assign 1 561 1788
toString 0 561 1788
assign 1 562 1789
synClassesGet 0 562 1789
assign 1 562 1790
get 1 562 1790
assign 1 563 1791
def 1 563 1796
return 1 564 1797
assign 1 570 1799
emitterGet 0 570 1799
assign 1 570 1800
loadSyn 1 570 1800
addSynClass 2 571 1801
return 1 572 1802
assign 1 579 1806
undef 1 579 1811
assign 1 580 1812
new 1 580 1812
return 1 582 1814
assign 1 587 1893
new 1 587 1893
assign 1 588 1894
new 0 588 1894
assign 1 589 1895
emitterGet 0 589 1895
assign 1 590 1896
assign 1 591 1897
new 0 591 1897
assign 1 592 1898
shouldEmitGet 0 592 1898
put 1 592 1899
assign 1 0 1902
assign 1 0 1906
assign 1 0 1909
assign 1 595 1913
new 0 595 1913
assign 1 595 1914
toString 0 595 1914
assign 1 595 1915
add 1 595 1915
print 0 595 1916
assign 1 597 1918
assign 1 599 1919
fileGet 0 599 1919
assign 1 599 1920
readerGet 0 599 1920
assign 1 599 1921
open 0 599 1921
assign 1 599 1922
readBuffer 1 599 1922
assign 1 600 1923
fileGet 0 600 1923
assign 1 600 1924
readerGet 0 600 1924
close 0 600 1925
assign 1 601 1926
tokenize 1 601 1926
assign 1 605 1928
new 0 605 1928
echo 0 605 1929
assign 1 607 1931
outermostGet 0 607 1931
nodify 2 607 1932
assign 1 609 1934
new 0 609 1934
print 0 609 1935
assign 1 610 1936
new 2 610 1936
traverse 1 610 1937
assign 1 614 1940
new 0 614 1940
echo 0 614 1941
assign 1 616 1943
new 0 616 1943
traverse 1 616 1944
assign 1 618 1946
new 0 618 1946
print 0 618 1947
assign 1 619 1948
new 2 619 1948
traverse 1 619 1949
assign 1 622 1952
new 0 622 1952
echo 0 622 1953
assign 1 625 1955
new 0 625 1955
traverse 1 625 1956
contain 0 626 1957
assign 1 628 1959
new 0 628 1959
print 0 628 1960
assign 1 629 1961
new 2 629 1961
traverse 1 629 1962
assign 1 633 1965
new 0 633 1965
echo 0 633 1966
assign 1 635 1968
new 0 635 1968
traverse 1 635 1969
assign 1 637 1971
new 0 637 1971
print 0 637 1972
assign 1 638 1973
new 2 638 1973
traverse 1 638 1974
assign 1 642 1977
new 0 642 1977
echo 0 642 1978
assign 1 644 1980
new 0 644 1980
traverse 1 644 1981
assign 1 646 1983
new 0 646 1983
print 0 646 1984
assign 1 647 1985
new 2 647 1985
traverse 1 647 1986
assign 1 651 1989
new 0 651 1989
echo 0 651 1990
assign 1 653 1992
new 0 653 1992
traverse 1 653 1993
assign 1 655 1995
new 0 655 1995
print 0 655 1996
assign 1 656 1997
new 2 656 1997
traverse 1 656 1998
assign 1 660 2001
new 0 660 2001
echo 0 660 2002
assign 1 662 2004
new 0 662 2004
traverse 1 662 2005
assign 1 664 2007
new 0 664 2007
print 0 664 2008
assign 1 665 2009
new 2 665 2009
traverse 1 665 2010
assign 1 669 2013
new 0 669 2013
echo 0 669 2014
assign 1 671 2016
new 0 671 2016
traverse 1 671 2017
assign 1 673 2019
new 0 673 2019
print 0 673 2020
assign 1 674 2021
new 2 674 2021
traverse 1 674 2022
assign 1 678 2025
new 0 678 2025
echo 0 678 2026
assign 1 680 2028
new 0 680 2028
traverse 1 680 2029
assign 1 682 2031
new 0 682 2031
print 0 682 2032
assign 1 683 2033
new 2 683 2033
traverse 1 683 2034
assign 1 687 2037
new 0 687 2037
echo 0 687 2038
assign 1 689 2040
new 0 689 2040
traverse 1 689 2041
assign 1 691 2043
new 0 691 2043
print 0 691 2044
assign 1 692 2045
new 2 692 2045
traverse 1 692 2046
assign 1 695 2049
new 0 695 2049
echo 0 695 2050
assign 1 697 2052
new 0 697 2052
traverse 1 697 2053
assign 1 699 2055
new 0 699 2055
print 0 699 2056
assign 1 700 2057
new 2 700 2057
traverse 1 700 2058
assign 1 704 2061
new 0 704 2061
echo 0 704 2062
assign 1 705 2063
new 0 705 2063
print 0 705 2064
assign 1 707 2066
new 0 707 2066
traverse 1 707 2067
assign 1 0 2069
assign 1 0 2073
assign 1 0 2076
assign 1 709 2080
new 0 709 2080
print 0 709 2081
assign 1 710 2082
new 2 710 2082
traverse 1 710 2083
assign 1 712 2085
classesGet 0 712 2085
assign 1 712 2086
valueIteratorGet 0 712 2086
assign 1 712 2089
hasNextGet 0 712 2089
assign 1 713 2091
nextGet 0 713 2091
assign 1 715 2092
transUnitGet 0 715 2092
assign 1 716 2093
new 1 716 2093
assign 1 717 2094
TRANSUNITGet 0 717 2094
typenameSet 1 717 2095
assign 1 718 2096
new 0 718 2096
assign 1 719 2097
heldGet 0 719 2097
assign 1 719 2098
emitsGet 0 719 2098
emitsSet 1 719 2099
heldSet 1 720 2100
delete 0 721 2101
addValue 1 722 2102
copyLoc 1 723 2103
reInitContained 0 729 2125
assign 1 730 2126
containedGet 0 730 2126
assign 1 731 2127
new 0 731 2127
assign 1 732 2128
new 0 732 2128
assign 1 732 2129
crGet 0 732 2129
assign 1 733 2130
linkedListIteratorGet 0 733 2130
assign 1 733 2133
hasNextGet 0 733 2133
assign 1 734 2135
new 1 734 2135
assign 1 735 2136
nextGet 0 735 2136
heldSet 1 735 2137
nlcSet 1 736 2138
assign 1 737 2139
heldGet 0 737 2139
assign 1 737 2140
equals 1 737 2140
assign 1 738 2142
increment 0 738 2142
assign 1 740 2144
heldGet 0 740 2144
assign 1 740 2145
notEquals 1 740 2145
addValue 1 741 2147
containerSet 1 742 2148
assign 1 749 2203
new 0 749 2203
fromString 1 750 2204
assign 1 752 2205
new 1 752 2205
assign 1 753 2206
NAMEPATHGet 0 753 2206
typenameSet 1 753 2207
heldSet 1 754 2208
copyLoc 1 755 2209
assign 1 757 2210
new 0 757 2210
assign 1 758 2211
new 0 758 2211
nameSet 1 758 2212
assign 1 759 2213
new 0 759 2213
wasBoundSet 1 759 2214
assign 1 760 2215
new 0 760 2215
boundSet 1 760 2216
assign 1 761 2217
new 0 761 2217
isConstructSet 1 761 2218
assign 1 762 2219
new 0 762 2219
isLiteralSet 1 762 2220
assign 1 763 2221
heldGet 0 763 2221
literalValueSet 1 763 2222
addValue 1 765 2223
assign 1 767 2224
CALLGet 0 767 2224
typenameSet 1 767 2225
heldSet 1 768 2226
resolveNp 0 770 2227
assign 1 772 2228
new 0 772 2228
assign 1 772 2229
equals 1 772 2229
assign 1 0 2231
assign 1 772 2234
new 0 772 2234
assign 1 772 2235
equals 1 772 2235
assign 1 0 2237
assign 1 0 2240
assign 1 773 2244
priorPeerGet 0 773 2244
assign 1 774 2245
def 1 774 2250
assign 1 774 2251
typenameGet 0 774 2251
assign 1 774 2252
SUBTRACTGet 0 774 2252
assign 1 774 2253
equals 1 774 2253
assign 1 0 2255
assign 1 774 2258
typenameGet 0 774 2258
assign 1 774 2259
ADDGet 0 774 2259
assign 1 774 2260
equals 1 774 2260
assign 1 0 2262
assign 1 0 2265
assign 1 0 2269
assign 1 0 2272
assign 1 0 2276
assign 1 775 2279
priorPeerGet 0 775 2279
assign 1 776 2280
undef 1 776 2285
assign 1 0 2286
assign 1 776 2289
typenameGet 0 776 2289
assign 1 776 2290
CALLGet 0 776 2290
assign 1 776 2291
notEquals 1 776 2291
assign 1 776 2293
typenameGet 0 776 2293
assign 1 776 2294
IDGet 0 776 2294
assign 1 776 2295
notEquals 1 776 2295
assign 1 0 2297
assign 1 0 2300
assign 1 0 2304
assign 1 776 2307
typenameGet 0 776 2307
assign 1 776 2308
VARGet 0 776 2308
assign 1 776 2309
notEquals 1 776 2309
assign 1 0 2311
assign 1 0 2314
assign 1 0 2318
assign 1 776 2321
typenameGet 0 776 2321
assign 1 776 2322
ACCESSORGet 0 776 2322
assign 1 776 2323
notEquals 1 776 2323
assign 1 0 2325
assign 1 0 2328
assign 1 0 2332
assign 1 0 2335
assign 1 0 2338
assign 1 782 2342
heldGet 0 782 2342
assign 1 782 2343
literalValueGet 0 782 2343
assign 1 782 2344
add 1 782 2344
literalValueSet 1 782 2345
delete 0 783 2346
return 1 0 2353
assign 1 0 2356
return 1 0 2360
assign 1 0 2363
return 1 0 2367
assign 1 0 2370
return 1 0 2374
assign 1 0 2377
return 1 0 2381
assign 1 0 2384
return 1 0 2388
assign 1 0 2391
return 1 0 2395
assign 1 0 2398
return 1 0 2402
assign 1 0 2405
return 1 0 2409
assign 1 0 2412
return 1 0 2416
assign 1 0 2419
return 1 0 2423
assign 1 0 2426
return 1 0 2430
assign 1 0 2433
return 1 0 2437
assign 1 0 2440
return 1 0 2444
assign 1 0 2447
return 1 0 2451
assign 1 0 2454
return 1 0 2458
assign 1 0 2461
return 1 0 2465
assign 1 0 2468
return 1 0 2472
assign 1 0 2475
return 1 0 2479
assign 1 0 2482
return 1 0 2486
assign 1 0 2489
return 1 0 2493
assign 1 0 2496
return 1 0 2500
assign 1 0 2503
return 1 0 2507
assign 1 0 2510
return 1 0 2514
assign 1 0 2517
return 1 0 2521
assign 1 0 2524
return 1 0 2528
assign 1 0 2531
return 1 0 2535
assign 1 0 2538
return 1 0 2542
assign 1 0 2545
return 1 0 2549
assign 1 0 2552
return 1 0 2556
assign 1 0 2559
return 1 0 2563
assign 1 0 2566
return 1 0 2570
assign 1 0 2573
return 1 0 2577
assign 1 0 2580
return 1 0 2584
assign 1 0 2587
return 1 0 2591
assign 1 0 2594
return 1 0 2598
assign 1 0 2601
return 1 0 2605
assign 1 0 2608
return 1 0 2612
assign 1 0 2615
return 1 0 2619
assign 1 0 2622
return 1 0 2626
assign 1 0 2629
return 1 0 2633
assign 1 0 2636
return 1 0 2640
assign 1 0 2643
return 1 0 2647
assign 1 0 2650
return 1 0 2654
assign 1 0 2657
return 1 0 2661
assign 1 0 2664
return 1 0 2668
assign 1 0 2671
return 1 0 2675
assign 1 0 2678
return 1 0 2682
assign 1 0 2685
return 1 0 2689
assign 1 0 2692
return 1 0 2696
assign 1 0 2699
return 1 0 2703
assign 1 0 2706
return 1 0 2710
assign 1 0 2713
return 1 0 2717
assign 1 0 2720
return 1 0 2724
assign 1 0 2727
return 1 0 2731
assign 1 0 2734
return 1 0 2738
assign 1 0 2741
return 1 0 2745
assign 1 0 2748
return 1 0 2752
assign 1 0 2755
return 1 0 2759
assign 1 0 2762
return 1 0 2766
assign 1 0 2769
return 1 0 2773
assign 1 0 2776
return 1 0 2780
assign 1 0 2783
return 1 0 2787
assign 1 0 2790
return 1 0 2794
assign 1 0 2797
return 1 0 2801
assign 1 0 2804
return 1 0 2808
assign 1 0 2811
return 1 0 2815
assign 1 0 2818
return 1 0 2822
assign 1 0 2825
return 1 0 2829
assign 1 0 2832
return 1 0 2836
assign 1 0 2839
return 1 0 2843
assign 1 0 2846
assign 1 0 2850
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callHash, int callId) throws Throwable {
switch (callHash) {
case -1308786538: return bem_echo_0();
case -404051026: return bem_printPlacesGet_0();
case -729571811: return bem_serializeToString_0();
case -2113443821: return bem_deployLibraryGet_0();
case -34945623: return bem_builtGet_0();
case 1503762842: return bem_twtokGet_0();
case -340280200: return bem_startTimeGet_0();
case 2055025483: return bem_serializeContents_0();
case 1102720804: return bem_classNameGet_0();
case 3178137: return bem_go_0();
case 1440072651: return bem_genOnlyGet_0();
case 766890616: return bem_extLibsGet_0();
case 871521083: return bem_deployPathGet_0();
case 1243720761: return bem_makeGet_0();
case 505821664: return bem_doWhat_0();
case -580139405: return bem_config_0();
case -2097068593: return bem_emitPathGet_0();
case 1506275655: return bem_parseTimeGet_0();
case -1081571542: return bem_main_0();
case 287040793: return bem_hashGet_0();
case -1803479881: return bem_libNameGet_0();
case -314718434: return bem_print_0();
case -2028575047: return bem_emitterGet_0();
case 793530812: return bem_runGet_0();
case -186098742: return bem_exeNameGet_0();
case -1023899351: return bem_doEmitGet_0();
case 795036897: return bem_fromFileGet_0();
case -829911139: return bem_compilerProfileGet_0();
case -1012494862: return bem_once_0();
case -1081412016: return bem_many_0();
case -1506224719: return bem_readBufferGet_0();
case 1467203118: return bem_extLinkObjectsGet_0();
case 1216843828: return bem_parseEmitTimeGet_0();
case -658773870: return bem_usedLibrarysGet_0();
case 515445972: return bem_platformGet_0();
case 2001798761: return bem_nlGet_0();
case -2082855574: return bem_emitDataGet_0();
case -786424307: return bem_tagGet_0();
case 1768658651: return bem_extIncludesGet_0();
case -2037974293: return bem_usedLibrarysStrGet_0();
case 2117559209: return bem_serializationIteratorGet_0();
case 1030311316: return bem_buildPathGet_0();
case -271866114: return bem_ownProcessGet_0();
case -2025906022: return bem_includePathGet_0();
case 801883195: return bem_printAstElementsGet_0();
case -1919619119: return bem_setClassesToWrite_0();
case -2127864150: return bem_argsGet_0();
case -400920261: return bem_estrGet_0();
case 1729492926: return bem_sharedEmitterGet_0();
case -1003238764: return bem_parseGet_0();
case -1924410263: return bem_initLibsGet_0();
case -902949587: return bem_printStepsGet_0();
case -35631997: return bem_deserializeClassNameGet_0();
case 104713553: return bem_new_0();
case 1696041108: return bem_toBuildGet_0();
case 332744691: return bem_ccObjArgsGet_0();
case 268778355: return bem_emitFlagsGet_0();
case 2072413014: return bem_loadSynsGet_0();
case -1505775346: return bem_putLineNumbersInTraceGet_0();
case -1713520961: return bem_linkLibArgsGet_0();
case -1696889601: return bem_emitLibraryGet_0();
case 478622533: return bem_sourceFileNameGet_0();
case 1092226051: return bem_mainNameGet_0();
case 1820417453: return bem_create_0();
case -644675716: return bem_ntypesGet_0();
case -1185503219: return bem_deployFilesFromGet_0();
case -1321442187: return bem_emitLangsGet_0();
case 1368494887: return bem_emitDebugGet_0();
case 643714188: return bem_prepMakeGet_0();
case 222774364: return bem_makeArgsGet_0();
case -1478944775: return bem_printAllAstGet_0();
case 1628180444: return bem_deployFilesToGet_0();
case -1492719209: return bem_dynConditionsAllGet_0();
case 70909774: return bem_buildMessageGet_0();
case 846203526: return bem_closeLibrariesGet_0();
case -1066352481: return bem_saveSynsGet_0();
case -1182494494: return bem_toAny_0();
case 1874994295: return bem_closeLibrariesStrGet_0();
case 927274360: return bem_constantsGet_0();
case 422411474: return bem_deployUsedLibrariesGet_0();
case 549080104: return bem_compilerGet_0();
case -560757623: return bem_emitCommonGet_0();
case 999136916: return bem_emitCs_0();
case -733055122: return bem_makeNameGet_0();
case -328200718: return bem_printAstGet_0();
case -126511789: return bem_outputPlatformGet_0();
case 1774940957: return bem_toString_0();
case 570254478: return bem_lctokGet_0();
case 1695168417: return bem_paramsGet_0();
case 1155524365: return bem_parseEmitCompileTimeGet_0();
case -1354714650: return bem_copy_0();
case 776765523: return bem_newlineGet_0();
case 1775071327: return bem_runArgsGet_0();
case -1458327669: return bem_emitFileHeaderGet_0();
case -1220511308: return bem_buildSucceededGet_0();
case -2034127137: return bem_fieldIteratorGet_0();
case -845792839: return bem_iteratorGet_0();
case -1149621350: return bem_codeGet_0();
}
return super.bemd_0(callHash, callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callHash) {
case 1517357908: return bem_parseTimeSet_1(bevd_0);
case -1094759839: return bem_process_1((BEC_2_4_6_TextString) bevd_0);
case 1794718135: return bem_sameObject_1(bevd_0);
case -505952126: return bem_copyTo_1(bevd_0);
case -2036609109: return bem_buildSyns_1(bevd_0);
case -972018826: return bem_dllhead_1((BEC_2_4_6_TextString) bevd_0);
case 279860608: return bem_emitFlagsSet_1(bevd_0);
case -1081571541: return bem_main_1((BEC_2_9_4_ContainerList) bevd_0);
case -633593463: return bem_ntypesSet_1(bevd_0);
case -1211344638: return bem_undefined_1(bevd_0);
case 81992027: return bem_buildMessageSet_1(bevd_0);
case -1012817098: return bem_doEmitSet_1(bevd_0);
case -458330056: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1041393569: return bem_buildPathSet_1(bevd_0);
case 1103308304: return bem_mainNameSet_1(bevd_0);
case 1254803014: return bem_makeSet_1(bevd_0);
case 812965448: return bem_printAstElementsSet_1(bevd_0);
case 95462007: return bem_def_1(bevd_0);
case -1447245416: return bem_emitFileHeaderSet_1(bevd_0);
case -1664117860: return bem_otherType_1(bevd_0);
case 1514845095: return bem_twtokSet_1(bevd_0);
case -1567407837: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -317118465: return bem_printAstSet_1(bevd_0);
case -2116781897: return bem_argsSet_1(bevd_0);
case 1740575179: return bem_sharedEmitterSet_1(bevd_0);
case -647691617: return bem_usedLibrarysSet_1(bevd_0);
case -1702438708: return bem_linkLibArgsSet_1(bevd_0);
case -1913328010: return bem_initLibsSet_1(bevd_0);
case 1166606618: return bem_parseEmitCompileTimeSet_1(bevd_0);
case -721972869: return bem_makeNameSet_1(bevd_0);
case -1055270228: return bem_saveSynsSet_1(bevd_0);
case 654796441: return bem_prepMakeSet_1(bevd_0);
case -1174420966: return bem_deployFilesFromSet_1(bevd_0);
case 1886076548: return bem_closeLibrariesStrSet_1(bevd_0);
case -1792397628: return bem_libNameSet_1(bevd_0);
case -1209429055: return bem_buildSucceededSet_1(bevd_0);
case -329197947: return bem_startTimeSet_1(bevd_0);
case -2071773321: return bem_emitDataSet_1(bevd_0);
case 1379577140: return bem_emitDebugSet_1(bevd_0);
case -2047949204: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1697252238: return bem_sameType_1(bevd_0);
case 2012881014: return bem_nlSet_1(bevd_0);
case 631500772: return bem_sameClass_1(bevd_0);
case 1706250670: return bem_paramsSet_1(bevd_0);
case 1779740904: return bem_extIncludesSet_1(bevd_0);
case 1658666490: return bem_otherClass_1(bevd_0);
case -1310359934: return bem_emitLangsSet_1(bevd_0);
case 1634690505: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 433493727: return bem_deployUsedLibrariesSet_1(bevd_0);
case -2026892040: return bem_usedLibrarysStrSet_1(bevd_0);
case 938356613: return bem_constantsSet_1(bevd_0);
case -2014823769: return bem_includePathSet_1(bevd_0);
case 1786153580: return bem_runArgsSet_1(bevd_0);
case -1685807348: return bem_emitLibrarySet_1(bevd_0);
case -992156511: return bem_parseSet_1(bevd_0);
case 2083495267: return bem_loadSynsSet_1(bevd_0);
case -211282909: return bem_loadSyns_1((BEC_2_4_6_TextString) bevd_0);
case -23863370: return bem_builtSet_1(bevd_0);
case -115429536: return bem_outputPlatformSet_1(bevd_0);
case 1000416164: return bem_notEquals_1(bevd_0);
case 1478285371: return bem_extLinkObjectsSet_1(bevd_0);
case -1494693093: return bem_putLineNumbersInTraceSet_1(bevd_0);
case 1451154904: return bem_genOnlySet_1(bevd_0);
case -1138539097: return bem_codeSet_1(bevd_0);
case -1495142466: return bem_readBufferSet_1(bevd_0);
case -891867334: return bem_printStepsSet_1(bevd_0);
case 343826944: return bem_ccObjArgsSet_1(bevd_0);
case 1707123361: return bem_toBuildSet_1(bevd_0);
case -1481636956: return bem_dynConditionsAllSet_1(bevd_0);
case 1227926081: return bem_parseEmitTimeSet_1(bevd_0);
case -175016489: return bem_exeNameSet_1(bevd_0);
case 1639262697: return bem_deployFilesToSet_1(bevd_0);
case 233856617: return bem_makeArgsSet_1(bevd_0);
case -2102361568: return bem_deployLibrarySet_1(bevd_0);
case 777972869: return bem_extLibsSet_1(bevd_0);
case -1279784069: return bem_defined_1(bevd_0);
case -260783861: return bem_ownProcessSet_1(bevd_0);
case 526528225: return bem_platformSet_1(bevd_0);
case -1467862522: return bem_printAllAstSet_1(bevd_0);
case 560162357: return bem_compilerSet_1(bevd_0);
case -2085986340: return bem_emitPathSet_1(bevd_0);
case 693284506: return bem_doParse_1(bevd_0);
case 787847776: return bem_newlineSet_1(bevd_0);
case -818828886: return bem_compilerProfileSet_1(bevd_0);
case -706249818: return bem_getSynNp_1(bevd_0);
case -291583106: return bem_undef_1(bevd_0);
case 804613065: return bem_runSet_1(bevd_0);
case 581408689: return bem_equals_1(bevd_0);
case -392968773: return bem_printPlacesSet_1(bevd_0);
case 806119150: return bem_fromFileSet_1(bevd_0);
case -549675370: return bem_emitCommonSet_1(bevd_0);
case 857285779: return bem_closeLibrariesSet_1(bevd_0);
case 593264218: return bem_isNewish_1((BEC_2_4_6_TextString) bevd_0);
case 581336731: return bem_lctokSet_1(bevd_0);
case -389838008: return bem_estrSet_1(bevd_0);
case 882603336: return bem_deployPathSet_1(bevd_0);
}
return super.bemd_1(callHash, callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callHash, int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callHash) {
case 1634690506: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 681472468: return bem_buildLiteral_2(bevd_0, bevd_1);
case -868745802: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1127312076: return bem_nodify_2(bevd_0, (BEC_2_9_10_ContainerLinkedList) bevd_1);
case 94427011: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1965743813: return bem_getSyn_2(bevd_0, bevd_1);
case 443668842: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 636686891: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1775841977: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1567407836: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callHash, callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(11, becc_BEC_2_5_5_BuildBuild_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_5_5_BuildBuild_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_5_BuildBuild();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst = (BEC_2_5_5_BuildBuild) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_5_BuildBuild.bece_BEC_2_5_5_BuildBuild_bevs_inst;
}
}
