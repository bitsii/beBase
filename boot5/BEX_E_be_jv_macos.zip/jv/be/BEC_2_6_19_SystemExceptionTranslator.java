package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/ExtSystem.be */
public class BEC_2_6_19_SystemExceptionTranslator extends BEC_2_6_6_SystemObject {
public BEC_2_6_19_SystemExceptionTranslator() { }
private static byte[] becc_BEC_2_6_19_SystemExceptionTranslator_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x54,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_6_19_SystemExceptionTranslator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x74,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_0 = {0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x20,0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x66,0x61,0x69,0x6C,0x65,0x64};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_1 = {0x67,0x65,0x74,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_2 = {0x63,0x73};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_3 = {0x6A,0x73};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_4 = {0x0D,0x0A};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_5 = {0x46,0x72,0x61,0x6D,0x65,0x20,0x6C,0x69,0x6E,0x65,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_6 = {0x61,0x74,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_7 = {0x73,0x74,0x61,0x72,0x74,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_8 = {0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_9 = {0x65,0x6E,0x64,0x20,0x69,0x73,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_10 = {0x69,0x6E};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_11 = {0x3A};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_12 = {0x6C,0x69,0x6E,0x65,0x20};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_13 = {0x28};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_14 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x73,0x74,0x61,0x72,0x74,0x20,0x64,0x65,0x66};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_15 = {0x29};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_16 = {0x69,0x6E,0x20,0x6A,0x73,0x20,0x65,0x6E,0x64,0x20,0x64,0x65,0x66};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_17 = {0x2E};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_18 = {0x63,0x61,0x6C,0x6C,0x50,0x61,0x72,0x74,0x20,0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_19 = {0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_20 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6D,0x74,0x64,0x20,0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_21 = {0x42,0x45,0x43,0x5F};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_22 = {0x5F};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_23 = {0x70,0x72,0x65,0x20,0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_24 = {0x65,0x78,0x74,0x72,0x61,0x63,0x74,0x65,0x64,0x20,0x6B,0x6C,0x61,0x73,0x73,0x20,0x7C};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_25 = {0x61,0x64,0x64,0x69,0x6E,0x67,0x20,0x66,0x72,0x61,0x6D,0x65};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_26 = {0x6E,0x6F,0x20,0x65,0x6E,0x64};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_27 = {0x62,0x65};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_28 = {0x6A,0x76};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_29 = {0x74,0x72,0x61,0x6E,0x73,0x6C,0x61,0x74,0x69,0x6F,0x6E,0x20,0x64,0x6F,0x6E,0x65};
private static byte[] bece_BEC_2_6_19_SystemExceptionTranslator_bels_30 = {0x62,0x65,0x6D,0x5F};
public static BEC_2_6_19_SystemExceptionTranslator bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;

public static BET_2_6_19_SystemExceptionTranslator bece_BEC_2_6_19_SystemExceptionTranslator_bevs_type;

public BEC_2_6_19_SystemExceptionTranslator bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_19_SystemExceptionTranslator bem_translateEmittedException_1(BEC_2_6_9_SystemException beva_tt) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
try /* Line: 1062*/ {
bem_translateEmittedExceptionInner_1(beva_tt);
} /* Line: 1063*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevt_1_ta_ph = (new BEC_2_4_6_TextString(28, bece_BEC_2_6_19_SystemExceptionTranslator_bels_0));
bevt_1_ta_ph.bem_print_0();
if (bevl_e == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1066*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_19_SystemExceptionTranslator_bels_1));
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_3_ta_ph = bevl_e.bemd_2(-29663031, bevt_4_ta_ph, bevt_5_ta_ph);
if (((BEC_2_5_4_LogicBool) bevt_3_ta_ph).bevi_bool)/* Line: 1066*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1066*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1066*/
 else /* Line: 1066*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1066*/ {
bevt_6_ta_ph = bevl_e.bemd_0(224254783);
bevt_6_ta_ph.bemd_0(603718350);
} /* Line: 1067*/
} /* Line: 1066*/
return this;
} /*method end*/
public BEC_2_6_19_SystemExceptionTranslator bem_translateEmittedExceptionInner_1(BEC_2_6_9_SystemException beva_tt) throws Throwable {
BEC_2_4_9_TextTokenizer bevl_ltok = null;
BEC_2_9_10_ContainerLinkedList bevl_lines = null;
BEC_2_5_4_LogicBool bevl_isCs = null;
BEC_2_4_6_TextString bevl_line = null;
BEC_2_4_3_MathInt bevl_start = null;
BEC_2_4_6_TextString bevl_efile = null;
BEC_2_4_3_MathInt bevl_eline = null;
BEC_2_4_3_MathInt bevl_end = null;
BEC_2_4_6_TextString bevl_callPart = null;
BEC_2_4_6_TextString bevl_inPart = null;
BEC_2_4_3_MathInt bevl_pdelim = null;
BEC_2_4_6_TextString bevl_iv = null;
BEC_2_9_4_ContainerList bevl_parts = null;
BEC_2_4_6_TextString bevl_klass = null;
BEC_2_4_6_TextString bevl_mtd = null;
BEC_2_9_5_ExceptionFrame bevl_fr = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_loop = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_7_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_8_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_9_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_10_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_11_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_5_4_LogicBool bevt_19_ta_ph = null;
BEC_2_4_6_TextString bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_4_6_TextString bevt_22_ta_ph = null;
BEC_2_5_4_LogicBool bevt_23_ta_ph = null;
BEC_2_4_6_TextString bevt_24_ta_ph = null;
BEC_2_4_6_TextString bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_4_6_TextString bevt_27_ta_ph = null;
BEC_2_4_6_TextString bevt_28_ta_ph = null;
BEC_2_4_6_TextString bevt_29_ta_ph = null;
BEC_2_4_6_TextString bevt_30_ta_ph = null;
BEC_2_5_4_LogicBool bevt_31_ta_ph = null;
BEC_2_4_6_TextString bevt_32_ta_ph = null;
BEC_2_4_6_TextString bevt_33_ta_ph = null;
BEC_2_6_6_SystemObject bevt_34_ta_ph = null;
BEC_2_5_4_LogicBool bevt_35_ta_ph = null;
BEC_2_4_6_TextString bevt_36_ta_ph = null;
BEC_2_4_6_TextString bevt_37_ta_ph = null;
BEC_2_4_6_TextString bevt_38_ta_ph = null;
BEC_2_5_4_LogicBool bevt_39_ta_ph = null;
BEC_2_5_4_LogicBool bevt_40_ta_ph = null;
BEC_2_4_3_MathInt bevt_41_ta_ph = null;
BEC_2_5_4_LogicBool bevt_42_ta_ph = null;
BEC_2_4_6_TextString bevt_43_ta_ph = null;
BEC_2_4_6_TextString bevt_44_ta_ph = null;
BEC_2_4_6_TextString bevt_45_ta_ph = null;
BEC_2_4_3_MathInt bevt_46_ta_ph = null;
BEC_2_4_3_MathInt bevt_47_ta_ph = null;
BEC_2_5_4_LogicBool bevt_48_ta_ph = null;
BEC_2_5_4_LogicBool bevt_49_ta_ph = null;
BEC_2_5_4_LogicBool bevt_50_ta_ph = null;
BEC_2_4_6_TextString bevt_51_ta_ph = null;
BEC_2_4_6_TextString bevt_52_ta_ph = null;
BEC_2_4_3_MathInt bevt_53_ta_ph = null;
BEC_2_4_3_MathInt bevt_54_ta_ph = null;
BEC_2_4_6_TextString bevt_55_ta_ph = null;
BEC_2_5_4_LogicBool bevt_56_ta_ph = null;
BEC_2_4_3_MathInt bevt_57_ta_ph = null;
BEC_2_4_3_MathInt bevt_58_ta_ph = null;
BEC_2_5_4_LogicBool bevt_59_ta_ph = null;
BEC_2_4_6_TextString bevt_60_ta_ph = null;
BEC_2_4_3_MathInt bevt_61_ta_ph = null;
BEC_2_4_3_MathInt bevt_62_ta_ph = null;
BEC_2_4_3_MathInt bevt_63_ta_ph = null;
BEC_2_4_6_TextString bevt_64_ta_ph = null;
BEC_2_5_4_LogicBool bevt_65_ta_ph = null;
BEC_2_4_3_MathInt bevt_66_ta_ph = null;
BEC_2_4_3_MathInt bevt_67_ta_ph = null;
BEC_2_4_3_MathInt bevt_68_ta_ph = null;
BEC_2_5_4_LogicBool bevt_69_ta_ph = null;
BEC_2_4_6_TextString bevt_70_ta_ph = null;
BEC_2_4_3_MathInt bevt_71_ta_ph = null;
BEC_2_5_4_LogicBool bevt_72_ta_ph = null;
BEC_2_4_6_TextString bevt_73_ta_ph = null;
BEC_2_5_4_LogicBool bevt_74_ta_ph = null;
BEC_2_5_4_LogicBool bevt_75_ta_ph = null;
BEC_2_4_6_TextString bevt_76_ta_ph = null;
BEC_2_4_6_TextString bevt_77_ta_ph = null;
BEC_2_4_3_MathInt bevt_78_ta_ph = null;
BEC_2_4_3_MathInt bevt_79_ta_ph = null;
BEC_2_5_4_LogicBool bevt_80_ta_ph = null;
BEC_2_5_4_LogicBool bevt_81_ta_ph = null;
BEC_2_4_6_TextString bevt_82_ta_ph = null;
BEC_2_4_3_MathInt bevt_83_ta_ph = null;
BEC_2_4_3_MathInt bevt_84_ta_ph = null;
BEC_2_4_6_TextString bevt_85_ta_ph = null;
BEC_2_5_4_LogicBool bevt_86_ta_ph = null;
BEC_2_4_3_MathInt bevt_87_ta_ph = null;
BEC_2_4_6_TextString bevt_88_ta_ph = null;
BEC_2_5_4_LogicBool bevt_89_ta_ph = null;
BEC_2_4_3_MathInt bevt_90_ta_ph = null;
BEC_2_4_3_MathInt bevt_91_ta_ph = null;
BEC_2_4_3_MathInt bevt_92_ta_ph = null;
BEC_2_5_4_LogicBool bevt_93_ta_ph = null;
BEC_2_4_6_TextString bevt_94_ta_ph = null;
BEC_2_4_3_MathInt bevt_95_ta_ph = null;
BEC_2_4_3_MathInt bevt_96_ta_ph = null;
BEC_2_5_4_LogicBool bevt_97_ta_ph = null;
BEC_2_5_4_LogicBool bevt_98_ta_ph = null;
BEC_2_4_3_MathInt bevt_99_ta_ph = null;
BEC_2_4_3_MathInt bevt_100_ta_ph = null;
BEC_2_4_3_MathInt bevt_101_ta_ph = null;
BEC_2_4_3_MathInt bevt_102_ta_ph = null;
BEC_2_5_4_LogicBool bevt_103_ta_ph = null;
BEC_2_4_6_TextString bevt_104_ta_ph = null;
BEC_2_4_3_MathInt bevt_105_ta_ph = null;
BEC_2_4_3_MathInt bevt_106_ta_ph = null;
BEC_2_4_6_TextString bevt_107_ta_ph = null;
BEC_2_4_6_TextString bevt_108_ta_ph = null;
BEC_2_5_4_LogicBool bevt_109_ta_ph = null;
BEC_2_4_6_TextString bevt_110_ta_ph = null;
BEC_2_4_6_TextString bevt_111_ta_ph = null;
BEC_2_4_6_TextString bevt_112_ta_ph = null;
BEC_2_4_6_TextString bevt_113_ta_ph = null;
BEC_2_4_6_TextString bevt_114_ta_ph = null;
BEC_2_5_4_LogicBool bevt_115_ta_ph = null;
BEC_2_4_3_MathInt bevt_116_ta_ph = null;
BEC_2_4_3_MathInt bevt_117_ta_ph = null;
BEC_2_5_4_LogicBool bevt_118_ta_ph = null;
BEC_2_4_3_MathInt bevt_119_ta_ph = null;
BEC_2_4_3_MathInt bevt_120_ta_ph = null;
BEC_2_4_3_MathInt bevt_121_ta_ph = null;
BEC_2_4_3_MathInt bevt_122_ta_ph = null;
BEC_2_4_3_MathInt bevt_123_ta_ph = null;
BEC_2_4_3_MathInt bevt_124_ta_ph = null;
BEC_2_5_4_LogicBool bevt_125_ta_ph = null;
BEC_2_4_6_TextString bevt_126_ta_ph = null;
BEC_2_4_6_TextString bevt_127_ta_ph = null;
BEC_2_4_6_TextString bevt_128_ta_ph = null;
BEC_2_4_6_TextString bevt_129_ta_ph = null;
BEC_2_4_6_TextString bevt_130_ta_ph = null;
BEC_2_5_4_LogicBool bevt_131_ta_ph = null;
BEC_2_5_4_LogicBool bevt_132_ta_ph = null;
BEC_2_4_3_MathInt bevt_133_ta_ph = null;
BEC_2_4_6_TextString bevt_134_ta_ph = null;
BEC_2_4_3_MathInt bevt_135_ta_ph = null;
BEC_2_4_3_MathInt bevt_136_ta_ph = null;
BEC_2_5_4_LogicBool bevt_137_ta_ph = null;
BEC_2_5_4_LogicBool bevt_138_ta_ph = null;
BEC_2_4_3_MathInt bevt_139_ta_ph = null;
BEC_2_5_4_LogicBool bevt_140_ta_ph = null;
BEC_2_4_6_TextString bevt_141_ta_ph = null;
BEC_2_4_6_TextString bevt_142_ta_ph = null;
BEC_2_4_6_TextString bevt_143_ta_ph = null;
BEC_2_4_6_TextString bevt_144_ta_ph = null;
BEC_2_5_4_LogicBool bevt_145_ta_ph = null;
BEC_2_4_6_TextString bevt_146_ta_ph = null;
BEC_2_4_6_TextString bevt_147_ta_ph = null;
BEC_2_4_6_TextString bevt_148_ta_ph = null;
BEC_2_4_6_TextString bevt_149_ta_ph = null;
BEC_2_4_6_TextString bevt_150_ta_ph = null;
BEC_2_4_6_TextString bevt_151_ta_ph = null;
BEC_2_5_4_LogicBool bevt_152_ta_ph = null;
BEC_2_4_6_TextString bevt_153_ta_ph = null;
BEC_2_5_4_LogicBool bevt_154_ta_ph = null;
BEC_2_4_6_TextString bevt_155_ta_ph = null;
BEC_2_4_6_TextString bevt_156_ta_ph = null;
BEC_2_4_6_TextString bevt_157_ta_ph = null;
BEC_2_5_4_LogicBool bevt_158_ta_ph = null;
BEC_2_9_4_ContainerList bevt_159_ta_ph = null;
BEC_2_5_4_LogicBool bevt_160_ta_ph = null;
BEC_2_4_6_TextString bevt_161_ta_ph = null;
BEC_2_5_4_LogicBool bevt_162_ta_ph = null;
BEC_2_4_6_TextString bevt_163_ta_ph = null;
BEC_2_4_6_TextString bevt_164_ta_ph = null;
BEC_2_9_4_ContainerList bevt_165_ta_ph = null;
BEC_2_6_6_SystemObject bevt_166_ta_ph = null;
BEC_2_4_6_TextString bevt_167_ta_ph = null;
BEC_2_4_6_TextString bevt_168_ta_ph = null;
BEC_2_4_6_TextString bevt_169_ta_ph = null;
BEC_2_4_6_TextString bevt_170_ta_ph = null;
BEC_2_4_6_TextString bevt_171_ta_ph = null;
BEC_2_4_6_TextString bevt_172_ta_ph = null;
BEC_2_4_6_TextString bevt_173_ta_ph = null;
BEC_2_4_6_TextString bevt_174_ta_ph = null;
BEC_2_5_4_LogicBool bevt_175_ta_ph = null;
BEC_2_4_6_TextString bevt_176_ta_ph = null;
bevt_13_ta_ph = beva_tt.bem_translatedGet_0();
if (bevt_13_ta_ph == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 1074*/ {
bevt_14_ta_ph = beva_tt.bem_translatedGet_0();
if (bevt_14_ta_ph.bevi_bool)/* Line: 1074*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1074*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1074*/
 else /* Line: 1074*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 1074*/ {
return this;
} /* Line: 1075*/
bevt_16_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_16_ta_ph == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 1077*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
beva_tt.bem_vvSet_1(bevt_17_ta_ph);
} /* Line: 1078*/
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
beva_tt.bem_translatedSet_1(bevt_18_ta_ph);
bevt_20_ta_ph = beva_tt.bem_framesTextGet_0();
if (bevt_20_ta_ph == null) {
bevt_19_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_19_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_19_ta_ph.bevi_bool)/* Line: 1081*/ {
bevt_22_ta_ph = beva_tt.bem_langGet_0();
if (bevt_22_ta_ph == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 1081*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1081*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1081*/
 else /* Line: 1081*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 1081*/ {
bevt_24_ta_ph = beva_tt.bem_langGet_0();
bevt_25_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_2));
bevt_23_ta_ph = bevt_24_ta_ph.bem_equals_1(bevt_25_ta_ph);
if (bevt_23_ta_ph.bevi_bool)/* Line: 1081*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1081*/ {
bevt_27_ta_ph = beva_tt.bem_langGet_0();
bevt_28_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_3));
bevt_26_ta_ph = bevt_27_ta_ph.bem_equals_1(bevt_28_ta_ph);
if (bevt_26_ta_ph.bevi_bool)/* Line: 1081*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1081*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1081*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 1081*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1081*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1081*/
 else /* Line: 1081*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 1081*/ {
bevt_29_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_4));
bevl_ltok = (new BEC_2_4_9_TextTokenizer()).bem_new_1(bevt_29_ta_ph);
bevt_30_ta_ph = beva_tt.bem_framesTextGet_0();
bevl_lines = (BEC_2_9_10_ContainerLinkedList) bevl_ltok.bem_tokenize_1(bevt_30_ta_ph);
bevt_32_ta_ph = beva_tt.bem_langGet_0();
bevt_33_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_2));
bevt_31_ta_ph = bevt_32_ta_ph.bem_equals_1(bevt_33_ta_ph);
if (bevt_31_ta_ph.bevi_bool)/* Line: 1084*/ {
bevl_isCs = be.BECS_Runtime.boolTrue;
} /* Line: 1085*/
 else /* Line: 1086*/ {
bevl_isCs = be.BECS_Runtime.boolFalse;
} /* Line: 1087*/
bevt_0_ta_loop = bevl_lines.bem_linkedListIteratorGet_0();
while (true)
/* Line: 1089*/ {
bevt_34_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_34_ta_ph).bevi_bool)/* Line: 1089*/ {
bevl_line = (BEC_2_4_6_TextString) bevt_0_ta_loop.bem_nextGet_0();
bevt_35_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_35_ta_ph.bevi_bool)/* Line: 1090*/ {
bevt_37_ta_ph = (new BEC_2_4_6_TextString(14, bece_BEC_2_6_19_SystemExceptionTranslator_bels_5));
bevt_36_ta_ph = bevt_37_ta_ph.bem_add_1(bevl_line);
bevt_36_ta_ph.bem_print_0();
} /* Line: 1091*/
bevt_38_ta_ph = (new BEC_2_4_6_TextString(3, bece_BEC_2_6_19_SystemExceptionTranslator_bels_6));
bevl_start = bevl_line.bem_find_1(bevt_38_ta_ph);
bevl_efile = null;
bevl_eline = null;
if (bevl_start == null) {
bevt_39_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_39_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_39_ta_ph.bevi_bool)/* Line: 1096*/ {
bevt_41_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_start.bevi_int >= bevt_41_ta_ph.bevi_int) {
bevt_40_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_40_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_40_ta_ph.bevi_bool)/* Line: 1096*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1096*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1096*/
 else /* Line: 1096*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 1096*/ {
bevt_42_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_42_ta_ph.bevi_bool)/* Line: 1097*/ {
bevt_44_ta_ph = (new BEC_2_4_6_TextString(9, bece_BEC_2_6_19_SystemExceptionTranslator_bels_7));
bevt_43_ta_ph = bevt_44_ta_ph.bem_add_1(bevl_start);
bevt_43_ta_ph.bem_print_0();
} /* Line: 1098*/
bevt_45_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_8));
bevt_47_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_46_ta_ph = bevl_start.bem_add_1(bevt_47_ta_ph);
bevl_end = bevl_line.bem_find_2(bevt_45_ta_ph, bevt_46_ta_ph);
if (bevl_end == null) {
bevt_48_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_48_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_48_ta_ph.bevi_bool)/* Line: 1101*/ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_49_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_49_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_49_ta_ph.bevi_bool)/* Line: 1101*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1101*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1101*/
 else /* Line: 1101*/ {
bevt_6_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_6_ta_anchor.bevi_bool)/* Line: 1101*/ {
bevt_50_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_50_ta_ph.bevi_bool)/* Line: 1102*/ {
bevt_52_ta_ph = (new BEC_2_4_6_TextString(7, bece_BEC_2_6_19_SystemExceptionTranslator_bels_9));
bevt_51_ta_ph = bevt_52_ta_ph.bem_add_1(bevl_end);
bevt_51_ta_ph.bem_print_0();
} /* Line: 1103*/
bevt_54_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_53_ta_ph = bevl_start.bem_add_1(bevt_54_ta_ph);
bevl_callPart = bevl_line.bem_substring_2(bevt_53_ta_ph, bevl_end);
if (bevl_isCs.bevi_bool)/* Line: 1107*/ {
bevt_55_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_10));
bevl_start = bevl_line.bem_find_2(bevt_55_ta_ph, bevl_end);
if (bevl_start == null) {
bevt_56_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_56_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_56_ta_ph.bevi_bool)/* Line: 1109*/ {
bevt_58_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_57_ta_ph = bevl_start.bem_add_1(bevt_58_ta_ph);
bevl_inPart = bevl_line.bem_substring_1(bevt_57_ta_ph);
bevt_60_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_8));
bevt_59_ta_ph = bevl_inPart.bem_ends_1(bevt_60_ta_ph);
if (bevt_59_ta_ph.bevi_bool)/* Line: 1112*/ {
bevt_62_ta_ph = bevl_inPart.bem_sizeGet_0();
bevt_63_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_61_ta_ph = bevt_62_ta_ph.bem_subtract_1(bevt_63_ta_ph);
bevl_inPart.bem_sizeSet_1(bevt_61_ta_ph);
} /* Line: 1113*/
bevt_64_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_11));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_64_ta_ph);
if (bevl_pdelim == null) {
bevt_65_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_65_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_65_ta_ph.bevi_bool)/* Line: 1117*/ {
bevt_66_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_efile = bevl_inPart.bem_substring_2(bevt_66_ta_ph, bevl_pdelim);
bevt_68_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_67_ta_ph = bevl_pdelim.bem_add_1(bevt_68_ta_ph);
bevl_iv = bevl_inPart.bem_substring_1(bevt_67_ta_ph);
bevt_70_ta_ph = (new BEC_2_4_6_TextString(5, bece_BEC_2_6_19_SystemExceptionTranslator_bels_12));
bevt_69_ta_ph = bevl_iv.bem_begins_1(bevt_70_ta_ph);
if (bevt_69_ta_ph.bevi_bool)/* Line: 1121*/ {
bevt_71_ta_ph = (new BEC_2_4_3_MathInt(5));
bevl_iv = bevl_iv.bem_substring_1(bevt_71_ta_ph);
} /* Line: 1122*/
bevt_72_ta_ph = bevl_iv.bem_isInteger_0();
if (bevt_72_ta_ph.bevi_bool)/* Line: 1125*/ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 1126*/
} /* Line: 1125*/
} /* Line: 1117*/
} /* Line: 1109*/
 else /* Line: 1130*/ {
bevt_73_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_13));
bevl_start = bevl_line.bem_find_2(bevt_73_ta_ph, bevl_end);
if (bevl_start == null) {
bevt_74_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_74_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_74_ta_ph.bevi_bool)/* Line: 1132*/ {
bevt_75_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_75_ta_ph.bevi_bool)/* Line: 1133*/ {
bevt_76_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_19_SystemExceptionTranslator_bels_14));
bevt_76_ta_ph.bem_print_0();
} /* Line: 1134*/
bevt_77_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_15));
bevt_79_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_78_ta_ph = bevl_start.bem_add_1(bevt_79_ta_ph);
bevl_end = bevl_line.bem_find_2(bevt_77_ta_ph, bevt_78_ta_ph);
if (bevl_end == null) {
bevt_80_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_80_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_80_ta_ph.bevi_bool)/* Line: 1138*/ {
bevt_81_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_81_ta_ph.bevi_bool)/* Line: 1139*/ {
bevt_82_ta_ph = (new BEC_2_4_6_TextString(13, bece_BEC_2_6_19_SystemExceptionTranslator_bels_16));
bevt_82_ta_ph.bem_print_0();
} /* Line: 1140*/
bevt_84_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_83_ta_ph = bevl_start.bem_add_1(bevt_84_ta_ph);
bevl_inPart = bevl_line.bem_substring_2(bevt_83_ta_ph, bevl_end);
bevt_85_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_11));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_85_ta_ph);
if (bevl_pdelim == null) {
bevt_86_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_86_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_86_ta_ph.bevi_bool)/* Line: 1145*/ {
bevt_87_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_inPart = bevl_inPart.bem_substring_2(bevt_87_ta_ph, bevl_pdelim);
bevt_88_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_11));
bevl_pdelim = bevl_inPart.bem_rfind_1(bevt_88_ta_ph);
if (bevl_pdelim == null) {
bevt_89_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_89_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_89_ta_ph.bevi_bool)/* Line: 1149*/ {
bevt_90_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_efile = bevl_inPart.bem_substring_2(bevt_90_ta_ph, bevl_pdelim);
} /* Line: 1150*/
bevt_92_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_91_ta_ph = bevl_pdelim.bem_add_1(bevt_92_ta_ph);
bevl_iv = bevl_inPart.bem_substring_1(bevt_91_ta_ph);
bevt_93_ta_ph = bevl_iv.bem_isInteger_0();
if (bevt_93_ta_ph.bevi_bool)/* Line: 1154*/ {
bevl_eline = (new BEC_2_4_3_MathInt()).bem_new_1(bevl_iv);
} /* Line: 1155*/
} /* Line: 1154*/
} /* Line: 1145*/
} /* Line: 1138*/
} /* Line: 1132*/
} /* Line: 1107*/
 else /* Line: 1161*/ {
bevt_94_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_13));
bevt_96_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_95_ta_ph = bevl_start.bem_add_1(bevt_96_ta_ph);
bevl_end = bevl_line.bem_find_2(bevt_94_ta_ph, bevt_95_ta_ph);
if (bevl_end == null) {
bevt_97_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_97_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_97_ta_ph.bevi_bool)/* Line: 1163*/ {
if (bevl_end.bevi_int > bevl_start.bevi_int) {
bevt_98_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_98_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_98_ta_ph.bevi_bool)/* Line: 1163*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1163*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1163*/
 else /* Line: 1163*/ {
bevt_7_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_7_ta_anchor.bevi_bool)/* Line: 1163*/ {
bevt_100_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_99_ta_ph = bevl_start.bem_add_1(bevt_100_ta_ph);
bevl_callPart = bevl_line.bem_substring_2(bevt_99_ta_ph, bevl_end);
} /* Line: 1164*/
 else /* Line: 1165*/ {
bevt_102_ta_ph = (new BEC_2_4_3_MathInt(3));
bevt_101_ta_ph = bevl_start.bem_add_1(bevt_102_ta_ph);
bevl_callPart = bevl_line.bem_substring_1(bevt_101_ta_ph);
} /* Line: 1166*/
} /* Line: 1163*/
if (bevl_callPart == null) {
bevt_103_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_103_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_103_ta_ph.bevi_bool)/* Line: 1169*/ {
if (bevl_isCs.bevi_bool)/* Line: 1170*/ {
bevt_104_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_17));
bevl_parts = bevl_callPart.bem_split_1(bevt_104_ta_ph);
bevt_105_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_105_ta_ph);
bevt_106_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_106_ta_ph);
bevl_klass = bem_extractKlass_1(bevl_klass);
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_108_ta_ph = bevl_fr.bem_klassNameGet_0();
bevt_107_ta_ph = bem_getSourceFileName_1(bevt_108_ta_ph);
bevl_fr.bem_fileNameSet_1(bevt_107_ta_ph);
beva_tt.bem_addFrame_1(bevl_fr);
} /* Line: 1183*/
 else /* Line: 1184*/ {
bevt_109_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_109_ta_ph.bevi_bool)/* Line: 1186*/ {
bevt_112_ta_ph = (new BEC_2_4_6_TextString(10, bece_BEC_2_6_19_SystemExceptionTranslator_bels_18));
bevt_111_ta_ph = bevt_112_ta_ph.bem_add_1(bevl_callPart);
bevt_113_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_19));
bevt_110_ta_ph = bevt_111_ta_ph.bem_add_1(bevt_113_ta_ph);
bevt_110_ta_ph.bem_print_0();
} /* Line: 1187*/
bevt_114_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_17));
bevl_parts = bevl_callPart.bem_split_1(bevt_114_ta_ph);
bevt_116_ta_ph = bevl_parts.bem_sizeGet_0();
bevt_117_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_116_ta_ph.bevi_int > bevt_117_ta_ph.bevi_int) {
bevt_115_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_115_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_115_ta_ph.bevi_bool)/* Line: 1190*/ {
bevt_119_ta_ph = bevl_parts.bem_sizeGet_0();
bevt_120_ta_ph = (new BEC_2_4_3_MathInt(2));
if (bevt_119_ta_ph.bevi_int > bevt_120_ta_ph.bevi_int) {
bevt_118_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_118_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_118_ta_ph.bevi_bool)/* Line: 1191*/ {
bevt_121_ta_ph = (new BEC_2_4_3_MathInt(2));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_121_ta_ph);
bevt_122_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_122_ta_ph);
} /* Line: 1193*/
 else /* Line: 1194*/ {
bevt_123_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_mtd = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_123_ta_ph);
bevt_124_ta_ph = (new BEC_2_4_3_MathInt(0));
bevl_klass = (BEC_2_4_6_TextString) bevl_parts.bem_get_1(bevt_124_ta_ph);
} /* Line: 1196*/
bevl_mtd = bem_extractMethod_1(bevl_mtd);
bevt_125_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_125_ta_ph.bevi_bool)/* Line: 1199*/ {
bevt_128_ta_ph = (new BEC_2_4_6_TextString(15, bece_BEC_2_6_19_SystemExceptionTranslator_bels_20));
bevt_127_ta_ph = bevt_128_ta_ph.bem_add_1(bevl_mtd);
bevt_129_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_19));
bevt_126_ta_ph = bevt_127_ta_ph.bem_add_1(bevt_129_ta_ph);
bevt_126_ta_ph.bem_print_0();
} /* Line: 1200*/
bevt_130_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_19_SystemExceptionTranslator_bels_21));
bevl_start = bevl_klass.bem_find_1(bevt_130_ta_ph);
if (bevl_start == null) {
bevt_131_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_131_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_131_ta_ph.bevi_bool)/* Line: 1203*/ {
bevt_133_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_start.bevi_int > bevt_133_ta_ph.bevi_int) {
bevt_132_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_132_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_132_ta_ph.bevi_bool)/* Line: 1203*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1203*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1203*/
 else /* Line: 1203*/ {
bevt_8_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_8_ta_anchor.bevi_bool)/* Line: 1203*/ {
bevt_134_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_22));
bevt_136_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_135_ta_ph = bevl_start.bem_add_1(bevt_136_ta_ph);
bevl_end = bevl_klass.bem_find_2(bevt_134_ta_ph, bevt_135_ta_ph);
if (bevl_end == null) {
bevt_137_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_137_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_137_ta_ph.bevi_bool)/* Line: 1205*/ {
bevt_139_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevl_end.bevi_int > bevt_139_ta_ph.bevi_int) {
bevt_138_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_138_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_138_ta_ph.bevi_bool)/* Line: 1205*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1205*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1205*/
 else /* Line: 1205*/ {
bevt_9_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_9_ta_anchor.bevi_bool)/* Line: 1205*/ {
bevl_klass = bevl_klass.bem_substring_1(bevl_start);
bevt_140_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_140_ta_ph.bevi_bool)/* Line: 1210*/ {
bevt_143_ta_ph = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_19_SystemExceptionTranslator_bels_23));
bevt_142_ta_ph = bevt_143_ta_ph.bem_add_1(bevl_klass);
bevt_144_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_19));
bevt_141_ta_ph = bevt_142_ta_ph.bem_add_1(bevt_144_ta_ph);
bevt_141_ta_ph.bem_print_0();
} /* Line: 1211*/
bevl_klass = bem_extractKlass_1(bevl_klass);
bevt_145_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_145_ta_ph.bevi_bool)/* Line: 1214*/ {
bevt_148_ta_ph = (new BEC_2_4_6_TextString(17, bece_BEC_2_6_19_SystemExceptionTranslator_bels_24));
bevt_147_ta_ph = bevt_148_ta_ph.bem_add_1(bevl_klass);
bevt_149_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_19));
bevt_146_ta_ph = bevt_147_ta_ph.bem_add_1(bevt_149_ta_ph);
bevt_146_ta_ph.bem_print_0();
} /* Line: 1215*/
bevl_fr = (new BEC_2_9_5_ExceptionFrame()).bem_new_4(bevl_klass, bevl_mtd, bevl_efile, bevl_eline);
bevt_151_ta_ph = bevl_fr.bem_klassNameGet_0();
bevt_150_ta_ph = bem_getSourceFileName_1(bevt_151_ta_ph);
bevl_fr.bem_fileNameSet_1(bevt_150_ta_ph);
bevt_152_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_152_ta_ph.bevi_bool)/* Line: 1219*/ {
bevt_153_ta_ph = (new BEC_2_4_6_TextString(12, bece_BEC_2_6_19_SystemExceptionTranslator_bels_25));
bevt_153_ta_ph.bem_print_0();
} /* Line: 1220*/
beva_tt.bem_addFrame_1(bevl_fr);
} /* Line: 1222*/
 else /* Line: 1223*/ {
bevt_154_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_154_ta_ph.bevi_bool)/* Line: 1224*/ {
bevt_155_ta_ph = (new BEC_2_4_6_TextString(6, bece_BEC_2_6_19_SystemExceptionTranslator_bels_26));
bevt_155_ta_ph.bem_print_0();
} /* Line: 1225*/
} /* Line: 1224*/
} /* Line: 1205*/
} /* Line: 1203*/
} /* Line: 1190*/
} /* Line: 1170*/
} /* Line: 1169*/
} /* Line: 1096*/
 else /* Line: 1089*/ {
break;
} /* Line: 1089*/
} /* Line: 1089*/
bevt_156_ta_ph = beva_tt.bem_langGet_0();
beva_tt.bem_emitLangSet_1(bevt_156_ta_ph);
bevt_157_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_27));
beva_tt.bem_langSet_1(bevt_157_ta_ph);
beva_tt.bem_framesTextSet_1(null);
} /* Line: 1236*/
 else /* Line: 1081*/ {
bevt_159_ta_ph = beva_tt.bem_framesGet_0();
if (bevt_159_ta_ph == null) {
bevt_158_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_158_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_158_ta_ph.bevi_bool)/* Line: 1237*/ {
bevt_161_ta_ph = beva_tt.bem_langGet_0();
if (bevt_161_ta_ph == null) {
bevt_160_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_160_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_160_ta_ph.bevi_bool)/* Line: 1237*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1237*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1237*/
 else /* Line: 1237*/ {
bevt_11_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_11_ta_anchor.bevi_bool)/* Line: 1237*/ {
bevt_163_ta_ph = beva_tt.bem_langGet_0();
bevt_164_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_28));
bevt_162_ta_ph = bevt_163_ta_ph.bem_equals_1(bevt_164_ta_ph);
if (bevt_162_ta_ph.bevi_bool)/* Line: 1237*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1237*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1237*/
 else /* Line: 1237*/ {
bevt_10_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_10_ta_anchor.bevi_bool)/* Line: 1237*/ {
bevt_165_ta_ph = beva_tt.bem_framesGet_0();
bevt_1_ta_loop = bevt_165_ta_ph.bem_iteratorGet_0();
while (true)
/* Line: 1238*/ {
bevt_166_ta_ph = bevt_1_ta_loop.bemd_0(-1510018049);
if (((BEC_2_5_4_LogicBool) bevt_166_ta_ph).bevi_bool)/* Line: 1238*/ {
bevl_fr = (BEC_2_9_5_ExceptionFrame) bevt_1_ta_loop.bemd_0(1658565917);
bevt_168_ta_ph = bevl_fr.bem_klassNameGet_0();
bevt_167_ta_ph = bem_extractKlassLib_1(bevt_168_ta_ph);
bevl_fr.bem_klassNameSet_1(bevt_167_ta_ph);
bevt_170_ta_ph = bevl_fr.bem_methodNameGet_0();
bevt_169_ta_ph = bem_extractMethod_1(bevt_170_ta_ph);
bevl_fr.bem_methodNameSet_1(bevt_169_ta_ph);
bevt_172_ta_ph = bevl_fr.bem_klassNameGet_0();
bevt_171_ta_ph = bem_getSourceFileName_1(bevt_172_ta_ph);
bevl_fr.bem_fileNameSet_1(bevt_171_ta_ph);
/* Line: 1242*/ {
bevl_fr.bem_extractLine_0();
} /* Line: 1243*/
} /* Line: 1242*/
 else /* Line: 1238*/ {
break;
} /* Line: 1238*/
} /* Line: 1238*/
bevt_173_ta_ph = beva_tt.bem_langGet_0();
beva_tt.bem_emitLangSet_1(bevt_173_ta_ph);
bevt_174_ta_ph = (new BEC_2_4_6_TextString(2, bece_BEC_2_6_19_SystemExceptionTranslator_bels_27));
beva_tt.bem_langSet_1(bevt_174_ta_ph);
} /* Line: 1247*/
 else /* Line: 1248*/ {
} /* Line: 1248*/
} /* Line: 1081*/
bevt_175_ta_ph = beva_tt.bem_vvGet_0();
if (bevt_175_ta_ph.bevi_bool)/* Line: 1251*/ {
bevt_176_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_19_SystemExceptionTranslator_bels_29));
bevt_176_ta_ph.bem_print_0();
} /* Line: 1252*/
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_getSourceFileName_1(BEC_2_4_6_TextString beva_klassName) throws Throwable {
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_3_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
bevl_i = bem_createInstance_2(beva_klassName, bevt_0_ta_ph);
if (bevl_i == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1259*/ {
bevt_3_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sourceFileName_1(bevl_i);
return bevt_2_ta_ph;
} /* Line: 1261*/
return null;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassLib_1(BEC_2_4_6_TextString beva_callPart) throws Throwable {
BEC_2_9_4_ContainerList bevl_parts = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_17));
bevl_parts = beva_callPart.bem_split_1(bevt_0_ta_ph);
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_2_ta_ph = bevl_parts.bem_get_1(bevt_3_ta_ph);
bevt_1_ta_ph = bem_extractKlass_1((BEC_2_4_6_TextString) bevt_2_ta_ph );
return bevt_1_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlass_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_6_TextString bevt_0_ta_ph = null;
try /* Line: 1275*/ {
bevt_0_ta_ph = bem_extractKlassInner_1(beva_klass);
return bevt_0_ta_ph;
} /* Line: 1276*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
} /* Line: 1277*/
return beva_klass;
} /*method end*/
public BEC_2_4_6_TextString bem_extractKlassInner_1(BEC_2_4_6_TextString beva_klass) throws Throwable {
BEC_2_9_4_ContainerList bevl_kparts = null;
BEC_2_4_3_MathInt bevl_kps = null;
BEC_2_4_6_TextString bevl_rawkl = null;
BEC_2_4_6_TextString bevl_bec = null;
BEC_2_4_3_MathInt bevl_sofar = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_4_3_MathInt bevl_len = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_4_6_TextString bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
BEC_2_4_3_MathInt bevt_16_ta_ph = null;
BEC_2_4_6_TextString bevt_17_ta_ph = null;
if (beva_klass == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1284*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_19_SystemExceptionTranslator_bels_21));
bevt_3_ta_ph = beva_klass.bem_begins_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1284*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1284*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1284*/ {
return beva_klass;
} /* Line: 1285*/
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(6));
bevt_5_ta_ph = beva_klass.bem_substring_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_22));
bevl_kparts = bevt_5_ta_ph.bem_split_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_kparts.bem_sizeGet_0();
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_kps = bevt_8_ta_ph.bem_subtract_1(bevt_9_ta_ph);
bevl_rawkl = (BEC_2_4_6_TextString) bevl_kparts.bem_get_1(bevl_kps);
bevl_bec = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_sofar = (new BEC_2_4_3_MathInt(0));
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1292*/ {
if (bevl_i.bevi_int < bevl_kps.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1292*/ {
bevt_11_ta_ph = bevl_kparts.bem_get_1(bevl_i);
bevl_len = (new BEC_2_4_3_MathInt()).bem_new_1(bevt_11_ta_ph);
bevt_13_ta_ph = bevl_sofar.bem_add_1(bevl_len);
bevt_12_ta_ph = bevl_rawkl.bem_substring_2(bevl_sofar, bevt_13_ta_ph);
bevl_bec.bem_addValue_1(bevt_12_ta_ph);
bevt_16_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_15_ta_ph = bevl_i.bem_add_1(bevt_16_ta_ph);
if (bevt_15_ta_ph.bevi_int < bevl_kps.bevi_int) {
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 1296*/ {
bevt_17_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_11));
bevl_bec.bem_addValue_1(bevt_17_ta_ph);
} /* Line: 1296*/
bevl_sofar.bevi_int += bevl_len.bevi_int;
bevl_i.bevi_int++;
} /* Line: 1292*/
 else /* Line: 1292*/ {
break;
} /* Line: 1292*/
} /* Line: 1292*/
return bevl_bec;
} /*method end*/
public BEC_2_4_6_TextString bem_extractMethod_1(BEC_2_4_6_TextString beva_mtd) throws Throwable {
BEC_2_9_4_ContainerList bevl_mparts = null;
BEC_2_4_3_MathInt bevl_mps = null;
BEC_2_4_6_TextString bevl_bem = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_6_TextString bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_6_TextString bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_6_6_SystemObject bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_6_TextString bevt_15_ta_ph = null;
if (beva_mtd == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1304*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1304*/ {
bevt_4_ta_ph = (new BEC_2_4_6_TextString(4, bece_BEC_2_6_19_SystemExceptionTranslator_bels_30));
bevt_3_ta_ph = beva_mtd.bem_begins_1(bevt_4_ta_ph);
if (bevt_3_ta_ph.bevi_bool) {
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1304*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1304*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1304*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1304*/ {
return beva_mtd;
} /* Line: 1305*/
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(4));
bevt_5_ta_ph = beva_mtd.bem_substring_1(bevt_6_ta_ph);
bevt_7_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_22));
bevl_mparts = bevt_5_ta_ph.bem_split_1(bevt_7_ta_ph);
bevt_8_ta_ph = bevl_mparts.bem_sizeGet_0();
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(1));
bevl_mps = bevt_8_ta_ph.bem_subtract_1(bevt_9_ta_ph);
bevl_bem = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 1310*/ {
if (bevl_i.bevi_int < bevl_mps.bevi_int) {
bevt_10_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_10_ta_ph.bevi_bool)/* Line: 1310*/ {
bevt_11_ta_ph = bevl_mparts.bem_get_1(bevl_i);
bevl_bem.bem_addValue_1(bevt_11_ta_ph);
bevt_14_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_13_ta_ph = bevl_i.bem_add_1(bevt_14_ta_ph);
if (bevt_13_ta_ph.bevi_int < bevl_mps.bevi_int) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 1312*/ {
bevt_15_ta_ph = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_19_SystemExceptionTranslator_bels_22));
bevl_bem.bem_addValue_1(bevt_15_ta_ph);
} /* Line: 1312*/
bevl_i.bevi_int++;
} /* Line: 1310*/
 else /* Line: 1310*/ {
break;
} /* Line: 1310*/
} /* Line: 1310*/
return bevl_bem;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1063, 1065, 1065, 1066, 1066, 1066, 1066, 1066, 0, 0, 0, 1067, 1067, 1074, 1074, 1074, 1074, 0, 0, 0, 1075, 1077, 1077, 1077, 1078, 1078, 1080, 1080, 1081, 1081, 1081, 1081, 1081, 1081, 0, 0, 0, 1081, 1081, 1081, 0, 1081, 1081, 1081, 0, 0, 0, 0, 0, 1082, 1082, 1083, 1083, 1084, 1084, 1084, 1085, 1087, 1089, 0, 1089, 1089, 1090, 1091, 1091, 1091, 1093, 1093, 1094, 1095, 1096, 1096, 1096, 1096, 1096, 0, 0, 0, 1097, 1098, 1098, 1098, 1100, 1100, 1100, 1100, 1101, 1101, 1101, 1101, 0, 0, 0, 1102, 1103, 1103, 1103, 1105, 1105, 1105, 1108, 1108, 1109, 1109, 1111, 1111, 1111, 1112, 1112, 1113, 1113, 1113, 1113, 1116, 1116, 1117, 1117, 1118, 1118, 1120, 1120, 1120, 1121, 1121, 1122, 1122, 1125, 1126, 1131, 1131, 1132, 1132, 1133, 1134, 1134, 1137, 1137, 1137, 1137, 1138, 1138, 1139, 1140, 1140, 1142, 1142, 1142, 1144, 1144, 1145, 1145, 1146, 1146, 1148, 1148, 1149, 1149, 1150, 1150, 1152, 1152, 1152, 1154, 1155, 1162, 1162, 1162, 1162, 1163, 1163, 1163, 1163, 0, 0, 0, 1164, 1164, 1164, 1166, 1166, 1166, 1169, 1169, 1172, 1172, 1174, 1174, 1175, 1175, 1177, 1179, 1181, 1182, 1182, 1182, 1183, 1186, 1187, 1187, 1187, 1187, 1187, 1189, 1189, 1190, 1190, 1190, 1190, 1191, 1191, 1191, 1191, 1192, 1192, 1193, 1193, 1195, 1195, 1196, 1196, 1198, 1199, 1200, 1200, 1200, 1200, 1200, 1202, 1202, 1203, 1203, 1203, 1203, 1203, 0, 0, 0, 1204, 1204, 1204, 1204, 1205, 1205, 1205, 1205, 1205, 0, 0, 0, 1209, 1210, 1211, 1211, 1211, 1211, 1211, 1213, 1214, 1215, 1215, 1215, 1215, 1215, 1217, 1218, 1218, 1218, 1219, 1220, 1220, 1222, 1224, 1225, 1225, 1234, 1234, 1235, 1235, 1236, 1237, 1237, 1237, 1237, 1237, 1237, 0, 0, 0, 1237, 1237, 1237, 0, 0, 0, 1238, 1238, 0, 1238, 1238, 1239, 1239, 1239, 1240, 1240, 1240, 1241, 1241, 1241, 1243, 1246, 1246, 1247, 1247, 1251, 1252, 1252, 1258, 1258, 1259, 1259, 1261, 1261, 1261, 1264, 1269, 1269, 1271, 1271, 1271, 1271, 1276, 1276, 1280, 1284, 1284, 0, 1284, 1284, 1284, 1284, 0, 0, 1285, 1287, 1287, 1287, 1287, 1288, 1288, 1288, 1289, 1290, 1291, 1292, 1292, 1292, 1293, 1293, 1295, 1295, 1295, 1296, 1296, 1296, 1296, 1296, 1296, 1297, 1292, 1300, 1304, 1304, 0, 1304, 1304, 1304, 1304, 0, 0, 1305, 1307, 1307, 1307, 1307, 1308, 1308, 1308, 1309, 1310, 1310, 1310, 1311, 1311, 1312, 1312, 1312, 1312, 1312, 1312, 1310, 1315};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {57, 61, 62, 63, 68, 69, 70, 71, 73, 76, 80, 83, 84, 283, 284, 289, 290, 292, 295, 299, 302, 304, 305, 310, 311, 312, 314, 315, 316, 317, 322, 323, 324, 329, 330, 333, 337, 340, 341, 342, 344, 347, 348, 349, 351, 354, 358, 361, 365, 368, 369, 370, 371, 372, 373, 374, 376, 379, 381, 381, 384, 386, 387, 389, 390, 391, 393, 394, 395, 396, 397, 402, 403, 404, 409, 410, 413, 417, 420, 422, 423, 424, 426, 427, 428, 429, 430, 435, 436, 441, 442, 445, 449, 452, 454, 455, 456, 458, 459, 460, 462, 463, 464, 469, 470, 471, 472, 473, 474, 476, 477, 478, 479, 481, 482, 483, 488, 489, 490, 491, 492, 493, 494, 495, 497, 498, 500, 502, 508, 509, 510, 515, 516, 518, 519, 521, 522, 523, 524, 525, 530, 531, 533, 534, 536, 537, 538, 539, 540, 541, 546, 547, 548, 549, 550, 551, 556, 557, 558, 560, 561, 562, 563, 565, 573, 574, 575, 576, 577, 582, 583, 588, 589, 592, 596, 599, 600, 601, 604, 605, 606, 609, 614, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 631, 633, 634, 635, 636, 637, 639, 640, 641, 642, 643, 648, 649, 650, 651, 656, 657, 658, 659, 660, 663, 664, 665, 666, 668, 669, 671, 672, 673, 674, 675, 677, 678, 679, 684, 685, 686, 691, 692, 695, 699, 702, 703, 704, 705, 706, 711, 712, 713, 718, 719, 722, 726, 729, 730, 732, 733, 734, 735, 736, 738, 739, 741, 742, 743, 744, 745, 747, 748, 749, 750, 751, 753, 754, 756, 759, 761, 762, 775, 776, 777, 778, 779, 782, 783, 788, 789, 790, 795, 796, 799, 803, 806, 807, 808, 810, 813, 817, 820, 821, 821, 824, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 837, 844, 845, 846, 847, 852, 854, 855, 865, 866, 867, 872, 873, 874, 875, 877, 885, 886, 887, 888, 889, 890, 896, 897, 902, 930, 935, 936, 939, 940, 941, 946, 947, 950, 954, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 969, 974, 975, 976, 977, 978, 979, 980, 981, 982, 987, 988, 989, 991, 992, 998, 1021, 1026, 1027, 1030, 1031, 1032, 1037, 1038, 1041, 1045, 1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1058, 1063, 1064, 1065, 1066, 1067, 1068, 1073, 1074, 1075, 1077, 1083};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
translateEmittedExceptionInner 1 1063 57
assign 1 1065 61
new 0 1065 61
print 0 1065 62
assign 1 1066 63
def 1 1066 68
assign 1 1066 69
new 0 1066 69
assign 1 1066 70
new 0 1066 70
assign 1 1066 71
can 2 1066 71
assign 1 0 73
assign 1 0 76
assign 1 0 80
assign 1 1067 83
descriptionGet 0 1067 83
print 0 1067 84
assign 1 1074 283
translatedGet 0 1074 283
assign 1 1074 284
def 1 1074 289
assign 1 1074 290
translatedGet 0 1074 290
assign 1 0 292
assign 1 0 295
assign 1 0 299
return 1 1075 302
assign 1 1077 304
vvGet 0 1077 304
assign 1 1077 305
undef 1 1077 310
assign 1 1078 311
new 0 1078 311
vvSet 1 1078 312
assign 1 1080 314
new 0 1080 314
translatedSet 1 1080 315
assign 1 1081 316
framesTextGet 0 1081 316
assign 1 1081 317
def 1 1081 322
assign 1 1081 323
langGet 0 1081 323
assign 1 1081 324
def 1 1081 329
assign 1 0 330
assign 1 0 333
assign 1 0 337
assign 1 1081 340
langGet 0 1081 340
assign 1 1081 341
new 0 1081 341
assign 1 1081 342
equals 1 1081 342
assign 1 0 344
assign 1 1081 347
langGet 0 1081 347
assign 1 1081 348
new 0 1081 348
assign 1 1081 349
equals 1 1081 349
assign 1 0 351
assign 1 0 354
assign 1 0 358
assign 1 0 361
assign 1 0 365
assign 1 1082 368
new 0 1082 368
assign 1 1082 369
new 1 1082 369
assign 1 1083 370
framesTextGet 0 1083 370
assign 1 1083 371
tokenize 1 1083 371
assign 1 1084 372
langGet 0 1084 372
assign 1 1084 373
new 0 1084 373
assign 1 1084 374
equals 1 1084 374
assign 1 1085 376
new 0 1085 376
assign 1 1087 379
new 0 1087 379
assign 1 1089 381
linkedListIteratorGet 0 0 381
assign 1 1089 384
hasNextGet 0 1089 384
assign 1 1089 386
nextGet 0 1089 386
assign 1 1090 387
vvGet 0 1090 387
assign 1 1091 389
new 0 1091 389
assign 1 1091 390
add 1 1091 390
print 0 1091 391
assign 1 1093 393
new 0 1093 393
assign 1 1093 394
find 1 1093 394
assign 1 1094 395
assign 1 1095 396
assign 1 1096 397
def 1 1096 402
assign 1 1096 403
new 0 1096 403
assign 1 1096 404
greaterEquals 1 1096 409
assign 1 0 410
assign 1 0 413
assign 1 0 417
assign 1 1097 420
vvGet 0 1097 420
assign 1 1098 422
new 0 1098 422
assign 1 1098 423
add 1 1098 423
print 0 1098 424
assign 1 1100 426
new 0 1100 426
assign 1 1100 427
new 0 1100 427
assign 1 1100 428
add 1 1100 428
assign 1 1100 429
find 2 1100 429
assign 1 1101 430
def 1 1101 435
assign 1 1101 436
greater 1 1101 441
assign 1 0 442
assign 1 0 445
assign 1 0 449
assign 1 1102 452
vvGet 0 1102 452
assign 1 1103 454
new 0 1103 454
assign 1 1103 455
add 1 1103 455
print 0 1103 456
assign 1 1105 458
new 0 1105 458
assign 1 1105 459
add 1 1105 459
assign 1 1105 460
substring 2 1105 460
assign 1 1108 462
new 0 1108 462
assign 1 1108 463
find 2 1108 463
assign 1 1109 464
def 1 1109 469
assign 1 1111 470
new 0 1111 470
assign 1 1111 471
add 1 1111 471
assign 1 1111 472
substring 1 1111 472
assign 1 1112 473
new 0 1112 473
assign 1 1112 474
ends 1 1112 474
assign 1 1113 476
sizeGet 0 1113 476
assign 1 1113 477
new 0 1113 477
assign 1 1113 478
subtract 1 1113 478
sizeSet 1 1113 479
assign 1 1116 481
new 0 1116 481
assign 1 1116 482
rfind 1 1116 482
assign 1 1117 483
def 1 1117 488
assign 1 1118 489
new 0 1118 489
assign 1 1118 490
substring 2 1118 490
assign 1 1120 491
new 0 1120 491
assign 1 1120 492
add 1 1120 492
assign 1 1120 493
substring 1 1120 493
assign 1 1121 494
new 0 1121 494
assign 1 1121 495
begins 1 1121 495
assign 1 1122 497
new 0 1122 497
assign 1 1122 498
substring 1 1122 498
assign 1 1125 500
isInteger 0 1125 500
assign 1 1126 502
new 1 1126 502
assign 1 1131 508
new 0 1131 508
assign 1 1131 509
find 2 1131 509
assign 1 1132 510
def 1 1132 515
assign 1 1133 516
vvGet 0 1133 516
assign 1 1134 518
new 0 1134 518
print 0 1134 519
assign 1 1137 521
new 0 1137 521
assign 1 1137 522
new 0 1137 522
assign 1 1137 523
add 1 1137 523
assign 1 1137 524
find 2 1137 524
assign 1 1138 525
def 1 1138 530
assign 1 1139 531
vvGet 0 1139 531
assign 1 1140 533
new 0 1140 533
print 0 1140 534
assign 1 1142 536
new 0 1142 536
assign 1 1142 537
add 1 1142 537
assign 1 1142 538
substring 2 1142 538
assign 1 1144 539
new 0 1144 539
assign 1 1144 540
rfind 1 1144 540
assign 1 1145 541
def 1 1145 546
assign 1 1146 547
new 0 1146 547
assign 1 1146 548
substring 2 1146 548
assign 1 1148 549
new 0 1148 549
assign 1 1148 550
rfind 1 1148 550
assign 1 1149 551
def 1 1149 556
assign 1 1150 557
new 0 1150 557
assign 1 1150 558
substring 2 1150 558
assign 1 1152 560
new 0 1152 560
assign 1 1152 561
add 1 1152 561
assign 1 1152 562
substring 1 1152 562
assign 1 1154 563
isInteger 0 1154 563
assign 1 1155 565
new 1 1155 565
assign 1 1162 573
new 0 1162 573
assign 1 1162 574
new 0 1162 574
assign 1 1162 575
add 1 1162 575
assign 1 1162 576
find 2 1162 576
assign 1 1163 577
def 1 1163 582
assign 1 1163 583
greater 1 1163 588
assign 1 0 589
assign 1 0 592
assign 1 0 596
assign 1 1164 599
new 0 1164 599
assign 1 1164 600
add 1 1164 600
assign 1 1164 601
substring 2 1164 601
assign 1 1166 604
new 0 1166 604
assign 1 1166 605
add 1 1166 605
assign 1 1166 606
substring 1 1166 606
assign 1 1169 609
def 1 1169 614
assign 1 1172 616
new 0 1172 616
assign 1 1172 617
split 1 1172 617
assign 1 1174 618
new 0 1174 618
assign 1 1174 619
get 1 1174 619
assign 1 1175 620
new 0 1175 620
assign 1 1175 621
get 1 1175 621
assign 1 1177 622
extractKlass 1 1177 622
assign 1 1179 623
extractMethod 1 1179 623
assign 1 1181 624
new 4 1181 624
assign 1 1182 625
klassNameGet 0 1182 625
assign 1 1182 626
getSourceFileName 1 1182 626
fileNameSet 1 1182 627
addFrame 1 1183 628
assign 1 1186 631
vvGet 0 1186 631
assign 1 1187 633
new 0 1187 633
assign 1 1187 634
add 1 1187 634
assign 1 1187 635
new 0 1187 635
assign 1 1187 636
add 1 1187 636
print 0 1187 637
assign 1 1189 639
new 0 1189 639
assign 1 1189 640
split 1 1189 640
assign 1 1190 641
sizeGet 0 1190 641
assign 1 1190 642
new 0 1190 642
assign 1 1190 643
greater 1 1190 648
assign 1 1191 649
sizeGet 0 1191 649
assign 1 1191 650
new 0 1191 650
assign 1 1191 651
greater 1 1191 656
assign 1 1192 657
new 0 1192 657
assign 1 1192 658
get 1 1192 658
assign 1 1193 659
new 0 1193 659
assign 1 1193 660
get 1 1193 660
assign 1 1195 663
new 0 1195 663
assign 1 1195 664
get 1 1195 664
assign 1 1196 665
new 0 1196 665
assign 1 1196 666
get 1 1196 666
assign 1 1198 668
extractMethod 1 1198 668
assign 1 1199 669
vvGet 0 1199 669
assign 1 1200 671
new 0 1200 671
assign 1 1200 672
add 1 1200 672
assign 1 1200 673
new 0 1200 673
assign 1 1200 674
add 1 1200 674
print 0 1200 675
assign 1 1202 677
new 0 1202 677
assign 1 1202 678
find 1 1202 678
assign 1 1203 679
def 1 1203 684
assign 1 1203 685
new 0 1203 685
assign 1 1203 686
greater 1 1203 691
assign 1 0 692
assign 1 0 695
assign 1 0 699
assign 1 1204 702
new 0 1204 702
assign 1 1204 703
new 0 1204 703
assign 1 1204 704
add 1 1204 704
assign 1 1204 705
find 2 1204 705
assign 1 1205 706
def 1 1205 711
assign 1 1205 712
new 0 1205 712
assign 1 1205 713
greater 1 1205 718
assign 1 0 719
assign 1 0 722
assign 1 0 726
assign 1 1209 729
substring 1 1209 729
assign 1 1210 730
vvGet 0 1210 730
assign 1 1211 732
new 0 1211 732
assign 1 1211 733
add 1 1211 733
assign 1 1211 734
new 0 1211 734
assign 1 1211 735
add 1 1211 735
print 0 1211 736
assign 1 1213 738
extractKlass 1 1213 738
assign 1 1214 739
vvGet 0 1214 739
assign 1 1215 741
new 0 1215 741
assign 1 1215 742
add 1 1215 742
assign 1 1215 743
new 0 1215 743
assign 1 1215 744
add 1 1215 744
print 0 1215 745
assign 1 1217 747
new 4 1217 747
assign 1 1218 748
klassNameGet 0 1218 748
assign 1 1218 749
getSourceFileName 1 1218 749
fileNameSet 1 1218 750
assign 1 1219 751
vvGet 0 1219 751
assign 1 1220 753
new 0 1220 753
print 0 1220 754
addFrame 1 1222 756
assign 1 1224 759
vvGet 0 1224 759
assign 1 1225 761
new 0 1225 761
print 0 1225 762
assign 1 1234 775
langGet 0 1234 775
emitLangSet 1 1234 776
assign 1 1235 777
new 0 1235 777
langSet 1 1235 778
framesTextSet 1 1236 779
assign 1 1237 782
framesGet 0 1237 782
assign 1 1237 783
def 1 1237 788
assign 1 1237 789
langGet 0 1237 789
assign 1 1237 790
def 1 1237 795
assign 1 0 796
assign 1 0 799
assign 1 0 803
assign 1 1237 806
langGet 0 1237 806
assign 1 1237 807
new 0 1237 807
assign 1 1237 808
equals 1 1237 808
assign 1 0 810
assign 1 0 813
assign 1 0 817
assign 1 1238 820
framesGet 0 1238 820
assign 1 1238 821
iteratorGet 0 0 821
assign 1 1238 824
hasNextGet 0 1238 824
assign 1 1238 826
nextGet 0 1238 826
assign 1 1239 827
klassNameGet 0 1239 827
assign 1 1239 828
extractKlassLib 1 1239 828
klassNameSet 1 1239 829
assign 1 1240 830
methodNameGet 0 1240 830
assign 1 1240 831
extractMethod 1 1240 831
methodNameSet 1 1240 832
assign 1 1241 833
klassNameGet 0 1241 833
assign 1 1241 834
getSourceFileName 1 1241 834
fileNameSet 1 1241 835
extractLine 0 1243 837
assign 1 1246 844
langGet 0 1246 844
emitLangSet 1 1246 845
assign 1 1247 846
new 0 1247 846
langSet 1 1247 847
assign 1 1251 852
vvGet 0 1251 852
assign 1 1252 854
new 0 1252 854
print 0 1252 855
assign 1 1258 865
new 0 1258 865
assign 1 1258 866
createInstance 2 1258 866
assign 1 1259 867
def 1 1259 872
assign 1 1261 873
new 0 1261 873
assign 1 1261 874
sourceFileName 1 1261 874
return 1 1261 875
return 1 1264 877
assign 1 1269 885
new 0 1269 885
assign 1 1269 886
split 1 1269 886
assign 1 1271 887
new 0 1271 887
assign 1 1271 888
get 1 1271 888
assign 1 1271 889
extractKlass 1 1271 889
return 1 1271 890
assign 1 1276 896
extractKlassInner 1 1276 896
return 1 1276 897
return 1 1280 902
assign 1 1284 930
undef 1 1284 935
assign 1 0 936
assign 1 1284 939
new 0 1284 939
assign 1 1284 940
begins 1 1284 940
assign 1 1284 941
not 0 1284 946
assign 1 0 947
assign 1 0 950
return 1 1285 954
assign 1 1287 956
new 0 1287 956
assign 1 1287 957
substring 1 1287 957
assign 1 1287 958
new 0 1287 958
assign 1 1287 959
split 1 1287 959
assign 1 1288 960
sizeGet 0 1288 960
assign 1 1288 961
new 0 1288 961
assign 1 1288 962
subtract 1 1288 962
assign 1 1289 963
get 1 1289 963
assign 1 1290 964
new 0 1290 964
assign 1 1291 965
new 0 1291 965
assign 1 1292 966
new 0 1292 966
assign 1 1292 969
lesser 1 1292 974
assign 1 1293 975
get 1 1293 975
assign 1 1293 976
new 1 1293 976
assign 1 1295 977
add 1 1295 977
assign 1 1295 978
substring 2 1295 978
addValue 1 1295 979
assign 1 1296 980
new 0 1296 980
assign 1 1296 981
add 1 1296 981
assign 1 1296 982
lesser 1 1296 987
assign 1 1296 988
new 0 1296 988
addValue 1 1296 989
addValue 1 1297 991
incrementValue 0 1292 992
return 1 1300 998
assign 1 1304 1021
undef 1 1304 1026
assign 1 0 1027
assign 1 1304 1030
new 0 1304 1030
assign 1 1304 1031
begins 1 1304 1031
assign 1 1304 1032
not 0 1304 1037
assign 1 0 1038
assign 1 0 1041
return 1 1305 1045
assign 1 1307 1047
new 0 1307 1047
assign 1 1307 1048
substring 1 1307 1048
assign 1 1307 1049
new 0 1307 1049
assign 1 1307 1050
split 1 1307 1050
assign 1 1308 1051
sizeGet 0 1308 1051
assign 1 1308 1052
new 0 1308 1052
assign 1 1308 1053
subtract 1 1308 1053
assign 1 1309 1054
new 0 1309 1054
assign 1 1310 1055
new 0 1310 1055
assign 1 1310 1058
lesser 1 1310 1063
assign 1 1311 1064
get 1 1311 1064
addValue 1 1311 1065
assign 1 1312 1066
new 0 1312 1066
assign 1 1312 1067
add 1 1312 1067
assign 1 1312 1068
lesser 1 1312 1073
assign 1 1312 1074
new 0 1312 1074
addValue 1 1312 1075
incrementValue 0 1310 1077
return 1 1315 1083
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1087891034: return bem_copy_0();
case -615427058: return bem_iteratorGet_0();
case 350723715: return bem_default_0();
case 380806302: return bem_new_0();
case -716837866: return bem_hashGet_0();
case -1147088242: return bem_create_0();
case 603718350: return bem_print_0();
case 53308341: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1554282063: return bem_notEquals_1(bevd_0);
case 985936960: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1738005159: return bem_equals_1(bevd_0);
case -2145938464: return bem_translateEmittedException_1((BEC_2_6_9_SystemException) bevd_0);
case 1285889506: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case -9176148: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1151437268: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
case -1462940865: return bem_copyTo_1(bevd_0);
case 556263301: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1237306698: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 971589665: return bem_def_1(bevd_0);
case 1209125372: return bem_undef_1(bevd_0);
case 72435732: return bem_translateEmittedExceptionInner_1((BEC_2_6_9_SystemException) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -29663031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1505420135: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2021917335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 559223927: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1581466981: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_19_SystemExceptionTranslator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_19_SystemExceptionTranslator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_19_SystemExceptionTranslator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst = (BEC_2_6_19_SystemExceptionTranslator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_19_SystemExceptionTranslator.bece_BEC_2_6_19_SystemExceptionTranslator_bevs_type;
}
}
