package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_20_XmlTagIteratorException extends BEC_2_6_9_SystemException {
public BEC_2_3_20_XmlTagIteratorException() { }
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;

public static BET_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -776421985: return bem_langGet_0();
case 701056781: return bem_print_0();
case -1377433234: return bem_vvGet_0();
case -1500345660: return bem_new_0();
case 798949284: return bem_framesTextGet_0();
case 1139359465: return bem_translatedGet_0();
case -411352811: return bem_iteratorGet_0();
case 2003880000: return bem_getFrameText_0();
case 1152166910: return bem_descriptionGet_0();
case -1044882: return bem_framesGet_0();
case 1914698093: return bem_copy_0();
case 361526279: return bem_methodNameGet_0();
case 404066714: return bem_lineNumberGet_0();
case -2044808959: return bem_create_0();
case 1563587509: return bem_fileNameGet_0();
case -110232957: return bem_klassNameGet_0();
case 332374972: return bem_toString_0();
case -1640958937: return bem_emitLangGet_0();
case 403207358: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 242448501: return bem_undef_1(bevd_0);
case -2091475700: return bem_def_1(bevd_0);
case 1853868091: return bem_klassNameSet_1(bevd_0);
case 1860971499: return bem_framesSet_1(bevd_0);
case -1848887632: return bem_fileNameSet_1(bevd_0);
case -1464240050: return bem_emitLangSet_1(bevd_0);
case -977163676: return bem_lineNumberSet_1(bevd_0);
case -178817885: return bem_langSet_1(bevd_0);
case 146134233: return bem_descriptionSet_1(bevd_0);
case 2093081199: return bem_equals_1(bevd_0);
case -183213474: return bem_copyTo_1(bevd_0);
case -192085192: return bem_new_1(bevd_0);
case 547755680: return bem_framesTextSet_1(bevd_0);
case -1455918774: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 1419463749: return bem_methodNameSet_1(bevd_0);
case -1687853245: return bem_vvSet_1(bevd_0);
case -1007956966: return bem_translatedSet_1(bevd_0);
case 1056390040: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1734287964: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1748111499: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1968238059: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1944821118: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 687930950: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_3_20_XmlTagIteratorException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_20_XmlTagIteratorException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_20_XmlTagIteratorException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst = (BEC_2_3_20_XmlTagIteratorException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;
}
}
