package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_20_XmlTagIteratorException extends BEC_2_6_9_SystemException {
public BEC_2_3_20_XmlTagIteratorException() { }
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;

public static BET_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -693135675: return bem_klassNameGet_0();
case -1631144114: return bem_methodNameGet_0();
case -1939148176: return bem_print_0();
case 1703385350: return bem_descriptionGet_0();
case -1705415508: return bem_copy_0();
case -2012755043: return bem_emitLangGet_0();
case 424971029: return bem_new_0();
case -111787496: return bem_create_0();
case 2067719507: return bem_vvGet_0();
case -1603384212: return bem_hashGet_0();
case -436442404: return bem_fileNameGet_0();
case -664840078: return bem_getFrameText_0();
case -1522644965: return bem_toString_0();
case -1213881956: return bem_translatedGet_0();
case 926255589: return bem_iteratorGet_0();
case -1136366046: return bem_framesTextGet_0();
case -802701253: return bem_langGet_0();
case 1150142576: return bem_framesGet_0();
case 283074634: return bem_lineNumberGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1704831336: return bem_def_1(bevd_0);
case 1718554350: return bem_notEquals_1(bevd_0);
case -807764758: return bem_equals_1(bevd_0);
case 805370625: return bem_emitLangSet_1(bevd_0);
case -1629982197: return bem_undef_1(bevd_0);
case -597505800: return bem_lineNumberSet_1(bevd_0);
case 1802441892: return bem_methodNameSet_1(bevd_0);
case 7387392: return bem_framesTextSet_1(bevd_0);
case 1059579873: return bem_copyTo_1(bevd_0);
case -538142087: return bem_klassNameSet_1(bevd_0);
case 108355759: return bem_vvSet_1(bevd_0);
case 95367310: return bem_langSet_1(bevd_0);
case -1169903635: return bem_translatedSet_1(bevd_0);
case -233931586: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case -1058620613: return bem_descriptionSet_1(bevd_0);
case -772330735: return bem_framesSet_1(bevd_0);
case 1950595029: return bem_new_1(bevd_0);
case -499012814: return bem_fileNameSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1274466133: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1052347851: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -170258296: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1651057385: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -148384425: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_3_20_XmlTagIteratorException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_20_XmlTagIteratorException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_20_XmlTagIteratorException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst = (BEC_2_3_20_XmlTagIteratorException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;
}
}
