package be;
/* IO:File: source/extended/Xml.be */
public class BEC_2_3_20_XmlTagIteratorException extends BEC_2_6_9_SystemException {
public BEC_2_3_20_XmlTagIteratorException() { }
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clname = {0x58,0x6D,0x6C,0x3A,0x54,0x61,0x67,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E};
private static byte[] becc_BEC_2_3_20_XmlTagIteratorException_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x58,0x6D,0x6C,0x2E,0x62,0x65};
public static BEC_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;

public static BET_2_3_20_XmlTagIteratorException bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;

public static int[] bems_smnlc() {
return new int[] {};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1527367436: return bem_getFrameText_0();
case 185075715: return bem_toAny_0();
case 49871177: return bem_klassNameGet_0();
case 1823849359: return bem_descriptionGet_0();
case -1812168422: return bem_fileNameGet_0();
case -1541505350: return bem_deserializeClassNameGet_0();
case 619757843: return bem_once_0();
case -1347905988: return bem_create_0();
case -1945232493: return bem_echo_0();
case 1880763773: return bem_lineNumberGet_0();
case -307935006: return bem_serializeContents_0();
case 1871018350: return bem_methodNameGet_0();
case -1176152522: return bem_translatedGet_0();
case 670217566: return bem_emitLangGet_0();
case -589513143: return bem_framesTextGet_0();
case 1277638303: return bem_framesGetDirect_0();
case 61965373: return bem_translatedGetDirect_0();
case 1790682890: return bem_fieldIteratorGet_0();
case 1121159883: return bem_print_0();
case 1472706330: return bem_framesTextGetDirect_0();
case -675938796: return bem_translateEmittedException_0();
case 1866992183: return bem_lineNumberGetDirect_0();
case -499237160: return bem_klassNameGetDirect_0();
case 1823740126: return bem_tagGet_0();
case -1493598338: return bem_emitLangGetDirect_0();
case 2052961016: return bem_framesGet_0();
case -301683900: return bem_many_0();
case 661355108: return bem_fileNameGetDirect_0();
case 597186178: return bem_translateEmittedExceptionInner_0();
case -1855820499: return bem_langGetDirect_0();
case 1100108870: return bem_classNameGet_0();
case 66568862: return bem_serializeToString_0();
case 598542224: return bem_iteratorGet_0();
case 766792083: return bem_new_0();
case 1847214649: return bem_descriptionGetDirect_0();
case -1404446512: return bem_hashGet_0();
case 777384407: return bem_methodNameGetDirect_0();
case 558155065: return bem_copy_0();
case 567515386: return bem_vvGet_0();
case -1505580350: return bem_langGet_0();
case 438469697: return bem_fieldNamesGet_0();
case -2077327881: return bem_serializationIteratorGet_0();
case -2082927025: return bem_toString_0();
case 516740577: return bem_sourceFileNameGet_0();
case -801074614: return bem_vvGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1868581166: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 71224597: return bem_framesSet_1(bevd_0);
case 1407523089: return bem_undef_1(bevd_0);
case -907470247: return bem_sameObject_1(bevd_0);
case -999494811: return bem_klassNameSetDirect_1(bevd_0);
case -2805495: return bem_descriptionSetDirect_1(bevd_0);
case -1788117101: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1150573387: return bem_copyTo_1(bevd_0);
case -935074238: return bem_otherType_1(bevd_0);
case -768370819: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -532166301: return bem_langSet_1(bevd_0);
case 1619296118: return bem_undefined_1(bevd_0);
case 1668417783: return bem_extractKlassInner_1((BEC_2_4_6_TextString) bevd_0);
case 1181989405: return bem_extractKlassLib_1((BEC_2_4_6_TextString) bevd_0);
case -1447666556: return bem_klassNameSet_1(bevd_0);
case -262755334: return bem_new_1(bevd_0);
case 1651574615: return bem_langSetDirect_1(bevd_0);
case -1219821399: return bem_framesTextSetDirect_1(bevd_0);
case -1528692518: return bem_framesSetDirect_1(bevd_0);
case -2143519757: return bem_methodNameSetDirect_1(bevd_0);
case -2019608541: return bem_fileNameSetDirect_1(bevd_0);
case 378746162: return bem_sameType_1(bevd_0);
case 1385898285: return bem_framesTextSet_1(bevd_0);
case -1154331895: return bem_methodNameSet_1(bevd_0);
case -954556804: return bem_addFrame_1((BEC_2_9_5_ExceptionFrame) bevd_0);
case 172532096: return bem_vvSet_1(bevd_0);
case 314955640: return bem_def_1(bevd_0);
case 726605959: return bem_descriptionSet_1(bevd_0);
case 1378481920: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1259411435: return bem_fileNameSet_1(bevd_0);
case 1315093896: return bem_defined_1(bevd_0);
case -535132443: return bem_emitLangSetDirect_1(bevd_0);
case -1184335843: return bem_getSourceFileName_1((BEC_2_4_6_TextString) bevd_0);
case 431153324: return bem_notEquals_1(bevd_0);
case 844066392: return bem_sameClass_1(bevd_0);
case 1872709810: return bem_equals_1(bevd_0);
case 1864036016: return bem_extractMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1530691970: return bem_otherClass_1(bevd_0);
case 1571339407: return bem_vvSetDirect_1(bevd_0);
case 1534259268: return bem_emitLangSet_1(bevd_0);
case 2024845509: return bem_translatedSetDirect_1(bevd_0);
case -1912364952: return bem_translatedSet_1(bevd_0);
case 956493469: return bem_lineNumberSet_1(bevd_0);
case 1683911201: return bem_lineNumberSetDirect_1(bevd_0);
case -1219771122: return bem_extractKlass_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 669366955: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -223228068: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1903036726: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1915345411: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1939171826: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1309309215: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 620336517: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case 1486913694: return bem_addFrame_4((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_6_TextString) bevd_1, (BEC_2_4_6_TextString) bevd_2, (BEC_2_4_3_MathInt) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_3_20_XmlTagIteratorException_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_3_20_XmlTagIteratorException_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_3_20_XmlTagIteratorException();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst = (BEC_2_3_20_XmlTagIteratorException) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_3_20_XmlTagIteratorException.bece_BEC_2_3_20_XmlTagIteratorException_bevs_type;
}
}
