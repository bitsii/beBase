package be;
/* IO:File: source/build/EmitData.be */
public final class BEC_2_5_11_BuildMethodIndex extends BEC_2_6_6_SystemObject {
public BEC_2_5_11_BuildMethodIndex() { }
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4D,0x65,0x74,0x68,0x6F,0x64,0x49,0x6E,0x64,0x65,0x78};
private static byte[] becc_BEC_2_5_11_BuildMethodIndex_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x45,0x6D,0x69,0x74,0x44,0x61,0x74,0x61,0x2E,0x62,0x65};
public static BEC_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;

public static BET_2_5_11_BuildMethodIndex bece_BEC_2_5_11_BuildMethodIndex_bevs_type;

public BEC_2_5_8_BuildClassSyn bevp_syn;
public BEC_2_5_6_BuildMtdSyn bevp_msyn;
public BEC_2_5_8_BuildNamePath bevp_declaration;
public BEC_2_4_6_TextString bevp_name;
public BEC_2_5_11_BuildMethodIndex bem_new_2(BEC_2_5_8_BuildClassSyn beva__syn, BEC_2_5_6_BuildMtdSyn beva__msyn) throws Throwable {
bevp_syn = beva__syn;
bevp_msyn = beva__msyn;
bevp_declaration = bevp_msyn.bem_declarationGet_0();
bevp_name = bevp_msyn.bem_nameGet_0();
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevt_2_ta_ph = bevp_declaration.bem_toString_0();
bevt_1_ta_ph = bevt_2_ta_ph.bem_add_1(bevp_name);
bevt_0_ta_ph = bevt_1_ta_ph.bem_hashGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_7_SystemClasses bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
if (beva_x == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 111*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 111*/ {
bevt_5_ta_ph = (BEC_2_6_7_SystemClasses) BEC_2_6_7_SystemClasses.bece_BEC_2_6_7_SystemClasses_bevs_inst;
bevt_4_ta_ph = bevt_5_ta_ph.bem_sameClass_2(this, beva_x);
if (bevt_4_ta_ph.bevi_bool) {
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 111*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 111*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 111*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 111*/ {
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_6_ta_ph;
} /* Line: 111*/
bevt_8_ta_ph = beva_x.bemd_0(-1557506545);
bevt_7_ta_ph = bevp_declaration.bem_equals_1(bevt_8_ta_ph);
if (bevt_7_ta_ph.bevi_bool)/* Line: 112*/ {
bevt_10_ta_ph = beva_x.bemd_0(-362954353);
bevt_9_ta_ph = bevp_name.bem_equals_1(bevt_10_ta_ph);
if (bevt_9_ta_ph.bevi_bool)/* Line: 112*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 112*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 112*/
 else /* Line: 112*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 112*/ {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_11_ta_ph;
} /* Line: 113*/
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_12_ta_ph;
} /*method end*/
public BEC_2_5_8_BuildClassSyn bem_synGet_0() throws Throwable {
return bevp_syn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_synSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_syn = (BEC_2_5_8_BuildClassSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_6_BuildMtdSyn bem_msynGet_0() throws Throwable {
return bevp_msyn;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_msynSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_msyn = (BEC_2_5_6_BuildMtdSyn) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_8_BuildNamePath bem_declarationGet_0() throws Throwable {
return bevp_declaration;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_declarationSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_declaration = (BEC_2_5_8_BuildNamePath) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_nameGet_0() throws Throwable {
return bevp_name;
} /*method end*/
public BEC_2_5_11_BuildMethodIndex bem_nameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_name = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {99, 100, 101, 102, 107, 107, 107, 107, 111, 111, 0, 111, 111, 111, 111, 0, 0, 111, 111, 112, 112, 112, 112, 0, 0, 0, 113, 113, 115, 115, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 26, 27, 28, 29, 45, 50, 51, 54, 55, 56, 61, 62, 65, 69, 70, 72, 73, 75, 76, 78, 81, 85, 88, 89, 91, 92, 95, 98, 102, 105, 109, 112, 116, 119};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 99 16
assign 1 100 17
assign 1 101 18
declarationGet 0 101 18
assign 1 102 19
nameGet 0 102 19
assign 1 107 26
toString 0 107 26
assign 1 107 27
add 1 107 27
assign 1 107 28
hashGet 0 107 28
return 1 107 29
assign 1 111 45
undef 1 111 50
assign 1 0 51
assign 1 111 54
new 0 111 54
assign 1 111 55
sameClass 2 111 55
assign 1 111 56
not 0 111 61
assign 1 0 62
assign 1 0 65
assign 1 111 69
new 0 111 69
return 1 111 70
assign 1 112 72
declarationGet 0 112 72
assign 1 112 73
equals 1 112 73
assign 1 112 75
nameGet 0 112 75
assign 1 112 76
equals 1 112 76
assign 1 0 78
assign 1 0 81
assign 1 0 85
assign 1 113 88
new 0 113 88
return 1 113 89
assign 1 115 91
new 0 115 91
return 1 115 92
return 1 0 95
assign 1 0 98
return 1 0 102
assign 1 0 105
return 1 0 109
assign 1 0 112
return 1 0 116
assign 1 0 119
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -362954353: return bem_nameGet_0();
case 495322505: return bem_msynGet_0();
case -1087891034: return bem_copy_0();
case -615427058: return bem_iteratorGet_0();
case -1763690912: return bem_synGet_0();
case 380806302: return bem_new_0();
case -716837866: return bem_hashGet_0();
case -1147088242: return bem_create_0();
case -1557506545: return bem_declarationGet_0();
case 603718350: return bem_print_0();
case 53308341: return bem_toString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1554282063: return bem_notEquals_1(bevd_0);
case 1738005159: return bem_equals_1(bevd_0);
case -2109244623: return bem_declarationSet_1(bevd_0);
case -723627335: return bem_msynSet_1(bevd_0);
case 788357474: return bem_nameSet_1(bevd_0);
case -1462940865: return bem_copyTo_1(bevd_0);
case -1237306698: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 971589665: return bem_def_1(bevd_0);
case 1209125372: return bem_undef_1(bevd_0);
case 17934118: return bem_synSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -29663031: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1804495597: return bem_new_2((BEC_2_5_8_BuildClassSyn) bevd_0, (BEC_2_5_6_BuildMtdSyn) bevd_1);
case -1505420135: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2021917335: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 559223927: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1581466981: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_5_11_BuildMethodIndex_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_5_11_BuildMethodIndex_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_11_BuildMethodIndex();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst = (BEC_2_5_11_BuildMethodIndex) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_11_BuildMethodIndex.bece_BEC_2_5_11_BuildMethodIndex_bevs_type;
}
}
