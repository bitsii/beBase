package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_7_SystemStartup extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemStartup() { }
private static byte[] becc_BEC_2_6_7_SystemStartup_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70};
private static byte[] becc_BEC_2_6_7_SystemStartup_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemStartup_bels_0 = {0x49,0x6E,0x73,0x75,0x66,0x66,0x69,0x63,0x69,0x65,0x6E,0x74,0x20,0x6E,0x75,0x6D,0x62,0x65,0x72,0x20,0x6F,0x66,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73,0x2C,0x20,0x61,0x74,0x20,0x6C,0x65,0x61,0x73,0x74,0x20,0x6F,0x6E,0x65,0x20,0x61,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x20,0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x64,0x20,0x66,0x6F,0x72,0x20,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2C,0x20,0x74,0x68,0x65,0x20,0x6E,0x61,0x6D,0x65,0x20,0x6F,0x66,0x20,0x74,0x68,0x65,0x20,0x63,0x6C,0x61,0x73,0x73,0x20,0x77,0x68,0x6F,0x73,0x65,0x20,0x6D,0x61,0x69,0x6E,0x28,0x29,0x20,0x6D,0x65,0x74,0x68,0x6F,0x64,0x20,0x73,0x68,0x6F,0x75,0x6C,0x64,0x20,0x62,0x65,0x20,0x63,0x61,0x6C,0x6C,0x65,0x64};
public static BEC_2_6_7_SystemStartup bece_BEC_2_6_7_SystemStartup_bevs_inst;

public static BET_2_6_7_SystemStartup bece_BEC_2_6_7_SystemStartup_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_7_SystemStartup bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_7_SystemStartup bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_ta_ph.bem_argsGet_0();
bevt_2_ta_ph = bevp_args.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_2_ta_ph.bevi_int < bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 37*/ {
bevt_5_ta_ph = (new BEC_2_4_6_TextString(136, bece_BEC_2_6_7_SystemStartup_bels_0));
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 38*/
bevt_7_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_9_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_8_ta_ph = bevp_args.bem_get_1(bevt_9_ta_ph);
bevt_6_ta_ph = bevt_7_ta_ph.bem_createInstance_1((BEC_2_4_6_TextString) bevt_8_ta_ph );
bevl_x = bevt_6_ta_ph.bemd_0(-2134993308);
bevt_10_ta_ph = bevl_x.bemd_0(-1362431667);
return bevt_10_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_7_SystemStartup bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {36, 36, 37, 37, 37, 37, 38, 38, 38, 40, 40, 40, 40, 40, 41, 41, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {32, 33, 34, 35, 36, 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 55, 58};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 36 32
new 0 36 32
assign 1 36 33
argsGet 0 36 33
assign 1 37 34
sizeGet 0 37 34
assign 1 37 35
new 0 37 35
assign 1 37 36
lesser 1 37 41
assign 1 38 42
new 0 38 42
assign 1 38 43
new 1 38 43
throw 1 38 44
assign 1 40 46
new 0 40 46
assign 1 40 47
new 0 40 47
assign 1 40 48
get 1 40 48
assign 1 40 49
createInstance 1 40 49
assign 1 40 50
new 0 40 50
assign 1 41 51
main 0 41 51
return 1 41 52
return 1 0 55
assign 1 0 58
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1454467551: return bem_default_0();
case -999123940: return bem_create_0();
case 97869199: return bem_hashGet_0();
case -2133146908: return bem_iteratorGet_0();
case -2134993308: return bem_new_0();
case 420796529: return bem_toString_0();
case 2105446481: return bem_print_0();
case -2096331826: return bem_copy_0();
case -1362431667: return bem_main_0();
case 541385806: return bem_argsGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1016050541: return bem_notEquals_1(bevd_0);
case -561946826: return bem_def_1(bevd_0);
case 1724089654: return bem_equals_1(bevd_0);
case -1012075519: return bem_argsSet_1(bevd_0);
case -199176115: return bem_undef_1(bevd_0);
case -1845239358: return bem_copyTo_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 861111505: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 150001987: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1560972769: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -444420730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemStartup_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_7_SystemStartup_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemStartup();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_inst = (BEC_2_6_7_SystemStartup) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemStartup.bece_BEC_2_6_7_SystemStartup_bevs_type;
}
}
