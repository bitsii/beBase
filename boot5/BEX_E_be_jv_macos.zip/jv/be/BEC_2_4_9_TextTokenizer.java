package be;
/* IO:File: source/base/Tokenize.be */
public final class BEC_2_4_9_TextTokenizer extends BEC_2_6_6_SystemObject {
public BEC_2_4_9_TextTokenizer() { }
private static byte[] becc_BEC_2_4_9_TextTokenizer_clname = {0x54,0x65,0x78,0x74,0x3A,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x72};
private static byte[] becc_BEC_2_4_9_TextTokenizer_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x54,0x6F,0x6B,0x65,0x6E,0x69,0x7A,0x65,0x2E,0x62,0x65};
public static BEC_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_inst;

public static BET_2_4_9_TextTokenizer bece_BEC_2_4_9_TextTokenizer_bevs_type;

public BEC_2_9_3_ContainerMap bevp_tmap;
public BEC_2_5_4_LogicBool bevp_includeTokens;
public BEC_2_4_9_TextTokenizer bem_new_1(BEC_2_4_6_TextString beva_delims) throws Throwable {
bevp_includeTokens = be.BECS_Runtime.boolFalse;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_new_2(BEC_2_4_6_TextString beva_delims, BEC_2_5_4_LogicBool beva__includeTokens) throws Throwable {
bevp_includeTokens = beva__includeTokens;
bem_tokensStringSet_1(beva_delims);
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokensStringSet_1(BEC_2_4_6_TextString beva_delims) throws Throwable {
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevt_0_ta_loop = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
bevp_tmap = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_ta_loop = beva_delims.bem_iteratorGet_0();
while (true)
/* Line: 29*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_1_ta_ph).bevi_bool)/* Line: 29*/ {
bevl_chi = (BEC_2_4_6_TextString) bevt_0_ta_loop.bemd_0(-747250137);
bevt_2_ta_ph = bevl_chi.bem_toString_0();
bevp_tmap.bem_put_2(bevl_chi, bevt_2_ta_ph);
} /* Line: 30*/
 else /* Line: 29*/ {
break;
} /* Line: 29*/
} /* Line: 29*/
return this;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_addToken_1(BEC_2_4_6_TextString beva__delim) throws Throwable {
BEC_2_4_6_TextString bevl_delim = null;
bevl_delim = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_delim.bem_addValue_1(beva__delim);
bevp_tmap.bem_put_2(bevl_delim, beva__delim);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_1(BEC_2_6_6_SystemObject beva_str) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_ta_ph = bem_tokenizeIterator_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenize_2(BEC_2_6_6_SystemObject beva_str, BEC_2_6_6_SystemObject beva_tokenAcceptor) throws Throwable {
BEC_2_4_9_TextTokenizer bevt_0_ta_ph = null;
BEC_2_4_17_TextMultiByteIterator bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_17_TextMultiByteIterator()).bem_new_1((BEC_2_4_6_TextString) beva_str );
bevt_0_ta_ph = bem_tokenizeIterator_2(bevt_1_ta_ph, beva_tokenAcceptor);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tokenizeIterator_2(BEC_2_6_6_SystemObject beva_i, BEC_2_6_6_SystemObject beva_acceptor) throws Throwable {
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
/* Line: 51*/ {
bevt_0_ta_ph = beva_i.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 51*/ {
beva_i.bemd_1(-2078162457, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 54*/ {
bevt_3_ta_ph = bevl_accum.bem_lengthGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 55*/ {
bevt_5_ta_ph = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(939736236, bevt_5_ta_ph);
} /* Line: 56*/
if (bevp_includeTokens.bevi_bool)/* Line: 58*/ {
beva_acceptor.bemd_1(939736236, bevl_cc);
} /* Line: 59*/
} /* Line: 58*/
 else /* Line: 61*/ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 62*/
} /* Line: 54*/
 else /* Line: 51*/ {
break;
} /* Line: 51*/
} /* Line: 51*/
bevt_7_ta_ph = bevl_accum.bem_lengthGet_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_7_ta_ph.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 65*/ {
bevt_9_ta_ph = bevl_accum.bem_extractString_0();
beva_acceptor.bemd_1(939736236, bevt_9_ta_ph);
} /* Line: 66*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tokenizeIterator_1(BEC_2_6_6_SystemObject beva_i) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_splits = null;
BEC_2_4_6_TextString bevl_accum = null;
BEC_2_4_6_TextString bevl_chi = null;
BEC_2_6_6_SystemObject bevl_cc = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_6_TextString bevt_9_ta_ph = null;
bevl_splits = (new BEC_2_9_10_ContainerLinkedList()).bem_new_0();
bevl_accum = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_chi = (new BEC_2_4_6_TextString()).bem_new_0();
while (true)
/* Line: 74*/ {
bevt_0_ta_ph = beva_i.bemd_0(1207162355);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 74*/ {
beva_i.bemd_1(-2078162457, bevl_chi);
bevl_cc = bevp_tmap.bem_get_1(bevl_chi);
if (bevl_cc == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 77*/ {
bevt_3_ta_ph = bevl_accum.bem_lengthGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_3_ta_ph.bevi_int > bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 78*/ {
bevt_5_ta_ph = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_5_ta_ph);
} /* Line: 79*/
if (bevp_includeTokens.bevi_bool)/* Line: 81*/ {
bevl_splits.bem_addValue_1(bevl_cc);
} /* Line: 82*/
} /* Line: 81*/
 else /* Line: 84*/ {
bevl_accum.bem_addValue_1(bevl_chi);
} /* Line: 85*/
} /* Line: 77*/
 else /* Line: 74*/ {
break;
} /* Line: 74*/
} /* Line: 74*/
bevt_7_ta_ph = bevl_accum.bem_lengthGet_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_7_ta_ph.bevi_int > bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 88*/ {
bevt_9_ta_ph = bevl_accum.bem_extractString_0();
bevl_splits.bem_addValue_1(bevt_9_ta_ph);
} /* Line: 89*/
return bevl_splits;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_tmapGet_0() throws Throwable {
return bevp_tmap;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_tmapSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_tmap = (BEC_2_9_3_ContainerMap) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_includeTokensGet_0() throws Throwable {
return bevp_includeTokens;
} /*method end*/
public BEC_2_4_9_TextTokenizer bem_includeTokensSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_includeTokens = (BEC_2_5_4_LogicBool) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {18, 19, 23, 24, 28, 29, 0, 29, 29, 30, 30, 35, 36, 37, 41, 41, 41, 45, 45, 45, 49, 50, 51, 52, 53, 54, 54, 55, 55, 55, 55, 56, 56, 59, 62, 65, 65, 65, 65, 66, 66, 71, 72, 73, 74, 75, 76, 77, 77, 78, 78, 78, 78, 79, 79, 82, 85, 88, 88, 88, 88, 89, 89, 91, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {14, 15, 19, 20, 28, 29, 29, 32, 34, 35, 36, 46, 47, 48, 54, 55, 56, 61, 62, 63, 79, 80, 83, 85, 86, 87, 92, 93, 94, 95, 100, 101, 102, 105, 109, 116, 117, 118, 123, 124, 125, 144, 145, 146, 149, 151, 152, 153, 158, 159, 160, 161, 166, 167, 168, 171, 175, 182, 183, 184, 189, 190, 191, 193, 196, 199, 203, 206};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 18 14
new 0 18 14
tokensStringSet 1 19 15
assign 1 23 19
tokensStringSet 1 24 20
assign 1 28 28
new 0 28 28
assign 1 29 29
iteratorGet 0 0 29
assign 1 29 32
hasNextGet 0 29 32
assign 1 29 34
nextGet 0 29 34
assign 1 30 35
toString 0 30 35
put 2 30 36
assign 1 35 46
new 0 35 46
addValue 1 36 47
put 2 37 48
assign 1 41 54
new 1 41 54
assign 1 41 55
tokenizeIterator 1 41 55
return 1 41 56
assign 1 45 61
new 1 45 61
assign 1 45 62
tokenizeIterator 2 45 62
return 1 45 63
assign 1 49 79
new 0 49 79
assign 1 50 80
new 0 50 80
assign 1 51 83
hasNextGet 0 51 83
next 1 52 85
assign 1 53 86
get 1 53 86
assign 1 54 87
def 1 54 92
assign 1 55 93
lengthGet 0 55 93
assign 1 55 94
new 0 55 94
assign 1 55 95
greater 1 55 100
assign 1 56 101
extractString 0 56 101
acceptToken 1 56 102
acceptToken 1 59 105
addValue 1 62 109
assign 1 65 116
lengthGet 0 65 116
assign 1 65 117
new 0 65 117
assign 1 65 118
greater 1 65 123
assign 1 66 124
extractString 0 66 124
acceptToken 1 66 125
assign 1 71 144
new 0 71 144
assign 1 72 145
new 0 72 145
assign 1 73 146
new 0 73 146
assign 1 74 149
hasNextGet 0 74 149
next 1 75 151
assign 1 76 152
get 1 76 152
assign 1 77 153
def 1 77 158
assign 1 78 159
lengthGet 0 78 159
assign 1 78 160
new 0 78 160
assign 1 78 161
greater 1 78 166
assign 1 79 167
extractString 0 79 167
addValue 1 79 168
addValue 1 82 171
addValue 1 85 175
assign 1 88 182
lengthGet 0 88 182
assign 1 88 183
new 0 88 183
assign 1 88 184
greater 1 88 189
assign 1 89 190
extractString 0 89 190
addValue 1 89 191
return 1 91 193
return 1 0 196
assign 1 0 199
return 1 0 203
assign 1 0 206
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1954876952: return bem_iteratorGet_0();
case 1551699625: return bem_tmapGet_0();
case 1069615902: return bem_copy_0();
case 1428575040: return bem_toString_0();
case -1629771427: return bem_create_0();
case -43191778: return bem_hashGet_0();
case -935641853: return bem_print_0();
case 1386971568: return bem_includeTokensGet_0();
case 1356338585: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -891079959: return bem_tokensStringSet_1((BEC_2_4_6_TextString) bevd_0);
case 1052290339: return bem_tmapSet_1(bevd_0);
case 1073716984: return bem_equals_1(bevd_0);
case 770748266: return bem_includeTokensSet_1(bevd_0);
case 484780340: return bem_notEquals_1(bevd_0);
case 870724511: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -179556288: return bem_undef_1(bevd_0);
case 501143872: return bem_tokenize_1(bevd_0);
case 1388413072: return bem_copyTo_1(bevd_0);
case 1478791771: return bem_tokenizeIterator_1(bevd_0);
case -946351099: return bem_print_1(bevd_0);
case -1366175642: return bem_def_1(bevd_0);
case 1186086733: return bem_addToken_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -570336382: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -519401577: return bem_tokenizeIterator_2(bevd_0, bevd_1);
case -1111008594: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -548042918: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 159189467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2002686419: return bem_new_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 549568192: return bem_tokenize_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_4_9_TextTokenizer_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_2_4_9_TextTokenizer_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_9_TextTokenizer();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst = (BEC_2_4_9_TextTokenizer) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_9_TextTokenizer.bece_BEC_2_4_9_TextTokenizer_bevs_type;
}
}
