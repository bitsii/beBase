package be;
/* IO:File: source/build/NodeTypes.be */
public final class BEC_2_5_9_BuildNodeTypes extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildNodeTypes() { }
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;

public static BET_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_TRANSUNIT;
public BEC_2_4_3_MathInt bevp_VAR;
public BEC_2_4_3_MathInt bevp_NULL;
public BEC_2_4_3_MathInt bevp_CALL;
public BEC_2_4_3_MathInt bevp_NAMEPATH;
public BEC_2_4_3_MathInt bevp_CLASS;
public BEC_2_4_3_MathInt bevp_EMIT;
public BEC_2_4_3_MathInt bevp_IFEMIT;
public BEC_2_4_3_MathInt bevp_TRUE;
public BEC_2_4_3_MathInt bevp_FALSE;
public BEC_2_4_3_MathInt bevp_BRACES;
public BEC_2_4_3_MathInt bevp_RBRACES;
public BEC_2_4_3_MathInt bevp_RPARENS;
public BEC_2_4_3_MathInt bevp_LOOP;
public BEC_2_4_3_MathInt bevp_FIELDS;
public BEC_2_4_3_MathInt bevp_SLOTS;
public BEC_2_4_3_MathInt bevp_ELSE;
public BEC_2_4_3_MathInt bevp_FINALLY;
public BEC_2_4_3_MathInt bevp_TRY;
public BEC_2_4_3_MathInt bevp_CATCH;
public BEC_2_4_3_MathInt bevp_IF;
public BEC_2_4_3_MathInt bevp_SPACE;
public BEC_2_4_3_MathInt bevp_METHOD;
public BEC_2_4_3_MathInt bevp_DEFMOD;
public BEC_2_4_3_MathInt bevp_PARENS;
public BEC_2_4_3_MathInt bevp_FLOATL;
public BEC_2_4_3_MathInt bevp_INTL;
public BEC_2_4_3_MathInt bevp_DIVIDE;
public BEC_2_4_3_MathInt bevp_DIVIDE_ASSIGN;
public BEC_2_4_3_MathInt bevp_MULTIPLY;
public BEC_2_4_3_MathInt bevp_MULTIPLY_ASSIGN;
public BEC_2_4_3_MathInt bevp_STRQ;
public BEC_2_4_3_MathInt bevp_WSTRQ;
public BEC_2_4_3_MathInt bevp_STRINGL;
public BEC_2_4_3_MathInt bevp_WSTRINGL;
public BEC_2_4_3_MathInt bevp_NEWLINE;
public BEC_2_4_3_MathInt bevp_ASSIGN;
public BEC_2_4_3_MathInt bevp_EQUALS;
public BEC_2_4_3_MathInt bevp_NOT;
public BEC_2_4_3_MathInt bevp_NOT_EQUALS;
public BEC_2_4_3_MathInt bevp_OR;
public BEC_2_4_3_MathInt bevp_AND;
public BEC_2_4_3_MathInt bevp_OR_ASSIGN;
public BEC_2_4_3_MathInt bevp_AND_ASSIGN;
public BEC_2_4_3_MathInt bevp_LOGICAL_OR;
public BEC_2_4_3_MathInt bevp_LOGICAL_AND;
public BEC_2_4_3_MathInt bevp_GREATER;
public BEC_2_4_3_MathInt bevp_GREATER_EQUALS;
public BEC_2_4_3_MathInt bevp_LESSER;
public BEC_2_4_3_MathInt bevp_LESSER_EQUALS;
public BEC_2_4_3_MathInt bevp_ADD;
public BEC_2_4_3_MathInt bevp_INCREMENT;
public BEC_2_4_3_MathInt bevp_ADD_ASSIGN;
public BEC_2_4_3_MathInt bevp_INCREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_SUBTRACT;
public BEC_2_4_3_MathInt bevp_DECREMENT;
public BEC_2_4_3_MathInt bevp_SUBTRACT_ASSIGN;
public BEC_2_4_3_MathInt bevp_DECREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_ID;
public BEC_2_4_3_MathInt bevp_COLON;
public BEC_2_4_3_MathInt bevp_WHILE;
public BEC_2_4_3_MathInt bevp_FOREACH;
public BEC_2_4_3_MathInt bevp_BLOCK;
public BEC_2_4_3_MathInt bevp_USE;
public BEC_2_4_3_MathInt bevp_AS;
public BEC_2_4_3_MathInt bevp_SEMI;
public BEC_2_4_3_MathInt bevp_EXPR;
public BEC_2_4_3_MathInt bevp_COMMA;
public BEC_2_4_3_MathInt bevp_ACCESSOR;
public BEC_2_4_3_MathInt bevp_DOT;
public BEC_2_4_3_MathInt bevp_BREAK;
public BEC_2_4_3_MathInt bevp_IDX;
public BEC_2_4_3_MathInt bevp_IDXACC;
public BEC_2_4_3_MathInt bevp_RIDX;
public BEC_2_4_3_MathInt bevp_TOKEN;
public BEC_2_4_3_MathInt bevp_MODULUS;
public BEC_2_4_3_MathInt bevp_MODULUS_ASSIGN;
public BEC_2_4_3_MathInt bevp_ELIF;
public BEC_2_4_3_MathInt bevp_FOR;
public BEC_2_4_3_MathInt bevp_IN;
public BEC_2_4_3_MathInt bevp_CONTINUE;
public BEC_2_4_3_MathInt bevp_ATYPE;
public BEC_2_4_3_MathInt bevp_FSLASH;
public BEC_2_5_9_BuildNodeTypes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_default_0() throws Throwable {
bevp_TRANSUNIT = (new BEC_2_4_3_MathInt(1));
bevp_VAR = (new BEC_2_4_3_MathInt(2));
bevp_NULL = (new BEC_2_4_3_MathInt(3));
bevp_CALL = (new BEC_2_4_3_MathInt(4));
bevp_NAMEPATH = (new BEC_2_4_3_MathInt(5));
bevp_CLASS = (new BEC_2_4_3_MathInt(6));
bevp_EMIT = (new BEC_2_4_3_MathInt(8));
bevp_IFEMIT = (new BEC_2_4_3_MathInt(9));
bevp_TRUE = (new BEC_2_4_3_MathInt(10));
bevp_FALSE = (new BEC_2_4_3_MathInt(11));
bevp_BRACES = (new BEC_2_4_3_MathInt(12));
bevp_RBRACES = (new BEC_2_4_3_MathInt(13));
bevp_RPARENS = (new BEC_2_4_3_MathInt(14));
bevp_LOOP = (new BEC_2_4_3_MathInt(15));
bevp_FIELDS = (new BEC_2_4_3_MathInt(94));
bevp_SLOTS = (new BEC_2_4_3_MathInt(23));
bevp_ELSE = (new BEC_2_4_3_MathInt(16));
bevp_FINALLY = (new BEC_2_4_3_MathInt(93));
bevp_TRY = (new BEC_2_4_3_MathInt(17));
bevp_CATCH = (new BEC_2_4_3_MathInt(18));
bevp_IF = (new BEC_2_4_3_MathInt(19));
bevp_SPACE = (new BEC_2_4_3_MathInt(20));
bevp_METHOD = (new BEC_2_4_3_MathInt(21));
bevp_DEFMOD = (new BEC_2_4_3_MathInt(74));
bevp_PARENS = (new BEC_2_4_3_MathInt(22));
bevp_FLOATL = (new BEC_2_4_3_MathInt(25));
bevp_INTL = (new BEC_2_4_3_MathInt(26));
bevp_DIVIDE = (new BEC_2_4_3_MathInt(27));
bevp_DIVIDE_ASSIGN = (new BEC_2_4_3_MathInt(86));
bevp_MULTIPLY = (new BEC_2_4_3_MathInt(28));
bevp_MULTIPLY_ASSIGN = (new BEC_2_4_3_MathInt(87));
bevp_STRQ = (new BEC_2_4_3_MathInt(29));
bevp_WSTRQ = (new BEC_2_4_3_MathInt(30));
bevp_STRINGL = (new BEC_2_4_3_MathInt(31));
bevp_WSTRINGL = (new BEC_2_4_3_MathInt(33));
bevp_NEWLINE = (new BEC_2_4_3_MathInt(32));
bevp_ASSIGN = (new BEC_2_4_3_MathInt(35));
bevp_EQUALS = (new BEC_2_4_3_MathInt(36));
bevp_NOT = (new BEC_2_4_3_MathInt(37));
bevp_NOT_EQUALS = (new BEC_2_4_3_MathInt(38));
bevp_OR = (new BEC_2_4_3_MathInt(39));
bevp_AND = (new BEC_2_4_3_MathInt(40));
bevp_OR_ASSIGN = (new BEC_2_4_3_MathInt(92));
bevp_AND_ASSIGN = (new BEC_2_4_3_MathInt(91));
bevp_LOGICAL_OR = (new BEC_2_4_3_MathInt(89));
bevp_LOGICAL_AND = (new BEC_2_4_3_MathInt(90));
bevp_GREATER = (new BEC_2_4_3_MathInt(41));
bevp_GREATER_EQUALS = (new BEC_2_4_3_MathInt(42));
bevp_LESSER = (new BEC_2_4_3_MathInt(43));
bevp_LESSER_EQUALS = (new BEC_2_4_3_MathInt(44));
bevp_ADD = (new BEC_2_4_3_MathInt(45));
bevp_INCREMENT = (new BEC_2_4_3_MathInt(46));
bevp_ADD_ASSIGN = (new BEC_2_4_3_MathInt(47));
bevp_INCREMENT_ASSIGN = (new BEC_2_4_3_MathInt(84));
bevp_SUBTRACT = (new BEC_2_4_3_MathInt(48));
bevp_DECREMENT = (new BEC_2_4_3_MathInt(49));
bevp_SUBTRACT_ASSIGN = (new BEC_2_4_3_MathInt(83));
bevp_DECREMENT_ASSIGN = (new BEC_2_4_3_MathInt(85));
bevp_ID = (new BEC_2_4_3_MathInt(50));
bevp_COLON = (new BEC_2_4_3_MathInt(51));
bevp_WHILE = (new BEC_2_4_3_MathInt(52));
bevp_FOREACH = (new BEC_2_4_3_MathInt(53));
bevp_BLOCK = (new BEC_2_4_3_MathInt(72));
bevp_USE = (new BEC_2_4_3_MathInt(54));
bevp_AS = (new BEC_2_4_3_MathInt(55));
bevp_SEMI = (new BEC_2_4_3_MathInt(56));
bevp_EXPR = (new BEC_2_4_3_MathInt(57));
bevp_COMMA = (new BEC_2_4_3_MathInt(58));
bevp_ACCESSOR = (new BEC_2_4_3_MathInt(59));
bevp_DOT = (new BEC_2_4_3_MathInt(60));
bevp_BREAK = (new BEC_2_4_3_MathInt(61));
bevp_IDX = (new BEC_2_4_3_MathInt(62));
bevp_IDXACC = (new BEC_2_4_3_MathInt(73));
bevp_RIDX = (new BEC_2_4_3_MathInt(63));
bevp_TOKEN = (new BEC_2_4_3_MathInt(64));
bevp_MODULUS = (new BEC_2_4_3_MathInt(65));
bevp_MODULUS_ASSIGN = (new BEC_2_4_3_MathInt(88));
bevp_ELIF = (new BEC_2_4_3_MathInt(66));
bevp_FOR = (new BEC_2_4_3_MathInt(67));
bevp_IN = (new BEC_2_4_3_MathInt(68));
bevp_CONTINUE = (new BEC_2_4_3_MathInt(69));
bevp_ATYPE = (new BEC_2_4_3_MathInt(71));
bevp_FSLASH = (new BEC_2_4_3_MathInt(80));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRANSUNITGet_0() throws Throwable {
return bevp_TRANSUNIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRANSUNITGetDirect_0() throws Throwable {
return bevp_TRANSUNIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_VARGet_0() throws Throwable {
return bevp_VAR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_VARGetDirect_0() throws Throwable {
return bevp_VAR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_VARSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_VARSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NULLGet_0() throws Throwable {
return bevp_NULL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NULLGetDirect_0() throws Throwable {
return bevp_NULL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NULLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NULLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CALLGet_0() throws Throwable {
return bevp_CALL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CALLGetDirect_0() throws Throwable {
return bevp_CALL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CALLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CALLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NAMEPATHGet_0() throws Throwable {
return bevp_NAMEPATH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NAMEPATHGetDirect_0() throws Throwable {
return bevp_NAMEPATH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CLASSGet_0() throws Throwable {
return bevp_CLASS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CLASSGetDirect_0() throws Throwable {
return bevp_CLASS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CLASSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CLASSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EMITGet_0() throws Throwable {
return bevp_EMIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EMITGetDirect_0() throws Throwable {
return bevp_EMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EMITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFEMITGet_0() throws Throwable {
return bevp_IFEMIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IFEMITGetDirect_0() throws Throwable {
return bevp_IFEMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFEMITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IFEMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRUEGet_0() throws Throwable {
return bevp_TRUE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRUEGetDirect_0() throws Throwable {
return bevp_TRUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRUESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FALSEGet_0() throws Throwable {
return bevp_FALSE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FALSEGetDirect_0() throws Throwable {
return bevp_FALSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FALSESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FALSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BRACESGet_0() throws Throwable {
return bevp_BRACES;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BRACESGetDirect_0() throws Throwable {
return bevp_BRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BRACESSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RBRACESGet_0() throws Throwable {
return bevp_RBRACES;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RBRACESGetDirect_0() throws Throwable {
return bevp_RBRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RBRACESSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RBRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RPARENSGet_0() throws Throwable {
return bevp_RPARENS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RPARENSGetDirect_0() throws Throwable {
return bevp_RPARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RPARENSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RPARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOOPGet_0() throws Throwable {
return bevp_LOOP;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOOPGetDirect_0() throws Throwable {
return bevp_LOOP;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOOPSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOOPSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FIELDSGet_0() throws Throwable {
return bevp_FIELDS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FIELDSGetDirect_0() throws Throwable {
return bevp_FIELDS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FIELDSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FIELDS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FIELDSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FIELDS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SLOTSGet_0() throws Throwable {
return bevp_SLOTS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SLOTSGetDirect_0() throws Throwable {
return bevp_SLOTS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SLOTSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SLOTS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SLOTSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SLOTS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELSEGet_0() throws Throwable {
return bevp_ELSE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ELSEGetDirect_0() throws Throwable {
return bevp_ELSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELSESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ELSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FINALLYGet_0() throws Throwable {
return bevp_FINALLY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FINALLYGetDirect_0() throws Throwable {
return bevp_FINALLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FINALLYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FINALLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRYGet_0() throws Throwable {
return bevp_TRY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRYGetDirect_0() throws Throwable {
return bevp_TRY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CATCHGet_0() throws Throwable {
return bevp_CATCH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CATCHGetDirect_0() throws Throwable {
return bevp_CATCH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CATCHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CATCHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFGet_0() throws Throwable {
return bevp_IF;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IFGetDirect_0() throws Throwable {
return bevp_IF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SPACEGet_0() throws Throwable {
return bevp_SPACE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SPACEGetDirect_0() throws Throwable {
return bevp_SPACE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SPACESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SPACESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_METHODGet_0() throws Throwable {
return bevp_METHOD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_METHODGetDirect_0() throws Throwable {
return bevp_METHOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_METHODSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_METHODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DEFMODGet_0() throws Throwable {
return bevp_DEFMOD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DEFMODGetDirect_0() throws Throwable {
return bevp_DEFMOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DEFMODSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DEFMODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PARENSGet_0() throws Throwable {
return bevp_PARENS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_PARENSGetDirect_0() throws Throwable {
return bevp_PARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PARENSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_PARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FLOATLGet_0() throws Throwable {
return bevp_FLOATL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FLOATLGetDirect_0() throws Throwable {
return bevp_FLOATL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FLOATLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FLOATLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INTLGet_0() throws Throwable {
return bevp_INTL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INTLGetDirect_0() throws Throwable {
return bevp_INTL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INTLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INTLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDEGet_0() throws Throwable {
return bevp_DIVIDE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DIVIDEGetDirect_0() throws Throwable {
return bevp_DIVIDE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DIVIDESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGet_0() throws Throwable {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGetDirect_0() throws Throwable {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLYGet_0() throws Throwable {
return bevp_MULTIPLY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MULTIPLYGetDirect_0() throws Throwable {
return bevp_MULTIPLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGet_0() throws Throwable {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGetDirect_0() throws Throwable {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRQGet_0() throws Throwable {
return bevp_STRQ;
} /*method end*/
public final BEC_2_4_3_MathInt bem_STRQGetDirect_0() throws Throwable {
return bevp_STRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRQSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_STRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRQGet_0() throws Throwable {
return bevp_WSTRQ;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WSTRQGetDirect_0() throws Throwable {
return bevp_WSTRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRQSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WSTRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRINGLGet_0() throws Throwable {
return bevp_STRINGL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_STRINGLGetDirect_0() throws Throwable {
return bevp_STRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_STRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRINGLGet_0() throws Throwable {
return bevp_WSTRINGL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WSTRINGLGetDirect_0() throws Throwable {
return bevp_WSTRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NEWLINEGet_0() throws Throwable {
return bevp_NEWLINE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NEWLINEGetDirect_0() throws Throwable {
return bevp_NEWLINE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NEWLINESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NEWLINESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASSIGNGet_0() throws Throwable {
return bevp_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ASSIGNGetDirect_0() throws Throwable {
return bevp_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EQUALSGet_0() throws Throwable {
return bevp_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EQUALSGetDirect_0() throws Throwable {
return bevp_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOTGet_0() throws Throwable {
return bevp_NOT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NOTGetDirect_0() throws Throwable {
return bevp_NOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOT_EQUALSGet_0() throws Throwable {
return bevp_NOT_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NOT_EQUALSGetDirect_0() throws Throwable {
return bevp_NOT_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ORGet_0() throws Throwable {
return bevp_OR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ORGetDirect_0() throws Throwable {
return bevp_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ANDGet_0() throws Throwable {
return bevp_AND;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ANDGetDirect_0() throws Throwable {
return bevp_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_OR_ASSIGNGet_0() throws Throwable {
return bevp_OR_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_OR_ASSIGNGetDirect_0() throws Throwable {
return bevp_OR_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_AND_ASSIGNGet_0() throws Throwable {
return bevp_AND_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_AND_ASSIGNGetDirect_0() throws Throwable {
return bevp_AND_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ORGet_0() throws Throwable {
return bevp_LOGICAL_OR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOGICAL_ORGetDirect_0() throws Throwable {
return bevp_LOGICAL_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ANDGet_0() throws Throwable {
return bevp_LOGICAL_AND;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOGICAL_ANDGetDirect_0() throws Throwable {
return bevp_LOGICAL_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATERGet_0() throws Throwable {
return bevp_GREATER;
} /*method end*/
public final BEC_2_4_3_MathInt bem_GREATERGetDirect_0() throws Throwable {
return bevp_GREATER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATERSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_GREATERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATER_EQUALSGet_0() throws Throwable {
return bevp_GREATER_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_GREATER_EQUALSGetDirect_0() throws Throwable {
return bevp_GREATER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSERGet_0() throws Throwable {
return bevp_LESSER;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LESSERGetDirect_0() throws Throwable {
return bevp_LESSER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSERSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LESSERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSER_EQUALSGet_0() throws Throwable {
return bevp_LESSER_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LESSER_EQUALSGetDirect_0() throws Throwable {
return bevp_LESSER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADDGet_0() throws Throwable {
return bevp_ADD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ADDGetDirect_0() throws Throwable {
return bevp_ADD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ADDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENTGet_0() throws Throwable {
return bevp_INCREMENT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INCREMENTGetDirect_0() throws Throwable {
return bevp_INCREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INCREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADD_ASSIGNGet_0() throws Throwable {
return bevp_ADD_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ADD_ASSIGNGetDirect_0() throws Throwable {
return bevp_ADD_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGet_0() throws Throwable {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGetDirect_0() throws Throwable {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACTGet_0() throws Throwable {
return bevp_SUBTRACT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SUBTRACTGetDirect_0() throws Throwable {
return bevp_SUBTRACT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENTGet_0() throws Throwable {
return bevp_DECREMENT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DECREMENTGetDirect_0() throws Throwable {
return bevp_DECREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DECREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGet_0() throws Throwable {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGetDirect_0() throws Throwable {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGet_0() throws Throwable {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGetDirect_0() throws Throwable {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDGet_0() throws Throwable {
return bevp_ID;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDGetDirect_0() throws Throwable {
return bevp_ID;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COLONGet_0() throws Throwable {
return bevp_COLON;
} /*method end*/
public final BEC_2_4_3_MathInt bem_COLONGetDirect_0() throws Throwable {
return bevp_COLON;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COLONSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_COLONSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WHILEGet_0() throws Throwable {
return bevp_WHILE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WHILEGetDirect_0() throws Throwable {
return bevp_WHILE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WHILESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WHILESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FOREACHGet_0() throws Throwable {
return bevp_FOREACH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FOREACHGetDirect_0() throws Throwable {
return bevp_FOREACH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FOREACHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FOREACHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BLOCKGet_0() throws Throwable {
return bevp_BLOCK;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BLOCKGetDirect_0() throws Throwable {
return bevp_BLOCK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BLOCKSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BLOCKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_USEGet_0() throws Throwable {
return bevp_USE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_USEGetDirect_0() throws Throwable {
return bevp_USE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_USESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_USESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASGet_0() throws Throwable {
return bevp_AS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ASGetDirect_0() throws Throwable {
return bevp_AS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ASSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SEMIGet_0() throws Throwable {
return bevp_SEMI;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SEMIGetDirect_0() throws Throwable {
return bevp_SEMI;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SEMISet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SEMISetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EXPRGet_0() throws Throwable {
return bevp_EXPR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EXPRGetDirect_0() throws Throwable {
return bevp_EXPR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EXPRSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EXPRSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COMMAGet_0() throws Throwable {
return bevp_COMMA;
} /*method end*/
public final BEC_2_4_3_MathInt bem_COMMAGetDirect_0() throws Throwable {
return bevp_COMMA;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COMMASet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_COMMASetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ACCESSORGet_0() throws Throwable {
return bevp_ACCESSOR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ACCESSORGetDirect_0() throws Throwable {
return bevp_ACCESSOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ACCESSORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ACCESSORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DOTGet_0() throws Throwable {
return bevp_DOT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DOTGetDirect_0() throws Throwable {
return bevp_DOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DOTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BREAKGet_0() throws Throwable {
return bevp_BREAK;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BREAKGetDirect_0() throws Throwable {
return bevp_BREAK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BREAKSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BREAKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXGet_0() throws Throwable {
return bevp_IDX;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDXGetDirect_0() throws Throwable {
return bevp_IDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXACCGet_0() throws Throwable {
return bevp_IDXACC;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDXACCGetDirect_0() throws Throwable {
return bevp_IDXACC;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXACCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDXACCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RIDXGet_0() throws Throwable {
return bevp_RIDX;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RIDXGetDirect_0() throws Throwable {
return bevp_RIDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RIDXSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RIDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TOKENGet_0() throws Throwable {
return bevp_TOKEN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TOKENGetDirect_0() throws Throwable {
return bevp_TOKEN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TOKENSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TOKENSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUSGet_0() throws Throwable {
return bevp_MODULUS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MODULUSGetDirect_0() throws Throwable {
return bevp_MODULUS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MODULUSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGet_0() throws Throwable {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGetDirect_0() throws Throwable {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELIFGet_0() throws Throwable {
return bevp_ELIF;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ELIFGetDirect_0() throws Throwable {
return bevp_ELIF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELIFSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ELIFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FORGet_0() throws Throwable {
return bevp_FOR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FORGetDirect_0() throws Throwable {
return bevp_FOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INGet_0() throws Throwable {
return bevp_IN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INGetDirect_0() throws Throwable {
return bevp_IN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CONTINUEGet_0() throws Throwable {
return bevp_CONTINUE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CONTINUEGetDirect_0() throws Throwable {
return bevp_CONTINUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CONTINUESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CONTINUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ATYPEGet_0() throws Throwable {
return bevp_ATYPE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ATYPEGetDirect_0() throws Throwable {
return bevp_ATYPE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ATYPESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ATYPESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FSLASHGet_0() throws Throwable {
return bevp_FSLASH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FSLASHGetDirect_0() throws Throwable {
return bevp_FSLASH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FSLASHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FSLASHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 184, 187, 190, 194, 198, 201, 204, 208, 212, 215, 218, 222, 226, 229, 232, 236, 240, 243, 246, 250, 254, 257, 260, 264, 268, 271, 274, 278, 282, 285, 288, 292, 296, 299, 302, 306, 310, 313, 316, 320, 324, 327, 330, 334, 338, 341, 344, 348, 352, 355, 358, 362, 366, 369, 372, 376, 380, 383, 386, 390, 394, 397, 400, 404, 408, 411, 414, 418, 422, 425, 428, 432, 436, 439, 442, 446, 450, 453, 456, 460, 464, 467, 470, 474, 478, 481, 484, 488, 492, 495, 498, 502, 506, 509, 512, 516, 520, 523, 526, 530, 534, 537, 540, 544, 548, 551, 554, 558, 562, 565, 568, 572, 576, 579, 582, 586, 590, 593, 596, 600, 604, 607, 610, 614, 618, 621, 624, 628, 632, 635, 638, 642, 646, 649, 652, 656, 660, 663, 666, 670, 674, 677, 680, 684, 688, 691, 694, 698, 702, 705, 708, 712, 716, 719, 722, 726, 730, 733, 736, 740, 744, 747, 750, 754, 758, 761, 764, 768, 772, 775, 778, 782, 786, 789, 792, 796, 800, 803, 806, 810, 814, 817, 820, 824, 828, 831, 834, 838, 842, 845, 848, 852, 856, 859, 862, 866, 870, 873, 876, 880, 884, 887, 890, 894, 898, 901, 904, 908, 912, 915, 918, 922, 926, 929, 932, 936, 940, 943, 946, 950, 954, 957, 960, 964, 968, 971, 974, 978, 982, 985, 988, 992, 996, 999, 1002, 1006, 1010, 1013, 1016, 1020, 1024, 1027, 1030, 1034, 1038, 1041, 1044, 1048, 1052, 1055, 1058, 1062, 1066, 1069, 1072, 1076, 1080, 1083, 1086, 1090, 1094, 1097, 1100, 1104, 1108, 1111, 1114, 1118, 1122, 1125, 1128, 1132, 1136, 1139, 1142, 1146, 1150, 1153, 1156, 1160, 1164, 1167, 1170, 1174, 1178, 1181, 1184, 1188, 1192, 1195, 1198, 1202, 1206, 1209, 1212, 1216, 1220, 1223, 1226, 1230, 1234, 1237, 1240, 1244, 1248, 1251, 1254, 1258, 1262, 1265, 1268, 1272, 1276, 1279, 1282, 1286, 1290, 1293, 1296, 1300, 1304, 1307, 1310, 1314, 1318, 1321, 1324, 1328, 1332, 1335, 1338, 1342};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 12 98
new 0 12 98
assign 1 13 99
new 0 13 99
assign 1 14 100
new 0 14 100
assign 1 15 101
new 0 15 101
assign 1 16 102
new 0 16 102
assign 1 17 103
new 0 17 103
assign 1 18 104
new 0 18 104
assign 1 19 105
new 0 19 105
assign 1 20 106
new 0 20 106
assign 1 21 107
new 0 21 107
assign 1 22 108
new 0 22 108
assign 1 23 109
new 0 23 109
assign 1 24 110
new 0 24 110
assign 1 25 111
new 0 25 111
assign 1 26 112
new 0 26 112
assign 1 27 113
new 0 27 113
assign 1 28 114
new 0 28 114
assign 1 29 115
new 0 29 115
assign 1 30 116
new 0 30 116
assign 1 31 117
new 0 31 117
assign 1 32 118
new 0 32 118
assign 1 33 119
new 0 33 119
assign 1 34 120
new 0 34 120
assign 1 35 121
new 0 35 121
assign 1 36 122
new 0 36 122
assign 1 37 123
new 0 37 123
assign 1 38 124
new 0 38 124
assign 1 39 125
new 0 39 125
assign 1 40 126
new 0 40 126
assign 1 41 127
new 0 41 127
assign 1 42 128
new 0 42 128
assign 1 43 129
new 0 43 129
assign 1 44 130
new 0 44 130
assign 1 45 131
new 0 45 131
assign 1 46 132
new 0 46 132
assign 1 47 133
new 0 47 133
assign 1 48 134
new 0 48 134
assign 1 49 135
new 0 49 135
assign 1 50 136
new 0 50 136
assign 1 51 137
new 0 51 137
assign 1 52 138
new 0 52 138
assign 1 53 139
new 0 53 139
assign 1 54 140
new 0 54 140
assign 1 55 141
new 0 55 141
assign 1 56 142
new 0 56 142
assign 1 57 143
new 0 57 143
assign 1 58 144
new 0 58 144
assign 1 59 145
new 0 59 145
assign 1 60 146
new 0 60 146
assign 1 61 147
new 0 61 147
assign 1 62 148
new 0 62 148
assign 1 63 149
new 0 63 149
assign 1 64 150
new 0 64 150
assign 1 65 151
new 0 65 151
assign 1 66 152
new 0 66 152
assign 1 67 153
new 0 67 153
assign 1 68 154
new 0 68 154
assign 1 69 155
new 0 69 155
assign 1 70 156
new 0 70 156
assign 1 71 157
new 0 71 157
assign 1 72 158
new 0 72 158
assign 1 73 159
new 0 73 159
assign 1 74 160
new 0 74 160
assign 1 75 161
new 0 75 161
assign 1 76 162
new 0 76 162
assign 1 77 163
new 0 77 163
assign 1 78 164
new 0 78 164
assign 1 79 165
new 0 79 165
assign 1 80 166
new 0 80 166
assign 1 81 167
new 0 81 167
assign 1 82 168
new 0 82 168
assign 1 83 169
new 0 83 169
assign 1 84 170
new 0 84 170
assign 1 85 171
new 0 85 171
assign 1 86 172
new 0 86 172
assign 1 87 173
new 0 87 173
assign 1 88 174
new 0 88 174
assign 1 89 175
new 0 89 175
assign 1 90 176
new 0 90 176
assign 1 91 177
new 0 91 177
assign 1 92 178
new 0 92 178
assign 1 93 179
new 0 93 179
assign 1 94 180
new 0 94 180
return 1 0 184
return 1 0 187
assign 1 0 190
assign 1 0 194
return 1 0 198
return 1 0 201
assign 1 0 204
assign 1 0 208
return 1 0 212
return 1 0 215
assign 1 0 218
assign 1 0 222
return 1 0 226
return 1 0 229
assign 1 0 232
assign 1 0 236
return 1 0 240
return 1 0 243
assign 1 0 246
assign 1 0 250
return 1 0 254
return 1 0 257
assign 1 0 260
assign 1 0 264
return 1 0 268
return 1 0 271
assign 1 0 274
assign 1 0 278
return 1 0 282
return 1 0 285
assign 1 0 288
assign 1 0 292
return 1 0 296
return 1 0 299
assign 1 0 302
assign 1 0 306
return 1 0 310
return 1 0 313
assign 1 0 316
assign 1 0 320
return 1 0 324
return 1 0 327
assign 1 0 330
assign 1 0 334
return 1 0 338
return 1 0 341
assign 1 0 344
assign 1 0 348
return 1 0 352
return 1 0 355
assign 1 0 358
assign 1 0 362
return 1 0 366
return 1 0 369
assign 1 0 372
assign 1 0 376
return 1 0 380
return 1 0 383
assign 1 0 386
assign 1 0 390
return 1 0 394
return 1 0 397
assign 1 0 400
assign 1 0 404
return 1 0 408
return 1 0 411
assign 1 0 414
assign 1 0 418
return 1 0 422
return 1 0 425
assign 1 0 428
assign 1 0 432
return 1 0 436
return 1 0 439
assign 1 0 442
assign 1 0 446
return 1 0 450
return 1 0 453
assign 1 0 456
assign 1 0 460
return 1 0 464
return 1 0 467
assign 1 0 470
assign 1 0 474
return 1 0 478
return 1 0 481
assign 1 0 484
assign 1 0 488
return 1 0 492
return 1 0 495
assign 1 0 498
assign 1 0 502
return 1 0 506
return 1 0 509
assign 1 0 512
assign 1 0 516
return 1 0 520
return 1 0 523
assign 1 0 526
assign 1 0 530
return 1 0 534
return 1 0 537
assign 1 0 540
assign 1 0 544
return 1 0 548
return 1 0 551
assign 1 0 554
assign 1 0 558
return 1 0 562
return 1 0 565
assign 1 0 568
assign 1 0 572
return 1 0 576
return 1 0 579
assign 1 0 582
assign 1 0 586
return 1 0 590
return 1 0 593
assign 1 0 596
assign 1 0 600
return 1 0 604
return 1 0 607
assign 1 0 610
assign 1 0 614
return 1 0 618
return 1 0 621
assign 1 0 624
assign 1 0 628
return 1 0 632
return 1 0 635
assign 1 0 638
assign 1 0 642
return 1 0 646
return 1 0 649
assign 1 0 652
assign 1 0 656
return 1 0 660
return 1 0 663
assign 1 0 666
assign 1 0 670
return 1 0 674
return 1 0 677
assign 1 0 680
assign 1 0 684
return 1 0 688
return 1 0 691
assign 1 0 694
assign 1 0 698
return 1 0 702
return 1 0 705
assign 1 0 708
assign 1 0 712
return 1 0 716
return 1 0 719
assign 1 0 722
assign 1 0 726
return 1 0 730
return 1 0 733
assign 1 0 736
assign 1 0 740
return 1 0 744
return 1 0 747
assign 1 0 750
assign 1 0 754
return 1 0 758
return 1 0 761
assign 1 0 764
assign 1 0 768
return 1 0 772
return 1 0 775
assign 1 0 778
assign 1 0 782
return 1 0 786
return 1 0 789
assign 1 0 792
assign 1 0 796
return 1 0 800
return 1 0 803
assign 1 0 806
assign 1 0 810
return 1 0 814
return 1 0 817
assign 1 0 820
assign 1 0 824
return 1 0 828
return 1 0 831
assign 1 0 834
assign 1 0 838
return 1 0 842
return 1 0 845
assign 1 0 848
assign 1 0 852
return 1 0 856
return 1 0 859
assign 1 0 862
assign 1 0 866
return 1 0 870
return 1 0 873
assign 1 0 876
assign 1 0 880
return 1 0 884
return 1 0 887
assign 1 0 890
assign 1 0 894
return 1 0 898
return 1 0 901
assign 1 0 904
assign 1 0 908
return 1 0 912
return 1 0 915
assign 1 0 918
assign 1 0 922
return 1 0 926
return 1 0 929
assign 1 0 932
assign 1 0 936
return 1 0 940
return 1 0 943
assign 1 0 946
assign 1 0 950
return 1 0 954
return 1 0 957
assign 1 0 960
assign 1 0 964
return 1 0 968
return 1 0 971
assign 1 0 974
assign 1 0 978
return 1 0 982
return 1 0 985
assign 1 0 988
assign 1 0 992
return 1 0 996
return 1 0 999
assign 1 0 1002
assign 1 0 1006
return 1 0 1010
return 1 0 1013
assign 1 0 1016
assign 1 0 1020
return 1 0 1024
return 1 0 1027
assign 1 0 1030
assign 1 0 1034
return 1 0 1038
return 1 0 1041
assign 1 0 1044
assign 1 0 1048
return 1 0 1052
return 1 0 1055
assign 1 0 1058
assign 1 0 1062
return 1 0 1066
return 1 0 1069
assign 1 0 1072
assign 1 0 1076
return 1 0 1080
return 1 0 1083
assign 1 0 1086
assign 1 0 1090
return 1 0 1094
return 1 0 1097
assign 1 0 1100
assign 1 0 1104
return 1 0 1108
return 1 0 1111
assign 1 0 1114
assign 1 0 1118
return 1 0 1122
return 1 0 1125
assign 1 0 1128
assign 1 0 1132
return 1 0 1136
return 1 0 1139
assign 1 0 1142
assign 1 0 1146
return 1 0 1150
return 1 0 1153
assign 1 0 1156
assign 1 0 1160
return 1 0 1164
return 1 0 1167
assign 1 0 1170
assign 1 0 1174
return 1 0 1178
return 1 0 1181
assign 1 0 1184
assign 1 0 1188
return 1 0 1192
return 1 0 1195
assign 1 0 1198
assign 1 0 1202
return 1 0 1206
return 1 0 1209
assign 1 0 1212
assign 1 0 1216
return 1 0 1220
return 1 0 1223
assign 1 0 1226
assign 1 0 1230
return 1 0 1234
return 1 0 1237
assign 1 0 1240
assign 1 0 1244
return 1 0 1248
return 1 0 1251
assign 1 0 1254
assign 1 0 1258
return 1 0 1262
return 1 0 1265
assign 1 0 1268
assign 1 0 1272
return 1 0 1276
return 1 0 1279
assign 1 0 1282
assign 1 0 1286
return 1 0 1290
return 1 0 1293
assign 1 0 1296
assign 1 0 1300
return 1 0 1304
return 1 0 1307
assign 1 0 1310
assign 1 0 1314
return 1 0 1318
return 1 0 1321
assign 1 0 1324
assign 1 0 1328
return 1 0 1332
return 1 0 1335
assign 1 0 1338
assign 1 0 1342
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1358160839: return bem_NAMEPATHGetDirect_0();
case -1740139760: return bem_hashGet_0();
case 812172282: return bem_ASSIGNGet_0();
case 312867770: return bem_copy_0();
case -1291911296: return bem_CATCHGet_0();
case -1426160321: return bem_RBRACESGetDirect_0();
case 31026049: return bem_SUBTRACT_ASSIGNGetDirect_0();
case 933593509: return bem_MULTIPLY_ASSIGNGetDirect_0();
case 776893867: return bem_EXPRGetDirect_0();
case 1904325071: return bem_TRUEGet_0();
case 535200794: return bem_INGet_0();
case 1953372137: return bem_ELIFGet_0();
case 698624055: return bem_SEMIGetDirect_0();
case 715746627: return bem_CALLGet_0();
case 1322695920: return bem_MULTIPLY_ASSIGNGet_0();
case -106895381: return bem_MODULUSGetDirect_0();
case 591699035: return bem_CONTINUEGet_0();
case -1622370540: return bem_OR_ASSIGNGet_0();
case -782501133: return bem_USEGetDirect_0();
case -1032468562: return bem_TRANSUNITGetDirect_0();
case -1166694069: return bem_METHODGetDirect_0();
case -543890752: return bem_EXPRGet_0();
case 1811123266: return bem_DIVIDE_ASSIGNGet_0();
case -1670668106: return bem_NEWLINEGet_0();
case 1295245010: return bem_FOREACHGetDirect_0();
case -784064478: return bem_ELSEGet_0();
case 1726967168: return bem_BRACESGetDirect_0();
case -881029601: return bem_sourceFileNameGet_0();
case -1069707073: return bem_ELSEGetDirect_0();
case -1052650371: return bem_WSTRINGLGetDirect_0();
case -755054956: return bem_IFEMITGet_0();
case -1946791439: return bem_BRACESGet_0();
case -1974577983: return bem_COLONGet_0();
case 157686226: return bem_DEFMODGet_0();
case -572574339: return bem_IFGetDirect_0();
case -1220148932: return bem_WSTRINGLGet_0();
case -1752304625: return bem_GREATERGet_0();
case -1599932665: return bem_DECREMENTGet_0();
case 433462984: return bem_NULLGet_0();
case 903475696: return bem_FORGet_0();
case 805022552: return bem_iteratorGet_0();
case -2140314122: return bem_GREATERGetDirect_0();
case -127108746: return bem_NULLGetDirect_0();
case 710348298: return bem_DECREMENT_ASSIGNGet_0();
case -1060437226: return bem_GREATER_EQUALSGet_0();
case 872205109: return bem_IDGet_0();
case -823736676: return bem_LOOPGetDirect_0();
case 1382672250: return bem_WSTRQGet_0();
case 20575740: return bem_METHODGet_0();
case 1989554108: return bem_INCREMENTGetDirect_0();
case 1167958177: return bem_SPACEGetDirect_0();
case -2037492581: return bem_INCREMENT_ASSIGNGetDirect_0();
case -1166652039: return bem_ACCESSORGetDirect_0();
case -182271053: return bem_LOGICAL_ORGetDirect_0();
case 2134371471: return bem_NOT_EQUALSGetDirect_0();
case 1444904638: return bem_ORGetDirect_0();
case 2029624383: return bem_IDXACCGet_0();
case -1490389198: return bem_ACCESSORGet_0();
case -2103881755: return bem_NAMEPATHGet_0();
case 1591730622: return bem_ADDGetDirect_0();
case -1227493640: return bem_DEFMODGetDirect_0();
case 1032061260: return bem_CLASSGetDirect_0();
case -1620636716: return bem_ELIFGetDirect_0();
case -1104258259: return bem_classNameGet_0();
case 1464785373: return bem_OR_ASSIGNGetDirect_0();
case 118127393: return bem_AND_ASSIGNGetDirect_0();
case -250251778: return bem_LOGICAL_ANDGet_0();
case -920880692: return bem_BLOCKGetDirect_0();
case -1843019939: return bem_DECREMENTGetDirect_0();
case 1198673860: return bem_FALSEGetDirect_0();
case 534073927: return bem_FINALLYGet_0();
case 625064969: return bem_DIVIDEGetDirect_0();
case 218755408: return bem_SEMIGet_0();
case 1815791639: return bem_SLOTSGetDirect_0();
case -201623452: return bem_IDXGetDirect_0();
case 97147622: return bem_ADDGet_0();
case -442607815: return bem_MODULUS_ASSIGNGetDirect_0();
case 606034187: return bem_DIVIDEGet_0();
case 140556156: return bem_EQUALSGetDirect_0();
case 1444323071: return bem_LESSERGet_0();
case 2041748343: return bem_VARGetDirect_0();
case 296917147: return bem_NEWLINEGetDirect_0();
case -1965681532: return bem_LESSER_EQUALSGet_0();
case -479197154: return bem_ASSIGNGetDirect_0();
case -451581544: return bem_ATYPEGet_0();
case -2032420347: return bem_FSLASHGet_0();
case 397081021: return bem_LESSERGetDirect_0();
case 1408165053: return bem_COMMAGetDirect_0();
case -1652550405: return bem_INTLGet_0();
case -734654182: return bem_ATYPEGetDirect_0();
case 911217281: return bem_create_0();
case -1848911083: return bem_CLASSGet_0();
case 473353292: return bem_ADD_ASSIGNGetDirect_0();
case -1073514702: return bem_MULTIPLYGet_0();
case 743262544: return bem_GREATER_EQUALSGetDirect_0();
case -214862240: return bem_default_0();
case -1492371480: return bem_DIVIDE_ASSIGNGetDirect_0();
case 1013007232: return bem_SUBTRACTGetDirect_0();
case 714089984: return bem_DOTGet_0();
case 905073961: return bem_STRQGet_0();
case 2040817132: return bem_STRQGetDirect_0();
case 253888277: return bem_TRUEGetDirect_0();
case 998172412: return bem_TRYGetDirect_0();
case -208574652: return bem_PARENSGetDirect_0();
case -2004811168: return bem_INCREMENTGet_0();
case 805446427: return bem_MULTIPLYGetDirect_0();
case 2075269275: return bem_WHILEGetDirect_0();
case -548661343: return bem_print_0();
case -1114508645: return bem_RPARENSGetDirect_0();
case 1754139750: return bem_ANDGet_0();
case -397593968: return bem_FALSEGet_0();
case -1628869115: return bem_BREAKGetDirect_0();
case -372386813: return bem_WHILEGet_0();
case -708134813: return bem_BREAKGet_0();
case 1906024104: return bem_new_0();
case 53861742: return bem_tagGet_0();
case 1234286661: return bem_STRINGLGetDirect_0();
case -568919982: return bem_FIELDSGetDirect_0();
case -91967317: return bem_LESSER_EQUALSGetDirect_0();
case 191759553: return bem_INCREMENT_ASSIGNGet_0();
case 1764057441: return bem_AND_ASSIGNGet_0();
case -380320965: return bem_CONTINUEGetDirect_0();
case 1581666123: return bem_fieldNamesGet_0();
case 1068832909: return bem_FSLASHGetDirect_0();
case 1805455794: return bem_INGetDirect_0();
case 1427494108: return bem_CALLGetDirect_0();
case -906524540: return bem_DOTGetDirect_0();
case -1124199018: return bem_MODULUSGet_0();
case 2037250123: return bem_DECREMENT_ASSIGNGetDirect_0();
case -531805500: return bem_TRANSUNITGet_0();
case -1877158914: return bem_toString_0();
case -39886277: return bem_LOGICAL_ANDGetDirect_0();
case -1935010301: return bem_USEGet_0();
case -858606529: return bem_RPARENSGet_0();
case 1796557489: return bem_TOKENGet_0();
case -1863482867: return bem_CATCHGetDirect_0();
case 296409560: return bem_WSTRQGetDirect_0();
case -702371034: return bem_EMITGet_0();
case 1272709086: return bem_NOTGetDirect_0();
case 924208552: return bem_FLOATLGet_0();
case -392564074: return bem_IDXGet_0();
case 1563963565: return bem_COLONGetDirect_0();
case 1443810894: return bem_RBRACESGet_0();
case 907841855: return bem_COMMAGet_0();
case -742690701: return bem_LOOPGet_0();
case 2072506799: return bem_EQUALSGet_0();
case 1519628437: return bem_PARENSGet_0();
case 1295512637: return bem_NOT_EQUALSGet_0();
case -1609202022: return bem_ADD_ASSIGNGet_0();
case 1587074419: return bem_FIELDSGet_0();
case 348791894: return bem_ORGet_0();
case -1334190533: return bem_FLOATLGetDirect_0();
case 692671582: return bem_ASGetDirect_0();
case -376349537: return bem_RIDXGetDirect_0();
case 999507250: return bem_INTLGetDirect_0();
case 785067591: return bem_SUBTRACTGet_0();
case 1522146783: return bem_EMITGetDirect_0();
case 1956876351: return bem_SUBTRACT_ASSIGNGet_0();
case -1597188131: return bem_RIDXGet_0();
case -155788465: return bem_FOREACHGet_0();
case 648562308: return bem_SPACEGet_0();
case 555209861: return bem_TOKENGetDirect_0();
case -260477614: return bem_VARGet_0();
case 293244112: return bem_SLOTSGet_0();
case 2093977650: return bem_MODULUS_ASSIGNGet_0();
case -568867155: return bem_IDGetDirect_0();
case 1234465913: return bem_ASGet_0();
case 1424490278: return bem_IFGet_0();
case 520680983: return bem_NOTGet_0();
case -560791993: return bem_IFEMITGetDirect_0();
case 1325908576: return bem_LOGICAL_ORGet_0();
case -2077529385: return bem_STRINGLGet_0();
case -1289374186: return bem_TRYGet_0();
case 2037159659: return bem_BLOCKGet_0();
case 316819054: return bem_ANDGetDirect_0();
case 1435983763: return bem_FORGetDirect_0();
case -798163709: return bem_IDXACCGetDirect_0();
case 2014834506: return bem_FINALLYGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1729217415: return bem_NEWLINESet_1(bevd_0);
case 1943644638: return bem_TRUESet_1(bevd_0);
case 604218990: return bem_NOT_EQUALSSetDirect_1(bevd_0);
case -1036944734: return bem_TOKENSetDirect_1(bevd_0);
case -315861604: return bem_DECREMENT_ASSIGNSetDirect_1(bevd_0);
case -390045088: return bem_TOKENSet_1(bevd_0);
case -896137663: return bem_OR_ASSIGNSetDirect_1(bevd_0);
case 195130801: return bem_TRANSUNITSet_1(bevd_0);
case -1253823387: return bem_FORSet_1(bevd_0);
case 1944640939: return bem_SPACESetDirect_1(bevd_0);
case 1963630428: return bem_MULTIPLY_ASSIGNSet_1(bevd_0);
case 1471541672: return bem_RBRACESSetDirect_1(bevd_0);
case 1717441005: return bem_DIVIDE_ASSIGNSet_1(bevd_0);
case 1449012487: return bem_CATCHSetDirect_1(bevd_0);
case 1198016964: return bem_FALSESet_1(bevd_0);
case 826476359: return bem_FOREACHSetDirect_1(bevd_0);
case -822959682: return bem_BREAKSet_1(bevd_0);
case -1255993929: return bem_DECREMENT_ASSIGNSet_1(bevd_0);
case 1959510534: return bem_ELSESetDirect_1(bevd_0);
case -101313219: return bem_FALSESetDirect_1(bevd_0);
case 267892965: return bem_FLOATLSetDirect_1(bevd_0);
case 222188342: return bem_BLOCKSet_1(bevd_0);
case 778934379: return bem_WHILESet_1(bevd_0);
case -378141279: return bem_BREAKSetDirect_1(bevd_0);
case -2006518417: return bem_EQUALSSetDirect_1(bevd_0);
case -291880441: return bem_ORSetDirect_1(bevd_0);
case 349768369: return bem_METHODSetDirect_1(bevd_0);
case 489253828: return bem_otherClass_1(bevd_0);
case 1763945460: return bem_TRUESetDirect_1(bevd_0);
case 330275439: return bem_IFEMITSet_1(bevd_0);
case 1304705725: return bem_STRQSetDirect_1(bevd_0);
case -1477591270: return bem_SUBTRACT_ASSIGNSetDirect_1(bevd_0);
case 1473933369: return bem_NAMEPATHSetDirect_1(bevd_0);
case -1334974428: return bem_INTLSetDirect_1(bevd_0);
case 139207899: return bem_DECREMENTSetDirect_1(bevd_0);
case -516656734: return bem_NAMEPATHSet_1(bevd_0);
case 1114301310: return bem_def_1(bevd_0);
case 1483243175: return bem_GREATER_EQUALSSet_1(bevd_0);
case 1587184167: return bem_NOT_EQUALSSet_1(bevd_0);
case 277451563: return bem_MODULUSSetDirect_1(bevd_0);
case -861732433: return bem_LESSERSet_1(bevd_0);
case 2044878209: return bem_ORSet_1(bevd_0);
case -852065018: return bem_NEWLINESetDirect_1(bevd_0);
case -1709867539: return bem_INCREMENT_ASSIGNSetDirect_1(bevd_0);
case 2067600838: return bem_AND_ASSIGNSet_1(bevd_0);
case -1176794288: return bem_DOTSet_1(bevd_0);
case -1887247579: return bem_sameObject_1(bevd_0);
case 275683324: return bem_ASSIGNSetDirect_1(bevd_0);
case 1385898186: return bem_FIELDSSetDirect_1(bevd_0);
case -751531806: return bem_PARENSSet_1(bevd_0);
case 2039088293: return bem_STRQSet_1(bevd_0);
case 1020628076: return bem_ACCESSORSet_1(bevd_0);
case 1316221499: return bem_WSTRINGLSetDirect_1(bevd_0);
case 766944777: return bem_GREATERSet_1(bevd_0);
case 1072147299: return bem_LOGICAL_ANDSet_1(bevd_0);
case 1801522511: return bem_ASSIGNSet_1(bevd_0);
case 7026167: return bem_LOGICAL_ORSet_1(bevd_0);
case 532828138: return bem_MODULUS_ASSIGNSetDirect_1(bevd_0);
case 1381064542: return bem_MULTIPLYSet_1(bevd_0);
case -1131002309: return bem_WSTRQSet_1(bevd_0);
case -879213204: return bem_FOREACHSet_1(bevd_0);
case -767274867: return bem_CLASSSet_1(bevd_0);
case 793835000: return bem_RIDXSetDirect_1(bevd_0);
case 1462553164: return bem_EMITSet_1(bevd_0);
case 1241568425: return bem_SEMISet_1(bevd_0);
case 526157132: return bem_IDXACCSet_1(bevd_0);
case 2026553637: return bem_ANDSet_1(bevd_0);
case 1941574502: return bem_RIDXSet_1(bevd_0);
case 1309114610: return bem_EXPRSetDirect_1(bevd_0);
case -1177816857: return bem_RBRACESSet_1(bevd_0);
case 1560667354: return bem_ELIFSetDirect_1(bevd_0);
case -1454704797: return bem_NOTSet_1(bevd_0);
case 1848352478: return bem_PARENSSetDirect_1(bevd_0);
case -2949384: return bem_LESSER_EQUALSSetDirect_1(bevd_0);
case 2031895514: return bem_IDXSet_1(bevd_0);
case -59191809: return bem_INCREMENTSet_1(bevd_0);
case -825666436: return bem_WSTRQSetDirect_1(bevd_0);
case -1040609418: return bem_BRACESSetDirect_1(bevd_0);
case 672333772: return bem_CATCHSet_1(bevd_0);
case 743645269: return bem_SUBTRACT_ASSIGNSet_1(bevd_0);
case 1746153772: return bem_MODULUSSet_1(bevd_0);
case -157939942: return bem_IFSetDirect_1(bevd_0);
case 624400377: return bem_MODULUS_ASSIGNSet_1(bevd_0);
case -1304428406: return bem_DOTSetDirect_1(bevd_0);
case -895839040: return bem_DEFMODSet_1(bevd_0);
case -1676371190: return bem_ASSetDirect_1(bevd_0);
case -690017034: return bem_CLASSSetDirect_1(bevd_0);
case 1293339574: return bem_undef_1(bevd_0);
case -1836935279: return bem_CONTINUESetDirect_1(bevd_0);
case -1101022520: return bem_ATYPESetDirect_1(bevd_0);
case -1667703096: return bem_RPARENSSet_1(bevd_0);
case -612174163: return bem_ADD_ASSIGNSetDirect_1(bevd_0);
case 1329843467: return bem_EXPRSet_1(bevd_0);
case 18677202: return bem_equals_1(bevd_0);
case 1147655887: return bem_SUBTRACTSetDirect_1(bevd_0);
case -1848320461: return bem_SEMISetDirect_1(bevd_0);
case 520313702: return bem_INSet_1(bevd_0);
case 1020389092: return bem_ADDSet_1(bevd_0);
case 685828168: return bem_ATYPESet_1(bevd_0);
case 181695797: return bem_DECREMENTSet_1(bevd_0);
case -1185616503: return bem_FINALLYSetDirect_1(bevd_0);
case -716437615: return bem_USESetDirect_1(bevd_0);
case -255486328: return bem_LESSER_EQUALSSet_1(bevd_0);
case 229472688: return bem_ADDSetDirect_1(bevd_0);
case 521701389: return bem_LESSERSetDirect_1(bevd_0);
case 515581356: return bem_IDSetDirect_1(bevd_0);
case 2022702695: return bem_STRINGLSetDirect_1(bevd_0);
case -928381244: return bem_USESet_1(bevd_0);
case -1722501225: return bem_FLOATLSet_1(bevd_0);
case 741353786: return bem_NULLSet_1(bevd_0);
case -2140541605: return bem_FINALLYSet_1(bevd_0);
case 2047271936: return bem_DIVIDE_ASSIGNSetDirect_1(bevd_0);
case -822823929: return bem_BRACESSet_1(bevd_0);
case 2023666712: return bem_LOGICAL_ORSetDirect_1(bevd_0);
case -1770007986: return bem_INSetDirect_1(bevd_0);
case 1255589592: return bem_copyTo_1(bevd_0);
case 433592499: return bem_INCREMENTSetDirect_1(bevd_0);
case 558249851: return bem_notEquals_1(bevd_0);
case -761451620: return bem_OR_ASSIGNSet_1(bevd_0);
case -1180155112: return bem_ELIFSet_1(bevd_0);
case -170897218: return bem_VARSetDirect_1(bevd_0);
case 1078326289: return bem_LOOPSetDirect_1(bevd_0);
case -17308196: return bem_VARSet_1(bevd_0);
case 168235536: return bem_CONTINUESet_1(bevd_0);
case -1624962821: return bem_METHODSet_1(bevd_0);
case 1519459203: return bem_MULTIPLY_ASSIGNSetDirect_1(bevd_0);
case 1813244390: return bem_IFEMITSetDirect_1(bevd_0);
case -1696800830: return bem_IFSet_1(bevd_0);
case -992883636: return bem_SLOTSSet_1(bevd_0);
case 1302795542: return bem_ACCESSORSetDirect_1(bevd_0);
case -2061056385: return bem_IDXACCSetDirect_1(bevd_0);
case -1174873258: return bem_FORSetDirect_1(bevd_0);
case 2071654035: return bem_INTLSet_1(bevd_0);
case -2077041902: return bem_IDSet_1(bevd_0);
case -1907410595: return bem_COMMASet_1(bevd_0);
case 1368115990: return bem_ELSESet_1(bevd_0);
case 729780106: return bem_GREATERSetDirect_1(bevd_0);
case -143333371: return bem_RPARENSSetDirect_1(bevd_0);
case -509142293: return bem_CALLSet_1(bevd_0);
case -1819091346: return bem_FIELDSSet_1(bevd_0);
case -2019430343: return bem_LOGICAL_ANDSetDirect_1(bevd_0);
case 335566051: return bem_TRANSUNITSetDirect_1(bevd_0);
case -1931893921: return bem_NOTSetDirect_1(bevd_0);
case 1797377271: return bem_STRINGLSet_1(bevd_0);
case 276921405: return bem_IDXSetDirect_1(bevd_0);
case 31086553: return bem_AND_ASSIGNSetDirect_1(bevd_0);
case -1517374863: return bem_BLOCKSetDirect_1(bevd_0);
case -2138208694: return bem_SLOTSSetDirect_1(bevd_0);
case 1198176247: return bem_FSLASHSetDirect_1(bevd_0);
case -630551686: return bem_EQUALSSet_1(bevd_0);
case -190177077: return bem_SUBTRACTSet_1(bevd_0);
case -2055027109: return bem_DIVIDESetDirect_1(bevd_0);
case 642484807: return bem_LOOPSet_1(bevd_0);
case -1686604089: return bem_MULTIPLYSetDirect_1(bevd_0);
case -93028495: return bem_SPACESet_1(bevd_0);
case -1298677367: return bem_sameClass_1(bevd_0);
case 1433290729: return bem_sameType_1(bevd_0);
case 1448396693: return bem_EMITSetDirect_1(bevd_0);
case -242953528: return bem_ADD_ASSIGNSet_1(bevd_0);
case 324841177: return bem_ANDSetDirect_1(bevd_0);
case 240469909: return bem_COLONSetDirect_1(bevd_0);
case -1778457038: return bem_INCREMENT_ASSIGNSet_1(bevd_0);
case -212525259: return bem_COMMASetDirect_1(bevd_0);
case 2016581599: return bem_ASSet_1(bevd_0);
case -1953407145: return bem_DIVIDESet_1(bevd_0);
case -864998510: return bem_WHILESetDirect_1(bevd_0);
case 2136885703: return bem_CALLSetDirect_1(bevd_0);
case -1535881014: return bem_NULLSetDirect_1(bevd_0);
case -722779244: return bem_GREATER_EQUALSSetDirect_1(bevd_0);
case -208638672: return bem_TRYSet_1(bevd_0);
case 876486485: return bem_TRYSetDirect_1(bevd_0);
case -1560907688: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1038079014: return bem_FSLASHSet_1(bevd_0);
case -525226312: return bem_WSTRINGLSet_1(bevd_0);
case 748883491: return bem_DEFMODSetDirect_1(bevd_0);
case 1376758358: return bem_otherType_1(bevd_0);
case 1596003954: return bem_COLONSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 465163535: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 290208042: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 332629402: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 732425668: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -772732651: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildNodeTypes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildNodeTypes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildNodeTypes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst = (BEC_2_5_9_BuildNodeTypes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_type;
}
}
