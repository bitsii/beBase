package be;
/* IO:File: source/build/NodeTypes.be */
public final class BEC_2_5_9_BuildNodeTypes extends BEC_2_6_6_SystemObject {
public BEC_2_5_9_BuildNodeTypes() { }
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73};
private static byte[] becc_BEC_2_5_9_BuildNodeTypes_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x4E,0x6F,0x64,0x65,0x54,0x79,0x70,0x65,0x73,0x2E,0x62,0x65};
public static BEC_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;

public static BET_2_5_9_BuildNodeTypes bece_BEC_2_5_9_BuildNodeTypes_bevs_type;

public BEC_2_4_3_MathInt bevp_TRANSUNIT;
public BEC_2_4_3_MathInt bevp_VAR;
public BEC_2_4_3_MathInt bevp_NULL;
public BEC_2_4_3_MathInt bevp_CALL;
public BEC_2_4_3_MathInt bevp_NAMEPATH;
public BEC_2_4_3_MathInt bevp_CLASS;
public BEC_2_4_3_MathInt bevp_EMIT;
public BEC_2_4_3_MathInt bevp_IFEMIT;
public BEC_2_4_3_MathInt bevp_TRUE;
public BEC_2_4_3_MathInt bevp_FALSE;
public BEC_2_4_3_MathInt bevp_BRACES;
public BEC_2_4_3_MathInt bevp_RBRACES;
public BEC_2_4_3_MathInt bevp_RPARENS;
public BEC_2_4_3_MathInt bevp_LOOP;
public BEC_2_4_3_MathInt bevp_PROPERTIES;
public BEC_2_4_3_MathInt bevp_ELSE;
public BEC_2_4_3_MathInt bevp_FINALLY;
public BEC_2_4_3_MathInt bevp_TRY;
public BEC_2_4_3_MathInt bevp_CATCH;
public BEC_2_4_3_MathInt bevp_IF;
public BEC_2_4_3_MathInt bevp_SPACE;
public BEC_2_4_3_MathInt bevp_METHOD;
public BEC_2_4_3_MathInt bevp_DEFMOD;
public BEC_2_4_3_MathInt bevp_PARENS;
public BEC_2_4_3_MathInt bevp_FLOATL;
public BEC_2_4_3_MathInt bevp_INTL;
public BEC_2_4_3_MathInt bevp_DIVIDE;
public BEC_2_4_3_MathInt bevp_DIVIDE_ASSIGN;
public BEC_2_4_3_MathInt bevp_MULTIPLY;
public BEC_2_4_3_MathInt bevp_MULTIPLY_ASSIGN;
public BEC_2_4_3_MathInt bevp_STRQ;
public BEC_2_4_3_MathInt bevp_WSTRQ;
public BEC_2_4_3_MathInt bevp_STRINGL;
public BEC_2_4_3_MathInt bevp_WSTRINGL;
public BEC_2_4_3_MathInt bevp_NEWLINE;
public BEC_2_4_3_MathInt bevp_ASSIGN;
public BEC_2_4_3_MathInt bevp_EQUALS;
public BEC_2_4_3_MathInt bevp_NOT;
public BEC_2_4_3_MathInt bevp_NOT_EQUALS;
public BEC_2_4_3_MathInt bevp_OR;
public BEC_2_4_3_MathInt bevp_AND;
public BEC_2_4_3_MathInt bevp_OR_ASSIGN;
public BEC_2_4_3_MathInt bevp_AND_ASSIGN;
public BEC_2_4_3_MathInt bevp_LOGICAL_OR;
public BEC_2_4_3_MathInt bevp_LOGICAL_AND;
public BEC_2_4_3_MathInt bevp_GREATER;
public BEC_2_4_3_MathInt bevp_GREATER_EQUALS;
public BEC_2_4_3_MathInt bevp_LESSER;
public BEC_2_4_3_MathInt bevp_LESSER_EQUALS;
public BEC_2_4_3_MathInt bevp_ADD;
public BEC_2_4_3_MathInt bevp_INCREMENT;
public BEC_2_4_3_MathInt bevp_ADD_ASSIGN;
public BEC_2_4_3_MathInt bevp_INCREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_SUBTRACT;
public BEC_2_4_3_MathInt bevp_DECREMENT;
public BEC_2_4_3_MathInt bevp_SUBTRACT_ASSIGN;
public BEC_2_4_3_MathInt bevp_DECREMENT_ASSIGN;
public BEC_2_4_3_MathInt bevp_ID;
public BEC_2_4_3_MathInt bevp_COLON;
public BEC_2_4_3_MathInt bevp_WHILE;
public BEC_2_4_3_MathInt bevp_FOREACH;
public BEC_2_4_3_MathInt bevp_BLOCK;
public BEC_2_4_3_MathInt bevp_USE;
public BEC_2_4_3_MathInt bevp_AS;
public BEC_2_4_3_MathInt bevp_SEMI;
public BEC_2_4_3_MathInt bevp_EXPR;
public BEC_2_4_3_MathInt bevp_COMMA;
public BEC_2_4_3_MathInt bevp_ACCESSOR;
public BEC_2_4_3_MathInt bevp_DOT;
public BEC_2_4_3_MathInt bevp_BREAK;
public BEC_2_4_3_MathInt bevp_IDX;
public BEC_2_4_3_MathInt bevp_IDXACC;
public BEC_2_4_3_MathInt bevp_RIDX;
public BEC_2_4_3_MathInt bevp_TOKEN;
public BEC_2_4_3_MathInt bevp_MODULUS;
public BEC_2_4_3_MathInt bevp_MODULUS_ASSIGN;
public BEC_2_4_3_MathInt bevp_ELIF;
public BEC_2_4_3_MathInt bevp_FOR;
public BEC_2_4_3_MathInt bevp_IN;
public BEC_2_4_3_MathInt bevp_CONTINUE;
public BEC_2_4_3_MathInt bevp_ATYPE;
public BEC_2_4_3_MathInt bevp_FSLASH;
public BEC_2_5_9_BuildNodeTypes bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_default_0() throws Throwable {
bevp_TRANSUNIT = (new BEC_2_4_3_MathInt(1));
bevp_VAR = (new BEC_2_4_3_MathInt(2));
bevp_NULL = (new BEC_2_4_3_MathInt(3));
bevp_CALL = (new BEC_2_4_3_MathInt(4));
bevp_NAMEPATH = (new BEC_2_4_3_MathInt(5));
bevp_CLASS = (new BEC_2_4_3_MathInt(6));
bevp_EMIT = (new BEC_2_4_3_MathInt(8));
bevp_IFEMIT = (new BEC_2_4_3_MathInt(9));
bevp_TRUE = (new BEC_2_4_3_MathInt(10));
bevp_FALSE = (new BEC_2_4_3_MathInt(11));
bevp_BRACES = (new BEC_2_4_3_MathInt(12));
bevp_RBRACES = (new BEC_2_4_3_MathInt(13));
bevp_RPARENS = (new BEC_2_4_3_MathInt(14));
bevp_LOOP = (new BEC_2_4_3_MathInt(15));
bevp_PROPERTIES = (new BEC_2_4_3_MathInt(23));
bevp_ELSE = (new BEC_2_4_3_MathInt(16));
bevp_FINALLY = (new BEC_2_4_3_MathInt(93));
bevp_TRY = (new BEC_2_4_3_MathInt(17));
bevp_CATCH = (new BEC_2_4_3_MathInt(18));
bevp_IF = (new BEC_2_4_3_MathInt(19));
bevp_SPACE = (new BEC_2_4_3_MathInt(20));
bevp_METHOD = (new BEC_2_4_3_MathInt(21));
bevp_DEFMOD = (new BEC_2_4_3_MathInt(74));
bevp_PARENS = (new BEC_2_4_3_MathInt(22));
bevp_FLOATL = (new BEC_2_4_3_MathInt(25));
bevp_INTL = (new BEC_2_4_3_MathInt(26));
bevp_DIVIDE = (new BEC_2_4_3_MathInt(27));
bevp_DIVIDE_ASSIGN = (new BEC_2_4_3_MathInt(86));
bevp_MULTIPLY = (new BEC_2_4_3_MathInt(28));
bevp_MULTIPLY_ASSIGN = (new BEC_2_4_3_MathInt(87));
bevp_STRQ = (new BEC_2_4_3_MathInt(29));
bevp_WSTRQ = (new BEC_2_4_3_MathInt(30));
bevp_STRINGL = (new BEC_2_4_3_MathInt(31));
bevp_WSTRINGL = (new BEC_2_4_3_MathInt(33));
bevp_NEWLINE = (new BEC_2_4_3_MathInt(32));
bevp_ASSIGN = (new BEC_2_4_3_MathInt(35));
bevp_EQUALS = (new BEC_2_4_3_MathInt(36));
bevp_NOT = (new BEC_2_4_3_MathInt(37));
bevp_NOT_EQUALS = (new BEC_2_4_3_MathInt(38));
bevp_OR = (new BEC_2_4_3_MathInt(39));
bevp_AND = (new BEC_2_4_3_MathInt(40));
bevp_OR_ASSIGN = (new BEC_2_4_3_MathInt(92));
bevp_AND_ASSIGN = (new BEC_2_4_3_MathInt(91));
bevp_LOGICAL_OR = (new BEC_2_4_3_MathInt(89));
bevp_LOGICAL_AND = (new BEC_2_4_3_MathInt(90));
bevp_GREATER = (new BEC_2_4_3_MathInt(41));
bevp_GREATER_EQUALS = (new BEC_2_4_3_MathInt(42));
bevp_LESSER = (new BEC_2_4_3_MathInt(43));
bevp_LESSER_EQUALS = (new BEC_2_4_3_MathInt(44));
bevp_ADD = (new BEC_2_4_3_MathInt(45));
bevp_INCREMENT = (new BEC_2_4_3_MathInt(46));
bevp_ADD_ASSIGN = (new BEC_2_4_3_MathInt(47));
bevp_INCREMENT_ASSIGN = (new BEC_2_4_3_MathInt(84));
bevp_SUBTRACT = (new BEC_2_4_3_MathInt(48));
bevp_DECREMENT = (new BEC_2_4_3_MathInt(49));
bevp_SUBTRACT_ASSIGN = (new BEC_2_4_3_MathInt(83));
bevp_DECREMENT_ASSIGN = (new BEC_2_4_3_MathInt(85));
bevp_ID = (new BEC_2_4_3_MathInt(50));
bevp_COLON = (new BEC_2_4_3_MathInt(51));
bevp_WHILE = (new BEC_2_4_3_MathInt(52));
bevp_FOREACH = (new BEC_2_4_3_MathInt(53));
bevp_BLOCK = (new BEC_2_4_3_MathInt(72));
bevp_USE = (new BEC_2_4_3_MathInt(54));
bevp_AS = (new BEC_2_4_3_MathInt(55));
bevp_SEMI = (new BEC_2_4_3_MathInt(56));
bevp_EXPR = (new BEC_2_4_3_MathInt(57));
bevp_COMMA = (new BEC_2_4_3_MathInt(58));
bevp_ACCESSOR = (new BEC_2_4_3_MathInt(59));
bevp_DOT = (new BEC_2_4_3_MathInt(60));
bevp_BREAK = (new BEC_2_4_3_MathInt(61));
bevp_IDX = (new BEC_2_4_3_MathInt(62));
bevp_IDXACC = (new BEC_2_4_3_MathInt(73));
bevp_RIDX = (new BEC_2_4_3_MathInt(63));
bevp_TOKEN = (new BEC_2_4_3_MathInt(64));
bevp_MODULUS = (new BEC_2_4_3_MathInt(65));
bevp_MODULUS_ASSIGN = (new BEC_2_4_3_MathInt(88));
bevp_ELIF = (new BEC_2_4_3_MathInt(66));
bevp_FOR = (new BEC_2_4_3_MathInt(67));
bevp_IN = (new BEC_2_4_3_MathInt(68));
bevp_CONTINUE = (new BEC_2_4_3_MathInt(69));
bevp_ATYPE = (new BEC_2_4_3_MathInt(71));
bevp_FSLASH = (new BEC_2_4_3_MathInt(80));
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRANSUNITGet_0() throws Throwable {
return bevp_TRANSUNIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRANSUNITGetDirect_0() throws Throwable {
return bevp_TRANSUNIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRANSUNITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRANSUNIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_VARGet_0() throws Throwable {
return bevp_VAR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_VARGetDirect_0() throws Throwable {
return bevp_VAR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_VARSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_VARSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_VAR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NULLGet_0() throws Throwable {
return bevp_NULL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NULLGetDirect_0() throws Throwable {
return bevp_NULL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NULLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NULLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NULL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CALLGet_0() throws Throwable {
return bevp_CALL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CALLGetDirect_0() throws Throwable {
return bevp_CALL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CALLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CALLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CALL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NAMEPATHGet_0() throws Throwable {
return bevp_NAMEPATH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NAMEPATHGetDirect_0() throws Throwable {
return bevp_NAMEPATH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NAMEPATHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NAMEPATH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CLASSGet_0() throws Throwable {
return bevp_CLASS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CLASSGetDirect_0() throws Throwable {
return bevp_CLASS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CLASSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CLASSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CLASS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EMITGet_0() throws Throwable {
return bevp_EMIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EMITGetDirect_0() throws Throwable {
return bevp_EMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EMITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFEMITGet_0() throws Throwable {
return bevp_IFEMIT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IFEMITGetDirect_0() throws Throwable {
return bevp_IFEMIT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFEMITSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IFEMITSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IFEMIT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRUEGet_0() throws Throwable {
return bevp_TRUE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRUEGetDirect_0() throws Throwable {
return bevp_TRUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRUESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FALSEGet_0() throws Throwable {
return bevp_FALSE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FALSEGetDirect_0() throws Throwable {
return bevp_FALSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FALSESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FALSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FALSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BRACESGet_0() throws Throwable {
return bevp_BRACES;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BRACESGetDirect_0() throws Throwable {
return bevp_BRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BRACESSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RBRACESGet_0() throws Throwable {
return bevp_RBRACES;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RBRACESGetDirect_0() throws Throwable {
return bevp_RBRACES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RBRACESSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RBRACESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RBRACES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RPARENSGet_0() throws Throwable {
return bevp_RPARENS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RPARENSGetDirect_0() throws Throwable {
return bevp_RPARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RPARENSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RPARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RPARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOOPGet_0() throws Throwable {
return bevp_LOOP;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOOPGetDirect_0() throws Throwable {
return bevp_LOOP;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOOPSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOOPSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOOP = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PROPERTIESGet_0() throws Throwable {
return bevp_PROPERTIES;
} /*method end*/
public final BEC_2_4_3_MathInt bem_PROPERTIESGetDirect_0() throws Throwable {
return bevp_PROPERTIES;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PROPERTIESSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_PROPERTIES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_PROPERTIESSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_PROPERTIES = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELSEGet_0() throws Throwable {
return bevp_ELSE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ELSEGetDirect_0() throws Throwable {
return bevp_ELSE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELSESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ELSESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ELSE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FINALLYGet_0() throws Throwable {
return bevp_FINALLY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FINALLYGetDirect_0() throws Throwable {
return bevp_FINALLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FINALLYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FINALLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FINALLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TRYGet_0() throws Throwable {
return bevp_TRY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TRYGetDirect_0() throws Throwable {
return bevp_TRY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TRYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TRYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TRY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CATCHGet_0() throws Throwable {
return bevp_CATCH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CATCHGetDirect_0() throws Throwable {
return bevp_CATCH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CATCHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CATCHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CATCH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IFGet_0() throws Throwable {
return bevp_IF;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IFGetDirect_0() throws Throwable {
return bevp_IF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IFSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SPACEGet_0() throws Throwable {
return bevp_SPACE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SPACEGetDirect_0() throws Throwable {
return bevp_SPACE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SPACESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SPACESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SPACE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_METHODGet_0() throws Throwable {
return bevp_METHOD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_METHODGetDirect_0() throws Throwable {
return bevp_METHOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_METHODSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_METHODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_METHOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DEFMODGet_0() throws Throwable {
return bevp_DEFMOD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DEFMODGetDirect_0() throws Throwable {
return bevp_DEFMOD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DEFMODSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DEFMODSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DEFMOD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_PARENSGet_0() throws Throwable {
return bevp_PARENS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_PARENSGetDirect_0() throws Throwable {
return bevp_PARENS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_PARENSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_PARENSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_PARENS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FLOATLGet_0() throws Throwable {
return bevp_FLOATL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FLOATLGetDirect_0() throws Throwable {
return bevp_FLOATL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FLOATLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FLOATLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FLOATL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INTLGet_0() throws Throwable {
return bevp_INTL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INTLGetDirect_0() throws Throwable {
return bevp_INTL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INTLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INTLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INTL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDEGet_0() throws Throwable {
return bevp_DIVIDE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DIVIDEGetDirect_0() throws Throwable {
return bevp_DIVIDE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DIVIDESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DIVIDE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGet_0() throws Throwable {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DIVIDE_ASSIGNGetDirect_0() throws Throwable {
return bevp_DIVIDE_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DIVIDE_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DIVIDE_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLYGet_0() throws Throwable {
return bevp_MULTIPLY;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MULTIPLYGetDirect_0() throws Throwable {
return bevp_MULTIPLY;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MULTIPLYSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MULTIPLY = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGet_0() throws Throwable {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MULTIPLY_ASSIGNGetDirect_0() throws Throwable {
return bevp_MULTIPLY_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MULTIPLY_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MULTIPLY_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRQGet_0() throws Throwable {
return bevp_STRQ;
} /*method end*/
public final BEC_2_4_3_MathInt bem_STRQGetDirect_0() throws Throwable {
return bevp_STRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRQSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_STRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_STRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRQGet_0() throws Throwable {
return bevp_WSTRQ;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WSTRQGetDirect_0() throws Throwable {
return bevp_WSTRQ;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRQSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WSTRQSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WSTRQ = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_STRINGLGet_0() throws Throwable {
return bevp_STRINGL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_STRINGLGetDirect_0() throws Throwable {
return bevp_STRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_STRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_STRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_STRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WSTRINGLGet_0() throws Throwable {
return bevp_WSTRINGL;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WSTRINGLGetDirect_0() throws Throwable {
return bevp_WSTRINGL;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WSTRINGLSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WSTRINGL = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NEWLINEGet_0() throws Throwable {
return bevp_NEWLINE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NEWLINEGetDirect_0() throws Throwable {
return bevp_NEWLINE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NEWLINESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NEWLINESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NEWLINE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASSIGNGet_0() throws Throwable {
return bevp_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ASSIGNGetDirect_0() throws Throwable {
return bevp_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EQUALSGet_0() throws Throwable {
return bevp_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EQUALSGetDirect_0() throws Throwable {
return bevp_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOTGet_0() throws Throwable {
return bevp_NOT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NOTGetDirect_0() throws Throwable {
return bevp_NOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_NOT_EQUALSGet_0() throws Throwable {
return bevp_NOT_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_NOT_EQUALSGetDirect_0() throws Throwable {
return bevp_NOT_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_NOT_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_NOT_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ORGet_0() throws Throwable {
return bevp_OR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ORGetDirect_0() throws Throwable {
return bevp_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ANDGet_0() throws Throwable {
return bevp_AND;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ANDGetDirect_0() throws Throwable {
return bevp_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_OR_ASSIGNGet_0() throws Throwable {
return bevp_OR_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_OR_ASSIGNGetDirect_0() throws Throwable {
return bevp_OR_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_OR_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_OR_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_AND_ASSIGNGet_0() throws Throwable {
return bevp_AND_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_AND_ASSIGNGetDirect_0() throws Throwable {
return bevp_AND_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_AND_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AND_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ORGet_0() throws Throwable {
return bevp_LOGICAL_OR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOGICAL_ORGetDirect_0() throws Throwable {
return bevp_LOGICAL_OR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOGICAL_OR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LOGICAL_ANDGet_0() throws Throwable {
return bevp_LOGICAL_AND;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LOGICAL_ANDGetDirect_0() throws Throwable {
return bevp_LOGICAL_AND;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LOGICAL_ANDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LOGICAL_AND = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATERGet_0() throws Throwable {
return bevp_GREATER;
} /*method end*/
public final BEC_2_4_3_MathInt bem_GREATERGetDirect_0() throws Throwable {
return bevp_GREATER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATERSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_GREATERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_GREATER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_GREATER_EQUALSGet_0() throws Throwable {
return bevp_GREATER_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_GREATER_EQUALSGetDirect_0() throws Throwable {
return bevp_GREATER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_GREATER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_GREATER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSERGet_0() throws Throwable {
return bevp_LESSER;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LESSERGetDirect_0() throws Throwable {
return bevp_LESSER;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSERSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LESSERSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LESSER = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_LESSER_EQUALSGet_0() throws Throwable {
return bevp_LESSER_EQUALS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_LESSER_EQUALSGetDirect_0() throws Throwable {
return bevp_LESSER_EQUALS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_LESSER_EQUALSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_LESSER_EQUALS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADDGet_0() throws Throwable {
return bevp_ADD;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ADDGetDirect_0() throws Throwable {
return bevp_ADD;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ADDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ADD = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENTGet_0() throws Throwable {
return bevp_INCREMENT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INCREMENTGetDirect_0() throws Throwable {
return bevp_INCREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INCREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INCREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ADD_ASSIGNGet_0() throws Throwable {
return bevp_ADD_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ADD_ASSIGNGetDirect_0() throws Throwable {
return bevp_ADD_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ADD_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ADD_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGet_0() throws Throwable {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INCREMENT_ASSIGNGetDirect_0() throws Throwable {
return bevp_INCREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INCREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_INCREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACTGet_0() throws Throwable {
return bevp_SUBTRACT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SUBTRACTGetDirect_0() throws Throwable {
return bevp_SUBTRACT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SUBTRACTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SUBTRACT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENTGet_0() throws Throwable {
return bevp_DECREMENT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DECREMENTGetDirect_0() throws Throwable {
return bevp_DECREMENT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DECREMENTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DECREMENT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGet_0() throws Throwable {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SUBTRACT_ASSIGNGetDirect_0() throws Throwable {
return bevp_SUBTRACT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SUBTRACT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SUBTRACT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGet_0() throws Throwable {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DECREMENT_ASSIGNGetDirect_0() throws Throwable {
return bevp_DECREMENT_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DECREMENT_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DECREMENT_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDGet_0() throws Throwable {
return bevp_ID;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDGetDirect_0() throws Throwable {
return bevp_ID;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ID = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COLONGet_0() throws Throwable {
return bevp_COLON;
} /*method end*/
public final BEC_2_4_3_MathInt bem_COLONGetDirect_0() throws Throwable {
return bevp_COLON;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COLONSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_COLONSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_COLON = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_WHILEGet_0() throws Throwable {
return bevp_WHILE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_WHILEGetDirect_0() throws Throwable {
return bevp_WHILE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_WHILESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_WHILESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_WHILE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FOREACHGet_0() throws Throwable {
return bevp_FOREACH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FOREACHGetDirect_0() throws Throwable {
return bevp_FOREACH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FOREACHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FOREACHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FOREACH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BLOCKGet_0() throws Throwable {
return bevp_BLOCK;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BLOCKGetDirect_0() throws Throwable {
return bevp_BLOCK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BLOCKSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BLOCKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BLOCK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_USEGet_0() throws Throwable {
return bevp_USE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_USEGetDirect_0() throws Throwable {
return bevp_USE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_USESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_USESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_USE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ASGet_0() throws Throwable {
return bevp_AS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ASGetDirect_0() throws Throwable {
return bevp_AS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ASSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ASSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_AS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_SEMIGet_0() throws Throwable {
return bevp_SEMI;
} /*method end*/
public final BEC_2_4_3_MathInt bem_SEMIGetDirect_0() throws Throwable {
return bevp_SEMI;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_SEMISet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_SEMISetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_SEMI = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_EXPRGet_0() throws Throwable {
return bevp_EXPR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_EXPRGetDirect_0() throws Throwable {
return bevp_EXPR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_EXPRSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_EXPRSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_EXPR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_COMMAGet_0() throws Throwable {
return bevp_COMMA;
} /*method end*/
public final BEC_2_4_3_MathInt bem_COMMAGetDirect_0() throws Throwable {
return bevp_COMMA;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_COMMASet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_COMMASetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_COMMA = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ACCESSORGet_0() throws Throwable {
return bevp_ACCESSOR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ACCESSORGetDirect_0() throws Throwable {
return bevp_ACCESSOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ACCESSORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ACCESSORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ACCESSOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_DOTGet_0() throws Throwable {
return bevp_DOT;
} /*method end*/
public final BEC_2_4_3_MathInt bem_DOTGetDirect_0() throws Throwable {
return bevp_DOT;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_DOTSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_DOTSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_DOT = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_BREAKGet_0() throws Throwable {
return bevp_BREAK;
} /*method end*/
public final BEC_2_4_3_MathInt bem_BREAKGetDirect_0() throws Throwable {
return bevp_BREAK;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_BREAKSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_BREAKSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_BREAK = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXGet_0() throws Throwable {
return bevp_IDX;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDXGetDirect_0() throws Throwable {
return bevp_IDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_IDXACCGet_0() throws Throwable {
return bevp_IDXACC;
} /*method end*/
public final BEC_2_4_3_MathInt bem_IDXACCGetDirect_0() throws Throwable {
return bevp_IDXACC;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_IDXACCSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_IDXACCSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IDXACC = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_RIDXGet_0() throws Throwable {
return bevp_RIDX;
} /*method end*/
public final BEC_2_4_3_MathInt bem_RIDXGetDirect_0() throws Throwable {
return bevp_RIDX;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_RIDXSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_RIDXSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_RIDX = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_TOKENGet_0() throws Throwable {
return bevp_TOKEN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_TOKENGetDirect_0() throws Throwable {
return bevp_TOKEN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_TOKENSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_TOKENSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_TOKEN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUSGet_0() throws Throwable {
return bevp_MODULUS;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MODULUSGetDirect_0() throws Throwable {
return bevp_MODULUS;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUSSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MODULUSSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MODULUS = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGet_0() throws Throwable {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_MODULUS_ASSIGNGetDirect_0() throws Throwable {
return bevp_MODULUS_ASSIGN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_MODULUS_ASSIGNSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_MODULUS_ASSIGN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ELIFGet_0() throws Throwable {
return bevp_ELIF;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ELIFGetDirect_0() throws Throwable {
return bevp_ELIF;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ELIFSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ELIFSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ELIF = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FORGet_0() throws Throwable {
return bevp_FOR;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FORGetDirect_0() throws Throwable {
return bevp_FOR;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FORSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FORSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FOR = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_INGet_0() throws Throwable {
return bevp_IN;
} /*method end*/
public final BEC_2_4_3_MathInt bem_INGetDirect_0() throws Throwable {
return bevp_IN;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_INSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_INSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_IN = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_CONTINUEGet_0() throws Throwable {
return bevp_CONTINUE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_CONTINUEGetDirect_0() throws Throwable {
return bevp_CONTINUE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_CONTINUESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_CONTINUESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_CONTINUE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_ATYPEGet_0() throws Throwable {
return bevp_ATYPE;
} /*method end*/
public final BEC_2_4_3_MathInt bem_ATYPEGetDirect_0() throws Throwable {
return bevp_ATYPE;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ATYPESet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ATYPESetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ATYPE = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_FSLASHGet_0() throws Throwable {
return bevp_FSLASH;
} /*method end*/
public final BEC_2_4_3_MathInt bem_FSLASHGetDirect_0() throws Throwable {
return bevp_FSLASH;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_FSLASHSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_FSLASHSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_FSLASH = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 182, 185, 188, 192, 196, 199, 202, 206, 210, 213, 216, 220, 224, 227, 230, 234, 238, 241, 244, 248, 252, 255, 258, 262, 266, 269, 272, 276, 280, 283, 286, 290, 294, 297, 300, 304, 308, 311, 314, 318, 322, 325, 328, 332, 336, 339, 342, 346, 350, 353, 356, 360, 364, 367, 370, 374, 378, 381, 384, 388, 392, 395, 398, 402, 406, 409, 412, 416, 420, 423, 426, 430, 434, 437, 440, 444, 448, 451, 454, 458, 462, 465, 468, 472, 476, 479, 482, 486, 490, 493, 496, 500, 504, 507, 510, 514, 518, 521, 524, 528, 532, 535, 538, 542, 546, 549, 552, 556, 560, 563, 566, 570, 574, 577, 580, 584, 588, 591, 594, 598, 602, 605, 608, 612, 616, 619, 622, 626, 630, 633, 636, 640, 644, 647, 650, 654, 658, 661, 664, 668, 672, 675, 678, 682, 686, 689, 692, 696, 700, 703, 706, 710, 714, 717, 720, 724, 728, 731, 734, 738, 742, 745, 748, 752, 756, 759, 762, 766, 770, 773, 776, 780, 784, 787, 790, 794, 798, 801, 804, 808, 812, 815, 818, 822, 826, 829, 832, 836, 840, 843, 846, 850, 854, 857, 860, 864, 868, 871, 874, 878, 882, 885, 888, 892, 896, 899, 902, 906, 910, 913, 916, 920, 924, 927, 930, 934, 938, 941, 944, 948, 952, 955, 958, 962, 966, 969, 972, 976, 980, 983, 986, 990, 994, 997, 1000, 1004, 1008, 1011, 1014, 1018, 1022, 1025, 1028, 1032, 1036, 1039, 1042, 1046, 1050, 1053, 1056, 1060, 1064, 1067, 1070, 1074, 1078, 1081, 1084, 1088, 1092, 1095, 1098, 1102, 1106, 1109, 1112, 1116, 1120, 1123, 1126, 1130, 1134, 1137, 1140, 1144, 1148, 1151, 1154, 1158, 1162, 1165, 1168, 1172, 1176, 1179, 1182, 1186, 1190, 1193, 1196, 1200, 1204, 1207, 1210, 1214, 1218, 1221, 1224, 1228, 1232, 1235, 1238, 1242, 1246, 1249, 1252, 1256, 1260, 1263, 1266, 1270, 1274, 1277, 1280, 1284, 1288, 1291, 1294, 1298, 1302, 1305, 1308, 1312, 1316, 1319, 1322, 1326};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 12 97
new 0 12 97
assign 1 13 98
new 0 13 98
assign 1 14 99
new 0 14 99
assign 1 15 100
new 0 15 100
assign 1 16 101
new 0 16 101
assign 1 17 102
new 0 17 102
assign 1 18 103
new 0 18 103
assign 1 19 104
new 0 19 104
assign 1 20 105
new 0 20 105
assign 1 21 106
new 0 21 106
assign 1 22 107
new 0 22 107
assign 1 23 108
new 0 23 108
assign 1 24 109
new 0 24 109
assign 1 25 110
new 0 25 110
assign 1 26 111
new 0 26 111
assign 1 27 112
new 0 27 112
assign 1 28 113
new 0 28 113
assign 1 29 114
new 0 29 114
assign 1 30 115
new 0 30 115
assign 1 31 116
new 0 31 116
assign 1 32 117
new 0 32 117
assign 1 33 118
new 0 33 118
assign 1 34 119
new 0 34 119
assign 1 35 120
new 0 35 120
assign 1 36 121
new 0 36 121
assign 1 37 122
new 0 37 122
assign 1 38 123
new 0 38 123
assign 1 39 124
new 0 39 124
assign 1 40 125
new 0 40 125
assign 1 41 126
new 0 41 126
assign 1 42 127
new 0 42 127
assign 1 43 128
new 0 43 128
assign 1 44 129
new 0 44 129
assign 1 45 130
new 0 45 130
assign 1 46 131
new 0 46 131
assign 1 47 132
new 0 47 132
assign 1 48 133
new 0 48 133
assign 1 49 134
new 0 49 134
assign 1 50 135
new 0 50 135
assign 1 51 136
new 0 51 136
assign 1 52 137
new 0 52 137
assign 1 53 138
new 0 53 138
assign 1 54 139
new 0 54 139
assign 1 55 140
new 0 55 140
assign 1 56 141
new 0 56 141
assign 1 57 142
new 0 57 142
assign 1 58 143
new 0 58 143
assign 1 59 144
new 0 59 144
assign 1 60 145
new 0 60 145
assign 1 61 146
new 0 61 146
assign 1 62 147
new 0 62 147
assign 1 63 148
new 0 63 148
assign 1 64 149
new 0 64 149
assign 1 65 150
new 0 65 150
assign 1 66 151
new 0 66 151
assign 1 67 152
new 0 67 152
assign 1 68 153
new 0 68 153
assign 1 69 154
new 0 69 154
assign 1 70 155
new 0 70 155
assign 1 71 156
new 0 71 156
assign 1 72 157
new 0 72 157
assign 1 73 158
new 0 73 158
assign 1 74 159
new 0 74 159
assign 1 75 160
new 0 75 160
assign 1 76 161
new 0 76 161
assign 1 77 162
new 0 77 162
assign 1 78 163
new 0 78 163
assign 1 79 164
new 0 79 164
assign 1 80 165
new 0 80 165
assign 1 81 166
new 0 81 166
assign 1 82 167
new 0 82 167
assign 1 83 168
new 0 83 168
assign 1 84 169
new 0 84 169
assign 1 85 170
new 0 85 170
assign 1 86 171
new 0 86 171
assign 1 87 172
new 0 87 172
assign 1 88 173
new 0 88 173
assign 1 89 174
new 0 89 174
assign 1 90 175
new 0 90 175
assign 1 91 176
new 0 91 176
assign 1 92 177
new 0 92 177
assign 1 93 178
new 0 93 178
return 1 0 182
return 1 0 185
assign 1 0 188
assign 1 0 192
return 1 0 196
return 1 0 199
assign 1 0 202
assign 1 0 206
return 1 0 210
return 1 0 213
assign 1 0 216
assign 1 0 220
return 1 0 224
return 1 0 227
assign 1 0 230
assign 1 0 234
return 1 0 238
return 1 0 241
assign 1 0 244
assign 1 0 248
return 1 0 252
return 1 0 255
assign 1 0 258
assign 1 0 262
return 1 0 266
return 1 0 269
assign 1 0 272
assign 1 0 276
return 1 0 280
return 1 0 283
assign 1 0 286
assign 1 0 290
return 1 0 294
return 1 0 297
assign 1 0 300
assign 1 0 304
return 1 0 308
return 1 0 311
assign 1 0 314
assign 1 0 318
return 1 0 322
return 1 0 325
assign 1 0 328
assign 1 0 332
return 1 0 336
return 1 0 339
assign 1 0 342
assign 1 0 346
return 1 0 350
return 1 0 353
assign 1 0 356
assign 1 0 360
return 1 0 364
return 1 0 367
assign 1 0 370
assign 1 0 374
return 1 0 378
return 1 0 381
assign 1 0 384
assign 1 0 388
return 1 0 392
return 1 0 395
assign 1 0 398
assign 1 0 402
return 1 0 406
return 1 0 409
assign 1 0 412
assign 1 0 416
return 1 0 420
return 1 0 423
assign 1 0 426
assign 1 0 430
return 1 0 434
return 1 0 437
assign 1 0 440
assign 1 0 444
return 1 0 448
return 1 0 451
assign 1 0 454
assign 1 0 458
return 1 0 462
return 1 0 465
assign 1 0 468
assign 1 0 472
return 1 0 476
return 1 0 479
assign 1 0 482
assign 1 0 486
return 1 0 490
return 1 0 493
assign 1 0 496
assign 1 0 500
return 1 0 504
return 1 0 507
assign 1 0 510
assign 1 0 514
return 1 0 518
return 1 0 521
assign 1 0 524
assign 1 0 528
return 1 0 532
return 1 0 535
assign 1 0 538
assign 1 0 542
return 1 0 546
return 1 0 549
assign 1 0 552
assign 1 0 556
return 1 0 560
return 1 0 563
assign 1 0 566
assign 1 0 570
return 1 0 574
return 1 0 577
assign 1 0 580
assign 1 0 584
return 1 0 588
return 1 0 591
assign 1 0 594
assign 1 0 598
return 1 0 602
return 1 0 605
assign 1 0 608
assign 1 0 612
return 1 0 616
return 1 0 619
assign 1 0 622
assign 1 0 626
return 1 0 630
return 1 0 633
assign 1 0 636
assign 1 0 640
return 1 0 644
return 1 0 647
assign 1 0 650
assign 1 0 654
return 1 0 658
return 1 0 661
assign 1 0 664
assign 1 0 668
return 1 0 672
return 1 0 675
assign 1 0 678
assign 1 0 682
return 1 0 686
return 1 0 689
assign 1 0 692
assign 1 0 696
return 1 0 700
return 1 0 703
assign 1 0 706
assign 1 0 710
return 1 0 714
return 1 0 717
assign 1 0 720
assign 1 0 724
return 1 0 728
return 1 0 731
assign 1 0 734
assign 1 0 738
return 1 0 742
return 1 0 745
assign 1 0 748
assign 1 0 752
return 1 0 756
return 1 0 759
assign 1 0 762
assign 1 0 766
return 1 0 770
return 1 0 773
assign 1 0 776
assign 1 0 780
return 1 0 784
return 1 0 787
assign 1 0 790
assign 1 0 794
return 1 0 798
return 1 0 801
assign 1 0 804
assign 1 0 808
return 1 0 812
return 1 0 815
assign 1 0 818
assign 1 0 822
return 1 0 826
return 1 0 829
assign 1 0 832
assign 1 0 836
return 1 0 840
return 1 0 843
assign 1 0 846
assign 1 0 850
return 1 0 854
return 1 0 857
assign 1 0 860
assign 1 0 864
return 1 0 868
return 1 0 871
assign 1 0 874
assign 1 0 878
return 1 0 882
return 1 0 885
assign 1 0 888
assign 1 0 892
return 1 0 896
return 1 0 899
assign 1 0 902
assign 1 0 906
return 1 0 910
return 1 0 913
assign 1 0 916
assign 1 0 920
return 1 0 924
return 1 0 927
assign 1 0 930
assign 1 0 934
return 1 0 938
return 1 0 941
assign 1 0 944
assign 1 0 948
return 1 0 952
return 1 0 955
assign 1 0 958
assign 1 0 962
return 1 0 966
return 1 0 969
assign 1 0 972
assign 1 0 976
return 1 0 980
return 1 0 983
assign 1 0 986
assign 1 0 990
return 1 0 994
return 1 0 997
assign 1 0 1000
assign 1 0 1004
return 1 0 1008
return 1 0 1011
assign 1 0 1014
assign 1 0 1018
return 1 0 1022
return 1 0 1025
assign 1 0 1028
assign 1 0 1032
return 1 0 1036
return 1 0 1039
assign 1 0 1042
assign 1 0 1046
return 1 0 1050
return 1 0 1053
assign 1 0 1056
assign 1 0 1060
return 1 0 1064
return 1 0 1067
assign 1 0 1070
assign 1 0 1074
return 1 0 1078
return 1 0 1081
assign 1 0 1084
assign 1 0 1088
return 1 0 1092
return 1 0 1095
assign 1 0 1098
assign 1 0 1102
return 1 0 1106
return 1 0 1109
assign 1 0 1112
assign 1 0 1116
return 1 0 1120
return 1 0 1123
assign 1 0 1126
assign 1 0 1130
return 1 0 1134
return 1 0 1137
assign 1 0 1140
assign 1 0 1144
return 1 0 1148
return 1 0 1151
assign 1 0 1154
assign 1 0 1158
return 1 0 1162
return 1 0 1165
assign 1 0 1168
assign 1 0 1172
return 1 0 1176
return 1 0 1179
assign 1 0 1182
assign 1 0 1186
return 1 0 1190
return 1 0 1193
assign 1 0 1196
assign 1 0 1200
return 1 0 1204
return 1 0 1207
assign 1 0 1210
assign 1 0 1214
return 1 0 1218
return 1 0 1221
assign 1 0 1224
assign 1 0 1228
return 1 0 1232
return 1 0 1235
assign 1 0 1238
assign 1 0 1242
return 1 0 1246
return 1 0 1249
assign 1 0 1252
assign 1 0 1256
return 1 0 1260
return 1 0 1263
assign 1 0 1266
assign 1 0 1270
return 1 0 1274
return 1 0 1277
assign 1 0 1280
assign 1 0 1284
return 1 0 1288
return 1 0 1291
assign 1 0 1294
assign 1 0 1298
return 1 0 1302
return 1 0 1305
assign 1 0 1308
assign 1 0 1312
return 1 0 1316
return 1 0 1319
assign 1 0 1322
assign 1 0 1326
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1464527658: return bem_toString_0();
case -2131640624: return bem_new_0();
case -1064930780: return bem_TRUEGet_0();
case -1239115423: return bem_AND_ASSIGNGetDirect_0();
case -1512243412: return bem_PARENSGetDirect_0();
case 854047456: return bem_FSLASHGetDirect_0();
case 1787011606: return bem_DIVIDE_ASSIGNGetDirect_0();
case -1577746861: return bem_TRYGetDirect_0();
case -404980460: return bem_EMITGetDirect_0();
case 63269268: return bem_DEFMODGet_0();
case 829195956: return bem_IDXGet_0();
case 585616435: return bem_BRACESGet_0();
case 1393634620: return bem_serializeToString_0();
case -1906992290: return bem_INCREMENTGet_0();
case 927690316: return bem_SPACEGet_0();
case 531694798: return bem_BLOCKGet_0();
case -1570695453: return bem_DOTGetDirect_0();
case -1567709750: return bem_ADD_ASSIGNGetDirect_0();
case 1596928006: return bem_IDXGetDirect_0();
case 471587247: return bem_RBRACESGetDirect_0();
case -470147631: return bem_SUBTRACT_ASSIGNGet_0();
case 22640607: return bem_ADDGet_0();
case -898595535: return bem_GREATERGet_0();
case 966746762: return bem_OR_ASSIGNGetDirect_0();
case -835647314: return bem_BLOCKGetDirect_0();
case -1541927790: return bem_IDXACCGetDirect_0();
case -1192316401: return bem_COLONGet_0();
case -909445927: return bem_TRYGet_0();
case -1626934764: return bem_NOTGet_0();
case -1913323282: return bem_PARENSGet_0();
case 1729447058: return bem_OR_ASSIGNGet_0();
case -1847525140: return bem_TOKENGetDirect_0();
case 239077256: return bem_print_0();
case 1223648583: return bem_GREATER_EQUALSGetDirect_0();
case 1587133120: return bem_classNameGet_0();
case 653059554: return bem_MODULUS_ASSIGNGetDirect_0();
case 790746082: return bem_SPACEGetDirect_0();
case -1271480076: return bem_USEGet_0();
case 1645989341: return bem_iteratorGet_0();
case 196095508: return bem_EQUALSGetDirect_0();
case -138712883: return bem_MULTIPLY_ASSIGNGet_0();
case 1733489793: return bem_MODULUS_ASSIGNGet_0();
case -1655397022: return bem_LOGICAL_ANDGetDirect_0();
case 1454422816: return bem_ACCESSORGet_0();
case 464093031: return bem_FOREACHGetDirect_0();
case 1976819376: return bem_MULTIPLYGet_0();
case -309705088: return bem_SUBTRACTGet_0();
case 1044384496: return bem_LESSERGet_0();
case -1773194340: return bem_VARGetDirect_0();
case 1529404972: return bem_DECREMENT_ASSIGNGet_0();
case 2005989840: return bem_TRUEGetDirect_0();
case 1922871526: return bem_RIDXGet_0();
case 1919046445: return bem_NEWLINEGetDirect_0();
case -215542043: return bem_SUBTRACTGetDirect_0();
case 2015931437: return bem_MULTIPLY_ASSIGNGetDirect_0();
case 187465649: return bem_SEMIGetDirect_0();
case 776441101: return bem_RBRACESGet_0();
case 740972168: return bem_ADD_ASSIGNGet_0();
case -1520861480: return bem_WHILEGetDirect_0();
case -1437886659: return bem_TRANSUNITGetDirect_0();
case 1952921548: return bem_ASGet_0();
case 594572360: return bem_ELIFGetDirect_0();
case -163907194: return bem_LESSER_EQUALSGetDirect_0();
case -294650231: return bem_WSTRQGetDirect_0();
case -610170586: return bem_LESSERGetDirect_0();
case 156900452: return bem_NULLGet_0();
case 1855416351: return bem_COMMAGetDirect_0();
case -2082309873: return bem_FORGet_0();
case 1621681179: return bem_CONTINUEGet_0();
case 1612214876: return bem_TRANSUNITGet_0();
case 1795805648: return bem_CALLGetDirect_0();
case 392953254: return bem_WSTRQGet_0();
case -1535901191: return bem_DEFMODGetDirect_0();
case -2132091712: return bem_COMMAGet_0();
case 1274189887: return bem_NOTGetDirect_0();
case 2041796906: return bem_BREAKGetDirect_0();
case -38472191: return bem_MULTIPLYGetDirect_0();
case 1924482635: return bem_FLOATLGetDirect_0();
case 2072647673: return bem_PROPERTIESGet_0();
case -312928711: return bem_NEWLINEGet_0();
case 115187101: return bem_LOGICAL_ANDGet_0();
case -1118941028: return bem_ANDGet_0();
case 1826923434: return bem_ACCESSORGetDirect_0();
case -2023075774: return bem_INCREMENT_ASSIGNGet_0();
case 141180526: return bem_DECREMENTGet_0();
case -450019696: return bem_RPARENSGet_0();
case 324728114: return bem_BRACESGetDirect_0();
case 1676643025: return bem_LOOPGet_0();
case -1722726283: return bem_PROPERTIESGetDirect_0();
case 94298091: return bem_NULLGetDirect_0();
case 315521097: return bem_TOKENGet_0();
case -478647065: return bem_LOGICAL_ORGetDirect_0();
case 1341478781: return bem_EXPRGetDirect_0();
case 513773472: return bem_RIDXGetDirect_0();
case 171554593: return bem_NAMEPATHGetDirect_0();
case 656197020: return bem_INGet_0();
case 536327526: return bem_FINALLYGet_0();
case 63040052: return bem_EXPRGet_0();
case 350812655: return bem_copy_0();
case -1505800634: return bem_IDXACCGet_0();
case 674711541: return bem_ANDGetDirect_0();
case 481657566: return bem_STRINGLGet_0();
case -1996096640: return bem_MODULUSGet_0();
case -1368350244: return bem_EMITGet_0();
case -104384839: return bem_IFEMITGetDirect_0();
case 1287426099: return bem_CLASSGet_0();
case -1490145470: return bem_DIVIDEGet_0();
case 1425572469: return bem_DIVIDE_ASSIGNGet_0();
case 1608137146: return bem_CALLGet_0();
case 792370026: return bem_ORGetDirect_0();
case 1918496177: return bem_FINALLYGetDirect_0();
case -1918446807: return bem_DIVIDEGetDirect_0();
case 969994032: return bem_serializationIteratorGet_0();
case -1601780017: return bem_FALSEGetDirect_0();
case 1098197279: return bem_ELIFGet_0();
case -54039930: return bem_CATCHGetDirect_0();
case 909877230: return bem_VARGet_0();
case -2011130219: return bem_NAMEPATHGet_0();
case -301709957: return bem_BREAKGet_0();
case -891398275: return bem_IDGet_0();
case 1864861581: return bem_echo_0();
case 313632763: return bem_FALSEGet_0();
case 2071875109: return bem_sourceFileNameGet_0();
case 1236124623: return bem_INTLGet_0();
case 877387932: return bem_LESSER_EQUALSGet_0();
case -720239566: return bem_ATYPEGetDirect_0();
case 304493653: return bem_AND_ASSIGNGet_0();
case 2111650624: return bem_DOTGet_0();
case 902491041: return bem_STRQGet_0();
case 566573794: return bem_tagGet_0();
case 785161348: return bem_fieldNamesGet_0();
case -1480464927: return bem_FLOATLGet_0();
case -1809699474: return bem_LOGICAL_ORGet_0();
case 1562202284: return bem_USEGetDirect_0();
case 287310884: return bem_IDGetDirect_0();
case -1730309063: return bem_FORGetDirect_0();
case 693561194: return bem_ELSEGet_0();
case 1887513005: return bem_WHILEGet_0();
case -469798437: return bem_STRINGLGetDirect_0();
case 904399825: return bem_DECREMENTGetDirect_0();
case -296612125: return bem_IFEMITGet_0();
case 583042303: return bem_EQUALSGet_0();
case -638173703: return bem_STRQGetDirect_0();
case -1580045596: return bem_NOT_EQUALSGet_0();
case 2113534779: return bem_hashGet_0();
case 2031701777: return bem_INCREMENT_ASSIGNGetDirect_0();
case 527242846: return bem_IFGetDirect_0();
case -2099993433: return bem_IFGet_0();
case 1443942239: return bem_SEMIGet_0();
case -2108674355: return bem_ATYPEGet_0();
case 1525171939: return bem_INCREMENTGetDirect_0();
case 1102420802: return bem_ELSEGetDirect_0();
case -798486837: return bem_CLASSGetDirect_0();
case -1756123577: return bem_FOREACHGet_0();
case 1380807345: return bem_ASGetDirect_0();
case 904171562: return bem_INGetDirect_0();
case -734997042: return bem_CONTINUEGetDirect_0();
case 1982356705: return bem_ADDGetDirect_0();
case -2068615045: return bem_WSTRINGLGetDirect_0();
case -157777737: return bem_fieldIteratorGet_0();
case -1470716440: return bem_GREATERGetDirect_0();
case 1410712269: return bem_WSTRINGLGet_0();
case -526611871: return bem_ASSIGNGetDirect_0();
case -1982290417: return bem_COLONGetDirect_0();
case 797377518: return bem_FSLASHGet_0();
case 10319452: return bem_MODULUSGetDirect_0();
case 1637429927: return bem_GREATER_EQUALSGet_0();
case 1005443364: return bem_create_0();
case 2138105661: return bem_CATCHGet_0();
case -49878906: return bem_METHODGetDirect_0();
case -442744: return bem_SUBTRACT_ASSIGNGetDirect_0();
case -1394259363: return bem_INTLGetDirect_0();
case -654415571: return bem_ORGet_0();
case -1270780814: return bem_default_0();
case 873828646: return bem_deserializeClassNameGet_0();
case -742766227: return bem_NOT_EQUALSGetDirect_0();
case 1538208962: return bem_RPARENSGetDirect_0();
case -281350604: return bem_serializeContents_0();
case 214697637: return bem_ASSIGNGet_0();
case -1476421082: return bem_LOOPGetDirect_0();
case -274866928: return bem_METHODGet_0();
case 1275851151: return bem_DECREMENT_ASSIGNGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 755908621: return bem_VARSetDirect_1(bevd_0);
case 1109065754: return bem_CONTINUESetDirect_1(bevd_0);
case -1823440928: return bem_TOKENSet_1(bevd_0);
case -233041963: return bem_GREATER_EQUALSSet_1(bevd_0);
case 2058541113: return bem_ANDSetDirect_1(bevd_0);
case -178907194: return bem_PROPERTIESSet_1(bevd_0);
case -2105370732: return bem_EQUALSSetDirect_1(bevd_0);
case -1508518120: return bem_FINALLYSetDirect_1(bevd_0);
case -690370853: return bem_LESSER_EQUALSSetDirect_1(bevd_0);
case -1426889023: return bem_ADD_ASSIGNSetDirect_1(bevd_0);
case 1092557191: return bem_FINALLYSet_1(bevd_0);
case 968792505: return bem_IDSetDirect_1(bevd_0);
case -1425734099: return bem_LOGICAL_ORSetDirect_1(bevd_0);
case -1653363157: return bem_IDXACCSet_1(bevd_0);
case 2045233652: return bem_COLONSetDirect_1(bevd_0);
case -1569737226: return bem_NEWLINESetDirect_1(bevd_0);
case -188873272: return bem_DECREMENT_ASSIGNSetDirect_1(bevd_0);
case 453986903: return bem_NULLSetDirect_1(bevd_0);
case -16392854: return bem_FLOATLSet_1(bevd_0);
case 825367211: return bem_INTLSetDirect_1(bevd_0);
case -1648847624: return bem_ANDSet_1(bevd_0);
case 1101853565: return bem_RIDXSetDirect_1(bevd_0);
case 911850375: return bem_LESSERSetDirect_1(bevd_0);
case 850060183: return bem_USESet_1(bevd_0);
case 2053116831: return bem_RPARENSSetDirect_1(bevd_0);
case 1749425061: return bem_INCREMENTSet_1(bevd_0);
case -441644036: return bem_FLOATLSetDirect_1(bevd_0);
case 2022992901: return bem_INSet_1(bevd_0);
case -2138825853: return bem_NULLSet_1(bevd_0);
case 292111501: return bem_BRACESSetDirect_1(bevd_0);
case 2018931860: return bem_INCREMENTSetDirect_1(bevd_0);
case -66958497: return bem_NAMEPATHSet_1(bevd_0);
case -528403640: return bem_NEWLINESet_1(bevd_0);
case -1767863631: return bem_LESSERSet_1(bevd_0);
case -1291132269: return bem_sameClass_1(bevd_0);
case 366964177: return bem_FORSetDirect_1(bevd_0);
case 303723997: return bem_CLASSSetDirect_1(bevd_0);
case 1095532049: return bem_IFSetDirect_1(bevd_0);
case -1322319406: return bem_DEFMODSetDirect_1(bevd_0);
case -1044917821: return bem_EMITSet_1(bevd_0);
case -2045118014: return bem_SUBTRACTSetDirect_1(bevd_0);
case 290612829: return bem_RBRACESSetDirect_1(bevd_0);
case 649084570: return bem_DIVIDE_ASSIGNSet_1(bevd_0);
case 822148765: return bem_INCREMENT_ASSIGNSet_1(bevd_0);
case -396283576: return bem_undef_1(bevd_0);
case 681402056: return bem_MODULUS_ASSIGNSet_1(bevd_0);
case -769003214: return bem_MULTIPLY_ASSIGNSet_1(bevd_0);
case -532274926: return bem_CONTINUESet_1(bevd_0);
case -450510586: return bem_PARENSSet_1(bevd_0);
case -1008109318: return bem_ORSetDirect_1(bevd_0);
case -1678923642: return bem_NOTSet_1(bevd_0);
case -2109255555: return bem_BLOCKSet_1(bevd_0);
case -1536714725: return bem_MULTIPLY_ASSIGNSetDirect_1(bevd_0);
case 1603739665: return bem_WHILESet_1(bevd_0);
case 1392656410: return bem_LESSER_EQUALSSet_1(bevd_0);
case 822732827: return bem_SPACESetDirect_1(bevd_0);
case -674226232: return bem_DECREMENTSet_1(bevd_0);
case 2038347858: return bem_GREATER_EQUALSSetDirect_1(bevd_0);
case 1826441346: return bem_IFEMITSet_1(bevd_0);
case -1922465930: return bem_notEquals_1(bevd_0);
case -2062248118: return bem_STRQSet_1(bevd_0);
case -471013575: return bem_ASSetDirect_1(bevd_0);
case -750713057: return bem_CALLSet_1(bevd_0);
case 1619173628: return bem_BREAKSet_1(bevd_0);
case 1071012100: return bem_SPACESet_1(bevd_0);
case 241271053: return bem_FORSet_1(bevd_0);
case -657367318: return bem_BREAKSetDirect_1(bevd_0);
case 306164004: return bem_FSLASHSet_1(bevd_0);
case -280531263: return bem_MULTIPLYSetDirect_1(bevd_0);
case 1362452841: return bem_MODULUSSetDirect_1(bevd_0);
case -236700011: return bem_LOOPSet_1(bevd_0);
case -1504385392: return bem_LOGICAL_ANDSet_1(bevd_0);
case 815206786: return bem_IDXSetDirect_1(bevd_0);
case 44737194: return bem_COLONSet_1(bevd_0);
case 1633422036: return bem_TRANSUNITSet_1(bevd_0);
case -1539480284: return bem_CATCHSetDirect_1(bevd_0);
case 295006943: return bem_STRINGLSet_1(bevd_0);
case 1543830239: return bem_IDXSet_1(bevd_0);
case -697365254: return bem_GREATERSetDirect_1(bevd_0);
case -873501475: return bem_IDXACCSetDirect_1(bevd_0);
case -131373904: return bem_ADDSetDirect_1(bevd_0);
case 293667751: return bem_FALSESetDirect_1(bevd_0);
case 1570403260: return bem_ASSet_1(bevd_0);
case -53830623: return bem_TOKENSetDirect_1(bevd_0);
case 1460370496: return bem_PROPERTIESSetDirect_1(bevd_0);
case 1302666411: return bem_DEFMODSet_1(bevd_0);
case 1132668150: return bem_TRUESet_1(bevd_0);
case -469435653: return bem_BLOCKSetDirect_1(bevd_0);
case -1180247316: return bem_DECREMENTSetDirect_1(bevd_0);
case -946505011: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -383204664: return bem_EXPRSetDirect_1(bevd_0);
case 730119492: return bem_DIVIDESet_1(bevd_0);
case 1221393791: return bem_SUBTRACT_ASSIGNSet_1(bevd_0);
case 1098089883: return bem_SEMISetDirect_1(bevd_0);
case 198276565: return bem_DECREMENT_ASSIGNSet_1(bevd_0);
case -1471657437: return bem_VARSet_1(bevd_0);
case 18066932: return bem_copyTo_1(bevd_0);
case 757804541: return bem_DOTSet_1(bevd_0);
case -2125673989: return bem_INTLSet_1(bevd_0);
case -767800882: return bem_ACCESSORSet_1(bevd_0);
case -2073708092: return bem_DIVIDESetDirect_1(bevd_0);
case -1966728769: return bem_FSLASHSetDirect_1(bevd_0);
case 1224853128: return bem_GREATERSet_1(bevd_0);
case -1597523624: return bem_FOREACHSet_1(bevd_0);
case 627625680: return bem_TRYSet_1(bevd_0);
case -44941012: return bem_DIVIDE_ASSIGNSetDirect_1(bevd_0);
case -583966481: return bem_ELSESet_1(bevd_0);
case 1276960549: return bem_AND_ASSIGNSet_1(bevd_0);
case 1903138624: return bem_otherType_1(bevd_0);
case -1914216280: return bem_INSetDirect_1(bevd_0);
case 908001158: return bem_TRYSetDirect_1(bevd_0);
case -730556296: return bem_ELIFSetDirect_1(bevd_0);
case 425322384: return bem_ATYPESet_1(bevd_0);
case -1963872168: return bem_OR_ASSIGNSetDirect_1(bevd_0);
case 170334142: return bem_ATYPESetDirect_1(bevd_0);
case -1354547222: return bem_EXPRSet_1(bevd_0);
case 1005494377: return bem_def_1(bevd_0);
case 1439654007: return bem_CALLSetDirect_1(bevd_0);
case 1685186703: return bem_CLASSSet_1(bevd_0);
case 1539401917: return bem_LOGICAL_ORSet_1(bevd_0);
case 2022824135: return bem_STRINGLSetDirect_1(bevd_0);
case 1723525411: return bem_SEMISet_1(bevd_0);
case 1163278640: return bem_COMMASetDirect_1(bevd_0);
case 1481470265: return bem_WSTRQSet_1(bevd_0);
case 729530712: return bem_IFSet_1(bevd_0);
case -1929841088: return bem_ASSIGNSetDirect_1(bevd_0);
case 2020385259: return bem_WSTRINGLSetDirect_1(bevd_0);
case -121428488: return bem_PARENSSetDirect_1(bevd_0);
case -718225974: return bem_INCREMENT_ASSIGNSetDirect_1(bevd_0);
case -1141289536: return bem_NOT_EQUALSSet_1(bevd_0);
case 551078489: return bem_equals_1(bevd_0);
case -1234875119: return bem_IDSet_1(bevd_0);
case 808463137: return bem_LOOPSetDirect_1(bevd_0);
case 355023710: return bem_WSTRINGLSet_1(bevd_0);
case 1773771614: return bem_FALSESet_1(bevd_0);
case 1664955299: return bem_sameType_1(bevd_0);
case -238717870: return bem_EMITSetDirect_1(bevd_0);
case -539853770: return bem_IFEMITSetDirect_1(bevd_0);
case -1046997995: return bem_ASSIGNSet_1(bevd_0);
case 1854725104: return bem_TRUESetDirect_1(bevd_0);
case 2125214715: return bem_USESetDirect_1(bevd_0);
case -1873667104: return bem_ELIFSet_1(bevd_0);
case -864914471: return bem_SUBTRACTSet_1(bevd_0);
case 1047741482: return bem_COMMASet_1(bevd_0);
case -1329523792: return bem_SUBTRACT_ASSIGNSetDirect_1(bevd_0);
case -2083361884: return bem_OR_ASSIGNSet_1(bevd_0);
case 15709283: return bem_MODULUS_ASSIGNSetDirect_1(bevd_0);
case 1482411110: return bem_otherClass_1(bevd_0);
case 934968430: return bem_EQUALSSet_1(bevd_0);
case -316279972: return bem_RBRACESSet_1(bevd_0);
case -496084174: return bem_CATCHSet_1(bevd_0);
case -1620694238: return bem_MODULUSSet_1(bevd_0);
case 109110510: return bem_RIDXSet_1(bevd_0);
case 613821708: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1687313702: return bem_ADDSet_1(bevd_0);
case -1051698494: return bem_BRACESSet_1(bevd_0);
case -650581: return bem_METHODSetDirect_1(bevd_0);
case -1115528588: return bem_sameObject_1(bevd_0);
case -1989610957: return bem_ELSESetDirect_1(bevd_0);
case -283274725: return bem_ORSet_1(bevd_0);
case 239123951: return bem_DOTSetDirect_1(bevd_0);
case -325877299: return bem_AND_ASSIGNSetDirect_1(bevd_0);
case 1382288970: return bem_NOT_EQUALSSetDirect_1(bevd_0);
case 1732699739: return bem_WHILESetDirect_1(bevd_0);
case 1194970716: return bem_RPARENSSet_1(bevd_0);
case -1727004282: return bem_NAMEPATHSetDirect_1(bevd_0);
case 207070866: return bem_METHODSet_1(bevd_0);
case 305718936: return bem_NOTSetDirect_1(bevd_0);
case -1929197253: return bem_ADD_ASSIGNSet_1(bevd_0);
case -131598142: return bem_ACCESSORSetDirect_1(bevd_0);
case 1638930300: return bem_FOREACHSetDirect_1(bevd_0);
case 617226124: return bem_TRANSUNITSetDirect_1(bevd_0);
case -770365339: return bem_WSTRQSetDirect_1(bevd_0);
case 1939980216: return bem_LOGICAL_ANDSetDirect_1(bevd_0);
case -885688293: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1301962736: return bem_STRQSetDirect_1(bevd_0);
case 1465479157: return bem_MULTIPLYSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -240446712: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 559843934: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 826063253: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1518040465: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1523888299: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_5_9_BuildNodeTypes_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_5_9_BuildNodeTypes_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_5_9_BuildNodeTypes();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst = (BEC_2_5_9_BuildNodeTypes) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_5_9_BuildNodeTypes.bece_BEC_2_5_9_BuildNodeTypes_bevs_type;
}
}
