package be;
/* IO:File: source/base/Exceptions.be */
public class BEC_2_6_10_SystemExceptions extends BEC_2_6_6_SystemObject {
public BEC_2_6_10_SystemExceptions() { }
private static byte[] becc_BEC_2_6_10_SystemExceptions_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73};
private static byte[] becc_BEC_2_6_10_SystemExceptions_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x78,0x63,0x65,0x70,0x74,0x69,0x6F,0x6E,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_10_SystemExceptions_bels_0 = {0x46,0x61,0x69,0x6C,0x75,0x72,0x65,0x20,0x6F,0x63,0x63,0x75,0x72,0x72,0x65,0x64};
private static byte[] bece_BEC_2_6_10_SystemExceptions_bels_1 = {0x2E,0x2E,0x2E,0x66,0x61,0x69,0x6C,0x75,0x72,0x65,0x20,0x74,0x6F,0x53,0x74,0x72,0x69,0x6E,0x67,0x20,0x6E,0x75,0x6C,0x6C,0x2E,0x2E,0x2E};
private static byte[] bece_BEC_2_6_10_SystemExceptions_bels_2 = {0x2E,0x2E,0x2E,0x66,0x61,0x69,0x6C,0x75,0x72,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C,0x2E,0x2E,0x2E};
public static BEC_2_6_10_SystemExceptions bece_BEC_2_6_10_SystemExceptions_bevs_inst;

public static BET_2_6_10_SystemExceptions bece_BEC_2_6_10_SystemExceptions_bevs_type;

public BEC_2_6_6_SystemObject bem_ts_1(BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_4_6_TextString bevl_esm = null;
BEC_2_4_6_TextString bevl_es = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevl_esm = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_10_SystemExceptions_bels_0));
if (beva_e == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 14*/ {
bevl_es = (BEC_2_4_6_TextString) beva_e.bemd_0(1116049816);
if (bevl_es == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 16*/ {
bevl_es = (new BEC_2_4_6_TextString(27, bece_BEC_2_6_10_SystemExceptions_bels_1));
} /* Line: 17*/
} /* Line: 16*/
 else /* Line: 19*/ {
bevl_es = (new BEC_2_4_6_TextString(21, bece_BEC_2_6_10_SystemExceptions_bels_2));
} /* Line: 20*/
bevl_esm.bem_addValue_1(bevl_es);
return bevl_esm;
} /*method end*/
public BEC_2_6_6_SystemObject bem_tS_1(BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_ts_1(beva_e);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_toString_1(BEC_2_6_6_SystemObject beva_e) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_ts_1(beva_e);
return bevt_0_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {13, 14, 14, 15, 16, 16, 17, 20, 22, 23, 27, 27, 31, 31};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {19, 20, 25, 26, 27, 32, 33, 37, 39, 40, 44, 45, 49, 50};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 13 19
new 0 13 19
assign 1 14 20
def 1 14 25
assign 1 15 26
toString 0 15 26
assign 1 16 27
undef 1 16 32
assign 1 17 33
new 0 17 33
assign 1 20 37
new 0 20 37
addValue 1 22 39
return 1 23 40
assign 1 27 44
ts 1 27 44
return 1 27 45
assign 1 31 49
ts 1 31 49
return 1 31 50
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1602239310: return bem_new_0();
case 1116049816: return bem_toString_0();
case 201436634: return bem_print_0();
case 1407534539: return bem_iteratorGet_0();
case 2021446686: return bem_create_0();
case -907463432: return bem_copy_0();
case -1827671744: return bem_hashGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1729413977: return bem_print_1(bevd_0);
case 1989503752: return bem_copyTo_1(bevd_0);
case -922556296: return bem_tS_1(bevd_0);
case -1291367990: return bem_equals_1(bevd_0);
case -1812901017: return bem_def_1(bevd_0);
case -1925375873: return bem_ts_1(bevd_0);
case -765236464: return bem_toString_1(bevd_0);
case -471447072: return bem_notEquals_1(bevd_0);
case 505990086: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1018458287: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -994154646: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 241691596: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -993790175: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_6_10_SystemExceptions_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_10_SystemExceptions_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_10_SystemExceptions();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_10_SystemExceptions.bece_BEC_2_6_10_SystemExceptions_bevs_inst = (BEC_2_6_10_SystemExceptions) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_10_SystemExceptions.bece_BEC_2_6_10_SystemExceptions_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_10_SystemExceptions.bece_BEC_2_6_10_SystemExceptions_bevs_type;
}
}
