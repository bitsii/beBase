package be;
/* IO:File: source/base/EcProcess.be */
public final class BEC_2_6_7_SystemProcess extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemProcess() { }
private static byte[] becc_BEC_2_6_7_SystemProcess_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x50,0x72,0x6F,0x63,0x65,0x73,0x73};
private static byte[] becc_BEC_2_6_7_SystemProcess_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x45,0x63,0x50,0x72,0x6F,0x63,0x65,0x73,0x73,0x2E,0x62,0x65};
public static BEC_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_inst;

public static BET_2_6_7_SystemProcess bece_BEC_2_6_7_SystemProcess_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_4_3_MathInt bevp_numArgs;
public BEC_2_6_6_SystemObject bevp_execName;
public BEC_2_6_6_SystemObject bevp_target;
public BEC_2_6_6_SystemObject bevp_result;
public BEC_2_6_6_SystemObject bevp_except;
public BEC_2_6_15_SystemCurrentPlatform bevp_platform;
public BEC_2_6_6_SystemObject bevp_fullExecName;
public BEC_2_6_7_SystemProcess bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_default_0() throws Throwable {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) BEC_2_6_15_SystemCurrentPlatform.bece_BEC_2_6_15_SystemCurrentPlatform_bevs_inst.bem_new_0();
bem_prepArgs_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_execNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
if (bevt_0_ta_ph.bevi_bool)/* Line: 44*/ {
bevt_1_ta_ph = bem_fullExecNameGet_0();
return bevt_1_ta_ph;
} /* Line: 44*/
if (bevp_execName == null) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 45*/ {
} /* Line: 46*/
return bevp_execName;
} /*method end*/
public BEC_3_2_4_4_IOFilePath bem_execPathGet_0() throws Throwable {
BEC_3_2_4_4_IOFilePath bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
bevt_1_ta_ph = bem_execNameGet_0();
bevt_0_ta_ph = (new BEC_3_2_4_4_IOFilePath()).bem_apNew_1((BEC_2_4_6_TextString) bevt_1_ta_ph );
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_fullExecNameGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_fullExecName == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 64*/ {
} /* Line: 65*/
return bevp_fullExecName;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_prepArgs_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
if (bevp_args == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 78*/ {
bevp_args = (new BEC_2_9_4_ContainerList()).bem_new_0();

            for (int i = 0;i < be.BECS_Runtime.args.length;i++) {
                bevp_args.bem_addValue_1(new BEC_2_4_6_TextString(be.BECS_Runtime.args[i].getBytes("UTF-8")));
            }
          bevp_numArgs = bevp_args.bem_sizeGet_0();
} /* Line: 112*/
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(0));
bem_exit_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exit_1(BEC_2_4_3_MathInt beva_code) throws Throwable {

     System.exit(beva_code.bevi_int);
     return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_start_1(BEC_2_6_6_SystemObject beva__target) throws Throwable {
BEC_2_6_6_SystemObject bevl_e = null;
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevp_target = beva__target;
try /* Line: 142*/ {
bevp_result = bevp_target.bemd_0(-554158618);
} /* Line: 143*/
 catch (Throwable beve_0) {
bevl_e = (be.BECS_ThrowBack.handleThrow(beve_0));
bevp_except = bevl_e;
bevl_e.bemd_0(-424614227);
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(1));
return bevt_0_ta_ph;
} /* Line: 147*/
return bevp_result;
} /*method end*/
public BEC_2_6_6_SystemObject bem_startByName_1(BEC_2_6_6_SystemObject beva__name) throws Throwable {
BEC_2_6_6_SystemObject bevl_t = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_7_SystemObjects bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
bevt_1_ta_ph = (BEC_2_6_7_SystemObjects) BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_createInstance_1((BEC_2_4_6_TextString) beva__name );
bevl_t = bevt_0_ta_ph.bemd_0(-52976429);
bevt_2_ta_ph = bem_start_1(bevl_t);
return bevt_2_ta_ph;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_numArgsGet_0() throws Throwable {
return bevp_numArgs;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_numArgsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_numArgs = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_execNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_execName = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_targetGet_0() throws Throwable {
return bevp_target;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_targetSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_target = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_resultGet_0() throws Throwable {
return bevp_result;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_resultSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_result = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_exceptGet_0() throws Throwable {
return bevp_except;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_exceptSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_except = bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_15_SystemCurrentPlatform bem_platformGet_0() throws Throwable {
return bevp_platform;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_platformSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_platform = (BEC_2_6_15_SystemCurrentPlatform) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_6_7_SystemProcess bem_fullExecNameSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_fullExecName = bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {37, 40, 44, 44, 44, 45, 45, 53, 57, 57, 57, 64, 64, 72, 78, 78, 79, 112, 119, 119, 141, 143, 145, 146, 147, 147, 149, 153, 153, 153, 154, 154, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 31, 33, 34, 36, 41, 43, 48, 49, 50, 54, 59, 61, 65, 70, 71, 76, 82, 83, 94, 96, 100, 101, 102, 103, 105, 112, 113, 114, 115, 116, 119, 122, 126, 129, 133, 137, 140, 144, 147, 151, 154, 158, 161, 165};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 37 23
new 0 37 23
prepArgs 0 40 24
assign 1 44 31
new 0 44 31
assign 1 44 33
fullExecNameGet 0 44 33
return 1 44 34
assign 1 45 36
undef 1 45 41
return 1 53 43
assign 1 57 48
execNameGet 0 57 48
assign 1 57 49
apNew 1 57 49
return 1 57 50
assign 1 64 54
undef 1 64 59
return 1 72 61
assign 1 78 65
undef 1 78 70
assign 1 79 71
new 0 79 71
assign 1 112 76
sizeGet 0 112 76
assign 1 119 82
new 0 119 82
exit 1 119 83
assign 1 141 94
assign 1 143 96
main 0 143 96
assign 1 145 100
print 0 146 101
assign 1 147 102
new 0 147 102
return 1 147 103
return 1 149 105
assign 1 153 112
new 0 153 112
assign 1 153 113
createInstance 1 153 113
assign 1 153 114
new 0 153 114
assign 1 154 115
start 1 154 115
return 1 154 116
return 1 0 119
assign 1 0 122
return 1 0 126
assign 1 0 129
assign 1 0 133
return 1 0 137
assign 1 0 140
return 1 0 144
assign 1 0 147
return 1 0 151
assign 1 0 154
return 1 0 158
assign 1 0 161
assign 1 0 165
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1626961071: return bem_argsGet_0();
case -52976429: return bem_new_0();
case -548653141: return bem_execNameGet_0();
case 214057323: return bem_platformGet_0();
case 993165800: return bem_fullExecNameGet_0();
case -424614227: return bem_print_0();
case 1015076031: return bem_prepArgs_0();
case -734055747: return bem_exceptGet_0();
case -1570337090: return bem_exit_0();
case 1161257691: return bem_numArgsGet_0();
case -676802561: return bem_create_0();
case -2046929697: return bem_toString_0();
case -1480152800: return bem_targetGet_0();
case 827808077: return bem_default_0();
case -1648793551: return bem_hashGet_0();
case 1293705497: return bem_iteratorGet_0();
case -1337014400: return bem_copy_0();
case 256897437: return bem_execPathGet_0();
case 85146560: return bem_resultGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 526222373: return bem_def_1(bevd_0);
case -1419585773: return bem_startByName_1(bevd_0);
case 1346074140: return bem_equals_1(bevd_0);
case -105743391: return bem_exit_1((BEC_2_4_3_MathInt) bevd_0);
case -370384533: return bem_exceptSet_1(bevd_0);
case -74815089: return bem_resultSet_1(bevd_0);
case -177349955: return bem_fullExecNameSet_1(bevd_0);
case 322005879: return bem_copyTo_1(bevd_0);
case -964176778: return bem_start_1(bevd_0);
case 1210255991: return bem_numArgsSet_1(bevd_0);
case -1254654199: return bem_platformSet_1(bevd_0);
case 421952814: return bem_argsSet_1(bevd_0);
case -1827561787: return bem_targetSet_1(bevd_0);
case 1651082390: return bem_undef_1(bevd_0);
case 1024745987: return bem_execNameSet_1(bevd_0);
case -1337452029: return bem_notEquals_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 964580200: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1649942408: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -628094110: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1488275060: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemProcess_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(24, becc_BEC_2_6_7_SystemProcess_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemProcess();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst = (BEC_2_6_7_SystemProcess) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_type;
}
}
