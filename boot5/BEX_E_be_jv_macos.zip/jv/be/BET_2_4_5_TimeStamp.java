package be;
public class BET_2_4_5_TimeStamp extends BETS_Object {
public BET_2_4_5_TimeStamp() {String[] bevs_mtnames = new String[] { "new_0", "undef_1", "def_1", "methodNotDefined_2", "forwardCall_2", "invoke_2", "can_2", "equals_1", "hashGet_0", "notEquals_1", "toString_0", "print_0", "print_1", "copy_0", "copyTo_1", "iteratorGet_0", "create_0", "now_0", "new_2", "secondInMinuteGet_0", "millisecondInSecondGet_0", "minutesGet_0", "secondsGet_0", "secondsSet_1", "millisecondsGet_0", "millisecondsSet_1", "addHours_1", "addDays_1", "subtractHours_1", "subtractDays_1", "addSeconds_1", "addMilliseconds_1", "carryMillis_0", "subtractSeconds_1", "subtractMilliseconds_1", "add_1", "subtract_1", "greater_1", "lesser_1", "greaterEquals_1", "lesserEquals_1", "offByHour_1", "toStringMinutes_0", "toShortString_0", "secsGet_0", "secsSet_1", "millisGet_0", "millisSet_1", "localZoneSet_1", "localZoneGet_0", "yearGet_0", "monthGet_0", "dayGet_0", "hourGet_0", "minuteGet_0", "secondGet_0", "millisecondGet_0" };
bems_buildMethodNames(bevs_mtnames);
bevs_fieldNames = new String[] { "secs", "millis", "localZone" };
}
public BEC_2_6_6_SystemObject bems_createInstance() {
return new BEC_2_4_5_TimeStamp();
}
}
