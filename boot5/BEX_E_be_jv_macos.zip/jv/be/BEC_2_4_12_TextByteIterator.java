package be;
/* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
public static BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;

public static BET_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public BEC_2_4_12_TextByteIterator bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_emptyGet_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_containerGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_str = beva__str;
bevp_pos = (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1361*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1362*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1372*/ {
bevt_3_ta_ph = beva_buf.bem_capacityGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1373*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_ta_ph);
} /* Line: 1374*/
bevt_7_ta_ph = beva_buf.bem_sizeGet_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_7_ta_ph.bevi_int != bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1376*/ {
bevt_9_ta_ph = beva_buf.bem_sizeGet_0();
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_9_ta_ph.bevi_int = bevt_10_ta_ph.bevi_int;
} /* Line: 1377*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_12_ta_ph = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_11_ta_ph, bevt_12_ta_ph);
bevp_pos.bevi_int++;
} /* Line: 1383*/
return beva_buf;
} /*method end*/
public BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1389*/ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1391*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1397*/ {
bevt_4_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1397*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1397*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1397*/
 else /* Line: 1397*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1397*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1400*/
return beva_into;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1406*/ {
bevt_4_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1406*/
 else /* Line: 1406*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1406*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1409*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public final BEC_2_4_6_TextString bem_strGetDirect_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_posGetDirect_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGet_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public final BEC_2_4_3_MathInt bem_vcopyGetDirect_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_vcopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1337, 1337, 1337, 1341, 1345, 1349, 1354, 1355, 1356, 1361, 1361, 1361, 1362, 1362, 1364, 1364, 1368, 1368, 1368, 1368, 1372, 1372, 1372, 1373, 1373, 1373, 1373, 1374, 1374, 1376, 1376, 1376, 1376, 1377, 1377, 1377, 1379, 1379, 1379, 1383, 1385, 1389, 1389, 1389, 1390, 1391, 1393, 1397, 1397, 1397, 1397, 1397, 1397, 0, 0, 0, 1398, 1399, 1400, 1402, 1406, 1406, 1406, 1406, 1406, 1406, 0, 0, 0, 1407, 1408, 1409, 1415, 1419, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 23, 26, 29, 33, 34, 35, 43, 44, 49, 50, 51, 53, 54, 60, 61, 62, 63, 81, 82, 87, 88, 89, 90, 95, 96, 97, 99, 100, 101, 106, 107, 108, 109, 111, 112, 113, 114, 116, 121, 122, 127, 128, 129, 131, 139, 140, 145, 146, 147, 152, 153, 156, 160, 163, 164, 165, 167, 175, 176, 181, 182, 183, 188, 189, 192, 196, 199, 200, 201, 206, 209, 212, 215, 218, 222, 226, 229, 232, 236, 240, 243, 246, 250};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1337 17
new 0 1337 17
assign 1 1337 18
emptyGet 0 1337 18
new 1 1337 19
return 1 1341 23
return 1 1345 26
new 1 1349 29
assign 1 1354 33
assign 1 1355 34
new 0 1355 34
assign 1 1356 35
new 0 1356 35
assign 1 1361 43
sizeGet 0 1361 43
assign 1 1361 44
greater 1 1361 49
assign 1 1362 50
new 0 1362 50
return 1 1362 51
assign 1 1364 53
new 0 1364 53
return 1 1364 54
assign 1 1368 60
new 0 1368 60
assign 1 1368 61
new 1 1368 61
assign 1 1368 62
next 1 1368 62
return 1 1368 63
assign 1 1372 81
sizeGet 0 1372 81
assign 1 1372 82
greater 1 1372 87
assign 1 1373 88
capacityGet 0 1373 88
assign 1 1373 89
new 0 1373 89
assign 1 1373 90
lesser 1 1373 95
assign 1 1374 96
new 0 1374 96
capacitySet 1 1374 97
assign 1 1376 99
sizeGet 0 1376 99
assign 1 1376 100
new 0 1376 100
assign 1 1376 101
notEquals 1 1376 106
assign 1 1377 107
sizeGet 0 1377 107
assign 1 1377 108
new 0 1377 108
setValue 1 1377 109
assign 1 1379 111
new 0 1379 111
assign 1 1379 112
getInt 2 1379 112
setIntUnchecked 2 1379 113
incrementValue 0 1383 114
return 1 1385 116
assign 1 1389 121
sizeGet 0 1389 121
assign 1 1389 122
greater 1 1389 127
getInt 2 1390 128
incrementValue 0 1391 129
return 1 1393 131
assign 1 1397 139
new 0 1397 139
assign 1 1397 140
greater 1 1397 145
assign 1 1397 146
sizeGet 0 1397 146
assign 1 1397 147
greaterEquals 1 1397 152
assign 1 0 153
assign 1 0 156
assign 1 0 160
decrementValue 0 1398 163
getInt 2 1399 164
incrementValue 0 1400 165
return 1 1402 167
assign 1 1406 175
new 0 1406 175
assign 1 1406 176
greater 1 1406 181
assign 1 1406 182
sizeGet 0 1406 182
assign 1 1406 183
greaterEquals 1 1406 188
assign 1 0 189
assign 1 0 192
assign 1 0 196
decrementValue 0 1407 199
setIntUnchecked 2 1408 200
incrementValue 0 1409 201
return 1 1415 206
return 1 1419 209
return 1 0 212
return 1 0 215
assign 1 0 218
assign 1 0 222
return 1 0 226
return 1 0 229
assign 1 0 232
assign 1 0 236
return 1 0 240
return 1 0 243
assign 1 0 246
assign 1 0 250
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1719079203: return bem_strGet_0();
case -204643138: return bem_strGetDirect_0();
case 138302413: return bem_new_0();
case 712783465: return bem_hashGet_0();
case 178019168: return bem_toString_0();
case 1897973507: return bem_vcopyGet_0();
case 1379005855: return bem_containerGet_0();
case 105271020: return bem_posGet_0();
case -681478278: return bem_nextGet_0();
case 432179744: return bem_fieldNamesGet_0();
case -27721956: return bem_vcopyGetDirect_0();
case 1315977308: return bem_hasNextGet_0();
case 2036051475: return bem_iteratorGet_0();
case -2146817816: return bem_posGetDirect_0();
case -1747597055: return bem_create_0();
case 530220965: return bem_byteIteratorIteratorGet_0();
case -1627734356: return bem_serializeToString_0();
case -1812965558: return bem_fieldIteratorGet_0();
case -1564975844: return bem_serializeContents_0();
case 556090396: return bem_sourceFileNameGet_0();
case -811046848: return bem_copy_0();
case 1267631579: return bem_serializationIteratorGet_0();
case 67700549: return bem_classNameGet_0();
case 1609612359: return bem_echo_0();
case 1132429880: return bem_tagGet_0();
case -2106036149: return bem_deserializeClassNameGet_0();
case 478950400: return bem_print_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1909830385: return bem_strSet_1(bevd_0);
case 1184247111: return bem_sameClass_1(bevd_0);
case 465594002: return bem_def_1(bevd_0);
case 1611934182: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1999489743: return bem_vcopySetDirect_1(bevd_0);
case -225795861: return bem_sameType_1(bevd_0);
case 399670111: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -951859496: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case -1085415307: return bem_strSetDirect_1(bevd_0);
case 606870566: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -60802666: return bem_otherClass_1(bevd_0);
case -132838650: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1951774795: return bem_copyTo_1(bevd_0);
case 2059692827: return bem_sameObject_1(bevd_0);
case 2107311680: return bem_notEquals_1(bevd_0);
case 1866417810: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1964074985: return bem_otherType_1(bevd_0);
case -301008142: return bem_equals_1(bevd_0);
case 257683973: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1366056513: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1675052052: return bem_posSetDirect_1(bevd_0);
case 754502653: return bem_posSet_1(bevd_0);
case -115157130: return bem_vcopySet_1(bevd_0);
case -1084952852: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1035176912: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1679235980: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1107212100: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 471675441: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1306506121: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_TextByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_type;
}
}
