package be;
/* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;

public static BET_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public BEC_2_4_12_TextByteIterator bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_emptyGet_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_containerGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_str = beva__str;
bevp_pos = (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1396*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1397*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
BEC_2_4_3_MathInt bevt_13_ta_ph = null;
BEC_2_4_3_MathInt bevt_14_ta_ph = null;
BEC_2_4_3_MathInt bevt_15_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1407*/ {
bevt_3_ta_ph = beva_buf.bem_capacityGet_0();
bevt_4_ta_ph = bece_BEC_2_4_12_TextByteIterator_bevo_0;
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1408*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_ta_ph);
} /* Line: 1409*/
bevt_7_ta_ph = beva_buf.bem_sizeGet_0();
bevt_8_ta_ph = bece_BEC_2_4_12_TextByteIterator_bevo_1;
if (bevt_7_ta_ph.bevi_int != bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1411*/ {
bevt_9_ta_ph = beva_buf.bem_sizeGet_0();
bevt_11_ta_ph = bece_BEC_2_4_12_TextByteIterator_bevo_2;
bevt_10_ta_ph = (BEC_2_4_3_MathInt) bevt_11_ta_ph.bem_once_0();
bevt_9_ta_ph.bevi_int = bevt_10_ta_ph.bevi_int;
} /* Line: 1412*/
bevt_12_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_13_ta_ph = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_ta_ph, bevt_13_ta_ph);
bevp_pos.bevi_int++;
} /* Line: 1418*/
return beva_buf;
} /*method end*/
public BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1424*/ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1426*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_4_12_TextByteIterator_bevo_3;
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1432*/ {
bevt_4_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1432*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1432*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1432*/
 else /* Line: 1432*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1432*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1435*/
return beva_into;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = bece_BEC_2_4_12_TextByteIterator_bevo_4;
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1441*/ {
bevt_4_ta_ph = bevp_str.bem_sizeGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1441*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1441*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1441*/
 else /* Line: 1441*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1441*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1444*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public final BEC_2_4_6_TextString bem_strGetDirect_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_posGetDirect_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGet_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public final BEC_2_4_3_MathInt bem_vcopyGetDirect_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_vcopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1372, 1372, 1372, 1376, 1380, 1384, 1389, 1390, 1391, 1396, 1396, 1396, 1397, 1397, 1399, 1399, 1403, 1403, 1403, 1403, 1407, 1407, 1407, 1408, 1408, 1408, 1408, 1409, 1409, 1411, 1411, 1411, 1411, 1412, 1412, 1412, 1412, 1414, 1414, 1414, 1418, 1420, 1424, 1424, 1424, 1425, 1426, 1428, 1432, 1432, 1432, 1432, 1432, 1432, 0, 0, 0, 1433, 1434, 1435, 1437, 1441, 1441, 1441, 1441, 1441, 1441, 0, 0, 0, 1442, 1443, 1444, 1450, 1454, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 28, 31, 34, 38, 39, 40, 48, 49, 54, 55, 56, 58, 59, 65, 66, 67, 68, 87, 88, 93, 94, 95, 96, 101, 102, 103, 105, 106, 107, 112, 113, 114, 115, 116, 118, 119, 120, 121, 123, 128, 129, 134, 135, 136, 138, 146, 147, 152, 153, 154, 159, 160, 163, 167, 170, 171, 172, 174, 182, 183, 188, 189, 190, 195, 196, 199, 203, 206, 207, 208, 213, 216, 219, 222, 225, 229, 233, 236, 239, 243, 247, 250, 253, 257};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1372 22
new 0 1372 22
assign 1 1372 23
emptyGet 0 1372 23
new 1 1372 24
return 1 1376 28
return 1 1380 31
new 1 1384 34
assign 1 1389 38
assign 1 1390 39
new 0 1390 39
assign 1 1391 40
new 0 1391 40
assign 1 1396 48
sizeGet 0 1396 48
assign 1 1396 49
greater 1 1396 54
assign 1 1397 55
new 0 1397 55
return 1 1397 56
assign 1 1399 58
new 0 1399 58
return 1 1399 59
assign 1 1403 65
new 0 1403 65
assign 1 1403 66
new 1 1403 66
assign 1 1403 67
next 1 1403 67
return 1 1403 68
assign 1 1407 87
sizeGet 0 1407 87
assign 1 1407 88
greater 1 1407 93
assign 1 1408 94
capacityGet 0 1408 94
assign 1 1408 95
new 0 1408 95
assign 1 1408 96
lesser 1 1408 101
assign 1 1409 102
new 0 1409 102
capacitySet 1 1409 103
assign 1 1411 105
sizeGet 0 1411 105
assign 1 1411 106
new 0 1411 106
assign 1 1411 107
notEquals 1 1411 112
assign 1 1412 113
sizeGet 0 1412 113
assign 1 1412 114
new 0 1412 114
assign 1 1412 115
once 0 1412 115
setValue 1 1412 116
assign 1 1414 118
new 0 1414 118
assign 1 1414 119
getInt 2 1414 119
setIntUnchecked 2 1414 120
incrementValue 0 1418 121
return 1 1420 123
assign 1 1424 128
sizeGet 0 1424 128
assign 1 1424 129
greater 1 1424 134
getInt 2 1425 135
incrementValue 0 1426 136
return 1 1428 138
assign 1 1432 146
new 0 1432 146
assign 1 1432 147
greater 1 1432 152
assign 1 1432 153
sizeGet 0 1432 153
assign 1 1432 154
greaterEquals 1 1432 159
assign 1 0 160
assign 1 0 163
assign 1 0 167
decrementValue 0 1433 170
getInt 2 1434 171
incrementValue 0 1435 172
return 1 1437 174
assign 1 1441 182
new 0 1441 182
assign 1 1441 183
greater 1 1441 188
assign 1 1441 189
sizeGet 0 1441 189
assign 1 1441 190
greaterEquals 1 1441 195
assign 1 0 196
assign 1 0 199
assign 1 0 203
decrementValue 0 1442 206
setIntUnchecked 2 1443 207
incrementValue 0 1444 208
return 1 1450 213
return 1 1454 216
return 1 0 219
return 1 0 222
assign 1 0 225
assign 1 0 229
return 1 0 233
return 1 0 236
assign 1 0 239
assign 1 0 243
return 1 0 247
return 1 0 250
assign 1 0 253
assign 1 0 257
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 126164297: return bem_serializationIteratorGet_0();
case -374496050: return bem_tagGet_0();
case 956237443: return bem_byteIteratorIteratorGet_0();
case -1530492540: return bem_many_0();
case 2021396727: return bem_hasNextGet_0();
case -1606863806: return bem_fieldIteratorGet_0();
case -190996314: return bem_nextGet_0();
case 1963846645: return bem_serializeContents_0();
case -1359840989: return bem_toAny_0();
case -1938521961: return bem_create_0();
case 1154422793: return bem_vcopyGet_0();
case 1845595557: return bem_containerGet_0();
case -1776592849: return bem_posGet_0();
case 1469761457: return bem_serializeToString_0();
case -1640020074: return bem_toString_0();
case -1483834827: return bem_copy_0();
case -1677294751: return bem_hashGet_0();
case 921209725: return bem_echo_0();
case -1660007365: return bem_iteratorGet_0();
case -575041668: return bem_posGetDirect_0();
case 976077722: return bem_new_0();
case 2028199664: return bem_once_0();
case 1442246848: return bem_strGet_0();
case -1120775249: return bem_classNameGet_0();
case -559654393: return bem_sourceFileNameGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case -129765629: return bem_print_0();
case -1219800889: return bem_vcopyGetDirect_0();
case 1898859637: return bem_strGetDirect_0();
case 1428196909: return bem_deserializeClassNameGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1414981672: return bem_defined_1(bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case -1903358960: return bem_vcopySetDirect_1(bevd_0);
case -1492174161: return bem_posSet_1(bevd_0);
case -1971135502: return bem_strSetDirect_1(bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case -247231398: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -516612268: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case -103182847: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case -1360401010: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case 1036190738: return bem_strSet_1(bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case -651887669: return bem_posSetDirect_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -721284330: return bem_vcopySet_1(bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 200898755: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1789648416: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_TextByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_type;
}
}
