package be;
/* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
public static BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;

public static BET_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_type;

public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_vcopy;
public BEC_2_4_12_TextByteIterator bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_7_TextStrings bevt_1_ta_ph = null;
bevt_1_ta_ph = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_ta_ph = bevt_1_ta_ph.bem_emptyGet_0();
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_containerGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_pos = (new BEC_2_4_3_MathInt(0));
bevp_str = beva__str;
bevp_vcopy = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_lengthGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1311*/ {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_2_ta_ph;
} /* Line: 1312*/
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_3_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_ta_ph);
bevt_0_ta_ph = bem_next_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_4_3_MathInt bevt_5_ta_ph = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
BEC_2_4_3_MathInt bevt_12_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_lengthGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1322*/ {
bevt_3_ta_ph = beva_buf.bem_capacityGet_0();
bevt_4_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_3_ta_ph.bevi_int < bevt_4_ta_ph.bevi_int) {
bevt_2_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_2_ta_ph.bevi_bool)/* Line: 1323*/ {
bevt_5_ta_ph = (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_ta_ph);
} /* Line: 1324*/
bevt_7_ta_ph = beva_buf.bem_lengthGet_0();
bevt_8_ta_ph = (new BEC_2_4_3_MathInt(1));
if (bevt_7_ta_ph.bevi_int != bevt_8_ta_ph.bevi_int) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 1326*/ {
bevt_9_ta_ph = beva_buf.bem_lengthGet_0();
bevt_10_ta_ph = (new BEC_2_4_3_MathInt(1));
bevt_9_ta_ph.bevi_int = bevt_10_ta_ph.bevi_int;
} /* Line: 1327*/
bevt_11_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_12_ta_ph = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_11_ta_ph, bevt_12_ta_ph);
bevp_pos.bevi_int++;
} /* Line: 1333*/
return beva_buf;
} /*method end*/
public BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = bevp_str.bem_lengthGet_0();
if (bevt_1_ta_ph.bevi_int > bevp_pos.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 1339*/ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1341*/
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1347*/ {
bevt_4_ta_ph = bevp_str.bem_lengthGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1347*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1347*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1347*/
 else /* Line: 1347*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1347*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1350*/
return beva_into;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
bevt_2_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevp_pos.bevi_int > bevt_2_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 1356*/ {
bevt_4_ta_ph = bevp_str.bem_lengthGet_0();
if (bevt_4_ta_ph.bevi_int >= bevp_pos.bevi_int) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 1356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 1356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 1356*/
 else /* Line: 1356*/ {
bevt_0_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_0_ta_anchor.bevi_bool)/* Line: 1356*/ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1359*/
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1285, 1285, 1285, 1289, 1293, 1297, 1302, 1305, 1306, 1311, 1311, 1311, 1312, 1312, 1314, 1314, 1318, 1318, 1318, 1318, 1322, 1322, 1322, 1323, 1323, 1323, 1323, 1324, 1324, 1326, 1326, 1326, 1326, 1327, 1327, 1327, 1329, 1329, 1329, 1333, 1335, 1339, 1339, 1339, 1340, 1341, 1343, 1347, 1347, 1347, 1347, 1347, 1347, 0, 0, 0, 1348, 1349, 1350, 1352, 1356, 1356, 1356, 1356, 1356, 1356, 0, 0, 0, 1357, 1358, 1359, 1365, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {17, 18, 19, 23, 26, 29, 33, 34, 35, 43, 44, 49, 50, 51, 53, 54, 60, 61, 62, 63, 79, 80, 85, 86, 87, 88, 93, 94, 95, 97, 98, 99, 104, 105, 106, 107, 109, 110, 111, 112, 114, 119, 120, 125, 126, 127, 129, 137, 138, 143, 144, 145, 150, 151, 154, 158, 161, 162, 163, 165, 173, 174, 179, 180, 181, 186, 187, 190, 194, 197, 198, 199, 204, 207, 210};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1285 17
new 0 1285 17
assign 1 1285 18
emptyGet 0 1285 18
new 1 1285 19
return 1 1289 23
return 1 1293 26
new 1 1297 29
assign 1 1302 33
new 0 1302 33
assign 1 1305 34
assign 1 1306 35
new 0 1306 35
assign 1 1311 43
lengthGet 0 1311 43
assign 1 1311 44
greater 1 1311 49
assign 1 1312 50
new 0 1312 50
return 1 1312 51
assign 1 1314 53
new 0 1314 53
return 1 1314 54
assign 1 1318 60
new 0 1318 60
assign 1 1318 61
new 1 1318 61
assign 1 1318 62
next 1 1318 62
return 1 1318 63
assign 1 1322 79
lengthGet 0 1322 79
assign 1 1322 80
greater 1 1322 85
assign 1 1323 86
capacityGet 0 1323 86
assign 1 1323 87
new 0 1323 87
assign 1 1323 88
lesser 1 1323 93
assign 1 1324 94
new 0 1324 94
capacitySet 1 1324 95
assign 1 1326 97
lengthGet 0 1326 97
assign 1 1326 98
new 0 1326 98
assign 1 1326 99
notEquals 1 1326 104
assign 1 1327 105
lengthGet 0 1327 105
assign 1 1327 106
new 0 1327 106
setValue 1 1327 107
assign 1 1329 109
new 0 1329 109
assign 1 1329 110
getInt 2 1329 110
setIntUnchecked 2 1329 111
incrementValue 0 1333 112
return 1 1335 114
assign 1 1339 119
lengthGet 0 1339 119
assign 1 1339 120
greater 1 1339 125
getInt 2 1340 126
incrementValue 0 1341 127
return 1 1343 129
assign 1 1347 137
new 0 1347 137
assign 1 1347 138
greater 1 1347 143
assign 1 1347 144
lengthGet 0 1347 144
assign 1 1347 145
greaterEquals 1 1347 150
assign 1 0 151
assign 1 0 154
assign 1 0 158
decrementValue 0 1348 161
getInt 2 1349 162
incrementValue 0 1350 163
return 1 1352 165
assign 1 1356 173
new 0 1356 173
assign 1 1356 174
greater 1 1356 179
assign 1 1356 180
lengthGet 0 1356 180
assign 1 1356 181
greaterEquals 1 1356 186
assign 1 0 187
assign 1 0 190
assign 1 0 194
decrementValue 0 1357 197
setIntUnchecked 2 1358 198
incrementValue 0 1359 199
return 1 1365 204
return 1 0 207
assign 1 0 210
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -662844650: return bem_iteratorGet_0();
case 1155069902: return bem_print_0();
case 2128492359: return bem_serializeToString_0();
case -1477018360: return bem_toString_0();
case 1379821961: return bem_create_0();
case 619786720: return bem_nextGet_0();
case 310309721: return bem_hashGet_0();
case 1030336271: return bem_new_0();
case -1577915776: return bem_posGet_0();
case -1866674687: return bem_hasNextGet_0();
case -1141241291: return bem_copy_0();
case 1953259047: return bem_containerGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 156150743: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1801291774: return bem_def_1(bevd_0);
case 1738502576: return bem_copyTo_1(bevd_0);
case -904066467: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1061126961: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case -1117209842: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 278034565: return bem_equals_1(bevd_0);
case -1176436455: return bem_print_1(bevd_0);
case 1075706066: return bem_undef_1(bevd_0);
case -680654277: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1264563233: return bem_notEquals_1(bevd_0);
case -119493843: return bem_posSet_1(bevd_0);
case -635723371: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -844523032: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1584274286: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 752466488: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -880661396: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_TextByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_type;
}
}
