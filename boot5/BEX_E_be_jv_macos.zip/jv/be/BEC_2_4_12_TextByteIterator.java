package be;
/* IO:File: source/base/String.be */
public class BEC_2_4_12_TextByteIterator extends BEC_2_6_6_SystemObject {
public BEC_2_4_12_TextByteIterator() { }
private static byte[] becc_BEC_2_4_12_TextByteIterator_clname = {0x54,0x65,0x78,0x74,0x3A,0x42,0x79,0x74,0x65,0x49,0x74,0x65,0x72,0x61,0x74,0x6F,0x72};
private static byte[] becc_BEC_2_4_12_TextByteIterator_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x74,0x72,0x69,0x6E,0x67,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_1 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_4_12_TextByteIterator_bevo_4 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_inst;

public static BET_2_4_12_TextByteIterator bece_BEC_2_4_12_TextByteIterator_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_4_3_MathInt bevp_pos;
public BEC_2_4_3_MathInt bevp_vcopy;
public BEC_2_4_12_TextByteIterator bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_emptyGet_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_containerGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_serializeToString_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_deserializeFromStringNew_1(BEC_2_4_6_TextString beva_str) throws Throwable {
bem_new_1(beva_str);
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_str = beva__str;
bevp_pos = (new BEC_2_4_3_MathInt(0));
bevp_vcopy = (new BEC_2_4_3_MathInt());
return this;
} /*method end*/
public BEC_2_5_4_LogicBool bem_hasNextGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1342 */ {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_2_tmpany_phold;
} /* Line: 1343 */
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_3_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_nextGet_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = (new BEC_2_4_3_MathInt(1));
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(bevt_2_tmpany_phold);
bevt_0_tmpany_phold = bem_next_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_next_1(BEC_2_4_6_TextString beva_buf) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_12_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_13_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_14_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_15_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1353 */ {
bevt_3_tmpany_phold = beva_buf.bem_capacityGet_0();
bevt_4_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_4_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 1354 */ {
bevt_5_tmpany_phold = (new BEC_2_4_3_MathInt(1));
beva_buf.bem_capacitySet_1(bevt_5_tmpany_phold);
} /* Line: 1355 */
bevt_7_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_8_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_1;
if (bevt_7_tmpany_phold.bevi_int != bevt_8_tmpany_phold.bevi_int) {
bevt_6_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_6_tmpany_phold.bevi_bool) /* Line: 1357 */ {
bevt_9_tmpany_phold = beva_buf.bem_sizeGet_0();
bevt_11_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_2;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_9_tmpany_phold.bevi_int = bevt_10_tmpany_phold.bevi_int;
} /* Line: 1358 */
bevt_12_tmpany_phold = (new BEC_2_4_3_MathInt(0));
bevt_13_tmpany_phold = bevp_str.bem_getInt_2(bevp_pos, bevp_vcopy);
beva_buf.bem_setIntUnchecked_2(bevt_12_tmpany_phold, bevt_13_tmpany_phold);
bevp_pos.bevi_int++;
} /* Line: 1364 */
return beva_buf;
} /*method end*/
public BEC_2_4_3_MathInt bem_nextInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_1_tmpany_phold.bevi_int > bevp_pos.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 1370 */ {
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1372 */
return beva_into;
} /*method end*/
public BEC_2_4_3_MathInt bem_currentInt_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_3;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1378 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1378 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1378 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1378 */
 else  /* Line: 1378 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1378 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_getInt_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1381 */
return beva_into;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_currentIntSet_1(BEC_2_4_3_MathInt beva_into) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevt_2_tmpany_phold = bece_BEC_2_4_12_TextByteIterator_bevo_4;
if (bevp_pos.bevi_int > bevt_2_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 1387 */ {
bevt_4_tmpany_phold = bevp_str.bem_sizeGet_0();
if (bevt_4_tmpany_phold.bevi_int >= bevp_pos.bevi_int) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 1387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 1387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 1387 */
 else  /* Line: 1387 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 1387 */ {
bevp_pos.bem_decrementValue_0();
bevp_str.bem_setIntUnchecked_2(bevp_pos, beva_into);
bevp_pos.bevi_int++;
} /* Line: 1390 */
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_byteIteratorIteratorGet_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public final BEC_2_4_6_TextString bem_strGetDirect_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_strSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_posGet_0() throws Throwable {
return bevp_pos;
} /*method end*/
public final BEC_2_4_3_MathInt bem_posGetDirect_0() throws Throwable {
return bevp_pos;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_posSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_posSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_pos = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_vcopyGet_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public final BEC_2_4_3_MathInt bem_vcopyGetDirect_0() throws Throwable {
return bevp_vcopy;
} /*method end*/
public BEC_2_4_12_TextByteIterator bem_vcopySet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_4_12_TextByteIterator bem_vcopySetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_vcopy = (BEC_2_4_3_MathInt) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {1318, 1318, 1318, 1322, 1326, 1330, 1335, 1336, 1337, 1342, 1342, 1342, 1343, 1343, 1345, 1345, 1349, 1349, 1349, 1349, 1353, 1353, 1353, 1354, 1354, 1354, 1354, 1355, 1355, 1357, 1357, 1357, 1357, 1358, 1358, 1358, 1358, 1360, 1360, 1360, 1364, 1366, 1370, 1370, 1370, 1371, 1372, 1374, 1378, 1378, 1378, 1378, 1378, 1378, 0, 0, 0, 1379, 1380, 1381, 1383, 1387, 1387, 1387, 1387, 1387, 1387, 0, 0, 0, 1388, 1389, 1390, 1396, 1400, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {22, 23, 24, 28, 31, 34, 38, 39, 40, 48, 49, 54, 55, 56, 58, 59, 65, 66, 67, 68, 87, 88, 93, 94, 95, 96, 101, 102, 103, 105, 106, 107, 112, 113, 114, 115, 116, 118, 119, 120, 121, 123, 128, 129, 134, 135, 136, 138, 146, 147, 152, 153, 154, 159, 160, 163, 167, 170, 171, 172, 174, 182, 183, 188, 189, 190, 195, 196, 199, 203, 206, 207, 208, 213, 216, 219, 222, 225, 229, 233, 236, 239, 243, 247, 250, 253, 257};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 1318 22
new 0 1318 22
assign 1 1318 23
emptyGet 0 1318 23
new 1 1318 24
return 1 1322 28
return 1 1326 31
new 1 1330 34
assign 1 1335 38
assign 1 1336 39
new 0 1336 39
assign 1 1337 40
new 0 1337 40
assign 1 1342 48
sizeGet 0 1342 48
assign 1 1342 49
greater 1 1342 54
assign 1 1343 55
new 0 1343 55
return 1 1343 56
assign 1 1345 58
new 0 1345 58
return 1 1345 59
assign 1 1349 65
new 0 1349 65
assign 1 1349 66
new 1 1349 66
assign 1 1349 67
next 1 1349 67
return 1 1349 68
assign 1 1353 87
sizeGet 0 1353 87
assign 1 1353 88
greater 1 1353 93
assign 1 1354 94
capacityGet 0 1354 94
assign 1 1354 95
new 0 1354 95
assign 1 1354 96
lesser 1 1354 101
assign 1 1355 102
new 0 1355 102
capacitySet 1 1355 103
assign 1 1357 105
sizeGet 0 1357 105
assign 1 1357 106
new 0 1357 106
assign 1 1357 107
notEquals 1 1357 112
assign 1 1358 113
sizeGet 0 1358 113
assign 1 1358 114
new 0 1358 114
assign 1 1358 115
once 0 1358 115
setValue 1 1358 116
assign 1 1360 118
new 0 1360 118
assign 1 1360 119
getInt 2 1360 119
setIntUnchecked 2 1360 120
incrementValue 0 1364 121
return 1 1366 123
assign 1 1370 128
sizeGet 0 1370 128
assign 1 1370 129
greater 1 1370 134
getInt 2 1371 135
incrementValue 0 1372 136
return 1 1374 138
assign 1 1378 146
new 0 1378 146
assign 1 1378 147
greater 1 1378 152
assign 1 1378 153
sizeGet 0 1378 153
assign 1 1378 154
greaterEquals 1 1378 159
assign 1 0 160
assign 1 0 163
assign 1 0 167
decrementValue 0 1379 170
getInt 2 1380 171
incrementValue 0 1381 172
return 1 1383 174
assign 1 1387 182
new 0 1387 182
assign 1 1387 183
greater 1 1387 188
assign 1 1387 189
sizeGet 0 1387 189
assign 1 1387 190
greaterEquals 1 1387 195
assign 1 0 196
assign 1 0 199
assign 1 0 203
decrementValue 0 1388 206
setIntUnchecked 2 1389 207
incrementValue 0 1390 208
return 1 1396 213
return 1 1400 216
return 1 0 219
return 1 0 222
assign 1 0 225
assign 1 0 229
return 1 0 233
return 1 0 236
assign 1 0 239
assign 1 0 243
return 1 0 247
return 1 0 250
assign 1 0 253
assign 1 0 257
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2061412556: return bem_classNameGet_0();
case 1315296621: return bem_vcopyGet_0();
case -1022157902: return bem_deserializeClassNameGet_0();
case -868741030: return bem_nextGet_0();
case 1839857805: return bem_vcopyGetDirect_0();
case 605755759: return bem_fieldNamesGet_0();
case -39706070: return bem_serializeContents_0();
case 2069196027: return bem_print_0();
case 1359777543: return bem_toAny_0();
case 874968344: return bem_once_0();
case 1460552894: return bem_posGet_0();
case 344752250: return bem_hashGet_0();
case -1276472965: return bem_hasNextGet_0();
case 27033645: return bem_sourceFileNameGet_0();
case 502031978: return bem_iteratorGet_0();
case 1480415803: return bem_serializationIteratorGet_0();
case -1920373479: return bem_strGet_0();
case 325964466: return bem_echo_0();
case 1965613314: return bem_tagGet_0();
case 1913804485: return bem_posGetDirect_0();
case -486337211: return bem_strGetDirect_0();
case 1578098134: return bem_toString_0();
case 26417469: return bem_create_0();
case 962099177: return bem_fieldIteratorGet_0();
case -1878305271: return bem_many_0();
case 334767424: return bem_copy_0();
case 967695511: return bem_byteIteratorIteratorGet_0();
case 159014997: return bem_containerGet_0();
case 2132890711: return bem_new_0();
case -799200084: return bem_serializeToString_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1999883955: return bem_vcopySet_1(bevd_0);
case 52647327: return bem_def_1(bevd_0);
case 1263041811: return bem_nextInt_1((BEC_2_4_3_MathInt) bevd_0);
case 1669065184: return bem_equals_1(bevd_0);
case -2067731006: return bem_posSetDirect_1(bevd_0);
case -1393590894: return bem_strSetDirect_1(bevd_0);
case -1603770030: return bem_defined_1(bevd_0);
case 419124452: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 846963577: return bem_posSet_1(bevd_0);
case 1489186141: return bem_sameType_1(bevd_0);
case -1199083406: return bem_currentInt_1((BEC_2_4_3_MathInt) bevd_0);
case -342646871: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 404755048: return bem_otherType_1(bevd_0);
case -1135610540: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1723224710: return bem_next_1((BEC_2_4_6_TextString) bevd_0);
case -2131512747: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 1056219816: return bem_currentIntSet_1((BEC_2_4_3_MathInt) bevd_0);
case 1968655109: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1316772144: return bem_sameClass_1(bevd_0);
case 1533828052: return bem_strSet_1(bevd_0);
case 288108016: return bem_sameObject_1(bevd_0);
case 1549997217: return bem_otherClass_1(bevd_0);
case -979994310: return bem_vcopySetDirect_1(bevd_0);
case 103812728: return bem_undef_1(bevd_0);
case -1374669487: return bem_notEquals_1(bevd_0);
case 1955467286: return bem_copyTo_1(bevd_0);
case 1139141946: return bem_undefined_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1613321201: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 988081359: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 220616626: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -288967797: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 378546086: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 515513732: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -689949786: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(17, becc_BEC_2_4_12_TextByteIterator_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_4_12_TextByteIterator_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_4_12_TextByteIterator();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst = (BEC_2_4_12_TextByteIterator) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_4_12_TextByteIterator.bece_BEC_2_4_12_TextByteIterator_bevs_type;
}
}
