package be;
/* IO:File: source/extended/Template.be */
public class BEC_2_7_10_ReplaceStringStep extends BEC_2_6_6_SystemObject {
public BEC_2_7_10_ReplaceStringStep() { }
private static byte[] becc_BEC_2_7_10_ReplaceStringStep_clname = {0x52,0x65,0x70,0x6C,0x61,0x63,0x65,0x3A,0x53,0x74,0x72,0x69,0x6E,0x67,0x53,0x74,0x65,0x70};
private static byte[] becc_BEC_2_7_10_ReplaceStringStep_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x54,0x65,0x6D,0x70,0x6C,0x61,0x74,0x65,0x2E,0x62,0x65};
public static BEC_2_7_10_ReplaceStringStep bece_BEC_2_7_10_ReplaceStringStep_bevs_inst;

public static BET_2_7_10_ReplaceStringStep bece_BEC_2_7_10_ReplaceStringStep_bevs_type;

public BEC_2_4_6_TextString bevp_str;
public BEC_2_7_10_ReplaceStringStep bem_new_1(BEC_2_4_6_TextString beva__str) throws Throwable {
bevp_str = beva__str;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_handle_1(BEC_2_6_6_SystemObject beva_r) throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_4_6_TextString bem_strGet_0() throws Throwable {
return bevp_str;
} /*method end*/
public BEC_2_7_10_ReplaceStringStep bem_strSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_str = (BEC_2_4_6_TextString) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {40, 46, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 17, 20, 23};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 40 13
return 1 46 17
return 1 0 20
assign 1 0 23
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1676715436: return bem_iteratorGet_0();
case -1844269288: return bem_create_0();
case -2042483961: return bem_toString_0();
case -1425898375: return bem_new_0();
case 436863164: return bem_hashGet_0();
case 1861855516: return bem_copy_0();
case -1757033570: return bem_print_0();
case 1301945151: return bem_strGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 756990913: return bem_strSet_1(bevd_0);
case -272587445: return bem_notEquals_1(bevd_0);
case 324846295: return bem_def_1(bevd_0);
case 1306600423: return bem_equals_1(bevd_0);
case 639451594: return bem_handle_1(bevd_0);
case -371582843: return bem_copyTo_1(bevd_0);
case 2015800048: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case 1051624606: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1704989212: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1725892051: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1176905374: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1263166407: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_7_10_ReplaceStringStep_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(27, becc_BEC_2_7_10_ReplaceStringStep_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_7_10_ReplaceStringStep();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_inst = (BEC_2_7_10_ReplaceStringStep) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_7_10_ReplaceStringStep.bece_BEC_2_7_10_ReplaceStringStep_bevs_type;
}
}
