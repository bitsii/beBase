package be;
/* IO:File: source/base/Objects.be */
public class BEC_2_6_7_SystemObjects extends BEC_2_6_6_SystemObject {
public BEC_2_6_7_SystemObjects() { }
private static byte[] becc_BEC_2_6_7_SystemObjects_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x4F,0x62,0x6A,0x65,0x63,0x74,0x73};
private static byte[] becc_BEC_2_6_7_SystemObjects_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4F,0x62,0x6A,0x65,0x63,0x74,0x73,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_7_SystemObjects_bels_0 = {0x63,0x6C,0x61,0x73,0x73,0x20,0x6E,0x61,0x6D,0x65,0x20,0x69,0x73,0x20,0x6E,0x75,0x6C,0x6C};
private static byte[] bece_BEC_2_6_7_SystemObjects_bels_1 = {0x43,0x6C,0x61,0x73,0x73,0x20,0x6E,0x6F,0x74,0x20,0x66,0x6F,0x75,0x6E,0x64,0x20};
public static BEC_2_6_7_SystemObjects bece_BEC_2_6_7_SystemObjects_bevs_inst;

public static BET_2_6_7_SystemObjects bece_BEC_2_6_7_SystemObjects_bevs_type;

public BEC_2_6_7_SystemObjects bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_7_SystemObjects bem_default_0() throws Throwable {
return this;
} /*method end*/
public final BEC_2_4_6_TextString bem_sourceFileName_1(BEC_2_6_6_SystemObject beva_org) throws Throwable {
BEC_2_4_6_TextString bevl_xi = null;

      //byte[] bevls_clname = bemc_clfile();
      //bevl_xi = new BEC_2_4_6_TextString(bevls_clname.length, bevls_clname);
      bevl_xi = beva_org.bemc_clfiles();
      return bevl_xi;
} /*method end*/
public final BEC_2_5_4_LogicBool bem_sameObject_2(BEC_2_6_6_SystemObject beva_org, BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;

      if (beva_org != beva_x) {
        return be.BECS_Runtime.boolFalse;
      }
      bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_4_3_MathInt bem_tag_1(BEC_2_6_6_SystemObject beva_org) throws Throwable {
BEC_2_4_3_MathInt bevl_toRet = null;
bevl_toRet = (new BEC_2_4_3_MathInt());

      bevl_toRet.bevi_int = beva_org.hashCode();
      return bevl_toRet;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_1(BEC_2_4_6_TextString beva_cname) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
bevt_0_ta_ph = bem_createInstance_2(beva_cname, bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public final BEC_2_6_6_SystemObject bem_createInstance_2(BEC_2_4_6_TextString beva_cname, BEC_2_5_4_LogicBool beva_throwOnFail) throws Throwable {
BEC_2_6_6_SystemObject bevl_result = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_6_19_SystemInvocationException bevt_1_ta_ph = null;
BEC_2_4_6_TextString bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_9_SystemException bevt_4_ta_ph = null;
BEC_2_4_6_TextString bevt_5_ta_ph = null;
BEC_2_4_6_TextString bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_11_SystemInitializer bevt_8_ta_ph = null;
if (beva_cname == null) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 98*/ {
bevt_2_ta_ph = (new BEC_2_4_6_TextString(18, bece_BEC_2_6_7_SystemObjects_bels_0));
bevt_1_ta_ph = (BEC_2_6_19_SystemInvocationException) (new BEC_2_6_19_SystemInvocationException()).bem_new_1(bevt_2_ta_ph);
throw new be.BECS_ThrowBack(bevt_1_ta_ph);
} /* Line: 99*/
bevl_result = null;

        String key = new String(beva_cname.bevi_bytes, 0, beva_cname.bevp_size.bevi_int, "UTF-8");
        BETS_Object ti = be.BECS_Runtime.typeRefs.get(key);
        if (ti != null) {
            bevl_result = ti.bems_createInstance();
        }
        if (bevl_result == null) {
bevt_3_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_3_ta_ph.bevi_bool)/* Line: 155*/ {
if (beva_throwOnFail.bevi_bool)/* Line: 156*/ {
bevt_6_ta_ph = (new BEC_2_4_6_TextString(16, bece_BEC_2_6_7_SystemObjects_bels_1));
bevt_5_ta_ph = bevt_6_ta_ph.bem_add_1(beva_cname);
bevt_4_ta_ph = (new BEC_2_6_9_SystemException()).bem_new_1(bevt_5_ta_ph);
throw new be.BECS_ThrowBack(bevt_4_ta_ph);
} /* Line: 157*/
 else /* Line: 158*/ {
return null;
} /* Line: 159*/
} /* Line: 156*/
bevt_8_ta_ph = (BEC_2_6_11_SystemInitializer) (new BEC_2_6_11_SystemInitializer());
bevt_7_ta_ph = bevt_8_ta_ph.bem_initializeIfShould_1(bevl_result);
return bevt_7_ta_ph;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {34, 59, 59, 63, 90, 94, 94, 94, 98, 98, 99, 99, 99, 101, 155, 155, 157, 157, 157, 157, 159, 162, 162, 162};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {25, 33, 34, 38, 41, 46, 47, 48, 61, 66, 67, 68, 69, 71, 78, 83, 85, 86, 87, 88, 91, 94, 95, 96};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
return 1 34 25
assign 1 59 33
new 0 59 33
return 1 59 34
assign 1 63 38
new 0 63 38
return 1 90 41
assign 1 94 46
new 0 94 46
assign 1 94 47
createInstance 2 94 47
return 1 94 48
assign 1 98 61
undef 1 98 66
assign 1 99 67
new 0 99 67
assign 1 99 68
new 1 99 68
throw 1 99 69
assign 1 101 71
assign 1 155 78
undef 1 155 83
assign 1 157 85
new 0 157 85
assign 1 157 86
add 1 157 86
assign 1 157 87
new 1 157 87
throw 1 157 88
return 1 159 91
assign 1 162 94
new 0 162 94
assign 1 162 95
initializeIfShould 1 162 95
return 1 162 96
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1293470343: return bem_hashGet_0();
case -146244539: return bem_new_0();
case 12637792: return bem_toString_0();
case 1696325472: return bem_copy_0();
case -812914864: return bem_default_0();
case -1485760361: return bem_iteratorGet_0();
case -1120158825: return bem_print_0();
case 13401454: return bem_create_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -611752368: return bem_equals_1(bevd_0);
case -44259182: return bem_def_1(bevd_0);
case -1689645447: return bem_notEquals_1(bevd_0);
case -855732496: return bem_copyTo_1(bevd_0);
case -256538980: return bem_tag_1(bevd_0);
case -580491199: return bem_undef_1(bevd_0);
case -1402891759: return bem_sourceFileName_1(bevd_0);
case -514065660: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1130899650: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1299735066: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -950609307: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -859667978: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 504776993: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 548027945: return bem_sameObject_2(bevd_0, bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(14, becc_BEC_2_6_7_SystemObjects_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(22, becc_BEC_2_6_7_SystemObjects_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_7_SystemObjects();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst = (BEC_2_6_7_SystemObjects) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_7_SystemObjects.bece_BEC_2_6_7_SystemObjects_bevs_type;
}
}
