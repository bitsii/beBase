package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_0 = (new BEC_2_4_3_MathInt(26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_1 = (new BEC_2_4_3_MathInt(65));
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_0_tmpany_phold = bem_getInt_1(bevt_1_tmpany_phold);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
bevt_3_tmpany_phold = (new BEC_2_4_3_MathInt());
bevt_2_tmpany_phold = bem_getInt_1(bevt_3_tmpany_phold);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_2_tmpany_phold = bem_getInt_1(beva_value);
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_absValue_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_modulusValue_1(beva_max);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_tmpany_phold = bem_getString_2(bevt_1_tmpany_phold, beva_size);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_7_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_10_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_11_tmpany_phold = null;
bevt_1_tmpany_phold = beva_str.bem_capacityGet_0();
if (bevt_1_tmpany_phold.bevi_int < beva_size.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 263 */ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 264 */
bevt_2_tmpany_phold = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_tmpany_phold);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 272 */ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_5_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_5_tmpany_phold.bevi_bool) /* Line: 272 */ {
bevt_9_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_0;
bevt_8_tmpany_phold = (BEC_2_4_3_MathInt) bevt_9_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold = bem_getIntMax_2(bevl_value, bevt_8_tmpany_phold);
bevt_11_tmpany_phold = bece_BEC_2_6_6_SystemRandom_bevo_1;
bevt_10_tmpany_phold = (BEC_2_4_3_MathInt) bevt_11_tmpany_phold.bem_once_0();
bevt_7_tmpany_phold.bevi_int += bevt_10_tmpany_phold.bevi_int;
bevt_6_tmpany_phold = bevt_7_tmpany_phold;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_tmpany_phold);
bevl_i.bevi_int++;
} /* Line: 272 */
 else  /* Line: 272 */ {
break;
} /* Line: 272 */
} /* Line: 272 */
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {203, 226, 226, 226, 247, 251, 251, 251, 251, 251, 255, 255, 255, 255, 259, 259, 259, 263, 263, 263, 264, 266, 266, 271, 272, 272, 272, 274, 274, 274, 274, 274, 274, 274, 272, 276};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 34, 35, 36, 41, 48, 49, 50, 51, 52, 58, 59, 60, 61, 66, 67, 68, 85, 86, 91, 92, 94, 95, 96, 97, 100, 105, 106, 107, 108, 109, 110, 111, 113, 114, 120};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 203 23
assign 1 226 34
new 0 226 34
assign 1 226 35
getInt 1 226 35
return 1 226 36
return 1 247 41
assign 1 251 48
new 0 251 48
assign 1 251 49
getInt 1 251 49
assign 1 251 50
absValue 0 251 50
assign 1 251 51
modulusValue 1 251 51
return 1 251 52
assign 1 255 58
getInt 1 255 58
assign 1 255 59
absValue 0 255 59
assign 1 255 60
modulusValue 1 255 60
return 1 255 61
assign 1 259 66
new 1 259 66
assign 1 259 67
getString 2 259 67
return 1 259 68
assign 1 263 85
capacityGet 0 263 85
assign 1 263 86
lesser 1 263 91
capacitySet 1 264 92
assign 1 266 94
copy 0 266 94
sizeSet 1 266 95
assign 1 271 96
new 0 271 96
assign 1 272 97
new 0 272 97
assign 1 272 100
lesser 1 272 105
assign 1 274 106
new 0 274 106
assign 1 274 107
once 0 274 107
assign 1 274 108
getIntMax 2 274 108
assign 1 274 109
new 0 274 109
assign 1 274 110
once 0 274 110
assign 1 274 111
addValue 1 274 111
setIntUnchecked 2 274 113
incrementValue 0 272 114
return 1 276 120
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1207343885: return bem_getInt_0();
case -451287241: return bem_iteratorGet_0();
case 1260713952: return bem_fieldNamesGet_0();
case -512173810: return bem_tagGet_0();
case 166156356: return bem_hashGet_0();
case 1012944178: return bem_create_0();
case -1360047774: return bem_serializeToString_0();
case -1400134931: return bem_seedNow_0();
case -794542805: return bem_fieldIteratorGet_0();
case 1712919396: return bem_serializationIteratorGet_0();
case 1010970574: return bem_deserializeClassNameGet_0();
case 368405588: return bem_echo_0();
case 652618710: return bem_print_0();
case 938978826: return bem_serializeContents_0();
case -131396274: return bem_classNameGet_0();
case 373871049: return bem_copy_0();
case 657440259: return bem_many_0();
case 37115722: return bem_toAny_0();
case 149300560: return bem_sourceFileNameGet_0();
case -1497736169: return bem_new_0();
case 884758076: return bem_toString_0();
case 144782273: return bem_once_0();
case 542819736: return bem_default_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 681441174: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case -1849842647: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 1450913634: return bem_defined_1(bevd_0);
case -2033993347: return bem_sameObject_1(bevd_0);
case 46811792: return bem_otherType_1(bevd_0);
case 2044588239: return bem_otherClass_1(bevd_0);
case 773892154: return bem_sameClass_1(bevd_0);
case 974930963: return bem_undefined_1(bevd_0);
case -926157429: return bem_equals_1(bevd_0);
case -1418198617: return bem_def_1(bevd_0);
case -1434589659: return bem_undef_1(bevd_0);
case 1575018883: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case 121856000: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case 1184632884: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1691038775: return bem_notEquals_1(bevd_0);
case -1340973491: return bem_sameType_1(bevd_0);
case -1952204646: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -442448216: return bem_copyTo_1(bevd_0);
case -675060011: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1842958248: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 498622947: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 1368517810: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -330880231: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -2005454261: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -854312667: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1351268593: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 840782676: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1807714621: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
