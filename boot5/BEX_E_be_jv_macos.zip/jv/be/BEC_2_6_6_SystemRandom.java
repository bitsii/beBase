package be;
/* IO:File: source/base/System.be */
public final class BEC_2_6_6_SystemRandom extends BEC_2_6_6_SystemObject {
public BEC_2_6_6_SystemRandom() { }

   
    public java.security.SecureRandom srand = new java.security.SecureRandom();
    
   private static byte[] becc_BEC_2_6_6_SystemRandom_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x52,0x61,0x6E,0x64,0x6F,0x6D};
private static byte[] becc_BEC_2_6_6_SystemRandom_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_0 = (new BEC_2_4_3_MathInt(26));
private static BEC_2_4_3_MathInt bece_BEC_2_6_6_SystemRandom_bevo_1 = (new BEC_2_4_3_MathInt(65));
public static BEC_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_inst;

public static BET_2_6_6_SystemRandom bece_BEC_2_6_6_SystemRandom_bevs_type;

public BEC_2_6_6_SystemRandom bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_default_0() throws Throwable {
bem_seedNow_0();
return this;
} /*method end*/
public BEC_2_6_6_SystemRandom bem_seedNow_0() throws Throwable {

      srand.setSeed(srand.generateSeed(8));
      return this;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_3_MathInt());
bevt_0_ta_ph = bem_getInt_1(bevt_1_ta_ph);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getInt_1(BEC_2_4_3_MathInt beva_value) throws Throwable {

      beva_value.bevi_int = srand.nextInt();
      return beva_value;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_1(BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
bevt_3_ta_ph = (new BEC_2_4_3_MathInt());
bevt_2_ta_ph = bem_getInt_1(bevt_3_ta_ph);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_3_MathInt bem_getIntMax_2(BEC_2_4_3_MathInt beva_value, BEC_2_4_3_MathInt beva_max) throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
bevt_2_ta_ph = bem_getInt_1(beva_value);
bevt_1_ta_ph = bevt_2_ta_ph.bem_absValue_0();
bevt_0_ta_ph = bevt_1_ta_ph.bem_modulusValue_1(beva_max);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_1(BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_6_TextString bevt_0_ta_ph = null;
BEC_2_4_6_TextString bevt_1_ta_ph = null;
bevt_1_ta_ph = (new BEC_2_4_6_TextString()).bem_new_1(beva_size);
bevt_0_ta_ph = bem_getString_2(bevt_1_ta_ph, beva_size);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_4_6_TextString bem_getString_2(BEC_2_4_6_TextString beva_str, BEC_2_4_3_MathInt beva_size) throws Throwable {
BEC_2_4_3_MathInt bevl_value = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_ta_ph = null;
BEC_2_4_3_MathInt bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_4_3_MathInt bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_4_3_MathInt bevt_10_ta_ph = null;
BEC_2_4_3_MathInt bevt_11_ta_ph = null;
bevt_1_ta_ph = beva_str.bem_capacityGet_0();
if (bevt_1_ta_ph.bevi_int < beva_size.bevi_int) {
bevt_0_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_0_ta_ph.bevi_bool)/* Line: 255*/ {
beva_str.bem_capacitySet_1(beva_size);
} /* Line: 256*/
bevt_2_ta_ph = beva_size.bem_copy_0();
beva_str.bem_sizeSet_1(bevt_2_ta_ph);
bevl_value = (new BEC_2_4_3_MathInt());
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
/* Line: 264*/ {
if (bevl_i.bevi_int < beva_size.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 264*/ {
bevt_9_ta_ph = bece_BEC_2_6_6_SystemRandom_bevo_0;
bevt_8_ta_ph = (BEC_2_4_3_MathInt) bevt_9_ta_ph.bem_once_0();
bevt_7_ta_ph = bem_getIntMax_2(bevl_value, bevt_8_ta_ph);
bevt_11_ta_ph = bece_BEC_2_6_6_SystemRandom_bevo_1;
bevt_10_ta_ph = (BEC_2_4_3_MathInt) bevt_11_ta_ph.bem_once_0();
bevt_7_ta_ph.bevi_int += bevt_10_ta_ph.bevi_int;
bevt_6_ta_ph = bevt_7_ta_ph;
beva_str.bem_setIntUnchecked_2(bevl_i, bevt_6_ta_ph);
bevl_i.bevi_int++;
} /* Line: 264*/
 else /* Line: 264*/ {
break;
} /* Line: 264*/
} /* Line: 264*/
return beva_str;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {180, 208, 208, 208, 239, 243, 243, 243, 243, 243, 247, 247, 247, 247, 251, 251, 251, 255, 255, 255, 256, 258, 258, 263, 264, 264, 264, 266, 266, 266, 266, 266, 266, 266, 264, 268};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {21, 32, 33, 34, 39, 46, 47, 48, 49, 50, 56, 57, 58, 59, 64, 65, 66, 83, 84, 89, 90, 92, 93, 94, 95, 98, 103, 104, 105, 106, 107, 108, 109, 111, 112, 118};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
seedNow 0 180 21
assign 1 208 32
new 0 208 32
assign 1 208 33
getInt 1 208 33
return 1 208 34
return 1 239 39
assign 1 243 46
new 0 243 46
assign 1 243 47
getInt 1 243 47
assign 1 243 48
absValue 0 243 48
assign 1 243 49
modulusValue 1 243 49
return 1 243 50
assign 1 247 56
getInt 1 247 56
assign 1 247 57
absValue 0 247 57
assign 1 247 58
modulusValue 1 247 58
return 1 247 59
assign 1 251 64
new 1 251 64
assign 1 251 65
getString 2 251 65
return 1 251 66
assign 1 255 83
capacityGet 0 255 83
assign 1 255 84
lesser 1 255 89
capacitySet 1 256 90
assign 1 258 92
copy 0 258 92
sizeSet 1 258 93
assign 1 263 94
new 0 263 94
assign 1 264 95
new 0 264 95
assign 1 264 98
lesser 1 264 103
assign 1 266 104
new 0 266 104
assign 1 266 105
once 0 266 105
assign 1 266 106
getIntMax 2 266 106
assign 1 266 107
new 0 266 107
assign 1 266 108
once 0 266 108
assign 1 266 109
addValue 1 266 109
setIntUnchecked 2 266 111
incrementValue 0 264 112
return 1 268 118
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1938521961: return bem_create_0();
case 1428196909: return bem_deserializeClassNameGet_0();
case 1505634064: return bem_fieldNamesGet_0();
case 1469761457: return bem_serializeToString_0();
case -1120775249: return bem_classNameGet_0();
case 1279804529: return bem_getInt_0();
case -559654393: return bem_sourceFileNameGet_0();
case 976077722: return bem_new_0();
case -1359840989: return bem_toAny_0();
case -129765629: return bem_print_0();
case -1677294751: return bem_hashGet_0();
case -1660007365: return bem_iteratorGet_0();
case 126164297: return bem_serializationIteratorGet_0();
case -1640020074: return bem_toString_0();
case 610462413: return bem_seedNow_0();
case -374496050: return bem_tagGet_0();
case -1530492540: return bem_many_0();
case 921209725: return bem_echo_0();
case -1606863806: return bem_fieldIteratorGet_0();
case -1483834827: return bem_copy_0();
case 510046831: return bem_default_0();
case 2028199664: return bem_once_0();
case 1963846645: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 1414981672: return bem_defined_1(bevd_0);
case -996797622: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 485781991: return bem_notEquals_1(bevd_0);
case -1407385206: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1783183294: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 671783933: return bem_sameObject_1(bevd_0);
case 1307641342: return bem_getIntMax_1((BEC_2_4_3_MathInt) bevd_0);
case 64239751: return bem_getString_1((BEC_2_4_3_MathInt) bevd_0);
case -175035347: return bem_undef_1(bevd_0);
case -1891626266: return bem_otherClass_1(bevd_0);
case -522178765: return bem_getInt_1((BEC_2_4_3_MathInt) bevd_0);
case 447224999: return bem_equals_1(bevd_0);
case 1820308428: return bem_undefined_1(bevd_0);
case 1203218404: return bem_sameType_1(bevd_0);
case -1174906644: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -146651973: return bem_sameClass_1(bevd_0);
case -1192518112: return bem_copyTo_1(bevd_0);
case 1090972685: return bem_otherType_1(bevd_0);
case -1789648416: return bem_def_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1034328603: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1508577359: return bem_getString_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1750640793: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -420419227: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1771088647: return bem_getIntMax_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -287855218: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 137991230: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -960162671: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 838948532: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_6_6_SystemRandom_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_6_SystemRandom_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_6_SystemRandom();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst = (BEC_2_6_6_SystemRandom) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_6_SystemRandom.bece_BEC_2_6_6_SystemRandom_bevs_type;
}
}
