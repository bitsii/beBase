package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap extends BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
private static byte[] becc_BEC_2_9_3_ContainerMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_3_ContainerMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_inst;

public static BET_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_type;

public BEC_2_9_3_ContainerMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_slots = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_5_4_LogicBool bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_4_3_MathInt bevt_7_ta_ph = null;
BEC_2_5_4_LogicBool bevt_8_ta_ph = null;
BEC_2_5_4_LogicBool bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_5_4_LogicBool bevt_12_ta_ph = null;
BEC_2_6_6_SystemObject bevt_13_ta_ph = null;
BEC_2_5_4_LogicBool bevt_14_ta_ph = null;
BEC_2_6_6_SystemObject bevt_15_ta_ph = null;
BEC_2_6_6_SystemObject bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_4_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_4_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_4_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 125*/ {
bevt_6_ta_ph = bevl_other.bem_sizeGet_0();
bevt_7_ta_ph = bem_sizeGet_0();
if (bevt_6_ta_ph.bevi_int != bevt_7_ta_ph.bevi_int) {
bevt_5_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_5_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_5_ta_ph.bevi_bool)/* Line: 125*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 125*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 125*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 125*/ {
bevt_8_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_8_ta_ph;
} /* Line: 126*/
bevt_0_ta_loop = bem_mapIteratorGet_0();
while (true)
/* Line: 128*/ {
bevt_9_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_9_ta_ph.bevi_bool)/* Line: 128*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_10_ta_ph = bevl_i.bemd_0(1150391758);
bevl_v = bevl_other.bem_get_1(bevt_10_ta_ph);
if (bevl_v == null) {
bevt_11_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_11_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_11_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 130*/ {
bevt_13_ta_ph = bevl_i.bemd_0(1564044286);
if (bevt_13_ta_ph == null) {
bevt_12_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_12_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_12_ta_ph.bevi_bool)/* Line: 130*/ {
if (bevl_v == null) {
bevt_14_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_14_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_14_ta_ph.bevi_bool)/* Line: 130*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 130*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 130*/
 else /* Line: 130*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 130*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 130*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 130*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 130*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 130*/ {
bevt_16_ta_ph = bevl_i.bemd_0(1564044286);
bevt_15_ta_ph = bevt_16_ta_ph.bemd_1(-19945451, bevl_v);
if (((BEC_2_5_4_LogicBool) bevt_15_ta_ph).bevi_bool)/* Line: 130*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 130*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 130*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 130*/ {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_17_ta_ph;
} /* Line: 130*/
} /* Line: 130*/
 else /* Line: 128*/ {
break;
} /* Line: 128*/
} /* Line: 128*/
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_18_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_v, null, bevp_slots);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(1535864312);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 136*/ {
bevl_slt = bevp_slots;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 139*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(1535864312);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 139*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 140*/
 else /* Line: 139*/ {
break;
} /* Line: 139*/
} /* Line: 139*/
bevp_slots = bevl_slt;
} /* Line: 142*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 144*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 145*/
return this;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_valueIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_5_4_LogicBool bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
BEC_2_6_6_SystemObject bevt_8_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 170*/ {
bevt_2_ta_ph = beva_other.bemd_1(-1935405349, this);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 171*/ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_ta_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
/* Line: 173*/ {
bevt_3_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_3_ta_ph.bevi_bool)/* Line: 173*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_4_ta_ph = bevl_x.bemd_0(1150391758);
bevt_5_ta_ph = bevl_x.bemd_0(1564044286);
bem_put_2(bevt_4_ta_ph, bevt_5_ta_ph);
} /* Line: 174*/
 else /* Line: 173*/ {
break;
} /* Line: 173*/
} /* Line: 173*/
} /* Line: 173*/
 else /* Line: 171*/ {
bevt_6_ta_ph = beva_other.bemd_1(-1935405349, bevp_baseNode);
if (((BEC_2_5_4_LogicBool) bevt_6_ta_ph).bevi_bool)/* Line: 176*/ {
bevt_7_ta_ph = beva_other.bemd_0(1150391758);
bevt_8_ta_ph = beva_other.bemd_0(1564044286);
bem_put_2(bevt_7_ta_ph, bevt_8_ta_ph);
} /* Line: 177*/
 else /* Line: 178*/ {
bem_put_2(beva_other, beva_other);
} /* Line: 179*/
} /* Line: 171*/
} /* Line: 171*/
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_toRet = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_ta_loop = bem_mapIteratorGet_0();
while (true)
/* Line: 186*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 186*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = bevl_x.bemd_0(1150391758);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(-677686019, beva_prefix);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 187*/ {
bevt_4_ta_ph = bevl_x.bemd_0(1150391758);
bevt_5_ta_ph = bevl_x.bemd_0(1564044286);
bevl_toRet.bem_put_2(bevt_4_ta_ph, bevt_5_ta_ph);
} /* Line: 188*/
} /* Line: 187*/
 else /* Line: 186*/ {
break;
} /* Line: 186*/
} /* Line: 186*/
return bevl_toRet;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {107, 107, 111, 112, 113, 114, 115, 116, 120, 120, 124, 125, 125, 0, 125, 125, 125, 125, 0, 0, 126, 126, 128, 0, 128, 128, 129, 129, 130, 130, 0, 130, 130, 130, 130, 130, 0, 0, 0, 0, 0, 0, 130, 130, 0, 0, 130, 130, 132, 132, 136, 136, 137, 138, 139, 139, 140, 142, 145, 150, 150, 154, 154, 158, 158, 162, 162, 166, 166, 170, 170, 171, 172, 173, 0, 173, 173, 174, 174, 174, 176, 177, 177, 177, 179, 185, 186, 0, 186, 186, 187, 187, 188, 188, 188, 191};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23, 28, 29, 54, 55, 60, 61, 64, 65, 66, 71, 72, 75, 79, 80, 82, 82, 85, 87, 88, 89, 90, 95, 96, 99, 100, 105, 106, 111, 112, 115, 119, 122, 125, 129, 132, 133, 135, 138, 142, 143, 150, 151, 159, 160, 162, 163, 166, 167, 169, 175, 178, 184, 185, 189, 190, 194, 195, 199, 200, 204, 205, 219, 224, 225, 227, 228, 228, 231, 233, 234, 235, 236, 244, 246, 247, 248, 251, 266, 267, 267, 270, 272, 273, 274, 276, 277, 278, 285};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 107 13
new 0 107 13
new 1 107 14
assign 1 111 18
new 1 111 18
assign 1 112 19
assign 1 113 20
new 0 113 20
assign 1 114 21
new 0 114 21
assign 1 115 22
new 0 115 22
assign 1 116 23
new 0 116 23
assign 1 120 28
new 1 120 28
return 1 120 29
assign 1 124 54
assign 1 125 55
undef 1 125 60
assign 1 0 61
assign 1 125 64
sizeGet 0 125 64
assign 1 125 65
sizeGet 0 125 65
assign 1 125 66
notEquals 1 125 71
assign 1 0 72
assign 1 0 75
assign 1 126 79
new 0 126 79
return 1 126 80
assign 1 128 82
mapIteratorGet 0 0 82
assign 1 128 85
hasNextGet 0 128 85
assign 1 128 87
nextGet 0 128 87
assign 1 129 88
keyGet 0 129 88
assign 1 129 89
get 1 129 89
assign 1 130 90
undef 1 130 95
assign 1 0 96
assign 1 130 99
valueGet 0 130 99
assign 1 130 100
undef 1 130 105
assign 1 130 106
def 1 130 111
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 0 122
assign 1 0 125
assign 1 0 129
assign 1 130 132
valueGet 0 130 132
assign 1 130 133
notEquals 1 130 133
assign 1 0 135
assign 1 0 138
assign 1 130 142
new 0 130 142
return 1 130 143
assign 1 132 150
new 0 132 150
return 1 132 151
assign 1 136 159
innerPut 4 136 159
assign 1 136 160
not 0 136 160
assign 1 137 162
assign 1 138 163
rehash 1 138 163
assign 1 139 166
innerPut 4 139 166
assign 1 139 167
not 0 139 167
assign 1 140 169
rehash 1 140 169
assign 1 142 175
assign 1 145 178
increment 0 145 178
assign 1 150 184
new 1 150 184
return 1 150 185
assign 1 154 189
valueIteratorGet 0 154 189
return 1 154 190
assign 1 158 194
new 1 158 194
return 1 158 195
assign 1 162 199
new 1 162 199
return 1 162 200
assign 1 166 204
new 1 166 204
return 1 166 205
assign 1 170 219
def 1 170 224
assign 1 171 225
sameType 1 171 225
assign 1 172 227
assign 1 173 228
mapIteratorGet 0 0 228
assign 1 173 231
hasNextGet 0 173 231
assign 1 173 233
nextGet 0 173 233
assign 1 174 234
keyGet 0 174 234
assign 1 174 235
valueGet 0 174 235
put 2 174 236
assign 1 176 244
sameType 1 176 244
assign 1 177 246
keyGet 0 177 246
assign 1 177 247
valueGet 0 177 247
put 2 177 248
put 2 179 251
assign 1 185 266
new 0 185 266
assign 1 186 267
mapIteratorGet 0 0 267
assign 1 186 270
hasNextGet 0 186 270
assign 1 186 272
nextGet 0 186 272
assign 1 187 273
keyGet 0 187 273
assign 1 187 274
begins 1 187 274
assign 1 188 276
keyGet 0 188 276
assign 1 188 277
valueGet 0 188 277
put 2 188 278
return 1 191 285
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1548685325: return bem_clear_0();
case 1610541665: return bem_relGetDirect_0();
case -676070096: return bem_sourceFileNameGet_0();
case 929997732: return bem_baseNodeGet_0();
case 37637962: return bem_print_0();
case 280816028: return bem_innerPutAddedGetDirect_0();
case -1224570985: return bem_sizeGetDirect_0();
case 186375980: return bem_valueIteratorGet_0();
case 340030523: return bem_classNameGet_0();
case -30316716: return bem_slotsGet_0();
case 724814094: return bem_keyIteratorGet_0();
case 1504440865: return bem_isEmptyGet_0();
case 1560923203: return bem_nodeIteratorGet_0();
case 1179961651: return bem_serializeToString_0();
case -1310235109: return bem_valuesGet_0();
case 1333799692: return bem_tagGet_0();
case 219112807: return bem_toString_0();
case -1886412145: return bem_innerPutAddedGet_0();
case -1349847811: return bem_multiGet_0();
case 1006567093: return bem_notEmptyGet_0();
case 2094947115: return bem_setIteratorGet_0();
case 1807619686: return bem_nodesGet_0();
case -1001743190: return bem_fieldNamesGet_0();
case -172419312: return bem_keysGet_0();
case -794062933: return bem_hashGet_0();
case -909436054: return bem_relGet_0();
case -800146552: return bem_serializeContents_0();
case 1577124637: return bem_deserializeClassNameGet_0();
case -794718926: return bem_copy_0();
case 37495128: return bem_keyValueIteratorGet_0();
case -1263154564: return bem_new_0();
case 173330374: return bem_sizeGet_0();
case -455009051: return bem_slotsGetDirect_0();
case -2095499202: return bem_fieldIteratorGet_0();
case -1225581584: return bem_moduGetDirect_0();
case -1935527841: return bem_moduGet_0();
case 1546143657: return bem_echo_0();
case 1445801145: return bem_serializationIteratorGet_0();
case 147497190: return bem_iteratorGet_0();
case 1615402015: return bem_create_0();
case -600238840: return bem_multiGetDirect_0();
case -1311515776: return bem_mapIteratorGet_0();
case -1560893675: return bem_baseNodeGetDirect_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 550061094: return bem_undef_1(bevd_0);
case -1800691088: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case -2064182848: return bem_baseNodeSet_1(bevd_0);
case -408068263: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1405755430: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 1251338233: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -1921789302: return bem_sizeSetDirect_1(bevd_0);
case -1463025079: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1900765566: return bem_relSetDirect_1(bevd_0);
case -1534545800: return bem_otherType_1(bevd_0);
case 1429959182: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1935405349: return bem_sameType_1(bevd_0);
case -1868129616: return bem_copyTo_1(bevd_0);
case -611685396: return bem_innerPutAddedSet_1(bevd_0);
case -1007539777: return bem_addValue_1(bevd_0);
case -1863474956: return bem_baseNodeSetDirect_1(bevd_0);
case -1437837195: return bem_sizeSet_1(bevd_0);
case -19945451: return bem_notEquals_1(bevd_0);
case -428656616: return bem_multiSet_1(bevd_0);
case 739117568: return bem_otherClass_1(bevd_0);
case 73368160: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case 506888508: return bem_get_1(bevd_0);
case 176399872: return bem_slotsSet_1(bevd_0);
case -2022815028: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case 1661150226: return bem_def_1(bevd_0);
case 2060848098: return bem_moduSetDirect_1(bevd_0);
case 34451743: return bem_has_1(bevd_0);
case 1453176062: return bem_delete_1(bevd_0);
case 1038080348: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1419064041: return bem_sameObject_1(bevd_0);
case 1030894563: return bem_moduSet_1(bevd_0);
case 250302014: return bem_equals_1(bevd_0);
case -422271543: return bem_slotsSetDirect_1(bevd_0);
case 126112686: return bem_relSet_1(bevd_0);
case 1981346500: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 2044993814: return bem_sameClass_1(bevd_0);
case 706527892: return bem_put_1(bevd_0);
case -1022630982: return bem_innerPutAddedSetDirect_1(bevd_0);
case -1056887408: return bem_multiSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -1172242478: return bem_put_2(bevd_0, bevd_1);
case -938540681: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1098115031: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1738406137: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1708873965: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 853768892: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -2112740717: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -420194261: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst = (BEC_2_9_3_ContainerMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_type;
}
}
