package be;
/* IO:File: source/base/Map.be */
public class BEC_2_9_3_ContainerMap extends BEC_2_9_3_ContainerSet {
public BEC_2_9_3_ContainerMap() { }
private static byte[] becc_BEC_2_9_3_ContainerMap_clname = {0x43,0x6F,0x6E,0x74,0x61,0x69,0x6E,0x65,0x72,0x3A,0x4D,0x61,0x70};
private static byte[] becc_BEC_2_9_3_ContainerMap_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x4D,0x61,0x70,0x2E,0x62,0x65};
public static BEC_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_inst;

public static BET_2_9_3_ContainerMap bece_BEC_2_9_3_ContainerMap_bevs_type;

public BEC_2_9_3_ContainerMap bem_new_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_2_4_3_MathInt(11));
bem_new_1(bevt_0_ta_ph);
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_new_1(BEC_2_4_3_MathInt beva__modu) throws Throwable {
bevp_buckets = (new BEC_2_9_4_ContainerList()).bem_new_1(beva__modu);
bevp_modu = beva__modu;
bevp_multi = (new BEC_2_4_3_MathInt(2));
bevp_rel = (BEC_3_9_3_9_ContainerSetRelations) BEC_3_9_3_9_ContainerSetRelations.bece_BEC_3_9_3_9_ContainerSetRelations_bevs_inst;
bevp_baseNode = (BEC_3_9_3_7_ContainerSetSetNode) (new BEC_3_9_3_7_ContainerMapMapNode());
bevp_size = (new BEC_2_4_3_MathInt(0));
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_serializationIteratorGet_0() throws Throwable {
BEC_3_9_3_21_ContainerMapSerializationIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_21_ContainerMapSerializationIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_5_4_LogicBool bem_contentsEqual_1(BEC_2_9_3_ContainerSet beva__other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_other = null;
BEC_2_6_6_SystemObject bevl_i = null;
BEC_2_6_6_SystemObject bevl_v = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_2_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_3_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_4_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_5_ta_anchor = null;
BEC_2_5_4_LogicBool bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_4_3_MathInt bevt_8_ta_ph = null;
BEC_2_4_3_MathInt bevt_9_ta_ph = null;
BEC_2_5_4_LogicBool bevt_10_ta_ph = null;
BEC_2_5_4_LogicBool bevt_11_ta_ph = null;
BEC_2_6_6_SystemObject bevt_12_ta_ph = null;
BEC_2_5_4_LogicBool bevt_13_ta_ph = null;
BEC_2_6_6_SystemObject bevt_14_ta_ph = null;
BEC_2_5_4_LogicBool bevt_15_ta_ph = null;
BEC_2_5_4_LogicBool bevt_16_ta_ph = null;
BEC_2_5_4_LogicBool bevt_17_ta_ph = null;
BEC_2_5_4_LogicBool bevt_18_ta_ph = null;
BEC_2_6_6_SystemObject bevt_19_ta_ph = null;
BEC_2_5_4_LogicBool bevt_20_ta_ph = null;
BEC_2_5_4_LogicBool bevt_21_ta_ph = null;
BEC_2_5_4_LogicBool bevt_22_ta_ph = null;
BEC_2_6_6_SystemObject bevt_23_ta_ph = null;
BEC_2_6_6_SystemObject bevt_24_ta_ph = null;
BEC_2_6_6_SystemObject bevt_25_ta_ph = null;
BEC_2_5_4_LogicBool bevt_26_ta_ph = null;
BEC_2_5_4_LogicBool bevt_27_ta_ph = null;
bevl_other = (BEC_2_9_3_ContainerMap) beva__other;
if (bevl_other == null) {
bevt_6_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_6_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_6_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
bevt_8_ta_ph = bevl_other.bem_sizeGet_0();
bevt_9_ta_ph = bem_sizeGet_0();
if (bevt_8_ta_ph.bevi_int != bevt_9_ta_ph.bevi_int) {
bevt_7_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_7_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_7_ta_ph.bevi_bool)/* Line: 94*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 94*/ {
bevt_1_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 94*/
if (bevt_1_ta_anchor.bevi_bool)/* Line: 94*/ {
bevt_10_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_10_ta_ph;
} /* Line: 95*/
bevt_0_ta_loop = bem_mapIteratorGet_0();
while (true)
/* Line: 97*/ {
bevt_11_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_11_ta_ph.bevi_bool)/* Line: 97*/ {
bevl_i = bevt_0_ta_loop.bem_nextGet_0();
bevt_12_ta_ph = bevl_i.bemd_0(-841181340);
bevl_v = bevl_other.bem_get_1(bevt_12_ta_ph);
bevt_14_ta_ph = bevl_i.bemd_0(935447025);
if (bevt_14_ta_ph == null) {
bevt_13_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_13_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_13_ta_ph.bevi_bool)/* Line: 99*/ {
if (bevl_v == null) {
bevt_15_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_15_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_15_ta_ph.bevi_bool)/* Line: 99*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 99*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 99*/
 else /* Line: 99*/ {
bevt_2_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_2_ta_anchor.bevi_bool)/* Line: 99*/ {
bevt_16_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_16_ta_ph;
} /* Line: 99*/
if (bevl_v == null) {
bevt_17_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_17_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_17_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_19_ta_ph = bevl_i.bemd_0(935447025);
if (bevt_19_ta_ph == null) {
bevt_18_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_18_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_18_ta_ph.bevi_bool)/* Line: 100*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 100*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 100*/
 else /* Line: 100*/ {
bevt_3_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_3_ta_anchor.bevi_bool)/* Line: 100*/ {
bevt_20_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_20_ta_ph;
} /* Line: 100*/
if (bevl_v == null) {
bevt_21_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_21_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_21_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_23_ta_ph = bevl_i.bemd_0(935447025);
if (bevt_23_ta_ph == null) {
bevt_22_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_22_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_22_ta_ph.bevi_bool)/* Line: 101*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
 else /* Line: 101*/ {
bevt_5_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_5_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_25_ta_ph = bevl_i.bemd_0(935447025);
bevt_24_ta_ph = bevt_25_ta_ph.bemd_1(1616842678, bevl_v);
if (((BEC_2_5_4_LogicBool) bevt_24_ta_ph).bevi_bool)/* Line: 101*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0*/
 else /* Line: 101*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
} /* Line: 101*/
 else /* Line: 101*/ {
bevt_4_ta_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0*/
if (bevt_4_ta_anchor.bevi_bool)/* Line: 101*/ {
bevt_26_ta_ph = be.BECS_Runtime.boolFalse;
return bevt_26_ta_ph;
} /* Line: 101*/
} /* Line: 101*/
 else /* Line: 97*/ {
break;
} /* Line: 97*/
} /* Line: 97*/
bevt_27_ta_ph = be.BECS_Runtime.boolTrue;
return bevt_27_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_put_2(BEC_2_6_6_SystemObject beva_k, BEC_2_6_6_SystemObject beva_v) throws Throwable {
BEC_2_9_4_ContainerList bevl_slt = null;
BEC_2_6_6_SystemObject bevt_0_ta_ph = null;
BEC_2_6_6_SystemObject bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
bevt_1_ta_ph = bem_innerPut_4(beva_k, beva_v, null, bevp_buckets);
bevt_0_ta_ph = bevt_1_ta_ph.bemd_0(-1011585462);
if (((BEC_2_5_4_LogicBool) bevt_0_ta_ph).bevi_bool)/* Line: 107*/ {
bevl_slt = bevp_buckets;
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
while (true)
/* Line: 110*/ {
bevt_3_ta_ph = bem_innerPut_4(beva_k, beva_v, null, bevl_slt);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_0(-1011585462);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 110*/ {
bevl_slt = (BEC_2_9_4_ContainerList) bem_rehash_1(bevl_slt);
} /* Line: 111*/
 else /* Line: 110*/ {
break;
} /* Line: 110*/
} /* Line: 110*/
bevp_buckets = bevl_slt;
} /* Line: 113*/
if (bevp_innerPutAdded.bevi_bool)/* Line: 115*/ {
bevp_size = bevp_size.bem_increment_0();
} /* Line: 116*/
return this;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valueIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_13_ContainerMapValueIterator()).bem_new_1(this);
return (BEC_3_9_3_13_ContainerMapValueIterator) bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_13_ContainerMapValueIterator bem_valuesGet_0() throws Throwable {
BEC_3_9_3_13_ContainerMapValueIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = bem_valueIteratorGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_16_ContainerMapKeyValueIterator bem_keyValueIteratorGet_0() throws Throwable {
BEC_3_9_3_16_ContainerMapKeyValueIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_16_ContainerMapKeyValueIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_6_6_SystemObject bem_iteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_9_3_12_ContainerSetNodeIterator bem_mapIteratorGet_0() throws Throwable {
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_ph = null;
bevt_0_ta_ph = (new BEC_3_9_3_12_ContainerSetNodeIterator()).bem_new_1(this);
return bevt_0_ta_ph;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_addValue_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_3_ContainerMap bevl_otherMap = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_5_4_LogicBool bevt_2_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_3_ta_ph = null;
BEC_2_5_4_LogicBool bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_6_6_SystemObject bevt_6_ta_ph = null;
BEC_2_5_4_LogicBool bevt_7_ta_ph = null;
BEC_2_6_5_SystemTypes bevt_8_ta_ph = null;
BEC_2_6_6_SystemObject bevt_9_ta_ph = null;
BEC_2_6_6_SystemObject bevt_10_ta_ph = null;
if (beva_other == null) {
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 141*/ {
bevt_3_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_2_ta_ph = bevt_3_ta_ph.bem_sameType_2(beva_other, this);
if (bevt_2_ta_ph.bevi_bool)/* Line: 142*/ {
bevl_otherMap = (BEC_2_9_3_ContainerMap) beva_other;
bevt_0_ta_loop = bevl_otherMap.bem_mapIteratorGet_0();
while (true)
/* Line: 144*/ {
bevt_4_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_4_ta_ph.bevi_bool)/* Line: 144*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_5_ta_ph = bevl_x.bemd_0(-841181340);
bevt_6_ta_ph = bevl_x.bemd_0(935447025);
bem_put_2(bevt_5_ta_ph, bevt_6_ta_ph);
} /* Line: 145*/
 else /* Line: 144*/ {
break;
} /* Line: 144*/
} /* Line: 144*/
} /* Line: 144*/
 else /* Line: 142*/ {
bevt_8_ta_ph = (BEC_2_6_5_SystemTypes) BEC_2_6_5_SystemTypes.bece_BEC_2_6_5_SystemTypes_bevs_inst;
bevt_7_ta_ph = bevt_8_ta_ph.bem_sameType_2(beva_other, bevp_baseNode);
if (bevt_7_ta_ph.bevi_bool)/* Line: 147*/ {
bevt_9_ta_ph = beva_other.bemd_0(-841181340);
bevt_10_ta_ph = beva_other.bemd_0(935447025);
bem_put_2(bevt_9_ta_ph, bevt_10_ta_ph);
} /* Line: 148*/
 else /* Line: 149*/ {
bem_put_2(beva_other, beva_other);
} /* Line: 150*/
} /* Line: 142*/
} /* Line: 142*/
return this;
} /*method end*/
public BEC_2_9_3_ContainerMap bem_getMap_1(BEC_2_4_6_TextString beva_prefix) throws Throwable {
BEC_2_9_3_ContainerMap bevl_toRet = null;
BEC_2_6_6_SystemObject bevl_x = null;
BEC_3_9_3_12_ContainerSetNodeIterator bevt_0_ta_loop = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_6_6_SystemObject bevt_2_ta_ph = null;
BEC_2_6_6_SystemObject bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
bevl_toRet = (new BEC_2_9_3_ContainerMap()).bem_new_0();
bevt_0_ta_loop = bem_mapIteratorGet_0();
while (true)
/* Line: 157*/ {
bevt_1_ta_ph = bevt_0_ta_loop.bem_hasNextGet_0();
if (bevt_1_ta_ph.bevi_bool)/* Line: 157*/ {
bevl_x = bevt_0_ta_loop.bem_nextGet_0();
bevt_3_ta_ph = bevl_x.bemd_0(-841181340);
bevt_2_ta_ph = bevt_3_ta_ph.bemd_1(254925847, beva_prefix);
if (((BEC_2_5_4_LogicBool) bevt_2_ta_ph).bevi_bool)/* Line: 158*/ {
bevt_4_ta_ph = bevl_x.bemd_0(-841181340);
bevt_5_ta_ph = bevl_x.bemd_0(935447025);
bevl_toRet.bem_put_2(bevt_4_ta_ph, bevt_5_ta_ph);
} /* Line: 159*/
} /* Line: 158*/
 else /* Line: 157*/ {
break;
} /* Line: 157*/
} /* Line: 157*/
return bevl_toRet;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {76, 76, 80, 81, 82, 83, 84, 85, 89, 89, 93, 94, 94, 0, 94, 94, 94, 94, 0, 0, 95, 95, 97, 0, 97, 97, 98, 98, 99, 99, 99, 99, 99, 0, 0, 0, 99, 99, 100, 100, 100, 100, 100, 0, 0, 0, 100, 100, 101, 101, 101, 101, 101, 0, 0, 0, 101, 101, 0, 0, 0, 101, 101, 103, 103, 107, 107, 108, 109, 110, 110, 111, 113, 116, 121, 121, 125, 125, 129, 129, 133, 133, 137, 137, 141, 141, 142, 142, 143, 144, 0, 144, 144, 145, 145, 145, 147, 147, 148, 148, 148, 150, 156, 157, 0, 157, 157, 158, 158, 159, 159, 159, 162};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {13, 14, 18, 19, 20, 21, 22, 23, 28, 29, 63, 64, 69, 70, 73, 74, 75, 80, 81, 84, 88, 89, 91, 91, 94, 96, 97, 98, 99, 100, 105, 106, 111, 112, 115, 119, 122, 123, 125, 130, 131, 132, 137, 138, 141, 145, 148, 149, 151, 156, 157, 158, 163, 164, 167, 171, 174, 175, 177, 180, 184, 187, 188, 195, 196, 204, 205, 207, 208, 211, 212, 214, 220, 223, 229, 230, 234, 235, 239, 240, 244, 245, 249, 250, 266, 271, 272, 273, 275, 276, 276, 279, 281, 282, 283, 284, 292, 293, 295, 296, 297, 300, 315, 316, 316, 319, 321, 322, 323, 325, 326, 327, 334};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 76 13
new 0 76 13
new 1 76 14
assign 1 80 18
new 1 80 18
assign 1 81 19
assign 1 82 20
new 0 82 20
assign 1 83 21
new 0 83 21
assign 1 84 22
new 0 84 22
assign 1 85 23
new 0 85 23
assign 1 89 28
new 1 89 28
return 1 89 29
assign 1 93 63
assign 1 94 64
undef 1 94 69
assign 1 0 70
assign 1 94 73
sizeGet 0 94 73
assign 1 94 74
sizeGet 0 94 74
assign 1 94 75
notEquals 1 94 80
assign 1 0 81
assign 1 0 84
assign 1 95 88
new 0 95 88
return 1 95 89
assign 1 97 91
mapIteratorGet 0 0 91
assign 1 97 94
hasNextGet 0 97 94
assign 1 97 96
nextGet 0 97 96
assign 1 98 97
keyGet 0 98 97
assign 1 98 98
get 1 98 98
assign 1 99 99
valueGet 0 99 99
assign 1 99 100
def 1 99 105
assign 1 99 106
undef 1 99 111
assign 1 0 112
assign 1 0 115
assign 1 0 119
assign 1 99 122
new 0 99 122
return 1 99 123
assign 1 100 125
def 1 100 130
assign 1 100 131
valueGet 0 100 131
assign 1 100 132
undef 1 100 137
assign 1 0 138
assign 1 0 141
assign 1 0 145
assign 1 100 148
new 0 100 148
return 1 100 149
assign 1 101 151
def 1 101 156
assign 1 101 157
valueGet 0 101 157
assign 1 101 158
def 1 101 163
assign 1 0 164
assign 1 0 167
assign 1 0 171
assign 1 101 174
valueGet 0 101 174
assign 1 101 175
notEquals 1 101 175
assign 1 0 177
assign 1 0 180
assign 1 0 184
assign 1 101 187
new 0 101 187
return 1 101 188
assign 1 103 195
new 0 103 195
return 1 103 196
assign 1 107 204
innerPut 4 107 204
assign 1 107 205
not 0 107 205
assign 1 108 207
assign 1 109 208
rehash 1 109 208
assign 1 110 211
innerPut 4 110 211
assign 1 110 212
not 0 110 212
assign 1 111 214
rehash 1 111 214
assign 1 113 220
assign 1 116 223
increment 0 116 223
assign 1 121 229
new 1 121 229
return 1 121 230
assign 1 125 234
valueIteratorGet 0 125 234
return 1 125 235
assign 1 129 239
new 1 129 239
return 1 129 240
assign 1 133 244
new 1 133 244
return 1 133 245
assign 1 137 249
new 1 137 249
return 1 137 250
assign 1 141 266
def 1 141 271
assign 1 142 272
new 0 142 272
assign 1 142 273
sameType 2 142 273
assign 1 143 275
assign 1 144 276
mapIteratorGet 0 0 276
assign 1 144 279
hasNextGet 0 144 279
assign 1 144 281
nextGet 0 144 281
assign 1 145 282
keyGet 0 145 282
assign 1 145 283
valueGet 0 145 283
put 2 145 284
assign 1 147 292
new 0 147 292
assign 1 147 293
sameType 2 147 293
assign 1 148 295
keyGet 0 148 295
assign 1 148 296
valueGet 0 148 296
put 2 148 297
put 2 150 300
assign 1 156 315
new 0 156 315
assign 1 157 316
mapIteratorGet 0 0 316
assign 1 157 319
hasNextGet 0 157 319
assign 1 157 321
nextGet 0 157 321
assign 1 158 322
keyGet 0 158 322
assign 1 158 323
begins 1 158 323
assign 1 159 325
keyGet 0 159 325
assign 1 159 326
valueGet 0 159 326
put 2 159 327
return 1 162 334
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -1024520658: return bem_bucketsGet_0();
case 1346975792: return bem_serializationIteratorGet_0();
case -252595038: return bem_keyValueIteratorGet_0();
case -1376188355: return bem_toString_0();
case -979097377: return bem_isEmptyGet_0();
case 1617519785: return bem_copy_0();
case -1697984785: return bem_setIteratorGet_0();
case -84725804: return bem_keyIteratorGet_0();
case 1583441790: return bem_nodeIteratorGet_0();
case -1654535088: return bem_valuesGet_0();
case -1300294592: return bem_new_0();
case -984604226: return bem_hashGet_0();
case -147411705: return bem_sizeGet_0();
case 1169462679: return bem_nodesGet_0();
case 1447137806: return bem_keysGet_0();
case 30862756: return bem_iteratorGet_0();
case -1606682728: return bem_print_0();
case -2079257428: return bem_clear_0();
case -159755629: return bem_valueIteratorGet_0();
case -219492711: return bem_create_0();
case -1551605768: return bem_serializeToString_0();
case -974536420: return bem_mapIteratorGet_0();
case -668548309: return bem_notEmptyGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -391686990: return bem_contentsEqual_1((BEC_2_9_3_ContainerSet) bevd_0);
case 410822050: return bem_getMap_1((BEC_2_4_6_TextString) bevd_0);
case -682509732: return bem_bucketsSet_1(bevd_0);
case -904863977: return bem_union_1((BEC_2_9_3_ContainerSet) bevd_0);
case 1616842678: return bem_notEquals_1(bevd_0);
case 1368875362: return bem_new_1((BEC_2_4_3_MathInt) bevd_0);
case 2047077538: return bem_put_1(bevd_0);
case -374330083: return bem_delete_1(bevd_0);
case 1950249653: return bem_get_1(bevd_0);
case -1960694773: return bem_rehash_1((BEC_2_9_4_ContainerList) bevd_0);
case -382459987: return bem_undef_1(bevd_0);
case 1558619634: return bem_intersection_1((BEC_2_9_3_ContainerSet) bevd_0);
case -1806891978: return bem_has_1(bevd_0);
case 717777871: return bem_addValue_1(bevd_0);
case -1104436681: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case -1920624455: return bem_add_1((BEC_2_9_3_ContainerSet) bevd_0);
case 144428460: return bem_equals_1(bevd_0);
case 25126761: return bem_def_1(bevd_0);
case 1634599038: return bem_copyTo_1(bevd_0);
case 1170997529: return bem_sizeSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 120651597: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1708823140: return bem_insertAll_2((BEC_2_9_4_ContainerList) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -159239392: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 845289889: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -353260694: return bem_put_2(bevd_0, bevd_1);
case -1813958638: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_6_6_SystemObject bemd_4(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1, BEC_2_6_6_SystemObject bevd_2, BEC_2_6_6_SystemObject bevd_3) throws Throwable {
switch (callId) {
case -1641555410: return bem_innerPut_4(bevd_0, bevd_1, bevd_2, (BEC_2_9_4_ContainerList) bevd_3);
}
return super.bemd_4(callId, bevd_0, bevd_1, bevd_2, bevd_3);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(13, becc_BEC_2_9_3_ContainerMap_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(18, becc_BEC_2_9_3_ContainerMap_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_9_3_ContainerMap();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst = (BEC_2_9_3_ContainerMap) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_9_3_ContainerMap.bece_BEC_2_9_3_ContainerMap_bevs_type;
}
}
