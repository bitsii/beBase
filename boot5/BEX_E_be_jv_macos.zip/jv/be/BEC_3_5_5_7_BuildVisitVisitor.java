package be;
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor extends BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;

public static BET_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;

public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevt_0_ta_ph = null;
bevt_0_ta_ph = beva_node.bem_nextDescendGet_0();
return bevt_0_ta_ph;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_transGet_0() throws Throwable {
return bevp_trans;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constGet_0() throws Throwable {
return bevp_const;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_ta_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {20, 21, 22, 23, 28, 28, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 24, 25, 31, 34, 38, 41, 45, 48, 52, 55};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 20 16
assign 1 21 17
buildGet 0 21 17
assign 1 22 18
constantsGet 0 22 18
assign 1 23 19
ntypesGet 0 23 19
assign 1 28 24
nextDescendGet 0 28 24
return 1 28 25
return 1 0 31
assign 1 0 34
return 1 0 38
assign 1 0 41
return 1 0 45
assign 1 0 48
return 1 0 52
assign 1 0 55
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -219220521: return bem_print_0();
case 1883566187: return bem_create_0();
case 1999202416: return bem_transGet_0();
case -2014043122: return bem_hashGet_0();
case 312077991: return bem_copy_0();
case -78475593: return bem_buildGet_0();
case -1864159119: return bem_toString_0();
case -1682692137: return bem_constGet_0();
case 879598193: return bem_ntypesGet_0();
case 1603058826: return bem_iteratorGet_0();
case 1552604533: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1474886087: return bem_equals_1(bevd_0);
case -875957138: return bem_transSet_1(bevd_0);
case 1342301914: return bem_undef_1(bevd_0);
case -492633247: return bem_begin_1(bevd_0);
case 647518055: return bem_def_1(bevd_0);
case -770818924: return bem_end_1(bevd_0);
case -1547701265: return bem_notEquals_1(bevd_0);
case -918433075: return bem_buildSet_1(bevd_0);
case -301773157: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -1373106803: return bem_print_1(bevd_0);
case 648644612: return bem_copyTo_1(bevd_0);
case 2137303145: return bem_constSet_1(bevd_0);
case -404093853: return bem_ntypesSet_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -827585189: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -1135235556: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -654018121: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 281117957: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;
}
}
