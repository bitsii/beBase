package be;
/* IO:File: source/build/Visitor.be */
public class BEC_3_5_5_7_BuildVisitVisitor extends BEC_2_6_6_SystemObject {
public BEC_3_5_5_7_BuildVisitVisitor() { }
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clname = {0x42,0x75,0x69,0x6C,0x64,0x3A,0x56,0x69,0x73,0x69,0x74,0x3A,0x56,0x69,0x73,0x69,0x74,0x6F,0x72};
private static byte[] becc_BEC_3_5_5_7_BuildVisitVisitor_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x75,0x69,0x6C,0x64,0x2F,0x56,0x69,0x73,0x69,0x74,0x6F,0x72,0x2E,0x62,0x65};
public static BEC_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;

public static BET_3_5_5_7_BuildVisitVisitor bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;

public BEC_2_5_9_BuildTransport bevp_trans;
public BEC_2_5_5_BuildBuild bevp_build;
public BEC_2_5_9_BuildConstants bevp_const;
public BEC_2_5_9_BuildNodeTypes bevp_ntypes;
public BEC_3_5_5_7_BuildVisitVisitor bem_begin_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) beva_transi;
bevp_build = bevp_trans.bem_buildGet_0();
bevp_const = bevp_build.bem_constantsGet_0();
bevp_ntypes = bevp_const.bem_ntypesGet_0();
return this;
} /*method end*/
public BEC_2_5_4_BuildNode bem_accept_1(BEC_2_5_4_BuildNode beva_node) throws Throwable {
BEC_2_5_4_BuildNode bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = beva_node.bem_nextDescendGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_end_1(BEC_2_6_6_SystemObject beva_transi) throws Throwable {
return this;
} /*method end*/
public BEC_2_5_9_BuildTransport bem_transGet_0() throws Throwable {
return bevp_trans;
} /*method end*/
public final BEC_2_5_9_BuildTransport bem_transGetDirect_0() throws Throwable {
return bevp_trans;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_transSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_7_BuildVisitVisitor bem_transSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_trans = (BEC_2_5_9_BuildTransport) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_5_BuildBuild bem_buildGet_0() throws Throwable {
return bevp_build;
} /*method end*/
public final BEC_2_5_5_BuildBuild bem_buildGetDirect_0() throws Throwable {
return bevp_build;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_buildSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_7_BuildVisitVisitor bem_buildSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_build = (BEC_2_5_5_BuildBuild) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildConstants bem_constGet_0() throws Throwable {
return bevp_const;
} /*method end*/
public final BEC_2_5_9_BuildConstants bem_constGetDirect_0() throws Throwable {
return bevp_const;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_constSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_7_BuildVisitVisitor bem_constSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_const = (BEC_2_5_9_BuildConstants) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_5_9_BuildNodeTypes bem_ntypesGet_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public final BEC_2_5_9_BuildNodeTypes bem_ntypesGetDirect_0() throws Throwable {
return bevp_ntypes;
} /*method end*/
public BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_3_5_5_7_BuildVisitVisitor bem_ntypesSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_ntypes = (BEC_2_5_9_BuildNodeTypes) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {15, 16, 17, 18, 23, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {16, 17, 18, 19, 24, 25, 31, 34, 37, 41, 45, 48, 51, 55, 59, 62, 65, 69, 73, 76, 79, 83};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 15 16
assign 1 16 17
buildGet 0 16 17
assign 1 17 18
constantsGet 0 17 18
assign 1 18 19
ntypesGet 0 18 19
assign 1 23 24
nextDescendGet 0 23 24
return 1 23 25
return 1 0 31
return 1 0 34
assign 1 0 37
assign 1 0 41
return 1 0 45
return 1 0 48
assign 1 0 51
assign 1 0 55
return 1 0 59
return 1 0 62
assign 1 0 65
assign 1 0 69
return 1 0 73
return 1 0 76
assign 1 0 79
assign 1 0 83
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case -907702096: return bem_once_0();
case 1159622845: return bem_echo_0();
case 2072217533: return bem_constGetDirect_0();
case -649199060: return bem_serializeContents_0();
case 1294757574: return bem_tagGet_0();
case 1097464934: return bem_print_0();
case -730552231: return bem_fieldIteratorGet_0();
case 1521004371: return bem_copy_0();
case -2010885181: return bem_many_0();
case 268640521: return bem_hashGet_0();
case -2060917023: return bem_classNameGet_0();
case -843126344: return bem_serializationIteratorGet_0();
case 84009197: return bem_deserializeClassNameGet_0();
case 1377735259: return bem_transGetDirect_0();
case 48884000: return bem_buildGet_0();
case -1196401912: return bem_buildGetDirect_0();
case 1234776985: return bem_constGet_0();
case -1333696208: return bem_toString_0();
case 831513957: return bem_iteratorGet_0();
case 1523724038: return bem_sourceFileNameGet_0();
case 885128203: return bem_create_0();
case -949791836: return bem_ntypesGetDirect_0();
case -1413337062: return bem_transGet_0();
case 2057652625: return bem_fieldNamesGet_0();
case 1121605448: return bem_serializeToString_0();
case -1315551696: return bem_ntypesGet_0();
case 2143550869: return bem_new_0();
case 444413474: return bem_toAny_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1863207166: return bem_def_1(bevd_0);
case -1114550651: return bem_undefined_1(bevd_0);
case -1550385100: return bem_transSetDirect_1(bevd_0);
case -1035577062: return bem_equals_1(bevd_0);
case 1290184008: return bem_constSet_1(bevd_0);
case -351226620: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1417473277: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -690118127: return bem_buildSetDirect_1(bevd_0);
case -933911215: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 288210658: return bem_ntypesSet_1(bevd_0);
case -1776510589: return bem_copyTo_1(bevd_0);
case 2123468926: return bem_sameObject_1(bevd_0);
case 775033796: return bem_sameClass_1(bevd_0);
case 1947170687: return bem_accept_1((BEC_2_5_4_BuildNode) bevd_0);
case -873749918: return bem_begin_1(bevd_0);
case 2031133019: return bem_end_1(bevd_0);
case 544363262: return bem_otherClass_1(bevd_0);
case 459298083: return bem_otherType_1(bevd_0);
case -1155685893: return bem_transSet_1(bevd_0);
case 1189274855: return bem_sameType_1(bevd_0);
case 1719411527: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case 171056025: return bem_defined_1(bevd_0);
case -839680850: return bem_undef_1(bevd_0);
case -571354968: return bem_notEquals_1(bevd_0);
case 82127106: return bem_constSetDirect_1(bevd_0);
case -1888439820: return bem_buildSet_1(bevd_0);
case 85498757: return bem_ntypesSetDirect_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 661608167: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 319580096: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -111616333: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -87616259: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 710208868: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case 520958435: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -842656681: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(19, becc_BEC_3_5_5_7_BuildVisitVisitor_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(23, becc_BEC_3_5_5_7_BuildVisitVisitor_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_3_5_5_7_BuildVisitVisitor();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst = (BEC_3_5_5_7_BuildVisitVisitor) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_3_5_5_7_BuildVisitVisitor.bece_BEC_3_5_5_7_BuildVisitVisitor_bevs_type;
}
}
