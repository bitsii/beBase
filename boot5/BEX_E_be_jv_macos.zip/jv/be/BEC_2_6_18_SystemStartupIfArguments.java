package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_18_SystemStartupIfArguments extends BEC_2_6_6_SystemObject {
public BEC_2_6_18_SystemStartupIfArguments() { }
private static byte[] becc_BEC_2_6_18_SystemStartupIfArguments_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x49,0x66,0x41,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_6_18_SystemStartupIfArguments_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
private static BEC_2_4_3_MathInt bece_BEC_2_6_18_SystemStartupIfArguments_bevo_0 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_18_SystemStartupIfArguments_bevo_1 = (new BEC_2_4_3_MathInt(0));
public static BEC_2_6_18_SystemStartupIfArguments bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst;

public static BET_2_6_18_SystemStartupIfArguments bece_BEC_2_6_18_SystemStartupIfArguments_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_18_SystemStartupIfArguments bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_18_SystemStartupIfArguments bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
bevt_0_tmpany_phold = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_tmpany_phold.bem_argsGet_0();
bevt_2_tmpany_phold = bevp_args.bem_sizeGet_0();
bevt_3_tmpany_phold = bece_BEC_2_6_18_SystemStartupIfArguments_bevo_0;
if (bevt_2_tmpany_phold.bevi_int > bevt_3_tmpany_phold.bevi_int) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 52 */ {
bevt_6_tmpany_phold = bece_BEC_2_6_18_SystemStartupIfArguments_bevo_1;
bevt_5_tmpany_phold = bevp_args.bem_get_1(bevt_6_tmpany_phold);
bevt_4_tmpany_phold = bem_createInstance_1((BEC_2_4_6_TextString) bevt_5_tmpany_phold );
bevl_x = bevt_4_tmpany_phold.bemd_0(-260016569);
bevt_7_tmpany_phold = bevl_x.bemd_0(2109151894);
return bevt_7_tmpany_phold;
} /* Line: 54 */
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public final BEC_2_9_4_ContainerList bem_argsGetDirect_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_18_SystemStartupIfArguments bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_18_SystemStartupIfArguments bem_argsSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {51, 51, 52, 52, 52, 52, 53, 53, 53, 53, 54, 54, 56, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {30, 31, 32, 33, 34, 39, 40, 41, 42, 43, 44, 45, 47, 50, 53, 56, 60};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 51 30
new 0 51 30
assign 1 51 31
argsGet 0 51 31
assign 1 52 32
sizeGet 0 52 32
assign 1 52 33
new 0 52 33
assign 1 52 34
greater 1 52 39
assign 1 53 40
new 0 53 40
assign 1 53 41
get 1 53 41
assign 1 53 42
createInstance 1 53 42
assign 1 53 43
new 0 53 43
assign 1 54 44
main 0 54 44
return 1 54 45
return 1 56 47
return 1 0 50
return 1 0 53
assign 1 0 56
assign 1 0 60
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 2109151894: return bem_main_0();
case 520238370: return bem_print_0();
case 1754760186: return bem_iteratorGet_0();
case 1841075196: return bem_deserializeClassNameGet_0();
case 834974873: return bem_once_0();
case -1153621323: return bem_sourceFileNameGet_0();
case -1768745420: return bem_argsGet_0();
case -516300936: return bem_many_0();
case -260016569: return bem_new_0();
case 1363596807: return bem_toAny_0();
case 1695553285: return bem_toString_0();
case 510740763: return bem_echo_0();
case -1906011811: return bem_classNameGet_0();
case -1481120: return bem_hashGet_0();
case 1934827441: return bem_tagGet_0();
case -2049404332: return bem_fieldIteratorGet_0();
case 1246525343: return bem_copy_0();
case 629513215: return bem_create_0();
case -1395512224: return bem_default_0();
case -1151122392: return bem_serializeToString_0();
case -2047520171: return bem_argsGetDirect_0();
case -319884304: return bem_serializationIteratorGet_0();
case 80505915: return bem_fieldNamesGet_0();
case -1784818407: return bem_serializeContents_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 462621647: return bem_def_1(bevd_0);
case -1512005598: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1177836823: return bem_sameType_1(bevd_0);
case -951929577: return bem_defined_1(bevd_0);
case 1049358928: return bem_equals_1(bevd_0);
case -425603043: return bem_argsSet_1(bevd_0);
case -1573802551: return bem_sameObject_1(bevd_0);
case 1632353878: return bem_undef_1(bevd_0);
case 216738391: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case -1430178609: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 482689426: return bem_otherClass_1(bevd_0);
case -818774645: return bem_argsSetDirect_1(bevd_0);
case 1523343000: return bem_sameClass_1(bevd_0);
case -228195679: return bem_copyTo_1(bevd_0);
case 2122170094: return bem_otherType_1(bevd_0);
case -1144341678: return bem_notEquals_1(bevd_0);
case -395850459: return bem_undefined_1(bevd_0);
case 989721692: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 1872811781: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 518732674: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -1018924161: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 308804077: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 2072018670: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -357078730: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -277637599: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_18_SystemStartupIfArguments_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_18_SystemStartupIfArguments_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_18_SystemStartupIfArguments();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst = (BEC_2_6_18_SystemStartupIfArguments) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_type;
}
}
