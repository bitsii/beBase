package be;
/* IO:File: source/extended/Startup.be */
public class BEC_2_6_18_SystemStartupIfArguments extends BEC_2_6_6_SystemObject {
public BEC_2_6_18_SystemStartupIfArguments() { }
private static byte[] becc_BEC_2_6_18_SystemStartupIfArguments_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x49,0x66,0x41,0x72,0x67,0x75,0x6D,0x65,0x6E,0x74,0x73};
private static byte[] becc_BEC_2_6_18_SystemStartupIfArguments_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x65,0x78,0x74,0x65,0x6E,0x64,0x65,0x64,0x2F,0x53,0x74,0x61,0x72,0x74,0x75,0x70,0x2E,0x62,0x65};
public static BEC_2_6_18_SystemStartupIfArguments bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst;

public static BET_2_6_18_SystemStartupIfArguments bece_BEC_2_6_18_SystemStartupIfArguments_bevs_type;

public BEC_2_9_4_ContainerList bevp_args;
public BEC_2_6_18_SystemStartupIfArguments bem_create_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_18_SystemStartupIfArguments bem_default_0() throws Throwable {
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_main_0() throws Throwable {
BEC_2_6_6_SystemObject bevl_x = null;
BEC_2_6_7_SystemProcess bevt_0_ta_ph = null;
BEC_2_5_4_LogicBool bevt_1_ta_ph = null;
BEC_2_4_3_MathInt bevt_2_ta_ph = null;
BEC_2_4_3_MathInt bevt_3_ta_ph = null;
BEC_2_6_6_SystemObject bevt_4_ta_ph = null;
BEC_2_6_6_SystemObject bevt_5_ta_ph = null;
BEC_2_4_3_MathInt bevt_6_ta_ph = null;
BEC_2_6_6_SystemObject bevt_7_ta_ph = null;
bevt_0_ta_ph = (BEC_2_6_7_SystemProcess) BEC_2_6_7_SystemProcess.bece_BEC_2_6_7_SystemProcess_bevs_inst;
bevp_args = bevt_0_ta_ph.bem_argsGet_0();
bevt_2_ta_ph = bevp_args.bem_sizeGet_0();
bevt_3_ta_ph = (new BEC_2_4_3_MathInt(0));
if (bevt_2_ta_ph.bevi_int > bevt_3_ta_ph.bevi_int) {
bevt_1_ta_ph = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_ta_ph = be.BECS_Runtime.boolFalse;
}
if (bevt_1_ta_ph.bevi_bool)/* Line: 51*/ {
bevt_6_ta_ph = (new BEC_2_4_3_MathInt(0));
bevt_5_ta_ph = bevp_args.bem_get_1(bevt_6_ta_ph);
bevt_4_ta_ph = bem_createInstance_1((BEC_2_4_6_TextString) bevt_5_ta_ph );
bevl_x = bevt_4_ta_ph.bemd_0(2115475884);
bevt_7_ta_ph = bevl_x.bemd_0(1703942120);
return bevt_7_ta_ph;
} /* Line: 53*/
return this;
} /*method end*/
public BEC_2_9_4_ContainerList bem_argsGet_0() throws Throwable {
return bevp_args;
} /*method end*/
public BEC_2_6_18_SystemStartupIfArguments bem_argsSet_1(BEC_2_6_6_SystemObject bevt_0_ta_SET) throws Throwable {
bevp_args = (BEC_2_9_4_ContainerList) bevt_0_ta_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {50, 50, 51, 51, 51, 51, 52, 52, 52, 52, 53, 53, 55, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {28, 29, 30, 31, 32, 37, 38, 39, 40, 41, 42, 43, 45, 48, 51};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 50 28
new 0 50 28
assign 1 50 29
argsGet 0 50 29
assign 1 51 30
sizeGet 0 51 30
assign 1 51 31
new 0 51 31
assign 1 51 32
greater 1 51 37
assign 1 52 38
new 0 52 38
assign 1 52 39
get 1 52 39
assign 1 52 40
createInstance 1 52 40
assign 1 52 41
new 0 52 41
assign 1 53 42
main 0 53 42
return 1 53 43
return 1 55 45
return 1 0 48
assign 1 0 51
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 49169285: return bem_create_0();
case -7476103: return bem_hashGet_0();
case 1519398611: return bem_argsGet_0();
case 1631198925: return bem_print_0();
case -2129238938: return bem_fieldNamesGet_0();
case 2115475884: return bem_new_0();
case -854129615: return bem_classNameGet_0();
case 1703942120: return bem_main_0();
case 744789579: return bem_tagGet_0();
case 956564530: return bem_toString_0();
case -6785712: return bem_copy_0();
case -928436113: return bem_default_0();
case 235554219: return bem_iteratorGet_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case -1256020058: return bem_otherType_1(bevd_0);
case -1554337727: return bem_sameObject_1(bevd_0);
case 1338190085: return bem_def_1(bevd_0);
case 1149746123: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -2142487980: return bem_sameType_1(bevd_0);
case -496051145: return bem_argsSet_1(bevd_0);
case -1005385637: return bem_copyTo_1(bevd_0);
case -76922352: return bem_equals_1(bevd_0);
case -2052423771: return bem_notEquals_1(bevd_0);
case -1184273709: return bem_undef_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case -829590487: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case -744751889: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1116067959: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -383996467: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case -1363599577: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(25, becc_BEC_2_6_18_SystemStartupIfArguments_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(26, becc_BEC_2_6_18_SystemStartupIfArguments_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_18_SystemStartupIfArguments();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst = (BEC_2_6_18_SystemStartupIfArguments) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_18_SystemStartupIfArguments.bece_BEC_2_6_18_SystemStartupIfArguments_bevs_type;
}
}
