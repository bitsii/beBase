package be;

import java.util.concurrent.locks.ReentrantLock;
/* IO:File: source/base/System.be */
public class BEC_2_6_8_SystemBasePath extends BEC_2_6_6_SystemObject {
public BEC_2_6_8_SystemBasePath() { }
private static byte[] becc_BEC_2_6_8_SystemBasePath_clname = {0x53,0x79,0x73,0x74,0x65,0x6D,0x3A,0x42,0x61,0x73,0x65,0x50,0x61,0x74,0x68};
private static byte[] becc_BEC_2_6_8_SystemBasePath_clfile = {0x73,0x6F,0x75,0x72,0x63,0x65,0x2F,0x62,0x61,0x73,0x65,0x2F,0x53,0x79,0x73,0x74,0x65,0x6D,0x2E,0x62,0x65};
private static byte[] bece_BEC_2_6_8_SystemBasePath_bels_0 = {0x20};
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_0 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_1 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_2 = (new BEC_2_4_3_MathInt(1));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_3 = (new BEC_2_4_3_MathInt(0));
private static BEC_2_4_3_MathInt bece_BEC_2_6_8_SystemBasePath_bevo_4 = (new BEC_2_4_3_MathInt(1));
public static BEC_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_inst;

public static BET_2_6_8_SystemBasePath bece_BEC_2_6_8_SystemBasePath_bevs_type;

public BEC_2_4_6_TextString bevp_separator;
public BEC_2_4_6_TextString bevp_path;
public BEC_2_6_8_SystemBasePath bem_new_0() throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bem_new_1(bevt_0_tmpany_phold);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_new_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_separator = (new BEC_2_4_6_TextString(1, bece_BEC_2_6_8_SystemBasePath_bels_0));
bem_fromString_1(beva_spath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_fromString_1(BEC_2_4_6_TextString beva_spath) throws Throwable {
bevp_path = beva_spath;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_4_6_TextString bem_toString_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_toStringWithSeparator_1(beva_newsep);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_toStringWithSeparator_1(BEC_2_4_6_TextString beva_newsep) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_4_6_TextString bevl_npath = null;
BEC_2_4_7_TextStrings bevt_0_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_npath = bevt_0_tmpany_phold.bem_join_2(beva_newsep, bevl_fpath);
return bevl_npath;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepListGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_firstStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_firstGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_6_TextString bem_lastStepGet_0() throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_9_10_ContainerLinkedList bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bem_lastGet_0();
return (BEC_2_4_6_TextString) bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_add_1(BEC_2_6_6_SystemObject beva_other) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_9_10_ContainerLinkedList bevl_spath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevl_l = null;
BEC_2_4_6_TextString bevl_rstr = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_4_6_TextString bevt_2_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_3_tmpany_phold = null;
BEC_2_6_8_SystemBasePath bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_6_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_7_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_8_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_9_tmpany_phold = null;
bevt_1_tmpany_phold = beva_other.bemd_0(254113130);
bevt_3_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_2_tmpany_phold = bevt_3_tmpany_phold.bem_emptyGet_0();
bevt_0_tmpany_phold = bevt_1_tmpany_phold.bemd_1(-1830241337, bevt_2_tmpany_phold);
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 355 */ {
bevt_4_tmpany_phold = bem_copy_0();
return (BEC_2_6_8_SystemBasePath) bevt_4_tmpany_phold;
} /* Line: 356 */
bevt_5_tmpany_phold = beva_other.bemd_0(-1966915114);
if (((BEC_2_5_4_LogicBool) bevt_5_tmpany_phold).bevi_bool) /* Line: 358 */ {
bevt_6_tmpany_phold = beva_other.bemd_0(290847982);
return (BEC_2_6_8_SystemBasePath) bevt_6_tmpany_phold;
} /* Line: 359 */
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevt_7_tmpany_phold = beva_other.bemd_0(254113130);
bevl_spath = (BEC_2_9_10_ContainerLinkedList) bevt_7_tmpany_phold.bemd_1(1454928685, bevp_separator);
bevl_i = bevl_spath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 363 */ {
bevt_8_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_8_tmpany_phold).bevi_bool) /* Line: 363 */ {
bevl_l = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevl_l);
} /* Line: 365 */
 else  /* Line: 363 */ {
break;
} /* Line: 363 */
} /* Line: 363 */
bevt_9_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevl_rstr = bevt_9_tmpany_phold.bem_join_2(bevp_separator, bevl_fpath);
bevl_rpath = bem_copy_0();
bevl_rpath = bevl_rpath.bem_fromString_1(bevl_rstr);
return (BEC_2_6_8_SystemBasePath) bevl_rpath;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_parentGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_2_6_8_SystemBasePath bevl_rpath = null;
BEC_2_4_3_MathInt bevl_rpl = null;
BEC_2_4_3_MathInt bevl_c = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_rpath = bem_copy_0();
bevt_0_tmpany_phold = (new BEC_2_4_6_TextString()).bem_new_0();
bevl_rpath.bem_pathSet_1(bevt_0_tmpany_phold);
bevl_rpl = bevl_fpath.bem_lengthGet_0();
bevl_rpl = bevl_rpl.bem_decrement_0();
bevl_c = (new BEC_2_4_3_MathInt(0));
bevl_i = bevl_fpath.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 381 */ {
bevt_1_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_1_tmpany_phold).bevi_bool) /* Line: 381 */ {
if (bevl_c.bevi_int < bevl_rpl.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 382 */ {
bevt_3_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_rpath.bem_addStep_1(bevt_3_tmpany_phold);
} /* Line: 383 */
 else  /* Line: 384 */ {
bevl_i.bem_nextGet_0();
} /* Line: 385 */
bevl_c = bevl_c.bem_increment_0();
} /* Line: 387 */
 else  /* Line: 381 */ {
break;
} /* Line: 381 */
} /* Line: 381 */
bevt_4_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 389 */ {
bevl_rpath.bem_makeAbsolute_0();
} /* Line: 390 */
return bevl_rpath;
} /*method end*/
public BEC_2_5_4_LogicBool bem_isAbsoluteGet_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_6_TextString bevt_4_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
BEC_2_4_6_TextString bevt_8_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_9_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_10_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_11_tmpany_phold = null;
if (bevp_path == null) {
bevt_1_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_1_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_1_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
bevt_4_tmpany_phold = bevp_path.bem_toString_0();
bevt_3_tmpany_phold = bevt_4_tmpany_phold.bem_sizeGet_0();
bevt_5_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_0;
if (bevt_3_tmpany_phold.bevi_int < bevt_5_tmpany_phold.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 396 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 396 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 396 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 396 */
bevt_9_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_1;
bevt_8_tmpany_phold = bevp_path.bem_getPoint_1(bevt_9_tmpany_phold);
bevt_7_tmpany_phold = bevt_8_tmpany_phold.bem_equals_1(bevp_separator);
if (bevt_7_tmpany_phold.bevi_bool) /* Line: 397 */ {
bevt_10_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_10_tmpany_phold;
} /* Line: 398 */
bevt_11_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_11_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeNonAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
bevt_0_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 404 */ {
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_2;
bevt_2_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_1_tmpany_phold, bevt_2_tmpany_phold);
} /* Line: 405 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_makeAbsolute_0() throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_isAbsoluteGet_0();
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 410 */ {
bevp_path = bevp_separator.bem_add_1(bevp_path);
} /* Line: 411 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_trimParents_1(BEC_2_4_3_MathInt beva_howMany) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_current = null;
BEC_3_9_10_4_ContainerLinkedListNode bevl_next = null;
BEC_2_4_3_MathInt bevl_i = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_1_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_3_tmpany_phold = null;
bevt_1_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_3;
if (beva_howMany.bevi_int > bevt_1_tmpany_phold.bevi_int) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 416 */ {
bem_makeNonAbsolute_0();
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_next = bevl_fpath.bem_firstNodeGet_0();
bevl_i = (new BEC_2_4_3_MathInt(0));
while (true)
 /* Line: 421 */ {
if (bevl_i.bevi_int < beva_howMany.bevi_int) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 421 */ {
if (bevl_next == null) {
bevt_3_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_3_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_3_tmpany_phold.bevi_bool) /* Line: 422 */ {
break;
} /* Line: 422 */
bevl_current = bevl_next;
bevl_next = bevl_current.bem_nextGet_0();
bevl_current.bem_delete_0();
bevl_i = bevl_i.bem_increment_0();
} /* Line: 421 */
 else  /* Line: 421 */ {
break;
} /* Line: 421 */
} /* Line: 421 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
} /* Line: 427 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStep_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_step);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_deleteFirstStep_0() throws Throwable {
BEC_2_4_3_MathInt bevl_fp = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_1_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_2_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_3_tmpany_phold = null;
BEC_2_4_3_MathInt bevt_4_tmpany_phold = null;
bevl_fp = bevp_path.bem_find_1(bevp_separator);
if (bevl_fp == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 439 */ {
bevt_1_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevp_path = bevt_1_tmpany_phold.bem_emptyGet_0();
} /* Line: 440 */
 else  /* Line: 441 */ {
bevt_3_tmpany_phold = bece_BEC_2_6_8_SystemBasePath_bevo_4;
bevt_2_tmpany_phold = bevl_fp.bem_add_1(bevt_3_tmpany_phold);
bevt_4_tmpany_phold = bevp_path.bem_sizeGet_0();
bevp_path = bevp_path.bem_substring_2(bevt_2_tmpany_phold, bevt_4_tmpany_phold);
} /* Line: 442 */
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addStepList_1(BEC_2_9_10_ContainerLinkedList beva_sl) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
BEC_3_9_10_8_ContainerLinkedListIterator bevl_i = null;
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_1_tmpany_phold = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_i = beva_sl.bem_linkedListIteratorGet_0();
while (true)
 /* Line: 448 */ {
bevt_0_tmpany_phold = bevl_i.bem_hasNextGet_0();
if (((BEC_2_5_4_LogicBool) bevt_0_tmpany_phold).bevi_bool) /* Line: 448 */ {
bevt_1_tmpany_phold = bevl_i.bem_nextGet_0();
bevl_fpath.bem_addValue_1(bevt_1_tmpany_phold);
} /* Line: 449 */
 else  /* Line: 448 */ {
break;
} /* Line: 448 */
} /* Line: 448 */
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_6_SystemObject bem_addSteps_1(BEC_2_6_6_SystemObject beva_step) throws Throwable {
BEC_2_6_8_SystemBasePath bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_addStep_1(beva_step);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_addSteps_2(BEC_2_6_6_SystemObject beva_s1, BEC_2_6_6_SystemObject beva_s2) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_fpath = null;
bevl_fpath = bevp_path.bem_split_1(bevp_separator);
bevl_fpath.bem_addValue_1(beva_s1);
bevl_fpath.bem_addValue_1(beva_s2);
bevp_path = bevp_path.bem_join_2(bevp_separator, bevl_fpath);
return this;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_copy_0() throws Throwable {
BEC_2_6_8_SystemBasePath bevl_other = null;
BEC_2_4_6_TextString bevt_0_tmpany_phold = null;
bevl_other = (BEC_2_6_8_SystemBasePath) bem_create_0();
bem_copyTo_1(bevl_other);
bevt_0_tmpany_phold = bevp_path.bem_copy_0();
bevl_other.bem_pathSet_1(bevt_0_tmpany_phold);
return (BEC_2_6_8_SystemBasePath) bevl_other;
} /*method end*/
public BEC_2_9_10_ContainerLinkedList bem_stepsGet_0() throws Throwable {
BEC_2_9_10_ContainerLinkedList bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_split_1(bevp_separator);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_4_3_MathInt bem_hashGet_0() throws Throwable {
BEC_2_4_3_MathInt bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bevp_path.bem_hashGet_0();
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_notEquals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_phold = null;
bevt_1_tmpany_phold = bem_equals_1(beva_x);
if (bevt_1_tmpany_phold.bevi_bool) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
}
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_5_4_LogicBool bem_equals_1(BEC_2_6_6_SystemObject beva_x) throws Throwable {
BEC_2_5_4_LogicBool bevt_0_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_1_tmpany_anchor = null;
BEC_2_5_4_LogicBool bevt_2_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_3_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_4_tmpany_phold = null;
BEC_2_6_6_SystemObject bevt_5_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_6_tmpany_phold = null;
BEC_2_5_4_LogicBool bevt_7_tmpany_phold = null;
if (beva_x == null) {
bevt_2_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_2_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_2_tmpany_phold.bevi_bool) /* Line: 488 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 488 */ {
bevt_3_tmpany_phold = beva_x.bemd_1(-167158523, this);
if (((BEC_2_5_4_LogicBool) bevt_3_tmpany_phold).bevi_bool) /* Line: 488 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 488 */ {
bevt_1_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 488 */
if (bevt_1_tmpany_anchor.bevi_bool) /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 488 */ {
bevt_5_tmpany_phold = beva_x.bemd_0(254113130);
bevt_4_tmpany_phold = bevp_path.bem_notEquals_1(bevt_5_tmpany_phold);
if (bevt_4_tmpany_phold.bevi_bool) /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolTrue;
} /* Line: 0 */
 else  /* Line: 488 */ {
bevt_0_tmpany_anchor = be.BECS_Runtime.boolFalse;
} /* Line: 0 */
} /* Line: 488 */
if (bevt_0_tmpany_anchor.bevi_bool) /* Line: 488 */ {
bevt_6_tmpany_phold = be.BECS_Runtime.boolFalse;
return bevt_6_tmpany_phold;
} /* Line: 489 */
bevt_7_tmpany_phold = be.BECS_Runtime.boolTrue;
return bevt_7_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_1(BEC_2_4_3_MathInt beva_start) throws Throwable {
BEC_2_6_6_SystemObject bevt_0_tmpany_phold = null;
bevt_0_tmpany_phold = bem_subPath_2(beva_start, null);
return bevt_0_tmpany_phold;
} /*method end*/
public BEC_2_6_6_SystemObject bem_subPath_2(BEC_2_4_3_MathInt beva_start, BEC_2_4_3_MathInt beva_end) throws Throwable {
BEC_2_9_10_ContainerLinkedList bevl_st = null;
BEC_2_6_6_SystemObject bevl_ll = null;
BEC_2_6_6_SystemObject bevl_res = null;
BEC_2_5_4_LogicBool bevt_0_tmpany_phold = null;
BEC_2_4_6_TextString bevt_1_tmpany_phold = null;
BEC_2_4_7_TextStrings bevt_2_tmpany_phold = null;
bevl_st = bem_stepsGet_0();
if (beva_end == null) {
bevt_0_tmpany_phold = be.BECS_Runtime.boolTrue;
 } else { 
bevt_0_tmpany_phold = be.BECS_Runtime.boolFalse;
}
if (bevt_0_tmpany_phold.bevi_bool) /* Line: 500 */ {
bevl_ll = bevl_st.bem_subList_1(beva_start);
} /* Line: 501 */
 else  /* Line: 502 */ {
bevl_ll = bevl_st.bem_subList_2(beva_start, beva_end);
} /* Line: 503 */
bevl_res = bem_create_0();
bevl_res.bemd_1(-1945004538, bevp_separator);
bevt_2_tmpany_phold = (BEC_2_4_7_TextStrings) BEC_2_4_7_TextStrings.bece_BEC_2_4_7_TextStrings_bevs_inst;
bevt_1_tmpany_phold = bevt_2_tmpany_phold.bem_join_2(bevp_separator, bevl_ll);
bevl_res.bemd_1(-1373607278, bevt_1_tmpany_phold);
return bevl_res;
} /*method end*/
public BEC_2_4_6_TextString bem_separatorGet_0() throws Throwable {
return bevp_separator;
} /*method end*/
public final BEC_2_4_6_TextString bem_separatorGetDirect_0() throws Throwable {
return bevp_separator;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_separatorSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_separatorSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_separator = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public BEC_2_4_6_TextString bem_pathGet_0() throws Throwable {
return bevp_path;
} /*method end*/
public final BEC_2_4_6_TextString bem_pathGetDirect_0() throws Throwable {
return bevp_path;
} /*method end*/
public BEC_2_6_8_SystemBasePath bem_pathSet_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public final BEC_2_6_8_SystemBasePath bem_pathSetDirect_1(BEC_2_6_6_SystemObject bevt_0_tmpany_SET) throws Throwable {
bevp_path = (BEC_2_4_6_TextString) bevt_0_tmpany_SET;
return this;
} /*method end*/
public static int[] bems_smnlc() {
return new int[] {316, 316, 320, 321, 325, 329, 333, 333, 337, 338, 338, 339, 343, 343, 347, 347, 347, 351, 351, 351, 355, 355, 355, 355, 356, 356, 358, 359, 359, 361, 362, 362, 363, 363, 364, 365, 367, 367, 368, 369, 371, 375, 376, 377, 377, 378, 379, 380, 381, 381, 382, 382, 383, 383, 385, 387, 389, 390, 392, 396, 396, 0, 396, 396, 396, 396, 396, 0, 0, 396, 396, 397, 397, 397, 398, 398, 400, 400, 404, 405, 405, 405, 410, 410, 410, 411, 416, 416, 416, 417, 418, 420, 421, 421, 421, 422, 422, 423, 424, 425, 421, 427, 432, 433, 434, 438, 439, 439, 440, 440, 442, 442, 442, 442, 447, 448, 448, 449, 449, 451, 455, 455, 459, 460, 461, 462, 466, 467, 468, 468, 469, 473, 473, 477, 477, 481, 481, 481, 488, 488, 0, 488, 0, 0, 0, 488, 488, 0, 0, 489, 489, 491, 491, 495, 495, 499, 500, 500, 501, 503, 505, 506, 507, 507, 507, 508, 0, 0, 0, 0, 0, 0, 0, 0};
}
public static int[] bevs_smnlc
 = bems_smnlc();
public static int[] bems_smnlec() {
return new int[] {23, 24, 28, 29, 33, 37, 41, 42, 48, 49, 50, 51, 55, 56, 61, 62, 63, 68, 69, 70, 89, 90, 91, 92, 94, 95, 97, 99, 100, 102, 103, 104, 105, 108, 110, 111, 117, 118, 119, 120, 121, 134, 135, 136, 137, 138, 139, 140, 141, 144, 146, 151, 152, 153, 156, 158, 164, 166, 168, 183, 188, 189, 192, 193, 194, 195, 200, 201, 204, 208, 209, 211, 212, 213, 215, 216, 218, 219, 225, 227, 228, 229, 236, 237, 242, 243, 256, 257, 262, 263, 264, 265, 266, 269, 274, 275, 280, 283, 284, 285, 286, 292, 298, 299, 300, 310, 311, 316, 317, 318, 321, 322, 323, 324, 333, 334, 337, 339, 340, 346, 351, 352, 356, 357, 358, 359, 365, 366, 367, 368, 369, 373, 374, 378, 379, 384, 385, 390, 401, 406, 407, 410, 412, 415, 419, 422, 423, 425, 428, 432, 433, 435, 436, 440, 441, 450, 451, 456, 457, 460, 462, 463, 464, 465, 466, 467, 470, 473, 476, 480, 484, 487, 490, 494};
}
public static int[] bevs_smnlec
 = bems_smnlec();
/* BEGIN LINEINFO 
assign 1 316 23
new 0 316 23
new 1 316 24
assign 1 320 28
new 0 320 28
fromString 1 321 29
assign 1 325 33
return 1 329 37
assign 1 333 41
toStringWithSeparator 1 333 41
return 1 333 42
assign 1 337 48
split 1 337 48
assign 1 338 49
new 0 338 49
assign 1 338 50
join 2 338 50
return 1 339 51
assign 1 343 55
split 1 343 55
return 1 343 56
assign 1 347 61
split 1 347 61
assign 1 347 62
firstGet 0 347 62
return 1 347 63
assign 1 351 68
split 1 351 68
assign 1 351 69
lastGet 0 351 69
return 1 351 70
assign 1 355 89
pathGet 0 355 89
assign 1 355 90
new 0 355 90
assign 1 355 91
emptyGet 0 355 91
assign 1 355 92
equals 1 355 92
assign 1 356 94
copy 0 356 94
return 1 356 95
assign 1 358 97
isAbsoluteGet 0 358 97
assign 1 359 99
copy 0 359 99
return 1 359 100
assign 1 361 102
split 1 361 102
assign 1 362 103
pathGet 0 362 103
assign 1 362 104
split 1 362 104
assign 1 363 105
linkedListIteratorGet 0 363 105
assign 1 363 108
hasNextGet 0 363 108
assign 1 364 110
nextGet 0 364 110
addValue 1 365 111
assign 1 367 117
new 0 367 117
assign 1 367 118
join 2 367 118
assign 1 368 119
copy 0 368 119
assign 1 369 120
fromString 1 369 120
return 1 371 121
assign 1 375 134
split 1 375 134
assign 1 376 135
copy 0 376 135
assign 1 377 136
new 0 377 136
pathSet 1 377 137
assign 1 378 138
lengthGet 0 378 138
assign 1 379 139
decrement 0 379 139
assign 1 380 140
new 0 380 140
assign 1 381 141
linkedListIteratorGet 0 381 141
assign 1 381 144
hasNextGet 0 381 144
assign 1 382 146
lesser 1 382 151
assign 1 383 152
nextGet 0 383 152
addStep 1 383 153
nextGet 0 385 156
assign 1 387 158
increment 0 387 158
assign 1 389 164
isAbsoluteGet 0 389 164
makeAbsolute 0 390 166
return 1 392 168
assign 1 396 183
undef 1 396 188
assign 1 0 189
assign 1 396 192
toString 0 396 192
assign 1 396 193
sizeGet 0 396 193
assign 1 396 194
new 0 396 194
assign 1 396 195
lesser 1 396 200
assign 1 0 201
assign 1 0 204
assign 1 396 208
new 0 396 208
return 1 396 209
assign 1 397 211
new 0 397 211
assign 1 397 212
getPoint 1 397 212
assign 1 397 213
equals 1 397 213
assign 1 398 215
new 0 398 215
return 1 398 216
assign 1 400 218
new 0 400 218
return 1 400 219
assign 1 404 225
isAbsoluteGet 0 404 225
assign 1 405 227
new 0 405 227
assign 1 405 228
sizeGet 0 405 228
assign 1 405 229
substring 2 405 229
assign 1 410 236
isAbsoluteGet 0 410 236
assign 1 410 237
not 0 410 242
assign 1 411 243
add 1 411 243
assign 1 416 256
new 0 416 256
assign 1 416 257
greater 1 416 262
makeNonAbsolute 0 417 263
assign 1 418 264
split 1 418 264
assign 1 420 265
firstNodeGet 0 420 265
assign 1 421 266
new 0 421 266
assign 1 421 269
lesser 1 421 274
assign 1 422 275
undef 1 422 280
assign 1 423 283
assign 1 424 284
nextGet 0 424 284
delete 0 425 285
assign 1 421 286
increment 0 421 286
assign 1 427 292
join 2 427 292
assign 1 432 298
split 1 432 298
addValue 1 433 299
assign 1 434 300
join 2 434 300
assign 1 438 310
find 1 438 310
assign 1 439 311
undef 1 439 316
assign 1 440 317
new 0 440 317
assign 1 440 318
emptyGet 0 440 318
assign 1 442 321
new 0 442 321
assign 1 442 322
add 1 442 322
assign 1 442 323
sizeGet 0 442 323
assign 1 442 324
substring 2 442 324
assign 1 447 333
split 1 447 333
assign 1 448 334
linkedListIteratorGet 0 448 334
assign 1 448 337
hasNextGet 0 448 337
assign 1 449 339
nextGet 0 449 339
addValue 1 449 340
assign 1 451 346
join 2 451 346
assign 1 455 351
addStep 1 455 351
return 1 455 352
assign 1 459 356
split 1 459 356
addValue 1 460 357
addValue 1 461 358
assign 1 462 359
join 2 462 359
assign 1 466 365
create 0 466 365
copyTo 1 467 366
assign 1 468 367
copy 0 468 367
pathSet 1 468 368
return 1 469 369
assign 1 473 373
split 1 473 373
return 1 473 374
assign 1 477 378
hashGet 0 477 378
return 1 477 379
assign 1 481 384
equals 1 481 384
assign 1 481 385
not 0 481 390
return 1 481 390
assign 1 488 401
undef 1 488 406
assign 1 0 407
assign 1 488 410
otherType 1 488 410
assign 1 0 412
assign 1 0 415
assign 1 0 419
assign 1 488 422
pathGet 0 488 422
assign 1 488 423
notEquals 1 488 423
assign 1 0 425
assign 1 0 428
assign 1 489 432
new 0 489 432
return 1 489 433
assign 1 491 435
new 0 491 435
return 1 491 436
assign 1 495 440
subPath 2 495 440
return 1 495 441
assign 1 499 450
stepsGet 0 499 450
assign 1 500 451
undef 1 500 456
assign 1 501 457
subList 1 501 457
assign 1 503 460
subList 2 503 460
assign 1 505 462
create 0 505 462
separatorSet 1 506 463
assign 1 507 464
new 0 507 464
assign 1 507 465
join 2 507 465
pathSet 1 507 466
return 1 508 467
return 1 0 470
return 1 0 473
assign 1 0 476
assign 1 0 480
return 1 0 484
return 1 0 487
assign 1 0 490
assign 1 0 494
END LINEINFO */
public BEC_2_6_6_SystemObject bemd_0(int callId) throws Throwable {
switch (callId) {
case 1441040566: return bem_sourceFileNameGet_0();
case -1302286153: return bem_fieldNamesGet_0();
case -1582894954: return bem_print_0();
case -1841553076: return bem_fieldIteratorGet_0();
case 1476014618: return bem_stepListGet_0();
case 254113130: return bem_pathGet_0();
case -1038486154: return bem_deleteFirstStep_0();
case -749659777: return bem_serializeContents_0();
case 290847982: return bem_copy_0();
case 573735614: return bem_separatorGet_0();
case -557497764: return bem_deserializeClassNameGet_0();
case 843800479: return bem_lastStepGet_0();
case -1455972480: return bem_firstStepGet_0();
case -1200923686: return bem_stepsGet_0();
case -2130319568: return bem_parentGet_0();
case -705961525: return bem_hashGet_0();
case -1607921594: return bem_iteratorGet_0();
case -94797444: return bem_tagGet_0();
case -1076974459: return bem_once_0();
case 360246200: return bem_separatorGetDirect_0();
case -1280297402: return bem_pathGetDirect_0();
case -991331785: return bem_serializationIteratorGet_0();
case 1044381470: return bem_makeNonAbsolute_0();
case -1966915114: return bem_isAbsoluteGet_0();
case -547935816: return bem_echo_0();
case 782770507: return bem_toString_0();
case -741944257: return bem_serializeToString_0();
case 233637298: return bem_makeAbsolute_0();
case 1461795953: return bem_toAny_0();
case -1838847527: return bem_many_0();
case -935373025: return bem_create_0();
case 618670577: return bem_classNameGet_0();
case 537383271: return bem_new_0();
}
return super.bemd_0(callId);
}
public BEC_2_6_6_SystemObject bemd_1(int callId, BEC_2_6_6_SystemObject bevd_0) throws Throwable {
switch (callId) {
case 529067620: return bem_sameType_1(bevd_0);
case 97981859: return bem_undef_1(bevd_0);
case -542374202: return bem_pathSetDirect_1(bevd_0);
case -1838812334: return bem_separatorSetDirect_1(bevd_0);
case 239697519: return bem_deserializeFromString_1((BEC_2_4_6_TextString) bevd_0);
case -1011791907: return bem_addSteps_1(bevd_0);
case -1373607278: return bem_pathSet_1(bevd_0);
case -1493788578: return bem_subPath_1((BEC_2_4_3_MathInt) bevd_0);
case -2085686581: return bem_defined_1(bevd_0);
case -769956181: return bem_trimParents_1((BEC_2_4_3_MathInt) bevd_0);
case 659675994: return bem_undefined_1(bevd_0);
case -167158523: return bem_otherType_1(bevd_0);
case -1378908837: return bem_fromString_1((BEC_2_4_6_TextString) bevd_0);
case 1876093054: return bem_add_1(bevd_0);
case 1237105374: return bem_notEquals_1(bevd_0);
case 1483369915: return bem_sameObject_1(bevd_0);
case -228872039: return bem_otherClass_1(bevd_0);
case -1330156098: return bem_copyTo_1(bevd_0);
case 1748491906: return bem_sameClass_1(bevd_0);
case 763245242: return bem_toStringWithSeparator_1((BEC_2_4_6_TextString) bevd_0);
case -926340668: return bem_deserializeFromStringNew_1((BEC_2_4_6_TextString) bevd_0);
case 445916200: return bem_toString_1((BEC_2_4_6_TextString) bevd_0);
case -1266347439: return bem_addStepList_1((BEC_2_9_10_ContainerLinkedList) bevd_0);
case -141397341: return bem_createInstance_1((BEC_2_4_6_TextString) bevd_0);
case -1945004538: return bem_separatorSet_1(bevd_0);
case -1434736665: return bem_getMethod_1((BEC_2_4_6_TextString) bevd_0);
case 293923702: return bem_def_1(bevd_0);
case -1830241337: return bem_equals_1(bevd_0);
case 2117181987: return bem_new_1((BEC_2_4_6_TextString) bevd_0);
case -1184078730: return bem_addStep_1(bevd_0);
}
return super.bemd_1(callId, bevd_0);
}
public BEC_2_6_6_SystemObject bemd_2(int callId, BEC_2_6_6_SystemObject bevd_0, BEC_2_6_6_SystemObject bevd_1) throws Throwable {
switch (callId) {
case 246296720: return bem_methodNotDefined_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1363285011: return bem_getMethod_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1258452187: return bem_invoke_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1900266912: return bem_forwardCall_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1382151939: return bem_createInstance_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_5_4_LogicBool) bevd_1);
case -957680293: return bem_addSteps_2(bevd_0, bevd_1);
case -1846932381: return bem_can_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
case 1600914698: return bem_getInvocation_2((BEC_2_4_6_TextString) bevd_0, (BEC_2_9_4_ContainerList) bevd_1);
case 1006301887: return bem_subPath_2((BEC_2_4_3_MathInt) bevd_0, (BEC_2_4_3_MathInt) bevd_1);
}
return super.bemd_2(callId, bevd_0, bevd_1);
}
public BEC_2_4_6_TextString bemc_clnames() throws Throwable {
return new BEC_2_4_6_TextString(15, becc_BEC_2_6_8_SystemBasePath_clname);
}
public BEC_2_4_6_TextString bemc_clfiles() throws Throwable {
return new BEC_2_4_6_TextString(21, becc_BEC_2_6_8_SystemBasePath_clfile);
}
public BEC_2_6_6_SystemObject bemc_create() throws Throwable {
return new BEC_2_6_8_SystemBasePath();
}
public void bemc_setInitial(BEC_2_6_6_SystemObject becc_inst) throws Throwable {
BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst = (BEC_2_6_8_SystemBasePath) becc_inst;
}
public BEC_2_6_6_SystemObject bemc_getInitial() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_inst;
}
public BETS_Object bemc_getType() throws Throwable {
return BEC_2_6_8_SystemBasePath.bece_BEC_2_6_8_SystemBasePath_bevs_type;
}
}
